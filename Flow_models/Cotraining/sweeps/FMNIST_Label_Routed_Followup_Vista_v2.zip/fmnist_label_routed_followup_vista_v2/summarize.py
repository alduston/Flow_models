"""Export validated matched-seed results for the pressure-by-objective comparison."""
import argparse
import csv
from pathlib import Path
import sys

from campaign import csv_rows, validate_complete
from protocol import ROOT, read, sources
from run_label_routed import DESIGN, PILOT, VAST, config_for


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pilot-dir", type=Path,
                        default=ROOT.parent / "fmnist_label_routed_rep_vista")
    parser.add_argument("--vast-dir", type=Path, default=ROOT.parent / "fmnist_tweedie_zero_vast_results")
    args = parser.parse_args()
    pilot_hashes = read(ROOT / "provenance/pilot_source_hashes.json")
    followup_hashes = sources(ROOT)
    rows = []
    missing = []
    for cell in DESIGN:
        seed, tenths, objective = cell
        expected = vars(config_for(ROOT, *cell))
        pilot = cell in PILOT
        if pilot:
            source, base = "pilot_vista", args.pilot_dir
        elif cell in VAST:
            source, base = "vast", args.vast_dir
        else:
            source, base = "followup_vista", ROOT
        run = base / "results" / expected["name"]
        if not (run / "complete.json").is_file():
            missing.append(str(run))
            continue
        # The Vast export verifies the final checkpoint before packaging metrics.
        snapshot = run / "snapshots" / f"epoch_{expected['epochs']:04d}.pt"
        validate_complete(run, production=True, verify_snapshot=source != "vast" or snapshot.is_file())
        actual = read(run / "config.json")
        for key, value in expected.items():
            if key not in ("output", "data_root") and actual[key] != value:
                raise ValueError(f"{run}: configuration mismatch for {key}")
        if actual["source_hashes"] != (pilot_hashes if pilot else followup_hashes):
            raise ValueError(f"{run}: source fingerprint mismatch")
        for row in csv_rows(run / "eval.csv"):
            if row["kind"] != "generation":
                raise ValueError(f"{run}: expected generation evaluation")
            rows.append((seed, tenths / 10, objective, int(row["epoch"]), float(row["cfg"]),
                         float(row["fid_generated"]), float(row["fid_posterior_recon"]),
                         source))
    if missing:
        sys.exit("Awaiting completed runs:\n" + "\n".join(missing))

    writer = csv.writer(sys.stdout)
    writer.writerow(["seed", "rep_factor", "score_head_loss", "epoch", "cfg",
                     "fid_generated", "fid_posterior_recon", "source"])
    writer.writerows(sorted(rows))


if __name__ == "__main__":
    main()
