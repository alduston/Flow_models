"""Submit the label-routed follow-up to Vista, waiting only when slots run out."""
import argparse
import fcntl
import getpass
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
from run_label_routed import CELLS, run_name


def queue():
    status = subprocess.run(
        ["squeue", "-h", "-r", "-u", getpass.getuser(), "-p", "gh", "-o", "%j"],
        check=True, capture_output=True, text=True,
    )
    return status.stdout.splitlines()


def sbatch_id(stdout):
    ids = set()
    for line in stdout.splitlines():
        match = re.fullmatch(r"(?:Submitted batch job\s+)?(\d+)(?:;\S+)?", line.strip())
        if match:
            ids.add(match[1])
    if len(ids) == 1:
        return ids.pop()
    return None


def at_submit_limit(message):
    return bool(re.search(
        r"submit.{0,24}limit|limit.{0,24}submit|maxsubmit|maximum number of jobs|too many jobs|"
        r"job count.{0,16}limit",
        message, re.I))


def submit(args, tasks):
    logs = BASE / "slurm_logs"
    logs.mkdir(exist_ok=True)
    with (logs / "submit.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit("A launcher is already running for this bundle.")
        return refill(args, tasks, logs)


def refill(args, tasks, logs):
    ledger = logs / "submitted.tsv"
    submitted = set()
    if ledger.exists() and not args.retry:
        submitted = {int(line.split("\t", 1)[0]) for line in ledger.read_text().splitlines()}
    while True:
        queued = queue()
        remaining = []
        limit_reached = False
        for cell, run, job, command in tasks:
            if cell in submitted or job in queued or (BASE / "results" / run / "complete.json").is_file():
                continue
            if limit_reached or len(queued) >= args.max_queued:
                remaining.append((cell, run, job, command))
                continue
            result = subprocess.run(command, capture_output=True, text=True, cwd=BASE)
            with (logs / "submission_responses.log").open("a") as responses:
                print(f"[{cell} {job} exit={result.returncode}]\n{result.stdout}{result.stderr}",
                      file=responses)
            if result.returncode:
                if not at_submit_limit(result.stderr + result.stdout):
                    raise SystemExit(f"Submission failed for {job}: {result.stderr}{result.stdout}")
                remaining.append((cell, run, job, command))
                limit_reached = True
                print(f"[SLURM LIMIT] {(result.stderr or result.stdout).strip()}", flush=True)
                continue
            jid = sbatch_id(result.stdout)
            if jid is None:
                raise SystemExit(f"Slurm returned success for {job}, but its ID was ambiguous. "
                                 "Inspect squeue and slurm_logs/submission_responses.log before retrying.")
            with ledger.open("a") as stream:
                print(cell, jid, job, sep="\t", file=stream)
            submitted.add(cell)
            queued.append(job)
            print(f"[SUBMITTED] cell={cell} job={jid} {job}", flush=True)
        if not remaining:
            print("[DONE] Every requested cell is submitted, queued, or complete.", flush=True)
            return 0
        print(f"[WAIT] {len(remaining)} cells left to submit.", flush=True)
        if not args.watch:
            print("Rerun with --watch to submit remaining cells as slots open.", flush=True)
            return 75
        time.sleep(args.poll)
        tasks = remaining


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("account")
    parser.add_argument("--cells", type=int, nargs="+", choices=range(len(CELLS)))
    parser.add_argument("--max-queued", type=int, default=40, help="Maximum user gh jobs queued or running")
    parser.add_argument("--watch", action="store_true")
    parser.add_argument("--poll", type=int, default=60)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--retry", action="store_true", help="Allow resubmission of explicitly selected inactive cells")
    args = parser.parse_args()
    if args.max_queued < 1 or args.poll < 1:
        parser.error("Queue cap and poll interval must be positive.")
    if args.retry and args.cells is None:
        parser.error("--retry requires --cells.")
    tasks = []
    for cell in dict.fromkeys(args.cells if args.cells is not None else range(len(CELLS))):
        run = run_name(*CELLS[cell])
        job = "fmrep2_" + run.removeprefix("label_routed_")
        command = ["sbatch", "--parsable", "-A", args.account, f"--job-name={job}",
                   str(BASE / "job.slurm"), str(cell)]
        tasks.append((cell, run, job, command))
    if args.dry_run:
        for _, _, _, command in tasks:
            print(shlex.join(command))
        return 0
    return submit(args, tasks)


if __name__ == "__main__":
    sys.exit(main())
