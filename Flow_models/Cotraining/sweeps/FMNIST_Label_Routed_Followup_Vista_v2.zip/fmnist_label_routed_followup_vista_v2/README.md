# FMNIST label-routed pressure follow-up on Vista and Vast.ai

This campaign uses the flat three-encoder model and the pilot's full 60k
training set, test evaluation, 500 epochs, EMA, and nine-point CFG grid at
epochs 100, 200, 300, 400, and 500. Evaluation uses 10,000 generated images,
Gaussian starts, temperature 1, RK4-20, and legacy Inception FID. CFG 0 uses
the null label.

| Condition | Existing Vista | New Vista | New Vast |
|---|---:|---:|---:|
| CSEM 0.3× | 3 | 7 | 0 |
| CSEM 0.6× | 3 | 7 | 0 |
| CSEM 0.0× | 0 | 10 | 0 |
| Tweedie 0.0× | 0 | 6 | 4 |

Each arm has seeds 43–52. The six existing Vista runs are CSEM 0.3× and
0.6× at seeds 43–45. Vast runs Tweedie 0.0× seeds 43–46. Vista runs
Tweedie 0.0× seeds 47–52. In total there are 30 new Vista jobs and four
Vast jobs.

The Tweedie score head trains on sampled diffusion noise using detached
noisy latents. The encoder receives zero score-loss gradient. Reconstruction,
perceptual, adversarial, terminal, and band terms remain active. Each
Tweedie job checks the gradient routing before training. Global gradient
clipping remains as in the pilot.

The combined CSV labels the platform for each row. Seeds 47–52 provide a
fully matched within-Vista comparison across all four conditions. The other
four paired Tweedie comparisons span Vast and Vista.

## Submit from Vista

Transfer the ZIP into the same sweeps directory as the original pilot.

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/Cotraining/sweeps
unzip FMNIST_Label_Routed_Followup_Vista_v2.zip
cd fmnist_label_routed_followup_vista_v2
export CSEM_DATA_ROOT="$(realpath ../fmnist_label_routed_rep_vista/data_cache_fmnist)"
qlimits
python3 prepare_cache.py --weights && mkdir -p slurm_logs && {
  nohup bash submit.sh DMS22021 --watch > slurm_logs/watcher.log 2>&1 < /dev/null &
}
```

The launcher submits all 30 immediately if there is room and otherwise
refills the queue as slots open. Each job requests one `gh` node for up to
20 hours. The documented submission cap is 40. If the live cap is lower,
pass `--max-queued N`. The launcher records IDs in `slurm_logs/submitted.tsv`
and exits when all requested jobs have been submitted or are already present.
Inspect failed jobs before using `bash submit.sh DMS22021 --retry --cells ID`.
Use `python3 run_label_routed.py --list` for the cell manifest and
`bash submit.sh DMS22021 --dry-run` to preview all submissions.
Use this version for a fresh submission. If the prior launcher is already
active, inspect its queue before launching this version so the shared cells
do not run twice.

Jobs use the existing `$SCRATCH/venvs/hlsi` environment by default. Export
`VENV_DIR` if it lives elsewhere. The cache and jobs honor `TORCH_HOME`.

## Combine results

Run the companion notebook on one Vast instance with two visible GPUs.
Extract its `FMNIST_Tweedie_Zero_Vast_Results.zip` into the sweeps directory
alongside this bundle. The notebook verifies completed checkpoints before
exporting the lightweight results archive. Copy final snapshots separately
if needed for inference.

```bash
python3 summarize.py > followup_fid.csv.tmp && mv followup_fid.csv.tmp followup_fid.csv
```

Pass `--pilot-dir` or `--vast-dir` if the other runs live elsewhere.
The exporter validates the evaluation grid, recipe and source fingerprints
and keeps the run origin with each row. When a Vast final snapshot is present,
the exporter verifies it again.
