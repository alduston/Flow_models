# Vista sweep of label-routed CSEM representation strength

The five representation factors 0.3×, 0.4×, 0.5×, 0.6× and 0.7× each run on fresh seeds 43, 44 and 45. The underlying `rep_multiplier` values are 0.15, 0.20, 0.25, 0.30 and 0.35, relative to the original multiplier of 0.50. The seed-42 exploratory runs motivated this grid. Each seed is shared by all five settings to support paired comparisons.

The source comes from the 0.3× Colab run, including its CPU checkpoint-reload parity check. Each job trains the same flat three-encoder label-routed co-trained model for 500 epochs on all 60,000 Fashion-MNIST training images. The representation factor scales the encoder-side score gradient. Evaluation uses the 10,000-image test reference, 10,000 generated images per CFG level, Gaussian starts, temperature 1, RK4-20 and the legacy Inception FID backend. All runs share the evaluation seed. Every evaluation uses the full grid **0, 0.5, 1, 1.5, 2, 2.5, 3, 4, 5** at epochs **100, 200, 300, 400, 500**. CFG 0 uses the null label. A completed cell has 45 generation rows.

## Submit on Vista

Place the ZIP in the directory where you want the sweep, then run these commands from that directory.

```bash
unzip FMNIST_Label_Routed_Rep_Sweep_Vista.zip
cd fmnist_label_routed_rep_vista
python3 prepare_cache.py --weights && bash submit.sh DMS22021
```

Run cache preparation on the login node. It verifies or downloads Fashion-MNIST and the pretrained Inception/VGG weights. Set and export `CSEM_DATA_ROOT` to reuse an existing prepared cache (the parent containing `FMNIST/FashionMNIST/raw`). Both preparation and jobs honor `TORCH_HOME` if exported. The job uses the existing `$SCRATCH/venvs/hlsi` environment by default. Export `VENV_DIR` if it lives elsewhere. The environment needs the CUDA torch/torchvision pair, LPIPS, NumPy, SciPy, pandas, matplotlib, Pillow and tqdm.

The submit script queues 15 independent jobs on `gh`. Each requests one node for up to 20 hours. `python3 run_label_routed.py --list` shows the cell ID mapping. To retry selected cells, run `bash submit.sh DMS22021 2 7`. The submit script skips completed and already queued jobs. A retried cell resumes from its last committed epoch in the same bundle directory.

## Read results

Each run writes `config.json`, `loss.csv`, `eval.csv`, archived checkpoints and `complete.json` under its own `results/` directory. Slurm logs live in `slurm_logs/`.

```bash
python3 summarize.py > matched_seed_fid.csv
```

The summary requires all 15 validated runs. It reports individual seed FIDs, mean, sample SD and mean paired FID difference versus 0.5× for each weight at each epoch and CFG. Positive deltas favor 0.5×. Use epoch 500 at CFG 2 as the primary comparison, with other CFG levels and earlier epochs showing whether the ranking holds across guidance and training time. CFG 2 was chosen from the prior seed-42 sweep.
