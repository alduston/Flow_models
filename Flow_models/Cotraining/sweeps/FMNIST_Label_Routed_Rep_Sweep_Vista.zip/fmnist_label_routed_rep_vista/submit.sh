#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
ACCOUNT="${1:?Usage: bash submit.sh ACCOUNT [CELL ...]}"
shift
mkdir -p slurm_logs

if (( $# == 0 )); then
    set -- {0..14}
fi
for cell in "$@"; do
    if [[ ! "$cell" =~ ^([0-9]|1[0-4])$ ]]; then
        echo "Invalid cell ID: $cell (expected 0 through 14)" >&2
        exit 2
    fi
done

manifest="$(python3 run_label_routed.py --list)"
queued="$(squeue -h -u "$(id -un)" -o '%j')"
for cell in "$@"; do
    run="$(awk -F '\t' -v cell="$cell" '$1 == cell {print $5}' <<< "$manifest")"
    job="fmrep_${run#label_routed_}"
    if [[ -f "results/$run/complete.json" ]]; then
        printf '[SKIP complete] %s\n' "$run"
    elif printf '%s\n' "$queued" | grep -Fxq "$job"; then
        printf '[SKIP queued] %s\n' "$run"
    else
        id="$(sbatch --parsable -A "$ACCOUNT" --job-name="$job" job.slurm "$cell")"
        printf '[SUBMITTED] %s %s %s\n' "$cell" "$run" "$id"
        queued+=$'\n'"$job"
    fi
done
