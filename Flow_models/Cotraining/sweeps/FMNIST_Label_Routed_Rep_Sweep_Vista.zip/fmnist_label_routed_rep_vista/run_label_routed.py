"""Run one cell of the paired Vista representation sweep."""
import argparse
import fcntl
import json
import os
from pathlib import Path

import protocol


SEEDS = (43, 44, 45)
REP_TENTHS = (3, 4, 5, 6, 7)
CELLS = tuple((seed, tenths) for seed in SEEDS for tenths in REP_TENTHS)
CFG_GRID = (0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0, 5.0)
SWEEP_EPOCHS = (100, 200, 300, 400, 500)


def config(base, cell, device="cuda"):
    seed, tenths = CELLS[cell]
    base = Path(base).resolve()
    original = protocol.read(base / "provenance/flat_three_encoder_cell2.json")["config"]
    c = protocol.common(base)
    name = f"label_routed_0{tenths}xrep_csem_s{seed}"
    c.update(
        name=name, group="vista_label_routed_rep_sweep", regime=name, stage="joint",
        seed=seed, split="historical_full60k", eval_split="test", device=device,
        cpu_threads=2, output=str(base / "results" / name),
        data_root=str(Path(os.environ.get("CSEM_DATA_ROOT") or base / "data_cache_fmnist").expanduser().resolve()),
        kid_subsets=0, eval_every=100,
        archive_epochs=original["archive_epochs"],
        save_array_samples=original["save_array_samples"],
        route_encoder_by_label=True,
        rep_multiplier=(tenths / 10) * original["rep_multiplier"],
        cfg_sweep_levels=list(CFG_GRID),
        cfg_sweep_epochs=list(SWEEP_EPOCHS),
    )
    operational = {"device", "cpu_threads", "checkpoint_every", "seed", "eval_every",
                   "diagnostic_at_start", "diagnostic_every", "witness_every",
                   "sampling_check_every"}
    drift = {key: (value, c.get(key)) for key, value in original.items()
             if key not in operational and key != "rep_multiplier"
             and value != c.get(key)}
    if drift:
        raise ValueError(f"Reference joint recipe drift: {drift}")
    if tuple(range(c["eval_every"], c["epochs"] + 1, c["eval_every"])) != SWEEP_EPOCHS:
        raise ValueError("Every evaluation must use the full CFG grid.")
    if not 0 <= c["label_dropout"] < 1:
        raise ValueError("Label routing requires a positive labeled fraction.")
    return argparse.Namespace(**c)


def check_routes(args, device):
    """One backward-only check, using a mixed label mask and the production loss."""
    import copy
    import torch
    import models
    from pinned import stacked_two_block as old

    torch.set_num_threads(args.cpu_threads)
    device = torch.device(device)
    small = copy.copy(args)
    small.joint_width, small.joint_depth = 48, 2
    old.seed_everything(args.seed)
    vae, head = models.build(small, device)
    with torch.no_grad():
        head.final_proj.weight.normal_(0, .002)
    images = torch.randn(4, 1, 32, 32, device=device)
    labels = torch.tensor([0, 2, 5, 9], device=device)
    schedule = old.ref.make_schedule(
        dict(time_schedule="log_t", t_min=args.t_min, t_max=args.t_max,
             num_train_timesteps=1000), device
    )
    t = torch.full((len(images),), .4, device=device)
    d = models.draw_noisy(vae, images, t)
    # Make both encoder-facing tensors independent leaves to inspect each path.
    d["packed"] = d["packed"].detach().requires_grad_()
    d["naive"] = [part.detach().requires_grad_() for part in d["naive"]]
    variables = [d["packed"], *d["naive"], *head.parameters()]
    # Find a deterministic mixed mask at the actual dropout rate.
    for seed in range(100):
        old.seed_everything(seed)
        dropped = torch.rand(len(labels), device=device) < args.label_dropout
        if dropped.any() and (~dropped).any():
            break
    else:
        raise AssertionError("No mixed dropout mask found")
    losses, gradients = [], []
    for routed in (False, True):
        old.seed_everything(seed)
        small.route_encoder_by_label = routed
        loss, _, _, _ = models.loss_from_draw(small, vae, head, d, labels, schedule)
        losses.append(loss.detach())
        gradients.append(torch.autograd.grad(loss, variables, allow_unused=True))
    torch.testing.assert_close(*losses, atol=0, rtol=0)
    num_paths = 1 + len(d["naive"])
    for reference, routed in zip(gradients[0][:num_paths], gradients[1][:num_paths]):
        assert reference[dropped].abs().sum().item() > 0
        assert torch.count_nonzero(routed[dropped]).item() == 0
        torch.testing.assert_close(
            routed[~dropped], reference[~dropped] / (1 - args.label_dropout),
            rtol=2e-5, atol=1e-8,
        )
    for reference, routed in zip(gradients[0][num_paths:], gradients[1][num_paths:]):
        if reference is None:
            assert routed is None
        else:
            torch.testing.assert_close(reference, routed, atol=0, rtol=0)
    print("[CHECK] Both label-dropped encoder routes are zero. Labeled routes "
          "have the expected normalization. Loss and pre-clip head gradients match.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--cell", type=int, choices=range(len(CELLS)))
    group.add_argument("--list", action="store_true")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    if args.list:
        print("cell\tseed\trep_factor\trep_multiplier\trun")
        for cell, (seed, tenths) in enumerate(CELLS):
            c = config(base, cell)
            print(f"{cell}\t{seed}\t{tenths / 10:.1f}\t{c.rep_multiplier:g}\t{c.name}")
        return 0
    c = config(base, args.cell)
    if args.check:
        check_routes(c, c.device)
        return 0
    out = Path(c.output)
    out.mkdir(parents=True, exist_ok=True)
    with (out / ".run.lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit(f"Another process is running {c.name}")
        from train_stages import run
        print("[STAGE]", json.dumps(vars(c), sort_keys=True), flush=True)
        return run(c, base, resume=True)


if __name__ == "__main__":
    raise SystemExit(main())
