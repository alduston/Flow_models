"""Summarize matched-seed, fixed-CFG results from the completed Vista sweep."""
import csv
import statistics
import sys

from campaign import csv_rows, validate_complete
from protocol import ROOT, read
from run_label_routed import CELLS, CFG_GRID, REP_TENTHS, SEEDS, SWEEP_EPOCHS, config


def main():
    results = {}
    missing = []
    for cell, (seed, tenths) in enumerate(CELLS):
        expected = vars(config(ROOT, cell))
        run_dir = ROOT / "results" / expected["name"]
        if not (run_dir / "complete.json").is_file():
            missing.append(expected["name"])
            continue
        validate_complete(run_dir, production=True)
        actual = read(run_dir / "config.json")
        for key in ("seed", "rep_multiplier", "regime", "eval_every",
                    "cfg_sweep_epochs", "cfg_sweep_levels", "route_encoder_by_label"):
            if actual[key] != expected[key]:
                raise ValueError(f"{run_dir}: configuration mismatch for {key}")
        for row in csv_rows(run_dir / "eval.csv"):
            if row["kind"] != "generation":
                raise ValueError(f"{run_dir}: expected a generation evaluation")
            results[int(row["epoch"]), float(row["cfg"]), tenths, seed] = float(row["fid_generated"])
    if missing:
        sys.exit("Awaiting completed runs: " + ", ".join(missing))

    writer = csv.writer(sys.stdout)
    writer.writerow(["epoch", "cfg", "rep_factor", *(f"fid_s{s}" for s in SEEDS),
                     "mean_fid", "seed_sd", "mean_paired_delta_vs_05x"])
    for epoch in SWEEP_EPOCHS:
        for cfg in CFG_GRID:
            reference = [results[epoch, cfg, 5, seed] for seed in SEEDS]
            for tenths in REP_TENTHS:
                fids = [results[epoch, cfg, tenths, seed] for seed in SEEDS]
                deltas = [fid - ref for fid, ref in zip(fids, reference)]
                writer.writerow([epoch, cfg, tenths / 10, *fids, statistics.mean(fids),
                                 statistics.stdev(fids), statistics.mean(deltas)])


if __name__ == "__main__":
    main()
