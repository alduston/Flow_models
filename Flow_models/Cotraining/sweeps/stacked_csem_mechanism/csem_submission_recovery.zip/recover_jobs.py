#!/usr/bin/env python3
"""Audit and submit missing stacked-CSEM jobs without changing guarded sources.

Default: read-only plan. --submit queues missing work. --watch retries recognized
submission-capacity rejections until everything is submitted, then exits; it
does not wait for training to finish. Standard library only.
"""
import argparse
import contextlib
from datetime import datetime, timezone
import fcntl
import getpass
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


def now():
    return datetime.now(timezone.utc).isoformat()


def load_paper(base):
    sys.path.insert(0, str(base))
    spec = importlib.util.spec_from_file_location('_csem_recovery_paper', base / 'paper.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if Path(module.experiments.__file__).resolve() != base / 'experiments.py':
        raise RuntimeError('Another sweep experiments.py is already imported; start a fresh Python process')
    return module


def queue_snapshot():
    result = subprocess.run(['squeue', '-h', '-u', getpass.getuser(), '-o', '%i|%j|%T|%Z'],
                            check=True, text=True, capture_output=True)
    jobs = []
    for line in result.stdout.splitlines():
        parts = line.strip().split('|')
        if not line.strip():
            continue
        if len(parts) != 4:
            raise RuntimeError('Unrecognized squeue output; refusing to risk duplicate submissions: ' + line)
        jobs.append(dict(zip(('id', 'name', 'state', 'directory'), (p.strip() for p in parts))))
    return jobs


def saved_data_root(base, override):
    if override is not None:
        return Path(override).expanduser().resolve()
    roots = set()
    for path in (base / 'results').glob('*/resume_recipe.json'):
        config = json.loads(path.read_text())['config']
        if config.get('data_root'):
            root = Path(config['data_root']).expanduser()
            roots.add(str((root if root.is_absolute() else base / root).resolve()))
    if len(roots) > 1:
        raise RuntimeError('Existing runs use different data roots; choose --data-root explicitly')
    if roots:
        return Path(next(iter(roots)))
    return Path(os.environ.get('CSEM_DATA_ROOT', str(base / 'data_cache_fmnist'))).expanduser().resolve()


def preflight(base, paper, data_root):
    """Check original guards, completed outputs and partial resumes before sbatch."""
    hashes = paper.experiments.digest(base)
    for row in paper.experiments.rows():
        st = paper.status(base, row)
        if st.get('signature') not in (None, paper.signature(row, base)):
            raise RuntimeError(f'Cell {row["cell_id"]}: source/recipe guard differs. Restore the original '
                               'training sources; do not use --restart on completed results.')
        out = base / 'results' / row['name']
        guard = out / 'resume_recipe.json'
        if guard.exists():
            saved = json.loads(guard.read_text())
            if saved['source_hashes'] != hashes:
                raise RuntimeError(f'Cell {row["cell_id"]}: guarded sources changed; restore them before recovery')
            # Completed runs may have used another explicit data path. Never
            # rewrite their recipes; incomplete runs must retain their exact one.
            if not (out / 'complete.json').exists():
                expected = dict(config=vars(paper.experiments.configuration(row, base, data_root)), source_hashes=hashes)
                if saved != expected:
                    raise RuntimeError(f'Cell {row["cell_id"]}: resume configuration differs, including data path')
        elif out.exists() and any(out.iterdir()):
            raise RuntimeError(f'Cell {row["cell_id"]}: nonempty result directory lacks a resume guard')
        if (out / 'complete.json').exists():
            if not guard.exists():
                raise RuntimeError(f'Cell {row["cell_id"]}: completed result lacks a resume guard')
            paper.validate_complete(row, out)
    raw = data_root / 'FMNIST' / 'FashionMNIST' / 'raw'
    names = ('train-images-idx3-ubyte', 'train-labels-idx1-ubyte',
             't10k-images-idx3-ubyte', 't10k-labels-idx1-ubyte')
    if not all((raw / name).is_file() for name in names):
        raise RuntimeError('Prepared Fashion-MNIST raw files not found at ' + str(raw) +
                           '. Supply the original --data-root; this command never downloads datasets.')


def classify(base, paper, rows, jobs):
    active = {job['id'] for job in jobs}
    records = []
    for row in rows:
        st = paper.status(base, row)
        out = base / 'results' / row['name']
        if (out / 'complete.json').exists():
            state = 'complete'
        else:
            matching = [job for job in jobs if job['name'] == f'stack_c{row["cell_id"]}'
                        and Path(job['directory']).resolve() == base]
            if len(matching) > 1 or any(job['id'] != str(st.get('slurm_job_id')) for job in matching):
                raise RuntimeError(f'Cell {row["cell_id"]}: untracked/duplicate job in queue. '
                                   'Inspect squeue and reconcile status before retrying; no duplicate was submitted.')
            state = 'active' if str(st.get('slurm_job_id')) in active else 'ready'
        if state == 'ready' and row['source'] is not None:
            parent = paper.experiments.rows()[row['source']]
            parent_complete = (base / 'results' / parent['name'] / 'complete.json').exists()
            parent_active = str(paper.status(base, parent).get('slurm_job_id')) in active
            if not parent_complete and not parent_active:
                state = 'blocked'
        records.append(dict(cell_id=row['cell_id'], name=row['name'], state=state,
                            job_id=st.get('slurm_job_id'), source=row['source']))
    return records


def show(records):
    for state in ('complete', 'active', 'ready', 'blocked'):
        ids = [r['cell_id'] for r in records if r['state'] == state]
        print(f'[{state.upper()}] {len(ids)} cells: ' + ','.join(map(str, ids)), flush=True)


def journal(base, event):
    path = base / 'status' / 'recovery_attempts.jsonl'
    with path.open('a') as target:
        fcntl.flock(target.fileno(), fcntl.LOCK_EX)
        target.write(json.dumps(dict(timestamp=now(), **event), default=str) + '\n')
        target.flush()
        os.fsync(target.fileno())


def capacity_rejection(exc):
    message = (exc.stderr or '') + '\n' + (exc.stdout or '')
    return Path(str(exc.cmd[0])).name == 'sbatch' and bool(re.search(
        r'(?:QOS|Assoc)\w*Max\w*(?:Submit|Job)|job.*(?:submit|submission).*limit|'
        r'maximum.*jobs|too many.*jobs|Job violates accounting/QOS policy', message, re.I))


def execute(args, base, paper, rows, data_root):
    original_hashes = paper.experiments.digest(base)
    while True:
        if paper.experiments.digest(base) != original_hashes:
            raise RuntimeError('Guarded training sources changed while watching; stopped before further submissions')
        jobs = queue_snapshot()
        records = classify(base, paper, rows, jobs)
        show(records)
        todo = [r for r in records if r['state'] in ('ready', 'blocked')]
        if not args.submit or not todo:
            if not todo:
                print('[DONE] Every selected cell is complete or already submitted.', flush=True)
            return 0
        attempted = False
        capacity = False
        fatal = False
        for item in records:
            if item['state'] in ('complete', 'active'):
                continue
            # Refresh after earlier submissions: a newly queued parent can now
            # serve as an afterok dependency, even within the same pass.
            current = classify(base, paper, [paper.experiments.rows()[item['cell_id']]], queue_snapshot())[0]
            if current['state'] != 'ready':
                continue
            attempted = True
            cell_id = item['cell_id']
            journal(base, dict(event='attempt', cell_id=cell_id))
            captured = io.StringIO()
            try:
                with contextlib.redirect_stdout(captured):
                    paper.submit(base, str(cell_id), partition=args.partition,
                                 time_limit=args.time, account=args.account,
                                 data_root=data_root, dependencies=True)
            except subprocess.CalledProcessError as exc:
                print(captured.getvalue(), end='', flush=True)
                print(f'[REJECTED] cell {cell_id}: return code {exc.returncode}', file=sys.stderr, flush=True)
                print(exc.stderr or exc.stdout or str(exc), file=sys.stderr, flush=True)
                capacity = capacity_rejection(exc)
                journal(base, dict(event='rejected', cell_id=cell_id, command=exc.cmd,
                                   returncode=exc.returncode, stdout=exc.stdout, stderr=exc.stderr,
                                   possibly_capacity_related=capacity))
                fatal = not capacity
                break
            except Exception as exc:
                print(captured.getvalue(), end='', flush=True)
                journal(base, dict(event='error', cell_id=cell_id, error=repr(exc)))
                print(f'[STOP] cell {cell_id}: {exc}. An accepted job may lack a recorded ID; '
                      'check the queue before any retry.', file=sys.stderr, flush=True)
                fatal = True
                break
            else:
                print(captured.getvalue(), end='', flush=True)
                st = paper.status(base, paper.experiments.rows()[cell_id])
                journal(base, dict(event='checked_after_submit', cell_id=cell_id,
                                   job_id=st.get('slurm_job_id'), command_output=captured.getvalue()))
                print(f'[SUBMISSION CHECK] cell {cell_id}: job {st.get("slurm_job_id")}', flush=True)
        records = classify(base, paper, rows, queue_snapshot())
        show(records)
        pending = [r for r in records if r['state'] in ('ready', 'blocked')]
        journal(base, dict(event='summary', unsubmitted=[r['cell_id'] for r in pending], fatal=fatal))
        if fatal:
            return 1
        if not pending:
            print('[DONE] Every selected cell is complete or already submitted.', flush=True)
            return 0
        if not attempted:
            print('[BLOCKED] Source jobs are not complete or queued. Include/submit those parents first.', flush=True)
            return 2
        if args.watch and capacity:
            print(f'[WAIT] Submission capacity/policy rejection; retrying unsubmitted cells in '
                  f'{args.poll_seconds:g}s. Ctrl-C leaves queued jobs running.', flush=True)
            time.sleep(args.poll_seconds)
            continue
        print('[UNSUBMITTED] Rerun this same recovery command after resolving the reason above.', flush=True)
        return 75 if capacity else 2


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-dir', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--cells', default='all')
    parser.add_argument('--submit', action='store_true', help='actually submit; default is a read-only plan')
    parser.add_argument('--watch', action='store_true', help='retry recognized quota/capacity rejections until all queued')
    parser.add_argument('--poll-seconds', type=float, default=60.)
    parser.add_argument('--data-root', type=Path)
    parser.add_argument('--partition', default='gh')
    parser.add_argument('--time', default='48:00:00')
    parser.add_argument('--account')
    args = parser.parse_args(argv)
    if args.watch and not args.submit:
        parser.error('--watch requires --submit')
    if args.poll_seconds < 1:
        parser.error('--poll-seconds must be at least 1')
    base = args.base_dir.expanduser().resolve()
    try:
        paper = load_paper(base)
        data_root = saved_data_root(base, args.data_root)
        print('[DATA ROOT]', data_root, flush=True)
        preflight(base, paper, data_root)
        rows = paper.experiments.selected(args.cells)
        rows = sorted(rows, key=lambda r: (0 if r['group'] == 'core' else 1 if r['stage'] == 'frozen' else 2, r['cell_id']))
        if not args.submit:
            return execute(args, base, paper, rows, data_root)
        (base / 'status').mkdir(exist_ok=True)
        with (base / 'status' / 'recovery.lock').open('a') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return execute(args, base, paper, rows, data_root)
    except KeyboardInterrupt:
        print('\n[STOPPED] Already submitted jobs remain queued/running.', file=sys.stderr)
        return 130
    except Exception as exc:
        print('[ERROR]', exc, file=sys.stderr, flush=True)
        if isinstance(exc, subprocess.CalledProcessError):
            print(exc.stderr or exc.stdout or '', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
