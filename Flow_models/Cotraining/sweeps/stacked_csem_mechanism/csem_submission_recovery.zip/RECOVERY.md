# Submit the 29 missing stacked-CSEM jobs

The uploaded evidence shows 25 successful jobs, not 29 failed training jobs.
All 22 core runs and frozen cells 30, 31, 32 have matching successful status
records and Slurm `COMPLETED / 0:0` records. Cells 22–29 and 33–53 have no status
file, result inventory entry, or accounting record. The captured queue is empty.
The 12 earlier cancelled pilot entries were cancelled before starting, then
superseded by successful submissions.

The terminal output from the incomplete submission was not included, so its
exact reason is unknown. A site submission limit is plausible given the 25
accepted jobs, but has not been established. The original submission function
aborts on the first `sbatch` error and hides the captured scheduler stderr from
its exception message. It also lacks a persistent ledger of attempted/rejected
submissions. The new helper makes those errors and remaining cells explicit.

## Install in the existing sweep

Run from the original `stacked_csem_mechanism` directory. This ZIP contains only
new files and does not contain replacements for `paper.py`, `experiments.py`,
`job.slurm`, or any training/model/diagnostic file.

```bash
unzip /path/to/csem_submission_recovery.zip -d .

# Read-only plan: should show 25 complete and 29 ready, if the queue is still empty.
python recover_jobs.py

# Submit remaining work; retry recognized capacity rejections until all queued.
python -u recover_jobs.py --submit --watch
```

The last command exits as soon as all selected jobs are complete or queued. It
does not wait for training. If a submission limit leaves some work unsubmitted,
it checks again every 60 seconds. It submits the 21 missing frozen comparisons
first, followed by the eight robustness runs, so the shorter and scientifically
most informative jobs can run first. The original parent dependencies remain
in force when a source is still active.

For a connection that may disconnect while waiting for submission capacity:

```bash
nohup python -u recover_jobs.py --submit --watch > recovery.log 2>&1 < /dev/null &
```

Without automatic waiting, use `python recover_jobs.py --submit`. If capacity
is exhausted it exits 75 with a list of unsubmitted cells. Rerun the same command
later; active/completed jobs are skipped. Ctrl-C stops only this submission
helper, leaving already submitted jobs running.

## What the helper checks and records

- Uses standard-library imports only; no Torch, model construction, dataset
  loading, weight download or checkpoint deserialization on the login node.
- Infers the data root from existing resume recipes. The uploaded runs used
  `.../stacked_csem_mechanism/data_cache_fmnist`. `--data-root PATH` is available
  if needed; partial resumes must retain their original configuration.
- Validates existing source signatures, resume guards and completed outputs
  using the original bundle functions. Never rewrites those sources/guards or
  restarts completed training. Do not replace the guarded scripts to install it.
- Uses the existing submission function and `status/submit.lock`, plus a
  separate recovery lock. Detects active jobs and refuses to duplicate an
  untracked job whose acceptance was ambiguous.
- Adds `status/recovery_attempts.jsonl`, with timestamps, per-cell attempts,
  accepted job IDs, commands, scheduler rejection text, and remaining cells.
  Existing per-cell status files continue to be managed by the original code.
- Stops on permanent errors such as an invalid account. `--watch` retries only
  recognized submission-limit/policy messages; read the printed scheduler text
  if such a message persists. A policy rejection can also mean a resource/time
  setting needs correction, so capacity messages are not treated as proof of a
  particular cluster limit.

The original `--partition`, `--time`, and `--account` settings can be supplied
to the helper if needed. Default selection is all 54 cells with completed and
active cells skipped. Restrict it with `--cells frozen`, `--cells robustness`,
or a range such as `--cells 33-53`.

After the recovered jobs finish:

```bash
python paper.py report --strict
```

## Validation

Nine offline integration tests use fake `squeue`/`sbatch` executables and copies
of the exact original guarded sources. They reproduce the 25-complete/29-missing
layout, check successful recovery and idempotence, simulate a 25-job submission
cap and automatic retry, preserve parent dependencies, surface permanent errors,
reject changed source guards, and stop ambiguous/untracked submissions. Existing
completed output/source/status bytes are checked for preservation. Heavy Python
imports are explicitly forbidden during the helper subprocess tests.

Run `python test_recover_jobs.py` from the installed sweep for these offline
tests. They use temporary directories, never contact Slurm, and never train.

The supplied archive's 25 actual status signatures were also verified against
the original source hashes and corresponding accounting records. The patch was
implemented and tested locally; no jobs were submitted to the remote cluster
from this environment. Its sources/receipts need to be read on the cluster to
perform the real submissions.
