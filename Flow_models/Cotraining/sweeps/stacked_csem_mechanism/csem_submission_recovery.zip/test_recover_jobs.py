#!/usr/bin/env python3
"""Offline Slurm integration tests. Never connects to a scheduler or trains."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

SOURCE_BASE = Path(__file__).resolve().parent
HELPER = Path(__file__).resolve().with_name('recover_jobs.py')
COMPLETE = list(range(22)) + [30, 31, 32]
MISSING = list(range(22, 30)) + list(range(33, 54))
GUARDED = ['experiments.py', 'models.py', 'vae_three.py', 'trainer.py', 'measurements.py',
           'witness.py', 'sampling.py', 'reference.py', 'paper.py', 'paper_io.py',
           'fmnist_reference.py', 'pinned/stacked_two_block.py']


FAKE_SLURM = r'''
import json,os,sys
from pathlib import Path
root=Path(os.environ['FAKE_SLURM_ROOT']);state=json.loads((root/'state.json').read_text())
args=sys.argv[1:]
def save(): (root/'state.json').write_text(json.dumps(state))
if Path(sys.argv[0]).name=='squeue':
    if state.get('release_after_rejection') and state.get('rejected'):
        state['limit']=100;save()
    for job in state['jobs']:
        print('|'.join(str(job[k]) for k in ('id','name','state','directory')) if '%Z' in args[-1] else job['id'])
    raise SystemExit(0)
def val(prefix):return next(a.split('=',1)[1] for a in args if a.startswith(prefix+'='))
cell=int(val('--job-name').removeprefix('stack_c'))
state['attempts'].append({'cell_id':cell,'args':args})
if state.get('permanent_error'):
    save();print('sbatch: error: Invalid account or account/partition combination specified',file=sys.stderr);raise SystemExit(1)
if len(state['jobs'])>=state.get('limit',100):
    state['rejected']=True;save()
    print('sbatch: error: QOSMaxSubmitJobPerUserLimit',file=sys.stderr)
    print('sbatch: error: Batch job submission failed: Job violates accounting/QOS policy (job submit limit)',file=sys.stderr)
    raise SystemExit(1)
jid=str(2000000+len(state['accepted']))
state['accepted'].append(cell)
state['jobs'].append({'id':jid,'name':val('--job-name'),'state':'PENDING','directory':val('--chdir')})
save()
print('accepted but identifier missing' if state.get('ambiguous_success') else jid)
'''


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.base = self.root / 'sweep'
        self.base.mkdir()
        for name in GUARDED + ['job.slurm']:
            target = self.base / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE_BASE / name, target)
        spec = importlib.util.spec_from_file_location('fixture_experiments', self.base / 'experiments.py')
        self.experiments = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.experiments)
        self.hashes = self.experiments.digest(self.base)
        self.data = self.base / 'data_cache_fmnist'
        raw = self.data / 'FMNIST' / 'FashionMNIST' / 'raw'
        raw.mkdir(parents=True)
        for name in ('train-images-idx3-ubyte','train-labels-idx1-ubyte','t10k-images-idx3-ubyte','t10k-labels-idx1-ubyte'):
            (raw / name).touch()
        (self.base / 'status').mkdir()
        for cell in COMPLETE:
            self.complete(cell)
        self.state = self.root / 'state.json'
        self.state.write_text(json.dumps(dict(jobs=[], accepted=[], attempts=[])))
        self.bin = self.root / 'bin'
        self.bin.mkdir()
        for command in ('squeue', 'sbatch'):
            path = self.bin / command
            path.write_text('#!' + sys.executable + '\n' + FAKE_SLURM)
            path.chmod(0o755)
        hook = self.root / 'hooks'
        hook.mkdir()
        (hook / 'sitecustomize.py').write_text(
            "import builtins\noriginal=builtins.__import__\n"
            "def checked(name,*a,**kw):\n"
            " if name.split('.')[0] in ('torch','torchvision','lpips','trainer','numpy','pandas'):raise RuntimeError('Heavy import: '+name)\n"
            " return original(name,*a,**kw)\n"
            "builtins.__import__=checked\n")
        self.env = dict(os.environ, PATH=str(self.bin) + os.pathsep + os.environ['PATH'],
                        FAKE_SLURM_ROOT=str(self.root), PYTHONPATH=str(hook),
                        CSEM_DATA_ROOT='/wrong/environment/path/must/not/override/saved/recipe')
        self.before = {str(p.relative_to(self.base)): p.read_bytes()
                       for p in self.base.rglob('*') if p.is_file()}

    def tearDown(self):
        self.temp.cleanup()

    def complete(self, cell):
        row = self.experiments.rows()[cell]
        config = row['config']
        out = self.base / 'results' / row['name']
        out.mkdir(parents=True, exist_ok=True)
        guard = dict(config=vars(self.experiments.configuration(row, self.base, self.data)), source_hashes=self.hashes)
        (out / 'resume_recipe.json').write_text(json.dumps(guard))
        (out / 'complete.json').write_text(json.dumps({'epoch': config['epochs']}))
        (out / 'snapshots').mkdir(exist_ok=True)
        (out / 'snapshots' / f'epoch_{config["epochs"]:04d}.pt').touch()
        (out / 'loss.csv').write_text('epoch\n' + ''.join(f'{i}\n' for i in range(1, config['epochs'] + 1)))
        eval_epochs = set(range(config['eval_every'], config['epochs'] + 1, config['eval_every'])) | {config['epochs']}
        if row['stage'] == 'frozen':
            eval_epochs.add(0)
        (out / 'eval.csv').write_text('epoch,cfg,steps,init,num_eval\n' + ''.join(
            f'{e},{g},{config["rk4_steps"]},gaussian,{config["eval_samples"]}\n'
            for e in sorted(eval_epochs) for g in (1, 3)))
        for folder, interval in [('diagnostics',config['diagnostic_every']),('witness',config['witness_every'])]:
            epochs = set(range(interval,config['epochs']+1,interval)) | {config['epochs']}
            if folder == 'diagnostics' and config['diagnostic_at_start']:
                epochs.add(0)
            (out / folder).mkdir(exist_ok=True)
            for epoch in epochs:
                (out / folder / f'epoch_{epoch:04d}.json').write_text('{}')
        signature = hashlib.sha256(json.dumps(dict(row=row,sources=self.hashes),sort_keys=True).encode()).hexdigest()
        (self.base / 'status' / f'cell_{cell:03d}.json').write_text(json.dumps(
            dict(cell_id=cell,name=row['name'],signature=signature,slurm_job_id=str(1077616+cell),returncode=0)))

    def configure(self, **changes):
        state = json.loads(self.state.read_text())
        state.update(changes)
        self.state.write_text(json.dumps(state))

    def run_helper(self, *args):
        result = subprocess.run([sys.executable, str(HELPER), '--base-dir', str(self.base), *args],
                                text=True, capture_output=True, env=self.env)
        return result

    def preserved(self):
        for name, content in self.before.items():
            self.assertEqual((self.base / name).read_bytes(), content, name)

    def test_uploaded_25_complete_29_missing_plan_is_read_only(self):
        result = self.run_helper()
        self.assertEqual(result.returncode, 0, result.stdout+result.stderr)
        self.assertIn('[COMPLETE] 25 cells:', result.stdout)
        self.assertIn('[READY] 29 cells:', result.stdout)
        self.assertEqual(json.loads(self.state.read_text())['attempts'], [])
        self.assertFalse((self.base/'status/recovery_attempts.jsonl').exists())
        self.preserved()

    def test_submits_only_29_missing_frozen_first_and_second_call_is_idempotent(self):
        result = self.run_helper('--submit')
        self.assertEqual(result.returncode, 0, result.stdout+result.stderr)
        state = json.loads(self.state.read_text())
        self.assertEqual(state['accepted'], list(range(33,54))+list(range(22,30)))
        for item in state['attempts']:
            self.assertTrue(any('CSEM_DATA_ROOT='+str(self.data) in arg for arg in item['args']))
        result = self.run_helper('--submit')
        self.assertEqual(result.returncode, 0, result.stdout+result.stderr)
        self.assertEqual(len(json.loads(self.state.read_text())['attempts']),29)
        self.preserved()

    def test_capacity_rejection_is_logged_and_retry_does_not_duplicate_accepted_jobs(self):
        self.configure(limit=25)
        result = self.run_helper('--submit')
        self.assertEqual(result.returncode,75,result.stdout+result.stderr)
        self.assertIn('QOSMaxSubmitJobPerUserLimit',result.stderr)
        state = json.loads(self.state.read_text())
        self.assertEqual(len(state['accepted']),25)
        events=[json.loads(line) for line in (self.base/'status/recovery_attempts.jsonl').read_text().splitlines()]
        self.assertEqual(events[-1]['unsubmitted'],[26,27,28,29])
        self.assertIn('QOSMaxSubmitJobPerUserLimit',next(e['stderr'] for e in events if e['event']=='rejected'))
        self.configure(limit=100)
        result=self.run_helper('--submit')
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertEqual(len(set(json.loads(self.state.read_text())['accepted'])),29)
        self.preserved()

    def test_watch_recovers_after_capacity_opens_and_exits_when_all_queued(self):
        self.configure(limit=25,release_after_rejection=True)
        result=self.run_helper('--submit','--watch','--poll-seconds','1')
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertIn('[WAIT]',result.stdout)
        self.assertEqual(len(json.loads(self.state.read_text())['accepted']),29)
        self.preserved()

    def test_permanent_rejection_is_visible_and_watch_does_not_spin(self):
        self.configure(permanent_error=True)
        result=self.run_helper('--submit','--watch','--poll-seconds','1')
        self.assertEqual(result.returncode,1,result.stdout+result.stderr)
        self.assertIn('Invalid account',result.stderr)
        self.assertEqual(len(json.loads(self.state.read_text())['attempts']),1)
        self.preserved()

    def test_changed_guarded_code_stops_before_sbatch(self):
        with (self.base/'paper.py').open('a') as target:
            target.write('\n# source change\n')
        result=self.run_helper('--submit')
        self.assertEqual(result.returncode,1,result.stdout+result.stderr)
        self.assertIn('source/recipe guard differs',result.stderr)
        self.assertFalse(json.loads(self.state.read_text())['attempts'])

    def test_untracked_or_ambiguous_accepted_job_never_gets_duplicated(self):
        self.configure(ambiguous_success=True)
        result=self.run_helper('--submit','--watch','--poll-seconds','1')
        self.assertEqual(result.returncode,1,result.stdout+result.stderr)
        self.assertEqual(len(json.loads(self.state.read_text())['accepted']),1)
        result=self.run_helper('--submit')
        self.assertEqual(result.returncode,1,result.stdout+result.stderr)
        self.assertIn('untracked/duplicate',result.stderr)
        self.assertEqual(len(json.loads(self.state.read_text())['attempts']),1)
        self.preserved()

    def test_incomplete_parent_is_not_silently_omitted(self):
        row=self.experiments.rows()[5]
        (self.base/'results'/row['name']/'complete.json').unlink()
        result=self.run_helper('--submit','--cells','33')
        self.assertEqual(result.returncode,2,result.stdout+result.stderr)
        self.assertIn('[BLOCKED]',result.stdout)
        self.assertFalse(json.loads(self.state.read_text())['attempts'])

    def test_active_parent_retains_afterok_dependency(self):
        row=self.experiments.rows()[5]
        (self.base/'results'/row['name']/'complete.json').unlink()
        parent_id=json.loads((self.base/'status/cell_005.json').read_text())['slurm_job_id']
        self.configure(jobs=[dict(id=parent_id,name='stack_c5',state='RUNNING',directory=str(self.base))])
        result=self.run_helper('--submit','--cells','33')
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        attempts=json.loads(self.state.read_text())['attempts']
        self.assertEqual(len(attempts),1)
        self.assertIn('--dependency=afterok:'+parent_id,attempts[0]['args'])


if __name__=='__main__':
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--source-base',type=Path,default=SOURCE_BASE)
    args,remaining=parser.parse_known_args()
    SOURCE_BASE=args.source_base.resolve()
    unittest.main(argv=[sys.argv[0],*remaining],verbosity=2)
