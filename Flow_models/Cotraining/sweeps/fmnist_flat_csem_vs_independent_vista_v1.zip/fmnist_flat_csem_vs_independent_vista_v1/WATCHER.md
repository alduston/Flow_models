# Bounded Vista campaign watcher

There are48 tasks across the complete experiment, but the watcher keeps at most
**four queued or running jobs from this bundle** by default. The existing pilot
counts toward that cap. It submits only stages whose parents have successful,
validated completion records, so waiting dependency jobs do not occupy slots.
This changes scheduling, not the4.323-FID training recipe or total experiment.

## Install into the current directory without disturbing the pilot

Upload this revised ZIP to the same sweeps directory, then extract only tools:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/Cotraining/sweeps
unzip -o fmnist_flat_csem_vs_independent_vista_v1.zip \
  'fmnist_flat_csem_vs_independent_vista_v1/tools/*'
cd fmnist_flat_csem_vs_independent_vista_v1
```

Root training/scheduler source files remain byte-identical to the previous ZIP.
The already queued pilot1109335 and its checkpoints remain valid. It was already
adopted successfully; no further pilot submission or adoption is needed.

## Start now, including while the pilot is queued

Use the active hlsi environment and the same exported cache/account settings:

```bash
mkdir -p status
nohup python -u tools/submit_vista.py \
  --phase all --watch --max-inflight 4 --poll 60 \
  --account DMS22021 \
  > status/watcher.log 2>&1 < /dev/null &
```

The watcher waits for `pilot/timing.json`, prints the pilot-based total cost,
then advances automatically through screening, beta selection, prior tuning,
recipe freezing, the20 final training tasks and strict figure compilation.
The existing pilot must finish successfully; an interrupted/failed pilot requires
inspection and explicit pilot resume before the watcher can proceed.

The4-job cap counts PENDING/RUNNING/COMPLETING jobs, not just GPU executions.
Change `--max-inflight 4` to2 for a smaller campaign queue. You may additionally
set `--max-user-jobs N` to leave room for your other Slurm work: this counts ALL
jobs returned by `squeue -u "$USER"`, including GAD jobs. No current cluster-wide
or per-account job limit is assumed. Recognized submit-limit rejections defer
submission until a later polling pass.

Watch the progress:

```bash
tail -f status/watcher.log
```

Or inspect a single snapshot:

```bash
cat status/watcher.json
squeue -u "$USER"
```

`status/watcher.json` records completed/expected tasks, in-flight count, and the
current waiting state. `status/watcher_error.json` is written if the watcher
stops on a substantive error; inspect the corresponding Slurm logs.

The background process must stay running to submit subsequent waves. `nohup`
allows the SSH connection to close; after a login-node restart, rerun the same
command. A per-bundle lock prevents duplicate watchers, and the submission ledger
prevents resubmission of active/completed stages. It can also recover a job that
was accepted immediately before a watcher interruption, after verifying its
working directory and job script.

## Retry behavior

- Timeout, preemption, node failure and a clean partial checkpoint exit75 can
  resume automatically, with at most two additional attempts per stage.
- Numerical/configuration failures and cancelled jobs stop the watcher; they are
  not repeatedly resubmitted. Previously generated valid outputs are retained.
- Temporary Slurm query failures wait for the next polling pass.
- The watcher never cancels jobs, including unrelated work. If an old command
  already queued more than the configured cap, it waits for that queue to drain
  rather than removing those jobs.

Restarting the same watcher command resumes orchestration from the ledger and
validated completion records. There are no root-source edits or recipe migration.

## One pass and dry runs

```bash
python tools/submit_vista.py --phase all --max-inflight 4 --dry-run
python tools/submit_vista.py --phase all --max-inflight 4
```

Without `--watch`, this performs only one bounded refill and exits. A dry run
prints up to the available ready slots; it does not queue48 tasks or change the
ledger. While the pilot is incomplete, it reports `waiting_for_pilot`.

The older root `paper.py submit` remains unchanged for source identity and is
unbounded. Use `tools/submit_vista.py` for submission. Pilot submission through
that wrapper remains supported and retains the earlier sbatch-output fix.

Offline checks: `python -B tools/test_watch_vista.py` and
`python -B tools/test_submit_vista.py`. They exercise caps, all48 eventual tasks,
readiness, restarts, pilot recovery, account-pressure deferral and retry guards
without calling Slurm or training models.
