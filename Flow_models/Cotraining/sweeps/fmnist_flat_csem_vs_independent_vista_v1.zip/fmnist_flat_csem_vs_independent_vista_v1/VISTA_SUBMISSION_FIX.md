# Vista submission acknowledgement fix

The original launcher accepted only a bare job ID as the entire stdout of
`sbatch --parsable`. A site wrapper can emit additional text even though the
job is accepted. The new `tools/submit_vista.py` accepts an unambiguous bare,
cluster-qualified, or standard Slurm acknowledgement among extra lines and
saves raw stdout/stderr before parsing. It changes no training source file,
recipe, checkpoint or source signature.

## Recover the current queued pilot

Upload the revised ZIP to the same sweeps directory, then extract only the
submission wrapper into the existing bundle:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/Cotraining/sweeps
unzip -o fmnist_flat_csem_vs_independent_vista_v1.zip \
  'fmnist_flat_csem_vs_independent_vista_v1/tools/submit_vista.py'
cd fmnist_flat_csem_vs_independent_vista_v1
python tools/submit_vista.py --adopt-pilot 1109335 --phase pilot
```

The adoption step checks `scontrol` for the full job name, working directory
and job script, records the existing ID, and the usual launcher then skips the
active or completed pilot. It never cancels or restarts that job. If the pilot
finishes before adoption, `scontrol` may no longer retain it; a completed
`pilot/timing.json` is sufficient and adoption can then be omitted.

If the pilot has failed, inspect its logs before starting it again. The wrapper
can resume it with `python tools/submit_vista.py --phase pilot` after the old
job has ended; ordinary checkpoint guards still apply.

After the pilot succeeds:

```bash
python tools/submit_vista.py --phase all --dry-run
python tools/submit_vista.py --phase all --watch --max-inflight 4
```

Use this wrapper for future submissions. See `WATCHER.md` for the bounded
watcher, which keeps at most four campaign jobs queued/running by default.
Monitoring and compilation remain `python paper.py status` and
`python paper.py report --strict`. The 4.323-FID architecture, losses and
training settings are unchanged.
