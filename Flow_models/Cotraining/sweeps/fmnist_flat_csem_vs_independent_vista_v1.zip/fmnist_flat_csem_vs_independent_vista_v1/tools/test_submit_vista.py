"""Offline tests: python -B tools/test_submit_vista.py. Never submits jobs."""
import io
import json
from pathlib import Path
import subprocess
import tempfile
from contextlib import redirect_stdout
from unittest.mock import patch
import submit_vista as v
from protocol import atomic,rows,sources

def fixture(base):
    (base/'pinned').mkdir();(base/'provenance').mkdir();(base/'job.slurm').write_text('fixture')
    (base/'provenance/flat_three_encoder_cell2.json').write_bytes((v.ROOT/'provenance/flat_three_encoder_cell2.json').read_bytes())

def main():
    assert sources(v.ROOT)==json.loads((v.ROOT/'source_hashes.json').read_text())
    for s in ['1109335\n','1109335;vista\n','TACC verification\n1109335\n','TACC banner\nSubmitted batch job 1109335\n','--> Submitted batch job 1109335\n','\033[32m1109335\033[0m\n']:
        assert v.parse_job_id(s)=='1109335'
    for s in ['TACC allocation 2026: 1 node','1109335\n1109336\n']:
        try:v.parse_job_id(s)
        except ValueError:pass
        else:raise AssertionError('Ambiguous output accepted')
    with tempfile.TemporaryDirectory() as temp:
        base=Path(temp);fixture(base)
        def detail(cmd,**kw):return subprocess.CompletedProcess(cmd,0,stdout=f'JobId=1109335 JobName=fm3_pilot WorkDir={base} Command={base}/job.slurm',stderr='')
        with redirect_stdout(io.StringIO()):
            v.adopt_pilot(base,'1109335',detail);v.adopt_pilot(base,'1109335',detail)
        assert json.loads((base/'status/submissions.json').read_text())['pilot']['job_id']=='1109335'
        def wrong(cmd,**kw):return subprocess.CompletedProcess(cmd,0,stdout='JobId=1109335 JobName=fm3_pilot WorkDir=/unrelated Command=/unrelated/job.slurm',stderr='')
        try:v.adopt_pilot(base,'1109335',wrong)
        except ValueError:pass
        else:raise AssertionError('Unrelated directory accepted')
        def banner(cmd,**kw):return subprocess.CompletedProcess(cmd,0,stdout='Site banner\n1109336\n',stderr='')
        with redirect_stdout(io.StringIO()):assert v.normalizer(base,banner)(['sbatch']).stdout=='1109336\n'
        def unknown(cmd,**kw):
            if cmd[0]=='sbatch':out='Unrecognized site-specific acknowledgement'
            elif cmd[0]=='squeue':out='1109335\n'
            else:return detail(cmd,**kw)
            return subprocess.CompletedProcess(cmd,0,stdout=out,stderr='')
        with redirect_stdout(io.StringIO()):assert v.normalizer(base,unknown)(['sbatch','--job-name=fm3_pilot']).stdout=='1109335\n'
    with tempfile.TemporaryDirectory() as temp:
        base=Path(temp);fixture(base)
        atomic(base/'pilot/timing.json',dict(gpu='fixture',stages={s:dict(seconds_per_batch=.1,evaluation_seconds=1.) for s in ('joint','vae_pretrain','prior_dsm','prior_csem')}))
        calls=[]
        def fake(cmd,**kw):
            if cmd[0]=='squeue':out=''
            else:calls.append(cmd);out='TACC checks complete\nSubmitted batch job '+str(2000+len(calls))+'\n'
            return subprocess.CompletedProcess(cmd,0,stdout=out,stderr='')
        with patch.object(v.campaign.subprocess,'run',side_effect=v.normalizer(base,fake)),patch.object(v.campaign,'task_complete',return_value=False),redirect_stdout(io.StringIO()):
            v.campaign.submit(base,phase='all',time_limit='auto')
        assert len(calls)==48
        rr=rows(base);ids={r['name']:str(2001+i) for i,r in enumerate(rr)}
        for r,c in zip(rr,calls):
            actual=[x.split('=',1)[1] for x in c if x.startswith('--dependency=')]
            assert actual==(['afterok:'+':'.join(ids[d] for d in r['deps'])] if r['deps'] else [])
    result=dict(parser_cases=8,existing_pilot_adoption=True,unrelated_job_rejection=True,raw_response_logging=True,
        exact_workdir_fallback=True,banner_submission_DAG_jobs=48,dependency_ids='all correct',training_source_hashes='unchanged')
    atomic(v.ROOT/'validation/vista_submit_fix.json',result)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
