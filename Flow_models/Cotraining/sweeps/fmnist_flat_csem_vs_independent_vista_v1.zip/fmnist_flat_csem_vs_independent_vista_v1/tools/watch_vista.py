#!/usr/bin/env python3
"""Keep a small queue of ready FMNIST stages; all training sources stay frozen."""
from __future__ import annotations
import argparse
import fcntl
import getpass
import json
import math
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import time
import submit_vista as vista
import campaign
from protocol import ROOT,atomic,read,rows,sources

PILOT=dict(name='pilot',kind='pilot',deps=[])
RESUMABLE={'TIMEOUT','PREEMPTED','NODE_FAIL','BOOT_FAIL'}

def field(text,name):
    m=re.search(r'(?:^|\s)'+re.escape(name)+r'=([^\s]+)',text)
    return m[1] if m else None

def capacity_error(exc):
    text=((exc.stdout or '')+' '+(exc.stderr or '')).lower()
    return any(s in text for s in ('maxsubmit','job submit limit','too many jobs','maximum number of jobs','submitted job limit'))

class Watcher:
    def __init__(self,args,run=subprocess.run):
        self.a=args;self.base=args.base_dir.resolve();self.run=run
        self.submit= vista.normalizer(self.base,run)
        self.rr=rows(self.base);self.byname={r['name']:r for r in [PILOT,*self.rr]}
        self.selected=self.rr if args.phase=='all' else [r for r in self.rr if r['group']==args.phase]
        self.initial_sources=sources(self.base);self.cache={};self.gone={};self.cost=None
        self.ledger_path=self.base/'status/submissions.json'
        (self.base/'status').mkdir(exist_ok=True);(self.base/'slurm_logs').mkdir(exist_ok=True)

    def complete(self,row):
        if row['kind']=='train':
            out=self.base/'results'/row['name'];done=out/'complete.json'
            if not done.exists():return False
            config=out/'config.json';c=read(config);snapshot=out/'snapshots'/f'epoch_{c["epochs"]:04d}.pt'
            paths=[done,config,snapshot,self.base/'selections/final.json',self.base/'selections/shortlist.json']
            key=tuple((str(p),p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ctime_ns) if p.exists() else (str(p),None) for p in paths)
            if self.cache.get(row['name'])==key:return True
            result=campaign.task_complete(self.base,row)
            if result:self.cache[row['name']]=key
            return result
        return campaign.task_complete(self.base,row)

    def queue(self):
        q=self.run(['squeue','-h','-u',getpass.getuser(),'-o','%.32i|%.200j|%.20T|%r'],check=True,capture_output=True,text=True)
        result={}
        for line in q.stdout.splitlines():
            parts=[v.strip() for v in line.split('|',3)]
            if len(parts)==4 and parts[0].isdigit():result[parts[0]]=dict(name=parts[1],state=parts[2],reason=parts[3])
        return result

    def recover_active(self,ledger,queue):
        """Recover accepted-but-unrecorded submissions using exact service metadata."""
        grouped={}
        for jid,item in queue.items():
            name=item['name'][4:] if item['name'].startswith('fm3_') else None
            if name not in self.byname:continue
            old=ledger.get(name,{})
            if str(old.get('job_id'))==jid:grouped.setdefault(name,[]).append(jid);continue
            q=self.run(['scontrol','show','job','-o',jid],check=True,capture_output=True,text=True)
            wd=field(q.stdout,'WorkDir');command=field(q.stdout,'Command')
            if wd and command and Path(wd).resolve()==self.base and Path(command).resolve()==self.base/'job.slurm':
                grouped.setdefault(name,[]).append(jid)
        for name,jids in grouped.items():
            if len(jids)!=1:raise RuntimeError(f'Multiple active jobs for {name}: {jids}; inspect them before continuing')
            jid=jids[0];row=self.byname[name];old=ledger.get(name,{})
            if old and old['signature']!=campaign.signature(row,self.base):raise ValueError(f'Source/recipe mismatch: {name}')
            if str(old.get('job_id'))!=jid:
                ledger[name]=dict(old,job_id=jid,signature=campaign.signature(row,self.base),row=row,
                    submitted_unix=time.time(),watcher_attempts=old.get('watcher_attempts',1),recovered_from='verified active job')
                if not self.a.dry_run:atomic(self.ledger_path,ledger)
                print(f'[{"WOULD RECOVER" if self.a.dry_run else "RECOVERED"}] {name} {jid}',flush=True)
        return {j for js in grouped.values() for j in js}

    def retry_status(self,row,previous):
        """Retry resumable exits only; scientific/configuration errors stop the watcher."""
        name=row['name'];jid=str(previous['job_id'])
        status_path=self.base/'status'/f'{name}.json'
        status=read(status_path) if status_path.exists() else {}
        rc=status.get('returncode') if str(status.get('slurm_job_id'))==jid else None
        state=None
        q=self.run(['sacct','-X','-n','-P','-j',jid,'--format=JobIDRaw,State,ExitCode'],check=True,capture_output=True,text=True)
        for line in q.stdout.splitlines():
            fields=line.strip().split('|')
            if len(fields)>=2 and fields[0]==jid:state=fields[1].split()[0].rstrip('+')
        if state in ('PENDING','RUNNING','COMPLETING','CONFIGURING'):return 'wait'
        if state and state.startswith('CANCELLED'):raise RuntimeError(f'{name}: job {jid} was cancelled; no automatic retry')
        if rc==75 or state in RESUMABLE:
            attempts=previous.get('watcher_attempts',1)
            if attempts>=1+self.a.max_retries:raise RuntimeError(f'{name} exhausted {self.a.max_retries} automatic resume retries; inspect job {jid}')
            return 'retry'
        if rc not in (None,0):raise RuntimeError(f'{name} failed (job {jid}, return code {rc}); inspect slurm_logs before restarting the watcher')
        if state and state not in ('COMPLETED',):raise RuntimeError(f'{name}: job {jid} ended as {state}; no automatic retry')
        since=self.gone.setdefault(name,time.monotonic())
        if time.monotonic()-since<self.a.completion_grace:return 'wait'
        raise RuntimeError(f'{name}: job {jid} left the queue without a valid completion record; inspect its logs')

    def command(self,row):
        exports=dict(BASE_DIR=str(self.base),TASK=row['name'])
        if self.a.data_root:exports['CSEM_DATA_ROOT']=str(self.a.data_root.resolve())
        if any(',' in v or '\n' in v for v in exports.values()):raise ValueError('Slurm export contains comma/newline')
        wall=self.a.time if row['kind']=='train' else '00:30:00'
        if wall=='auto':
            minutes=max(60,math.ceil(self.cost['per_task_hours'][row['name']]*1.7*60))
            wall=f'{min(minutes//60,48):02d}:{minutes%60 if minutes<2880 else 0:02d}:00'
        cmd=['sbatch','--parsable',f'--job-name=fm3_{row["name"]}',f'--partition={self.a.partition}',f'--time={wall}',
             f'--chdir={self.base}','--export=ALL,'+','.join(f'{k}={v}' for k,v in exports.items())]
        if self.a.account:cmd.append(f'--account={self.a.account}')
        cmd.append(str(self.base/'job.slurm'))
        return cmd

    def tick(self):
        if sources(self.base)!=self.initial_sources:raise ValueError('Training sources changed while the watcher was running')
        with (self.base/'status/submit.lock').open('a') as lock:
            fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
            ledger=read(self.ledger_path) if self.ledger_path.exists() else {}
            queue=self.queue()
            own=self.recover_active(ledger,queue)
            for name,previous in ledger.items():
                if name in self.byname and previous['signature']!=campaign.signature(self.byname[name],self.base):raise ValueError(f'Frozen source/recipe changed for {name}')
            result=dict(inflight=len(own),max_inflight=self.a.max_inflight,user_jobs=len(queue),submitted=[],complete=0,total=len(self.selected),state='active')
            if not self.complete(PILOT):
                previous=ledger.get('pilot')
                if previous and str(previous['job_id']) not in queue:
                    if self.retry_status(PILOT,previous)=='retry':
                        raise RuntimeError('Pilot is incomplete after a resumable interruption. Resume it with python tools/submit_vista.py --phase pilot, then restart this watcher.')
                result['state']='waiting_for_pilot';return self.publish(result)
            if self.cost is None:
                self.cost=campaign.estimate(self.base,self.selected)
                if not self.cost['known']:raise RuntimeError('Pilot timing is not complete')
                print('[PROJECTED COST]',json.dumps(self.cost),flush=True)
                if not self.a.dry_run:atomic(self.base/'projected_cost.json',self.cost)
            complete={r['name']:self.complete(r) for r in self.rr}
            result['complete']=sum(complete[r['name']] for r in self.selected)
            if result['complete']==result['total']:result['state']='complete';return self.publish(result)
            slots=max(0,self.a.max_inflight-len(own))
            if self.a.max_user_jobs is not None:slots=min(slots,max(0,self.a.max_user_jobs-len(queue)))
            for row in self.selected:
                name=row['name'];previous=ledger.get(name)
                if complete[name] or previous and str(previous['job_id']) in queue:continue
                if previous and self.retry_status(row,previous)=='wait':continue
                if not all(complete[p] for p in row['deps']):continue
                if slots<=0:break
                cmd=self.command(row);print('[READY]',shlex.join(cmd),flush=True)
                if self.a.dry_run:result['submitted'].append(name);slots-=1;continue
                try:q=self.submit(cmd,check=True,capture_output=True,text=True,cwd=self.base)
                except subprocess.CalledProcessError as exc:
                    if not capacity_error(exc):raise
                    result.update(state='waiting_for_slurm_capacity',slurm_message=((exc.stdout or '')+' '+(exc.stderr or '')).strip());break
                jid=vista.parse_job_id(q.stdout);history=list(previous.get('watcher_history',[])) if previous else []
                if previous:history.append(dict(job_id=previous['job_id'],submitted_unix=previous.get('submitted_unix')))
                ledger[name]=dict(job_id=jid,signature=campaign.signature(row,self.base),submitted_unix=time.time(),row=row,
                    watcher_attempts=(previous.get('watcher_attempts',1)+1 if previous else 1),watcher_history=history)
                atomic(self.ledger_path,ledger);result['submitted'].append(name);result['inflight']+=1
                self.gone.pop(name,None);slots-=1
            if not result['submitted'] and result['state']=='active':result['state']='waiting_for_slots_or_parents'
            return self.publish(result)

    def publish(self,result):
        result['updated_unix']=time.time()
        if not self.a.dry_run:atomic(self.base/'status/watcher.json',result)
        print('[WATCHER]',json.dumps(result),flush=True)
        return result

def arguments(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base-dir',type=Path,default=ROOT)
    p.add_argument('--phase',choices=('all','screen','development','final'),default='all')
    p.add_argument('--watch',action='store_true',help='Keep refilling; otherwise perform one pass')
    p.add_argument('--dry-run',action='store_true')
    p.add_argument('--max-inflight',type=int,default=4,help='Maximum queued/running jobs from this bundle, including the pilot')
    p.add_argument('--max-user-jobs',type=int,help='Optional additional cap including your unrelated Slurm jobs')
    p.add_argument('--poll',type=float,default=60.)
    p.add_argument('--max-retries',type=int,default=2,help='Extra attempts for timeout, preemption, node failure or exit75 only')
    p.add_argument('--completion-grace',type=float,default=180.)
    p.add_argument('--account',default=os.environ.get('VISTA_ACCOUNT'))
    p.add_argument('--partition',default='gh');p.add_argument('--time',default='auto')
    p.add_argument('--data-root',type=Path,default=os.environ.get('CSEM_DATA_ROOT'))
    a=p.parse_args(argv)
    if a.max_inflight<1 or a.max_retries<0 or a.poll<10 or a.completion_grace<0 or a.max_user_jobs is not None and a.max_user_jobs<1:p.error('Invalid cap, retry count or polling interval')
    if a.watch and a.dry_run:p.error('Use --dry-run without --watch')
    return a

def main(argv=None):
    a=arguments(argv);watcher=Watcher(a);stop=False
    def stopping(*_):
        nonlocal stop
        stop=True
    for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,stopping)
    with (watcher.base/'status/watcher.lock').open('a') as lock:
        try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('A watcher already holds this bundle lock')
        while not stop:
            try:result=watcher.tick()
            except subprocess.CalledProcessError as exc:
                if exc.cmd and exc.cmd[0] in ('squeue','sacct','scontrol'):
                    result=watcher.publish(dict(state='waiting_for_slurm_query',error=str(exc),submitted=[]))
                else:
                    if not a.dry_run:atomic(watcher.base/'status/watcher_error.json',dict(error=str(exc),updated_unix=time.time()))
                    raise
            except BaseException as exc:
                if not a.dry_run:atomic(watcher.base/'status/watcher_error.json',dict(error=str(exc),updated_unix=time.time()))
                raise
            if not a.watch or result['state']=='complete':break
            # Small sleep increments permit quick clean shutdown; the user starts this process on Vista.
            deadline=time.monotonic()+a.poll
            while not stop and time.monotonic()<deadline:time.sleep(min(1.,max(0.,deadline-time.monotonic())))
    return 0

if __name__=='__main__':raise SystemExit(main())
