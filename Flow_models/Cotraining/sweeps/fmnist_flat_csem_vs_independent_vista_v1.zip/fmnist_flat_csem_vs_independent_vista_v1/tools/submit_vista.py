#!/usr/bin/env python3
"""Vista-compatible submission without changing checkpoint source identities.

Examples:
  python tools/submit_vista.py --adopt-pilot 1109335 --phase pilot
  python tools/submit_vista.py --phase all --watch --max-inflight 4
"""
from __future__ import annotations
import argparse
import fcntl
import getpass
import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import campaign
import paper
from protocol import atomic,read

def parse_job_id(stdout):
    """Accept bare/cluster-qualified records and standard Slurm acknowledgements.

    Never interpret arbitrary numbers embedded in a site banner as job IDs.
    Multiple different acknowledgements are ambiguous and fail explicitly.
    """
    stdout=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',stdout)
    candidates=set(re.findall(r'(?m)^\s*(\d+)(?:;[A-Za-z0-9_.-]+)?\s*$',stdout))
    candidates.update(re.findall(r'(?i)\bSubmitted\s+batch\s+job\s+(\d+)\b',stdout))
    if len(candidates)!=1:raise ValueError('No unique Slurm job acknowledgement in stdout')
    return candidates.pop()

def adopt_pilot(base,jid,run=subprocess.run):
    if not re.fullmatch(r'\d+',str(jid)):raise ValueError('Pilot ID must be numeric')
    q=run(['scontrol','show','job','-o',str(jid)],check=True,capture_output=True,text=True)
    def field(name):
        m=re.search(r'(?:^|\s)'+re.escape(name)+r'=([^\s]+)',q.stdout)
        if not m:raise ValueError(f'scontrol did not report {name} for job {jid}')
        return m[1]
    if field('JobName')!='fm3_pilot' or Path(field('WorkDir')).resolve()!=base:
        raise ValueError('Job name/working directory does not match this pilot; no metadata changed')
    if Path(field('Command')).resolve()!=base/'job.slurm':raise ValueError('Job script does not match this bundle')
    row=dict(name='pilot',kind='pilot',deps=[])
    sig=campaign.signature(row,base)
    path=base/'status/submissions.json';path.parent.mkdir(exist_ok=True)
    with (base/'status/submit.lock').open('a') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
        ledger=read(path) if path.exists() else {}
        existing=ledger.get('pilot')
        if existing and existing['signature']!=sig:raise ValueError('Existing pilot source/recipe signature differs')
        if existing and str(existing['job_id'])!=str(jid):raise ValueError('A different pilot is already recorded')
        ledger['pilot']=dict(job_id=str(jid),signature=sig,submitted_unix=time.time(),row=row,
                             recovered_from='verified scontrol job name, workdir and script')
        atomic(path,ledger)
    print(f'[RECOVERED] Existing pilot {jid}; it will not be submitted again.',flush=True)

def normalizer(base,real_run):
    def run(cmd,*args,**kwargs):
        result=real_run(cmd,*args,**kwargs)
        if cmd and str(cmd[0])=='sbatch' and result.returncode==0:
            directory=base/'status/sbatch_responses';directory.mkdir(parents=True,exist_ok=True)
            record=directory/f'{time.time_ns()}.json'
            atomic(record,dict(command=list(cmd),stdout=result.stdout,stderr=result.stderr))
            try:jid=parse_job_id(result.stdout)
            except ValueError as exc:
                jobname=next((str(x).split('=',1)[1] for x in cmd if str(x).startswith('--job-name=')),None)
                matching=[]
                if jobname:
                    q=real_run(['squeue','-h','-u',getpass.getuser(),'--name',jobname,'-o','%i'],check=True,capture_output=True,text=True)
                    for candidate in q.stdout.split():
                        if not candidate.isdigit():continue
                        detail=real_run(['scontrol','show','job','-o',candidate],check=True,capture_output=True,text=True).stdout
                        def field(name):
                            m=re.search(r'(?:^|\s)'+name+r'=([^\s]+)',detail)
                            return m[1] if m else None
                        workdir=field('WorkDir');script=field('Command')
                        if field('JobName')==jobname and workdir and script and Path(workdir).resolve()==base and Path(script).resolve()==base/'job.slurm':matching.append(candidate)
                if len(matching)!=1:
                    raise RuntimeError(f'sbatch returned success but the response could not be parsed uniquely. The job may already be queued. Inspect squeue before retrying; raw output: {record}; matching active IDs: {matching}') from exc
                jid=matching[0]
            result.stdout=jid+'\n'
            print(f'[SUBMITTED] Job {jid}',flush=True)
        return result
    return run

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__,add_help=False)
    p.add_argument('--base-dir',type=Path,default=ROOT)
    p.add_argument('--adopt-pilot',help='Recover the verified ID of an already-submitted pilot')
    p.add_argument('--phase',choices=('pilot','all','screen','development','final'),default='all')
    a,remaining=p.parse_known_args(argv);base=a.base_dir.resolve()
    if a.adopt_pilot:
        if '--dry-run' in remaining:raise ValueError('--adopt-pilot writes the submission ledger; omit --dry-run')
        adopt_pilot(base,a.adopt_pilot)
    if a.phase!='pilot':
        from watch_vista import main as watch_main
        return watch_main(['--base-dir',str(base),'--phase',a.phase,*remaining])
    real_run=campaign.subprocess.run
    campaign.subprocess.run=normalizer(base,real_run)
    try:return paper.main(['--base-dir',str(base),'submit','--phase',a.phase,*remaining])
    finally:campaign.subprocess.run=real_run

if __name__=='__main__':raise SystemExit(main())
