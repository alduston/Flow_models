"""Offline throttling/restart/failure tests; no Slurm commands are executed."""
import io
import json
from pathlib import Path
import subprocess
import tempfile
from contextlib import redirect_stdout
import watch_vista as w
from protocol import ROOT,atomic,rows,sources

class Cluster:
    def __init__(self,base):
        self.base=base;self.active={};self.terminal={};self.completed={'pilot'}
        self.counter=3000;self.calls=[];self.limit=None;self.peak=0
    def run(self,cmd,**kw):
        if cmd[0]=='squeue':
            output='\n'.join(f'{jid}|{value["name"]}|RUNNING|None' for jid,value in self.active.items())
        elif cmd[0]=='scontrol':
            jid=cmd[-1];value=self.active[jid]
            output=f'JobId={jid} JobName={value["name"]} WorkDir={value.get("base",self.base)} Command={value.get("base",self.base)}/job.slurm'
        elif cmd[0]=='sacct':
            jid=cmd[cmd.index('-j')+1];output=f'{jid}|{self.terminal.get(jid,"UNKNOWN")}|0:0|'
        else:
            assert cmd[0]=='sbatch'
            if self.limit is not None and len(self.active)>=self.limit:
                raise subprocess.CalledProcessError(1,cmd,output='',stderr='Job violates accounting/QOS policy (job submit limit)')
            name=next(x.split('=',1)[1] for x in cmd if x.startswith('--job-name='))
            row=next(r for r in rows(self.base) if 'fm3_'+r['name']==name)
            assert all(p in self.completed for p in row['deps']),'Child queued before parent committed'
            self.counter+=1;jid=str(self.counter);self.active[jid]=dict(name=name)
            self.calls.append((row,cmd,jid));self.peak=max(self.peak,len(self.active))
            assert not any(x.startswith('--dependency=') for x in cmd)
            output=f'TACC banner\nSubmitted batch job {jid}\n'
        return subprocess.CompletedProcess(cmd,0,stdout=output,stderr='')
    def finish_all(self):
        for jid,value in list(self.active.items()):
            if value['name'].startswith('fm3_'):
                self.completed.add(value['name'][4:]);self.terminal[jid]='COMPLETED';del self.active[jid]

def fixture(base):
    (base/'pinned').mkdir();(base/'provenance').mkdir();(base/'job.slurm').write_text('fixture')
    (base/'provenance/flat_three_encoder_cell2.json').write_bytes((ROOT/'provenance/flat_three_encoder_cell2.json').read_bytes())
    atomic(base/'pilot/timing.json',dict(gpu='fixture',stages={s:dict(seconds_per_batch=.1,evaluation_seconds=1.) for s in ('joint','vae_pretrain','prior_dsm','prior_csem')}))

def watcher(base,cluster,*flags):
    a=w.arguments(['--base-dir',str(base),'--max-inflight','3',*flags])
    instance=w.Watcher(a,cluster.run)
    instance.complete=lambda row:row['name'] in cluster.completed
    return instance

def main():
    assert sources(ROOT)==json.loads((ROOT/'source_hashes.json').read_text())
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);fixture(base);cluster=Cluster(base);instance=watcher(base,cluster)
        first=instance.tick();assert len(first['submitted'])==3 and len(cluster.active)==3
        restarted=watcher(base,cluster);assert not restarted.tick()['submitted'] and len(cluster.calls)==3
        cluster.active['999']=dict(name='fm3_screen_joint_s42',base=Path('/other/bundle'))
        assert restarted.tick()['inflight']==3
        del cluster.active['999']
        for _ in range(100):
            cluster.finish_all();result=restarted.tick()
            assert len(cluster.active)<=3
            if result['state']=='complete':break
        else:raise AssertionError('Campaign did not finish')
        assert len(cluster.calls)==48 and len({r['name'] for r,cmd,jid in cluster.calls})==48
        assert cluster.peak==3
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);fixture(base);cluster=Cluster(base);cluster.completed.clear()
        cluster.active['1109335']=dict(name='fm3_pilot')
        result=watcher(base,cluster).tick()
        assert result['state']=='waiting_for_pilot' and result['inflight']==1 and not cluster.calls
        assert json.loads((base/'status/submissions.json').read_text())['pilot']['job_id']=='1109335'
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);fixture(base);cluster=Cluster(base)
        for i in range(5):cluster.active[str(100+i)]=dict(name='other_project')
        result=watcher(base,cluster,'--max-user-jobs','6').tick()
        assert len(result['submitted'])==1 and len(cluster.active)==6
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);fixture(base);cluster=Cluster(base);cluster.limit=0;instance=watcher(base,cluster)
        assert instance.tick()['state']=='waiting_for_slurm_capacity' and not cluster.calls
        cluster.limit=None;assert len(instance.tick()['submitted'])==3
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);fixture(base);cluster=Cluster(base)
        instance=watcher(base,cluster,'--max-inflight','1','--max-retries','1')
        instance.tick();row,cmd,jid=cluster.calls[-1]
        del cluster.active[jid];cluster.terminal[jid]='TIMEOUT'
        instance.tick();assert len(cluster.calls)==2
        row,cmd,jid=cluster.calls[-1];del cluster.active[jid];cluster.terminal[jid]='TIMEOUT'
        try:instance.tick()
        except RuntimeError as exc:assert 'exhausted' in str(exc)
        else:raise AssertionError('Retries were unbounded')
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);fixture(base);cluster=Cluster(base);instance=watcher(base,cluster,'--max-inflight','1')
        instance.tick();row,cmd,jid=cluster.calls[-1];del cluster.active[jid];cluster.terminal[jid]='FAILED'
        atomic(base/'status'/f'{row["name"]}.json',dict(slurm_job_id=jid,returncode=1))
        try:instance.tick()
        except RuntimeError as exc:assert 'failed' in str(exc)
        else:raise AssertionError('Scientific failure was resubmitted')
        assert len(cluster.calls)==1
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);fixture(base);cluster=Cluster(base);instance=watcher(base,cluster,'--dry-run')
        assert len(instance.tick()['submitted'])==3 and not cluster.calls
        assert not (base/'status/submissions.json').exists()
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);fixture(base);cluster=Cluster(base);instance=watcher(base,cluster,'--max-inflight','1')
        instance.tick();row,cmd,jid=cluster.calls[-1];del cluster.active[jid];cluster.terminal[jid]='CANCELLED'
        atomic(base/'status'/f'{row["name"]}.json',dict(slurm_job_id=jid,returncode=75))
        try:instance.tick()
        except RuntimeError as exc:assert 'cancelled' in str(exc)
        else:raise AssertionError('Cancelled job was automatically resubmitted')
        assert len(cluster.calls)==1
    result=dict(total_jobs=48,tested_inflight_cap=3,parents_complete_before_submission=True,
        restart_without_duplicates=True,existing_pilot_preserved=True,unrelated_jobs_untouched=True,
        optional_user_job_cap=True,capacity_rejection_deferred=True,resume_retry_limit=True,
        scientific_failures_stop=True,cancelled_jobs_not_resubmitted=True,dry_run_does_not_submit=True,training_source_hashes='unchanged')
    atomic(ROOT/'validation/watcher_checks.json',result);print(json.dumps(result,indent=2))

if __name__=='__main__':main()
