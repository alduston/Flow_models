# LS6 port validation

The port was checked offline in a Python3.12 workspace without Torch or a GPU.
No LS6 installation, CUDA execution, or scientific training is claimed.

Passed checks:

- Python3.9 grammar parsing of all25 active Python files and Bash syntax for
  environment/setup/job scripts.
- Eight Slurm response-parser cases, verified pilot adoption, rejection of an
  unrelated directory, raw response capture, and exact-workdir fallback.
- Simulation of the complete48-task DAG under a three-job inflight cap, ready
  parents only, duplicate-free restart, active-pilot preservation, other-user-
  job cap, scheduler capacity deferral, bounded timeout retries, hard failure
  stop, cancellation stop, and non-submitting dry runs.
- Automatic fresh pilot submission/gating and pilot-only mode; A100/H100 and
  global caps including expanded array tasks; explicit hard-failure retry
  consumed once; rejection of a different GPU partition after binding.
- All public submission routes use the bounded LS6 launcher. Actual Bash job
  execution with a mock Python executable preserved positional data arguments,
  selected one visible GPU, and propagated exit75.
- Exact equality of the parsed common training recipe and full DAG to the
  previous comparison bundle. Fourteen scientific source files remain byte-
  identical, including models, training, data, evaluation, and compilation.
  The reference module differs only by removing an unused private Torch import.
  `provenance/LS6_PORT_AUDIT.json` records this comparison and the parent ZIP hash.

Re-run offline checks from the bundle directory:

```bash
python -B tools/test_submit_ls6.py
python -B tools/test_watch_ls6.py
python -B tools/test_ls6_port.py
```

See validation/*.json for actual offline results. Previous framework execution
records are explicitly archived under provenance/vista_validation/; they are
not evidence of this LS6 environment. The mandatory LS6 pilot performs CUDA
model/gradient checks, CPU bitwise replay for all four stages, and real-model
training/evaluation with prepared Fashion-MNIST and LPIPS/Inception weights.
Only successful completion releases production jobs.

Deployment changes are limited to module/venv/pinned-wheel setup, scheduler and
job transport, environment checks, deployment-source identity guards, removal
of the unused private import, and the CPU replay-check fix. Fresh source hashes
and archive checksums were regenerated. No old submissions/results/timings are
installed. `SHA256SUMS` covers every packaged file except itself.
