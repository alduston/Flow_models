#!/bin/bash
set -eo pipefail
FMNIST_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export FMNIST_ALLOW_MISSING_ENV=1
source "$FMNIST_ROOT/environment.sh"
python3 - <<'PY'
import sys,platform
assert sys.version_info[:2]==(3,9), 'Expected module Python 3.9; select the documented module.'
assert platform.machine()=='x86_64', 'Run on an LS6 x86_64 node, not Vista ARM.'
PY
if [[ ! -x "$FMNIST_VENV_DIR/bin/python" ]]; then python3 -m venv "$FMNIST_VENV_DIR"; fi
source "$FMNIST_VENV_DIR/bin/activate"
python -m pip install --upgrade 'pip==25.3'
python -m pip install 'torch==2.5.1' 'torchvision==0.20.1' --index-url https://download.pytorch.org/whl/cu121
python -m pip install -r "$FMNIST_ROOT/requirements_ls6.txt"
python -m pip check
python "$FMNIST_ROOT/check_environment.py"
python -m pip freeze > "$FMNIST_VENV_DIR/fmnist_installed_packages.txt"
echo 'Environment ready. Run: source environment.sh; python prepare_cache.py --weights'
