# Run the FMNIST comparison on Lonestar6

This is the three-regime comparison campaign from this conversation, ported to
LS6. The attached capacity-matched LS6 audit and GAD bundles supplied the
module, environment, and queue conventions. They do not replace this study's
models, losses, grids, or evaluation. This archive starts a fresh campaign;
Vista job IDs, results, selections, and pilot timing are not installed.

## 1. Extract and prepare on an LS6 login node

Put `fmnist_flat_csem_vs_independent_ls6_v1.zip` in your sweeps directory:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/Cotraining/sweeps
unzip fmnist_flat_csem_vs_independent_ls6_v1.zip
cd fmnist_flat_csem_vs_independent_ls6_v1
sha256sum -c SHA256SUMS
bash setup_environment.sh
source environment.sh
export CSEM_DATA_ROOT="$PWD/data_cache_fmnist"
python paper.py init
python prepare_cache.py --weights
python paper.py plan
```

Use a fresh directory. Do not extract over the Vista campaign or copy its
`status/`, `pilot/`, `selections/`, or `results/` into this directory. There is
no need to cancel Vista jobs to prepare this bundle. If the same campaign is
still active there, decide which cluster's results you intend to use before
spending compute on both.

The setup loads `gcc/11.2.0` and `python3/3.9.7`, creates
`${SCRATCH}/venvs/fmnist_comparison_ls6_py39`, and installs PyTorch2.5.1 and
torchvision0.20.1 CUDA12.1 wheels plus the pinned Python3.9 dependencies. It
also runs import/version checks and `pip check`. It does not modify your GAD
or capacity-audit environment. Every job reloads this same environment.

If setup/downloads cannot run on your login node, use an allocated session:

```bash
idev -p gpu-a100-dev -N 1 -n 1 -t 01:00:00 -A DMS22021
# Once allocated, return to the bundle directory and repeat setup/preparation.
```

The venv belongs on LS6 `$SCRATCH`, as TACC specifies; do not reuse Vista's
ARM/Python3.11 venv. Torch weights use `${SCRATCH}/fmnist_ls6_torch_cache` by
default, allowing reuse of valid weights from the attached LS6 audit. Dataset
preparation validates the Fashion-MNIST IDX files/checksums; it does not import
Torch or load large checkpoints. LPIPS calibration weights ship with LPIPS.

Optional custom paths: export `FMNIST_VENV_DIR`, `FMNIST_TORCH_HOME`, and/or
`CSEM_DATA_ROOT` before setup/preparation, and retain the same values on future
submissions. `environment.sh` maps `FMNIST_TORCH_HOME` to `TORCH_HOME` and supplies
the module Python's shared-library path on compute nodes. No installs or data
preparation run inside batch jobs.

## 2. Start the bounded campaign (A100 default)

Preview the first submission, then launch the persistent watcher:

```bash
python tools/submit_ls6.py --phase all --partition gpu-a100 --dry-run
mkdir -p status slurm_logs
nohup python -u tools/submit_ls6.py \
  --phase all --watch --partition gpu-a100 \
  --max-inflight 4 --max-user-jobs 32 --poll 60 \
  --account DMS22021 \
  > status/watcher.log 2>&1 < /dev/null &
echo $! > status/watcher.pid
hostname > status/watcher.host
```

One command handles the pilot and the full campaign. It first submits one
4-hour pilot, waits for success, then refills at most four pending/running
campaign jobs. It submits only tasks whose parent outputs have been validated.
The full study remains 45 training tasks plus shortlist/freeze/report (48), in
addition to the pilot. They are submitted in waves, not all at once.

For H100, use `--partition gpu-h100` in BOTH commands **before the first
submission**, instead of A100. The same isolated environment supports both.
The watcher additionally limits submissions using published partition caps:
32 A100 jobs or four H100 jobs, counting your other jobs in that partition.
The default global cap also counts all your user jobs, including expanded array
tasks, across partitions. It never cancels or changes your other project jobs.
Live `qlimits`/Slurm policy can be stricter; submit-limit rejection defers a
refill. H100 may run only one of your jobs at once under current queue policy.

Each scientific trainer requests one node and one task, uses a single visible
GPU, and retains batch128 and full500-epoch budgets. There is no DDP or change
to the loss reduction. Whole-node GPU queues may allocate more GPUs than this
trainer uses, and node billing still applies. No `--gres` or `--export` is used;
the bundle path, task, and data path are positional job arguments.

A campaign becomes bound to its first GPU partition in
`status/ls6_scheduler.json`. This prevents silently using A100 pilot timing to
size H100 jobs or mixing GPU families within a comparison. To run another GPU
family, extract a fresh copy into another directory, select that partition,
prepare its paths, and run a fresh pilot. Both queues currently allow up to
48 hours per job; auto walltimes use1.7 times the new pilot estimate, rounded
up with a1-hour floor and48-hour cap. `--time 48:00:00` overrides production
walltime, and `--pilot-time 08:00:00` changes the pilot limit. Epoch budgets do
not change to fit walltime. `LS6_SU_PER_NODE_HOUR` optionally supplies your actual
billing multiplier for `projected_cost.json`; no SU rate is assumed.

## 3. Check progress

```bash
squeue -u "$USER"
cat status/watcher.host
ps -p "$(cat status/watcher.pid)" -o pid,etime,args
cat status/watcher.json
tail -n 30 status/watcher.log
```

Check the PID on the login host recorded in `watcher.host`; a process on
login1 is not shown by `ps` on login2. A `nohup` process survives disconnects
but cannot survive a login-node restart or a site process cleanup. If it stops,
restart the same command on an LS6 login node, after `source environment.sh`.
The file lock rejects a second simultaneous watcher for this directory.
Restarting reuses its ledger, verified active jobs, and completed outputs.
Writing a fresh `watcher.log` on restart avoids confusing old tracebacks with
current status. Historical per-submission responses remain in
`status/sbatch_responses/`.

`waiting_for_pilot` while the pilot is pending/running is expected. Production
is gated on `pilot/timing.json`. That file is written only after all checks
and four timed production stages succeed. The pilot runs model/gradient/frozen
state checks on CUDA, exact interruption/replay checks on CPU, then real
production architecture and data (ten training batches per stage), including
LPIPS/GAN and full10k validation evaluations. Synthetic replay metrics cannot
enter selection or the final report. This includes the CPU resume-check fix
applied to the failed Vista pilot; it does not alter scientific training.

The actual LS6 Python/CUDA driver combination is checked on the allocated
node, including a CUDA matrix backward pass; failure has no CPU fallback.
Inspect `slurm_logs/fm3_pilot_<ID>.out` and `.err` if the pilot fails. A pilot
alone can be submitted via `--phase pilot`; later `--phase all --watch` adopts
that recorded active/completed pilot without submitting another.

## 4. Resume and recover

Training checkpoints every committed epoch, with optimizer, scheduler, EMA,
discriminator and RNG state. Slurm signals the job ten minutes before its limit,
and the wrapper forwards that signal to Python. Timeouts, preemptions, node
failures, or exit75 can resume automatically, up to two additional attempts
per task. Increase `--max-retries` deliberately if LS6 timings show that more
allocations are needed. The data/recipe/source/parent hash guards remain active.

A hard training/environment failure or cancellation stops the watcher for
inspection. After correcting an external environment/cache issue, explicitly
retry the named task once (example for a pilot):

```bash
source environment.sh
nohup python -u tools/submit_ls6.py \
  --phase all --watch --partition gpu-a100 \
  --max-inflight 4 --max-user-jobs 32 --poll 60 --account DMS22021 \
  --retry-failed pilot \
  > status/watcher.log 2>&1 < /dev/null &
echo $! > status/watcher.pid
hostname > status/watcher.host
```

Use your chosen partition and the actual failed task name from the ledger/log.
The explicit permission is consumed once, so a second hard failure stops again.
Do not delete the submission ledger or edit source hashes to force a retry.
Changes to code, dependencies, scientific settings, or frozen selections after
training has started require review of checkpoint compatibility; a fresh
campaign directory is the straightforward option for a changed experiment.
An unparseable successful `sbatch` response may mean the job was accepted:
inspect `squeue` before retrying. The launcher stores raw responses and recovers
a unique active job only after matching name, working directory, and script.

Without `--watch`, the launcher performs just one bounded refill. With
`--dry-run`, it only prints the ready submissions; before a completed pilot it
can preview only that pilot. After the pilot it previews the first production
wave. No dry run submits a job or writes the submission ledger.

## 5. Compile results

After reconnecting, enter the directory and `source environment.sh`, then:

```bash
python paper.py status
python paper.py report
# Once all confirmation stages are complete:
python paper.py report --strict
zip -r fmnist_ls6_comparison_results.zip compiled/
```

The watcher also runs the strict report automatically after all required tasks
complete. `compiled/` contains FID curves, paired seed differences, endpoint
confidence intervals, raw tables, and prespecified seed47 images. Independent
pipeline compute includes its VAE pretraining cost. See `STUDY.md` for the
scientific design, `RECIPE_DIFF.md` for the comparison's intentional changes
from the historical recipe, and `VALIDATION_LS6.md` for checks actually run.

## References checked for this port

- https://docs.tacc.utexas.edu/hpc/lonestar6/ (LS6 environment and architecture)
- https://docs.tacc.utexas.edu/hpc/6lonestar/running/ (GPU queues and limits)
- https://docs.pytorch.org/get-started/previous-versions/ (2.5.1/0.20.1 CUDA12.1 wheels)

Published queue limits are guides, not a promise of immediate availability.
Local `qlimits` and the allocation's active policies take precedence.
