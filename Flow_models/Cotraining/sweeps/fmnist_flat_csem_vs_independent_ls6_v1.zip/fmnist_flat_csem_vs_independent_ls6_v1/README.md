# FMNIST flat CSEM versus two-stage LDMs — Lonestar6

Start with **RUN_ON_LONESTAR6.md** for exact setup, A100/H100 submission,
bounded watching, recovery, and compilation commands.

This ports the existing comparison campaign, preserving the historical4.323
flat-three-encoder co-training recipe and its matched independent Tweedie/DSM
and analytic CSEM variants. The full grid, fresh47–51 confirmation seeds,
500-epoch budgets and evaluation are unchanged. See STUDY.md and RECIPE_DIFF.md.

The Python3.9 LS6 environment is isolated from GAD and the older capacity audit.
The launcher starts a fresh timed LS6 pilot and keeps at most four campaign
jobs pending/running. Published queue caps and your other user jobs are also
counted. All entry points use this bounded launcher.

This ZIP contains source and validation records, not trained weights or new FID
results. No LS6 GPU run was executed here. A mandatory allocated pilot tests
CUDA and the real production paths before expensive training. The known Vista
bitwise replay check now runs on CPU; GPU model checks remain enabled.

Archived Vista instructions/checks under provenance/ are historical records.
Do not use those commands to launch this port. All completed Vista state stays
outside this fresh campaign.
