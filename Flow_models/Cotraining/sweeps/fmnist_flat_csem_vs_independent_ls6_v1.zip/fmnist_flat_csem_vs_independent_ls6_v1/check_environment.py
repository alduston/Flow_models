"""Fail before training if the LS6 Python/wheel/driver setup is incompatible."""
import argparse
import json
import platform
import sys

def main():
    p=argparse.ArgumentParser();p.add_argument('--gpu',action='store_true');a=p.parse_args()
    if sys.version_info[:2]!=(3,9):raise RuntimeError('Load python3/3.9.7 and source environment.sh')
    if platform.machine()!='x86_64':raise RuntimeError('Expected LS6 x86_64, not the Vista ARM environment')
    import torch,torchvision,lpips,numpy,scipy,pandas,matplotlib
    if torch.__version__.split('+')[0]!='2.5.1' or torchvision.__version__.split('+')[0]!='0.20.1':
        raise RuntimeError('Use the torch2.5.1/torchvision0.20.1 CUDA12.1 pair installed by setup_environment.sh')
    if torch.version.cuda!='12.1':raise RuntimeError('Expected the CUDA12.1 wheel set')
    import models,train_stages,evaluate,compile_results,checks
    print(json.dumps(dict(python=sys.version,torch=torch.__version__,torchvision=torchvision.__version__,
        cuda=torch.version.cuda,numpy=numpy.__version__,machine=platform.machine())),flush=True)
    if a.gpu:
        if not torch.cuda.is_available():raise RuntimeError('CUDA unavailable on allocated LS6 node; no CPU fallback')
        x=torch.randn(128,128,device='cuda',requires_grad=True)
        loss=(x@x.T).square().mean();loss.backward();torch.cuda.synchronize()
        if not torch.isfinite(loss):raise RuntimeError('Nonfinite CUDA check')
        print('GPU:',torch.cuda.get_device_name(0),flush=True)
    return 0

if __name__=='__main__':raise SystemExit(main())
