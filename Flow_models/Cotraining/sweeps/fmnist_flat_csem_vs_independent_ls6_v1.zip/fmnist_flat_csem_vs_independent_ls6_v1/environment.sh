#!/bin/bash
# Source on LS6 login AND compute nodes; isolated FMNIST environment.
fmnist_environment() {
  if declare -F deactivate >/dev/null; then deactivate; fi
  if [[ "${FMNIST_SKIP_MODULES:-0}" != 1 ]]; then
    module purge || return
    module load "${FMNIST_GCC_MODULE:-gcc/11.2.0}" || return
    module load "${FMNIST_PYTHON_MODULE:-python3/3.9.7}" || return
  fi
  export FMNIST_VENV_DIR="${FMNIST_VENV_DIR:-${SCRATCH:?Set SCRATCH or FMNIST_VENV_DIR}/venvs/fmnist_comparison_ls6_py39}"
  export TORCH_HOME="${FMNIST_TORCH_HOME:-${SCRATCH:?Set SCRATCH or FMNIST_TORCH_HOME}/fmnist_ls6_torch_cache}"
  # Include module Python's shared-library directory for batch-node startup.
  local fmnist_lib
  fmnist_lib="$(python3 -c 'import sysconfig;print(sysconfig.get_config_var("LIBDIR") or "")')" || return
  if [[ -n "$fmnist_lib" ]]; then export LD_LIBRARY_PATH="$fmnist_lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"; fi
  if [[ -f "$FMNIST_VENV_DIR/bin/activate" ]]; then source "$FMNIST_VENV_DIR/bin/activate" || return
  elif [[ "${FMNIST_ALLOW_MISSING_ENV:-0}" != 1 ]]; then
    echo "Missing $FMNIST_VENV_DIR. Run bash setup_environment.sh first." >&2; return 2
  fi
  export OMP_NUM_THREADS=8 MKL_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 NUMEXPR_NUM_THREADS=8 MPLBACKEND=Agg
}
fmnist_environment
