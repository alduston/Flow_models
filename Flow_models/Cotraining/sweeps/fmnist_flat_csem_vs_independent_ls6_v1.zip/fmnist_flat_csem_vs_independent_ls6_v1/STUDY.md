# Fashion-MNIST: matched flat CSEM versus two-stage LDMs

This bundle preserves the **flat_three_encoder** architecture and joint recipe
identified in the supplied plan with **seed-42 FID 4.3229685350** and historical
five-seed mean **4.5597724371 +/- 0.1684896094 SD**. It does not use the separate
two-block 4.304 run or the smaller `flat` encoder. Those endpoint values are
provenance reported in the supplied plan, not results newly measured here.

The comparison has three output regimes:

| Regime | Representation | Prior |
|---|---|---|
| `cotrained_csem` | 500 joint epochs, original CSEM/terminal/band recipe | Original joint analytic CSEM |
| `indep_tweedie` | 500 epochs of image loss + beta0 time-zero KL | Fresh DiT, 500 DSM epochs |
| `indep_csem` | Exactly the same frozen VAE as paired DSM | Fresh equally initialized DiT, 500 analytic CSEM epochs |

No cluster training is performed by downloading this archive. All training
starts from scratch: the supplied baseline archive contains source and recipes,
not the completed 4.323 model weights.

## Campaign design

The default full DAG has **45 training tasks plus three selection/report jobs**
(48 total jobs, submitted in waves of at most four, in addition to the pilot):

1. **Screen:** seed42 joint reference and six independent VAEs at
   beta0 = 0, .01, .03, .07, .15, .30; all run 500 epochs. Only validation
   reconstruction/representation diagnostics select two positive beta points.
2. **Shortlist:** keep the closest reconstruction match and a point on the
   positive-beta reconstruction/KL frontier. Prefer the opposite side of the
   reference distortion when available. Beta=0 remains a diagnostic control.
   The automatic selector stops if no positive point is within 50% of the joint
   reconstruction FID, so a poor screen cannot silently become the final baseline.
3. **Development:** train the two shortlisted seed43 VAEs. Reuse the corresponding
   seed42 screen VAEs. Train both prior objectives at both candidate LRs,
   **3.333333e-4 and 8e-4**, on development seeds42/43: 16 priors, 500 epochs each.
4. **Freeze:** choose one common beta0/LR by mean epoch500 CFG3 validation FID
   across both objectives and both seeds. The paired priors' checkpoint and
   initialization hashes must match. The shortlist and final choice are immutable.
5. **Confirmation:** seeds47--51, 5 joint runs + 5 VAEs + 10 priors = **20 tasks**,
   yielding 15 generative models. Each independent prior depends on its exact,
   successfully completed VAE. Fresh jobs cannot start before parameter selection.
6. **Report:** require all 20 stages and all five seed identities, then produce
   curves, uncertainty tables, paired differences, sample grids and raw exports.

The watcher waits for successful parent-stage completion before queueing each
child. Training verifies parent metadata and hashes again at startup. Job names use symbolic beta slots
until the validation shortlist is available; each run's `config.json` records
the resolved beta, source checkpoint hash, selection hash and exact recipe.

## Evaluation and results

All three new comparison arms train on the **same fixed stratified 50k subset**
of the original60k training images; the remaining10k form a validation reference.
The official10k test images are reserved for confirmation reporting. This is the
split change explicitly prescribed by the supplied plan. The model and joint
loss recipe remain those of the4.323 result; a repeated4.323 value on this split
is not promised.

- Fixed CFG3 primary and CFG1 secondary, Gaussian start, temperature1, T=2,
  t_min=2e-5, decode_time=1e-4, 20 RK4 integration steps.
- The unchanged legacy torchvision Inception extractor and inherited PSD
  covariance FID calculation are used throughout. No new feature backend.
- Evaluation every50 joint/prior epochs, including the fixed500 endpoint;
  independent VAEs report reconstruction diagnostics at the same interval.
- One fixed evaluation start/posterior stream across regimes, seeds and epochs,
  isolated from training; class counts/order follow the common reference labels.
- Actual head forward calls are counted. With the inherited two-pass CFG path,
  RK4-20 uses160 head forwards per sample even at CFG1; it is not20 NFE.
- Endpoint KID uses20 fixed subsets of1000, raw polynomial MMD^2 units. Subset SD
  is separate from training-seed uncertainty.
- Posterior-sample reconstruction FID is a reference, not a guaranteed lower bound.
- EMA is applied only to the score head; VAE state is online/frozen as appropriate.
- Saved-checkpoint evaluation checks identical tensors and full RK4 solves on
  fixed inputs, including CFG1/null-label and CFG3 paths.

```bash
python paper.py report --strict
```

`compiled/` then contains:

- `fmnist_comparison.pdf`, `.svg`, `.png`: two-panel FID versus epoch and total
  training GPU-hours, with pointwise95% Student-t intervals across five seeds.
- `per_seed_metrics.csv`, `curve_summary.csv`, `endpoint_summary.csv/.json`,
  `paired_differences.csv`, `timing.csv`, `status.csv` and a readable `report.md`.
- `common_compute_summary.csv`: comparison only within overlapping observed
  compute ranges for every seed, linearly interpolating between recorded points;
  no extrapolation. Empty if no common range exists.
- `website_training_curves.csv`: `regime,seed,epoch,fid`, CFG3 only, with duplicate
  and seed checks performed by this compiler.
- `representative_seed47/`: prespecified class-balanced images and reconstruction
  references, chosen without best-seed selection.

Independent compute curves include the **full500-epoch VAE cost for each usable
pipeline**, even though the campaign shares that checkpoint. Evaluation time and
allocation runtime are exported separately from training. Generation curves start
at the first measured prior checkpoint after pretraining, not at zero cost.
Both independent stages receive500 epochs; co-training receives500 joint epochs.
This is a fully trained baseline comparison, not an equal-epoch/equal-compute claim.

The historical seeds42--46 are excluded from fresh confidence intervals. The
endpoint differences are seed-paired; overlapping curve bands are not used as a
significance test. An incomplete report displays observed/expected counts and
never writes the strict completion marker.


For LS6 setup and submission, use RUN_ON_LONESTAR6.md. Archived Vista instructions are provenance only.
