"""Offline LS6 regression checks; no Torch installation or Slurm account needed."""
import ast
import io
import json
from pathlib import Path
import subprocess
import tempfile
from contextlib import redirect_stdout
from unittest.mock import patch
import test_watch_ls6 as sim
import watch_ls6 as w
import submit_ls6
import campaign
import paper
from protocol import ROOT,atomic,common,rows,sources

def main():
    parsed=0
    for path in [*ROOT.glob('*.py'),*(ROOT/'tools').glob('*.py'),*(ROOT/'pinned').glob('*.py')]:
        ast.parse(path.read_text(),filename=str(path),feature_version=(3,9));parsed+=1
    for name in ('environment.sh','setup_environment.sh','job.slurm'):
        subprocess.run(['bash','-n',str(ROOT/name)],check=True)
    assert sources(ROOT)==json.loads((ROOT/'source_hashes.json').read_text())
    config=common();rr=rows()
    assert len(rr)==48 and sum(r['kind']=='train' for r in rr)==45
    assert config['epochs']==500 and config['rep_multiplier']==.5
    assert config['joint_depth']==18 and config['joint_width']==192
    assert config['batch']==128 and config['eval_samples']==10000
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);sim.fixture(base);cluster=sim.Cluster(base);cluster.completed.clear()
        instance=sim.watcher(base,cluster)
        assert instance.tick()['submitted']==['pilot']
        assert not instance.tick()['submitted'] and len(cluster.calls)==1
        row,cmd,jid=cluster.calls[0];assert '--time=04:00:00' in cmd
        cluster.finish_all();assert len(instance.tick()['submitted'])==3
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);sim.fixture(base);cluster=sim.Cluster(base);cluster.completed.clear()
        instance=sim.watcher(base,cluster,'--phase','pilot');instance.tick();cluster.finish_all()
        assert instance.tick()['state']=='complete' and len(cluster.calls)==1
    for partition,limit in (('gpu-h100',4),('gpu-a100',32)):
        with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
            base=Path(temp);sim.fixture(base);cluster=sim.Cluster(base)
            for i in range(limit-1):cluster.active[str(100+i)]=dict(name='other',partition=partition)
            instance=sim.watcher(base,cluster,'--partition',partition)
            assert len(instance.tick()['submitted'])==1
            assert not instance.tick()['submitted']
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);sim.fixture(base);cluster=sim.Cluster(base)
        for i in range(32):cluster.active[str(100+i)]=dict(name='other',partition='normal')
        assert not sim.watcher(base,cluster).tick()['submitted']
        cluster.run_original=cluster.run
        def arrays(cmd,**kw):
            if cmd[0]=='squeue':
                assert '--array' in cmd
                out='\n'.join(f'123_{i}|other|PENDING|Priority|normal' for i in range(32))
                return subprocess.CompletedProcess(cmd,0,stdout=out,stderr='')
            return cluster.run_original(cmd,**kw)
        cluster.run=arrays
        assert not sim.watcher(base,cluster).tick()['submitted']
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);sim.fixture(base);cluster=sim.Cluster(base)
        instance=sim.watcher(base,cluster,'--max-inflight','1');instance.tick()
        row,cmd,jid=cluster.calls[-1];del cluster.active[jid];cluster.terminal[jid]='FAILED'
        retry=sim.watcher(base,cluster,'--max-inflight','1','--retry-failed',row['name'])
        assert len(retry.tick()['submitted'])==1
        row,cmd,jid=cluster.calls[-1];del cluster.active[jid];cluster.terminal[jid]='FAILED'
        try:retry.tick()
        except RuntimeError:pass
        else:raise AssertionError('Explicit retry was not consumed')
    with tempfile.TemporaryDirectory() as temp,redirect_stdout(io.StringIO()):
        base=Path(temp);sim.fixture(base);cluster=sim.Cluster(base)
        sim.watcher(base,cluster).tick()
        try:sim.watcher(base,cluster,'--partition','gpu-h100').tick()
        except ValueError as exc:assert 'different GPU partition' in str(exc)
        else:raise AssertionError('Cross-GPU timing reuse was accepted')
    # Every public submission entry point reaches the same bounded launcher.
    with patch('watch_ls6.main',return_value=0) as entry:
        submit_ls6.main(['--phase','pilot']);assert '--phase' in entry.call_args.args[0]
        submit_ls6.main(['--phase','all']);assert entry.call_count==2
    with patch('submit_ls6.main',return_value=0) as entry:
        paper.main(['submit','--phase','pilot']);assert '--partition' in entry.call_args.args[0]
        assert 'gpu-a100' in entry.call_args.args[0]
    # Real job script argument/environment forwarding, single GPU, and exit propagation.
    with tempfile.TemporaryDirectory() as temp:
        base=Path(temp);(base/'bin').mkdir()
        (base/'environment.sh').write_text('export PATH="'+str(base/'bin')+':$PATH"\n')
        fake=base/'bin/python'
        fake.write_text('#!/bin/bash\nprintf "%s\\n" "$* gpu=$CUDA_VISIBLE_DEVICES" >> "$LS6_TEST_LOG"\nif [[ "$1" == -u ]]; then exit 75; fi\n')
        fake.chmod(0o755)
        import os
        env=dict(os.environ,LS6_TEST_LOG=str(base/'calls'),CUDA_VISIBLE_DEVICES='2,1')
        result=subprocess.run(['bash',str(ROOT/'job.slurm'),str(base),'pilot','/data path'],env=env)
        assert result.returncode==75
        calls=(base/'calls').read_text()
        assert 'check_environment.py --gpu gpu=2' in calls
        assert '-u paper.py run --task pilot --data-root /data path gpu=2' in calls
    result=dict(python39_syntax_files=parsed,shell_syntax=True,dag_tasks=48,training_tasks=45,
        fresh_pilot_gate=True,pilot_only_no_production=True,global_and_partition_caps=True,array_tasks_counted=True,
        positional_arguments=True,no_slurm_export=True,explicit_failure_retry_once=True,
        public_submit_paths_bounded=True,batch_exit75_preserved=True,single_visible_gpu=True,
        production_torch_execution=False,ls6_gpu_execution=False)
    atomic(ROOT/'validation/ls6_port_checks.json',result);print(json.dumps(result,indent=2))
if __name__=='__main__':main()
