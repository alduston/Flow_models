import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import sys,tempfile,time,numpy as np
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from models import ConditionalBank,GMM
from flows import integrate
from common import write,source_sha
p=np.load(R/'data/inputs.npz');v=np.load(R/'tests/pilot_velocity.npz');vm=GMM(v['weights'],v['means'],v['covariances']);bank=ConditionalBank(p['x'],p['s'],p['P'],vm);x=p['posterior'][:64,8:12];vel=p['posterior'][:64,20:];config=dict(tau=1e-6,T=8.,rtol=1e-8,atol=1e-10,chunk=16)
with tempfile.TemporaryDirectory() as temp:
 os.environ['QUAKE_CHUNK_WORKERS']='1';t=time.perf_counter();a,la,ca=integrate(bank,x,vel,2,False,config,Path(temp)/'serial','test');serial=time.perf_counter()-t
 os.environ['QUAKE_CHUNK_WORKERS']='4';t=time.perf_counter();b,lb,cb=integrate(bank,x,vel,2,False,config,Path(temp)/'parallel','test');parallel=time.perf_counter()-t
 assert np.array_equal(a,b) and np.array_equal(la,lb) and ca==cb
 # Parallel execution can reuse serial checkpoint files because row groups and arithmetic are unchanged.
 c,lc,cc=integrate(bank,x,vel,2,False,config,Path(temp)/'serial','test');assert np.array_equal(a,c) and np.array_equal(la,lc) and ca==cc
write(R/'logs/parallel_chunk_checks.json',dict(passed=True,bitwise_equal=True,query_count=64,chunk=16,serial_seconds=serial,parallel_seconds=parallel,parallel_workers=4,scope='local timing only; not an LS6 runtime or cost prediction'))
print('Parallel chunks bitwise equal; times',serial,parallel)
