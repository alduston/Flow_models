#!/bin/bash
# 20 balanced production tasks by default. Actual task/concurrency caps use queue/headroom preflight.
set -euo pipefail
BUNDLE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$BUNDLE"
profile=production;reference=0;marginals=1
while [[ $# -gt 0 ]]; do
 case "$1" in --pilot) profile=pilot;; --smoke-only) profile=smoke;; --with-reference) reference=1;; --no-marginals) marginals=0;; *) echo "Usage: bash submit.sh [--pilot|--smoke-only] [--with-reference] [--no-marginals]"; exit 2;; esac
 shift
done
mkdir -p logs
exec 9>.submission.lock
flock -n 9 || { echo 'Submission already in progress'; exit 2; }
if [[ -f logs/submitted_ids.txt ]]; then
 while read -r stage id; do
  if ! state=$(squeue -h -j "$id" 2>/dev/null); then
   # Some Slurm versions reject IDs that have left squeue. Confirm terminal state in accounting.
   state=$(sacct -n -X -j "$id" --format=State --parsable2) || { echo "Cannot verify prior $stage job $id; inspect queue before resubmitting." >&2; exit 2; }
   if [[ -z "$state" ]] || [[ -n "$(printf '%s\n' "$state" | sed '/^$/d' | grep -Ev '^(COMPLETED|FAILED|CANCELLED|TIMEOUT|NODE_FAIL|OUT_OF_MEMORY|PREEMPTED|BOOT_FAIL|DEADLINE)[^|]*\|?$' || true)" ]]; then echo "Prior $stage job $id is not confirmed terminal." >&2; exit 2; fi
   state=''
  fi
  if [[ -n "$state" ]]; then echo "Existing $stage job/array $id is active; do not submit a duplicate."; exit 2; fi
 done < logs/submitted_ids.txt
 cp logs/submitted_ids.txt "logs/submitted_ids_$(date +%s).txt"
fi
# Standard-library-only preflight; no numerical work or installs on login nodes.
read -r tasks concurrency < <(python3 ls6/limits.py --profile "$profile" --reference "$reference" --marginals "$marginals") || { echo 'Queue preflight failed; no jobs submitted.' >&2; exit 2; }
: > logs/submitted_ids.txt
submit() {
 local stage=$1 wall=$2 cpus=$3 dep=${4:-} arr=${5:-}
 local args=(-A "${QUAKE_ACCOUNT:-DMS22021}" -p "${QUAKE_QUEUE:-normal}" -N 1 -n 1 -c "$cpus" -t "$wall" -J "quake-$stage")
 if [[ -n "$arr" ]]; then args+=(--array="$arr" -o 'logs/%x-%A_%a.out' -e 'logs/%x-%A_%a.err');else args+=(-o 'logs/%x-%j.out' -e 'logs/%x-%j.err');fi
 if [[ -n "$dep" ]]; then args+=(--dependency="$dep");fi
 local raw id
 raw=$(sbatch --parsable "${args[@]}" ls6/job.sh "$BUNDLE" "$stage" "$profile")
 id=${raw%%;*};[[ "$id" =~ ^[0-9]+$ ]] || { echo "Unexpected sbatch response: $raw" >&2; exit 2; }
 printf '%s %s\n' "$stage" "$id" >> logs/submitted_ids.txt;echo "$id"
}
setup=$(submit setup 00:30:00 1)
smoke=$(submit smoke "${QUAKE_SMOKE_WALL:-01:30:00}" 64 "afterok:$setup")
if [[ "$profile" != smoke ]]; then
 run=$(submit "$profile" "${QUAKE_WALL:-04:00:00}" 128 "afterok:$smoke" "0-$((tasks-1))%$concurrency")
 dep="afterany:$run"
 if [[ "$marginals" == 1 ]]; then marg=$(submit marginals "${QUAKE_MARGINALS_WALL:-03:00:00}" 64 "afterany:$run");dep="$dep:$marg";fi
 if [[ "$reference" == 1 ]]; then ref=$(submit reference "${QUAKE_REFERENCE_WALL:-12:00:00}" 1 "afterok:$smoke");dep="$dep:$ref";fi
 report=$(submit report 00:30:00 1 "$dep")
fi
cat logs/submitted_ids.txt
if [[ "$profile" != smoke ]]; then echo "Production array: $tasks tasks, at most $concurrency concurrently; see logs/submission_preflight.json. Every element counts toward submission limits.";fi
