#!/bin/bash
if [[ "${QUAKE_SKIP_MODULES:-0}" != 1 ]]; then
 module purge
 module load "${QUAKE_GCC_MODULE:-gcc/11.2.0}" "${QUAKE_PYTHON_MODULE:-python3/3.9.7}"
fi
export QUAKE_CPU_VENV="${QUAKE_CPU_VENV:-/work/10812/ald4435/ls6/venvs/lfgi_quake_array_cpu_py39}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 MPLBACKEND=Agg PYTHONUNBUFFERED=1 CUDA_VISIBLE_DEVICES=""

# Independent 16-query ODE solves run in parallel, with BLAS still single-threaded.
export QUAKE_CHUNK_WORKERS="${QUAKE_CHUNK_WORKERS:-8}"
