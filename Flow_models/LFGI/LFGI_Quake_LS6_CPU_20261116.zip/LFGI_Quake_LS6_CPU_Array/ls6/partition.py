"""Deterministic bounded-size, cost-balanced fit partition; no scientific inputs changed."""
import hashlib,json,math
from pathlib import Path
METHOD_COST={'joint_lfgi':40.,'conditional_lfgi':12.,'conditional_fitted_flow':2.,'conditional_t_mixture':1.2,'joint_gmm_bic':.3,'conditional_gmm_bic':.25,'conditional_gn_mixture':.1,'conditional_gaussian':.05,'warp3':.05,'joint_gaussian':.03}
def key(c):return (int(c['seed']),int(c['N']),c['method'])
def effort(c,chunks=8):
 w=METHOD_COST[c['method']]
 if c['method'] in ['joint_lfgi','conditional_lfgi']:w/=chunks
 return w*(c['N']/1024.)**(1.1 if c['method']=='joint_lfgi' else 1.)
def build(cells,count,chunks=8):
 count=min(int(count),len(cells))
 if count<1:raise ValueError('at least one array task required')
 quotas=[len(cells)//count+(i<len(cells)%count) for i in range(count)];bins=[[] for _ in range(count)];loads=[0.]*count
 for c in sorted(cells,key=lambda c:(-effort(c,chunks),key(c))):
  i=min((i for i in range(count) if len(bins[i])<quotas[i]),key=lambda i:(loads[i],len(bins[i]),i));bins[i].append(c);loads[i]+=effort(c,chunks)
 assert sorted(key(c) for b in bins for c in b)==sorted(key(c) for c in cells)
 return dict(tasks=count,chunk_workers=chunks,quotas=quotas,estimated_relative_load=loads,shards=bins,weight_scope='static relative scheduling estimates; not benchmarked LS6 runtimes')
def fingerprint(plan):return hashlib.sha256(json.dumps(plan,sort_keys=True).encode()).hexdigest()
