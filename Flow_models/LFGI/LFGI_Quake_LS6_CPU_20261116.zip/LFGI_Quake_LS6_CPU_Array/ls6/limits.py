"""Login-safe queue/headroom preflight. Capture qlimits and query live QoS when readable."""
import argparse,csv,getpass,json,os,re,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PUBLISHED_RUN=20;PUBLISHED_SUBMIT=100

def command(args,timeout=12):
 try:
  r=subprocess.run(args,universal_newlines=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout);return dict(args=args,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
 except (OSError,subprocess.TimeoutExpired) as e:return dict(args=args,returncode=-1,stdout='',stderr=str(e))
def integer(x):
 if x is None or str(x).strip().upper() in ['', 'NONE','UNLIMITED','N/A','NA']:return None
 try:return int(x)
 except ValueError:return None
def parse_labeled(text,queue):
 lines=[re.sub(r'\x1b\[[0-9;]*m','',s) for s in text.splitlines()];out={}
 for line in lines:
  if not re.search(r'(?<![\w-])'+re.escape(queue)+r'(?![\w-])',line):continue
  for k,pattern in [('run',r'(?:MaxJobsPU|MaxJobsPerUser|MaxJobs)\s*[=:]\s*(\d+)'),('submit',r'(?:MaxSubmitPU|MaxSubmitJobsPU|MaxSubmitJobs|MaxSubmit)\s*[=:]\s*(\d+)')]:
   m=re.search(pattern,line,re.I)
   if m:out[k]=int(m.group(1))
 return out
def live():
 queue=os.getenv('QUAKE_QUEUE','normal');user=os.getenv('USER') or getpass.getuser();raw={};ql=command(['qlimits']);raw['qlimits']=ql;limits=parse_labeled(ql['stdout'],queue);sources=['published LS6 normal table']
 # The actual table format of qlimits varies. Never infer limits from unlabeled numeric positions.
 partition=command(['scontrol','show','partition',queue,'-o']);raw['partition']=partition;match=re.search(r'\bQoS=(\S+)',partition['stdout'],re.I);qos=match.group(1) if match and match.group(1).upper() not in ['N/A','NONE'] else queue
 qr=command(['sacctmgr','-n','-P','show','qos',qos,'format=Name,MaxJobsPU,MaxSubmitPU']);raw['qos']=qr
 for line in qr['stdout'].splitlines():
  p=line.strip().split('|')
  if len(p)>=3 and p[0]==qos:
   for k,v in [('run',p[1]),('submit',p[2])]:
    n=integer(v)
    if n is not None:limits[k]=min(limits.get(k,n),n)
   sources.append('live QoS '+qos)
 sr=command(['squeue','-h','-r','-u',user,'-o','%i|%P|%T'])
 if sr['returncode']!=0:raise RuntimeError('Cannot verify current submitted jobs: '+sr['stderr'])
 records=[]
 for line in sr['stdout'].splitlines():
  if not line.strip():continue
  p=line.strip().split('|')
  if len(p)!=3:raise RuntimeError('Unexpected expanded squeue format: '+line)
  records.append(dict(id=p[0].strip(),queue=p[1].strip(),state=p[2].strip()))
 if queue!='normal' and not (os.getenv('QUAKE_MAX_RUNNING') and os.getenv('QUAKE_MAX_SUBMIT')):raise RuntimeError('For a non-normal queue specify QUAKE_MAX_RUNNING and QUAKE_MAX_SUBMIT from its current qlimits.')
 default_run=PUBLISHED_RUN if queue=='normal' else int(os.environ['QUAKE_MAX_RUNNING']);default_sub=PUBLISHED_SUBMIT if queue=='normal' else int(os.environ['QUAKE_MAX_SUBMIT'])
 run=min(default_run,limits.get('run',default_run),int(os.getenv('QUAKE_MAX_RUNNING',str(default_run))));sub=min(default_sub,limits.get('submit',default_sub),int(os.getenv('QUAKE_MAX_SUBMIT',str(default_sub))))
 if os.getenv('QUAKE_REQUIRE_LIVE_LIMITS','0')=='1' and not all(k in limits for k in ['run','submit']):raise RuntimeError('Live numeric limits could not be read; inspect qlimits/QoS or use the documented fallback without QUAKE_REQUIRE_LIVE_LIMITS=1.')
 # Read MaxArraySize when permitted. Twenty tasks are far below the usual configuration.
 ar=command(['scontrol','show','config']);raw['slurm_config']=ar;ma=re.search(r'\bMaxArraySize\s*=\s*(\d+)',ar['stdout']);array_cap=int(ma.group(1)) if ma else 1001
 return dict(queue=queue,max_running=run,max_submit=sub,max_array_size=array_cap,existing_submitted=len(records),existing_running=sum(r['state'] in ['RUNNING','COMPLETING','CONFIGURING'] for r in records),existing_jobs=records,limit_sources=sources,live_numeric_limits=limits,raw=raw,scope='all expanded user jobs conservatively charged against submission headroom; native Slurm still enforces other association/node/QoS limits')
def plan(profile,reference,marginals):
 r=live();overhead=2+(0 if profile=='smoke' else 1+int(marginals)+int(reference));available=r['max_submit']-r['existing_submitted']-overhead
 if profile=='smoke':
  if available<0:raise RuntimeError('Insufficient submission headroom for setup and smoke')
  r.update(tasks=0,concurrency=0,overhead=2,new_task_slots=2)
 else:
  count=10 if profile=='pilot' else len(list(csv.DictReader((ROOT/'configs/RUN_MATRIX.csv').open())));requested=int(os.getenv('QUAKE_ARRAY_TASKS','20'));tasks=min(requested,count,available,r['max_array_size']);cap=min(r['max_running']-int(reference),int(os.getenv('QUAKE_ARRAY_CONCURRENCY',str(r['max_running']))),tasks)
  if tasks<1 or cap<1:raise RuntimeError('Insufficient queue headroom; wait for current jobs or choose fewer helper stages. No job submitted.')
  r.update(tasks=tasks,concurrency=cap,overhead=overhead,new_task_slots=tasks+overhead,total_fits=count,requested_array_tasks=requested)
 r['profile']=profile;r['captured_at']=time.time();return r
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--profile',choices=['production','pilot','smoke'],required=True);p.add_argument('--reference',type=int,default=0);p.add_argument('--marginals',type=int,default=1);a=p.parse_args();r=plan(a.profile,bool(a.reference),bool(a.marginals));(ROOT/'logs').mkdir(exist_ok=True);(ROOT/'logs/submission_preflight.json').write_text(json.dumps(r,indent=2));print(r['tasks'],r['concurrency'])
