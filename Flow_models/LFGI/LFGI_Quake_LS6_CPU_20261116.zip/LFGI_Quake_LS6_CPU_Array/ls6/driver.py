import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
import argparse,sys,json,time,subprocess,resource,platform
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'code'))
from common import read,write,sha,source_sha
from campaign import METHODS,environment
from partition import build,fingerprint

def check():
 for relative,digest in read(B/'provenance/IMMUTABLE_SHA256.json').items():
  if sha(B/relative)!=digest:raise RuntimeError('Frozen input/source hash mismatch: '+relative)
 return environment()
def launch(c,label,count=None,repeats=None,quick=False,retry=False):
 d=B/'results'/label/f"seed{c['seed']}/N{c['N']}"/c['method'];d.mkdir(parents=True,exist_ok=True);args=[sys.executable,str(B/'code/campaign.py'),'cell','--seed',str(c['seed']),'--N',str(c['N']),'--method',c['method'],'--label',label]
 if count:args+=['--count',str(count)]
 if repeats:args+=['--repeats',str(repeats)]
 if quick:args+=['--quick']
 if retry:args+=['--retry-failed']
 with (d/'worker.log').open('a') as f:r=subprocess.run(args,cwd=B,stdout=f,stderr=subprocess.STDOUT)
 path=d/'status.json';s=read(path)['status'] if path.exists() else 'INCOMPLETE';return dict(**c,returncode=r.returncode,status=s)
def smoke():
 env=check();subprocess.run([sys.executable,str(B/'tests/task_routing.py')],cwd=B,check=True);subprocess.run([sys.executable,str(B/'tests/orchestration.py')],cwd=B,check=True);subprocess.run([sys.executable,str(B/'tests/parallel_chunks.py')],cwd=B,check=True);subprocess.run([sys.executable,str(B/'tests/verify.py')],cwd=B,check=True);subprocess.run([sys.executable,str(B/'tests/pilot_regression.py')],cwd=B,check=True);label='smoke_'+os.getenv('SLURM_JOB_ID',str(int(time.time())));records=[]
 # Every competitor adapter, fitting/serialization, sampling and bridge root.
 for m in METHODS:
  r=launch(dict(seed=101,N=64,method=m),label,count=8,repeats=1,quick=True);records.append(r)
  if r['returncode'] or r['status']!='COMPLETE':raise RuntimeError('Native smoke failed: '+str(r))
 # Full bank and chunk size for memory/ODE portability of both numerical models.
 for m in ['conditional_lfgi','joint_lfgi']:
  r=launch(dict(seed=101,N=1024,method=m),label+'_full',count=32,repeats=1);records.append(r)
  if r['returncode'] or r['status']!='COMPLETE':raise RuntimeError('Full-bank smoke failed: '+str(r))
 # Same frozen-law roundtrip of one generated point, independent evaluation.
 from campaign import paths
 import pickle,numpy as np
 for m in ['conditional_lfgi','joint_lfgi']:
  c=dict(seed=101,N=1024,method=m);d=paths(c,label+'_full')
  with (d/'model.pkl').open('rb') as f:model=pickle.load(f)
  a=np.load(d/'repeat00.npz');lq=model.logq(a['proposal'][:2],tag='independent_roundtrip');err=float(np.max(abs(lq-a['logq'][:2])));assert err<1e-3,(m,err)
 peak=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss*1024
 import psutil
 workers=max(1,min(32,int(.7*psutil.virtual_memory().total/max(2*peak,1024**3))))
 gate=dict(orchestration_sha256=sha(Path(__file__)),chunk_workers=int(os.getenv('QUAKE_CHUNK_WORKERS','1')),passed=True,source_sha256=source_sha(),environment=env,native_host=platform.node(),job=os.getenv('SLURM_JOB_ID'),max_process_RSS_bytes=peak,recommended_workers=workers,records=records,note='memory gate has factor-two RSS headroom and 30% node reserve; timing is not a ranking');write(B/'logs/smoke_passed.json',gate)
def production(profile,retry=False,task_index=None,task_count=None):
 env=check();gate=read(B/'logs/smoke_passed.json');assert gate['passed'] and gate['source_sha256']==source_sha() and gate['environment']==env,'Native smoke binding mismatch'
 jobs=read(B/'prepared/cells.json');label=profile
 if profile=='pilot':jobs=[c for c in jobs if c['seed']==101 and c['N']==1024]
 assert gate.get('orchestration_sha256')==sha(Path(__file__)),'Orchestration changed after smoke'
 chunks=int(os.getenv('QUAKE_CHUNK_WORKERS','8'));assert gate.get('chunk_workers')==chunks,'Chunk parallelism differs from native smoke'
 count=task_count or int(os.getenv('SLURM_ARRAY_TASK_COUNT','1'));index=task_index if task_index is not None else int(os.getenv('SLURM_ARRAY_TASK_ID','0'))
 plan=build(jobs,count,chunks);assert 0<=index<count;plan_id=fingerprint(plan)
 jobs=plan['shards'][index];write(B/f'logs/{profile}_task{index:02d}_partition_{plan_id[:12]}.json',plan)
 workers=min(int(os.getenv('QUAKE_WORKERS','8')),len(jobs),gate['recommended_workers'],max(1,len(os.sched_getaffinity(0))//chunks))
 if workers<1:raise ValueError('workers must be positive')
 records=[]
 with ThreadPoolExecutor(max_workers=workers) as pool:
  fs=[pool.submit(launch,c,label,128 if profile=='pilot' else None,1 if profile=='pilot' else None,False,retry) for c in jobs]
  for f in as_completed(fs):
   records.append(f.result());write(B/f'logs/{profile}_task{index:02d}_progress.json',dict(task=index,tasks=count,partition=plan_id,expected=len(jobs),workers=workers,chunk_workers=chunks,records=records));print(records[-1],flush=True)
 if any(r['returncode'] or r['status']!='COMPLETE' for r in records):raise RuntimeError('Retained failed/incomplete cells; inspect per-cell logs')
def reference():
 check()
 for n,m,seeds in [(4096,10,[501,502,503]),(8192,20,[601,602,603])]:
  for seed in seeds:subprocess.run([sys.executable,str(B/'code/reference_smc.py'),'--n',str(n),'--moves',str(m),'--seed',str(seed)],check=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('stage',choices=['check','prepare','smoke','pilot','production','reference','report','marginals']);p.add_argument('--profile',default='production',choices=['production','pilot']);p.add_argument('--retry-failed',action='store_true');p.add_argument('--task-index',type=int);p.add_argument('--task-count',type=int);a=p.parse_args()
 if a.stage=='check':print(check())
 elif a.stage=='prepare':
  check();from campaign import prepare;prepare()
 elif a.stage=='smoke':smoke()
 elif a.stage in ['pilot','production']:production(a.stage,a.retry_failed,a.task_index,a.task_count)
 elif a.stage=='reference':reference()
 elif a.stage=='marginals':
  from marginals import run;run(a.profile,implicit=True)
 else:
  from report import report;report(a.profile)
