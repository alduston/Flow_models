# Validation and remaining scope

The delivery is an executable campaign, not the previous planning scaffold. Local tests cover all ten adapters, the actual bridge root, normalized conditional Student-t identities, fitted-flow training gradients/inverses/Jacobians, both GN probability-flow fields, zero-target proposal support, independent conditional density regression, checkpoint recovery and strict identity rejection, Slurm dependency/duplicate protection, Python-3.9 syntax, report aggregation, and optional SMC controls.

The full local smoke also fits/evaluates both LFGI models at N=1024 with a full 16-query chunk and checks independent generation/evaluation round trips. A separate test fits the conditional Student-t and fitted-flow methods at N=256 using their full fitting recipes. The saved original conditional-LFGI pilot densities at states 0,17,124 are reproduced to about 3.1e-7. The native C++ divergence trace agrees with complex-step differentiation and Gaussian score cancellation to floating-point accuracy. These are checks of implementations and numerical correspondence, not evidence that any method wins production.

The optional SMC engine is checked on a known Gaussian integral and a small quake execution. Small-particle quake evidence can be poor; every reference output remains PROVISIONAL. Six optional production reference runs at two particle/move settings must be assessed for consistency and mixing before any evidence-error claim. No exact quake normalizer is supplied.

The main campaign is conditioned on one archived posterior dataset. The five bank seeds are not five new independent posterior-inference runs. Proposal repeats are not extra independent fitting banks. Bootstrap summaries resample bank means, and separate within-fit variability comes from proposal repeats. Chain/reference uncertainty and the trustworthiness of the archived NUTS reference remain distinct.

The package has **not** run on LS6 here. Its setup uses the prior working acoustic bundle's module/venv conventions, and the batch DAG enforces native setup and smoke before production. Local NumPy/SciPy/sklearn versions differ from the pinned Python-3.9 wheels. No remote job has been submitted by the assistant. The local smoke gate itself is not shipped as an LS6 pass.

There is no automatic claim that a fitted conditional flow is optimally tuned. The explicit validation-selected grid, restarts and all fitting cost are reported. Warp-U, exact-Hessian ablations and a calibrated absolute quake evidence RMSE remain outside this main matrix. The preserved handoff plan notes contain historical pending statuses; current README/config/source and the machine-readable validation record take precedence.


## Array revision

Adds disjoint bounded-size cost partitioning, live QoS/expanded-job headroom checks, array-parent dependencies, distinct per-task progress files and independent per-chunk ODE parallelism. Tests cover all 150 cells with no omissions/duplication, exact 7/8-cell quotas for 20 tasks, optional reference slot reservation, reduced live limits/headroom, duplicate submissions, and correct marginal-stage dispatch. Parallel chunk outputs and divergence integrals match serial outputs bitwise on a real conditional field, with the same row grouping/checkpoint math. Local timing is not an LS6 cost prediction. The current full smoke is recorded in provenance; native LS6 execution remains unperformed here.
