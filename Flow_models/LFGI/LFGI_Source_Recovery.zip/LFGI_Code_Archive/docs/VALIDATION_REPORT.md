# Executed validation

All experiment runs below are small wiring checks. They are not publication results. The Darcy check uses an explicitly scaled grid.

| Family | Exit code | Seconds |
|---|---:|---:|
| darcy_scaled | 0 | 25.4 |
| funnel | 0 | 8.1 |
| gate_sweep | 0 | 28.4 |
| gaussian | 0 | 6.1 |
| gmm24 | 0 | 6.8 |
| gmm8 | 0 | 5.4 |
| misaligned | 0 | 5.6 |
| mixture | 0 | 7.5 |
| pole_audit | 0 | 5.4 |

## Independent numerical checks

- Maximum Gaussian score cancellation error, arbitrary one-atom and split banks: 2.9e-13.
- Maximum shared-bank analytic divergence error against finite differences: 4.49e-11.
- Maximum split-bank analytic divergence error: 6.82e-11.
- Gaussian PF log-density RMSE under integration refinement:

| Steps | RMSE |
|---:|---:|
| 32 | 0.0129026 |
| 64 | 0.00261173 |
| 128 | 0.000618878 |

The comparison uses the positive-cutoff Gaussian marginal; the Gaussian terminal base leaves a small finite-horizon mismatch.

## Historical data consistency

- Recomputed gate-sweep mean/SD columns agree with their recovered summaries to floating-point precision.
- Recomputed pole-audit rates agree with the recovered summary (3072 queries over 6 times).
- Darcy stored log ratios, target energies and negative log densities obey their defining array identities.
- The recovered table aggregator successfully processes the authentic June 11 single-run density CSVs.
- Historical arrays and new synthetic sample clouds were successfully redrawn; the resulting PNGs were inspected.

## Limits

The final five-seed production results were not rerun. Historical variants were syntax/hash checked, not all executed. The November extension campaign was not rerun. Scientific equivalence of a recovered code family does not establish equality with an unrecovered production run.
