# Environments

## Recovered June production log

The June 19 Darcy parameter record reports Python 3.11.8 on Linux aarch64, NumPy 2.4.3, pandas 3.0.2, Torch 2.11.0+cu126, JAX 0.10.0 and CUDA. The unchanged log is preserved in `provenance/historical_documents/`. This is evidence for that recorded Darcy run, not a complete environment specification for every paper experiment.

## Archive validation

The archive was validated on Linux x86_64 with Python 3.12 and CPU PyTorch/JAX. Exact observed package versions are in `provenance/validation_environment.json`. The general requirements file gives minimum API requirements; it does not claim bitwise cross-platform reproducibility.

The canonical synthetic/validation engines use PyTorch, NumPy, SciPy, scikit-learn and matplotlib. Inverse scripts additionally use JAX and pandas. The November extension uses NumPy/SciPy/matplotlib. Optional POT supports additional transport metrics outside the primary reconstructed recipe. No remote jobs were launched.

CPU checks limit BLAS/OpenMP threads to one. Increase thread counts deliberately for full campaigns, and record any new settings. For CUDA use a suitable PyTorch build; for accelerated PDE derivatives use a suitable JAX build. The checks in this archive do not measure cluster runtime or GPU performance.
