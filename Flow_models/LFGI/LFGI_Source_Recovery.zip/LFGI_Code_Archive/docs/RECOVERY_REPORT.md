# Recovery report

## Scope and method

The recovery covered the currently accessible workspace and persistent files concentrated in May–June 2026, with attention to the June 23 submission and July 1 revision. Filename/date searches were followed by downloading and inspecting code, imports, entry points, emitted filenames and numerical settings. Historical conversation retrieval supplied additional run-command and source-name leads. No old transient June workspace could be recovered directly from the currently mounted scratch directories.

The decisive files are the June 20 uniform-blend versions of the synthetic benchmark, validation sweep, inverse sampling module, Darcy script and three known-Z calibrations. A June 23 submission TeX file was also recovered. It differs from the supplied current source only in Tan's hyphenated name and one score-figure width setting. This strongly anchors the recovered code generation period to the current paper, but it does not recover missing production outputs.

Every consolidated recovered file has an original name, SHA-256 and source metadata in `provenance/recovered_files.json`. Content duplicates are identified and stored once. Canonical filenames are normalized for portable imports; file contents are preserved unchanged. Earlier variants remain in the historical directory. No original experiment engine had to be recreated from scratch.

## Recovered

- Six-estimator synthetic comparison engine, target definitions, reverse sampler, score RMSE and distributional metrics, plotting, repeated-run aggregation and funnel pole audit.
- Reference-bank metric sweep and gate-capture sweep, with both older and uniform-method variants.
- Shared target-derivative caching, GN/LFGI score, probability-flow density, analytic divergence, comparison estimators and density metrics.
- Darcy forward model, acquisition/prior construction, source/evaluation bank wiring and plotting.
- Linear-Gaussian, shared-curvature mixture and misaligned-curvature mixture analytic known-Z experiments.
- Density/known-Z table aggregation utilities.
- Authentic May gate/metric sweep CSVs, June funnel pole-audit data, June 11 Darcy density NPZ arrays and scalar summaries, and some older aggregate diagnostics.
- Supplied current manuscript/bibliography/all figure assets, plus the recovered near-identical submission TeX.
- A separate November Pearson-control code/data extension already included in the supplied material.

The original notebooks were not recovered as `.ipynb` files. Some recovered scripts retain Colab-export headers and original notebook URLs. These headers are provenance, not a dependency of the portable archive.

## Reconstructed

- A portable CLI with isolated output directories, explicit recipes, logs and exit status.
- A synthetic driver using unchanged recovered functions, adding saved sample clouds and machine-readable per-run metrics.
- Seed initialization before recovered inverse scripts and an explicitly scaled Darcy CPU check.
- Independent plots from recovered arrays and new sample arrays.
- Automatic export of manuscript table cells, labelled reported-only.
- Integrity and independent numerical checks, documentation and the figure/table mapping.

These files are dated by this recovery and live outside the recovered source directories. None is represented as original production code.

## Unrecovered production inputs

| Missing item | Available replacement |
|---|---|
| Final five-seed GMM8/GMM24/funnel metric runs | Original engine; reconstructed manuscript-setting recipes; new small executed examples |
| Current histogram sample clouds and exact postprocessing edits | Original plotting functions and current PNG assets; new driver saves clouds for exact future redraws |
| Uniform-method score-count sweep arrays | Uniform-method sweep engine; older four-method raw sweep kept separately |
| Exact final gate-figure data/configuration | Gate engine and authentic earlier raw sweep; exact current-asset linkage not established |
| June 19 Darcy raw density arrays | June 19 parameter log; June 11 raw arrays; later Darcy engine |
| Final known-Z per-seed outputs | All three original problem scripts and shared density engine; reported TeX table cells |
| Full six-method late Darcy aggregate raw runs | Older aggregates and current reported table, clearly distinguished |

These are source/data gaps, not excuses to substitute numbers. The supplied figure PNGs remain available for comparison. The archive can generate new results, but does not certify old table values simply because the same code family was found.

## Validation performed

All canonical families were executed locally with deliberately reduced sizes: six-method synthetic runs on GMM8, GMM24 and the funnel; the score/gate sweep; funnel pole audit; all three analytic inverse problems; and the Darcy pipeline on an 8x8 grid with four parameters. Logs and recipes are in `validation_runs/`. Full publication-scale campaigns were not rerun.

Independent checks use arbitrary Gaussian reference banks (including one atom and split banks), nonconstant positive Hessians for divergence finite-difference checks, and Gaussian probability-flow likelihood refinement. Machine-readable errors and pass/fail status are in `validation_runs/numerical_checks.json`.

Historical arrays were successfully replotted without running a model. Saved samples from the new synthetic driver were also replotted. The supplied paper tables were automatically exported as summaries. Syntax and hash checks cover the complete consolidated source archive; only canonical entry points and numerical checks were execution-tested.
