# Current-paper result map

The exact supplied assets and their hashes are listed in `provenance/paper_figures.csv`. An engine match means its target, estimator and emitted result family match the paper; it does not imply the exact final data or plotting edits were recovered.

| Current result | Recovered code | Data status / regeneration |
|---|---|---|
| `Figs/score_rmse_by_t.png` (caption is a bank-count sweep) | `recovered/validation/claim_validation_sweep.py`, metric sweep / `time_avg_score_rmse` | Older raw sweep recovered; final six-method arrays missing. `run_experiment.py validation` regenerates the family. |
| `Figs/gate_figs/frobenius_capture_04.png` | Same engine, gate sweep | Earlier May 29 raw and aggregate CSVs recovered; exact current plot linkage unverified. |
| `Figs/gate_figs/frobenius_capture_08.png` | Same engine, gate sweep | Same status; t=0.08. |
| `Figs/gate_figs/frobenius_capture_16.png` | Same engine, gate sweep | Same status; t=0.16. |
| `Figs/gate_figs/risk_capture_04.png` | Same engine, risk-weighted gate diagnostics | Earlier raw data recovered; current version linkage unverified. |
| `Figs/gate_figs/risk_capture_08.png` | Same engine, risk-weighted gate diagnostics | Same status; t=0.08. |
| `Figs/gate_figs/risk_capture_16.png` | Same engine, risk-weighted gate diagnostics | Same status; t=0.16. |
| `Figs/gmm8_heatmap.png` | `recovered/synthetic/benchmark_sweep.py`: `run`, `plot`, misaligned GMM rank 3 | Current PNG and an earlier June PNG recovered; final cloud missing. New driver saves raw clouds. |
| `Figs/gmm24_heatmap.png` | Same benchmark: rank 4, d=24 | Same status. |
| `Figs/funnel_heatmaps.png` | Same benchmark: `FunnelTarget`, plotting | Same status; raw pole-audit data separately recovered. |
| `Figs/darcy_density_array.png` | `recovered/inverse/darcy_flow.py` plus shared `sampling_uniform_blends.py` comparison-grid functions | June 19 parameter log and June 11 density arrays recovered; exact later arrays missing. |

| Numerical table label | Source / status |
|---|---|
| `tab:misaligned-gmm-d8-results` | Synthetic engine and aggregation recovered. Final five-run raw metrics missing. |
| `tab:misaligned-gmm-d24-results` | Same. |
| `tab:funnel-d10-results` | Same; score error is a high-reference proxy. |
| `tab:darcy-density-results` | Darcy + shared helper + `recovered/aggregation/aggregate_tables.py`. Historical multi-run summaries differ from the final table. |
| `tab:known-z-gaussian-calibration` | `recovered/inverse/known_z_gaussian.py` plus shared helper; raw final runs missing. |
| `tab:known-z-mixture-calibration` | `recovered/inverse/known_z_shared_mixture.py` plus shared helper; raw final runs missing. |
| `tab:known-z-misaligned-mixture-calibration` | `recovered/inverse/known_z_misaligned_mixture.py` plus shared helper; raw final runs missing. |
| `tab:funnel-pole-audit-summary` | Synthetic pole-audit implementation and authentic raw/summary CSVs recovered. Summary agrees with the manuscript's cited diagnostics at reported precision. |

Notation and estimator-definition tables are manuscript text, not experimental data. All ten table environments, including these two, have reported-cell CSV exports under `data/paper_reported/`.
