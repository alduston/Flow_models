# Reproduction qualifications and scientific conventions

## Provenance levels

1. `recovered_unchanged`: exact recovered bytes, with renamed paths recorded in provenance.
2. `recovered_historical_data`: genuine outputs, not necessarily the final production run.
3. `reported_cells_only`: table summaries extracted from the manuscript, not per-seed observations.
4. `reconstructed_recipe` or `reconstructed_tool`: new orchestration/plotting/validation written during recovery.
5. `new_smoke_output`: newly executed small runs, not evidence reproducing published values.

## Configuration differences to retain

- The synthetic engine defaults to a lower `t_min` than the paper, and its source `paper_sweep` includes rings. The CLI explicitly supplies the paper's 0.01 cutoff and selects only the three current targets.
- The manuscript reports five synthetic seeds 42–46. A retrieved historical uniform-blend command requested seven runs. Both are documented; neither should silently replace the other.
- The validation-sweep engine has its own settings and ridge convention; these are not the fixed-budget synthetic sampler settings. The runner's paper validation recipe uses the recovered sweep defaults because its final invocation was not found.
- Recovered raw metric sweeps predate spatially uniform methods and contain different metric values/settings from the fixed-budget main tables. Uniform rows cannot be reconstructed from these data alone.
- Some recovered Darcy aggregates combine 12 or 21 runs and differ from the paper's five-run results. Keep them as historical diagnostics. The June 11 density arrays contain 2,000 evaluations, whereas the paper describes 1,000 evaluations per later run.
- The recovered Darcy default robust band is 4–96%; the later parameter log and current manuscript use 3–97%. The CLI explicitly sets 3–97%.
- The inverse helper uses a positive precision floor in its CE/GN gate eigenbasis. The synthetic raw-Hessian engine is a different implementation. Preserve the distinction, especially for indefinite curvature.
- The GMM code computes the marginal Hessian as responsibility-weighted component precision minus covariance of component scores. Positive component precisions do not by themselves imply the marginal Hessian is PSD. This is a manuscript/theory alignment item for the next revision, not silently repaired here.

## Density/evidence conventions

- Analytic inverse likelihoods omit observation Gaussian normalization constants. The exact `TRUE_LOGZ` follows that same convention.
- The existing known-Z tables report density/log-ratio diagnostics on held-out posterior draws. The inherited `known_logZ_abs_error` is based on a posterior-average log ratio; it is **not** an optimal bridge estimate or an unbiased Monte Carlo evidence estimator. The newer bridge comparisons belong to the next experiment phase.
- A PF density is normalized for the exact invertible continuous flow. The stored implementation approximates that density numerically. Finite terminal initialization, positive low-time cutoff, divergence estimation and integration error remain distinct.
- The recovered inverse helper internally floors `t_min` at 1e-4 during PF evaluation. The current paper's 10^-2.5 cutoff lies above that floor.
- Synthetic final denoising is a sampling convention and is not a free invertible completion of the density flow.
- Split banks are part of the recorded estimator setup; slicing an autocorrelated chain is not the same as drawing independent banks. This archive preserves the original wiring without claiming an independence theorem for MCMC data.

## Reconstructed launchers

The canonical inverse scripts execute at top level; importing them launches an experiment. Use the runner, not an import, unless intentionally executing. The synthetic and validation engines are safe to import for their functions and classes. The runner writes to the requested output directory rather than the source tree and records every override. Historical variants are retained for comparison, not automatically imported.

The Darcy smoke wrapper changes only five top-level constants in an in-memory AST: grid 32→8, KL modes 100→16, observations 120→12, holdout observations 30→6, and parameters 32→4. It preserves the original file and writes the exact change record. This validates the pipeline on the same PDE family; it does not reproduce the full inverse problem.

The reconstructed seed wrapper initializes Python, NumPy and Torch before the inverse script. Darcy subsequently resets NumPy to its fixed acquisition seed; Torch sampling still uses the requested run seed. The known-Z scripts have separate fixed problem and stochastic run seeds.
