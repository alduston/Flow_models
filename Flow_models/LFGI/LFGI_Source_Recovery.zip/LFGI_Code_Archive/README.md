# LFGI code recovery archive

Source recovery for **Laplace–Fisher Gate Identities for Optimal Matrix-Gated Blended Score Estimation**, arXiv:2606.25169. Consolidated 13 November 2026 for the submission revision.

The main experiment engines were recovered. Missing orchestration, raw-sample export, portable run recipes, and independent replotting tools were reconstructed. This is a tested source archive, **not a claim that the final five-seed paper tables have been numerically reproduced**. Some recovered raw data comes from earlier experiments. See [the result map](docs/FIGURE_TABLE_MAP.md) before using an artifact.

## Start here

| Directory | Contents |
|---|---|
| `recovered/synthetic/` | Unchanged June 20 benchmark engine: GMM8, GMM24, funnel, estimator comparisons, samplers, metrics and plots |
| `recovered/validation/` | Unchanged reference-count and gate-capture sweep engine |
| `recovered/inverse/` | Unchanged shared sampling/PF-density module, Darcy, and all three analytic known-Z scripts |
| `recovered/aggregation/` | Unchanged density/evidence table aggregator |
| `recovered/historical/` | Distinct earlier source versions and contextual iterative experiments; not the recommended entry points |
| `reconstructed/` | New orchestration, seeding and explicitly scaled Darcy smoke check |
| `scripts/` | New portable runner, raw-data replotter, table exporter and integrity checker |
| `data/recovered/` | Authentic historical CSV/NPZ data, including gate sweeps, Darcy arrays and funnel pole audit |
| `data/paper_reported/` | Table cells extracted from the supplied TeX; summary values, not raw runs |
| `paper_snapshot/` | Supplied manuscript, bibliography and all 11 referenced figure assets |
| `validation_runs/` | Small executed checks, logs, recipes, metrics, sample arrays and example redraws; not publication runs |
| `extensions/pearson_control/` | Separate recovered November theory experiments; not the source of the current paper's figures |
| `provenance/` | Original names, creation dates, source identifiers, hashes, deduplication record and figure inventory |

Canonical recovered files are byte-for-byte copies under portable names. The provenance index records each original filename. Duplicate content is stored once. The optional historical directory preserves scientifically distinct versions rather than silently replacing the June implementation with newer code.

## Install

Use Python 3.11 or 3.12. For a CPU environment:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
```

For GPU use, install appropriate PyTorch and JAX builds for that machine. The recorded June production environment and the CPU environment actually used to validate this archive are documented separately in [ENVIRONMENT.md](docs/ENVIRONMENT.md). No notebook session, Colab mount, remote account or cluster connection is required for the portable entry points.

## Quick validation

Run from the repository root:

```bash
python scripts/check_integrity.py
python tests/verify_numerics.py --output outputs/numerical_checks.json
python tests/verify_recovered_data.py --output outputs/recovered_data_checks.json
python scripts/run_experiment.py validation --profile smoke --output outputs/gate_sweep
python scripts/run_experiment.py synthetic --profile smoke --target gmm8 --output outputs/gmm8
python scripts/run_experiment.py gaussian --profile smoke --output outputs/gaussian
```

Other available families are `synthetic --target gmm24`, `synthetic --target funnel`, `pole_audit`, `mixture`, `misaligned`, and `darcy`. `darcy --profile smoke` deliberately changes the PDE grid and observation/parameter counts; its transformation is recorded in `scaled_darcy_manifest.json`. `darcy --profile paper` uses the original full-size problem.

Each runner invocation saves `recipe.json`, `run.log` and `exit_status.json`. Synthetic runs additionally save raw clouds (`samples.npz` plus `sample_keys.json`) and per-run/aggregate metrics. Use `--dry-run` to print a recipe without executing. `--env KEY=VALUE` provides explicit overrides. `--runs` applies to synthetic experiments; invoke inverse experiments separately with `--seed`.

## Paper-scale regeneration

These recipes reconstruct the manuscript's stated setup; they are not recovered original shell invocations and do not guarantee identical numeric output on another platform.

```bash
python scripts/run_experiment.py synthetic --profile paper --target all --runs 5 --seed 42 --device cuda --plots --output outputs/paper_synthetic
python scripts/run_experiment.py validation --profile paper --device cuda --output outputs/paper_validation
python scripts/run_experiment.py gaussian --profile paper --seed 42 --plots --output outputs/known_z_gaussian_s42
python scripts/run_experiment.py mixture --profile paper --seed 42 --plots --output outputs/known_z_mixture_s42
python scripts/run_experiment.py misaligned --profile paper --seed 42 --plots --output outputs/known_z_misaligned_s42
python scripts/run_experiment.py darcy --profile paper --seed 42 --plots --output outputs/darcy_s42
```

Repeat inverse families with seeds 43–46 for five-run summaries. Darcy's acquisition seed is hard-coded to 42 in the recovered source; the reconstructed launcher sets Torch sampling seeds, preserving the fixed acquisition. `validation --profile paper` uses the recovered sweep defaults (see the saved recipe and source). Some exact June sweep run settings remain unrecovered. For the seven-run uniform-blend command described in the historical conversation, use synthetic `--runs 7`; the current manuscript specifies five runs.

The source-level synthetic root mode `paper_sweep` also includes a rings target no longer in the current main experiments. The portable `--target all` deliberately selects only GMM8, GMM24 and the funnel. The wrapper disables auxiliary curl/copying/stationarity calculations unless overridden; core score and table metrics remain enabled. Consult [REPRODUCTION_NOTES.md](docs/REPRODUCTION_NOTES.md) for metric and configuration qualifications.

## Redraw and reaggregate

```bash
python scripts/replot.py historical --output outputs/historical_redraws
python scripts/replot.py samples --samples outputs/gmm8/misaligned_subspace_gmm_d8/seed_42/samples.npz --output outputs/gmm8_redraw
python scripts/export_manuscript_tables.py
python recovered/aggregation/aggregate_tables.py --help
```

Historical redraws use authentic recovered arrays and are explicitly dated. They do not recreate missing uniform-method rows from older four-method data. The historical Darcy redraw uses the June 11 arrays, not the later June 19 displayed run. None of these tools reads values back from raster plots.

## What is still missing

The exact raw five-seed synthetic/known-Z production runs, the late uniform-blend sweep arrays, the exact raw clouds behind the current histogram PNGs, and the June 19 Darcy density arrays were not located. Their engines are recovered and runnable. Reported table cells and original figures are preserved as reference artifacts. See [RECOVERY_REPORT.md](docs/RECOVERY_REPORT.md) for the search scope, remaining gaps and completed checks.

No software license has been inferred or added to the recovered source. Existing attribution and source comments are preserved.
