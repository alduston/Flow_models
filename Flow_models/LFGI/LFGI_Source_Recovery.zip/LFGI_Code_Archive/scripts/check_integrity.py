#!/usr/bin/env python3
"""Verify unchanged recovered bytes, Python syntax, and the archive checksum list."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--refresh',action='store_true')
    a=p.parse_args()
    records=json.loads((ROOT/'provenance/recovered_files.json').read_text())
    failures=[]
    for r in records:
        path=ROOT/r['archive_path']
        if not path.is_file() or sha(path)!=r['sha256']:
            failures.append(r['archive_path'])
    files=[p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name!='SHA256SUMS']
    for path in files:
        if path.suffix=='.py':
            try:ast.parse(path.read_text(),filename=str(path.relative_to(ROOT)))
            except SyntaxError as e:failures.append(f'{path.relative_to(ROOT)}:{e.lineno}: {e.msg}')
    manifest=ROOT/'SHA256SUMS'
    if a.refresh and not failures:
        manifest.write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT).as_posix()}\n' for p in sorted(files)))
    elif manifest.exists():
        for line in manifest.read_text().splitlines():
            expected,name=line.split('  ',1);path=ROOT/name
            if not path.is_file() or sha(path)!=expected:failures.append(name)
    result={'status':'passed' if not failures else 'failed','recovered_entries':len(records),
            'unique_recovered_files':len({r['archive_path'] for r in records}),
            'python_files_parsed':sum(p.suffix=='.py' for p in files),'failures':failures}
    print(json.dumps(result,indent=2))
    if failures:raise SystemExit(1)

if __name__=='__main__':main()
