#!/usr/bin/env python3
"""Generate the validation report from saved executed-run records."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
runs=ROOT/'validation_runs'
rows=[]
for path in sorted(runs.glob('*/exit_status.json')):
    status=json.loads(path.read_text());recipe=json.loads(path.with_name('recipe.json').read_text())
    rows.append({'family':path.parent.name,**status,'profile':recipe['profile']})
numeric=json.loads((runs/'numerical_checks.json').read_text())
data=json.loads((runs/'recovered_data_checks.json').read_text())
summary={'runs':rows,'numerical_checks':numeric,'historical_data_checks':data,
         'full_paper_campaign_rerun':False}
(runs/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
text=['# Executed validation','',
      'All experiment runs below are small wiring checks. They are not publication results. The Darcy check uses an explicitly scaled grid.','',
      '| Family | Exit code | Seconds |','|---|---:|---:|']
text += [f"| {r['family']} | {r['exit_code']} | {r['seconds']:.1f} |" for r in rows]
text += ['', '## Independent numerical checks','',
         f"- Maximum Gaussian score cancellation error, arbitrary one-atom and split banks: {numeric['gaussian_arbitrary_bank_max_abs_error']:.3g}.",
         f"- Maximum shared-bank analytic divergence error against finite differences: {numeric['divergence_vs_finite_difference_max_abs_error']['shared']:.3g}.",
         f"- Maximum split-bank analytic divergence error: {numeric['divergence_vs_finite_difference_max_abs_error']['split']:.3g}.",
         '- Gaussian PF log-density RMSE under integration refinement:', '',
         '| Steps | RMSE |','|---:|---:|']
text += [f'| {k} | {v:.6g} |' for k,v in numeric['gaussian_pf_log_density_rmse_by_steps'].items()]
text += ['', 'The comparison uses the positive-cutoff Gaussian marginal; the Gaussian terminal base leaves a small finite-horizon mismatch.',
         '', '## Historical data consistency','',
         '- Recomputed gate-sweep mean/SD columns agree with their recovered summaries to floating-point precision.',
         f"- Recomputed pole-audit rates agree with the recovered summary ({data['funnel_audit_rows']} queries over {data['funnel_audit_summary_rows']} times).",
         '- Darcy stored log ratios, target energies and negative log densities obey their defining array identities.',
         '- The recovered table aggregator successfully processes the authentic June 11 single-run density CSVs.',
         '- Historical arrays and new synthetic sample clouds were successfully redrawn; the resulting PNGs were inspected.',
         '', '## Limits','',
         'The final five-seed production results were not rerun. Historical variants were syntax/hash checked, not all executed. The November extension campaign was not rerun. Scientific equivalence of a recovered code family does not establish equality with an unrecovered production run.','']
(ROOT/'docs/VALIDATION_REPORT.md').write_text('\n'.join(text))
print(json.dumps({'families':len(rows),'failed':sum(r['exit_code']!=0 for r in rows)},indent=2))
