#!/usr/bin/env python3
"""Reconstructed plots from authentic recovered arrays or new saved runs.

Recovered-data plots are historical redraws, not byte-identical current-paper
figures. No curves, error bars, or sample clouds are digitized from images.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

ROOT=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'pdf.fonttype':42,'savefig.dpi':180})

def save(fig,out,name):
    fig.savefig(out/(name+'.pdf'),bbox_inches='tight')
    fig.savefig(out/(name+'.png'),bbox_inches='tight')
    plt.close(fig)

def sweeps(out):
    folder=ROOT/'data/recovered/sweeps'
    df=pd.read_csv(folder/'gate_sample_complexity_raw.csv')
    methods={'centered-regression':'Matrix Blend','lfgi-hessian':'LFGI'}
    times=sorted(df.t.unique())
    fig,axes=plt.subplots(2,len(times),figsize=(4*len(times),6.4),squeeze=False,layout='constrained')
    for j,t in enumerate(times):
        for i,(metric,label) in enumerate([('fro_relative_mean','Relative Frobenius error'),
                                           ('risk_weighted_rel_to_D_trace','Excess risk / trace(D)')]):
            ax=axes[i,j]
            for method,name in methods.items():
                groups=df[(df.t==t)&(df.gate_estimator==method)].groupby('n_gate')[metric]
                x=groups.agg(['mean','std'])
                mean=x['mean'].to_numpy()
                low=groups.quantile(.16).to_numpy();high=groups.quantile(.84).to_numpy()
                line=ax.plot(x.index,mean,'o-',label=name)[0]
                ax.fill_between(x.index,low,high,color=line.get_color(),alpha=.15)
            ax.set(xscale='log',yscale='log',xlabel='Gate-bank size',ylabel=label,title=f't = {t:g}')
            ax.grid(alpha=.2);ax.legend()
    fig.suptitle('Recovered May 29 gate data: mean and 16–84% run range')
    save(fig,out,'historical_gate_capture')
    df=pd.read_csv(folder/'metric_sweep_raw_1_.csv')
    names={'tweedie':'Tweedie','blend':'Scalar Blend','centered-regression':'Matrix Blend','lfgi':'LFGI'}
    fig,ax=plt.subplots(figsize=(6,4),layout='constrained')
    for method,name in names.items():
        x=df[df.method==method].groupby('n_ref').score_rmse.agg(['mean','std'])
        ax.errorbar(x.index,x['mean'],yerr=x['std'].fillna(0),fmt='o-',capsize=2,label=name)
    ax.set(xscale='log',yscale='log',xlabel='Reference-bank size',ylabel='Time-averaged score RMSE',
           title='Recovered May 29 sweep: historical methods only')
    ax.legend();ax.grid(alpha=.2)
    save(fig,out,'historical_score_rmse')

def darcy(out):
    files=sorted((ROOT/'data/recovered/darcy').glob('*drc_energy*.npz'))
    fig,axes=plt.subplots(2,2,figsize=(10,8),layout='constrained')
    for ax,p in zip(axes.ravel(),files):
        with np.load(p,allow_pickle=False) as d:
            x,y=d['energy'],d['neglogq']
            good=np.isfinite(x)&np.isfinite(y)
            ax.scatter(x[good],y[good],s=5,alpha=.3,rasterized=True)
            ax.set(xlabel='Target energy',ylabel='PF negative log density',
                   title=p.stem.split('DENS-')[-1].replace('CE-HLSI','LFGI (historical)'))
            ax.grid(alpha=.2)
    fig.suptitle('Recovered June 11 Darcy arrays; untrimmed finite evaluations')
    save(fig,out,'historical_darcy_density')

def samples(path,out):
    keys=json.loads(path.with_name('sample_keys.json').read_text())
    with np.load(path,allow_pickle=False) as data:
        ref=data['reference']; center=ref.mean(0)
        if 'funnel' in str(path).lower():
            basis=np.eye(ref.shape[1])[:,:2];labels=('Funnel coordinate','Conditional coordinate')
        else:
            _,_,v=np.linalg.svd(ref-center,full_matrices=False);basis=v[:2].T;labels=('Reference PC 1','Reference PC 2')
        pretty={'tweedie':'Tweedie','unif-scalar-blend':'Uniform scalar',
                'blend':'Scalar Blend','unif-matrix-blend':'Uniform matrix',
                'centered-matrix-blend':'Matrix Blend','ce-hlsi':'LFGI'}
        arrays={'Reference':ref,**{pretty.get(name,name):data[key] for key,name in keys.items()}}
        coords={name:(value-center)@basis for name,value in arrays.items()}
    reference=coords['Reference'];lo,hi=np.quantile(reference,[.005,.995],axis=0)
    width=np.maximum(hi-lo,1e-8);lo-=.1*width;hi+=.1*width
    edges=[np.linspace(lo[i],hi[i],41) for i in range(2)]
    n=len(coords);cols=min(4,n);rows=(n+cols-1)//cols
    fig,axes=plt.subplots(rows,cols,figsize=(3.6*cols,3.1*rows),layout='constrained',squeeze=False)
    hist={name:np.histogram2d(z[:,0],z[:,1],bins=edges)[0] for name,z in coords.items()}
    vmax=max(h.max() for h in hist.values());norm=LogNorm(vmin=1,vmax=max(2,vmax))
    for ax,(name,h) in zip(axes.ravel(),hist.items()):
        ax.pcolormesh(*edges,np.ma.masked_equal(h.T,0),norm=norm,cmap='viridis',rasterized=True)
        ax.set(title=name,xlabel=labels[0],ylabel=labels[1])
    for ax in axes.ravel()[n:]:ax.set_visible(False)
    fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='viridis'),ax=axes.ravel().tolist(),label='Count per common bin',shrink=.7)
    fig.suptitle('Saved run samples: common reference-derived axes and count scale')
    save(fig,out,'saved_sample_comparison')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('kind',choices=['historical','samples']);p.add_argument('--samples',type=Path)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    if a.kind=='historical':sweeps(a.output);darcy(a.output)
    else:
        if a.samples is None:p.error('--samples is required')
        samples(a.samples,a.output)
    print(a.output.resolve())

if __name__=='__main__':main()
