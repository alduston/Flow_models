#!/usr/bin/env python3
"""Portable recipes reconstructed from the manuscript and recovered settings.

Run from any directory. Each run gets an explicit output directory, recipe,
stdout/stderr log, and exit status. Recovered source files stay unchanged.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
METHODS = 'tweedie,unif_scalar_blend,scalar_blend,unif_matrix_blend,centered_blend,lfgi'
TARGETS = {'gmm8': 'misaligned_subspace_gmm_d8', 'gmm24': 'misaligned_subspace_gmm_d24', 'funnel': 'funnel_d10'}

def recipe(args):
    smoke = args.profile == 'smoke'
    env = {'MPLBACKEND': 'Agg', 'PYTHONUNBUFFERED': '1', 'DW4_DEVICE': args.device,
           'DW4_DTYPE': 'float64', 'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
           'XLA_PYTHON_CLIENT_PREALLOCATE': 'false'}
    if args.experiment == 'synthetic':
        env.update({
            'LFGI_BENCH_RUN_MODE': TARGETS.get(args.target, ','.join(TARGETS.values())),
            'LFGI_BENCH_NR': '32' if smoke else '250', 'LFGI_BENCH_NG': '32' if smoke else '250',
            'LFGI_BENCH_NS': '96' if smoke else '12000', 'LFGI_BENCH_NT': '96' if smoke else '12000',
            'LFGI_BENCH_NR_LARGE': '128' if smoke else '512',
            'LFGI_BENCH_BANK_COUPLING': 'independent', 'METHODS': METHODS,
            'LFGI_BENCH_STEPS': '24' if smoke else '300',
            'LFGI_BENCH_T_MIN': '0.01', 'LFGI_BENCH_T_MAX': '3.0',
            'LFGI_BENCH_TIME_SCHEDULE': 'linear', 'LFGI_BENCH_SCORE_RMSE': '1',
            'LFGI_BENCH_TIME_GRID': '4' if smoke else '300',
            'LFGI_BENCH_RMSE_EVAL': '48' if smoke else '512',
            'LFGI_BENCH_METRIC_MAX': '96' if smoke else '512',
            'LFGI_BENCH_KS_PROJ': '32' if smoke else '1000',
            'LFGI_BENCH_AUX_METRICS': '1', 'LFGI_BENCH_CURL': '0',
            'LFGI_BENCH_COPYING': '0', 'LFGI_BENCH_MALA_STATIONARITY': '0',
            'LFGI_BENCH_POLE_AUDIT': '0',
            'LFGI_BENCH_PRIMAL_MATRIX_RIDGE': '1e-8',
            'LFGI_BENCH_PRIMAL_MATRIX_RIDGE_REL': '1e-2',
            'LFGI_BENCH_PRIMAL_MATRIX_CENTER': '1',
            'LFGI_BENCH_PRIMAL_MATRIX_GATE_CLIP': '1e6',
        })
        cmd = [sys.executable, str(ROOT / 'reconstructed/run_synthetic.py'), '--seed', str(args.seed), '--runs', str(args.runs)]
        if args.plots:
            cmd.append('--plots')
    elif args.experiment == 'validation':
        cmd = [sys.executable, str(ROOT / 'recovered/validation/claim_validation_sweep.py'),
               '--device', args.device, '--dtype', 'float64', '--seed', str(args.seed),
               '--out-dir', 'validation', '--methods', METHODS,
               '--skip-learnability-diagnostics', '--skip-gate-ratio-diagnostics',
               '--gate-capture-estimators', 'matrix_blend,lfgi']
        if smoke:
            cmd += ['--nref-grid', '32', '64', '--repeats', '2', '--n-samples', '64',
                    '--n-metric', '64', '--n-score', '64', '--n-steps', '20',
                    '--score-t-grid', '0.04', '0.16', '0.64', '--gate-n-grid', '32', '64',
                    '--gate-repeats', '2', '--gate-n-query', '8', '--gate-n-oracle', '256']
    elif args.experiment == 'pole_audit':
        env.update({'LFGI_BENCH_RUN_MODE': 'funnel_d10', 'LFGI_BENCH_POLE_AUDIT': '1',
                    'LFGI_BENCH_POLE_AUDIT_HESSIAN_SOURCE': 'true',
                    'LFGI_BENCH_NR': '32' if smoke else '250', 'LFGI_BENCH_NG': '32' if smoke else '250',
                    'LFGI_BENCH_NS': '64' if smoke else '12000', 'LFGI_BENCH_NT': '64' if smoke else '12000',
                    'LFGI_BENCH_BANK_COUPLING': 'independent', 'METHODS': 'lfgi',
                    'LFGI_BENCH_STEPS': '16' if smoke else '300', 'LFGI_BENCH_T_MIN': '0.01',
                    'LFGI_BENCH_POLE_AUDIT_N': '8' if smoke else '512',
                    'LFGI_BENCH_POLE_AUDIT_N_HI': '128' if smoke else '8192',
                    'LFGI_BENCH_AUX_METRICS': '0', 'LFGI_BENCH_SCORE_RMSE': '0',
                    'LFGI_BENCH_CURL': '0', 'LFGI_BENCH_COPYING': '0',
                    'LFGI_BENCH_MALA_STATIONARITY': '0', 'LFGI_BENCH_KS_PROJ': '32'})
        cmd = [sys.executable, str(ROOT / 'reconstructed/run_synthetic.py'), '--seed', str(args.seed)]
    else:
        filename = {'gaussian': 'known_z_gaussian.py', 'mixture': 'known_z_shared_mixture.py',
                    'misaligned': 'known_z_misaligned_mixture.py', 'darcy': 'darcy_flow.py'}[args.experiment]
        n = '12' if smoke else ('1000' if args.experiment == 'darcy' else '2000')
        env.update({'HLSI_SAMPLING_MODULE': 'sampling_uniform_blends', 'SEED': str(args.seed),
                    'GIP_SEED': str(args.seed), 'GIP_PROBLEM_SEED': '42', 'GIP_DIM': '8',
                    'IP_DENSITY_N_REF_SIGNAL': n, 'IP_DENSITY_N_REF_GATE': n,
                    'IP_DENSITY_N_REF_EVAL': n, 'IP_DENSITY_DEFAULT_N_GEN': n,
                    'IP_DENSITY_BANK_COUPLING': 'independent',
                    'IP_DENSITY_EVAL_BANK_COUPLING': 'independent',
                    'IP_DENSITY_DRC_PF_STEPS': '8' if smoke else '64',
                    'IP_DENSITY_DRC_EVAL_BATCH_SIZE': '12' if smoke else '32',
                    'IP_DENSITY_DRC_TMIN': str(10**-2.5), 'IP_DENSITY_DRC_TMAX': '5',
                    'IP_DENSITY_DRC_ROBUST_PERCENTILES': '3,97',
                    'IP_DENSITY_MAP_LAPLACE_STARTS': '2' if smoke else '32',
                    'IP_DENSITY_MAP_LAPLACE_MAX_ITER': '3' if smoke else '25',
                    'IP_DENSITY_RUN_PF_SENSITIVITY': '0',
                    'IP_DENSITY_DRC_ENERGY_PLOTS': '1' if args.plots else '0'})
        if args.experiment == 'darcy':
            env.update({'IP_DENSITY_MALA_N_SAMPLES': str(2*int(n)),
                        'IP_DENSITY_MALA_EVAL_N_SAMPLES': n,
                        'IP_DENSITY_MALA_STEPS': '4' if smoke else '600',
                        'IP_DENSITY_MALA_BURNIN': '2' if smoke else '200',
                        'IP_DENSITY_MALA_DT': '5e-5'})
        cmd = [sys.executable, str(ROOT / 'recovered/inverse' / filename)]
        if smoke and args.experiment == 'darcy':
            cmd = [sys.executable, str(ROOT / 'reconstructed/run_darcy_smoke.py')]
        cmd = [sys.executable, str(ROOT / 'reconstructed/run_inverse.py'), cmd[1], '--seed', str(args.seed)]
    return cmd, env

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('experiment', choices=['synthetic','validation','pole_audit','gaussian','mixture','misaligned','darcy'])
    p.add_argument('--profile', choices=['smoke','paper'], default='smoke')
    p.add_argument('--target', choices=['gmm8','gmm24','funnel','all'], default='gmm8')
    p.add_argument('--device', choices=['cpu','cuda','auto'], default='cpu')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--runs', type=int, default=1)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--plots', action='store_true')
    p.add_argument('--dry-run', action='store_true')
    p.add_argument('--env', action='append', default=[], metavar='KEY=VALUE')
    args = p.parse_args()
    if args.runs != 1 and args.experiment != 'synthetic':
        p.error('--runs is supported for synthetic only; invoke other families separately with --seed')
    cmd, changes = recipe(args)
    for value in args.env:
        key, sep, val = value.partition('=')
        if not sep or not key:
            p.error('--env must be KEY=VALUE')
        changes[key] = val
    out = args.output.resolve()
    description = {'profile': args.profile, 'provenance': 'reconstructed recipe; unchanged recovered engines',
                   'command': cmd, 'environment_overrides': changes, 'cwd': str(out),
                   'utc_start': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    print(json.dumps(description, indent=2), flush=True)
    if args.dry_run:
        return
    out.mkdir(parents=True, exist_ok=True)
    (out / 'data').mkdir(exist_ok=True)
    (out / 'recipe.json').write_text(json.dumps(description, indent=2)+'\n')
    env = os.environ.copy(); env.update(changes)
    env['PYTHONPATH'] = str(ROOT / 'recovered/inverse') + os.pathsep + env.get('PYTHONPATH','')
    t = time.time()
    with (out / 'run.log').open('w') as log:
        result = subprocess.run(cmd, cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT)
    status = {'exit_code': result.returncode, 'seconds': time.time()-t}
    (out / 'exit_status.json').write_text(json.dumps(status, indent=2)+'\n')
    print(json.dumps(status), flush=True)
    if result.returncode:
        print((out / 'run.log').read_text()[-6000:], file=sys.stderr)
    raise SystemExit(result.returncode)

if __name__ == '__main__':
    main()
