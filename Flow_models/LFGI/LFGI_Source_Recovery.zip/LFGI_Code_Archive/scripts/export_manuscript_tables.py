#!/usr/bin/env python3
"""Extract reported table cells from TeX; does not reconstruct per-run data."""
import argparse
import csv
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,default=ROOT/'paper_snapshot/main.tex')
    p.add_argument('--output',type=Path,default=ROOT/'data/paper_reported')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    s=a.source.read_text();tables=[]
    for block in re.findall(r'\\begin\{table\}.*?\\end\{table\}',s,re.S):
        label=re.search(r'\\label\{([^}]+)\}',block)
        if not label or '\\midrule' not in block:continue
        body=block.split('\\midrule',1)[1].split('\\bottomrule',1)[0]
        rows=[]
        for raw in re.split(r'\\\\\s*(?:\[[^]]*\])?',body):
            raw=re.sub(r'(?m)%.*$','',raw).strip()
            if '&' in raw:
                rows.append([re.sub(r'\s+',' ',x).strip() for x in re.split(r'(?<!\\)&',raw)])
        name=label.group(1).replace(':','_')
        if not rows:continue
        with (a.output/f'{name}.csv').open('w') as f:
            w=csv.writer(f);w.writerow(['method_or_row']+[f'value_{i}_tex' for i in range(1,max(map(len,rows)))]);w.writerows(rows)
        tables.append({'label':label.group(1),'file':name+'.csv','rows':len(rows),'status':'reported_cells_only; not raw runs'})
    (a.output/'index.json').write_text(json.dumps(tables,indent=2)+'\n')
    (a.output/'README.md').write_text('# Reported manuscript tables\n\nAutomatically extracted from the supplied TeX snapshot. Cells preserve LaTeX notation. These are reported summaries, not recovered per-seed measurements. Do not use them as raw data or infer missing uncertainty from them.\n')
    print(json.dumps(tables,indent=2))

if __name__=='__main__':main()
