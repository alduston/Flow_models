# Reported manuscript tables

Automatically extracted from the supplied TeX snapshot. Cells preserve LaTeX notation. These are reported summaries, not recovered per-seed measurements. Do not use them as raw data or infer missing uncertainty from them.
