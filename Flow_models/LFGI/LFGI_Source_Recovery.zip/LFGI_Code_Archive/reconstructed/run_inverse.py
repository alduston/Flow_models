#!/usr/bin/env python3
"""Reconstructed seed initialization for unchanged recovered problem scripts."""
import argparse
import os
from pathlib import Path
import random
import runpy
import numpy as np
import torch

p=argparse.ArgumentParser();p.add_argument('script',type=Path);p.add_argument('--seed',type=int,required=True)
a=p.parse_args()
random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed)
if torch.cuda.is_available():torch.cuda.manual_seed_all(a.seed)
os.environ['SEED']=str(a.seed)
runpy.run_path(str(a.script.resolve()),run_name='__main__')
