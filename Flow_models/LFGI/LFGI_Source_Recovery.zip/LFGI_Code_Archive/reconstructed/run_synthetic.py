#!/usr/bin/env python3
"""Reconstructed orchestration around the recovered, unchanged June engine.

The original engine plots samples but does not persist the returned clouds.
This driver additionally saves arrays and run-level scalar metrics. It does
not alter the target, estimator, sampling, or metric implementations.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--runs', type=int, default=1)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--plots', action='store_true')
    args = p.parse_args()
    source = ROOT / 'recovered/synthetic/benchmark_sweep.py'
    spec = importlib.util.spec_from_file_location('recovered_benchmark', source)
    engine = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = engine
    spec.loader.exec_module(engine)
    _, variants = engine.resolve_run_mode_variants(os.environ['LFGI_BENCH_RUN_MODE'])
    rows = []
    for target_name, target in variants.items():
        for seed in range(args.seed, args.seed + args.runs):
            out = Path(target_name) / f'seed_{seed}'
            out.mkdir(parents=True, exist_ok=True)
            engine.set_global_seed(seed)
            results, truth, bank, methods, target = engine.run(target, out_dir=str(out))
            if args.plots:
                engine.plot(results, truth, bank, methods, target, out_dir=str(out))
            arrays = {'reference': truth.detach().cpu().numpy(), 'score_bank': bank.detach().cpu().numpy()}
            names = {}
            for i, (method, result) in enumerate(results.items()):
                key = f'method_{i:02d}'
                if 'samples' in result:
                    samples = result['samples']
                    arrays[key] = samples.detach().cpu().numpy() if hasattr(samples, 'detach') else np.asarray(samples)
                    names[key] = method
                row = {'target': target_name, 'seed': seed, 'method': method}
                for metric, value in result.items():
                    if isinstance(value, (int, float, bool, np.number)):
                        row[metric] = value
                rows.append(row)
            np.savez_compressed(out / 'samples.npz', **arrays)
            (out / 'sample_keys.json').write_text(json.dumps(names, indent=2) + '\n')
            pd.DataFrame([r for r in rows if r['target'] == target_name and r['seed'] == seed]).to_csv(out / 'run_metrics.csv', index=False)
    frame = pd.DataFrame(rows)
    frame.to_csv('run_metrics_all.csv', index=False)
    numeric = [c for c in frame.select_dtypes(include='number').columns if c != 'seed']
    frame.groupby(['target', 'method'])[numeric].agg(['mean', 'std', 'count']).to_csv('aggregate_metrics.csv')
    print('Saved raw clouds, per-run metrics, and aggregate_metrics.csv', flush=True)

if __name__ == '__main__':
    main()
