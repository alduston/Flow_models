#!/usr/bin/env python3
"""Execute a clearly labelled, smaller-grid wiring check of recovered Darcy.

This is not a reproduction of the paper's 32x32/32-parameter problem. The
original source is preserved unchanged; only these five top-level constants
are changed in an in-memory AST for a practical CPU validation run.
"""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / 'recovered/inverse/darcy_flow.py'
text = source.read_text()
tree = ast.parse(text, filename=str(source))
changes = {'N': 8, 'q_max': 16, 'num_observation': 12,
           'num_holdout_observation': 6, 'num_truncated_series': 4}
found = {}
for node in tree.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        name = node.targets[0].id
        if name in changes:
            if name in found:
                raise RuntimeError(f'Duplicate top-level assignment: {name}')
            found[name] = {'original': ast.unparse(node.value), 'smoke': changes[name]}
            node.value = ast.copy_location(ast.Constant(value=changes[name]), node.value)
if set(found) != set(changes):
    raise RuntimeError(f'Unmatched smoke constants: {set(changes)-set(found)}')
Path('scaled_darcy_manifest.json').write_text(json.dumps({
    'status': 'reconstructed scaled smoke; not paper results', 'changes': found,
    'original_sha256': hashlib.sha256(source.read_bytes()).hexdigest()
}, indent=2)+'\n')
exec(compile(ast.fix_missing_locations(tree), str(source), 'exec'),
     {'__name__': '__main__', '__file__': str(source)})
