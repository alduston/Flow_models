# Additional recovered theory code

`pearson_control/` is the supplied November 12 finite-reference density/Pearson investigation. Its source, logs, saved arrays, report and figure generator are preserved. It is an extension for the planned revision, not the producer of the June/arXiv manuscript figures. Read its own README for script-to-result mapping and runtime estimates. The full extension campaign was not rerun during source recovery.
