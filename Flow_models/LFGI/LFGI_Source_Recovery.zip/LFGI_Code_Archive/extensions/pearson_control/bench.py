import numpy as np, time
from fast1d import lfgi1, pf1
from lfgi_core import time_grid, sched
from targets1d import CosTarget, bank_pigrid
tg = CosTarget(0.125, 2.0, nmax=14)
bank = bank_pigrid(tg, 97)
xs = np.linspace(-2.5,2.5,3001)
t0=time.time()
for _ in range(20):
    lfgi1(bank.x[:,0], bank.logw, bank.s[:,0], bank.P[:,0,0], xs, 0.01)
print('lfgi1 per call', (time.time()-t0)/20)
t0=time.time()
for _ in range(20):
    tg.st(xs,0.01); tg.dst(xs,0.01)
print('target per call', (time.time()-t0)/20)
