"""Pointwise bounds on e and div e (Theorem C) checked on a dense (y,t) grid, d = 1.

Bounds (exact Hessian gates, eps_P = 0; L_H Lipschitz constant of H0; P_{y,t} lam_P-strongly
log-concave; A_g >= a_*):
  |e|     <= (alpha/a_*) [ L_H m1^2 + (L_H/2)(m2^2 + sigma_P^2) ]
  |div e| <= (s/a_*) sigma_Q [ L_H m1 m2 + (L_H/2) m4^2 ] + (alpha/a_*) sigma_Q S_Q |a|
             + w [ 2 d^2 L_H^2 / lam_P^4 + (d gamma/(a_* lam_P)) L_H (m1 + sqrt(d/lam_P)) ]
where m_k = (E_Q |X - mu_P|^k)^{1/k}.
"""
import numpy as np
from lfgi_core import lfgi, sched
from targets1d import CosTarget, bank_quantile, bank_pigrid, bank_iid

rng = np.random.default_rng(1)
tg = CosTarget(eps=0.125, om=2.0)
LH, kappa = tg.LH, tg.kappa
print(f"target: L_H={LH}, kappa={kappa}")


def bounds(bank, yq, t):
    a, g = sched(t)
    s = a * a / g
    o = lfgi(bank, yq[:, None], t)
    m = o['m']; xb = bank.x[:, 0]; Pb = bank.P[:, 0, 0]
    Hg = o['H'][:, 0, 0]; A = o['A'][:, 0, 0]; muQ = o['mu'][:, 0]
    shat = o['shat'][:, 0]; act = shat - o['stw'][:, 0]
    st = tg.st(yq, t)
    e = st - shat
    dive = tg.dst(yq, t) - o['div']
    muP, varP = tg.post_moments(yq, t)
    dev = np.abs(xb[None, :] - muP[:, None])
    m1 = (m * dev).sum(1)
    m2 = np.sqrt((m * dev ** 2).sum(1))
    m4 = ((m * dev ** 4).sum(1)) ** 0.25
    sigQ = np.sqrt((m * (xb[None, :] - muQ[:, None]) ** 2).sum(1))
    SQ = np.sqrt((m * (Pb[None, :] - Hg[:, None]) ** 2).sum(1))
    lamP = s + kappa
    astar = A  # actual gate floor at the query (>= a^2 + g*kappa)
    B_e = (a / astar) * (LH * m1 ** 2 + 0.5 * LH * (m2 ** 2 + 1.0 / lamP))
    w = (a / g) ** 2
    B_div = (s / astar) * sigQ * (LH * m1 * m2 + 0.5 * LH * m4 ** 2) + (a / astar) * sigQ * SQ * np.abs(act) \
        + w * (2 * LH ** 2 / lamP ** 4 + (g / (astar * lamP)) * LH * (m1 + np.sqrt(1.0 / lamP)))
    return dict(e=e, dive=dive, B_e=B_e, B_div=B_div, m4=m4, sigQ=sigQ, st=st)


yq = np.linspace(-3, 3, 1201)
tlist = np.exp(np.linspace(np.log(1e-6), np.log(6.0), 60))
for name, bank in [('pi-grid N=48', bank_pigrid(tg, 48)), ('quantile N=48', bank_quantile(tg, 48)),
                   ('iid N=48', bank_iid(tg, 48, rng)), ('iid N=200', bank_iid(tg, 200, rng))]:
    re, rd, tight_e, tight_d = 0, 0, [], []
    for t in tlist:
        b = bounds(bank, yq, t)
        re = max(re, (np.abs(b['e']) / b['B_e']).max())
        rd = max(rd, (np.abs(b['dive']) / b['B_div']).max())
        tight_e.append(np.abs(b['e']).max() / b['B_e'].max())
        tight_d.append(np.abs(b['dive']).max() / b['B_div'].max())
    print(f"{name:14s}: max |e|/bound = {re:.3f}   max |div e|/bound = {rd:.3f}   "
          f"sup|e|/sup bound (median over t) = {np.median(tight_e):.3f}   sup|div e|/sup bound = {np.median(tight_d):.3f}")

# scaling of the singular layer term: sup_y |div e| * gamma / rho^3 in the unresolved window (pi-grid)
print("\nlayer scaling for the pi-weighted grid: sup_y|div e| * gamma_t / (L_H rho^3)")
for N in [24, 48, 96]:
    bank = bank_pigrid(tg, N)
    rho = 12.0 / (N - 1)
    row = []
    for t in [1e-6, 1e-5, 1e-4, rho ** 2 / 20]:
        a, g = sched(t)
        b = bounds(bank, np.linspace(-2.5, 2.5, 20001), t)
        row.append(np.abs(b['dive']).max() * g / (LH * rho ** 3))
    print(f"  N={N:3d} rho={rho:.3f}: " + "  ".join(f"{v:.4f}" for v in row))
