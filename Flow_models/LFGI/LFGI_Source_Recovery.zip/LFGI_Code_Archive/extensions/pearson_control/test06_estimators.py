"""Evidence estimators built on the 2D LFGI-GN surrogate, with known Z (quadrature).

Replicated with n posterior and M surrogate samples per replicate:
  forward IS, reciprocal IS, their truncated versions on the surrogate HPD set S,
  prior-defensive forward IS, optimal bridge, and the ELBO/EUBO sandwich.
Also: KL <-> Pearson constants (Lemma B) on the same samples.
"""
import numpy as np
from lfgi_core import time_grid, pf_forward, log_std_normal
from target2d import TanhIP

rng = np.random.default_rng(5)
d = np.load('out_tails2d_samples.npz')
xp, l_p, logq_p = d['xp'], d['l_p'], d['logq_p']
xq, l_q, logq_s = d['xq'], d['l_q'], d['logq_s']
logZ = float(d['logZ'])
lt_p = l_p + logZ   # log(pi_tilde/q) at posterior samples
lt_q = l_q + logZ   # log(pi_tilde/q) at surrogate samples

# ---- log q at prior samples for the defensive mixture (same bank as test05)
tg = TanhIP()
bank = tg.bank(tg.sample(150, np.random.default_rng(11)), gate='gn')
ts = time_grid(1e-3, 8.0, n_log=130, n_lin=130)
xpr = rng.normal(size=(3000, 2))
yT, L, _ = pf_forward(bank, xpr, ts)
logq_pr = log_std_normal(yT) + L
logpt_pr = tg.logpi_un(xpr)
logphi_pr = log_std_normal(xpr)
logphi_q = log_std_normal(xq)
logpt_q = lt_q + logq_s

# ---- truncation set S: surrogate HPD at 90% of q-mass, calibrated on the last 10000 surrogate samples
cal = slice(10000, 20000)
c90 = np.quantile(logq_s[cal], 0.10)
qS = np.mean(logq_s[cal] >= c90)
piS_all = np.mean(logq_p >= c90)
inS_p = logq_p >= c90
print(f"S = {{log q >= {c90:.3f}}}: q(S) = {qS:.3f}, pi(S) = {piS_all:.3f};  on S: l in [{l_p[inS_p].min():.3f}, {l_p[inS_p].max():.3f}]"
      f"  (all posterior samples: [{l_p.min():.3f}, {l_p.max():.3f}])")


def bridge(l1, l2, iters=200):
    n2, n1 = len(l1), len(l2)
    s1, s2 = n1 / (n1 + n2), n2 / (n1 + n2)
    r = np.exp(np.mean(l1))
    e1, e2 = np.exp(l1), np.exp(l2)
    for _ in range(iters):
        num = np.mean(e1 / (s1 * e1 + s2 * r))
        den = np.mean(1.0 / (s1 * e2 + s2 * r))
        r = num / den
    return np.log(r)


n = M = 200
K = 30
eps = 0.1
est = {k: [] for k in ['forward IS', 'reciprocal IS', 'truncated forward', 'truncated reciprocal',
                       'prior-defensive forward', 'bridge', 'ELBO (lower)', 'EUBO (upper)']}
for k in range(K):
    ip = slice(k * n, (k + 1) * n)
    iq = slice(k * M, (k + 1) * M)
    a, b = lt_q[iq], lt_p[ip]
    est['forward IS'].append(np.log(np.mean(np.exp(a))))
    est['reciprocal IS'].append(-np.log(np.mean(np.exp(-b))))
    Sq = logq_s[iq] >= c90
    Sp = logq_p[ip] >= c90
    est['truncated forward'].append(np.log(np.mean(np.exp(a) * Sq)) - np.log(np.mean(Sp)))
    est['truncated reciprocal'].append(-np.log(np.mean(np.exp(-b) * Sp)) + np.log(qS))
    # defensive mixture: (1-eps) q + eps prior
    npr = rng.binomial(M, eps)
    jpr = rng.choice(len(xpr), npr, replace=False)
    jq = np.arange(k * M, k * M + (M - npr))
    lw = np.concatenate([
        logpt_q[jq] - np.logaddexp(np.log1p(-eps) + logq_s[jq], np.log(eps) + logphi_q[jq]),
        logpt_pr[jpr] - np.logaddexp(np.log1p(-eps) + logq_pr[jpr], np.log(eps) + logphi_pr[jpr])])
    est['prior-defensive forward'].append(np.log(np.mean(np.exp(lw))))
    est['bridge'].append(bridge(a, b))
    est['ELBO (lower)'].append(np.mean(a))
    est['EUBO (upper)'].append(np.mean(b))

chi_rev = np.mean(np.exp(-2 * l_p)) - 1
chi_fwd = np.mean(np.exp(2 * l_q)) - 1
KL_pq, KL_qp = l_p.mean(), -l_q.mean()
tri = 0.5 * (np.mean(np.tanh(l_p / 2) ** 2 * (1 + np.exp(-l_p))) + np.mean(np.tanh(l_q / 2) ** 2 * (1 + np.exp(l_q))))
pred = {'forward IS': np.sqrt(chi_fwd / M), 'reciprocal IS': np.sqrt(chi_rev / n),
        'bridge': np.sqrt((2 * tri / (n + M)) / (1 - tri / 2))}
print(f"\ntrue log Z = {logZ:.4f};  replicates K={K}, n=M={n}")
print(f"{'estimator':26s} {'mean error':>11s} {'RMSE':>9s} {'predicted sd':>13s}")
for name, v in est.items():
    v = np.array(v) - logZ
    p = pred.get(name)
    print(f"{name:26s} {v.mean():11.4f} {np.sqrt(np.mean(v ** 2)):9.4f} {'' if p is None else f'{p:13.4f}'}")
print(f"\nsandwich width EUBO-ELBO (all samples) = {l_p.mean() - l_q.mean():.4f} = KL(pi||q) + KL(q||pi) = {KL_pq:.4f} + {KL_qp:.4f}")

# ---- Lemma B constants on these samples
Mrev = np.exp(-l_p).max(); Mfwd = np.exp(l_q).max()
print("\nKL <-> Pearson (sampled region):")
print(f"   chi2(q||pi) = {chi_rev:.4f};  KL(q||pi) = {KL_qp:.4f};  ratio = {chi_rev / KL_qp:.2f}  <= (2/3)(M+2) = {(2 / 3) * (Mrev + 2):.2f}  with M = sup q/pi = {Mrev:.2f}")
print(f"   chi2(q||pi) / KL(pi||q) = {chi_rev / KL_pq:.2f}  <= (2/3)(2M+1) = {(2 / 3) * (2 * Mrev + 1):.2f}")
print(f"   chi2(pi||q) = {chi_fwd:.4f};  KL(pi||q) = {KL_pq:.4f};  ratio = {chi_fwd / KL_pq:.2f}  <= (2/3)(M'+2) = {(2 / 3) * (Mfwd + 2):.2f}  with M' = sup pi/q = {Mfwd:.2f}")
print(f"   Delta = {tri:.4f}  <= min(chi2) = {min(chi_rev, chi_fwd):.4f}")
# entropy
H_cross = -np.mean(logq_p)
H_q = -np.mean(logq_s)
H_true = -np.mean(l_p + logq_p)  # -E_pi log pi
print(f"\nentropy: H(pi) = {H_true:.4f} (MC);  cross-entropy -E_pi log q = {H_cross:.4f} (excess {H_cross - H_true:.4f} = KL(pi||q));  surrogate entropy H(q) = {H_q:.4f}"
      f"  (|H(q)-H(pi)| = {abs(H_q - H_true):.4f}, bound sqrt(chi2_rev)*sd_pi(log q) + KL = {np.sqrt(chi_rev) * logq_p.std() + KL_pq:.4f})")
