"""Refined ray study for the 2D LFGI-GN surrogate: path-integrated radial constant, mass bound,
and polar quadrature of the tail integrands (192 directions, dr = 0.05)."""
import numpy as np
from scipy.stats import chi as chi_dist
from lfgi_core import lfgi, sched, time_grid, pf_forward, log_std_normal
from target2d import TanhIP

rng = np.random.default_rng(11)
tg = TanhIP()
N = 150
tau, T = 1e-3, 8.0
ts = time_grid(tau, T, n_log=130, n_lin=130)
bank = tg.bank(tg.sample(N, rng), gate='gn')
B_i = bank.P - np.eye(2)[None]
m_i = bank.x + np.linalg.solve(bank.P, bank.s[..., None])[..., 0]
c = np.exp(bank.logw) @ m_i


def extra(yy, tt, o):
    a, g = sched(tt)
    m = o['m']
    Bg = o['H'] - np.eye(2)[None]
    t1 = -np.einsum('mn,nij,nj->mi', m, bank.P, m_i - c)
    dx = bank.x[None] - o['mu'][:, None]
    t2 = np.einsum('mn,nij,mnj->mi', m, B_i, dx)
    f = t1 + t2
    v = np.linalg.solve(np.eye(2)[None] + g * Bg, f[..., None])[..., 0]
    return (a * np.linalg.norm(v, axis=1))[:, None]


angles = np.linspace(0, 2 * np.pi, 192, endpoint=False)
radii = np.arange(0.0, 8.0001, 0.05)
ctr = bank.x.mean(0)
pts = np.concatenate([ctr[None] + r * np.stack([np.cos(angles), np.sin(angles)], 1) for r in radii])
yT, Ldet, E = pf_forward(bank, pts, ts, extra=extra)
logq = log_std_normal(yT) + Ldet
logpi = tg.logpi(pts)
a_tau, _ = sched(tau); a_T, _ = sched(T)
rad_in = np.linalg.norm(pts - a_tau * c, axis=1)
rad_out = np.linalg.norm(yT - a_T * c, axis=1)
Fint = E[:, 0].max()
print(f"path-integrated radial constant F_c = sup_x int alpha |(I+gamma B_g)^-1 f_c| dt = {Fint:.3f}")
print(f"min over starts of |Phi_T x - a_T c| - |x - a_tau c| = {(rad_out - rad_in).min():.3f}  (must be >= -F_c: {'OK' if (rad_out - rad_in + E[:, 0]).min() >= -1e-9 else 'VIOLATED'})")
print("(D2) mass bound P(chi_2 >= r - F_c - a_T|c|) vs prior tail:")
for r in [2.5, 3.0, 3.5, 4.0, 5.0]:
    print(f"   r={r}: bound {chi_dist.sf(max(r - Fint - a_T * np.linalg.norm(c), 0), 2):.3e}   prior tail {chi_dist.sf(r, 2):.3e}")

shape = (len(radii), len(angles))
LP, LQ = logpi.reshape(shape), logq.reshape(shape)
dth = angles[1] - angles[0]; dr = radii[1] - radii[0]
print("\n polar quadrature outside radius R about the bank mean (192 rays, dr=0.05):")
print("    R    pi-mass      q-mass       int q^2/pi   [share from directions with log(q/pi)>3]   log10 int pi^2/q (r<=8)")
for R in [1.5, 2, 2.5, 3, 4, 5, 6]:
    k = radii >= R
    w = (radii[k] * dr)[:, None] * dth * np.ones((1, len(angles)))
    rev_int = np.exp(2 * LQ[k] - LP[k]) * w
    heavy = (LQ[k] - LP[k]) > 3
    lf = 2 * LP[k] - LQ[k] + np.log(w)
    fwd = (lf.max() + np.log(np.exp(lf - lf.max()).sum())) / np.log(10)
    print(f"   {R:3.1f}  {(np.exp(LP[k]) * w).sum():.3e}   {(np.exp(LQ[k]) * w).sum():.3e}   {rev_int.sum():.3e}   {rev_int[heavy].sum() / rev_int.sum():6.1%}"
          f"                                  {fwd:8.1f}")
# inside-R (core) integrals for comparison
for R in [1.5, 2.0, 2.5, 3.0]:
    k = (radii < R) & (radii > 0)
    w = (radii[k] * dr)[:, None] * dth * np.ones((1, len(angles)))
    print(f"   core r<{R}: pi-mass {(np.exp(LP[k]) * w).sum():.4f}, q-mass {(np.exp(LQ[k]) * w).sum():.4f}, int_S q^2/pi = {(np.exp(2 * LQ[k] - LP[k]) * w).sum():.4f}, "
          f"int_S pi^2/q = {(np.exp(2 * LP[k] - LQ[k]) * w).sum():.4f}, sup_S |l| = {np.abs(LP[k] - LQ[k]).max():.3f}")
np.savez('out_rays2d_fine.npz', radii=radii, angles=angles, LP=LP, LQ=LQ, ctr=ctr, bankx=bank.x, Fint=Fint,
         rad_gain=(rad_out - rad_in).reshape(shape))
