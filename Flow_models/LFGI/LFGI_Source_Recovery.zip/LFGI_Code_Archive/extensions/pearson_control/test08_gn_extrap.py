"""Tail ratio of the LFGI-GN surrogate vs the Gauss-Newton extrapolation error of the misfit.
Beyond the bank hull the frozen field is the Laplace field of the extreme particle e, so
   log(q/pi)(x) ≈ Phi(x) - Phi_e^GN(x) + const,   Phi_e^GN(x) = Phi(x_e) + gradPhi(x_e).(x-x_e) + (x-x_e)^T B_e (x-x_e)/2."""
import numpy as np
from lfgi_core import time_grid, pf_forward, log_std_normal
from target2d import TanhIP
tg = TanhIP(); bank = tg.bank(tg.sample(150, np.random.default_rng(11)), gate='gn')
ts = time_grid(1e-3, 8.0, n_log=130, n_lin=130)
ctr = bank.x.mean(0)
r = np.linspace(0.0, 9.0, 73)
out = {}
for name, ang in [('heavy', 45.0), ('light', 202.5)]:
    u = np.array([np.cos(np.radians(ang)), np.sin(np.radians(ang))])
    pts = ctr[None] + r[:, None] * u[None]
    yT, L, _ = pf_forward(bank, pts, ts)
    lr = log_std_normal(yT) + L - tg.logpi(pts)
    e = np.argmax(bank.x @ u)
    xe = bank.x[e]; Be = bank.P[e] - np.eye(2)
    dx = pts - xe[None]
    PhiGN = tg.Phi(xe[None])[0] + dx @ tg.gradPhi(xe[None])[0] + 0.5 * np.einsum('mi,ij,mj->m', dx, Be, dx)
    pred = tg.Phi(pts) - PhiGN
    k0 = np.argmin(np.abs(r - 6.0))
    pred = pred + (lr[k0] - pred[k0])
    hull_r = (bank.x - ctr) @ u
    print(f"{name}: direction {ang} deg, extreme particle at projected radius {hull_r.max():.2f}, u.B_e.u = {u @ Be @ u:.3f}")
    for rr in [3, 4, 5, 6, 7, 8, 9]:
        k = np.argmin(np.abs(r - rr))
        print(f"    r={rr}: log(q/pi) = {lr[k]:9.3f}   Phi - Phi_GN + const = {pred[k]:9.3f}")
    out[name] = (lr, pred)
np.savez('out_gn_extrap.npz', r=r, lr=out['heavy'][0], pred=out['heavy'][1], lr_light=out['light'][0], pred_light=out['light'][1])
