"""Monte-Carlo (resolved) regime for iid banks: first-order influence function of the PF log-density.

Prediction (delta method):  l(x0) = log(pi_tau/q_tau)(x0) ≈ (1/N) sum_i Xi(x0, x_i),
   Xi(x0,x) = int_tau^T  pi_t(Y_t)^{-1} d/dy [ alpha A^{-1} K_t(y|x) (phi_{y,t}(x) - E_P phi) ]_{y=Y_t(x0)} dt,
with Y_t the *target* PF trajectory, phi = s0 + H_P x, A = alpha^2 + gamma H_P.
Hence N * E_bank[l(x0)^2] -> V(x0) = Var_{x~pi} Xi(x0,x), and chi^2 ≈ (1/N) E_pi V on the covered core.
"""
import numpy as np
from lfgi_core import sched, time_grid
from fast1d import pf1
from targets1d import CosTarget, bank_iid

tg = CosTarget(eps=0.125, om=2.0, nmax=14)
T = 8.0
x0 = np.linspace(-2.0, 2.0, 81)
X = np.linspace(-7, 7, 5601)
dX = X[1] - X[0]
piX = np.exp(tg.logpi(X))


def influence(tau, nlog=500, nlin=220):
    ts = time_grid(tau, T, n_log=nlog, n_lin=nlin)
    y = x0.copy()
    Xi = np.zeros((len(x0), len(X)))

    def integrand(yy, tt):
        a, g = sched(tt)
        dy = 1e-3 * np.sqrt(g)

        def gfun(yq):
            HP = tg.HP(yq, tt)
            A = a * a + g * HP
            muP, _ = tg.post_moments(yq, tt)
            phibar = a * tg.st(yq, tt) + HP * muP
            phi = tg.s0(X)[None, :] + HP[:, None] * X[None, :]
            k = np.exp(-0.5 * (yq[:, None] - a * X[None, :]) ** 2 / g) / np.sqrt(2 * np.pi * g)
            return (a / A)[:, None] * k * (phi - phibar[:, None])

        dg = (gfun(yy + dy) - gfun(yy - dy)) / (2 * dy)
        return dg / np.exp(tg.logpit(yy, tt))[:, None]

    def vel(yy, tt):
        return -yy - tg.st(yy, tt)

    for k in range(len(ts) - 1):
        t0, t1 = ts[k], ts[k + 1]
        h = t1 - t0
        k1 = vel(y, t0); i1 = integrand(y, t0)
        ym = y + 0.5 * h * k1
        k2 = vel(ym, t0 + 0.5 * h)
        ym2 = y + 0.5 * h * k2
        k3 = vel(ym2, t0 + 0.5 * h); i23 = integrand(0.5 * (ym + ym2), t0 + 0.5 * h)
        ye = y + h * k3
        k4 = vel(ye, t1); i4 = integrand(ye, t1)
        Xi += h / 6 * (i1 + 4 * i23 + i4)
        y = y + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
    mean = (Xi * piX[None, :]).sum(1) * dX
    V = (Xi ** 2 * piX[None, :]).sum(1) * dX - mean ** 2
    return V, mean, Xi


rng = np.random.default_rng(7)
px0 = np.exp(tg.logpi(x0)); w0 = px0 / px0.sum()
res = {}
for tau in [2e-2, 2e-3]:
    V, mean, Xi = influence(tau)
    print(f"tau={tau}: influence mean (should be 0): max|mean| = {np.abs(mean).max():.2e};  "
          f"core-averaged V = {(w0 * V).sum():.4e}", flush=True)
    ts = time_grid(tau, T, n_log=int(70 * np.log10(0.3 / tau)), n_lin=220)
    for N in [50, 100, 200, 400, 800]:
        nrep = 24 if N <= 400 else 12
        acc2 = np.zeros_like(x0); acc1 = np.zeros_like(x0); acc_lin = 0.0
        for r in range(nrep):
            bank = bank_iid(tg, N, rng)
            logq, _, _ = pf1(bank, x0, ts)
            l = tg.logpit(x0, tau) - logq
            # first-order prediction for this very bank
            lin = np.array([np.interp(bank.x[:, 0], X, Xi[i]).mean() for i in range(len(x0))])
            acc_lin += np.corrcoef(l, lin)[0, 1]
            acc2 += l ** 2; acc1 += l
        m2 = acc2 / nrep
        print(f"   N={N:4d}: N*E[l^2] core-avg = {N * (w0 * m2).sum():.4e}   (prediction {(w0 * V).sum():.4e});  "
              f"ratio = {N * (w0 * m2).sum() / (w0 * V).sum():.3f};  mean corr(l, first-order prediction) = {acc_lin / nrep:.3f}", flush=True)
        res[(tau, N)] = (N * (w0 * m2).sum(), (w0 * V).sum())
    np.savez(f'out_influence_tau{tau}.npz', x0=x0, V=V, X=X, Xi_mid=Xi[len(x0) // 2])
