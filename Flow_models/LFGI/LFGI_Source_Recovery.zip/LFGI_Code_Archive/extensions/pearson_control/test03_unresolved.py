"""Unresolved-window law (d=1, calibrated pi-weighted grid bank).

l = log(pi_tau/q_tau) is split into the contribution of the unresolved window [tau, t1]
(gamma_{t1} = rho^2) and of the resolved window [t1, T]:  l = l_T - int_un h - int_res h.

Tested:
  * sup_x |l_un(x)| grows like L_H rho^3 log(rho^2/gamma_tau)   (log loss in the cutoff)
  * the L^2(pi) size of l_un is tau-independent as tau -> 0     (no Pearson penalty)
  * total sup|l| and L^2 norms scale as rho^3 for the calibrated grid.
"""
import sys
import numpy as np
from lfgi_core import sched, time_grid
from fast1d import pf1
from targets1d import CosTarget, bank_pigrid

tg = CosTarget(eps=0.125, om=2.0, nmax=14)
LH = tg.LH
T = 8.0
xs = np.linspace(-2.5, 2.5, 3001)
px = np.exp(tg.logpi(xs)); px /= px.sum()
per_decade = int(sys.argv[1]) if len(sys.argv) > 1 else 70

rows = []
print(f"{'N':>4} {'rho':>6} {'tau':>8} {'sup|l|':>10} {'sup|l_un|':>10} {'sup|l_res|':>10} "
      f"{'L2 l_un':>10} {'L2 l_res':>10} {'L2 l':>10} {'sup l_un/(LH rho^3)':>20} {'log(rho^2/g_tau)':>17}", flush=True)
for N in [25, 49, 97]:
    bank = bank_pigrid(tg, N)
    rho = 12.0 / (N - 1)
    t1 = -0.5 * np.log(1 - rho ** 2)  # gamma_{t1} = rho^2
    for tau in [1e-3, 1e-4, 1e-5, 1e-6, 1e-7]:
        if tau >= t1:
            continue
        nlog = int(per_decade * np.log10(0.3 / tau))
        ts = time_grid(tau, T, n_log=nlog, n_lin=220)

        def extra(yy, tt, sh, dsh, o):
            st = tg.st(yy, tt)
            e = st - sh
            hsrc = tg.dst(yy, tt) - dsh + st * e
            un = 1.0 if tt <= t1 else 0.0
            return np.stack([hsrc * un, hsrc * (1 - un)], 1)

        logq, yT, E = pf1(bank, xs, ts, extra=extra)
        l = tg.logpit(xs, tau) - logq
        l_un, l_res = -E[:, 0], -E[:, 1]
        a_, g_tau = sched(tau)
        r = (N, rho, tau, np.abs(l).max(), np.abs(l_un).max(), np.abs(l_res).max(),
             np.sqrt((px * l_un ** 2).sum()), np.sqrt((px * l_res ** 2).sum()),
             np.sqrt((px * l ** 2).sum()), np.log(rho ** 2 / g_tau))
        rows.append(r)
        print(f"{N:4d} {rho:6.3f} {tau:8.0e} {r[3]:10.3e} {r[4]:10.3e} {r[5]:10.3e} {r[6]:10.3e} {r[7]:10.3e} {r[8]:10.3e} "
              f"{r[4] / (LH * rho ** 3):20.4f} {r[9]:17.2f}", flush=True)
        if N == 49 and tau == 1e-6:
            np.savez('out_unres_profile.npz', xs=xs, l=l, l_un=l_un, l_res=l_res, bankx=bank.x[:, 0], rho=rho)
np.save(f'out_unres_rows_{per_decade}.npy', np.array(rows))
