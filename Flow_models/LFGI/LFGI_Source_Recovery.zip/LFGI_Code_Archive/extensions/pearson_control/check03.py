"""Time-step convergence of the unresolved-window numbers, and sup|l_un| against distance to Voronoi faces."""
import numpy as np
from lfgi_core import sched, time_grid
from fast1d import pf1
from targets1d import CosTarget, bank_pigrid
tg = CosTarget(0.125, 2.0, nmax=14); T=8.0
N=49; bank = bank_pigrid(tg, N); rho = 12.0/(N-1)
xs = np.linspace(-2.5,2.5,3001); px=np.exp(tg.logpi(xs)); px/=px.sum()
tau=1e-6
out=[]
for per_decade in [70,140]:
    ts = time_grid(tau, T, n_log=int(per_decade*np.log10(0.3/tau)), n_lin=220 if per_decade==70 else 440)
    logq,_,_ = pf1(bank, xs, ts)
    l = tg.logpit(xs,tau)-logq
    out.append(l)
    print(f"per_decade={per_decade}: sup|l|={np.abs(l).max():.6e}  L2={np.sqrt((px*l**2).sum()):.6e}")
print("max difference between the two time grids:", np.abs(out[0]-out[1]).max())
# log-singularity at faces: points at geometric distances D from the midpoint between two bank points near x=0.9
i = np.argmin(np.abs(bank.x[:,0]-0.9)); face = 0.5*(bank.x[i,0]+bank.x[i+1,0])
D = rho*2.0**(-np.arange(1,16)); xs2 = face + D
saved = {}
for tau in [1e-5,1e-7,1e-9]:
    ts = time_grid(tau, T, n_log=int(90*np.log10(0.3/tau)), n_lin=220)
    logq,_,_ = pf1(bank, xs2, ts)
    l = tg.logpit(xs2,tau)-logq
    saved[tau] = l
    print(f"tau={tau:.0e}: l(face + D)/(L_H rho^3) for D/rho = 2^-1..2^-15:\n   " + " ".join(f"{v/(tg.LH*rho**3):7.4f}" for v in l))

np.savez('out_face_scan.npz', D=D, l_5=saved[1e-5]/tg.LH, l_7=saved[1e-7]/tg.LH, l_9=saved[1e-9]/tg.LH, rho=rho)
