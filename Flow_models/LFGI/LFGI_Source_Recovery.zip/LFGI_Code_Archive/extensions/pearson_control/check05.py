import numpy as np
from lfgi_core import lfgi, sched, time_grid, pf_forward, log_std_normal
from target2d import TanhIP
rng = np.random.default_rng(11)
tg = TanhIP(); N=150
bank = tg.bank(tg.sample(N, rng), gate='gn')
d = np.load('out_tails2d_rays.npz'); lr=d['lr']; radii=d['radii']; angles=d['angles']; ctr=d['ctr']
k8 = int(round(8/0.1))
j = np.argmax(lr[k8]); print('worst direction angle (deg):', np.degrees(angles[j]), ' log q/pi at r=8:', lr[k8,j])
jm = np.argmin(lr[k8]); print('lightest direction angle (deg):', np.degrees(angles[jm]), lr[k8,jm])
u = np.array([np.cos(angles[j]), np.sin(angles[j])])
rr = np.array([2,3,4,5,6,8.0])
pts = ctr[None]+rr[:,None]*u[None]
print('Phi along worst ray:', np.round(tg.Phi(pts),2), ' Phi at bank: min %.2f median %.2f max %.2f'%(tg.Phi(bank.x).min(), np.median(tg.Phi(bank.x)), tg.Phi(bank.x).max()))
# extreme particle in that direction and its GN matrix
e = np.argmax(bank.x@u); print('extreme particle', bank.x[e], 'B_e eig', np.linalg.eigvalsh(bank.P[e]-np.eye(2)), ' u.B_e.u =', u@(bank.P[e]-np.eye(2))@u)
for (tau,nl,nn) in [(1e-3,130,130),(1e-3,400,300),(1e-4,500,300)]:
    ts = time_grid(tau, 8.0, n_log=nl, n_lin=nn)
    yT, L, _ = pf_forward(bank, pts, ts)
    print(f'tau={tau} steps=({nl},{nn}): log q/pi along worst ray:', np.round(log_std_normal(yT)+L - tg.logpi(pts),3))
