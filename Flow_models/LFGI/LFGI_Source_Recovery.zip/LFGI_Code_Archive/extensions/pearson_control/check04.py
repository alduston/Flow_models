"""Scaling of the Monte-Carlo Pearson constant V with the Hessian-variation amplitude eps (L_H = 8 eps)."""
import numpy as np, importlib, sys
import targets1d
from lfgi_core import sched, time_grid
x0 = np.linspace(-2.0, 2.0, 41); X = np.linspace(-7, 7, 2801); dX = X[1]-X[0]; T=8.0
def V_of(eps, tau=2e-2):
    tg = targets1d.CosTarget(eps, 2.0, nmax=14)
    piX = np.exp(tg.logpi(X)); ts = time_grid(tau, T, n_log=300, n_lin=160)
    y = x0.copy(); Xi = np.zeros((len(x0), len(X)))
    def integrand(yy, tt):
        a, g = sched(tt); dy = 1e-3*np.sqrt(g)
        def gfun(yq):
            HP = tg.HP(yq, tt); A = a*a+g*HP; muP,_ = tg.post_moments(yq, tt)
            phibar = a*tg.st(yq, tt)+HP*muP
            phi = tg.s0(X)[None,:]+HP[:,None]*X[None,:]
            k = np.exp(-0.5*(yq[:,None]-a*X[None,:])**2/g)/np.sqrt(2*np.pi*g)
            return (a/A)[:,None]*k*(phi-phibar[:,None])
        return (gfun(yy+dy)-gfun(yy-dy))/(2*dy)/np.exp(tg.logpit(yy,tt))[:,None]
    vel = lambda yy,tt: -yy-tg.st(yy,tt)
    for k in range(len(ts)-1):
        t0,t1 = ts[k],ts[k+1]; h=t1-t0
        k1=vel(y,t0); i1=integrand(y,t0); ym=y+0.5*h*k1; k2=vel(ym,t0+0.5*h); ym2=y+0.5*h*k2
        k3=vel(ym2,t0+0.5*h); i23=integrand(0.5*(ym+ym2),t0+0.5*h); ye=y+h*k3; k4=vel(ye,t1); i4=integrand(ye,t1)
        Xi += h/6*(i1+4*i23+i4); y = y+h/6*(k1+2*k2+2*k3+k4)
    V = (Xi**2*piX[None,:]).sum(1)*dX - ((Xi*piX[None,:]).sum(1)*dX)**2
    w0 = np.exp(tg.logpi(x0)); w0/=w0.sum()
    return (w0*V).sum()
for eps in [1/32, 1/16, 1/8, 3/16]:
    V = V_of(eps); print(f"eps={eps:.4f}  L_H={8*eps:.3f}  V={V:.5e}  V/L_H^2={V/(8*eps)**2:.5f}")
