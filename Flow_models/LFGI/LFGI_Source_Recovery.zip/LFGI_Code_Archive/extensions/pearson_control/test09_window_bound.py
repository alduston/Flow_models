"""Tightness of Theorem (pointwise) / Corollary (unresolved window) along actual PF trajectories, d=1.

Accumulates, over the unresolved window [tau, t1] (gamma_{t1} = c * rho_grid^2):
   I_true  = int |h_t| dt                      (actual source)
   I_post  = int ( B_div + |s_t| B_e ) dt      (Theorem bound with the realized bank moments)
and reports sup_x of both, the realized cover radius rho = sup m_4, and the closed-form bound of the Corollary.
"""
import numpy as np
from lfgi_core import sched, time_grid
from fast1d import pf1
from targets1d import CosTarget, bank_pigrid, bank_iid

tg = CosTarget(eps=0.125, om=2.0, nmax=14)
LH, kappa = tg.LH, tg.kappa
T = 8.0
xs = np.linspace(-2.5, 2.5, 1501)
rng = np.random.default_rng(3)


def run(bank, rho_grid, tau, cfrac, label):
    t1 = -0.5 * np.log(1 - cfrac * rho_grid ** 2)
    ts = time_grid(tau, T, n_log=int(70 * np.log10(0.3 / tau)), n_lin=220)
    xb, Pb = bank.x[:, 0], bank.P[:, 0, 0]
    stats = dict(m4=0.0, Sstar=0.0, amin=np.inf)

    def extra(yy, tt, sh, dsh, o):
        if tt > t1:
            return np.zeros((len(yy), 2))
        a, g = sched(tt); s = a * a / g; w = (a / g) ** 2
        st = tg.st(yy, tt); e = st - sh
        dive = tg.dst(yy, tt) - dsh
        hsrc = dive + st * e
        m = o['m']; A = o['A']; muQ = o['mu']
        muP, _ = tg.post_moments(yy, tt)
        dev = np.abs(xb[None, :] - muP[:, None])
        m1 = (m * dev).sum(1); m2 = np.sqrt((m * dev ** 2).sum(1)); m4 = ((m * dev ** 4).sum(1)) ** 0.25
        sigQ = np.sqrt(o['Sig'])
        SQ = np.sqrt((m * (Pb[None, :] - o['H'][:, None]) ** 2).sum(1))
        lamP = s + kappa
        act = np.abs(sh - o['stw'])
        Be = (a / A) * (LH * m1 ** 2 + 0.5 * LH * (m2 ** 2 + 1 / lamP))
        Bdiv = (s / A) * sigQ * (LH * m1 * m2 + 0.5 * LH * m4 ** 2) + (a / A) * sigQ * SQ * act \
            + w * (2 * LH ** 2 / lamP ** 4 + (g / (A * lamP)) * LH * (m1 + np.sqrt(1 / lamP)))
        stats['m4'] = max(stats['m4'], m4.max()); stats['Sstar'] = max(stats['Sstar'], np.abs(st).max())
        stats['amin'] = min(stats['amin'], A.min())
        return np.stack([np.abs(hsrc), Bdiv + np.abs(st) * Be], 1)

    _, _, E = pf1(bank, xs, ts, extra=extra)
    a1, g1 = sched(t1); _, gtau = sched(tau)
    rho, astar, Sst = stats['m4'], min(stats['amin'], 1.0), stats['Sstar']
    drho = LH * rho
    Cun = (1 / (2 * a1 ** 2)) * ((1.5 + 1 / a1 ** 2) * rho * (Sst + 2 * drho * rho / astar) + 2 * (1 + np.sqrt(2) / a1) + 32 * drho * rho ** 2 / a1 ** 6)
    closed = (drho * rho ** 2 / astar) * (1.75 * np.log(g1 / gtau) + Cun)
    print(f"{label:22s} tau={tau:.0e} gamma1={cfrac:g}*rho_grid^2: sup int|h| = {E[:, 0].max():.3e};  theorem with realized moments = {E[:, 1].max():.3e} "
          f"(ratio {E[:, 1].max() / E[:, 0].max():5.1f});  rho=sup m4 = {rho:.3f} ({rho / rho_grid:.2f} rho_grid);  closed form = {closed:.3e} (ratio {closed / E[:, 0].max():6.1f})")


for N in [49, 97]:
    bank = bank_pigrid(tg, N); rg = 12.0 / (N - 1)
    for tau in [1e-4, 1e-6]:
        for cfrac in [1.0, 1 / 16]:
            run(bank, rg, tau, cfrac, f"pi-grid N={N}")
