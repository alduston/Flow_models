"""Two-dimensional tail structure of the LFGI-GN probability-flow surrogate (Theorem D).

Checks
  (D1) radial monotonicity about the moving centre alpha_t c:  |Phi_T(x) - alpha_T c| >= |x - alpha_tau c| - F_c
  (D2) surrogate tail mass dominated by the (shifted) prior tail
  (D3/D4) log(q/pi) along rays: reverse integrand q^2/pi decays, forward integrand pi^2/q blows up
  bulk: reverse / forward Pearson, both KL, triangular discrimination on held-out posterior samples
"""
import sys
import numpy as np
from scipy.stats import chi as chi_dist
from lfgi_core import lfgi, sched, time_grid, pf_forward, pf_sample, log_std_normal
from target2d import TanhIP

rng = np.random.default_rng(11)
tg = TanhIP()
N = int(sys.argv[1]) if len(sys.argv) > 1 else 150
tau, T = 1e-3, 8.0
ts = time_grid(tau, T, n_log=130, n_lin=130)
bank = tg.bank(tg.sample(N, rng), gate='gn')
print(f"N={N}, logZ={tg.logZ:.6f}")

# ---- Newton points, centre and the constant F_c
B_i = bank.P - np.eye(2)[None]
m_i = bank.x + np.linalg.solve(bank.P, bank.s[..., None])[..., 0]
c = np.exp(bank.logw) @ m_i
print("spread of Newton points |m_i - c|: median %.3f, max %.3f" % (np.median(np.linalg.norm(m_i - c, axis=1)), np.linalg.norm(m_i - c, axis=1).max()))


def fc_field(y, t):
    """(I + gamma B_g)^{-1} f_c at queries y."""
    a, g = sched(t)
    o = lfgi(bank, y, t, jac=False)
    m = o['m']
    Bg = o['H'] - np.eye(2)[None]
    t1 = -np.einsum('mn,nij,nj->mi', m, bank.P, m_i - c)
    dx = bank.x[None] - o['mu'][:, None]
    t2 = np.einsum('mn,nij,mnj->mi', m, B_i, dx) - np.einsum('mij,mj->mi', Bg, (m[..., None] * dx).sum(1))
    f = t1 + t2
    return np.linalg.solve(np.eye(2)[None] + g * Bg, f[..., None])[..., 0]


# ---- rays
angles = np.linspace(0, 2 * np.pi, 48, endpoint=False)
radii = np.linspace(0.0, 9.0, 91)
ctr = bank.x.mean(0)
pts = np.concatenate([ctr[None] + r * np.stack([np.cos(angles), np.sin(angles)], 1) for r in radii])
Fc_sup = [0.0]


def extra(yy, tt, o):
    v = np.linalg.norm(fc_field(yy, tt), axis=1)
    Fc_sup[0] = max(Fc_sup[0], v.max())
    return np.zeros((len(yy), 1))


yT, Ldet, _ = pf_forward(bank, pts, ts, extra=extra)
logq = log_std_normal(yT) + Ldet
logpi = tg.logpi(pts)
a_tau, _ = sched(tau); a_T, _ = sched(T)
rad_in = np.linalg.norm(pts - a_tau * c, axis=1)
rad_out = np.linalg.norm(yT - a_T * c, axis=1)
print(f"(D1) F_c (sup over visited (y,t)) = {Fc_sup[0]:.3f};  min over rays of (|Phi_T x - a_T c| - |x - a_tau c|) = {(rad_out - rad_in).min():.3f}"
      f"   -> bound requires >= -F_c*(a_tau - a_T) = {-Fc_sup[0] * (a_tau - a_T):.3f}")
lr = (logq - logpi).reshape(len(radii), len(angles))  # log q/pi
print("\nlog(q/pi) along rays (min / median / max over 48 directions):")
for r in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]:
    k = int(round(r / 0.1))
    print(f"   r={r:2d}: {lr[k].min():10.2f} {np.median(lr[k]):10.2f} {lr[k].max():10.2f}")
np.savez('out_tails2d_rays.npz', radii=radii, angles=angles, lr=lr, ctr=ctr, bankx=bank.x)

# reverse and forward tail integrals by polar quadrature outside radius R (about ctr)
dth = angles[1] - angles[0]; dr = radii[1] - radii[0]
pi_ray = np.exp(logpi).reshape(lr.shape); q_ray = np.exp(logq).reshape(lr.shape)
print("\n polar quadrature of tail integrands outside radius R (about the bank mean):")
print("    R    pi(|x-c|>R)   q(|x-c|>R)   int q^2/pi      log10 int pi^2/q")
for R in [2, 3, 4, 5, 6, 7]:
    k = radii >= R
    w = (radii[k] * dr)[:, None] * dth
    rev = (q_ray[k] ** 2 / pi_ray[k] * w).sum()
    with np.errstate(over='ignore'):
        lf = 2 * logpi.reshape(lr.shape)[k] - logq.reshape(lr.shape)[k] + np.log(w + 1e-300)
    fwd_log10 = (np.max(lf) + np.log(np.exp(lf - np.max(lf)).sum())) / np.log(10)
    print(f"   {R:2d}   {(pi_ray[k] * w).sum():.3e}    {(q_ray[k] * w).sum():.3e}   {rev:.3e}      {fwd_log10:10.1f}")

# (D2) surrogate tail mass vs shifted prior tail
z = rng.normal(size=(20000, 2))
xq, logq_s = pf_sample(bank, z, ts)
rq = np.linalg.norm(xq - a_tau * c, axis=1)
print("\n(D2) surrogate tail mass vs prior-tail bound  P(chi_2 >= r - F_c - a_T|c|):")
for r in [2.0, 2.5, 3.0, 3.5]:
    print(f"   r={r}: q-mass {np.mean(rq >= r):.4f}   bound {chi_dist.sf(max(r - Fc_sup[0] - a_T * np.linalg.norm(c), 0), 2):.4f}"
          f"   (prior mass {chi_dist.sf(r, 2):.4f})")

# ---- bulk divergences from held-out posterior samples and from surrogate samples
xp = tg.sample(6000, rng)
yT2, L2, _ = pf_forward(bank, xp, ts)
logq_p = log_std_normal(yT2) + L2
l_p = tg.logpi(xp) - logq_p           # l = log pi/q at posterior samples
l_q = tg.logpi(xq) - logq_s           # l at surrogate samples
np.savez('out_tails2d_samples.npz', xp=xp, l_p=l_p, xq=xq, l_q=l_q, logq_p=logq_p, logq_s=logq_s, logZ=tg.logZ)
r_p = np.exp(-l_p)                     # q/pi under pi
w_q = np.exp(l_q)                      # pi/q under q
print("\nheld-out posterior samples (n=6000) and surrogate samples (n=20000):")
print(f"   E_pi[q/pi] = {r_p.mean():.4f} (should be 1 - q-mass outside support ~ 1),  E_q[pi/q] = {w_q.mean():.4f}")
print(f"   reverse chi^2(q||pi) = E_pi[(q/pi)^2]-1 = {np.mean(r_p ** 2) - 1:.4f}   (max q/pi = {r_p.max():.2f})")
print(f"   forward chi^2(pi||q) sample estimate = {np.mean(w_q ** 2) - 1:.4f}   (max pi/q = {w_q.max():.2f}; top-5 weights carry {np.sort(w_q ** 2)[-5:].sum() / np.sum(w_q ** 2):.2%} of the second moment)")
print(f"   KL(pi||q) = {l_p.mean():.4f},   KL(q||pi) = {-l_q.mean():.4f},   Jeffreys = {l_p.mean() - l_q.mean():.4f}")
tri = 0.5 * (np.mean(np.tanh(l_p / 2) ** 2 * (1 + np.exp(-l_p))) + np.mean(np.tanh(l_q / 2) ** 2 * (1 + np.exp(l_q))))
print(f"   triangular discrimination Delta = int (pi+q) tanh^2(l/2) = {tri:.4f}")
print(f"   quantiles of l on posterior samples: 1% {np.quantile(l_p, .01):.3f}, 50% {np.median(l_p):.3f}, 99% {np.quantile(l_p, .99):.3f}; sd = {l_p.std():.3f}")
