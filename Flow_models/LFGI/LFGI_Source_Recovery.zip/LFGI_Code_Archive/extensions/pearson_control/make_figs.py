"""Figures for the note (static PDF, validated three-colour categorical palette)."""
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BLUE, ORANGE, AQUA = '#2a78d6', '#eb6834', '#1baf7a'
INK, MUTED, GRID, SURF = '#0b0b0b', '#52514e', '#e4e3df', '#fcfcfb'
plt.rcParams.update({
    'font.size': 8.5, 'axes.edgecolor': MUTED, 'axes.labelcolor': INK, 'text.color': INK,
    'xtick.color': MUTED, 'ytick.color': MUTED, 'axes.linewidth': 0.6, 'axes.facecolor': SURF,
    'figure.facecolor': 'white', 'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.5,
    'axes.spines.top': False, 'axes.spines.right': False, 'legend.frameon': False, 'lines.linewidth': 1.6,
    'axes.titlesize': 9, 'axes.titleweight': 'bold', 'axes.titlelocation': 'left'})

# ------------------------------------------------------------------ Fig 1: unresolved window
rows = np.load('out_unres_rows_70.npy')
prof = np.load('out_unres_profile.npz')
face = np.load('out_face_scan.npz')
fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.45))
xs, l = prof['xs'], prof['l']
rho = float(prof['rho'])
m = (xs > 0.2) & (xs < 1.6)
ax[0].plot(xs[m], l[m] / rho ** 3, color=BLUE, lw=1.0)
for b in prof['bankx']:
    if 0.2 < b < 1.6:
        ax[0].axvline(b, color=MUTED, lw=0.5, ls=':')
ax[0].set_xlabel('x'); ax[0].set_ylabel(r'$\ell(x)\,/\,(L_H\rho^3)$')
ax[0].set_title('Error sits at Voronoi faces')

for D, lab, col, mk in [(face['l_5'], r'$\tau=10^{-5}$', ORANGE, 'o'), (face['l_9'], r'$\tau=10^{-9}$', BLUE, 's')]:
    ax[1].plot(np.log2(face['D'] / rho), D / rho ** 3, color=col, marker=mk, ms=3.2, lw=1.2, label=lab)
ax[1].set_xlabel(r'$\log_2(D/\rho)$, $D$ = distance to face'); ax[1].set_ylabel(r'$\ell\,/\,(L_H\rho^3)$')
ax[1].set_title('Logarithmic in the distance')
ax[1].legend(loc='lower right', fontsize=7.5)

for N, col, mk in [(25, BLUE, 'o'), (49, ORANGE, 's'), (97, AQUA, '^')]:
    r = rows[rows[:, 0] == N]
    ax[2].plot(r[:, 9], r[:, 4] / r[:, 1] ** 3, color=col, marker=mk, ms=3.5, lw=1.2, label=f'N={N}')
    ax[2].plot(r[:, 9], r[:, 6] / r[:, 1] ** 3, color=col, marker=mk, ms=3.5, lw=1.0, ls='--', mfc='white')
ax[2].set_xlabel(r'$\log(\rho^2/\gamma_\tau)$'); ax[2].set_ylabel(r'norm of $\ell_{\rm un}$ / $(L_H\rho^3)$')
ax[2].set_title('sup grows, $L^2(\\pi)$ does not')
ax[2].legend(loc='upper left', fontsize=7)
ax[2].set_ylim(0, 0.40)
fig.tight_layout(w_pad=1.2)
fig.savefig('fig_unresolved.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Fig 2: iid banks, influence prediction
txt = open('log_test04.txt').read()
blocks = re.split(r'tau=', txt)[1:]
fig, ax = plt.subplots(1, 2, figsize=(7.4, 2.45))
for blk, col, mk in zip(blocks, [BLUE, ORANGE], ['o', 's']):
    tau = float(blk.split(':')[0])
    V = float(re.search(r'core-averaged V = ([0-9.e+-]+)', blk).group(1))
    Ns = [int(v) for v in re.findall(r'N=\s*(\d+):', blk)]
    obs = [float(v) for v in re.findall(r'core-avg = ([0-9.e+-]+)', blk)]
    ax[0].plot(Ns, np.array(obs), color=col, marker=mk, ms=4, lw=0, label=f'measured, $\\tau$={tau:g}')
ax[0].axhline(V, color=INK, lw=1.0, label=r'first-order prediction $\mathcal{V}$')

ax[0].set_xscale('log'); ax[0].set_ylim(0, 0.055)
ax[0].set_xticks([50, 100, 200, 400, 800]); ax[0].set_xticklabels(['50', '100', '200', '400', '800']); ax[0].minorticks_off()
ax[0].set_xlabel('bank size N (iid)'); ax[0].set_ylabel(r'$N\cdot\mathrm{E}\,[\ell^2]$ on the core')
ax[0].set_title('iid banks: $\\chi^2\\approx\\mathcal{V}/N$')
ax[0].legend(loc='upper left', fontsize=7.5)
eps = np.array([1 / 32, 1 / 16, 1 / 8, 3 / 16]); LH = 8 * eps
Vs = np.array([float(v) for v in re.findall(r'V=([0-9.e+-]+)', open('log_check04.txt').read())])
ax[1].loglog(LH, Vs, color=BLUE, marker='o', ms=4)
ax[1].loglog(LH, Vs[2] * (LH / LH[2]) ** 2, color=MUTED, lw=0.8, ls='--')
ax[1].text(LH[1] * 1.08, Vs[1] * 0.62, 'slope 2', color=MUTED, fontsize=7.5)
ax[1].set_xticks(LH); ax[1].set_xticklabels(['0.25', '0.5', '1', '1.5']); ax[1].minorticks_off()
ax[1].set_yticks([1e-3, 1e-2, 1e-1]); ax[1].set_ylim(8e-4, 1e-1)
ax[1].set_xlabel(r'Hessian Lipschitz constant $L_H$'); ax[1].set_ylabel(r'$\mathcal{V}$')
ax[1].set_title('The constant is Hessian variation squared')
fig.tight_layout(w_pad=1.5)
fig.savefig('fig_iid.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Fig 3: 2D tails
d = np.load('out_rays2d_fine.npz')
radii, angles, LP, LQ = d['radii'], d['angles'], d['LP'], d['LQ']
lr = LQ - LP
fig, ax = plt.subplots(1, 2, figsize=(7.4, 2.6))
k8 = np.argmin(np.abs(radii - 8.0))
jh, jl = np.argmax(lr[k8]), np.argmin(lr[k8])
med = np.median(lr, axis=1)
ax[0].plot(radii, lr[:, jh], color=ORANGE, label='heaviest direction')
ax[0].plot(radii, med, color=MUTED, lw=1.0, label='median over directions')
ax[0].plot(radii, np.clip(lr[:, jl], -60, None), color=BLUE, label='lightest direction')
ax[0].set_ylim(-60, 25)
ax[0].set_xlabel('distance r from the bank mean'); ax[0].set_ylabel(r'$\log(q/\pi)$')
ax[0].set_title('Both tail pathologies in one surrogate')
ax[0].legend(loc='lower right', fontsize=7.5)
gn = np.load('out_gn_extrap.npz')
ax[1].plot(gn['r'], gn['lr'], color=ORANGE, label=r'$\log(q/\pi)$ along the heaviest ray')
mh = gn['r'] >= 2.1
ax[1].plot(gn['r'][mh], gn['pred'][mh], color=INK, lw=1.0, ls='--', label=r'$\Phi-\Phi^{\rm GN}_e$ + const (beyond the hull)')
ax[1].set_xlabel('distance r from the bank mean'); ax[1].set_ylabel('log ratio')
ax[1].set_title('Tail ratio = Gauss-Newton extrapolation error')
ax[1].legend(loc='lower right', fontsize=7.5)
fig.tight_layout(w_pad=1.5)
fig.savefig('fig_tails2d.pdf'); plt.close(fig)
print('figures written')
