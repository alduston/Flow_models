"""Machinery checks.
 (a) analytic LFGI Jacobian vs central finite differences (d=1 and d=3, matrix gates)
 (b) exact PF log-ratio identity  l_tau(x) = l_T(Phi_T x) - int h_t(Phi_t x) dt
 (c) Gaussian exactness for arbitrary banks
 (d) the gradient identity  grad e = A^{-1}[ a Cov_Q(Pa,X) + s (Cov_P(phi,X) - Cov_Q(phi,X)) ]
     with the Stein form Cov_P(phi,X) = A Sigma_P / gamma - I
"""
import numpy as np
from lfgi_core import Bank, lfgi, sched, time_grid, pf_logq, log_std_normal
from targets1d import CosTarget, bank_quantile, bank_iid

rng = np.random.default_rng(0)

# ---------- (a) Jacobian vs finite differences, d = 3 with random SPD gates
d, N, M = 3, 12, 7
x = rng.normal(size=(N, d))
s = rng.normal(size=(N, d))
R = rng.normal(size=(N, d, d))
P = np.einsum('nij,nkj->nik', R, R) + 0.3 * np.eye(d)
bank = Bank(x, rng.normal(size=N), s, P)
y = rng.normal(size=(M, d))
for t in [0.02, 0.3, 1.5]:
    o = lfgi(bank, y, t)
    Jfd = np.zeros((M, d, d))
    h = 1e-5
    for j in range(d):
        e = np.zeros(d); e[j] = h
        Jfd[:, :, j] = (lfgi(bank, y + e, t, jac=False)['shat'] - lfgi(bank, y - e, t, jac=False)['shat']) / (2 * h)
    print(f"(a) d=3 t={t}: max |J - J_fd| = {np.abs(o['J'] - Jfd).max():.2e}  (|J|max={np.abs(o['J']).max():.2e})")

# ---------- (b) exact log-ratio identity on the cosine target
tg = CosTarget(eps=0.125, om=2.0)
bank = bank_quantile(tg, 64)
tau, T = 1e-3, 8.0
ts = time_grid(tau, T, n_log=900, n_lin=300)
xs = np.linspace(-2.5, 2.5, 41)[:, None]


def extra(yy, tt, o):
    a, g = sched(tt)
    st = tg.st(yy[:, 0], tt)
    e = st - o['shat'][:, 0]
    dive = tg.dst(yy[:, 0], tt) - o['div']
    hsrc = dive + st * e
    return np.stack([hsrc, np.abs(hsrc), e ** 2], 1)


logq, yT, E = pf_logq(bank, xs, ts, extra=extra)
l_direct = tg.logpit(xs[:, 0], tau) - logq
l_T = tg.logpit(yT[:, 0], T) - log_std_normal(yT)
l_ident = l_T - E[:, 0]
print(f"(b) identity: max|l_direct - (l_T - int h)| = {np.abs(l_direct - l_ident).max():.2e};  max|l| = {np.abs(l_direct).max():.3e};  max|l_T| = {np.abs(l_T).max():.2e}")

# ---------- (c) Gaussian exactness: arbitrary bank, constant Hessian
lam = 3.7
xg = rng.normal(size=(9, 1)) * 2
bankG = Bank(xg, rng.normal(size=9), -lam * (xg - 0.4), np.full((9, 1, 1), lam))
xs2 = np.linspace(-1, 2, 9)[:, None]
logqG, _, _ = pf_logq(bankG, xs2, time_grid(1e-4, 10.0, 600, 400))
# exact PF endpoint from N(0,1) base at T: N(mu_t, C_t) with C_t = a^2/lam + g
a, g = sched(1e-4); C = a * a / lam + g
ref = -0.5 * (xs2[:, 0] - a * 0.4) ** 2 / C - 0.5 * np.log(2 * np.pi * C)
print(f"(c) Gaussian exactness (random 9-point bank): max|log q - log pi_tau| = {np.abs(logqG - ref).max():.2e}")

# ---------- (d) gradient identity for e (d=1 uses exact target posterior moments)
for bank_, name in [(bank_quantile(tg, 24), 'quantile N=24'), (bank_iid(tg, 24, rng), 'iid N=24')]:
    worst = 0.0
    for t in [3e-3, 3e-2, 0.2, 1.0]:
        a, g = sched(t)
        yq = np.linspace(-2, 2, 33)
        o = lfgi(bank_, yq[:, None], t)
        m = o['m']; xb = bank_.x[:, 0]; Pb = bank_.P[:, 0, 0]; sb = bank_.s[:, 0]
        Hg = o['H'][:, 0, 0]; A = o['A'][:, 0, 0]; muQ = o['mu'][:, 0]
        shat = o['shat'][:, 0]; stw = o['stw'][:, 0]
        act = shat - stw
        phi = sb[None, :] + Hg[:, None] * xb[None, :]
        phibar = (m * phi).sum(1)
        covQ_phiX = (m * (phi - phibar[:, None]) * (xb[None, :] - muQ[:, None])).sum(1)
        covQ_PaX = (m * (Pb[None, :] - Hg[:, None]) * act[:, None] * (xb[None, :] - muQ[:, None])).sum(1)
        muP, varP = tg.post_moments(yq, t)
        covP_phiX = A * varP / g - 1.0
        grad_e_formula = (a * covQ_PaX + (a * a / g) * (covP_phiX - covQ_phiX)) / A
        grad_e_direct = tg.dst(yq, t) - o['div']
        worst = max(worst, np.abs(grad_e_formula - grad_e_direct).max() / (1e-12 + np.abs(grad_e_direct).max()))
    print(f"(d) grad-e identity, {name}: max relative mismatch over t = {worst:.2e}")
