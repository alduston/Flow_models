# Pearson control of LFGI probability-flow densities: scripts and logs

Companion to `note/lfgi_pearson_control.pdf` (12 November 2026).

## Layout

- `note/` : LaTeX source, the three figures, compiled PDF.
- `lfgi_core.py` : general-d finite-reference LFGI field with exact Jacobian, RK4 probability flow, log-density.
- `fast1d.py` : vectorised 1D version of the same.
- `targets1d.py` : cosine-perturbed Gaussian with exact OU marginals (Jacobi-Anger), bank builders.
- `target2d.py` : 2D tanh inverse problem (prior N(0,I), two observations, noise 0.25), Gauss-Newton gates.
- `make_figs.py` : regenerates the three figures from the `out_*` files and logs.

## Tests, and where each number in the note comes from

| Script | Log | Used in |
|---|---|---|
| `test01_machinery.py` | `log_test01.txt` | Table 1 |
| `test02_pointwise.py` | `log_test02.txt` | Theorem 6 check (worst ratios 0.998, 0.987) |
| `test03_unresolved.py 70` | `log_test03.txt` | Table 2, Figure 1 right |
| `check03.py` | `log_check03.txt` | Figure 1 middle (face scan) |
| `test09_window_bound.py` | `log_test09.txt` | tightness factors in Section 5 |
| `test04_influence.py`, `check04.py` | `log_test04.txt`, `log_check04.txt` | Section 6, Figure 2 |
| `test05_tails2d.py` | `log_test05_N150.txt` | Section 7 bulk numbers |
| `test05b_rays.py` | `log_test05b.txt` | Table 3 |
| `test08_gn_extrap.py` | `log_test08.txt` | Remark 13 check, Figure 3 right |
| `test06_estimators.py` | `log_test06.txt` | Table 4 left block, Lemma 3 constants, entropy |
| `test07_smallbank.py` | `log_test07.txt` | Table 4 right block |

All scripts are seeded and run from this directory with `python3 <script>`.
Approximate run times on two cores: test03 4 min, test05 20 min, test05b 35 min, the rest under 3 min each.

Requirements: numpy, scipy, matplotlib.
