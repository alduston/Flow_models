"""Core machinery: OU schedule, weighted reference banks, the finite-reference LFGI
field with its exact Jacobian, and the frozen probability-flow (PF) density.

Conventions follow the 14 Oct 2026 coverage note:
  alpha_t = exp(-t), gamma_t = 1 - exp(-2t), K_t(y|x) = N(y; alpha x, gamma I)
  shat = A_g^{-1} { alpha E_Q s0 + H_g (alpha E_Q X - y) },  A_g = alpha^2 I + gamma H_g
  PF (forward in t):  dy/dt = -y - shat(y,t);   q_tau = pull-back of b_T = N(0,I).
"""
import numpy as np
from scipy.special import logsumexp


def sched(t):
    a = np.exp(-t)
    g = -np.expm1(-2.0 * t)
    return a, g


class Bank:
    """Weighted bank: points x (N,d), log-weights (N,), scores s0(x_i) (N,d), gates P_i (N,d,d)."""

    def __init__(self, x, logw, s, P):
        self.x = np.atleast_2d(x)
        self.N, self.d = self.x.shape
        self.logw = np.asarray(logw, float) - logsumexp(logw)
        self.s = np.atleast_2d(s)
        self.P = np.asarray(P, float).reshape(self.N, self.d, self.d)


def lfgi(bank, y, t, jac=True):
    """Finite-reference LFGI field at queries y (M,d), time t (scalar).

    Returns dict with shat (M,d), div (M,), J (M,d,d) and bank-posterior moments.
    The Jacobian is the exact derivative of the frozen field (weights and gate
    differentiated), cf. Prop. 'closed-form divergence' of the LFGI manuscript.
    """
    a, g = sched(t)
    d = bank.d
    y = np.atleast_2d(y)
    diff = y[:, None, :] - a * bank.x[None, :, :]
    lw = bank.logw[None, :] - 0.5 * np.sum(diff * diff, -1) / g
    lw = lw - logsumexp(lw, axis=1, keepdims=True)
    m = np.exp(lw)  # (M,N) posterior weights of Q_{y,t}
    mu = m @ bank.x
    sbar = m @ bank.s
    H = np.einsum('mn,nij->mij', m, bank.P)
    A = a * a * np.eye(d)[None] + g * H
    u = a * sbar + np.einsum('mij,mj->mi', H, a * mu - y)
    shat = np.linalg.solve(A, u[..., None])[..., 0]
    out = dict(shat=shat, m=m, mu=mu, sbar=sbar, H=H, A=A)
    if not jac:
        return out
    dx = bank.x[None] - mu[:, None]
    ds = bank.s[None] - sbar[:, None]
    Sig = np.einsum('mn,mni,mnj->mij', m, dx, dx)
    CsX = np.einsum('mn,mni,mnj->mij', m, ds, dx)
    stw = (a * mu - y) / g  # Tweedie score of the bank
    v = a * (stw - shat)
    Pv = np.einsum('nij,mj->mni', bank.P, v) - np.einsum('mij,mj->mi', H, v)[:, None, :]
    K = np.einsum('mn,mni,mnj->mij', m, Pv, dx)
    s_ = a * a / g
    rhs = s_ * CsX + s_ * np.einsum('mik,mkj->mij', H, Sig) - H + K
    J = np.linalg.solve(A, rhs)
    out.update(J=J, div=np.trace(J, axis1=1, axis2=2), Sig=Sig, stw=stw, dx=dx)
    return out


def time_grid(tau, T, n_log=600, n_lin=200, t_switch=0.3):
    """Log-spaced on [tau, t_switch], linear on [t_switch, T]."""
    if tau >= t_switch:
        return np.linspace(tau, T, n_lin + 1)
    a = np.exp(np.linspace(np.log(tau), np.log(t_switch), n_log + 1))
    b = np.linspace(t_switch, T, n_lin + 1)[1:]
    return np.concatenate([a, b])


def pf_forward(bank, x, ts, extra=None, chunk=20000):
    """Integrate the frozen PF from tau=ts[0] to T=ts[-1] starting at x (M,d).

    Returns (y_T, logdet) with logdet = int div v dt, so that
        log q_tau(x) = log N(y_T; 0, I) + logdet.
    `extra(y,t,out)` may return an (M,k) array of additional integrands accumulated
    with the same RK4 weights (e.g. the weighted-divergence source h_t).
    """
    x = np.atleast_2d(x)
    M, d = x.shape
    res_y, res_L, res_E = [], [], []
    for c0 in range(0, M, chunk):
        y = x[c0:c0 + chunk].copy()
        L = np.zeros(y.shape[0])
        E = None

        def f(yy, tt):
            o = lfgi(bank, yy, tt)
            vy = -yy - o['shat']
            vl = -d - o['div']
            ve = extra(yy, tt, o) if extra is not None else None
            return vy, vl, ve

        for k in range(len(ts) - 1):
            t0, t1 = ts[k], ts[k + 1]
            h = t1 - t0
            k1 = f(y, t0)
            k2 = f(y + 0.5 * h * k1[0], t0 + 0.5 * h)
            k3 = f(y + 0.5 * h * k2[0], t0 + 0.5 * h)
            k4 = f(y + h * k3[0], t1)
            y = y + h / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])
            L = L + h / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])
            if extra is not None:
                inc = h / 6 * (k1[2] + 2 * k2[2] + 2 * k3[2] + k4[2])
                E = inc if E is None else E + inc
        res_y.append(y)
        res_L.append(L)
        res_E.append(E)
    yT = np.concatenate(res_y)
    L = np.concatenate(res_L)
    E = np.concatenate(res_E) if extra is not None else None
    return yT, L, E


def log_std_normal(y):
    y = np.atleast_2d(y)
    d = y.shape[1]
    return -0.5 * np.sum(y * y, -1) - 0.5 * d * np.log(2 * np.pi)


def pf_logq(bank, x, ts, extra=None):
    yT, L, E = pf_forward(bank, x, ts, extra=extra)
    return log_std_normal(yT) + L, yT, E


def pf_sample(bank, z, ts):
    """Generation direction: integrate from T down to tau starting at z ~ N(0,I).
    Returns (x_tau, log q_tau(x_tau))."""
    z = np.atleast_2d(z)
    d = z.shape[1]
    y = z.copy()
    L = np.zeros(y.shape[0])

    def f(yy, tt):
        o = lfgi(bank, yy, tt)
        return -yy - o['shat'], -d - o['div']

    tr = ts[::-1]
    for k in range(len(tr) - 1):
        t0, t1 = tr[k], tr[k + 1]
        h = t1 - t0  # negative
        k1 = f(y, t0)
        k2 = f(y + 0.5 * h * k1[0], t0 + 0.5 * h)
        k3 = f(y + 0.5 * h * k2[0], t0 + 0.5 * h)
        k4 = f(y + h * k3[0], t1)
        y = y + h / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])
        L = L + h / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])
    # log q_tau(x) = log b_T(z) + int_tau^T div v dt = log b_T(z) - L  (L integrates T -> tau)
    return y, log_std_normal(z) - L
