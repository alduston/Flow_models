"""Two-dimensional prior-dominated inverse problem (whitened prior N(0,I)).

  pi(x) = Z^{-1} phi_2(x) exp(-Phi(x)),   Phi(x) = sum_k (y_k - tanh(a_k.x + c_k))^2 / (2 sigma^2)
  Z = E_prior[exp(-Phi)]  is the model evidence (computed by quadrature).
Gauss-Newton gate:  P(x) = I + B(x),  B = sum_k (1 - T_k^2)^2 a_k a_k^T / sigma^2  (PSD).
"""
import numpy as np
from lfgi_core import Bank


class TanhIP:
    def __init__(self, a=((1.2, 0.5), (-0.5, 1.0)), c=(0.2, -0.1), sigma=0.25,
                 xtrue=(0.7, -0.5), noise=(0.11, -0.07), L=9.0, n=1801):
        self.a = np.array(a, float)
        self.c = np.array(c, float)
        self.sigma = sigma
        self.yobs = np.tanh(self.a @ np.array(xtrue) + self.c) + sigma * np.array(noise)
        g = np.linspace(-L, L, n)
        self.g, self.dg = g, g[1] - g[0]
        X1, X2 = np.meshgrid(g, g, indexing='ij')
        P = np.stack([X1.ravel(), X2.ravel()], 1)
        lp = self.logpi_un(P)
        self.logZ = np.log(np.sum(np.exp(lp - lp.max())) * self.dg ** 2) + lp.max()
        self._pgrid = np.exp(lp - self.logZ).reshape(n, n)

    def T(self, x):
        return np.tanh(x @ self.a.T + self.c)

    def Phi(self, x):
        return 0.5 * np.sum((self.yobs - self.T(x)) ** 2, -1) / self.sigma ** 2

    def gradPhi(self, x):
        T = self.T(x)
        return -((self.yobs - T) * (1 - T ** 2)) @ self.a / self.sigma ** 2

    def B(self, x):
        T = self.T(x)
        w = (1 - T ** 2) ** 2 / self.sigma ** 2  # (M,m)
        return np.einsum('mk,ki,kj->mij', w, self.a, self.a)

    def hessPhi(self, x):
        T = self.T(x)
        w = ((1 - T ** 2) ** 2 + 2 * (self.yobs - T) * T * (1 - T ** 2)) / self.sigma ** 2
        return np.einsum('mk,ki,kj->mij', w, self.a, self.a)

    def logpi_un(self, x):  # log of phi_2 * exp(-Phi)
        return -0.5 * np.sum(x * x, -1) - np.log(2 * np.pi) - self.Phi(x)

    def logpi(self, x):
        return self.logpi_un(x) - self.logZ

    def s0(self, x):
        return -x - self.gradPhi(x)

    def sample(self, n, rng):
        """Exact-up-to-grid posterior draws: pick a grid cell by mass, jitter uniformly inside."""
        p = self._pgrid.ravel() * self.dg ** 2
        idx = rng.choice(p.size, size=n, p=p / p.sum())
        i, j = np.unravel_index(idx, self._pgrid.shape)
        x = np.stack([self.g[i], self.g[j]], 1) + (rng.uniform(size=(n, 2)) - 0.5) * self.dg
        return x

    def bank(self, x, gate='gn'):
        x = np.atleast_2d(x)
        I = np.eye(2)[None]
        P = I + (self.B(x) if gate == 'gn' else self.hessPhi(x))
        return Bank(x, np.zeros(len(x)), self.s0(x), P)
