"""Stress case: the same 2D inverse problem with a deliberately small bank (N = 25), so that the
uncovered posterior mass is not negligible.  Shows how each evidence estimator fails or survives."""
import numpy as np
from lfgi_core import time_grid, pf_forward, pf_sample, log_std_normal
from target2d import TanhIP

rng = np.random.default_rng(21)
tg = TanhIP()
N = 25
tau, T = 1e-3, 8.0
ts = time_grid(tau, T, n_log=130, n_lin=130)
bank = tg.bank(tg.sample(N, rng), gate='gn')
logZ = tg.logZ

xp = tg.sample(6000, rng)
yT, L, _ = pf_forward(bank, xp, ts)
logq_p = log_std_normal(yT) + L
l_p = tg.logpi(xp) - logq_p
z = rng.normal(size=(12000, 2))
xq, logq_s = pf_sample(bank, z, ts)
l_q = tg.logpi(xq) - logq_s
np.savez('out_smallbank.npz', l_p=l_p, l_q=l_q, logq_p=logq_p, logq_s=logq_s)

print(f"N={N}: l on posterior samples: sd {l_p.std():.3f}, quantiles 0.1%/1%/50%/99%/99.9%: "
      + ", ".join(f"{np.quantile(l_p, q):.2f}" for q in [.001, .01, .5, .99, .999]) + f", max {l_p.max():.2f}")
print(f"   l on surrogate samples: quantiles 0.1%/1%/50%/99%/99.9%: "
      + ", ".join(f"{np.quantile(l_q, q):.2f}" for q in [.001, .01, .5, .99, .999]))
print(f"   E_pi[q/pi] = {np.mean(np.exp(-l_p)):.4f}   E_q[pi/q] = {np.mean(np.exp(l_q)):.4f}   (each equals 1 if the other law's mass is fully seen)")
print(f"   sample chi2(q||pi) = {np.mean(np.exp(-2 * l_p)) - 1:.4f} (largest term carries {np.exp(-2 * l_p).max() / np.exp(-2 * l_p).sum():.1%}),"
      f"  sample chi2(pi||q) = {np.mean(np.exp(2 * l_q)) - 1:.4f} (largest term carries {np.exp(2 * l_q).max() / np.exp(2 * l_q).sum():.1%})")
print(f"   KL(pi||q) = {l_p.mean():.4f}, KL(q||pi) = {-l_q.mean():.4f}")
for Lcap in [0.5, 1.0, 2.0]:
    print(f"   pi-mass of {{l > {Lcap}}} (surrogate too light): {np.mean(l_p > Lcap):.4f};   q-mass of {{l < -{Lcap}}} (surrogate too heavy): {np.mean(l_q < -Lcap):.4f}")

lt_p, lt_q = l_p + logZ, l_q + logZ


def bridge(l1, l2, iters=300):
    n2, n1 = len(l1), len(l2)
    s1, s2 = n1 / (n1 + n2), n2 / (n1 + n2)
    r = np.exp(np.median(l1))
    e1, e2 = np.exp(l1), np.exp(l2)
    for _ in range(iters):
        r = np.mean(e1 / (s1 * e1 + s2 * r)) / np.mean(1.0 / (s1 * e2 + s2 * r))
    return np.log(r)


c99 = np.quantile(logq_s[6000:], 0.01)
qS = np.mean(logq_s[6000:] >= c99)
n = M = 500
K = 12
est = {k: [] for k in ['forward IS', 'reciprocal IS', 'truncated forward (99% HPD)', 'truncated reciprocal (99% HPD)', 'bridge', 'ELBO', 'EUBO']}
for k in range(K):
    a, b = lt_q[k * M:(k + 1) * M], lt_p[k * n:(k + 1) * n]
    Sq, Sp = logq_s[k * M:(k + 1) * M] >= c99, logq_p[k * n:(k + 1) * n] >= c99
    est['forward IS'].append(np.log(np.mean(np.exp(a))))
    est['reciprocal IS'].append(-np.log(np.mean(np.exp(-b))))
    est['truncated forward (99% HPD)'].append(np.log(np.mean(np.exp(a) * Sq)) - np.log(np.mean(Sp)))
    est['truncated reciprocal (99% HPD)'].append(-np.log(np.mean(np.exp(-b) * Sp)) + np.log(qS))
    est['bridge'].append(bridge(a, b))
    est['ELBO'].append(np.mean(a)); est['EUBO'].append(np.mean(b))
print(f"\ntrue log Z = {logZ:.4f}; K={K} replicates with n=M={n};  S = surrogate 99% HPD: q(S)={qS:.3f}, pi(S)={np.mean(logq_p >= c99):.3f}")
print(f"{'estimator':32s} {'mean error':>11s} {'RMSE':>9s} {'worst':>9s}")
for name, v in est.items():
    v = np.array(v) - logZ
    print(f"{name:32s} {v.mean():11.4f} {np.sqrt(np.mean(v ** 2)):9.4f} {v[np.argmax(np.abs(v))]:9.4f}")
