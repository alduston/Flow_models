"""One-dimensional targets with exact OU marginals.

CosTarget:  pi(x) ∝ phi(x) exp(-eps cos(om x)),  U = x^2/2 + eps cos(om x)
            H0 = 1 - eps om^2 cos(om x),  L_H = eps om^3.
            pi_t(y) = phi(y) G_t(y) / Z0 with a Jacobi-Anger series for G_t (exact).
QuadTarget: generic pi ∝ exp(-U) with pi_t by quadrature (fixed grid + Gauss-Hermite at small t).
"""
import numpy as np
from scipy.special import ive, iv
from lfgi_core import sched, Bank


class CosTarget:
    def __init__(self, eps, om=2.0, nmax=60):
        self.eps, self.om = eps, om
        n = np.arange(1, nmax + 1)
        self.n = n
        self.c0 = iv(0, eps)
        self.cn = 2.0 * (-1.0) ** n * iv(n, eps)
        self.Z0 = self.c0 + np.sum(self.cn * np.exp(-0.5 * (n * om) ** 2))
        self.LH = eps * om ** 3
        self.kappa = 1 - eps * om ** 2

    # clean quantities
    def U(self, x):
        return 0.5 * x * x + self.eps * np.cos(self.om * x)

    def s0(self, x):
        return -x + self.eps * self.om * np.sin(self.om * x)

    def H0(self, x):
        return 1 - self.eps * self.om ** 2 * np.cos(self.om * x)

    def logpi(self, x):
        return -self.U(x) - 0.5 * np.log(2 * np.pi) - np.log(self.Z0)

    # OU marginal: G_t(y) = c0 + sum cn exp(-n^2 om^2 g/2) cos(n om a y)
    def _G(self, y, t, order=2):
        a, g = sched(t)
        y = np.asarray(y, float)
        k = self.n * self.om * a
        amp = self.cn * np.exp(-0.5 * (self.n * self.om) ** 2 * g)
        ky = np.multiply.outer(y, k)
        G = self.c0 + np.cos(ky) @ amp
        G1 = -(np.sin(ky) * k) @ amp
        G2 = -(np.cos(ky) * k * k) @ amp
        return G, G1, G2

    def logpit(self, y, t):
        G, _, _ = self._G(y, t)
        return -0.5 * y * y - 0.5 * np.log(2 * np.pi) + np.log(G) - np.log(self.Z0)

    def st(self, y, t):
        G, G1, _ = self._G(y, t)
        return -y + G1 / G

    def dst(self, y, t):
        G, G1, G2 = self._G(y, t)
        return -1 + G2 / G - (G1 / G) ** 2

    def post_moments(self, y, t):
        """Mean and variance of the target OU posterior P_{y,t}."""
        a, g = sched(t)
        s = self.st(y, t)
        mu = (y + g * s) / a
        var = g * (1 + g * self.dst(y, t)) / a ** 2
        return mu, var


    def EPcos(self, y, t):
        """E_P[cos(om X)] for the OU posterior P_{y,t} (exact series, = -d/d eps log G_t)."""
        a, g = sched(t)
        y = np.asarray(y, float)
        n = self.n
        dcn = 2.0 * (-1.0) ** n * 0.5 * (iv(n - 1, self.eps) + iv(n + 1, self.eps))
        dc0 = iv(1, self.eps)
        k = n * self.om * a
        damp = np.exp(-0.5 * (n * self.om) ** 2 * g)
        ky = np.multiply.outer(y, k)
        G = self.c0 + np.cos(ky) @ (self.cn * damp)
        dG = dc0 + np.cos(ky) @ (dcn * damp)
        return -dG / G

    def HP(self, y, t):
        """Posterior-averaged observed information E_P[H0]."""
        return 1 - self.eps * self.om ** 2 * self.EPcos(y, t)

    # sampling utilities
    def grid_cdf(self, L=10.0, n=400001):
        x = np.linspace(-L, L, n)
        p = np.exp(self.logpi(x))
        c = np.cumsum(p) * (x[1] - x[0])
        c /= c[-1]
        return x, c

    def quantiles(self, u):
        x, c = self.grid_cdf()
        return np.interp(u, c, x)


class QuadTarget:
    """Generic 1D target pi ∝ exp(-U); OU marginals by quadrature.

    U, dU, d2U are vectorised callables.  For t with kernel width sqrt(g)/a below
    `gh_switch` a Gauss-Hermite rule centred at y/a is used, otherwise a fixed grid.
    """

    def __init__(self, U, dU, d2U, L=12.0, n=24001, gh_n=120, gh_switch=0.15):
        self.U_, self.dU_, self.d2U_ = U, dU, d2U
        self.xg = np.linspace(-L, L, n)
        self.dx = self.xg[1] - self.xg[0]
        self.logZ = np.log(np.sum(np.exp(-U(self.xg))) * self.dx)
        self.pg = np.exp(-U(self.xg) - self.logZ)
        self.ghx, self.ghw = np.polynomial.hermite_e.hermegauss(gh_n)
        self.ghw = self.ghw / np.sqrt(2 * np.pi)
        self.gh_switch = gh_switch

    def U(self, x):
        return self.U_(x)

    def s0(self, x):
        return -self.dU_(x)

    def H0(self, x):
        return self.d2U_(x)

    def logpi(self, x):
        return -self.U_(x) - self.logZ

    def _moments(self, y, t, kmax=2):
        """Return pi_t(y) and E_P[(X - y/a)^k], k=1..kmax, for the OU posterior."""
        a, g = sched(t)
        y = np.asarray(y, float)
        z = y / a
        w = np.sqrt(g) / a
        if w < self.gh_switch:
            X = z[:, None] + w * self.ghx[None, :]
            f = np.exp(self.logpi(X)) * self.ghw[None, :]
            m0 = f.sum(1)
            mom = [(f * (X - z[:, None]) ** k).sum(1) / m0 for k in range(1, kmax + 1)]
            return m0 / a, mom
        D = self.xg[None, :] - z[:, None]
        ker = np.exp(-0.5 * (D / w) ** 2) / (np.sqrt(2 * np.pi) * w) * self.pg[None, :] * self.dx
        m0 = ker.sum(1)
        mom = [(ker * D ** k).sum(1) / m0 for k in range(1, kmax + 1)]
        return m0 / a, mom

    def logpit(self, y, t):
        p, _ = self._moments(y, t, 0)
        return np.log(p)

    def post_moments(self, y, t):
        a, g = sched(t)
        _, (m1, m2) = self._moments(y, t, 2)
        mu = y / a + m1
        return mu, m2 - m1 ** 2

    def st(self, y, t):
        a, g = sched(t)
        mu, _ = self.post_moments(y, t)
        return (a * mu - y) / g

    def dst(self, y, t):
        a, g = sched(t)
        _, var = self.post_moments(y, t)
        return a * a * var / g ** 2 - 1 / g

    def grid_cdf(self):
        c = np.cumsum(self.pg) * self.dx
        return self.xg, c / c[-1]

    def quantiles(self, u):
        x, c = self.grid_cdf()
        return np.interp(u, c, x)


# ---------------------------------------------------------------- banks
def bank_from_points(target, x, logw=None, gate='exact', gate_fn=None):
    x = np.asarray(x, float).ravel()
    N = len(x)
    if logw is None:
        logw = np.zeros(N)
    if gate == 'exact':
        P = target.H0(x)
    else:
        P = gate_fn(x)
    return Bank(x[:, None], logw, target.s0(x)[:, None], P[:, None, None])


def bank_quantile(target, N, **kw):
    u = (np.arange(N) + 0.5) / N
    return bank_from_points(target, target.quantiles(u), **kw)


def bank_pigrid(target, N, L=6.0, **kw):
    x = np.linspace(-L, L, N)
    return bank_from_points(target, x, logw=target.logpi(x), **kw)


def bank_iid(target, N, rng, **kw):
    return bank_from_points(target, target.quantiles(rng.uniform(size=N)), **kw)
