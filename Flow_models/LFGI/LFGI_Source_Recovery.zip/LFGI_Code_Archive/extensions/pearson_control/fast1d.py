"""Fast scalar (d=1) path for the LFGI field, its derivative and the PF integrator."""
import numpy as np
from lfgi_core import sched


def lfgi1(xb, lwb, sb, Pb, y, t, jac=True):
    """xb,lwb,sb,Pb: bank arrays (N,).  y: (M,).  Returns shat, dshat (and moments)."""
    a, g = sched(t)
    diff = y[:, None] - a * xb[None, :]
    lw = lwb[None, :] - 0.5 * diff * diff / g
    lw -= lw.max(1, keepdims=True)
    m = np.exp(lw)
    m /= m.sum(1, keepdims=True)
    mu = m @ xb
    sbar = m @ sb
    H = m @ Pb
    A = a * a + g * H
    shat = (a * sbar + H * (a * mu - y)) / A
    if not jac:
        return shat, None, dict(m=m, mu=mu, H=H, A=A)
    dx = xb[None, :] - mu[:, None]
    Sig = (m * dx * dx).sum(1)
    CsX = (m * (sb[None, :] - sbar[:, None]) * dx).sum(1)
    CPX = (m * (Pb[None, :] - H[:, None]) * dx).sum(1)
    stw = (a * mu - y) / g
    v = a * (stw - shat)
    s_ = a * a / g
    dshat = (s_ * CsX + s_ * H * Sig - H + CPX * v) / A
    return shat, dshat, dict(m=m, mu=mu, H=H, A=A, Sig=Sig, stw=stw, CPX=CPX)


def pf1(bank, x, ts, extra=None):
    """Forward PF tau -> T for scalar problems. Returns (log q_tau(x), y_T, extras)."""
    xb, lwb, sb, Pb = bank.x[:, 0], bank.logw, bank.s[:, 0], bank.P[:, 0, 0]
    y = np.array(x, float)
    L = np.zeros_like(y)
    E = None

    def f(yy, tt):
        sh, dsh, o = lfgi1(xb, lwb, sb, Pb, yy, tt)
        ve = extra(yy, tt, sh, dsh, o) if extra is not None else None
        return -yy - sh, -1.0 - dsh, ve

    for k in range(len(ts) - 1):
        t0, t1 = ts[k], ts[k + 1]
        h = t1 - t0
        k1 = f(y, t0)
        k2 = f(y + 0.5 * h * k1[0], t0 + 0.5 * h)
        k3 = f(y + 0.5 * h * k2[0], t0 + 0.5 * h)
        k4 = f(y + h * k3[0], t1)
        y = y + h / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])
        L = L + h / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])
        if extra is not None:
            inc = h / 6 * (k1[2] + 2 * k2[2] + 2 * k3[2] + k4[2])
            E = inc if E is None else E + inc
    logq = -0.5 * y * y - 0.5 * np.log(2 * np.pi) + L
    return logq, y, E


def pf1_sample(bank, z, ts):
    """Generation direction T -> tau from z ~ N(0,1). Returns (x, log q_tau(x))."""
    xb, lwb, sb, Pb = bank.x[:, 0], bank.logw, bank.s[:, 0], bank.P[:, 0, 0]
    y = np.array(z, float)
    L = np.zeros_like(y)

    def f(yy, tt):
        sh, dsh, _ = lfgi1(xb, lwb, sb, Pb, yy, tt)
        return -yy - sh, -1.0 - dsh

    tr = ts[::-1]
    for k in range(len(tr) - 1):
        t0, t1 = tr[k], tr[k + 1]
        h = t1 - t0
        k1 = f(y, t0)
        k2 = f(y + 0.5 * h * k1[0], t0 + 0.5 * h)
        k3 = f(y + 0.5 * h * k2[0], t0 + 0.5 * h)
        k4 = f(y + h * k3[0], t1)
        y = y + h / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])
        L = L + h / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])
    return y, -0.5 * z * z - 0.5 * np.log(2 * np.pi) - L
