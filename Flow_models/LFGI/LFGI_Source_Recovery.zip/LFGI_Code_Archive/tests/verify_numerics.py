#!/usr/bin/env python3
"""Independent numerical checks of the recovered computational core."""
import argparse
import importlib.util
import json
import math
from pathlib import Path
import sys
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'recovered/inverse'))
import sampling_uniform_blends as ip

def load_validation():
    spec = importlib.util.spec_from_file_location('lfgi_validation', ROOT / 'recovered/validation/claim_validation_sweep.py')
    m = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = m
    spec.loader.exec_module(m)
    m.set_runtime('cpu', 'float64', 2026)
    return m

def main():
    p = argparse.ArgumentParser(); p.add_argument('--output', type=Path, default=Path('numerical_checks.json'))
    args = p.parse_args()
    torch.set_default_dtype(torch.float64); torch.set_num_threads(1)
    torch.manual_seed(2026)
    cv = load_validation()
    P = torch.tensor([[3.0, 0.4], [0.4, 1.2]])
    mu = torch.tensor([0.3, -0.2])
    y = torch.randn(8, 2)
    errors = []
    for ns, ng in [(1, 1), (7, 5)]:
        x, xg = 2*torch.randn(ns, 2)+1, 2*torch.randn(ng, 2)-1
        bank = cv.ReferenceBank(x, -(x-mu)@P, P.expand(ns,2,2).clone())
        gate = cv.ReferenceBank(xg, -(xg-mu)@P, P.expand(ng,2,2).clone())
        for t in [0.003, 0.1, 1.0, 3.0]:
            a, g = math.exp(-t), -math.expm1(-2*t)
            exact = -(y-a*mu) @ torch.linalg.inv(a*a*torch.linalg.inv(P)+g*torch.eye(2))
            actual = cv.estimate_score_chunk(y,t,bank,'lfgi',gate_ref=gate)
            errors.append(float((actual-exact).abs().max()))
    gaussian_max = max(errors)
    if gaussian_max > 2e-10:
        raise AssertionError(f'Gaussian cancellation error {gaussian_max}')

    # Varying, positive Hessians ensure the gate-derivative term is exercised.
    x, xg = torch.randn(9,2), torch.randn(6,2)
    def score(x): return -(x@P + 0.1*x**3)
    def hessian(x): return P.expand(len(x),2,2).clone()+torch.diag_embed(0.3*x*x)
    yy = 0.4*torch.randn(5,2)
    divergence_errors = {}
    for separate in [False, True]:
        spec = {'mode':'ce_hlsi','transition_w':'ou','X_ref':x,
                's0_post_ref':score(x),'P_ref':hessian(x),'log_weights':torch.zeros(len(x))}
        if separate:
            spec.update(gate_X_ref=xg,gate_P_ref=hessian(xg),gate_log_weights=torch.zeros(len(xg)))
        _, div = ip._eval_ce_hlsi_score_and_divergence_analytic(yy,0.2,spec)
        fd = torch.zeros(len(yy)); step=2e-5
        for j in range(2):
            shift = torch.zeros_like(yy); shift[:,j]=step
            plus = ip._eval_ce_hlsi_score_and_divergence_analytic(yy+shift,0.2,spec)[0]
            minus = ip._eval_ce_hlsi_score_and_divergence_analytic(yy-shift,0.2,spec)[0]
            fd += (plus[:,j]-minus[:,j])/(2*step)
        error = float((fd-div).abs().max())
        divergence_errors['split' if separate else 'shared'] = error
        if error > 2e-6:
            raise AssertionError(f'Divergence mismatch {error}')

    # Check likelihood integration independently of the finite-bank score error.
    x = torch.randn(5,2)
    spec = {'mode':'ce_hlsi','transition_w':'ou','X_ref':x,
            's0_post_ref':-(x-mu)@P,'P_ref':P.expand(len(x),2,2).clone(),
            'log_weights':torch.zeros(len(x))}
    tau, T = 0.01, 6.0
    a, g = math.exp(-tau), -math.expm1(-2*tau)
    covariance = a*a*torch.linalg.inv(P)+g*torch.eye(2)
    dist = torch.distributions.MultivariateNormal(a*mu,covariance_matrix=covariance)
    expected = dist.log_prob(y)
    pf = {}
    for steps in [32,64,128]:
        actual = ip.estimate_logq_probability_flow(y,spec,t_min=tau,t_max=T,n_steps=steps,divergence_mode='analytic')
        pf[str(steps)] = float((actual-expected).square().mean().sqrt())
    if not (pf['128'] < pf['32'] and pf['128'] < 0.01):
        raise AssertionError(f'PF integration did not converge: {pf}')
    result = {'status':'passed','gaussian_arbitrary_bank_max_abs_error':gaussian_max,
              'divergence_vs_finite_difference_max_abs_error':divergence_errors,
              'gaussian_pf_log_density_rmse_by_steps':pf,
              'endpoint':'p_tau; Gaussian base at finite T adds a small terminal mismatch',
              'torch_version':torch.__version__}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
