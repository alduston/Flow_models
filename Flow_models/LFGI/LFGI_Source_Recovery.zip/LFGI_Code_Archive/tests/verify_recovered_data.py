#!/usr/bin/env python3
"""Verify that authentic recovered arrays reproduce their saved summaries."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=ROOT/'validation_runs/recovered_data_checks.json')
    a=p.parse_args()
    sweeps=ROOT/'data/recovered/sweeps'
    raw=pd.read_csv(sweeps/'gate_sample_complexity_raw.csv')
    summary=pd.read_csv(sweeps/'gate_sample_complexity_summary_misaligned_subspace_gmm_d8.csv')
    keys=['target','t','n_gate','gate_estimator']
    diffs={}
    for metric in ['fro_relative_mean','risk_weighted_excess_mean','risk_weighted_rel_to_D_trace']:
        got=raw.groupby(keys)[metric].agg(['mean','std']).reset_index().merge(summary,on=keys)
        for stat in ['mean','std']:
            x,y=got[stat].to_numpy(),got[f'{metric}_{stat}'].to_numpy()
            np.testing.assert_allclose(x,y,rtol=1e-11,atol=1e-11)
            diffs[f'{metric}_{stat}']=float(np.max(np.abs(x-y)))
    diagnostics=ROOT/'data/recovered/diagnostics'
    audit=pd.read_csv(diagnostics/'funnel_d10_lfgi_pole_audit.csv')
    audit_summary=pd.read_csv(diagnostics/'funnel_d10_lfgi_pole_audit_summary.csv')
    for row in audit_summary.itertuples():
        group=audit[np.isclose(audit.t,row.t)]
        np.testing.assert_allclose(group.strict_section8_pass.mean(),row.pass_rate)
        np.testing.assert_allclose(group.active_pole.mean(),row.active_pole_rate)
        np.testing.assert_allclose((group.lam_min_A<=0).mean(),row.nonpos_A_rate)
    darcy=ROOT/'data/recovered/darcy'
    for path in darcy.glob('*.npz'):
        with np.load(path,allow_pickle=False) as z:
            np.testing.assert_allclose(z['raw_logw'],z['log_target']-z['logq'])
            np.testing.assert_allclose(z['energy'],-z['log_target'])
            np.testing.assert_allclose(z['neglogq'],-z['logq'])
    # Run the recovered table aggregator against the authentic single-run CSVs.
    with tempfile.TemporaryDirectory() as temp:
        temp=Path(temp);folder=temp/'darcy_flow/run_results';folder.mkdir(parents=True)
        for path in darcy.glob('*drc_energy*.csv'):shutil.copyfile(path,folder/path.name)
        command=[sys.executable,str(ROOT/'recovered/aggregation/aggregate_tables.py'),
                 '--root',str(temp),'--outdir',str(temp/'aggregated'),'--problems','darcy_flow']
        done=subprocess.run(command,text=True,capture_output=True,check=True)
        tables=list((temp/'aggregated').rglob('*.csv'))
        if not tables:raise AssertionError('No tables emitted by recovered aggregator')
        counts={str(path.relative_to(temp/'aggregated')):len(pd.read_csv(path)) for path in tables}
    result={'status':'passed','gate_summary_max_abs_errors':diffs,
            'funnel_audit_rows':len(audit),'funnel_audit_summary_rows':len(audit_summary),
            'darcy_array_identities':'passed','recovered_aggregator_tables':counts,
            'scope':'authentic historical data consistency; not final paper table reproduction'}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
