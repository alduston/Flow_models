#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
density_benchmark_sweep_sampling_stdout.py

Version: benchmark-sweep-matched sampling/heatmap patch.

Minimal first-pass density/evidence benchmark for LFGI-PF.

This script intentionally reuses the probability-flow likelihood, reverse OU
sampler, SNIS bank, KDE calibration helpers, and target definitions from the
attached iterative_lfgi.py when available. It adds a small density-benchmark
wrapper around them:

  * targets: gmm_8d / stiff_misaligned_gmm, funnel_d10, nonlinear_inverse_d8
  * PF density methods: tweedie_pf, scalar_blend_pf, centered_matrix_blend_pf,
    lfgi_pf, gn_lfgi_pf when a GN Hessian is available
  * direct density baselines: kde, laplace_mixture,
    local_linear_langevin_mixture
  * metrics: held-out NLL, log-density RMSE or centered RMSE, energy
    correlation, forward/reverse/bridge logZ estimates and ESS diagnostics
  * plots: benchmark-sweep-style 2D heatmap histogram array comparing q samples to ground-truth target samples

Expected colocated files:
  iterative_lfgi.py   (or an uploaded copy matching iterative_lfgi*.py)

Example smoke test:
  python density_benchmark_sweep.py \
    --target gmm_8d --device cpu --dtype float32 \
    --n-ref 64 --n-eval 128 --n-q-samples 128 \
    --sample-steps 6 --pf-steps 4 --methods tweedie_pf,lfgi_pf,kde
"""

from __future__ import annotations

VERSION = "exactmatch-darcy-v0"

import argparse
import csv
import glob
import importlib.util
import sys
import json
import math
import os
import time
from dataclasses import asdict, dataclass
from typing import Dict, Iterable, List, Optional, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
import numpy as np
import torch


# -----------------------------------------------------------------------------
# Dynamic import of iterative_lfgi.py
# -----------------------------------------------------------------------------


def _load_iterative_module():
    here = os.path.dirname(os.path.abspath(__file__))
    cwd = os.getcwd()
    candidates = []
    for base in [cwd, here, "/mnt/data"]:
        candidates.extend([
            os.path.join(base, "iterative_lfgi.py"),
            os.path.join(base, "iterative_lfgi (13).py"),
        ])
        candidates.extend(sorted(glob.glob(os.path.join(base, "iterative_lfgi*.py"))))
    seen = set()
    for path in candidates:
        if path in seen:
            continue
        seen.add(path)
        if os.path.exists(path) and os.path.abspath(path) != os.path.abspath(__file__):
            spec = importlib.util.spec_from_file_location("iterative_lfgi_base", path)
            if spec is None or spec.loader is None:
                continue
            mod = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = mod
            spec.loader.exec_module(mod)
            return mod, path
    raise FileNotFoundError(
        "Could not find iterative_lfgi.py next to this script. Place iterative_lfgi.py "
        "in the same directory, or keep the uploaded iterative_lfgi*.py file in /mnt/data."
    )


it, ITERATIVE_PATH = _load_iterative_module()



def _load_benchmark_module():
    """Load benchmark_sweep.py when available so target/sampler semantics match exactly.

    Set BENCHMARK_SWEEP_PATH or LFGI_BENCHMARK_SWEEP_PATH to force a specific
    file.  This avoids Colab namespace/cache ambiguity when the benchmark script
    has a versioned name such as benchmark_sweep_density_sweep_v1.py.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    cwd = os.getcwd()
    candidates = []
    for env_name in ["BENCHMARK_SWEEP_PATH", "LFGI_BENCHMARK_SWEEP_PATH"]:
        env_path = os.environ.get(env_name, "").strip()
        if env_path:
            candidates.append(env_path)
    for base in [cwd, here, "/mnt/data"]:
        candidates.extend([
            os.path.join(base, "benchmark_sweep.py"),
            os.path.join(base, "benchmark_sweep_density_sweep_v1.py"),
            os.path.join(base, "benchmark_sweep_density_sweep_v0.py"),
            os.path.join(base, "benchmark_sweep (8).py"),
            os.path.join(base, "benchmark_sweep (6).py"),
            os.path.join(base, "benchmark_sweep (5).py"),
        ])
        candidates.extend(sorted(glob.glob(os.path.join(base, "benchmark_sweep*.py"))))
        candidates.extend(sorted(glob.glob(os.path.join(base, "benchmark_sweep (*).py"))))
    seen = set()
    for path in candidates:
        if not path:
            continue
        ap = os.path.abspath(path)
        if ap in seen or ap == os.path.abspath(__file__):
            continue
        seen.add(ap)
        if os.path.exists(path):
            spec = importlib.util.spec_from_file_location("benchmark_sweep_exact", path)
            if spec is None or spec.loader is None:
                continue
            mod = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = mod
            spec.loader.exec_module(mod)
            return mod, path
    return None, ""


bs, BENCHMARK_PATH = _load_benchmark_module()


_SAMPLING_MOD = None
_SAMPLING_PATH = ""


def _load_sampling_module():
    """Lazy-load sampling.py so Darcy target can reuse the shared physics likelihood.

    The uploaded project files often have versioned names such as
    ``sampling (22).py``.  We keep this loader lazy because the non-Darcy
    density benchmarks should not pay JAX import/compile cost just to parse
    arguments or run toy targets.
    """
    global _SAMPLING_MOD, _SAMPLING_PATH
    if _SAMPLING_MOD is not None:
        return _SAMPLING_MOD, _SAMPLING_PATH
    here = os.path.dirname(os.path.abspath(__file__))
    cwd = os.getcwd()
    candidates = []
    for env_name in ["SAMPLING_PATH", "HLSI_SAMPLING_PATH"]:
        env_path = os.environ.get(env_name, "").strip()
        if env_path:
            candidates.append(env_path)
    for base in [cwd, here, "/mnt/data"]:
        candidates.extend([
            os.path.join(base, "sampling.py"),
            os.path.join(base, "sampling (22).py"),
        ])
        candidates.extend(sorted(glob.glob(os.path.join(base, "sampling*.py"))))
        candidates.extend(sorted(glob.glob(os.path.join(base, "sampling (*).py"))))
    seen = set()
    for path in candidates:
        if not path:
            continue
        ap = os.path.abspath(path)
        if ap in seen or ap == os.path.abspath(__file__):
            continue
        seen.add(ap)
        if os.path.exists(path):
            spec = importlib.util.spec_from_file_location("hlsi_sampling_shared", path)
            if spec is None or spec.loader is None:
                continue
            mod = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = mod
            spec.loader.exec_module(mod)
            _SAMPLING_MOD = mod
            _SAMPLING_PATH = path
            return mod, path
    raise FileNotFoundError(
        "Could not find sampling.py. Place sampling.py or sampling (22).py next to this script, "
        "or set SAMPLING_PATH=/path/to/sampling.py."
    )


# -----------------------------------------------------------------------------
# Config and utility functions
# -----------------------------------------------------------------------------


@dataclass
class Args:
    outdir: str = "results/density_benchmark"
    seed: int = 42
    device: str = "cuda" if torch.cuda.is_available() else "cpu"
    dtype: str = "float64"

    target: str = "gmm_8d"  # gmm_8d, funnel_d10, nonlinear_inverse_d8, all
    methods: str = (
        "tweedie_pf,scalar_blend_pf,plugin_matrix_blend_pf,centered_matrix_blend_pf,"
        "lfgi_pf,gn_lfgi_pf,kde,laplace_mixture,local_linear_langevin_mixture"
    )

    # Defaults mirror the paper_sweep benchmark settings when the same flags are used.
    # n_gate/bank_coupling control the separate score/gate banks exactly as in
    # benchmark_sweep.py: shared, prefix, or independent.
    n_ref: int = 300
    n_gate: int = 300
    bank_coupling: str = "independent"
    n_eval: int = 8192
    n_q_samples: int = 8192
    n_oracle: int = 0  # reserved; first pass uses exact/or sampled target eval banks

    # Standard sample-quality metrics, copied from benchmark_sweep.py style.
    metric_max: int = 2000
    sw2_projections: int = 256
    ksd_max_points: int = 1000
    mmd_max_points: int = 2000

    t_min: float = 0.005
    t_max: float = 3.0
    time_schedule: str = "linear"  # linear or log_linear
    sample_steps: int = 300
    pf_steps: int = 32
    eval_chunk: int = 256
    rho_batch: int = 256

    # IMPORTANT for benchmark equivalence: benchmark_sweep.py does not clip
    # reverse-SDE scores/states and always applies the final Tweedie denoise.
    score_clip: float = 0.0
    sample_clip: float = 0.0
    final_denoise: bool = True
    use_benchmark_sampler: bool = True
    # Matrix gate clip in benchmark_sweep defaults to 1e6; CE/LFGI raw gate is unclipped there.
    gate_clip: float = 1.0e6
    resolvent_eps: float = 1.0e-8
    pf_div_clip: float = 1.0e4
    hutchinson_probes: int = 1
    hutchinson_eps: float = 1.0e-3

    kde_bandwidth: float = 0.0
    kde_min_bandwidth: float = 0.05
    kde_chunk: int = 256
    lll_h: float = 1.0
    precision_floor: float = 1.0e-3
    precision_cap: float = 1.0e6
    matrix_ridge: float = 1.0e-8
    matrix_ridge_rel: float = 1.0e-6

    inverse_variant: str = "clean"  # clean or residual
    inverse_mala_steps: int = 800
    inverse_mala_step_size: float = 2.0e-3
    inverse_mala_burnin_frac: float = 0.5

    # Darcy-flow KL inverse-problem target.  These defaults intentionally define
    # an ambiguous/sparse variant rather than the dense 120-sensor experiment in
    # darcy_flow.py.
    darcy_dim: int = 16
    darcy_grid_n: int = 32
    darcy_n_obs: int = 24
    darcy_n_holdout_obs: int = 32
    darcy_noise_std: float = 1.0e-2
    darcy_sensor_mode: str = "left_sparse"  # random_sparse, left_sparse, symmetric_sparse
    darcy_prior_ell: float = 0.1
    darcy_prior_sigma: float = 1.0
    darcy_truth_scale: float = 0.5
    darcy_mala_steps: int = 2000
    darcy_mala_step_size: float = 1.0e-5
    darcy_mala_burnin_frac: float = 0.5
    darcy_mala_init: str = "truth_jitter"  # prior or truth_jitter
    darcy_log_batch_size: int = 64
    darcy_grad_batch_size: int = 32
    darcy_hess_batch_size: int = 4

    hist_bins: int = 100
    hist_gamma: float = 0.42
    hist_vmax_quantile: float = 98.5
    # Implicit density heatmap outlier protection.  The plot is made from
    # density weights q(x_i) on GT samples.  A few PF singularities can otherwise
    # dominate the entire panel even when rank/correlation diagnostics look good.
    # Set implicit_logq_clip_quantile=100 to disable winsorization.
    implicit_logq_clip_quantile: float = 99.0
    implicit_logq_temperature: float = 1.0
    implicit_brightness_power: float = 0.5
    heatmap_interp: str = "nearest"
    max_plot_samples: int = 12000
    skip_plots: bool = False


def parse_args() -> Args:
    p = argparse.ArgumentParser(description="Minimal density/evidence benchmark for LFGI-PF.")
    defaults = Args()
    for k, v in asdict(defaults).items():
        flag = "--" + k.replace("_", "-")
        if isinstance(v, bool):
            g = p.add_mutually_exclusive_group(required=False)
            g.add_argument(flag, dest=k, action="store_true")
            g.add_argument("--no-" + k.replace("_", "-"), dest=k, action="store_false")
            p.set_defaults(**{k: v})
        elif isinstance(v, int):
            p.add_argument(flag, dest=k, type=int, default=v)
        elif isinstance(v, float):
            p.add_argument(flag, dest=k, type=float, default=v)
        else:
            p.add_argument(flag, dest=k, type=str, default=v)
    ns = p.parse_args()
    return Args(**vars(ns))


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def get_dtype(name: str) -> torch.dtype:
    key = str(name).lower()
    if key in {"float64", "double", "fp64"}:
        return torch.float64
    if key in {"float32", "single", "fp32"}:
        return torch.float32
    raise ValueError(f"Unsupported dtype {name!r}")


def make_generator(seed: int, device: torch.device) -> torch.Generator:
    g = torch.Generator(device=device)
    g.manual_seed(int(seed))
    return g


def canonical_bank_coupling(value: str) -> str:
    key = str(value or "shared").strip().lower().replace("_", "-").replace(" ", "-")
    aliases = {
        "shared": "shared", "same": "shared", "same-bank": "shared",
        "prefix": "prefix", "coupled": "prefix", "subset": "prefix",
        "independent": "independent", "indep": "independent", "disjoint": "independent", "separate": "independent",
    }
    if key not in aliases:
        raise ValueError(f"Unknown bank_coupling={value!r}; use shared, prefix, or independent")
    return aliases[key]


def effective_gate_n(args: Args) -> int:
    if canonical_bank_coupling(args.bank_coupling) == "shared":
        return int(args.n_ref)
    return int(args.n_gate if int(args.n_gate) > 0 else args.n_ref)


def target_pool_slices(args: Args):
    """Return score/gate/eval slices with benchmark_sweep.py semantics."""
    nr = int(args.n_ref)
    ng = effective_gate_n(args)
    mode = canonical_bank_coupling(args.bank_coupling)
    if mode == "shared":
        sample_offset = nr
        score_slice = slice(0, nr)
        gate_slice = slice(0, nr)
    elif mode == "prefix":
        sample_offset = ng
        score_slice = slice(0, nr)
        gate_slice = slice(0, ng)
    elif mode == "independent":
        sample_offset = nr + ng
        score_slice = slice(0, nr)
        gate_slice = slice(nr, nr + ng)
    else:
        raise RuntimeError(mode)
    eval_slice = slice(sample_offset, sample_offset + int(args.n_eval))
    return score_slice, gate_slice, eval_slice, sample_offset, mode, ng


def funnel_logZ_constant(d: int, eta2: float) -> float:
    # benchmark_sweep.py's FunnelTarget.log_prob omits only the normalizing
    # constants of z_1 ~ N(0, eta^2) and x_{2:d}|x_1 ~ N(0, exp(x_1)I).
    return 0.5 * math.log(2.0 * math.pi * float(eta2)) + 0.5 * float(d - 1) * math.log(2.0 * math.pi)


def safe_float(x) -> float:
    try:
        if isinstance(x, torch.Tensor):
            x = x.detach().cpu().item()
        x = float(x)
        return x if math.isfinite(x) else float("nan")
    except Exception:
        return float("nan")


def logmeanexp(x: torch.Tensor) -> torch.Tensor:
    return torch.logsumexp(x.reshape(-1), dim=0) - math.log(max(1, int(x.numel())))


def log_weight_ess(logw: torch.Tensor) -> Tuple[float, float, float]:
    lw = logw.reshape(-1)
    mask = torch.isfinite(lw)
    if int(mask.sum().item()) == 0:
        return float("nan"), float("nan"), float("nan")
    lw = lw[mask]
    lwc = lw - torch.max(lw)
    w = torch.exp(lwc)
    s1 = torch.sum(w)
    s2 = torch.sum(w * w).clamp_min(1.0e-300)
    ess = (s1 * s1 / s2).item()
    ess_frac = ess / float(max(1, int(w.numel())))
    max_frac = (torch.max(w) / s1.clamp_min(1.0e-300)).item()
    return float(ess), float(ess_frac), float(max_frac)


def pearson_corr(x: torch.Tensor, y: torch.Tensor) -> float:
    if hasattr(it, "pearson_corr"):
        return float(it.pearson_corr(x, y))
    x = x.reshape(-1)
    y = y.reshape(-1)
    mask = torch.isfinite(x) & torch.isfinite(y)
    if int(mask.sum().item()) < 3:
        return float("nan")
    x = x[mask] - x[mask].mean()
    y = y[mask] - y[mask].mean()
    return safe_float(torch.sum(x * y) / torch.sqrt(torch.sum(x * x) * torch.sum(y * y)).clamp_min(1.0e-30))


def centered_rmse(x: torch.Tensor, y: torch.Tensor) -> float:
    if hasattr(it, "centered_rmse"):
        return float(it.centered_rmse(x, y))
    x = x.reshape(-1)
    y = y.reshape(-1)
    mask = torch.isfinite(x) & torch.isfinite(y)
    if int(mask.sum().item()) == 0:
        return float("nan")
    return safe_float(torch.sqrt(torch.mean(((x[mask] - x[mask].mean()) - (y[mask] - y[mask].mean())) ** 2)))


def pairwise_sq_dists(x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    return torch.clamp((x * x).sum(1, keepdim=True) + (y * y).sum(1, keepdim=True).T - 2.0 * (x @ y.T), min=0.0)


def median_bandwidth(x: torch.Tensor, max_n: int = 1200) -> float:
    z = x
    if z.shape[0] > max_n:
        idx = torch.randperm(z.shape[0], device=z.device)[:max_n]
        z = z[idx]
    d2 = pairwise_sq_dists(z, z)
    vals = d2[d2 > 0]
    if vals.numel() == 0:
        return 1.0
    return float(torch.sqrt(torch.median(vals).clamp_min(1.0e-12)).item())


def sym(A: torch.Tensor) -> torch.Tensor:
    return 0.5 * (A + A.transpose(-1, -2))


def torch_logaddexp(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    return torch.logaddexp(a, b)


def target_log_unnorm(target, x: torch.Tensor) -> torch.Tensor:
    if hasattr(target, "log_unnorm"):
        return target.log_unnorm(x)
    try:
        return target.log_prob(x, t=0.0)
    except TypeError:
        return target.log_prob(x)


def target_log_prob_norm(target, x: torch.Tensor) -> Optional[torch.Tensor]:
    logZ = getattr(target, "logZ_oracle", None)
    if logZ is None:
        return None
    return target_log_unnorm(target, x) - float(logZ)


def target_name(target) -> str:
    return str(getattr(target, "name", getattr(target, "variant_name", target.__class__.__name__)))


# -----------------------------------------------------------------------------
# Target: nonlinear inverse problem, adapted minimally from benchmark_sweep.py
# -----------------------------------------------------------------------------


class NonlinearSineInverseD8Target:
    def __init__(
        self,
        variant: str = "clean",
        d: int = 8,
        m: int = 16,
        seed: int = 123,
        device: torch.device = torch.device("cpu"),
        dtype: torch.dtype = torch.float64,
    ):
        self.d = int(d)
        self.D = int(d)
        self.m = int(m)
        self.seed = int(seed)
        self.device = device
        self.dtype = dtype
        self.variant = str(variant).lower().replace("-", "_")
        self.tau = 2.0
        if self.variant in {"clean", "small", "small_residual"}:
            self.beta = 0.35
            self.sigma_y = 0.45
            obs_noise = 0.05
            obs_bias_scale = 0.0
            self.variant_key = "clean"
        elif self.variant in {"residual", "large_residual", "mismatch"}:
            self.beta = 0.65
            self.sigma_y = 0.30
            obs_noise = 0.20
            obs_bias_scale = 0.55
            self.variant_key = "residual"
        else:
            raise ValueError("inverse_variant must be clean or residual")
        rng = np.random.RandomState(self.seed)
        QA, _ = np.linalg.qr(rng.normal(size=(self.m, self.m)))
        QB, RB = np.linalg.qr(rng.normal(size=(self.d, self.d)))
        QB = QB @ np.diag(np.sign(np.diag(RB)) + (np.diag(RB) == 0))
        svals = np.geomspace(5.0, 0.08, self.d)
        A_np = QA[:, : self.d] @ np.diag(svals) @ QB.T
        B_np = rng.normal(size=(self.m, self.d)) / math.sqrt(self.d)
        B_np = B_np / np.maximum(np.linalg.norm(B_np, axis=1, keepdims=True), 1.0e-12)
        x_true_np = rng.normal(size=self.d)
        x_true_np = 0.85 * x_true_np / max(np.linalg.norm(x_true_np), 1.0e-12) * math.sqrt(self.d)

        def f_np(x):
            return A_np @ x + self.beta * np.sin(B_np @ x)

        y_np = f_np(x_true_np) + obs_noise * rng.normal(size=self.m)
        if obs_bias_scale != 0.0:
            bias = rng.normal(size=self.m)
            bias = bias / max(np.linalg.norm(bias), 1.0e-12)
            y_np = y_np + obs_bias_scale * math.sqrt(self.m) * self.sigma_y * bias
        self.A = torch.tensor(A_np, device=device, dtype=dtype)
        self.Bmat = torch.tensor(B_np, device=device, dtype=dtype)
        self.x_true = torch.tensor(x_true_np, device=device, dtype=dtype)
        self.y_obs = torch.tensor(y_np, device=device, dtype=dtype)
        self.svals = torch.tensor(svals, device=device, dtype=dtype)
        self.name = f"nonlinear_sine_inverse_d8_{self.variant_key}"
        # Unknown posterior evidence; report centered log-density metrics only.
        self.logZ_oracle = None

    def _forward_and_jacobian(self, x: torch.Tensor):
        z = x @ self.Bmat.T
        sin_z = torch.sin(z)
        cos_z = torch.cos(z)
        Fx = x @ self.A.T + self.beta * sin_z
        residual = Fx - self.y_obs[None, :]
        J = self.A[None, :, :] + self.beta * cos_z[:, :, None] * self.Bmat[None, :, :]
        return Fx, residual, J, z, sin_z

    def log_unnorm(self, x: torch.Tensor) -> torch.Tensor:
        _, residual, _, _, _ = self._forward_and_jacobian(x)
        data_U = 0.5 * residual.square().sum(dim=1) / (self.sigma_y ** 2)
        prior_U = 0.5 * x.square().sum(dim=1) / (self.tau ** 2)
        return -(data_U + prior_U)

    def log_prob(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        if abs(float(t)) > 0:
            raise NotImplementedError("Exact OU-marginal log_prob is not implemented for nonlinear inverse target.")
        return self.log_unnorm(x)

    def energy(self, x: torch.Tensor) -> torch.Tensor:
        return -self.log_unnorm(x)

    def score(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        if abs(float(t)) > 0:
            raise NotImplementedError("Exact OU-marginal score is not implemented for nonlinear inverse target.")
        _, residual, J, _, _ = self._forward_and_jacobian(x)
        grad_U = torch.einsum("bmd,bm->bd", J, residual) / (self.sigma_y ** 2)
        grad_U = grad_U + x / (self.tau ** 2)
        return -grad_U

    def gn_hessian(self, x: torch.Tensor) -> torch.Tensor:
        _, _, J, _, _ = self._forward_and_jacobian(x)
        eye = torch.eye(self.d, device=x.device, dtype=x.dtype)[None, :, :]
        H = torch.einsum("bmi,bmj->bij", J, J) / (self.sigma_y ** 2)
        return sym(H + eye / (self.tau ** 2))

    def observed_information(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        return self.hessian(x)

    def hessian(self, x: torch.Tensor) -> torch.Tensor:
        _, residual, _, _, sin_z = self._forward_and_jacobian(x)
        H = self.gn_hessian(x)
        coeff = (-self.beta * residual * sin_z) / (self.sigma_y ** 2)
        H_resid = torch.einsum("bm,mi,mj->bij", coeff, self.Bmat, self.Bmat)
        return sym(H + H_resid)

    @torch.no_grad()
    def sample(self, n: int, generator: Optional[torch.Generator] = None, steps: int = 800, step_size: float = 2.0e-3, burnin_frac: float = 0.5) -> torch.Tensor:
        # Vectorized MALA. This is deliberately simple and adequate for first-pass
        # density diagnostics, not a production posterior sampler.
        n = int(n)
        burnin = int(max(0, round(float(burnin_frac) * int(steps))))
        keep_every = max(1, (int(steps) - burnin) // 2)
        x = self.tau * torch.randn((n, self.d), device=self.device, dtype=self.dtype, generator=generator)
        lp = self.log_unnorm(x)
        sx = self.score(x)
        samples = []
        for k in range(int(steps)):
            noise = torch.randn(x.shape, device=self.device, dtype=self.dtype, generator=generator)
            x_prop = x + float(step_size) * sx + math.sqrt(2.0 * float(step_size)) * noise
            lp_prop = self.log_unnorm(x_prop)
            sx_prop = self.score(x_prop)
            log_q_fwd = -((x_prop - x - float(step_size) * sx) ** 2).sum(dim=1) / (4.0 * float(step_size))
            log_q_bwd = -((x - x_prop - float(step_size) * sx_prop) ** 2).sum(dim=1) / (4.0 * float(step_size))
            log_alpha = (lp_prop - lp + log_q_bwd - log_q_fwd).clamp(max=0.0)
            acc = torch.rand((n,), device=self.device, dtype=self.dtype, generator=generator) < torch.exp(log_alpha)
            x = torch.where(acc[:, None], x_prop, x)
            lp = torch.where(acc, lp_prop, lp)
            sx = torch.where(acc[:, None], sx_prop, sx)
            if k >= burnin and ((k - burnin) % keep_every == 0):
                samples.append(x.detach().clone())
        if len(samples) == 0:
            return x.detach()
        out = torch.cat(samples, dim=0)
        idx = torch.randperm(out.shape[0], device=self.device, generator=generator)[:n]
        return out[idx].detach()


# -----------------------------------------------------------------------------
# Target: ambiguous Darcy-flow KL inverse problem
# -----------------------------------------------------------------------------


class DarcyFlowKLTarget:
    """Low-dimensional Darcy log-permeability inverse problem for density tests.

    This target is a density-benchmark wrapper around the same ingredients used
    by ``darcy_flow.py`` and ``sampling.py``:

      * exponential-covariance KL basis on an N x N grid;
      * finite-difference Darcy pressure solve with harmonic face averages;
      * sparse pressure observations;
      * standard Gaussian KL prior;
      * Gaussian data likelihood;
      * Gauss--Newton log-likelihood Hessian from ``make_physics_likelihood``.

    The target is deliberately sparse/ambiguous by default: d=16 and 24 sensors,
    not the original dense d=32, 120-sensor sampler experiment.
    """

    def __init__(
        self,
        d: int = 16,
        grid_n: int = 32,
        n_obs: int = 24,
        n_holdout_obs: int = 32,
        noise_std: float = 1.0e-2,
        sensor_mode: str = "left_sparse",
        prior_ell: float = 0.1,
        prior_sigma: float = 1.0,
        truth_scale: float = 0.5,
        seed: int = 42,
        device: torch.device = torch.device("cpu"),
        dtype: torch.dtype = torch.float64,
        log_batch_size: int = 64,
        grad_batch_size: int = 32,
        hess_batch_size: int = 4,
    ):
        import jax
        import jax.numpy as jnp

        jax.config.update("jax_enable_x64", True)
        sampling_mod, sampling_path = _load_sampling_module()

        self.d = int(d)
        self.D = int(d)
        self.grid_n = int(grid_n)
        self.n_obs = int(n_obs)
        self.n_holdout_obs = int(n_holdout_obs)
        self.noise_std = float(noise_std)
        self.sensor_mode = str(sensor_mode).lower().strip().replace("-", "_")
        self.prior_ell = float(prior_ell)
        self.prior_sigma = float(prior_sigma)
        self.truth_scale = float(truth_scale)
        self.seed = int(seed)
        self.device = device
        self.dtype = dtype
        self.name = f"ambiguous_darcy_kl_d{self.d}_{self.sensor_mode}_m{self.n_obs}_sigma{self.noise_std:g}"
        self.variant_name = self.name
        self.logZ_oracle = None
        self.sampling_path = sampling_path

        N = self.grid_n
        if N < 5:
            raise ValueError("darcy_grid_n must be at least 5")
        if self.d < 1:
            raise ValueError("darcy_dim must be positive")
        if self.n_obs < 1:
            raise ValueError("darcy_n_obs must be positive")

        rng = np.random.RandomState(self.seed)
        x_1d_np = np.linspace(0.0, 1.0, N)
        X_np, Y_np = np.meshgrid(x_1d_np, x_1d_np)
        coords = np.column_stack([X_np.ravel(), Y_np.ravel()])
        diff = coords[:, None, :] - coords[None, :, :]
        dists = np.sqrt(np.sum(diff * diff, axis=2))
        C = (self.prior_sigma ** 2) * np.exp(-dists / self.prior_ell)
        eigvals, eigvecs = np.linalg.eigh(C)
        order = np.argsort(eigvals)[::-1]
        eigvals = eigvals[order]
        eigvecs = eigvecs[:, order]
        if self.d > eigvecs.shape[1]:
            raise ValueError(f"darcy_dim={self.d} exceeds available grid basis dimension {eigvecs.shape[1]}")
        Basis_np = eigvecs[:, : self.d] * np.sqrt(np.maximum(eigvals[: self.d], 0.0))
        self.Basis_np = Basis_np.astype(np.float64)

        interior_mask = np.ones((N, N), dtype=bool)
        interior_mask[0, :] = False
        interior_mask[-1, :] = False
        interior_mask[:, 0] = False
        interior_mask[:, -1] = False
        interior_indices = np.where(interior_mask.ravel())[0]
        obs_indices_train = self._select_sensor_indices(interior_indices, N, self.n_obs, self.sensor_mode, rng)
        remaining = np.setdiff1d(interior_indices, obs_indices_train, assume_unique=False)
        if remaining.size < self.n_holdout_obs:
            raise ValueError("Not enough remaining interior grid points for holdout sensors")
        obs_indices_holdout = rng.choice(remaining, size=self.n_holdout_obs, replace=False)
        self.obs_indices_train_np = np.asarray(obs_indices_train, dtype=np.int64)
        self.obs_indices_holdout_np = np.asarray(obs_indices_holdout, dtype=np.int64)

        Basis = jnp.array(self.Basis_np, dtype=jnp.float64)
        obs_locations_train = jnp.array(self.obs_indices_train_np, dtype=jnp.int32)
        obs_locations_holdout = jnp.array(self.obs_indices_holdout_np, dtype=jnp.int32)

        h = 1.0 / float(N - 1)
        h2 = h * h
        f_darcy = jnp.ones((N, N), dtype=jnp.float64)
        int_mask = jnp.zeros((N, N), dtype=bool)
        int_mask = int_mask.at[1:-1, 1:-1].set(True)
        int_rows, int_cols = jnp.where(int_mask)
        n_int = int_rows.shape[0]
        int_id = -jnp.ones((N, N), dtype=jnp.int32)
        int_id = int_id.at[int_rows, int_cols].set(jnp.arange(n_int, dtype=jnp.int32))
        int_flat = int_rows * N + int_cols

        def assemble_darcy_vectorized(k_field):
            k_xp = 2.0 * k_field[:-1, :] * k_field[1:, :] / (k_field[:-1, :] + k_field[1:, :] + 1.0e-30)
            k_yp = 2.0 * k_field[:, :-1] * k_field[:, 1:] / (k_field[:, :-1] + k_field[:, 1:] + 1.0e-30)
            ir = int_rows
            ic = int_cols
            c_E = k_xp[ir, ic] / h2
            c_W = k_xp[ir - 1, ic] / h2
            c_N = k_yp[ir, ic] / h2
            c_S = k_yp[ir, ic - 1] / h2
            diag = c_E + c_W + c_N + c_S
            idx = jnp.arange(n_int)
            nbr_E = int_id[ir + 1, ic]
            nbr_W = int_id[ir - 1, ic]
            nbr_N = int_id[ir, ic + 1]
            nbr_S = int_id[ir, ic - 1]
            A = jnp.zeros((n_int, n_int), dtype=jnp.float64)
            A = A.at[idx, idx].add(diag)
            A = A.at[idx, nbr_E].add(jnp.where(nbr_E >= 0, -c_E, 0.0))
            A = A.at[idx, nbr_W].add(jnp.where(nbr_W >= 0, -c_W, 0.0))
            A = A.at[idx, nbr_N].add(jnp.where(nbr_N >= 0, -c_N, 0.0))
            A = A.at[idx, nbr_S].add(jnp.where(nbr_S >= 0, -c_S, 0.0))
            rhs = f_darcy[int_rows, int_cols]
            return A, rhs

        @jax.jit
        def solve_full_pressure_jax(alpha):
            log_k = jnp.reshape(Basis @ alpha, (N, N))
            # Mild clipping prevents pathological early-MCMC proposals from
            # producing exp overflow while leaving normal posterior states alone.
            k_field = jnp.exp(jnp.clip(log_k, -20.0, 20.0))
            A, rhs = assemble_darcy_vectorized(k_field)
            p_int = jnp.linalg.solve(A, rhs)
            p_full = jnp.zeros(N * N, dtype=jnp.float64)
            p_full = p_full.at[int_flat].set(p_int)
            return p_full.reshape(N, N)

        @jax.jit
        def solve_forward_jax(alpha):
            return solve_full_pressure_jax(alpha).reshape(-1)[obs_locations_train]

        @jax.jit
        def solve_forward_holdout_jax(alpha):
            return solve_full_pressure_jax(alpha).reshape(-1)[obs_locations_holdout]

        self.solve_forward_jax = solve_forward_jax
        self.solve_forward_holdout_jax = solve_forward_holdout_jax
        self.solve_full_pressure_jax = solve_full_pressure_jax

        rng_truth = np.random.RandomState(self.seed + 1009)
        alpha_true_np = rng_truth.randn(self.d) * self.truth_scale
        y_clean_np = np.asarray(solve_forward_jax(jnp.array(alpha_true_np, dtype=jnp.float64)))
        y_obs_np = y_clean_np + rng_truth.normal(0.0, self.noise_std, size=y_clean_np.shape)
        y_holdout_clean_np = np.asarray(solve_forward_holdout_jax(jnp.array(alpha_true_np, dtype=jnp.float64)))
        y_holdout_obs_np = y_holdout_clean_np + rng_truth.normal(0.0, self.noise_std, size=y_holdout_clean_np.shape)
        self.alpha_true_np = alpha_true_np.astype(np.float64)
        self.y_clean_np = y_clean_np.astype(np.float64)
        self.y_obs_np = y_obs_np.astype(np.float64)
        self.y_holdout_clean_np = y_holdout_clean_np.astype(np.float64)
        self.y_holdout_obs_np = y_holdout_obs_np.astype(np.float64)
        self.alpha_true = torch.tensor(self.alpha_true_np, device=device, dtype=dtype)
        self.y_obs = torch.tensor(self.y_obs_np, device=device, dtype=dtype)

        self.lik_model, self.lik_aux = sampling_mod.make_physics_likelihood(
            solve_forward_jax,
            self.y_obs_np,
            self.noise_std,
            use_gauss_newton_hessian=True,
            log_batch_size=int(log_batch_size),
            grad_batch_size=int(grad_batch_size),
            hess_batch_size=int(hess_batch_size),
        )

        print(
            f"[DarcyFlowKLTarget] built {self.name}: grid={N}x{N}, d={self.d}, "
            f"n_obs={self.n_obs}, noise={self.noise_std:g}, sampling={sampling_path}"
        )

    @staticmethod
    def _select_sensor_indices(interior_indices: np.ndarray, N: int, n_obs: int, mode: str, rng: np.random.RandomState) -> np.ndarray:
        mode = str(mode).lower().replace("-", "_")
        rows = interior_indices // N
        cols = interior_indices % N
        if mode in {"random", "random_sparse", "sparse"}:
            candidates = interior_indices
            if n_obs > candidates.size:
                raise ValueError("darcy_n_obs exceeds number of interior grid points")
            return np.asarray(rng.choice(candidates, size=n_obs, replace=False), dtype=np.int64)
        if mode in {"left", "left_sparse", "one_sided", "one_side"}:
            # One-sided pressure sensors: good for ambiguous weakly observed KL directions.
            candidates = interior_indices[cols <= max(1, N // 2)]
            if n_obs > candidates.size:
                raise ValueError("darcy_n_obs exceeds left_sparse candidate pool")
            return np.asarray(rng.choice(candidates, size=n_obs, replace=False), dtype=np.int64)
        if mode in {"symmetric", "symmetric_sparse", "mirror_sparse"}:
            left_mask = cols < (N - 1) / 2.0
            left_candidates = interior_indices[left_mask]
            half = n_obs // 2
            if half > left_candidates.size:
                raise ValueError("darcy_n_obs too large for symmetric_sparse left pool")
            chosen_left = np.asarray(rng.choice(left_candidates, size=half, replace=False), dtype=np.int64)
            r = chosen_left // N
            c = chosen_left % N
            chosen_right = r * N + (N - 1 - c)
            chosen = np.unique(np.concatenate([chosen_left, chosen_right]).astype(np.int64))
            if chosen.size < n_obs:
                remaining = np.setdiff1d(interior_indices, chosen, assume_unique=False)
                extra = rng.choice(remaining, size=n_obs - chosen.size, replace=False)
                chosen = np.concatenate([chosen, extra.astype(np.int64)])
            return np.asarray(chosen[:n_obs], dtype=np.int64)
        raise ValueError("Unknown darcy_sensor_mode={!r}; use random_sparse, left_sparse, or symmetric_sparse".format(mode))

    def _as_batch(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim == 1:
            return x.unsqueeze(0)
        return x

    def log_unnorm(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_batch(x)
        ll = self.lik_model.log_likelihood(x).to(device=x.device, dtype=x.dtype)
        prior = -0.5 * torch.sum(x * x, dim=1)
        return torch.nan_to_num(prior + ll, nan=-float("inf"), posinf=-float("inf"), neginf=-float("inf"))

    def log_prob(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        if abs(float(t)) > 0:
            raise NotImplementedError("Exact OU-marginal log_prob is not implemented for Darcy target.")
        return self.log_unnorm(x)

    def energy(self, x: torch.Tensor) -> torch.Tensor:
        return -self.log_unnorm(x)

    def score(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        if abs(float(t)) > 0:
            raise NotImplementedError("Exact OU-marginal score is not implemented for Darcy target.")
        x = self._as_batch(x)
        grad_ll = self.lik_model.grad_log_likelihood(x).to(device=x.device, dtype=x.dtype)
        out = -x + grad_ll
        return torch.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)

    def gn_hessian(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_batch(x)
        H_log_lik = self.lik_model.hess_log_likelihood(x).to(device=x.device, dtype=x.dtype)
        eye = torch.eye(self.d, device=x.device, dtype=x.dtype)[None, :, :]
        # hess_log_likelihood is negative GN curvature, so posterior observed
        # information is I - Hessian(log likelihood).
        H = eye - H_log_lik
        return sym(torch.nan_to_num(H, nan=0.0, posinf=1.0e12, neginf=-1.0e12))

    def hessian(self, x: torch.Tensor) -> torch.Tensor:
        # First Darcy density target intentionally uses GN curvature as the
        # inverse-problem-native Hessian proxy.  Exact Hessian can be added later
        # by constructing a second PhysicsLikelihood with use_gauss_newton=False.
        return self.gn_hessian(x)

    def observed_information(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        return self.gn_hessian(x)

    def latent_to_log_permeability(self, x: torch.Tensor) -> torch.Tensor:
        x = self._as_batch(x).detach().cpu().double().numpy()
        fields = x @ self.Basis_np.T
        return torch.tensor(fields.reshape((-1, self.grid_n, self.grid_n)), device=self.device, dtype=self.dtype)

    def plot_projection(self, x: torch.Tensor, fit_ref: Optional[torch.Tensor] = None) -> torch.Tensor:
        # Use the posterior/reference PCA if supplied, otherwise first two KL coordinates.
        if fit_ref is None or fit_ref.shape[0] < 3:
            return x[:, :2]
        ref = fit_ref.to(device=x.device, dtype=x.dtype)
        mu = ref.mean(dim=0, keepdim=True)
        Xc = ref - mu
        try:
            _, _, Vh = torch.linalg.svd(Xc, full_matrices=False)
            V = Vh[:2].T
            return (x - mu) @ V
        except RuntimeError:
            return x[:, :2]

    @torch.no_grad()
    def sample(
        self,
        n: int,
        generator: Optional[torch.Generator] = None,
        steps: int = 2000,
        step_size: float = 1.0e-5,
        burnin_frac: float = 0.5,
        init: str = "truth_jitter",
    ) -> torch.Tensor:
        """Vectorized MALA sampler used to build the target/eval bank.

        This is a deliberately simple pilot/reference sampler.  It is adequate
        for wiring and first density diagnostics, but the paper-quality version
        should cache a longer tuned MCMC/reference bank.
        """
        n = int(n)
        steps = int(steps)
        dt = float(step_size)
        if dt <= 0.0:
            raise ValueError("darcy_mala_step_size must be positive")
        burnin = int(max(0, min(steps - 1, round(float(burnin_frac) * steps)))) if steps > 1 else 0
        keep_every = max(1, (steps - burnin) // 2)
        init_key = str(init).lower().replace("-", "_")
        if init_key in {"truth", "truth_jitter", "true"}:
            x = self.alpha_true.unsqueeze(0) + torch.randn((n, self.d), device=self.device, dtype=self.dtype, generator=generator)
        elif init_key in {"prior", "standard", "standard_normal"}:
            x = torch.randn((n, self.d), device=self.device, dtype=self.dtype, generator=generator)
        else:
            raise ValueError("darcy_mala_init must be prior or truth_jitter")
        lp = self.log_unnorm(x)
        sx = self.score(x)
        samples = []
        acc_total = 0.0
        finite_total = 0.0
        sqrt_2dt = math.sqrt(2.0 * dt)
        for k in range(steps):
            noise = torch.randn(x.shape, device=self.device, dtype=self.dtype, generator=generator)
            x_prop = x + dt * sx + sqrt_2dt * noise
            lp_prop = self.log_unnorm(x_prop)
            sx_prop = self.score(x_prop)
            log_q_fwd = -((x_prop - x - dt * sx) ** 2).sum(dim=1) / (4.0 * dt)
            log_q_bwd = -((x - x_prop - dt * sx_prop) ** 2).sum(dim=1) / (4.0 * dt)
            log_alpha = lp_prop - lp + log_q_bwd - log_q_fwd
            finite = torch.isfinite(log_alpha) & torch.isfinite(lp_prop) & torch.isfinite(sx_prop).all(dim=1)
            log_alpha = torch.where(finite, log_alpha.clamp(max=0.0), torch.full_like(log_alpha, -float("inf")))
            acc = torch.rand((n,), device=self.device, dtype=self.dtype, generator=generator) < torch.exp(log_alpha)
            x = torch.where(acc[:, None], x_prop, x)
            lp = torch.where(acc, lp_prop, lp)
            sx = torch.where(acc[:, None], sx_prop, sx)
            acc_total += float(acc.double().mean().detach().cpu().item())
            finite_total += float(finite.double().mean().detach().cpu().item())
            if k >= burnin and ((k - burnin) % keep_every == 0):
                samples.append(x.detach().clone())
        self.last_mala_acceptance = acc_total / max(1, steps)
        self.last_mala_finite_fraction = finite_total / max(1, steps)
        print(
            f"[DarcyFlowKLTarget] MALA bank: n={n}, steps={steps}, dt={dt:g}, "
            f"burnin={burnin}, init={init_key}, accept={self.last_mala_acceptance:.3f}, "
            f"finite={self.last_mala_finite_fraction:.3f}"
        )
        if len(samples) == 0:
            return x.detach()
        out = torch.cat(samples, dim=0)
        idx = torch.randperm(out.shape[0], device=self.device, generator=generator)[:n]
        return out[idx].detach()



# -----------------------------------------------------------------------------
# Score banks and PF densities
# -----------------------------------------------------------------------------


class GNHessianTargetView:
    def __init__(self, target):
        self.target = target
        self.d = target.d
        self.D = getattr(target, "D", target.d)
        self.device = target.device
        self.dtype = target.dtype
        self.name = target_name(target) + "_gn_view"
        self.logZ_oracle = getattr(target, "logZ_oracle", None)

    def __getattr__(self, name):
        return getattr(self.target, name)

    def observed_information(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        if hasattr(self.target, "gn_hessian"):
            return self.target.gn_hessian(x)
        return self.target.observed_information(x, t=t)


class DensitySNISScoreBank(it.SNISScoreBank):
    """SNISScoreBank with plugin/centered matrix blends added for density benchmarking."""

    def estimate_chunk(self, y: torch.Tensor, t: float, method: str) -> torch.Tensor:  # type: ignore[override]
        key = str(method).strip().lower().replace("_", "-")
        # Match benchmark_sweep.py exactly: the scalar blend gate is estimated
        # on the score/reference bank xr, not on the independent LFGI gate bank xg.
        # Only CE-LFGI and primal/matrix blends use the separate gate bank.
        if key in {"blend", "blended", "scalar-blend", "scalar"}:
            w, b, c, alpha, gamma = self._weights_and_signals(y, t)
            am = torch.sum(w[:, :, None] * c, dim=1)
            bm = torch.sum(w[:, :, None] * b, dim=1)
            ac = c - am[:, None, :]
            bc = b - bm[:, None, :]
            va = torch.sum(w[:, :, None] * ac.square(), dim=1).clamp(min=1.0e-30)
            vb = torch.sum(w[:, :, None] * bc.square(), dim=1).clamp(min=1.0e-30)
            cab = torch.sum(w[:, :, None] * ac * bc, dim=1)
            den = (va + vb - 2.0 * cab).clamp(min=1.0e-20)
            g = ((va - cab) / den).clamp(0.0, 1.0)
            return (1.0 - g) * am + g * bm

        matrix_keys = {
            "plugin-matrix-blend", "plugin-blend", "uncentered-matrix-blend",
            "primal-matrix-blend", "matrix-blend", "moment-matrix-blend",
            "centered-matrix-blend", "centered-blend", "regression-blend",
        }
        if key not in matrix_keys:
            return super().estimate_chunk(y, t, method)

        centered = key in {"centered-matrix-blend", "centered-blend", "regression-blend"}
        w, b, c, alpha, gamma = self._weights_and_signals(y, t)
        s_twd = torch.sum(w[:, :, None] * b, dim=1)
        s_tsi = torch.sum(w[:, :, None] * c, dim=1)

        wg, bg, cg, _alpha_g, _gamma_g = self._gate_weights_and_signals(y, t)
        d_gate = cg - bg
        if centered:
            b_mean = torch.sum(wg[:, :, None] * bg, dim=1)
            d_mean = torch.sum(wg[:, :, None] * d_gate, dim=1)
            b_mom = bg - b_mean[:, None, :]
            d_mom = d_gate - d_mean[:, None, :]
        else:
            # Uncentered plug-in normal-equation baseline from benchmark_sweep.py:
            #     G = - E[b d^T] E[d d^T]^{-1},  d = c - b.
            b_mom = bg
            d_mom = d_gate

        M = torch.einsum("bn,bni,bnj->bij", wg, d_mom, d_mom)
        N = torch.einsum("bn,bni,bnj->bij", wg, b_mom, d_mom)
        M = sym(torch.nan_to_num(M, nan=0.0, posinf=0.0, neginf=0.0))
        N = torch.nan_to_num(N, nan=0.0, posinf=0.0, neginf=0.0)
        B, d = M.shape[0], M.shape[-1]
        eye = torch.eye(d, device=y.device, dtype=y.dtype).expand(B, d, d)
        ridge = float(getattr(self.cfg, "matrix_ridge", 1.0e-8))
        ridge_rel = float(getattr(self.cfg, "matrix_ridge_rel", 1.0e-6))
        tr = torch.diagonal(M, dim1=-2, dim2=-1).sum(dim=-1) / max(1, d)
        M_reg = M + (ridge + ridge_rel * tr.clamp_min(0.0))[:, None, None] * eye
        try:
            G = torch.linalg.solve(M_reg.transpose(-1, -2), (-N).transpose(-1, -2)).transpose(-1, -2)
        except RuntimeError:
            G = -torch.matmul(N, torch.linalg.pinv(M_reg))
        G = torch.nan_to_num(G, nan=0.0, posinf=0.0, neginf=0.0)
        gate_clip = float(getattr(self.cfg, "gate_clip", 50.0))
        if math.isfinite(gate_clip) and gate_clip > 0:
            G = G.clamp(min=-gate_clip, max=gate_clip)
        out = s_twd + torch.einsum("bij,bj->bi", G, s_tsi - s_twd)
        return torch.nan_to_num(out, nan=0.0, posinf=gate_clip, neginf=-gate_clip)


def make_it_cfg(args: Args, n_samples: Optional[int] = None) -> object:
    cfg = it.Config()
    cfg.outdir = args.outdir
    cfg.seed = int(args.seed)
    cfg.device = args.device
    cfg.dtype = args.dtype
    cfg.n_ref = int(args.n_ref)
    cfg.gate_n = effective_gate_n(args)
    cfg.bank_coupling = canonical_bank_coupling(args.bank_coupling)
    cfg.n_samples = int(args.n_q_samples if n_samples is None else n_samples)
    cfg.n_truth = int(args.n_eval)
    cfg.t_min = float(args.t_min)
    cfg.t_max = float(args.t_max)
    cfg.t_start = float(args.t_max)
    cfg.t_end = float(args.t_min)
    cfg.time_schedule = args.time_schedule
    cfg.n_steps = int(args.sample_steps)
    cfg.pf_steps = int(args.pf_steps)
    cfg.eval_chunk = int(args.eval_chunk)
    cfg.rho_batch = int(args.rho_batch)
    cfg.score_clip = float(args.score_clip)
    cfg.sample_clip = float(args.sample_clip)
    cfg.gate_clip = float(args.gate_clip)
    cfg.resolvent_eps = float(args.resolvent_eps)
    cfg.pf_div_clip = float(args.pf_div_clip)
    cfg.pf_divergence = "auto"
    cfg.hutchinson_probes = int(args.hutchinson_probes)
    cfg.hutchinson_eps = float(args.hutchinson_eps)
    cfg.kde_bandwidth = float(args.kde_bandwidth)
    cfg.kde_min_bandwidth = float(args.kde_min_bandwidth)
    cfg.kde_chunk = int(args.kde_chunk)
    cfg.matrix_ridge = float(args.matrix_ridge)
    cfg.matrix_ridge_rel = float(args.matrix_ridge_rel)
    cfg.final_denoise = bool(args.final_denoise)
    return cfg


class PFDensity:
    def __init__(self, name: str, target, fit_x: torch.Tensor, method: str, args: Args, hessian_source: str = "full", gate_x: Optional[torch.Tensor] = None):
        self.name = name
        self.target = target
        self.method = method
        self.args = args
        self.cfg = make_it_cfg(args)
        bank_target = GNHessianTargetView(target) if hessian_source == "gn" else target
        self.bank = DensitySNISScoreBank(bank_target, fit_x, self.cfg, gate_anchors=gate_x)
        self.hessian_source = hessian_source
        self.fit_seconds = 0.0
        self.last_pf_info: Dict[str, object] = {}
        self.last_sample_info: Dict[str, object] = {}

    @torch.no_grad()
    def score(self, y: torch.Tensor, t: float) -> torch.Tensor:
        return self.bank.estimate(y, t, self.method)

    @torch.no_grad()
    def sample(self, n: int, generator: torch.Generator) -> torch.Tensor:
        if bool(getattr(self.args, "use_benchmark_sampler", True)) and bool(getattr(self.cfg, "final_denoise", True)) and bs is not None and hasattr(bs, "heun_sde"):
            def fn(yy, tt):
                if torch.is_tensor(tt):
                    tt_val = float(tt.detach().cpu().item())
                else:
                    tt_val = float(tt)
                return self.bank.estimate(yy, tt_val, self.method)
            x, ms, fail = bs.heun_sde(
                fn, int(n), int(self.target.d), n_steps=int(self.cfg.n_steps),
                t_max=float(self.cfg.t_max), t_min=float(self.cfg.t_min),
                device=self.target.device, time_schedule=str(self.cfg.time_schedule),
            )
            self.last_sample_info = {"failed": bool(fail), "max_abs_score": float(ms), "sampler": "benchmark_sweep.heun_sde"}
            return x.detach()
        old_n = self.cfg.n_samples
        self.cfg.n_samples = int(n)
        x, info = it.reverse_ou_heun_sde(
            self.bank.target,
            lambda yy, tt: self.bank.estimate(yy, tt, self.method),
            self.cfg,
            generator,
            n_samples=int(n),
            final_denoise=bool(self.cfg.final_denoise),
        )
        self.cfg.n_samples = old_n
        self.last_sample_info = dict(info)
        return x.detach()

    @torch.no_grad()
    def log_prob(self, x: torch.Tensor) -> torch.Tensor:
        logq, info = it.pf_logprob_bank(self.bank, x, self.method, self.cfg)
        self.last_pf_info = dict(info)
        return logq.detach()


# -----------------------------------------------------------------------------
# Direct normalized density baselines
# -----------------------------------------------------------------------------


class KDEDensity:
    def __init__(self, fit_x: torch.Tensor, args: Args, name: str = "kde"):
        self.name = name
        self.x = fit_x.detach()
        self.device = self.x.device
        self.dtype = self.x.dtype
        self.N, self.d = self.x.shape
        if float(args.kde_bandwidth) > 0:
            self.h = float(args.kde_bandwidth)
        else:
            h0 = median_bandwidth(self.x, max_n=min(1200, self.N))
            self.h = max(h0 * (float(self.N) ** (-1.0 / float(self.d + 4))), float(args.kde_min_bandwidth))
        self.chunk = int(args.kde_chunk)

    @torch.no_grad()
    def sample(self, n: int, generator: torch.Generator) -> torch.Tensor:
        idx = torch.randint(0, self.N, (int(n),), device=self.device, generator=generator)
        return self.x[idx] + self.h * torch.randn((int(n), self.d), device=self.device, dtype=self.dtype, generator=generator)

    @torch.no_grad()
    def log_prob(self, x: torch.Tensor) -> torch.Tensor:
        h2 = max(self.h * self.h, 1.0e-12)
        log_norm = -0.5 * self.d * math.log(2.0 * math.pi) - self.d * math.log(self.h)
        outs = []
        for start in range(0, x.shape[0], self.chunk):
            xx = x[start : start + self.chunk]
            logits = -0.5 * pairwise_sq_dists(xx, self.x) / h2
            outs.append(log_norm + torch.logsumexp(logits, dim=1) - math.log(self.N))
        return torch.cat(outs, dim=0)


class GaussianMixtureEighDensity:
    def __init__(self, name: str, means: torch.Tensor, evecs: torch.Tensor, cov_eigs: torch.Tensor, args: Args):
        self.name = name
        self.means = means.detach()
        self.evecs = evecs.detach()
        self.cov_eigs = cov_eigs.detach().clamp_min(1.0e-12)
        self.N, self.d = self.means.shape
        self.device = self.means.device
        self.dtype = self.means.dtype
        self.chunk = int(args.kde_chunk)
        self.logdet = torch.log(self.cov_eigs).sum(dim=1)
        self.sqrt_cov_eigs = torch.sqrt(self.cov_eigs)

    @torch.no_grad()
    def sample(self, n: int, generator: torch.Generator) -> torch.Tensor:
        idx = torch.randint(0, self.N, (int(n),), device=self.device, generator=generator)
        z = torch.randn((int(n), self.d), device=self.device, dtype=self.dtype, generator=generator)
        return self.means[idx] + torch.einsum("bij,bj->bi", self.evecs[idx], self.sqrt_cov_eigs[idx] * z)

    @torch.no_grad()
    def log_prob(self, x: torch.Tensor) -> torch.Tensor:
        const = -0.5 * self.d * math.log(2.0 * math.pi)
        outs = []
        for start in range(0, x.shape[0], self.chunk):
            xx = x[start : start + self.chunk]
            diff = xx[:, None, :] - self.means[None, :, :]
            # component-local eigencoordinates
            diff_e = torch.einsum("bnj,njk->bnk", diff, self.evecs)
            mahal = torch.sum(diff_e.square() / self.cov_eigs[None, :, :], dim=2)
            logits = const - 0.5 * (self.logdet[None, :] + mahal)
            outs.append(torch.logsumexp(logits, dim=1) - math.log(self.N))
        return torch.cat(outs, dim=0)


def make_psd_eigh(H: torch.Tensor, args: Args) -> Tuple[torch.Tensor, torch.Tensor]:
    evals, evecs = torch.linalg.eigh(sym(H))
    lam = torch.clamp(evals, min=float(args.precision_floor), max=float(args.precision_cap))
    return lam, evecs


def make_laplace_mixture(target, fit_x: torch.Tensor, args: Args) -> GaussianMixtureEighDensity:
    with torch.no_grad():
        s = target.score(fit_x, t=0.0)
        H = target.observed_information(fit_x, t=0.0)
        lam, V = make_psd_eigh(H, args)
        s_e = torch.einsum("bji,bj->bi", V, s)
        shift = torch.einsum("bij,bj->bi", V, s_e / lam)
        means = fit_x + shift
        cov_eigs = 1.0 / lam
    return GaussianMixtureEighDensity("laplace_mixture", means, V, cov_eigs, args)


def make_local_linear_langevin_mixture(target, fit_x: torch.Tensor, args: Args) -> GaussianMixtureEighDensity:
    with torch.no_grad():
        s = target.score(fit_x, t=0.0)
        H = target.observed_information(fit_x, t=0.0)
        lam, V = make_psd_eigh(H, args)
        h = float(args.lll_h)
        s_e = torch.einsum("bji,bj->bi", V, s)
        mean_factor = (1.0 - torch.exp(-h * lam)) / lam
        cov_eigs = (1.0 - torch.exp(-2.0 * h * lam)) / lam
        shift = torch.einsum("bij,bj->bi", V, mean_factor * s_e)
        means = fit_x + shift
    return GaussianMixtureEighDensity("local_linear_langevin_mixture", means, V, cov_eigs, args)



class CachedDensity:
    """Thin wrapper that avoids repeated expensive PF log_prob evaluations."""

    def __init__(self, base, eval_x: torch.Tensor, eval_logq: torch.Tensor, q_x: torch.Tensor, q_logq: torch.Tensor):
        self.base = base
        self.name = getattr(base, "name", base.__class__.__name__)
        self.eval_x = eval_x
        self.eval_logq = eval_logq
        self.q_x = q_x
        self.q_logq = q_logq
        self.fit_seconds = getattr(base, "fit_seconds", 0.0)
        self.last_pf_info = getattr(base, "last_pf_info", {})
        self.last_sample_info = getattr(base, "last_sample_info", {})

    def __getattr__(self, key):
        return getattr(self.base, key)

    def sample(self, n: int, generator: torch.Generator) -> torch.Tensor:
        return self.base.sample(n, generator)

    def log_prob(self, x: torch.Tensor) -> torch.Tensor:
        if x.data_ptr() == self.eval_x.data_ptr() and tuple(x.shape) == tuple(self.eval_x.shape):
            return self.eval_logq
        if x.data_ptr() == self.q_x.data_ptr() and tuple(x.shape) == tuple(self.q_x.shape):
            return self.q_logq
        return self.base.log_prob(x)


class BenchmarkTargetAdapter:
    """Adapter that exposes benchmark_sweep targets to the density/PF code.

    The wrapped object is the actual benchmark_sweep target class, so GMM/funnel
    parameters, native coordinates, score/Hessian algebra, plot projection, and
    sample_reference behavior are inherited from the benchmark implementation.
    """

    def __init__(self, base, device: torch.device, dtype: torch.dtype, logZ_oracle: Optional[float] = None):
        self.base = base
        self.device = device
        self.dtype = dtype
        self.d = int(getattr(base, "d", getattr(base, "D")))
        self.D = int(getattr(base, "D", self.d))
        self.variant_name = getattr(base, "variant_name", base.__class__.__name__)
        self.name = self.variant_name
        self.variant_desc = getattr(base, "variant_desc", "")
        self.logZ_oracle = logZ_oracle

    def __getattr__(self, name):
        return getattr(self.base, name)

    def log_prob(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        if abs(float(t)) > 0.0:
            raise NotImplementedError("benchmark_sweep target adapter only exposes t=0 log_prob")
        return self.base.log_prob(x)

    def log_unnorm(self, x: torch.Tensor) -> torch.Tensor:
        return self.base.log_prob(x)

    def energy(self, x: torch.Tensor) -> torch.Tensor:
        return -self.base.log_prob(x)

    def score(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        if abs(float(t)) > 0.0:
            raise NotImplementedError("benchmark_sweep target adapter only exposes t=0 score")
        return self.base.score(x)

    def hessian(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        if abs(float(t)) > 0.0:
            raise NotImplementedError("benchmark_sweep target adapter only exposes t=0 Hessian")
        return self.base.hessian(x)

    def observed_information(self, x: torch.Tensor, t: float = 0.0) -> torch.Tensor:
        return self.hessian(x, t=t)

    @torch.no_grad()
    def sample_reference(self, n: int, **kwargs) -> torch.Tensor:
        # Explicitly pass device so benchmark_sweep's import-time default DEVICE
        # cannot leak into this script.
        if hasattr(self.base, "sample_reference"):
            try:
                return self.base.sample_reference(int(n), device=self.device, **kwargs).to(device=self.device, dtype=self.dtype).detach()
            except TypeError:
                return self.base.sample_reference(int(n), device=self.device).to(device=self.device, dtype=self.dtype).detach()
        raise AttributeError("wrapped benchmark target has no sample_reference")

    @torch.no_grad()
    def sample(self, n: int, generator: Optional[torch.Generator] = None) -> torch.Tensor:
        # benchmark_sweep uses the global torch RNG.  We intentionally do the same
        # here rather than threading a private generator, so target pools match
        # benchmark_sweep after torch.manual_seed(args.seed).
        return self.sample_reference(int(n))

    def plot_projection(self, x: torch.Tensor, fit_ref: Optional[torch.Tensor] = None) -> torch.Tensor:
        if hasattr(self.base, "plot_projection"):
            return self.base.plot_projection(x, fit_ref=fit_ref)
        return x[:, :2]


# -----------------------------------------------------------------------------
# Benchmark target construction
# -----------------------------------------------------------------------------


def make_target(key: str, args: Args, device: torch.device, dtype: torch.dtype):
    k = str(key).lower().strip().replace("-", "_")
    if k in {"gmm", "gmm8", "gmm_8d", "stiff_misaligned_gmm", "misaligned_gmm", "misaligned_subspace_gmm_d8"}:
        # Exact benchmark_sweep target, not the whitened iterative-DRC variant.
        if bs is not None and hasattr(bs, "MisalignedSingularSubspaceGMMTarget"):
            bs.DEVICE = device
            if hasattr(bs, "DTYPE"):
                bs.DTYPE = dtype
            base = bs.MisalignedSingularSubspaceGMMTarget(d=8, rank=3)
            return BenchmarkTargetAdapter(base, device=device, dtype=dtype, logZ_oracle=0.0)
        # Fallback is distribution-equivalent but not sample-identical because the
        # Cholesky factor differs by an orthogonal rotation of Gaussian noise.
        tgt = it.MisalignedSubspaceGMM(d=8, rank=3, n_components=8, seed=29, normalize=False, device=device, dtype=dtype)
        tgt.name = "misaligned_subspace_gmm_d8"
        tgt.variant_name = "misaligned_subspace_gmm_d8"
        tgt.logZ_oracle = 0.0
        return tgt
    if k in {"funnel", "funnel_d10", "neal_funnel", "neal_funnel_d10"}:
        eta2 = float(os.environ.get("LFGI_BENCH_FUNNEL_ETA2", "6.0"))
        if bs is not None and hasattr(bs, "FunnelTarget"):
            bs.DEVICE = device
            if hasattr(bs, "DTYPE"):
                bs.DTYPE = dtype
            base = bs.FunnelTarget(d=10, eta2=eta2)
            return BenchmarkTargetAdapter(base, device=device, dtype=dtype, logZ_oracle=funnel_logZ_constant(10, eta2))
        tgt = it.NealFunnelTarget(d=10, eta2=eta2, normalize=False, device=device, dtype=dtype)
        tgt.name = "funnel_d10"
        tgt.variant_name = "funnel_d10"
        tgt.logZ_oracle = funnel_logZ_constant(10, eta2)
        return tgt
    if k in {"nonlinear_inverse", "nonlinear_inverse_d8", "nonlinear_sine_inverse_d8", "nonlinear_sine_inverse_d8_clean", "nonlinear_inverse_clean"}:
        if bs is not None and hasattr(bs, "NonlinearSineInverseD8Target"):
            bs.DEVICE = device
            if hasattr(bs, "DTYPE"):
                bs.DTYPE = dtype
            base = bs.NonlinearSineInverseD8Target(variant=args.inverse_variant)
            return BenchmarkTargetAdapter(base, device=device, dtype=dtype, logZ_oracle=None)
        return NonlinearSineInverseD8Target(variant=args.inverse_variant, device=device, dtype=dtype)
    if k in {
        "darcy", "darcy_kl", "darcy_d16", "darcy_kl_d16",
        "ambiguous_darcy", "ambiguous_darcy_d16", "ambiguous_darcy_kl_d16",
        "darcy_flow", "darcy_flow_kl", "darcy_flow_kl_d16",
    }:
        return DarcyFlowKLTarget(
            d=int(args.darcy_dim),
            grid_n=int(args.darcy_grid_n),
            n_obs=int(args.darcy_n_obs),
            n_holdout_obs=int(args.darcy_n_holdout_obs),
            noise_std=float(args.darcy_noise_std),
            sensor_mode=str(args.darcy_sensor_mode),
            prior_ell=float(args.darcy_prior_ell),
            prior_sigma=float(args.darcy_prior_sigma),
            truth_scale=float(args.darcy_truth_scale),
            seed=int(args.seed),
            device=device,
            dtype=dtype,
            log_batch_size=int(args.darcy_log_batch_size),
            grad_batch_size=int(args.darcy_grad_batch_size),
            hess_batch_size=int(args.darcy_hess_batch_size),
        )
    raise ValueError(f"Unknown target {key!r}")


def target_keys(args: Args) -> List[str]:
    k = args.target.strip().lower()
    if k in {"all", "minimal", "suite"}:
        return ["gmm_8d", "funnel_d10", "nonlinear_inverse_d8"]
    if k in {"pde", "inverse_pde", "darcy_suite"}:
        return ["ambiguous_darcy_kl_d16"]
    return [s.strip() for s in args.target.replace(";", ",").split(",") if s.strip()]


def method_names(args: Args) -> List[str]:
    return [s.strip() for s in args.methods.replace(";", ",").split(",") if s.strip()]


def sample_target(target, n: int, args: Args, generator: torch.Generator) -> torch.Tensor:
    if isinstance(target, DarcyFlowKLTarget):
        return target.sample(
            n,
            generator=generator,
            steps=int(args.darcy_mala_steps),
            step_size=float(args.darcy_mala_step_size),
            burnin_frac=float(args.darcy_mala_burnin_frac),
            init=str(args.darcy_mala_init),
        )
    if isinstance(target, NonlinearSineInverseD8Target):
        return target.sample(
            n,
            generator=generator,
            steps=int(args.inverse_mala_steps),
            step_size=float(args.inverse_mala_step_size),
            burnin_frac=float(args.inverse_mala_burnin_frac),
        )
    if isinstance(target, BenchmarkTargetAdapter):
        return target.sample_reference(int(n)).detach()
    return target.sample(n, generator=generator).detach()


def build_density(method: str, target, fit_x: torch.Tensor, args: Args, gate_x: Optional[torch.Tensor] = None):
    m = method.strip().lower().replace("-", "_")
    t0 = time.time()
    if m == "tweedie_pf":
        q = PFDensity("tweedie_pf", target, fit_x, "tweedie", args, gate_x=gate_x)
    elif m in {"scalar_blend_pf", "blend_pf"}:
        q = PFDensity("scalar_blend_pf", target, fit_x, "blend", args, gate_x=gate_x)
    elif m in {"plugin_matrix_blend_pf", "plugin_blend_pf", "primal_matrix_blend_pf", "matrix_blend_pf"}:
        q = PFDensity("plugin_matrix_blend_pf", target, fit_x, "plugin-matrix-blend", args, gate_x=gate_x)
    elif m in {"centered_matrix_blend_pf", "centered_blend_pf", "regression_blend_pf"}:
        q = PFDensity("centered_matrix_blend_pf", target, fit_x, "centered-matrix-blend", args, gate_x=gate_x)
    elif m in {"lfgi_pf", "ce_hlsi_pf", "ce_hlsi"}:
        q = PFDensity("lfgi_pf", target, fit_x, "ce-hlsi", args, gate_x=gate_x)
    elif m in {"gn_lfgi_pf", "gn_lfgi"}:
        if not hasattr(target, "gn_hessian"):
            return None
        q = PFDensity("gn_lfgi_pf", target, fit_x, "ce-hlsi", args, hessian_source="gn", gate_x=gate_x)
    elif m == "kde":
        q = KDEDensity(fit_x, args, name="kde")
    elif m == "laplace_mixture":
        q = make_laplace_mixture(target, fit_x, args)
    elif m in {"local_linear_langevin_mixture", "lll_mixture", "langevin_mixture"}:
        q = make_local_linear_langevin_mixture(target, fit_x, args)
    else:
        raise ValueError(f"Unknown method {method!r}")
    q.fit_seconds = time.time() - t0
    return q


# -----------------------------------------------------------------------------
# Metrics and evidence estimators
# -----------------------------------------------------------------------------


@torch.no_grad()
def density_metrics(target, q, eval_x: torch.Tensor, q_x: torch.Tensor, args: Args) -> Dict[str, object]:
    t0 = time.time()
    logq_eval = q.log_prob(eval_x)
    logp_eval = target_log_unnorm(target, eval_x)
    energy_eval = -logp_eval
    logp_norm = target_log_prob_norm(target, eval_x)
    out: Dict[str, object] = {
        "heldout_nll": safe_float((-logq_eval).mean()),
        "logq_eval_mean": safe_float(logq_eval.mean()),
        "logq_eval_std": safe_float(logq_eval.std(unbiased=False)),
        "logp_unnorm_eval_mean": safe_float(logp_eval.mean()),
        "log_ratio_eval_mean": safe_float((logp_eval - logq_eval).mean()),
        "log_ratio_eval_std": safe_float((logp_eval - logq_eval).std(unbiased=False)),
        "energy_corr_neglogq": pearson_corr(-logq_eval, energy_eval),
        "energy_centered_rmse_neglogq": centered_rmse(-logq_eval, energy_eval),
        "density_eval_seconds": time.time() - t0,
    }
    if logp_norm is not None:
        out["log_density_rmse"] = safe_float(torch.sqrt(torch.mean((logq_eval - logp_norm) ** 2)))
        out["centered_log_density_rmse"] = centered_rmse(logq_eval, logp_norm)
    else:
        out["log_density_rmse"] = float("nan")
        out["centered_log_density_rmse"] = centered_rmse(logq_eval, logp_eval)

    # Reciprocal weights on target samples: E_p[q / ptilde] = 1/Z.
    logw_rev = logq_eval - logp_eval
    ess, ess_frac, max_frac = log_weight_ess(logw_rev)
    out.update({
        "reverse_weight_ess": ess,
        "reverse_weight_ess_frac": ess_frac,
        "reverse_weight_max_frac": max_frac,
    })

    logq_q = q.log_prob(q_x)
    logp_q = target_log_unnorm(target, q_x)
    energy_q = -logp_q
    out.update({
        "q_energy_mean": safe_float(energy_q.mean()),
        "q_energy_std": safe_float(energy_q.std(unbiased=False)),
        "q_logq_mean": safe_float(logq_q.mean()),
        "q_logp_unnorm_mean": safe_float(logp_q.mean()),
    })
    return out


# -----------------------------------------------------------------------------
# Standard sample-quality metrics from benchmark_sweep.py
# -----------------------------------------------------------------------------


def target_score0(target, x: torch.Tensor) -> torch.Tensor:
    try:
        return target.score(x, t=0.0)
    except TypeError:
        return target.score(x)


@torch.no_grad()
def benchmark_mmd(X: torch.Tensor, Y: torch.Tensor, bws=(0.5, 1.0, 2.0, 5.0, 10.0), max_points: Optional[int] = None) -> float:
    """Exact benchmark_sweep.py multi-bandwidth RBF MMD.

    Important: benchmark_sweep.mmd ignores LFGI_BENCH_METRIC_MAX and always
    uses X[:min(len(X), 2000)] and Y[:min(len(Y), 2000)] independently.
    We preserve that behavior here rather than pre-truncating both samples to
    metric_max, because otherwise nominally identical runs get different MMDs.
    """
    if bs is not None and hasattr(bs, "mmd"):
        return float(bs.mmd(X, Y, bws=bws))
    n = min(len(X), 2000)
    m = min(len(Y), 2000)
    if n <= 1 or m <= 1:
        return float("nan")
    X = X[:n]
    Y = Y[:m]
    xx = torch.cdist(X, X) ** 2
    yy = torch.cdist(Y, Y) ** 2
    xy = torch.cdist(X, Y) ** 2
    gs = [0.5 / (float(b) ** 2) for b in bws]
    v = sum(((-g * xx).exp().mean() + (-g * yy).exp().mean() - 2.0 * (-g * xy).exp().mean()) for g in gs)
    return safe_float(v / len(gs))


@torch.no_grad()
def benchmark_ksd_rbf(samples: torch.Tensor, score_fn, bandwidth="median", max_points: int = 1000) -> float:
    """RBF KSD implementation matching benchmark_sweep.py."""
    n = min(int(max_points), len(samples))
    X = samples[:n]
    if n < 5 or not torch.isfinite(X).all():
        return float("nan")
    S = score_fn(X)
    d = X.shape[1]
    dmat = torch.cdist(X, X)
    positive = dmat[dmat > 0]
    med = torch.median(positive).item() if positive.numel() else 1.0
    h = med if (np.isfinite(med) and med > 1.0e-12) else 1.0
    if bandwidth != "median":
        h = float(bandwidth)
    d2 = dmat ** 2
    K = torch.exp(-d2 / (2.0 * h ** 2))
    diff = X.unsqueeze(1) - X.unsqueeze(0)
    term1 = K * (S @ S.T)
    sdiff = S.unsqueeze(1) - S.unsqueeze(0)
    term2 = -(K.unsqueeze(-1) * sdiff * diff).sum(-1) / (h ** 2)
    term4 = K * (d / (h ** 2) - d2 / (h ** 4))
    U = term1 + term2 + term4
    ksd2 = U.mean()
    return safe_float(torch.sqrt(ksd2.clamp(min=0.0)))


@torch.no_grad()
def benchmark_sliced_w2_distance(X: torch.Tensor, Y: torch.Tensor, n_projections: int = 256, max_points: Optional[int] = None, seed: int = 0) -> float:
    """Exact benchmark_sweep.py sliced W2 distance.

    This delegates to benchmark_sweep.sliced_w2_distance when available so the
    reshape, random subsampling, direction seeding, and sqrt(mean squared 1D
    transport error) are identical.  Pass max_points=args.metric_max to emulate
    the usual LFGI_BENCH_METRIC_MAX cap.
    """
    if bs is not None and hasattr(bs, "sliced_w2_distance"):
        return float(bs.sliced_w2_distance(
            X, Y,
            n_projections=int(n_projections),
            max_points=max_points,
            seed=int(seed),
        ))
    if X.dim() > 2:
        X = X.reshape(X.shape[0], -1)
    if Y.dim() > 2:
        Y = Y.reshape(Y.shape[0], -1)
    if max_points is None:
        max_points = int(os.environ.get("LFGI_BENCH_METRIC_MAX", "4096"))
    n = min(int(max_points), X.shape[0], Y.shape[0])
    if n <= 1:
        return float("inf")
    X = X[torch.randperm(X.shape[0], device=X.device)[:n]]
    Y = Y[torch.randperm(Y.shape[0], device=Y.device)[:n]]
    d = X.shape[1]
    gen = torch.Generator(device=X.device)
    gen.manual_seed(int(seed))
    dirs = torch.randn(int(n_projections), d, generator=gen, dtype=X.dtype, device=X.device)
    dirs = dirs / torch.linalg.norm(dirs, dim=1, keepdim=True).clamp_min(1.0e-30)
    Xp = torch.sort(X @ dirs.T, dim=0).values
    Yp = torch.sort(Y @ dirs.T, dim=0).values
    return safe_float(torch.sqrt((Xp - Yp).square().mean()))


@torch.no_grad()
def sampling_metrics(target, eval_x: torch.Tensor, q_x: torch.Tensor, args: Args, seed: int = 0) -> Dict[str, object]:
    """Reference-sample metrics with benchmark_sweep.py semantics.

    MMD is intentionally evaluated on the full arrays passed here, because
    benchmark_sweep.mmd performs its own fixed first-2000 cap.  Sliced W2 uses
    benchmark_sweep.sliced_w2_distance with max_points=args.metric_max, matching
    the LFGI_BENCH_METRIC_MAX-style cap used elsewhere in that script.
    """
    n = min(int(args.metric_max), eval_x.shape[0], q_x.shape[0])
    if n <= 1:
        return {"sampling_metric_n": int(n), "sw2": float("nan"), "mmd": float("nan"), "ksd": float("nan")}
    return {
        "sampling_metric_n": int(n),
        "sw2": benchmark_sliced_w2_distance(
            q_x, eval_x,
            n_projections=int(args.sw2_projections),
            max_points=int(args.metric_max),
            seed=int(seed),
        ),
        "mmd": benchmark_mmd(q_x, eval_x),
        "ksd": benchmark_ksd_rbf(q_x, lambda z: target_score0(target, z), max_points=int(args.ksd_max_points)),
    }


@torch.no_grad()
def estimate_logZ_forward(target, q, q_x: torch.Tensor) -> Dict[str, object]:
    logq = q.log_prob(q_x)
    logp = target_log_unnorm(target, q_x)
    logw = logp - logq
    ess, ess_frac, max_frac = log_weight_ess(logw)
    return {
        "estimator": "forward_is",
        "logZ_hat": safe_float(logmeanexp(logw)),
        "ess": ess,
        "ess_frac": ess_frac,
        "max_weight_frac": max_frac,
        "logw_mean": safe_float(logw.mean()),
        "logw_std": safe_float(logw.std(unbiased=False)),
    }


@torch.no_grad()
def estimate_logZ_reverse(target, q, eval_x: torch.Tensor) -> Dict[str, object]:
    logq = q.log_prob(eval_x)
    logp = target_log_unnorm(target, eval_x)
    logw = logq - logp
    ess, ess_frac, max_frac = log_weight_ess(logw)
    return {
        "estimator": "reverse_reciprocal_is",
        "logZ_hat": safe_float(-logmeanexp(logw)),
        "ess": ess,
        "ess_frac": ess_frac,
        "max_weight_frac": max_frac,
        "logw_mean": safe_float(logw.mean()),
        "logw_std": safe_float(logw.std(unbiased=False)),
    }


@torch.no_grad()
def estimate_logZ_bridge(target, q, eval_x: torch.Tensor, q_x: torch.Tensor, init_logZ: Optional[float] = None, iters: int = 50) -> Dict[str, object]:
    # Meng-Wong style fixed-point bridge update for target unnormalized ptilde and normalized q.
    logp_x = target_log_unnorm(target, eval_x)
    logq_x = q.log_prob(eval_x)
    logp_y = target_log_unnorm(target, q_x)
    logq_y = q.log_prob(q_x)
    n1 = max(1, int(eval_x.shape[0]))  # target samples
    n2 = max(1, int(q_x.shape[0]))     # q samples
    s1 = n1 / float(n1 + n2)
    s2 = n2 / float(n1 + n2)
    log_s1 = math.log(s1)
    log_s2 = math.log(s2)
    if init_logZ is None or not math.isfinite(float(init_logZ)):
        logr = safe_float(logmeanexp(logp_y - logq_y))
        if not math.isfinite(logr):
            logr = 0.0
    else:
        logr = float(init_logZ)
    for _ in range(int(iters)):
        lr = torch.as_tensor(logr, device=eval_x.device, dtype=eval_x.dtype)
        den_y = torch_logaddexp(torch.as_tensor(log_s1, device=eval_x.device, dtype=eval_x.dtype) + logp_y,
                                torch.as_tensor(log_s2, device=eval_x.device, dtype=eval_x.dtype) + lr + logq_y)
        den_x = torch_logaddexp(torch.as_tensor(log_s1, device=eval_x.device, dtype=eval_x.dtype) + logp_x,
                                torch.as_tensor(log_s2, device=eval_x.device, dtype=eval_x.dtype) + lr + logq_x)
        new_logr = safe_float(logmeanexp(logp_y - den_y) - logmeanexp(logq_x - den_x))
        if not math.isfinite(new_logr):
            break
        if abs(new_logr - logr) < 1.0e-7:
            logr = new_logr
            break
        logr = new_logr
    # Bridge does not have a simple IS ESS; report fwd/rev ESS-like overlap proxies.
    fwd_ess, fwd_frac, fwd_max = log_weight_ess(logp_y - logq_y)
    return {
        "estimator": "bridge_fixed_point",
        "logZ_hat": float(logr),
        "ess": fwd_ess,
        "ess_frac": fwd_frac,
        "max_weight_frac": fwd_max,
        "logw_mean": safe_float((logp_y - logq_y).mean()),
        "logw_std": safe_float((logp_y - logq_y).std(unbiased=False)),
    }


def add_logZ_error(row: Dict[str, object], target) -> Dict[str, object]:
    logZ_ref = getattr(target, "logZ_oracle", None)
    if logZ_ref is not None and math.isfinite(float(logZ_ref)):
        row["logZ_ref"] = float(logZ_ref)
        row["abs_logZ_err"] = abs(float(row["logZ_hat"]) - float(logZ_ref)) if math.isfinite(float(row["logZ_hat"])) else float("nan")
    else:
        row["logZ_ref"] = float("nan")
        row["abs_logZ_err"] = float("nan")
    return row


# -----------------------------------------------------------------------------
# Plotting and CSV
# -----------------------------------------------------------------------------


def fit_pca(x: torch.Tensor) -> Tuple[np.ndarray, np.ndarray]:
    z = x.detach().cpu().double().numpy()
    mean = z.mean(axis=0)
    X = z - mean[None, :]
    _, _, vh = np.linalg.svd(X, full_matrices=False)
    basis = vh[:2].T
    if basis.shape[1] < 2:
        basis = np.eye(z.shape[1], 2)
    return mean, basis


def project(x: torch.Tensor, mean: np.ndarray, basis: np.ndarray) -> np.ndarray:
    z = x.detach().cpu().double().numpy()
    return (z - mean[None, :]) @ basis


def paper_method_label(name: str) -> str:
    key = str(name).strip().lower().replace("_", "-")
    labels = {
        "tweedie-pf": "TWEEDIE",
        "scalar-blend-pf": "SCALAR BLEND",
        "plugin-matrix-blend-pf": "PLUGIN MATRIX BLEND",
        "centered-matrix-blend-pf": "CENTERED MATRIX BLEND",
        "lfgi-pf": "LFGI BLEND",
        "gn-lfgi-pf": "GN-LFGI BLEND",
        "kde": "KDE",
        "laplace-mixture": "LAPLACE MIXTURE",
        "local-linear-langevin-mixture": "LOCAL LINEAR LANGEVIN",
        "gt-floor": "GT FLOOR",
        "true-target": "GT FLOOR",
    }
    return labels.get(key, key.replace("-", " ").upper())




def pretty_target_title(target) -> str:
    name = target_name(target)
    low = name.lower()
    if "funnel" in low:
        d = int(getattr(target, "d", getattr(target, "D", 10)))
        return rf"Neal Funnel ($d={d}$)"
    if "misaligned" in low or "gmm" in low:
        d = int(getattr(target, "d", getattr(target, "D", 0)))
        return rf"Stiff Misaligned GMM ($d={d}$)"
    if "inverse" in low:
        d = int(getattr(target, "d", getattr(target, "D", 0)))
        return rf"Nonlinear Inverse Problem ($d={d}$)"
    return name.replace("_", " ")


def _target_plot_coords(target, x: torch.Tensor, fit_ref: Optional[torch.Tensor] = None) -> Optional[torch.Tensor]:
    if not hasattr(target, "plot_projection"):
        return None
    try:
        return target.plot_projection(x, fit_ref=fit_ref)
    except TypeError:
        try:
            return target.plot_projection(x)
        except Exception:
            return None
    except Exception:
        return None


def make_heatmap_projection(target, eval_x: torch.Tensor, samples_by_method: Dict[str, torch.Tensor], args: Args):
    """Match benchmark_sweep.py's 2D heatmap projection conventions exactly."""
    max_n = int(args.max_plot_samples)
    ref = eval_x[: min(max_n, eval_x.shape[0])]
    tname = target_name(target).lower()

    if "funnel" in tname and hasattr(target, "plot_projection"):
        def coord_getter(z: torch.Tensor) -> torch.Tensor:
            return target.plot_projection(z, fit_ref=ref)
        gt_coords_t = coord_getter(ref)
        projection_label = "Funnel coordinates"
        axis_labels = (r"$x_1$", r"$x_2$")
        panel_aspect = "auto"
        pca_mean = None
        pca_basis = None
    elif hasattr(target, "plot_projection"):
        # For benchmark GMM, this calls GenericPotentialTarget.plot_projection,
        # which computes PCA from fit_ref[:4096] using torch.linalg.svd.
        def coord_getter(z: torch.Tensor) -> torch.Tensor:
            return target.plot_projection(z, fit_ref=ref)
        gt_coords_t = coord_getter(ref)
        projection_label = "2D marginal/PCA projection"
        axis_labels = (r"$z_1$", r"$z_2$")
        panel_aspect = "equal"
        pca_mean = None
        pca_basis = None
    else:
        pca_mean, pca_basis = fit_pca(ref[: min(len(ref), 4096)])
        def coord_getter(z: torch.Tensor) -> torch.Tensor:
            arr = project(z, pca_mean, pca_basis)
            return torch.as_tensor(arr, device=z.device, dtype=z.dtype)
        gt_coords_t = coord_getter(ref)
        projection_label = "2D marginal/PCA projection"
        axis_labels = (r"$z_1$", r"$z_2$")
        panel_aspect = "equal"
    return coord_getter, gt_coords_t.detach().cpu().numpy(), projection_label, axis_labels, panel_aspect, pca_mean, pca_basis

def save_histogram_array(outdir: str, target, eval_x: torch.Tensor, samples_by_method: Dict[str, torch.Tensor], args: Args) -> Optional[str]:
    """Save benchmark-sweep-style 2D heatmap histogram array.

    This replaces the earlier 1D PC histograms.  It uses a common set of 2D
    histogram bins and a shared robust PowerNorm color scale across all method
    panels plus a GT-floor panel, matching the benchmark_sweep heatmap layout.
    """
    if args.skip_plots:
        return None
    ensure_dir(outdir)
    if not samples_by_method:
        return None

    max_n = int(args.max_plot_samples)
    coord_getter, gt_coords, projection_label, axis_labels, panel_aspect, pca_mean, pca_basis = make_heatmap_projection(
        target, eval_x, samples_by_method, args
    )

    # Common extent must be set from the GT floor only.  Do not include method
    # samples here: a single unstable sampler/direct baseline outlier can expand
    # the axes by orders of magnitude and make all useful panels appear blank.
    # This matches the benchmark-sweep diagnostic intent: show how each method
    # covers the target support, with out-of-support explosions clipped outside
    # the displayed target-calibrated window.
    gt_finite = gt_coords[np.isfinite(gt_coords).all(axis=1)]
    if gt_finite.shape[0] == 0:
        gt_finite = np.zeros((1, 2), dtype=np.float64)
    tname = target_name(target).lower()
    if "funnel" in tname:
        x_lo, x_hi = np.percentile(gt_finite[:, 0], [0.5, 99.0])
        y_abs = float(np.percentile(np.abs(gt_finite[:, 1]), 99.0))
        x_pad = 0.06 * max(float(x_hi - x_lo), 1.0e-9)
        y_pad = 0.06 * max(2.0 * y_abs, 1.0e-9)
        lo = np.array([x_lo - x_pad, -y_abs - y_pad], dtype=np.float64)
        hi = np.array([x_hi + x_pad, y_abs + y_pad], dtype=np.float64)
    else:
        lo = gt_finite.min(axis=0) - 0.2
        hi = gt_finite.max(axis=0) + 0.2

    bins = int(args.hist_bins)
    xedges = np.linspace(lo[0], hi[0], bins + 1)
    yedges = np.linspace(lo[1], hi[1], bins + 1)
    extent = [xedges[0], xedges[-1], yedges[0], yedges[-1]]

    def make_hist(coords: np.ndarray) -> np.ndarray:
        coords = np.asarray(coords, dtype=np.float64)
        if coords.ndim != 2 or coords.shape[1] < 2:
            return np.zeros((bins, bins), dtype=np.float64)
        coords = coords[np.isfinite(coords[:, :2]).all(axis=1)]
        if coords.shape[0] == 0:
            return np.zeros((bins, bins), dtype=np.float64)
        H, _, _ = np.histogram2d(coords[:, 0], coords[:, 1], bins=[xedges, yedges], density=False)
        H = H.astype(np.float64)
        inside = float(H.sum())
        if inside <= 0.0:
            return np.zeros((bins, bins), dtype=np.float64)
        dx = max(float(xedges[1] - xedges[0]), 1.0e-300)
        dy = max(float(yedges[1] - yedges[0]), 1.0e-300)
        # Normalize to density over the displayed GT-calibrated window.  Outliers
        # outside this window are intentionally clipped and do not expand axes.
        H = H / (inside * dx * dy)
        return H.T

    heatmap_entries: List[Tuple[str, np.ndarray]] = []
    hist_arrays: Dict[str, np.ndarray] = {}
    for m, sc in samples_by_method.items():
        if sc.shape[0] >= 10:
            coords = coord_getter(sc[: min(max_n, sc.shape[0])]).detach().cpu().numpy()
            H = make_hist(coords)
        else:
            H = np.zeros((bins, bins), dtype=np.float64)
        heatmap_entries.append((m, H))
        hist_arrays[m] = H
    H_true = make_hist(gt_coords)
    heatmap_entries.append(("GT floor", H_true))
    hist_arrays["GT floor"] = H_true

    # Color normalization is also GT-only.  Method histograms are plotted on
    # the target-calibrated density scale; they should not set their own scale
    # and they should not be allowed to inflate the shared normalization.
    positive_gt = H_true[np.isfinite(H_true) & (H_true > 0.0)]
    if positive_gt.size:
        vmax = float(np.percentile(positive_gt, float(args.hist_vmax_quantile)))
        if not np.isfinite(vmax) or vmax <= 0.0:
            vmax = float(np.max(positive_gt))
    else:
        vmax = 1.0
    vmax = max(vmax, 1.0e-12)
    gamma = min(max(float(args.hist_gamma), 0.05), 1.0)
    norm = mcolors.PowerNorm(gamma=gamma, vmin=0.0, vmax=vmax)
    interp = str(args.heatmap_interp).strip() or "nearest"

    nc = len(heatmap_entries)
    fig_w = max(7.2, 2.65 * nc)
    fig, axes_arr = plt.subplots(1, nc, figsize=(fig_w, 2.95), squeeze=False)
    axes = list(axes_arr[0])
    for ci, (name, H) in enumerate(heatmap_entries):
        ax = axes[ci]
        ax.imshow(H, origin="lower", extent=extent, aspect=panel_aspect, interpolation=interp, norm=norm)
        ax.set_title(paper_method_label(name), fontsize=12.5, pad=4)
        ax.set_xlabel(axis_labels[0])
        if ci == 0:
            ax.set_ylabel(axis_labels[1])
        else:
            ax.set_yticklabels([])
        ax.tick_params(axis="both", labelsize=9.5, length=2.5, width=0.7)
        for spine in ax.spines.values():
            spine.set_linewidth(0.8)
    fig.suptitle(f"{projection_label} — {pretty_target_title(target)}", fontsize=15.5, y=1.02)
    fig.tight_layout(pad=0.25, w_pad=0.35)
    path = os.path.join(outdir, f"histogram_array_{target_name(target)}.png")
    fig.savefig(path, dpi=220, bbox_inches="tight")
    plt.close(fig)

    np.savez(
        os.path.join(outdir, f"histogram_array_{target_name(target)}.npz"),
        xedges=xedges,
        yedges=yedges,
        extent=np.asarray(extent),
        methods=np.asarray([name for name, _ in heatmap_entries], dtype=object),
        histograms=np.stack([H for _, H in heatmap_entries], axis=0),
        pca_mean=np.asarray([]) if pca_mean is None else pca_mean,
        pca_basis=np.asarray([]) if pca_basis is None else pca_basis,
    )
    return path


def save_density_pseudohist_array(outdir: str, target, eval_x: torch.Tensor, eval_logq_by_method: Dict[str, torch.Tensor], args: Args) -> Optional[str]:
    """Save robust implicit density heatmaps induced by model densities on GT samples.

    For each method, take the ground-truth evaluation samples in the same 2D
    coordinates/window used by the sample heatmaps, compute the model density
    q(x) on those target samples, and form a weighted 2D histogram using q(x)
    as the contribution weight. This is intentionally *not* a sample histogram.

    Because PF likelihoods can occasionally produce isolated singular outliers,
    the displayed plot winsorizes log q at a configurable visible-window
    quantile before exponentiating.  This protects the diagnostic plot from a
    single pixel swallowing the color scale.  The unclipped and clipped weight
    diagnostics are saved in a sidecar CSV/NPZ so the clipping is auditable.
    """
    if args.skip_plots:
        return None
    ensure_dir(outdir)
    if not eval_logq_by_method:
        return None

    coord_getter, gt_coords, projection_label, axis_labels, panel_aspect, pca_mean, pca_basis = make_heatmap_projection(
        target, eval_x, {}, args
    )

    gt_finite = gt_coords[np.isfinite(gt_coords).all(axis=1)]
    if gt_finite.shape[0] == 0:
        gt_finite = np.zeros((1, 2), dtype=np.float64)
    tname = target_name(target).lower()
    if "funnel" in tname:
        x_lo, x_hi = np.percentile(gt_finite[:, 0], [0.5, 99.0])
        y_abs = float(np.percentile(np.abs(gt_finite[:, 1]), 99.0))
        x_pad = 0.06 * max(float(x_hi - x_lo), 1.0e-9)
        y_pad = 0.06 * max(2.0 * y_abs, 1.0e-9)
        lo = np.array([x_lo - x_pad, -y_abs - y_pad], dtype=np.float64)
        hi = np.array([x_hi + x_pad, y_abs + y_pad], dtype=np.float64)
    else:
        lo = gt_finite.min(axis=0) - 0.2
        hi = gt_finite.max(axis=0) + 0.2

    bins = int(args.hist_bins)
    xedges = np.linspace(lo[0], hi[0], bins + 1)
    yedges = np.linspace(lo[1], hi[1], bins + 1)
    extent = [xedges[0], xedges[-1], yedges[0], yedges[-1]]
    dx = max(float(xedges[1] - xedges[0]), 1.0e-300)
    dy = max(float(yedges[1] - yedges[0]), 1.0e-300)

    gt_coords = np.asarray(gt_coords, dtype=np.float64)
    gt_mask = np.isfinite(gt_coords[:, :2]).all(axis=1)
    gt_coords_masked = gt_coords[gt_mask]
    visible_mask = (
        (gt_coords_masked[:, 0] >= xedges[0]) & (gt_coords_masked[:, 0] <= xedges[-1]) &
        (gt_coords_masked[:, 1] >= yedges[0]) & (gt_coords_masked[:, 1] <= yedges[-1])
    ) if gt_coords_masked.shape[0] else np.zeros((0,), dtype=bool)

    def make_hist(coords: np.ndarray, weights: Optional[np.ndarray] = None) -> np.ndarray:
        coords = np.asarray(coords, dtype=np.float64)
        if coords.ndim != 2 or coords.shape[1] < 2:
            return np.zeros((bins, bins), dtype=np.float64)
        finite = np.isfinite(coords[:, :2]).all(axis=1)
        coords = coords[finite]
        if weights is not None:
            weights = np.asarray(weights, dtype=np.float64)
            if weights.ndim != 1:
                weights = weights.reshape(-1)
            weights = weights[finite]
            finite_w = np.isfinite(weights) & (weights > 0.0)
            coords = coords[finite_w]
            weights = weights[finite_w]
        if coords.shape[0] == 0:
            return np.zeros((bins, bins), dtype=np.float64)
        H, _, _ = np.histogram2d(coords[:, 0], coords[:, 1], bins=[xedges, yedges], density=False, weights=weights)
        H = H.astype(np.float64)
        inside = float(H.sum())
        if inside <= 0.0 or not np.isfinite(inside):
            return np.zeros((bins, bins), dtype=np.float64)
        H = H / (inside * dx * dy)
        return H.T

    H_true = make_hist(gt_coords_masked, weights=None)
    positive_gt = H_true[np.isfinite(H_true) & (H_true > 0.0)]
    if positive_gt.size:
        vmax = float(np.percentile(positive_gt, float(args.hist_vmax_quantile)))
        if not np.isfinite(vmax) or vmax <= 0.0:
            vmax = float(np.max(positive_gt))
    else:
        vmax = 1.0
    vmax = max(vmax, 1.0e-12)
    gamma = min(max(float(args.hist_gamma), 0.05), 1.0)
    norm = mcolors.PowerNorm(gamma=gamma, vmin=0.0, vmax=vmax)
    interp = str(args.heatmap_interp).strip() or "nearest"

    clip_q = float(getattr(args, "implicit_logq_clip_quantile", 99.0))
    clip_q = min(max(clip_q, 0.0), 100.0)
    temp = max(float(getattr(args, "implicit_logq_temperature", 1.0)), 1.0e-8)
    bright_p = float(getattr(args, "implicit_brightness_power", 0.5))
    if not math.isfinite(bright_p):
        bright_p = 1.0
    bright_p = min(max(bright_p, 1.0e-6), 1.0)

    heatmap_entries: List[Tuple[str, np.ndarray]] = []
    raw_hist_arrays: Dict[str, np.ndarray] = {}
    clipped_hist_arrays: Dict[str, np.ndarray] = {}
    clip_rows: List[Dict[str, object]] = []

    for m, logq_t in eval_logq_by_method.items():
        try:
            logq = logq_t.detach().cpu().double().numpy().reshape(-1)
        except Exception:
            continue
        if logq.shape[0] != gt_coords.shape[0]:
            continue
        logq = logq[gt_mask]
        finite = np.isfinite(logq)
        if finite.sum() == 0:
            H_raw = np.zeros((bins, bins), dtype=np.float64)
            H = np.zeros((bins, bins), dtype=np.float64)
            clip_rows.append({"method": m, "finite_n": 0, "visible_finite_n": 0})
        else:
            coords_f = gt_coords_masked[finite]
            logq_f = logq[finite]
            vis_f = visible_mask[finite]
            logq_vis = logq_f[vis_f]
            if logq_vis.size == 0:
                logq_vis = logq_f

            raw_shift = float(np.max(logq_f))
            raw_weights_base = np.exp((logq_f - raw_shift) / temp)
            raw_weights = raw_weights_base ** bright_p
            H_raw = make_hist(coords_f, weights=raw_weights)

            if clip_q >= 100.0:
                clip_level = float(np.max(logq_vis))
            else:
                clip_level = float(np.percentile(logq_vis, clip_q))
            if not np.isfinite(clip_level):
                clip_level = float(np.nanmax(logq_f))
            logq_clip = np.minimum(logq_f, clip_level)
            shift = float(np.max(logq_clip))
            weights_base = np.exp((logq_clip - shift) / temp)
            weights = weights_base ** bright_p
            H = make_hist(coords_f, weights=weights)

            # Diagnostics: how concentrated were raw/clipped weights on visible GT samples?
            def ess_frac_from_logw(vals: np.ndarray) -> float:
                vals = vals[np.isfinite(vals)]
                if vals.size == 0:
                    return float("nan")
                ww = np.exp(vals - np.max(vals))
                den = float(np.sum(ww * ww))
                if den <= 0.0:
                    return float("nan")
                return float((np.sum(ww) ** 2) / den / max(1, vals.size))
            clip_rows.append({
                "method": m,
                "finite_n": int(finite.sum()),
                "visible_finite_n": int(logq_vis.size),
                "clip_quantile": clip_q,
                "clip_level": clip_level,
                "logq_max_visible": float(np.max(logq_vis)) if logq_vis.size else float("nan"),
                "logq_p99_visible": float(np.percentile(logq_vis, 99.0)) if logq_vis.size else float("nan"),
                "raw_visible_ess_frac": ess_frac_from_logw((bright_p / temp) * logq_vis),
                "clipped_visible_ess_frac": ess_frac_from_logw((bright_p / temp) * np.minimum(logq_vis, clip_level)),
                "brightness_power": bright_p,
                "num_clipped_visible": int(np.sum(logq_vis > clip_level)) if logq_vis.size else 0,
                "frac_clipped_visible": float(np.mean(logq_vis > clip_level)) if logq_vis.size else float("nan"),
            })
        heatmap_entries.append((m, H))
        clipped_hist_arrays[m] = H
        raw_hist_arrays[m] = H_raw

    heatmap_entries.append(("GT floor", H_true))
    clipped_hist_arrays["GT floor"] = H_true
    raw_hist_arrays["GT floor"] = H_true

    nc = len(heatmap_entries)
    fig_w = max(7.2, 2.65 * nc)
    fig, axes_arr = plt.subplots(1, nc, figsize=(fig_w, 2.95), squeeze=False)
    axes = list(axes_arr[0])
    for ci, (name, H) in enumerate(heatmap_entries):
        ax = axes[ci]
        ax.imshow(H, origin="lower", extent=extent, aspect=panel_aspect, interpolation=interp, norm=norm)
        ax.set_title(paper_method_label(name), fontsize=12.5, pad=4)
        ax.set_xlabel(axis_labels[0])
        if ci == 0:
            ax.set_ylabel(axis_labels[1])
        else:
            ax.set_yticklabels([])
        ax.tick_params(axis="both", labelsize=9.5, length=2.5, width=0.7)
        for spine in ax.spines.values():
            spine.set_linewidth(0.8)
    clip_label = "raw" if clip_q >= 100.0 else f"logq clipped at visible p{clip_q:g}"
    if bright_p < 0.999999:
        clip_label = f"{clip_label}, brightness^{{{bright_p:g}}}"
    fig.suptitle(f"Implicit density heatmap on GT samples ({clip_label}) — {pretty_target_title(target)}", fontsize=14.2, y=1.02)
    fig.tight_layout(pad=0.25, w_pad=0.35)
    path = os.path.join(outdir, f"implicit_histogram_array_{target_name(target)}.png")
    fig.savefig(path, dpi=220, bbox_inches="tight")
    plt.close(fig)

    np.savez(
        os.path.join(outdir, f"implicit_histogram_array_{target_name(target)}.npz"),
        xedges=xedges,
        yedges=yedges,
        extent=np.asarray(extent),
        methods=np.asarray([name for name, _ in heatmap_entries], dtype=object),
        histograms=np.stack([H for _, H in heatmap_entries], axis=0),
        raw_histograms=np.stack([raw_hist_arrays[name] for name, _ in heatmap_entries], axis=0),
        clip_quantile=np.asarray([clip_q]),
        implicit_logq_temperature=np.asarray([temp]),
        implicit_brightness_power=np.asarray([bright_p]),
        pca_mean=np.asarray([]) if pca_mean is None else pca_mean,
        pca_basis=np.asarray([]) if pca_basis is None else pca_basis,
    )
    write_csv(os.path.join(outdir, f"implicit_histogram_clip_stats_{target_name(target)}.csv"), clip_rows)
    return path

def write_csv(path: str, rows: List[Dict[str, object]]) -> None:
    ensure_dir(os.path.dirname(path))
    if not rows:
        return
    keys = sorted({k for r in rows for k in r.keys()})
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in keys})


# -----------------------------------------------------------------------------
# Main sweep
# -----------------------------------------------------------------------------


def run_one_target(tkey: str, args: Args, device: torch.device, dtype: torch.dtype) -> Tuple[List[Dict[str, object]], List[Dict[str, object]], List[Dict[str, object]]]:
    print(f"\n================================================================================")
    print(f"Density benchmark target={tkey}  n_ref={args.n_ref} n_gate={effective_gate_n(args)} bank={canonical_bank_coupling(args.bank_coupling)} n_eval={args.n_eval} n_q={args.n_q_samples}")
    print(f"PF: steps={args.pf_steps}, sample_steps={args.sample_steps}, t=[{args.t_min},{args.t_max}], schedule={args.time_schedule}, final_denoise={args.final_denoise}, score_clip={args.score_clip}, sample_clip={args.sample_clip}")
    print(f"Base iterative_lfgi module: {ITERATIVE_PATH}")
    print(f"Benchmark-sweep exact module: {BENCHMARK_PATH or 'not found'}")
    print(f"================================================================================", flush=True)

    gen = make_generator(args.seed + 101, device)
    target = make_target(tkey, args, device, dtype)
    print(f"[target] {target_name(target)} d={target.d} logZ_oracle={getattr(target, 'logZ_oracle', None)}", flush=True)
    if str(tkey).lower().replace('-', '_') in {"nonlinear_inverse", "nonlinear_inverse_d8", "nonlinear_sine_inverse_d8"} and not isinstance(target, BenchmarkTargetAdapter):
        print("[warning] nonlinear inverse is using the density-script fallback target/sampler, not benchmark_sweep.NonLinearSineInverseD8Target. Metrics/plots will not match benchmark_sweep.", flush=True)

    t0 = time.time()
    score_slice, gate_slice, eval_slice, sample_offset, bank_mode, ng_eff = target_pool_slices(args)
    n_total = int(sample_offset) + int(args.n_eval)
    all_target = sample_target(target, n_total, args, gen)
    fit_x = all_target[score_slice].contiguous()
    gate_x = all_target[gate_slice].contiguous()
    eval_x = all_target[eval_slice].contiguous()
    print(
        f"[data] sampled target pool in {time.time() - t0:.2f}s | "
        f"bank_coupling={bank_mode} xr={tuple(fit_x.shape)} xg={tuple(gate_x.shape)} "
        f"sample_offset={sample_offset} eval={tuple(eval_x.shape)}",
        flush=True,
    )
    if bank_mode == "prefix":
        prefix_err = safe_float((gate_x[: int(args.n_ref)] - fit_x).abs().max()) if int(args.n_ref) > 0 else 0.0
        print(f"[data] prefix max|xg[:NR]-xr|={prefix_err:.3e}", flush=True)

    density_rows: List[Dict[str, object]] = []
    evidence_rows: List[Dict[str, object]] = []
    sampling_rows: List[Dict[str, object]] = []
    samples_by_method: Dict[str, torch.Tensor] = {}
    eval_logq_by_method: Dict[str, torch.Tensor] = {}

    for raw_m in method_names(args):
        try:
            q = build_density(raw_m, target, fit_x, args, gate_x=gate_x)
        except Exception as e:
            print(f"[skip] method={raw_m}: build failed: {e}", flush=True)
            continue
        if q is None:
            print(f"[skip] method={raw_m}: unavailable for target", flush=True)
            continue
        m = q.name
        print(f"\n[method] {m}", flush=True)
        t_build = float(getattr(q, "fit_seconds", 0.0))
        print(f"  built in {t_build:.2f}s", flush=True)
        qgen = make_generator(args.seed + 10_000 + len(samples_by_method), device)
        t1 = time.time()
        try:
            q_x = q.sample(int(args.n_q_samples), qgen).detach()
        except Exception as e:
            print(f"  sample failed: {e}", flush=True)
            continue
        sample_sec = time.time() - t1
        samples_by_method[m] = q_x
        print(f"  sampled q in {sample_sec:.2f}s", flush=True)

        # PF log_prob is the expensive step. Compute it once on target eval
        # samples and once on q samples, then reuse through a cached wrapper for
        # density metrics, IS, reciprocal IS, and bridge sampling.
        try:
            t_logq = time.time()
            eval_logq = q.log_prob(eval_x).detach()
            q_logq = q.log_prob(q_x).detach()
            q_metric = CachedDensity(q, eval_x, eval_logq, q_x, q_logq)
            eval_logq_by_method[m] = eval_logq.detach()
            print(f"  evaluated logq on eval/q banks in {time.time() - t_logq:.2f}s", flush=True)
        except Exception as e:
            print(f"  log_prob precompute failed: {e}", flush=True)
            q_metric = q

        try:
            drow = density_metrics(target, q_metric, eval_x, q_x, args)
        except Exception as e:
            print(f"  density metrics failed: {e}", flush=True)
            drow = {"metric_failed": str(e)}

        try:
            srow = sampling_metrics(target, eval_x, q_x, args, seed=int(args.seed + len(samples_by_method)))
        except Exception as e:
            print(f"  sampling metrics failed: {e}", flush=True)
            srow = {"sampling_metric_failed": str(e), "sw2": float("nan"), "mmd": float("nan"), "ksd": float("nan")}
        drow.update({f"sampling_{k}": v for k, v in srow.items()})
        drow.update({
            "target": target_name(target),
            "method": m,
            "n_ref": int(args.n_ref),
            "n_gate": int(effective_gate_n(args)),
            "bank_coupling": canonical_bank_coupling(args.bank_coupling),
            "n_eval": int(args.n_eval),
            "n_q_samples": int(args.n_q_samples),
            "pf_steps": int(args.pf_steps) if m.endswith("_pf") else 0,
            "sample_steps": int(args.sample_steps) if m.endswith("_pf") else 0,
            "t_min": float(args.t_min),
            "t_max": float(args.t_max),
            "time_schedule": args.time_schedule,
            "fit_seconds": t_build,
            "sample_seconds": sample_sec,
            "hessian_evals": int(args.n_ref) if m in {"lfgi_pf", "gn_lfgi_pf", "laplace_mixture", "local_linear_langevin_mixture"} else 0,
            "score_evals_fit": int(args.n_ref),
        })
        if hasattr(q, "last_pf_info"):
            drow.update({f"last_{k}": v for k, v in getattr(q, "last_pf_info", {}).items()})
        density_rows.append(drow)
        srow.update({
            "target": target_name(target),
            "method": m,
            "n_ref": int(args.n_ref),
            "n_gate": int(effective_gate_n(args)),
            "bank_coupling": canonical_bank_coupling(args.bank_coupling),
            "n_eval": int(args.n_eval),
            "n_q_samples": int(args.n_q_samples),
            "metric_max": int(args.metric_max),
        })
        sampling_rows.append(srow)
        print(
            f"  NLL={safe_float(drow.get('heldout_nll')):.4g} "
            f"cRMSE={safe_float(drow.get('centered_log_density_rmse')):.4g} "
            f"energyCorr={safe_float(drow.get('energy_corr_neglogq')):.3f}",
            flush=True,
        )
        print(
            f"  sampling: SW2={safe_float(srow.get('sw2')):.4g} "
            f"MMD={safe_float(srow.get('mmd')):.4g} "
            f"KSD={safe_float(srow.get('ksd')):.4g} "
            f"n={int(srow.get('sampling_metric_n', 0) or 0)}",
            flush=True,
        )

        # Evidence estimators. Reuse q_x for forward/bridge sample side.
        ests = []
        try:
            fwd = estimate_logZ_forward(target, q_metric, q_x)
            ests.append(fwd)
        except Exception as e:
            ests.append({"estimator": "forward_is", "error": str(e), "logZ_hat": float("nan")})
            fwd = {"logZ_hat": float("nan")}
        try:
            ests.append(estimate_logZ_reverse(target, q_metric, eval_x))
        except Exception as e:
            ests.append({"estimator": "reverse_reciprocal_is", "error": str(e), "logZ_hat": float("nan")})
        try:
            ests.append(estimate_logZ_bridge(target, q_metric, eval_x, q_x, init_logZ=safe_float(fwd.get("logZ_hat", float("nan")))))
        except Exception as e:
            ests.append({"estimator": "bridge_fixed_point", "error": str(e), "logZ_hat": float("nan")})
        for erow in ests:
            erow.update({
                "target": target_name(target),
                "method": m,
                "n_ref": int(args.n_ref),
                "n_gate": int(effective_gate_n(args)),
                "bank_coupling": canonical_bank_coupling(args.bank_coupling),
                "n_eval": int(args.n_eval),
                "n_q_samples": int(args.n_q_samples),
                "pf_steps": int(args.pf_steps) if m.endswith("_pf") else 0,
            })
            add_logZ_error(erow, target)
            evidence_rows.append(erow)
        bridge = [e for e in ests if e.get("estimator") == "bridge_fixed_point"]
        if bridge:
            print(f"  bridge_logZ={safe_float(bridge[0].get('logZ_hat')):.5g} err={safe_float(bridge[0].get('abs_logZ_err')):.3g}", flush=True)

    path = save_histogram_array(args.outdir, target, eval_x, samples_by_method, args)
    if path:
        print(f"[plot] {path}", flush=True)
    implicit_path = save_density_pseudohist_array(args.outdir, target, eval_x, eval_logq_by_method, args)
    if implicit_path:
        print(f"[plot] {implicit_path}", flush=True)
    return density_rows, evidence_rows, sampling_rows


def run(args: Args) -> None:
    ensure_dir(args.outdir)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        print("CUDA requested but unavailable; falling back to CPU.")
        device = torch.device("cpu")
    dtype = get_dtype(args.dtype)
    torch.set_default_dtype(dtype)
    if bs is not None:
        bs.DEVICE = device
        if hasattr(bs, "DTYPE"):
            bs.DTYPE = dtype
    torch.manual_seed(int(args.seed))
    if device.type == "cuda":
        torch.cuda.manual_seed_all(int(args.seed))

    with open(os.path.join(args.outdir, "config.json"), "w") as f:
        payload = asdict(args)
        payload["iterative_lfgi_path"] = ITERATIVE_PATH
        payload["benchmark_sweep_path"] = BENCHMARK_PATH
        json.dump(payload, f, indent=2)

    all_density: List[Dict[str, object]] = []
    all_evidence: List[Dict[str, object]] = []
    all_sampling: List[Dict[str, object]] = []
    for tk in target_keys(args):
        drows, erows, srows = run_one_target(tk, args, device, dtype)
        all_density.extend(drows)
        all_evidence.extend(erows)
        all_sampling.extend(srows)
        write_csv(os.path.join(args.outdir, "density_metrics.csv"), all_density)
        write_csv(os.path.join(args.outdir, "evidence_metrics.csv"), all_evidence)
        write_csv(os.path.join(args.outdir, "sampling_metrics.csv"), all_sampling)

    print("\nDone. Wrote:")
    for name in ["config.json", "density_metrics.csv", "evidence_metrics.csv", "sampling_metrics.csv"]:
        print("  " + os.path.join(args.outdir, name))


if __name__ == "__main__":
    run(parse_args())
