# Factorized conditional LFGI: quake density experiment

The known event/velocity structure substantially improves the LFGI density surrogate in this single-bank pilot. The posterior log-density-ratio SD falls from **51.07 to 1.89** with the same 1024 cached particles, scores, and GN matrices and the corrected endpoint **t_min=1e-6**. The sparse-event origin-time bias largely disappears. Strong conditional GMM baselines also benefit from the structure, but conditional LFGI has better held-out log density and a smaller estimated reverse KL in this run.

This is an exploratory implementation and evaluation on one existing bank, not a multi-seed result or a pure one-line weight ablation. The new normalized surrogate uses a fitted shared-velocity marginal, separate conditional flows, and a cached GN approximation for changes in the conditioning velocities. No manuscript was edited.

![Comparison](Quake_Factorized_Density_Comparison.png)

## Construction and available information

The forward model identifies five four-dimensional event blocks (location and origin time) and one shared three-dimensional velocity block. Its prior/likelihood factorization establishes conditional independence of events given clean velocities before posterior sampling. All new alternatives receive this same partition, the same N=1024 bank, and the same cached scores and positive GN matrices. No new target evaluations or derivative evaluations enter fitting or flow fields. Target energy evaluations on held-out states and generated proposals are used only for assessment.

A Gaussian velocity marginal is selected by training-bank BIC from K=1 or K=2; it is shared by every conditional model. Each event is represented by a normalized conditional model. Thus the joint density is

    q(v,e_1,...,e_5) = q_v(v) product_j q_j(e_j | v).

For conditional LFGI, at each fixed clean v, define velocity-kernel weights a_i(v) using Gaussian kernels centred at the bank velocities with covariance h² C_v, where C_v is their empirical covariance and h=N^(-1/7)=0.37150. This Scott-rule bandwidth was fixed before inspecting evaluation results. At event diffusion state y_j and time t, the bank weights are

    w_ij(y_j,t;v) proportional to a_i(v)
                   exp[-||y_j-alpha_t e_ij||²/(2 gamma_t)].

There is no distance to another event in these weights. The clean event score at each anchor is adjusted using the cached cross block:

    s_ij(v) = s_event,j(b_i) - P_event,j;v(b_i) (v-v_i).

This is a local GN/Taylor approximation, not an exact fresh evaluation of the conditional target score. The event GN block P_jj is retained. With Hbar, sbar, and ebar denoting the corresponding weighted means, the conditional field is

    s_hat_j = (alpha_t² I + gamma_t Hbar)^(-1)
              [alpha_t sbar + Hbar(alpha_t ebar-y_j)].

Each four-dimensional probability flow is integrated between T=8 and t_min=1e-6 with DOP853 in log time, rtol=1e-8, atol=1e-10. Sampling draws v from q_v, draws independent standard-normal terminal states for the events, and reverses these flows. Density evaluation uses the same fields and endpoints and integrates their analytic divergence. The triangular construction makes the full Jacobian determinant the product of conditional event determinants and the velocity-marginal contribution; off-diagonal velocity derivatives do not add determinant terms.

This explicitly defines a normalized conditional density model. It does **not** assert that the full 23D OU-diffused target factorizes in this way at every noisy time. Conditioning on clean velocities avoids needing an exact factorization of that noisy law.

## Fair alternatives

- Conditional Gaussian and conditional two-component GMM: fit each joint seven-dimensional (event,velocity) marginal and analytically condition on v. They use the same fitted q_v as LFGI.
- Stronger conditional GMM: choose K in {1,2,4} separately for each seven-dimensional fit using training-bank BIC. It selects [1,4,4,4,4]. This stronger comparator was added after the initial pilot; no held-out density metric was used to select its components. The fitted joint blocks plus velocity model have about 616 parameters, comparable in order to the original global two-component GMM's 599.
- Conditional local GN mixture: use the same velocity-kernel weights and cached cross-block adjustment. Each local event Gaussian has covariance P_jj^-1 and mean e_ij + P_jj^-1 s_ij(v). This provides an explicit normalized alternative with access to the same derivative cache, without the flow construction.
- Original joint Gaussian, joint two-component GMM, and small-endpoint joint GN-LFGI are retained as context. MAP–Laplace is also reported, but it used additional MAP-search target queries and is not an equal-cache comparator.

## Primary density metrics: identical 128 held-out posterior states

The primary proposal evaluations also use 128 samples per model. Fitting is confined to the original bank drawn from the first two reference chains; evaluation states come from the held-out chains. No new posterior samples were generated. A lower log-ratio SD is useful but does not itself identify forward KL or sample quality, so both directions of KL are assessed separately below.

| Model | Posterior log-ratio SD ↓ | Mean held-out log q ↑ | ELBO, 128 proposals ↑ | Bridge overlap ↑ |
|---|---:|---:|---:|---:|
| Joint Gaussian | 2.587 | 2.552 | -155.205 | 0.011 |
| Joint GMM, 2 components | 3.476 | 2.921 | -122.090 | 0.037 |
| MAP–Laplace (context only) | 370.159 | -338.572 | -225.460 | 0.043 |
| Joint-bank GN-LFGI, small endpoint | 51.066 | -13.906 | -32.937 | 0.207 |
| Conditional Gaussian | 2.575 | 2.659 | -146.081 | 0.003 |
| Conditional GMM, 2 components/event | 3.294 | 5.816 | -34.128 | 0.281 |
| Conditional GMM, training BIC | 4.913 | 7.288 | -27.196 | 0.482 |
| Conditional local GN mixture | 3.777 | 2.617 | -373.945 | 0.027 |
| Conditional GN-LFGI | 1.893 | 8.352 | -24.479 | 0.787 |

The unknown log evidence cancels from comparisons of forward KL: the new model's increase in mean held-out log q is its estimated reduction in KL(target || model). Paired Monte Carlo standard errors below describe these 128 states for this fixed bank; they are not across-bank uncertainty.

| Comparator | Estimated reduction in forward KL from conditional LFGI (nats) | Paired MCSE |
|---|---:|---:|
| Joint-bank GN-LFGI, small endpoint | 22.259 | 4.484 |
| Joint Gaussian | 5.800 | 0.274 |
| Joint GMM, 2 components | 5.431 | 0.272 |
| Conditional GMM, 2 components/event | 2.536 | 0.244 |
| Conditional GMM, training BIC | 1.064 | 0.330 |
| Conditional local GN mixture | 5.736 | 0.228 |

## Reverse KL and larger proposal checks

For normalized q, ELBO(q)=E_q[log unnormalized_target-log q]=log Z-KL(q || target). Therefore differences in ELBO are actual reverse-KL differences, without knowing Z. Fresh independent proposal draws reduce the noise of this comparison:

| Model | Fresh proposal count | ELBO | MCSE |
|---|---:|---:|---:|
| Conditional Gaussian | 4096 | -146.852 | 2.133 |
| Conditional GMM, 2 components/event | 4096 | -38.214 | 0.312 |
| Conditional GMM, training BIC | 4096 | -26.953 | 0.101 |
| Conditional GN-LFGI | 512 | -24.612 | 0.051 |

Conditional LFGI reduces estimated reverse KL by **2.340 nats (MCSE 0.113)** relative to the strongest training-BIC GMM. The evaluation counts differ here; the original 128-per-model comparison is retained above. All methods have the same fitting information. The larger GMM samples also show why the small pilot ELBO should not be treated as precise: the conditional K=2 mean shifts from -34.13 at 128 draws to -38.21 at 4096.

## Evidence estimation

| Model | Primary bridge log Z | Descriptive bootstrap SD |
|---|---:|---:|
| Joint Gaussian | -26.1783 | 2.7696 |
| Joint GMM, 2 components | -24.8514 | 0.8900 |
| Joint-bank GN-LFGI, small endpoint | -24.0371 | 0.2975 |
| Conditional GMM, 2 components/event | -23.8159 | 0.2884 |
| Conditional GMM, training BIC | -24.2858 | 0.1103 |
| Conditional GN-LFGI | -23.8948 | 0.0576 |

These use 128 posterior states and 128 actual model proposals. The bootstrap resamples the available p and q arrays 250 times, refitting neither model; it measures descriptive Monte Carlo sensitivity, not finite-bank/model uncertainty or independently verified evidence error.

Using the 512 fresh conditional-LFGI proposals with the original 128 posterior states gives bridge log Z=-24.0062. As a separate consistency check, two cheap structured models use 3872 extra held-out posterior states (excluding the primary 128) and 4096 model draws: conditional K=2 GMM gives -24.0131 with approximate chain-block bootstrap SD 0.0460; conditional training-BIC GMM gives -24.0564 with SD 0.0216. Their agreement supports the scale of the evidence estimate. **There is no independently known exact log Z, so no evidence-accuracy dominance is claimed.** In particular, the new model's primary 128-draw estimate -23.8948 is visibly different from these larger checks.

Raw importance ESS does not uniformly improve. At 128 proposals it is 17.7% for conditional LFGI versus 20.2% for joint LFGI; on the 512 fresh conditional draws it is 6.1%. This is consistent with a remaining heavy-weight tail and makes small-sample ESS an unstable ranking. The density, KL, bridge-overlap and geometric diagnostics provide the stronger evidence here.

## Geometry and actual particles

The previously problematic held-out state #124 changes from log q=-504.30 under joint-bank LFGI to log q=+9.124 under conditional LFGI. Its log(unnormalized_target/q) becomes -24.005, consistent with the large-sample evidence checks. This is the same state diagnosed before the new model was fitted; it was not removed or used for tuning.

The following diagnostics use 4000 held-out NUTS states, 4096 old joint-LFGI particles, and 512 fresh conditional-LFGI particles. The standardized origin residual is computed from the exact known Gaussian conditional of origin time given location and velocities. It is a diagnostic only; the new sampler does not perform an exact origin refresh.

| Particle law | Mean squared noise-normalized data residual | P(all four sparse origins earlier than their conditional means) |
|---|---:|---:|
| reference | 19.126 | 6.350% |
| joint_lfgi | 36.552 | 0.635% |
| conditional_lfgi | 19.323 | 5.859% |

The exact latter probability is 6.25%. Conditional LFGI's five origin-residual means range from -0.082 to +0.065 SD, and their SDs range from 0.977 to 1.041. Thus the principal late-origin displacement is largely removed without additional target derivative information.

## Validation and limits

- Conditional score-divergence formulas were checked against finite differences and independent complex-step differentiation. The maximum tested relative complex-step error was below 8e-13, including t=1e-6.
- An arbitrary correlated Gaussian control verifies exact conditional Gaussian score cancellation to 7.2e-15 for any bank weights.
- Tolerance refinement on selected posterior states, including #124, changes log density by at most 3.13e-07; generation/evaluation round trips differ by at most 7.13e-07.
- A finite-difference Jacobian of the independently integrated E3 conditional map agrees with its divergence log determinant to 2.86e-08.
- Conditional-LFGI primary generation plus density evaluation took about 71 seconds; 512 fresh proposal draws took about 124 seconds, with one BLAS thread. These are local timings, not a controlled runtime comparison with archived implementations. Conditional parametric models are much cheaper to evaluate.
- Factorization, a fitted velocity marginal, and cross-block GN score adjustment change together. This establishes that a computable structural reconstruction can resolve the diagnosed failure; it does not isolate every contribution or establish an exact-Hessian comparison.
- The conditional score adjustment remains approximate off the bank. One seed/bank and 128 primary posterior queries support a pilot conclusion, not a broad high-dimensional guarantee.

## Reproduction

The accompanying ZIP is self-contained. Install requirements.txt, ensure a C++ compiler is available, and run `python run_all.py`. It compiles the conditional divergence routine, runs the analytic/numerical checks, fits the alternatives, generates and evaluates the new flow model, and reconstructs the tables and figure. Chunk-level checkpoints are generated automatically; primary files already included in the archive allow completed results to be reviewed without rerunning flows. Archived original-model evaluation arrays are included as context; the new experiment does not recompute those original models. No cluster or external target source is required.
