# Paper integration plan: quake as the second density application

## Source and scope

`source_snapshot_v3` is the current retrieved `LFGI_Preliminary_Source_20261115.zip`, Library version 3 (updated 2026-11-16T03:14:06Z). The full archive's SHA256 and identity are in provenance. TeX, bibliography, figures and editorial/code notes are preserved; bulky Data/Sampling arrays are omitted here and remain in the full source archive. No source was edited for this handoff.

The snapshot's `Sections/05_experiments.tex` has S1 controlled score reconstruction and sampling, then S2 Tanh normalized density/actual bridge accuracy. Acoustic is an appendix study. Add quake after S2 as **the second inverse/density application**; keep existing S1/S2 identifiers stable where possible, and use a fresh quake label such as `sec:quake_density`. Acoustic's historical S3 naming in editorial files must not accidentally become a duplicate body identifier.

## Scientific narrative

1. Start from the original contribution: a conditional Fisher/Hessian matrix gate reduces score-estimator variance and has affine/Gaussian cancellation. Do not turn the paper into a task-specific earthquake-density paper. Density/evidence post-processing is a concrete application requiring posterior samples plus cached target derivatives.
2. Tanh provides a fully calibrated low-dimensional density/evidence example with known quadrature normalizer. Quake tests a larger structured inverse posterior with meaningful geometry and posterior post-processing.
3. Quake reveals two distinct failure mechanisms: a too-large endpoint smears narrow directions, and empirical full-state weights can suppress locally relevant event anchors. Low ESS alone is insufficient to diagnose either; arbitrary-Gaussian exactness is the counterexample.
4. Model-specified conditional structure provides a computable remedy. Define the normalized conditional construction and disclose cached GN velocity rebasing. Distinguish a new practical reconstruction from an exact factorization of the original noisy joint law and from a theorem for arbitrary high-dimensional targets.
5. Evaluate strong proposals with the same structure/information and actual bridge estimators. Show useful density/KL/posterior-probability outcomes alongside evidence estimates; only claim absolute evidence accuracy when a trustworthy reference is available.

## Concrete insertion map

| File | Proposed edit after production |
|---|---|
| Sections/01_introduction.tex | Briefly add structured inverse-posterior application after the gate motivation; preserve original score-estimation emphasis |
| Sections/03_frozen_density.tex | Add a compact paragraph defining conditional product flows and triangular density evaluation, pointing to appendix algorithm; no unsupported extension of global noisy-law results |
| Sections/05_experiments.tex | New quake subsection after S2: model/partition, cache and data split, small endpoint, same-info comparators, replicated results and qualified evidence reference |
| Sections/06_discussion.tex | State locality relative to block geometry, endpoint control, and the distinction between generic dense banks and known conditional structure |
| Appendices/D_experimental_details.tex | Include quake target convention, conditional weights, GN cross rebasing, KDE bandwidth, baseline recipes, split/seed hierarchy, numerical audit and all unfavorable results |
| New appendix fragment D_quake_details.tex | Optional isolated fragment input by the existing experimental appendix; keep labels unique |
| main.tex abstract | Only after results stabilize, one restrained application sentence; do not rewrite the abstract around quake or let the density application displace the score/gate contribution |
| refs.bib | Add primary bridge/Warp references actually used, and precise conditional-flow baseline citations once the implementation is chosen |
| Editorial/OPEN_ITEMS.md and DATA_PROVENANCE.md | Append quake readiness, reference-Z status, conditional construction, code hashes, endpoint choice and completed/planned counts |

## Body assets and table

Use at most two new quake body figures: (1) compact geometry plus exact-origin residual comparison demonstrating why the joint weights fail and conditional weights recover local information; (2) replicated density/evidence/KL quality versus N with whole-bank uncertainty. Put endpoint ablations, full 2D particle and integrated-density marginals, all conditionals, numerical checks, and timing in the appendix. Existing pilot plots are development illustrations and must not be relabeled multi-seed production figures.

One concise table can report the largest common bank size with held-out mean log q/forward-KL difference, reverse-KL difference or ELBO, actual bridge stability/error as justified by the reference, and information/resources. Separate transformed-target Warp evidence rows from original-coordinate density metrics (unavailable entries should stay unavailable). Do not compare centered log-ratio SD with Tanh's uncalibrated density RMSE as if they were the same statistic.

Particle histograms must be labeled actual samples. Implicit-density histograms must marginalize using a valid integration proposal with q/r weights, validated total mass, and uncertainty. Preserve single-seed display with no pooling. Prefer the hidden conditional-origin view over crowded overlapping location scatters when explaining the joint error.

## Safe claims now and publication gates

Supported now: in one fixed N=1024 bank, a known-structure normalized conditional construction using the same cached derivatives greatly reduces held-out density errors and the origin-time coupling bias relative to joint-bank GN-LFGI; it also improves estimated forward/reverse KL over the tested conditional GMMs. These are pilot estimates.

Before strong publication claims: finish new-source/cache identity, native numerical smoke and competitor checks; freeze training choices; obtain paired new bank groups; verify chain/reference qualifications and full accounting; check origin diagnostics and modes; validate reference evidence if claiming RMSE; build/render the edited paper and update captions/provenance. Five resampled banks from fixed chains are not five independent posterior samplers. No exact-Hessian or general dimension-scaling conclusion follows from the current composite change.

Retain the current S2 historical-source mismatch, acoustic missing scalar cells and independent-reference limitations as open items. Do not silently resolve those unrelated issues while adding quake. The new example is additive; it does not replace the current calibrated Tanh evidence benchmark.
