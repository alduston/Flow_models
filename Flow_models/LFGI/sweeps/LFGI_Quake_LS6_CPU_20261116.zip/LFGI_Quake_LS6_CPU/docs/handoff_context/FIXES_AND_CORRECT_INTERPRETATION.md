# Fixes and corrected interpretation

## 1. Endpoint smoothing: a distinct numerical/model issue

The original fixed t_min=.001 was too large for the quake target's stiff directions. OU smoothing contributes gamma_t times prior-scale covariance in physical coordinates. For E1 this predicted horizontal SD .48783 km, agreeing with generated .49076 km, versus clean reference .27622 km. Reducing the endpoint to 1e-6 gives .28341 km and removes about 97.6% of excess horizontal variance. This was not a rotated density-Jacobian bug.

The original GAD source uses a curvature-controlled endpoint. For maximum cached GN eigenvalue 2793.903, epsilon=.01 yields .5*log1p(epsilon/lambda_max)=1.7896e-6. The pilot's 1e-6 is conservative. Proposed larger-bank production rule: tau=min(1e-6, .5*log1p(.01/lambda_max)), selected from fitting information only and shared by matched flow arms. Validate halving tau on development cells; record terminal horizon/base and any endpoint denoising separately. The density evaluator and generator must implement the same endpoint law.

## 2. The bank has relevant tangents; global weights suppress them

At the problematic held-out state #124, the full-joint nearest anchor #163 is 11.77 km away in E3 location, on the other side of the displayed arc. Its full prior-whitened 23D distance is 1.71854. Anchor #1009 is only 1.45 km away in E3 and predicts the required E3 origin mean within .10 conditional SD, but its full distance is 1.71988 because another event differs. At tau=1e-6 its relative kernel weight is exp(-1153). The marginally closer E3 anchor #878 is also present.

The selected anchor's E3 conditional-origin prediction errs by 28.44 conditional SD. This is not an indictment of tangent stitching: using local scores and Hessians is the intended mechanism. It shows that ambient joint-neighbour selection need not provide a relevant local approximation for each conditionally independent event block. Earlier language that LFGI simply follows the wrong sheet or lacks all local information was too broad.

Low kernel ESS alone does not diagnose failure. For Gaussian scores, exact affine cancellation works with any nonempty bank. Here the meaningful object is the unresolved score/Hessian residual over the selected bank-to-query displacement, and whether relevant local blocks are discarded. Dimension enters through the joint combinatorial matching requirement, not as a standalone cause established by this experiment.

## 3. Computable conditional construction

The likelihood specifies five independent event data blocks given three shared velocities. This partition is known before posterior sampling. Fit q_v(v) and represent q(v,e)=q_v(v) product_j q_j(e_j|v). Each q_j is a normalized four-dimensional probability-flow density. Its weights are proportional to a_i(v) exp(-||y_j-alpha e_ij||²/(2 gamma)); a_i is a Gaussian velocity KDE with covariance h² C_v and fixed Scott h=N^(-1/7). Other event coordinates never enter that event's kernel distance.

Target conditional anchor scores at a new velocity are approximated from the existing cache: s_ij(v)=s_ij-P_jv,i (v-v_i); GN event blocks P_jj,i are retained. The same local resolvent formula is applied conditionally. No new physics query is used in fitting or field evaluation. Drawing one shared v and independently running the five conditional flows yields a normalized joint law with a triangular Jacobian. All new conditional competitors receive the same partition and q_v.

This avoids inventing independence of the full noisy 23D law: it defines a clean-velocity conditional surrogate instead. Exact marginal q_v and exact conditional scores are not known; both remain approximated. The experiment combines conditioning, marginal fitting and GN velocity rebasing. It does not isolate these modifications or compare exact Hessians.

## 4. Why the diagnostic supports this explanation

The catastrophic state changes from log q=-504.30 to +9.124; its new log(unnormalized target/q)=-24.005 is on the scale of large-sample bridge checks. Across generated particles, sparse-event origin residual bias and excess spread largely disappear. These are actual particles from the evaluated normalized conditional flow, not an exact-origin Gibbs refresh. The archived GAD particles also showed hidden origin-time bias; their location-depth fidelity alone did not establish joint correctness.

The supplied older geometry and audit reports remain historical records. This file supersedes overly categorical causal wording in them. The independent endpoint smoothing explanation remains valid.
