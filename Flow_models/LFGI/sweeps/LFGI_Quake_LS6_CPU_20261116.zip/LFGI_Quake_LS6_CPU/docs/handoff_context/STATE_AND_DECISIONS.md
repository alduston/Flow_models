# State and decisions

## Completed and reliable within the pilot

- Frozen quake forward map/whitening/observations match the archived GAD source at checked states; analytic derivatives and independent density-Jacobian checks pass.
- N=1024 cached fitting bank, 128 held-out posterior states, 128 initial actual proposal draws/model; fixed-bank comparisons are paired. Extra proposal checks use 512 new conditional-LFGI draws and 4096 conditional GMM draws.
- The endpoint was reduced from 1e-3 to 1e-6. The first cutoff visibly blurred the E1 narrow direction; lowering it removes that smoothing effect. It does not alone fix finite-bank locality.
- A normalized event/velocity conditional model fixes the main locality failure in this run. Full implementation, data and validation are included. Stronger conditional baselines are included, not just global Gaussian blobs.
- Relative to the training-BIC conditional GMM, conditional LFGI improves forward KL by 1.064 nats (paired MCSE .330) and reverse KL by 2.340 nats (proposal MCSE .113). One fixed bank; neither number is multi-seed uncertainty.
- Data misfit mean: NUTS 19.126, old LFGI 36.552, conditional LFGI 19.323. Exact all-four-sparse-origin-negative probability 6.25%; old LFGI .635%, new 5.859%, reference 6.350%.
- New primary bridge log Z=-23.8948; fresh-512-proposal bridge=-24.0062. Larger GMM checks are -24.0131 and -24.0564. These are convention-dependent estimates, not known truth.
- Importance ESS does not uniformly favor the new model; retain this fact.

## Not yet established

Multi-bank robustness; accurate independent quake Z; exact-Hessian versus GN causality; pure weight-only causal separation; equal-time advantage over fitted mixtures/flows; all fair competitive bridge methods; generic high-dimensional efficiency; full posterior correctness of archived GAD; or compatibility with a new LS6 production environment.

## Scope and author preferences

Use score/gate optimality as the scientific spine. Explain the density application through practical posterior post-processing and actual evidence experiments. A bound by itself is not the application. ESS is diagnostic and must be interpreted relative to residual/Hessian variation and available local information. Gaussian cancellation can make ESS=1 harmless. No new theory campaign. No pooling seeds for publication histograms. Reference-sample N is the principal empirical axis; E+G+H and time remain visible secondary resources. Preserve old unfavorable results with clear scope. The user's request now is an organized handoff and plans, not immediate cluster submission or paper editing.
