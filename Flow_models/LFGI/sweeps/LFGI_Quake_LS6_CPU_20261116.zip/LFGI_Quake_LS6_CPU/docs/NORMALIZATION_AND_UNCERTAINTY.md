# Density, evidence and entropy conventions

## Pilot target and conversion

The NumPy quake target uses 23 prior-whitened variables u and 24 observations. Its reported unnormalized log density is

    log tilde_pi_pilot(u) = -.5 ||u||² -.5 sum_j ((F_j(u)-y_j)/sigma_j)².

It omits both the standard-normal prior constant and Gaussian observation constants. Thus the pilot's log Z near -24 is an integral in **this** convention, not automatically the fully normalized data marginal likelihood. All current proposal comparisons use the same convention, so log-ratio SD, relative KL and bridge comparisons are internally meaningful.

To use the existing Tanh paper convention (normalized prior, observation normalization omitted):

    log Z_paper = log Z_pilot -21.135586263707.

To report the fully normalized Gaussian-observation model evidence:

    log Z_full = log Z_pilot +11.141289808555.

The latter equals -(23+24)/2 log(2 pi)-sum log(sigma_j) added to pilot log Z. This assumes the archived standard-normal whitened prior and observation model, with no additional prior truncation constants. Audit any support/domain changes before applying it. If integrating in physical coordinates instead, transform the density and Jacobian consistently; do not add a physical-coordinate Jacobian twice to an already whitened-prior integral.

A common additive target constant shifts log Z, ELBO and mean log(target/q) equally. It leaves normalized posterior probabilities, bridge overlap, log-ratio SD, and forward/reverse-KL differences unchanged. For example the new primary ELBO -24.479 and large-sample ELBO -24.612 are in the pilot convention. Record a `normalization_id` in every future cell.

## Entropy

For a normalized q, -E_q log q is its own entropy, not automatically posterior entropy. -E_pi log q is target cross entropy, differing from H(pi) by KL(pi||q). If a trusted log Z is available, H(pi)=log Z-E_pi log tilde_pi under a consistent coordinate convention. Physical entropy also needs E log|Jacobian of physical map|; the velocity log transforms make that term state dependent. Keep paper values in clearly named prior-whitened units unless there is a substantive reason to convert.

## Uncertainty and evidence reference

The pilot comparisons condition on one bank. Paired MCSE uses 128 held-out posterior states. Proposal MCSE uses independently generated q draws from fixed fitted laws. Neither captures uncertainty from new banks or new posterior chains. Ordinary bridge bootstraps from fixed arrays are descriptive; the larger-check bootstrap approximates chain-block uncertainty but still does not create an exact reference.

The reference data split is archived four-chain NUTS output: first 4000 states for fitting/development and last 4000 held out in the pilot. New bank seeds drawn from the same pool are fitting-bank repeats conditional on these chains. Keep all sample-law labels explicit. Proposed production should reserve genuinely uninspected query states if feasible, and document any already-used data.

The new bridge checks are not ground truth: -24.0062 (128 p/512 q conditional LFGI), -24.0131 (3872 p/4096 q conditional GMM2), -24.0564 (3872 p/4096 q BIC conditional GMM), all in pilot units. Do not estimate absolute evidence RMSE by choosing one consensus value as exact. Independent reference validation or a visibly qualified numerical reference band is required.
