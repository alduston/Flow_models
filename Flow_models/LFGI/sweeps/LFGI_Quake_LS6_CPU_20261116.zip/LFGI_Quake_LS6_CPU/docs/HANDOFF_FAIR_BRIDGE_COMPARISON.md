# Planned LS6 comparison: competitive, law-aware bridge estimators

Status: protocol and proposed run matrix, not completed implementations or launched production. The local conditional pilot is runnable; production refactoring and new competitors are next-day work.

## Objective and estimands

Compare actual bridge estimates obtained from normalized posterior surrogates using the same available bank/structure. A good score or ELBO is useful evidence but not a substitute for the bridge experiment. Separate (a) conditional density quality, (b) actual evidence estimation, (c) entropy/cross-entropy post-processing, and (d) resources. Tanh retains its known-quadrature evidence benchmark; quake currently has no exact normalizer.

## Common information and two budget views

Every main arm gets the same fitting states, cached target scores and GN matrices, original coordinate map, and model-specified event/velocity partition. Methods may ignore some ingredients; the conditional local-GN mixture is an explicit derivative-cache comparator. Common posterior acquisition is a supplied-data cost; count it separately if reporting end-to-end inference. Fit model selection on training/development data only, never the final posterior density queries or a reference log Z.

Primary view: matched fitting-bank N, held-out posterior-query count, and actual proposal count, with the common bridge root solver wherever the same estimator applies. Secondary view: matched **new target-output allowance**, counting all E/G/H requests, plus common-host time. Warp transformations can require multiple target energies per transformed point; expose their cost rather than pretending equal draw counts mean equal work. Keep reference-generation work separate.

Use W=N_E+N_G+N_H in addition to the three individual counts. Account for shared cached acquisitions once and report incremental per-method requests. Record both total requested outputs and unique state/cache-hit counts. Do not silently price a returned GN matrix as one ordinary gradient or mix archived host timings into a speed ranking.

## Main methods to implement/port before full production

| ID | Method | How it uses the same information | Current readiness |
|---|---|---|---|
| joint_gaussian | Gaussian proposal + optimal bridge | bank mean/covariance; partition available | existing pilot |
| joint_gmm_bic | Full-covariance GMM + optimal bridge | training-selected components, adequate regularization | pilot K=2; expanded fitting pending |
| warp3 | Affine-whitened, symmetrized Warp-III bridge | fit mean/covariance on fit split; exact transformed target evaluations | new adapter pending |
| conditional_gaussian | q_v times five Gaussian conditionals + optimal bridge | known conditional structure, shared q_v | existing pilot |
| conditional_gmm_bic | q_v times five fitted GMM conditionals + optimal bridge | K selected independently by training criterion | existing K=1/2/4 pilot; production adapter pending |
| conditional_t_mixture | Conditional Student-t mixture + optimal bridge | same blocks; tails learned/selected using training only | new implementation pending |
| conditional_gn_mixture | Conditional local GN mixture + optimal bridge | same cached scores, GN blocks and velocity rebasing as LFGI | existing pilot |
| conditional_fitted_flow | Normalized fitted conditional flow + optimal bridge | same bank/partition; data-only MLE, derivative cache available | production-strength fit/development recipe pending |
| joint_lfgi | Existing joint-bank GN-LFGI + optimal bridge | original full-state weighting; corrected cutoff | contextual pilot; production adapter pending |
| conditional_lfgi | Shared q_v, five conditional GN-LFGI flows + optimal bridge | structural weighting and cached GN cross-block rebasing | validated local pilot; sweep adapter pending |

Warp-U is a priority extension if the core mixture/warp comparison leaves a multimodal-geometry concern. Implement from the original method with a fitted mixture and split-fitting correction, not merely label a GMM proposal as Warp-U. A scalar conditional flow and a spatially uniform curvature control are mechanism ablations rather than mandatory external bridge methods. Keep an original/global fitted-flow control if affordable and explicitly distinguish it from the stronger structural flow.

Competitive tuning proposal: GMM candidate K={1,2,4,8}, constrained by training size/occupancy and covariance floors, multiple fixed initializations; conditional t mixture df={4,8,16,infinity} with exact conditional densities; modest conditional spline/coupling-flow capacity grid using an internal validation split and fixed optimization caps. Freeze recipes after a separate development stage and before final bank groups. All tuning/failed fits count toward method resources. The already inspected pilot is development/exploratory, not a new untouched confirmatory group.

## Warp-III implementation contract

Using fitting-only mean mu and covariance LL^T, let rho(z)=|det L| tilde_pi(mu+Lz). Its symmetrization rho_s(z)=[rho(z)+rho(-z)]/2 has the same normalizer. Apply a random sign to whitened posterior states to obtain draws from rho_s/Z, and bridge against standard-normal draws using rho_s as the unnormalized target. Use log-sum-exp for the two target evaluations. This is an evidence-estimator arm with a transformed target; it is not automatically a normalized original-coordinate density surrogate and therefore has no generic original-coordinate held-out log-q score to report. Count both target evaluations and any reusable original evaluations. Check against the maintained bridgesampling implementation on normalized Gaussian/skewed controls before using the port.

The Warp-III arm also receives the known partition: offer the structured Gaussian whitener implied by the shared velocity marginal and Gaussian event conditionals, alongside dense empirical whitening, as predeclared development candidates. These are affine maps with known determinants. Freeze that choice on development data; do not handicap the warp arm by withholding conditional covariance information. Additional nonlinear/block stochastic warps need their own exact transformed-target derivation and target-call accounting.

## Student-t and fitted-flow contracts

For a joint t component in (e,v), condition analytically: event location shifts by the covariance regression; conditional degrees of freedom become nu+dim(v); the Schur scale receives the usual (nu+Mahalanobis_v)/(nu+dim(v)) factor. Update component weights with each component's velocity marginal. Verify normalization/sampling against numerical checks before use. All structural methods share q_v in the main ablation; an independently optimized velocity marginal is a secondary sensitivity check.

For the fitted conditional flow, require normalized log density, exact sampling/evaluation correspondence, train/validation isolation, several fixed initialization seeds, and a reasonable validation-selected capacity/early-stopping protocol. A poorly tuned tiny network is not a sufficient competitive control. Optional cached-score regularization is a separate information-matched arm; account for its optimization cost and avoid requiring fresh hidden target labels.

## Bridge and density metrics

1. Held-out mean log q and paired forward-KL differences; posterior log-ratio SD and tail quantiles. Absolute log-density RMSE requires an independently trustworthy Z or an explicit reference uncertainty band.
2. Actual bridge log Z, independent proposal-repeat variability, bridge overlap, failure counts and sensitivity to posterior chain/block sampling. Do not use the p/q ratio arrays from the wrong sample law or replace the bridge root with an energy-offset fit.
3. ELBO and model entropy from actual q draws, with Monte Carlo error; reverse-KL differences cancel log Z. Do not present entropy of q as automatically accurate posterior entropy.
4. Importance weights/ESS as diagnostics, not the primary ranking. Report catastrophic target-domain states and nonfinite evaluations rather than discarding them. Production bridge implementation must treat zero target density on q draws correctly in log space; the pilot's finite-only bridge guard is a known generalization task.
5. Exact conditional-origin residual diagnostics, event probabilities, and data fit. These remain interpretable even without reference Z.
6. Actual particle 2D histograms and integrated implicit-density marginals. The latter require importance/cubature weights q(x)/r(x), with quadrature uncertainty and mass/ESS checks; raw q(x) weights on posterior particles do not define a marginal.

## Independent quake evidence reference

The existing large bridge checks are agreement diagnostics only. Plan a separate high-budget validation using at least two independently seeded/reference strategies, such as tempered SMC/AIS and thermodynamic integration, with validated transitions, tempering refinement, repeated estimates and a normalization audit. Exploit the known Gaussian origin-time conditional to integrate out those variables analytically for reference computations if useful; track this as structural reference work, not free oracle information given only to one competitor. Its extra physics effort is outside the matched post-processing allowance.

If a trustworthy reference cannot be established within scope, do not delay all other results or invent truth from consensus. Retain Tanh absolute evidence RMSE as the calibrated application and report quake bridge stability/overlap, forward/reverse-KL differences and geometry with clearly qualified estimates. Evidence accuracy claims need a reference; normalized densities, likelihood reweighting and posterior probabilities remain concrete downstream tasks.

## Replication and resource allocation

Proposed main bank sizes 256,1024,2048 and five new bank-order seeds 101–105, nested within seed. Ten main methods imply 150 fit cells. These vary fitting banks conditional on the existing first-two-chain pool; they are not five independent posterior-inference runs. Final evaluation/posterior states must be disjoint from fitting and development; predeclare 512 states shared across methods and bank groups, acknowledging reuse. At each frozen fit, use repeated independent q draws to study bridge Monte Carlo error; repeats are nested within bank groups, not extra scientific bank replicates. Proposed R=5 repeats of 512 q draws; smoke uses 32/32 and first development stage 128/128. Reuse costly held-out log-q evaluations across proposal repeats. Reassess time/memory after a native smoke; matrix counts are not a runtime guarantee.

Main uncertainty resamples complete bank groups preserving paired methods/nested sizes; add chain/block reference sensitivity. Repeated proposal draws quantify within-fit error separately. Five groups give exploratory uncertainty; expanding to 10–20 groups is an explicit later decision if publication claims require it. Display histograms use one predeclared seed with no pooling.
