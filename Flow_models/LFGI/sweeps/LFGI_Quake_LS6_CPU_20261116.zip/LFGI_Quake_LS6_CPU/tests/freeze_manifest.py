from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1];paths=[]
for folder in ['code','ls6','configs','data','tests']:
 paths.extend(p for p in (R/folder).glob('*') if p.is_file() and p.suffix in ['.py','.cpp','.sh','.txt','.json','.npz'])
paths.extend([R/'submit.sh',R/'pack_results.py'])
# This generator is not part of scientific identity, but immutable source bytes are included.
(R/'provenance/IMMUTABLE_SHA256.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)},indent=2))
