import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import sys,numpy as np
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from models import GMM,ConditionalBank
from flows import PFModel
from common import write,source_sha
p=np.load(R/'data/inputs.npz');v=np.load(R/'tests/pilot_velocity.npz');vm=GMM(v['weights'],v['means'],v['covariances']);bank=ConditionalBank(p['x'],p['s'],p['P'],vm);config=dict(tau=1e-6,T=8.,rtol=1e-8,atol=1e-10,chunk=4);model=PFModel(bank,True,config,R/'test_runtime'/('pilot_regression_'+source_sha()[:12]),source_sha());f=np.load(R/'tests/pilot_fixture.npz');lq=model.logq(f['x']);err=float(np.max(abs(lq-f['logq'])));assert err<1e-3,err;write(R/'logs/pilot_regression.json',dict(passed=True,max_logq_error=err,states=[0,17,124]));print('Pilot regression max logq error',err)
