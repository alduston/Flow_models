import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import sys,json,copy,pickle,time
from pathlib import Path
import numpy as np
from scipy.stats import norm
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from common import write,bridge,rng
from fitted_flow import CouplingFlow
from mixtures import TMixture
from flows import Field
from reference_smc import smc
from target_numpy import Quake
r=rng(450);results={}
target=Quake(json.loads((ROOT/'data/model_spec.json').read_text()));raw=np.load(ROOT/'data/inputs.npz');assert np.array_equal(target.y,raw['y']);E,S,P=target.values(raw['x'][:4]);assert np.max(abs(S-raw['s'][:4]))<1e-9 and np.max(abs(P-raw['P'][:4]))<1e-9;results['frozen_observation_and_cache_check']=True
# Conditional and joint Gaussian cancellation and trace differentiation.
for d in [4,23]:
 M=r.normal(size=(d,d));P=M@M.T+np.eye(d);mu=r.normal(size=d);x=r.normal(size=(32,d));bank=SimpleNamespace(x=x,s=-(x-mu)@P,P=np.tile(P,(32,1,1)));y=r.normal(size=(3,d));f=Field(bank)
 errors=[]
 for t in [1e-6,.01,.2,2.]:
  a=np.exp(-t);g=-np.expm1(-2*t);V=a*a*np.linalg.inv(P)+g*np.eye(d);s,div=f.calc(y,t);expected=-(y-a*mu)@np.linalg.inv(V);errors.append(max(abs(s-expected).ravel()));assert max(abs(div+np.trace(np.linalg.inv(V))))<1e-7
 results['gaussian_d%d'%d]=max(errors);assert max(errors)<1e-8
# Complex-step divergence on real cached GN targets, joint and event field.
data=np.load(ROOT/'data/inputs.npz');from models import ConditionalBank,fit_gmm
bank=ConditionalBank(data['x'],data['s'],data['P'],fit_gmm(data['x'][:,20:],1));errors=[]
for j in [None,2]:
 y=data['posterior'][:2].copy() if j is None else data['posterior'][:2,8:12].copy();f=Field(bank,None if j is None else data['posterior'][:2,20:],j)
 for t in [1e-6,.01,.2]:
  score,div=f.calc(y,t);fd=np.zeros(len(y))
  for k in range(y.shape[1]):
   yy=y.astype(complex);yy[:,k]+=1e-20j;fd+=f.calc(yy,t,False)[:,k].imag/1e-20
  errors.append(float(np.max(abs(fd-div)/(1+abs(div)))))
assert max(errors)<1e-8;results['complex_step_divergence_relative']=max(errors)
# MLE coupling gradients and inverse/Jacobian.
f=CouplingFlow(2,8,5)
for layer in f.params:layer[-2]+=r.normal(scale=.03,size=layer[-2].shape);layer[-1]+=r.normal(scale=.02,size=4)
x=r.normal(size=(9,4));v=r.normal(size=(9,3));loss,gr=f.forward(x,v,True);errs=[]
for layer in range(2):
 for param in range(6):
  p=f.params[layer][param];idx=tuple(r.integers(s) for s in p.shape);old=p[idx];ep=1e-6;p[idx]=old+ep;plus=-f.forward(x,v).mean();p[idx]=old-ep;minus=-f.forward(x,v).mean();p[idx]=old;fd=(plus-minus)/(2*ep);errs.append(abs(fd-gr[layer][param][idx]))
assert max(errs)<1e-6;results['flow_gradient_max_error']=max(errs)
z=r.normal(size=(3,4));v=r.normal(size=(3,3));e=f.inverse(z,v);assert max(abs(f.forward(e,v)-(-.5*(z*z).sum(1)-2*np.log(2*np.pi))))<2 # nonzero Jacobian
# Verify the full normalized density via finite-difference forward map.
y=f.inverse(z,v);eps=1e-5
# Build transformed z by inverting sampling backwards using stored coupling calculations.
def transform(e,v):
 zz=e.copy()
 for k in range(f.layers):
  a,b,net,h1,h2,o=f.network(zz,v,k);zz[:,b]=(zz[:,b]-o[:,:2])*np.exp(-1.5*np.tanh(o[:,2:]))
 return zz
assert np.max(abs(transform(y,v)-z))<1e-12
J=np.stack([(transform(y+eps*np.eye(4)[k],v)-transform(y-eps*np.eye(4)[k],v))/(2*eps) for k in range(4)],-1);ll=-.5*(z*z).sum(1)-2*np.log(2*np.pi)+np.linalg.slogdet(J)[1];results['flow_jacobian_logq_error']=float(max(abs(ll-f.forward(y,v))));assert results['flow_jacobian_logq_error']<1e-7
# Exact conditional mixture t identity.
M=r.normal(size=(7,7));C=M@M.T+np.eye(7);t=TMixture(np.array([.4,.6]),r.normal(size=(2,7)),np.stack([C,2*C]),8);xx=r.normal(size=(20,7));tv=TMixture(t.w,t.m[:,4:],t.c[:,4:,4:],8);err=max(abs(t.cond_logq(xx[:,:4],xx[:,4:])-(t.logq(xx)-tv.logq(xx[:,4:]))));assert err<1e-10;results['student_conditional_identity']=float(err)
# Legitimate target zeros on q draws must be included, not dropped.
p=np.abs(r.normal(size=4000));q=r.normal(size=4000);lpp=norm.logpdf(p);lqp=lpp;lpq=np.where(q>0,norm.logpdf(q),-np.inf);lqq=norm.logpdf(q);b=bridge(lpp,lqp,lpq,lqq);assert b['success'] and abs(b['logZ']-np.log(.5))<.08;results['zero_target_bridge']=b
# Optional reference engine checked against a known Gaussian integral.
P=np.diag([1.,3.]);out,_=smc(1024,501,2,lambda x:(-.5*np.sum(x*(x@P),1),-x@P),np.eye(2)+P,steps=16);err=abs(out['logZ_normalized_prior']+.5*np.log(np.linalg.det(np.eye(2)+P)));assert err<.15;results['SMC_gaussian_logZ_error']=err
results['passed']=True;write(ROOT/'logs/local_unit_checks.json',results);print(json.dumps(results,indent=2))
