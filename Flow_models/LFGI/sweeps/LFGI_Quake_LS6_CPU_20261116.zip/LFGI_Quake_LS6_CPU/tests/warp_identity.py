import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,numpy as np
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from campaign import warp_logp
from common import write,rng
r=rng(90);d=23;A=r.normal(size=(d,d));C=A@A.T+np.eye(d);P=np.linalg.inv(C);L=np.linalg.cholesky(C);mu=r.normal(size=d)
class Target:
 def __init__(self):self.E=0
 def logp(self,x):self.E+=len(x);return -.5*np.einsum('ni,ij,nj->n',x-mu,P,x-mu)
t=Target();z=r.normal(size=(20,d));lp=warp_logp((mu,L),z,t);base=-.5*(z*z).sum(1)-d/2*np.log(2*np.pi);logZ=d/2*np.log(2*np.pi)+np.log(np.diag(L)).sum();err=max(abs(lp-base-logZ));assert err<1e-10 and t.E==40;write(R/'logs/local_warp_identity.json',dict(passed=True,max_log_normalizer_error=err,E=t.E));print(err)
