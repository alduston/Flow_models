import os,sys,tempfile,json,subprocess,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from common import write
with tempfile.TemporaryDirectory() as temp:
 d=Path(temp);shutil.copy(R/'submit.sh',d);(d/'bin').mkdir();(d/'ls6').mkdir();shutil.copy(R/'ls6/job.sh',d/'ls6/job.sh')
 (d/'bin/sbatch').write_text('''#!/usr/bin/env python3
import os,json,sys
from pathlib import Path
p=Path(os.environ['MOCK_ROOT']);f=p/'counter';n=int(f.read_text())+1 if f.exists() else 1;f.write_text(str(n))
with (p/'calls.jsonl').open('a') as o:o.write(json.dumps(sys.argv[1:])+'\\n')
print(1000+n)
''');(d/'bin/squeue').write_text('#!/bin/bash\nif [[ "${MOCK_ACTIVE:-0}" == 1 ]]; then echo active; fi\n')
 for p in (d/'bin').iterdir():p.chmod(0o755)
 env=os.environ.copy();env.update(PATH=str(d/'bin')+os.pathsep+env['PATH'],MOCK_ROOT=str(d));subprocess.run(['bash','submit.sh','--with-reference'],cwd=d,env=env,check=True,capture_output=True);calls=[json.loads(x) for x in (d/'calls.jsonl').read_text().splitlines()];assert len(calls)==6
 def arg(c,k):return c[c.index(k)+1]
 stages={c[-2]:c for c in calls};assert '--dependency=afterok:1001' in stages['smoke'];assert '--dependency=afterok:1002' in stages['production'];assert '--dependency=afterany:1003' in stages['marginals'];assert '--dependency=afterany:1003:1004:1005' in stages['report'];assert all(arg(c,'-N')=='1' and arg(c,'-n')=='1' for c in calls)
 env['MOCK_ACTIVE']='1';r=subprocess.run(['bash','submit.sh'],cwd=d,env=env,capture_output=True);assert r.returncode!=0 and (d/'counter').read_text()=='6'
write(R/'logs/local_slurm_mock.json',dict(passed=True,jobs=6,duplicate_block_verified=True,dependency_checks=True,remote_jobs_submitted=False))
print('Slurm dependency/duplicate mock passed')
