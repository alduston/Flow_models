import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import sys,time,json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'ls6'));sys.path.insert(0,str(R/'code'))
from driver import launch
from campaign import METHODS
from common import write
label='local_e2e_'+str(int(time.time()));out=[]
with ThreadPoolExecutor(max_workers=3) as p:
 fs=[p.submit(launch,dict(seed=101,N=64,method=m),label,8,1,True) for m in METHODS]
 for f in as_completed(fs):out.append(f.result());print(out[-1],flush=True)
assert all(r['returncode']==0 and r['status']=='COMPLETE' for r in out),out
write(R/'logs/local_e2e.json',dict(passed=True,label=label,records=out))
