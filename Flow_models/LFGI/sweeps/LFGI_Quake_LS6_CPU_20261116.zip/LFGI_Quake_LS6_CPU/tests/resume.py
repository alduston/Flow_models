import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,tempfile,numpy as np
from types import SimpleNamespace
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
import flows
from common import write
random=np.random.default_rng(19);x=random.normal(size=(17,4));bank=SimpleNamespace(x=x,s=-x,P=np.tile(np.eye(4),(17,1,1)));query=random.normal(size=(2,4));config=dict(tau=1e-6,T=8.,rtol=1e-8,atol=1e-10,chunk=2);real=flows.solve_ivp;calls=0
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp)
 def interrupted(*args,**kwargs):
  global calls
  calls+=1
  if calls==2:raise RuntimeError('simulated interruption')
  return real(*args,**kwargs)
 flows.solve_ivp=interrupted
 try:flows.integrate(bank,query,None,None,False,config,p/'resume','same')
 except RuntimeError:pass
 finally:flows.solve_ivp=real
 a,la,_=flows.integrate(bank,query,None,None,False,config,p/'resume','same');b,lb,_=flows.integrate(bank,query,None,None,False,config,p/'fresh','same');assert np.max(abs(a-b))<1e-12 and np.max(abs(la-lb))<1e-12
 try:flows.integrate(bank,query,None,None,False,config,p/'resume','different')
 except AssertionError:pass
 else:raise AssertionError('cache mismatch accepted')
write(R/'logs/local_resume.json',dict(passed=True,interruption_recovered=True,identity_rejection=True))
print('Interruption/resume/identity checks passed')
