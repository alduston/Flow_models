"""NumPy conditional affine-coupling flow with explicit reverse-mode MLE gradients.
No GPU/autodiff dependency. Exact inverse and normalized Jacobian density.
"""
import copy
import numpy as np
from scipy.special import logsumexp
class CouplingFlow:
 def __init__(self,layers,width,seed):
  self.layers=layers;self.width=width;self.params=[];rng=np.random.default_rng(seed)
  for k in range(layers):
   self.params.append([rng.normal(size=(5,width))/np.sqrt(5),np.zeros(width),rng.normal(size=(width,width))/np.sqrt(width),np.zeros(width),np.zeros((width,4)),np.zeros(4)])
 def network(self,z,v,k):
  a=np.array([0,1]) if k%2==0 else np.array([2,3]);b=np.array([2,3]) if k%2==0 else np.array([0,1]);net=np.c_[z[:,a],v];W1,b1,W2,b2,W3,b3=self.params[k];h1=np.tanh(net@W1+b1);h2=np.tanh(h1@W2+b2);o=h2@W3+b3;return a,b,net,h1,h2,o
 def forward(self,e,v,grad=False):
  z=e.copy();ld=np.zeros(len(z));cache=[]
  for k in range(self.layers):
   a,b,net,h1,h2,o=self.network(z,v,k);l=1.5*np.tanh(o[:,2:]);z[:,b]=(z[:,b]-o[:,:2])*np.exp(-l);ld-=l.sum(1);cache.append((a,b,net,h1,h2,o,z[:,b].copy(),l))
  ll=-.5*np.sum(z*z,1)-2*np.log(2*np.pi)+ld
  if not grad:return ll
  dz=z/len(z);grads=[]
  for k in range(self.layers-1,-1,-1):
   a,b,net,h1,h2,o,zb,l=cache[k];W1,b1,W2,b2,W3,b3=self.params[k];db=dz[:,b].copy();do=np.c_[-db*np.exp(-l),(-db*zb+1/len(z))*1.5*(1-np.tanh(o[:,2:])**2)];gW3=h2.T@do;gb3=do.sum(0);dh2=(do@W3.T)*(1-h2*h2);gW2=h1.T@dh2;gb2=dh2.sum(0);dh1=(dh2@W2.T)*(1-h1*h1);gW1=net.T@dh1;gb1=dh1.sum(0);din=dh1@W1.T;dz[:,a]+=din[:,:2];dz[:,b]=db*np.exp(-l);grads.append([gW1,gb1,gW2,gb2,gW3,gb3])
  return -ll.mean(),grads[::-1]
 def inverse(self,z,v):
  e=z.copy()
  for k in range(self.layers-1,-1,-1):
   a,b,net,h1,h2,o=self.network(e,v,k);e[:,b]=e[:,b]*np.exp(1.5*np.tanh(o[:,2:]))+o[:,:2]
  return e
 def train(self,e,v,epochs,rng,validation=None,patience=30):
  moments=[[np.zeros_like(a) for a in layer] for layer in self.params];squares=copy.deepcopy(moments);step=0;best=np.inf;bestpar=None;bestepoch=0;stale=0
  for epoch in range(1,epochs+1):
   order=rng.permutation(len(e))
   for first in range(0,len(e),128):
    ix=order[first:first+128];loss,gr=self.forward(e[ix],v[ix],True);norm=np.sqrt(sum((g*g).sum() for layer in gr for g in layer));clip=min(1,10/max(norm,1e-12));step+=1
    for j in range(self.layers):
     for k in range(6):
      g=gr[j][k]*clip;moments[j][k]=.9*moments[j][k]+.1*g;squares[j][k]=.999*squares[j][k]+.001*g*g;self.params[j][k]-=.001*(moments[j][k]/(1-.9**step))/(np.sqrt(squares[j][k]/(1-.999**step))+1e-8)
   val=-self.forward(*(validation if validation is not None else (e,v))).mean()
   if not np.isfinite(val):raise ArithmeticError('nonfinite fitted-flow loss')
   if val<best-1e-5:best=val;bestepoch=epoch;bestpar=copy.deepcopy(self.params);stale=0
   else:stale+=1
   if validation is not None and epoch>=50 and stale>=patience:break
  if validation is not None:self.params=bestpar
  return dict(best_validation_loss=float(best),best_epoch=bestepoch,epochs_run=epoch)
class Preprocess:
 def __init__(self,e,v):
  self.vm=v.mean(0);self.vs=np.maximum(v.std(0),1e-5);design=np.c_[np.ones(len(v)),(v-self.vm)/self.vs];self.reg=np.linalg.lstsq(design,e,rcond=None)[0];r=e-design@self.reg;self.L=np.linalg.cholesky(np.cov(r.T)+np.eye(4)*1e-6);self.logdet=np.log(np.diag(self.L)).sum()
 def encode(self,e,v):
  vv=(v-self.vm)/self.vs;mu=np.c_[np.ones(len(v)),vv]@self.reg;return np.linalg.solve(self.L,(e-mu).T).T,vv
 def decode(self,z,v):
  vv=(v-self.vm)/self.vs;return z@self.L.T+np.c_[np.ones(len(v)),vv]@self.reg
class ConditionalFittedFlow:
 def __init__(self,x,velocity,seed,epochs=300,quick=False):
  self.velocity=velocity;self.blocks=[];self.info=[];rng=np.random.default_rng(seed);order=rng.permutation(len(x));split=max(32,int(.8*len(x)));it,iv=order[:split],order[split:]
  if len(iv)<8:raise ValueError('Too few validation states for fitted flow')
  for j in range(5):
   e=x[:,4*j:4*j+4];v=x[:,20:];prep=Preprocess(e[it],v[it]);et,vt=prep.encode(e[it],v[it]);ev,vv=prep.encode(e[iv],v[iv]);choices=[]
   for layers,width in ([(2,16)] if quick else [(2,32),(4,64)]):
    for restart in range(1 if quick else 2):
     sd=seed+100*j+10*layers+restart;f=CouplingFlow(layers,width,sd);info=f.train(et,vt,epochs,np.random.default_rng(sd+1),validation=(ev,vv));choices.append((info['best_validation_loss']+prep.logdet,layers,width,sd,info))
   score,layers,width,sd,selection=min(choices,key=lambda a:a[0]);pp=Preprocess(e,v);ee,vv=pp.encode(e,v);flow=CouplingFlow(layers,width,sd);final=flow.train(ee,vv,max(1,selection['best_epoch']),np.random.default_rng(sd+1));self.blocks.append((pp,flow));self.info.append(dict(layers=layers,width=width,seed=sd,selection=selection,refit_epochs=selection['best_epoch'],candidates=len(choices)))
 def logq(self,x):
  v=x[:,20:];out=self.velocity.logq(v)
  for j,(prep,flow) in enumerate(self.blocks):
   e,vv=prep.encode(x[:,4*j:4*j+4],v);out+=flow.forward(e,vv)-prep.logdet
  return out
 def sample(self,n,rng):
  v=self.velocity.sample(n,rng);x=np.zeros((n,23));x[:,20:]=v
  for j,(prep,flow) in enumerate(self.blocks):x[:,4*j:4*j+4]=prep.decode(flow.inverse(rng.normal(size=(n,4)),(v-prep.vm)/prep.vs),v)
  return x
