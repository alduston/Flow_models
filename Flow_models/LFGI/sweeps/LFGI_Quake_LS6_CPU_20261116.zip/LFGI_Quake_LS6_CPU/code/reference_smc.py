"""Optional independently initialized tempered-SMC consistency check, not exact evidence."""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
import argparse,time
import numpy as np
from scipy.special import logsumexp
from common import ROOT,read,write,save,rng,sha,source_sha
from target_numpy import Quake

def smc(n,seed,moves,likelihood,precision,steps=None,checkpoint=None,binding=None):
 random=np.random.default_rng(seed);d=len(precision);x=random.normal(size=(n,d));E=n;G=n;beta=0.;logZ=0.;trace=[]
 if checkpoint is None or not checkpoint.exists():ll,gl=likelihood(x)
 if checkpoint is not None and checkpoint.exists():
  z=np.load(checkpoint);assert str(z['binding'])==binding,'Reference checkpoint identity mismatch';x=z['x'];ll=z['ll'];gl=z['gl'];E=int(z['E']);G=int(z['G']);beta=float(z['beta']);logZ=float(z['logZ']);trace=__import__('json').loads(str(z['trace']));random.bit_generator.state=__import__('json').loads(str(z['rng']))
 while beta<1-1e-12:
  if len(trace)>2000:raise ArithmeticError('SMC exceeded 2000 temperatures')
  def ess(b):
   w=(b-beta)*ll;return np.exp(2*logsumexp(w)-logsumexp(2*w))
  if steps is not None:bn=min(1.,beta+1/steps)
  elif ess(1.)>=.8*n:bn=1.
  else:
   lo=beta;hi=1.;goal=min(.8*n,.95*np.isfinite(ll).sum())
   for k in range(45):
    mid=(lo+hi)/2
    if ess(mid)<goal:hi=mid
    else:lo=mid
   bn=(lo+hi)/2
   if bn-beta<1e-12:raise ArithmeticError('SMC temperature cannot advance')
  lw=(bn-beta)*ll;logZ+=logsumexp(lw)-np.log(n);w=np.exp(lw-logsumexp(lw));u=(random.random()+np.arange(n))/n;ix=np.minimum(np.searchsorted(np.cumsum(w),u),n-1);x=x[ix].copy();ll=ll[ix];gl=gl[ix];beta=bn
  P=(1-beta)*np.eye(d)+beta*precision;cov=np.linalg.inv(P);L=np.linalg.cholesky(cov);dt=.05;accepted=0
  for step in range(moves):
   grad=-x+beta*gl;y=x+dt*(grad@cov)+np.sqrt(2*dt)*random.normal(size=x.shape)@L.T;ly,gy=likelihood(y);E+=n;G+=n;gnew=-y+beta*gy
   old=-.5*(x*x).sum(1)+beta*ll;new=-.5*(y*y).sum(1)+beta*ly;f=y-x-dt*(grad@cov);b=x-y-dt*(gnew@cov);lr=new-old+(np.einsum('ni,ij,nj->n',f,P,f)-np.einsum('ni,ij,nj->n',b,P,b))/(4*dt);ok=np.isfinite(lr)&(np.log(random.random(n))<lr);x[ok]=y[ok];ll[ok]=ly[ok];gl[ok]=gy[ok];accepted+=int(ok.sum())
  trace.append(dict(beta=beta,logZ_normalized_prior=float(logZ),acceptance=accepted/(n*moves)))
  if checkpoint is not None:save(checkpoint,x=x,ll=ll,gl=gl,E=E,G=G,beta=beta,logZ=logZ,trace=np.array(__import__('json').dumps(trace)),rng=np.array(__import__('json').dumps(random.bit_generator.state)),binding=np.array(binding))
 return dict(logZ_normalized_prior=float(logZ),logZ_pilot=float(logZ+d/2*np.log(2*np.pi)),trace=trace,E=E,G=G,H=0),x

def main(n,seed,moves):
 t=Quake(read(ROOT/'data/model_spec.json'));data=np.load(ROOT/'data/inputs.npz');P=data['P'].mean(0);calls=0
 def likelihood(x):
  with np.errstate(all='ignore'):
   pred,J=t.parts(x,True);r=(pred-t.y)/t.sd;ll=-.5*(r*r).sum(1);gr=-np.einsum('nki,nk->ni',J/t.sd[None,:,None],r);valid=np.isfinite(ll)&np.isfinite(gr).all(1)
  ll[~valid]=-np.inf;gr[~valid]=0;return ll,gr
 path=ROOT/f'reference/N{n}_M{moves}_seed{seed}.json'
 binding=source_sha()+sha(ROOT/'data/inputs.npz')+str((n,seed,moves))
 if path.exists():
  assert read(path)['binding']==binding,'Reference output identity mismatch';return
 tick=time.time();out,x=smc(n,seed,moves,likelihood,P,checkpoint=path.with_suffix('.checkpoint.npz'),binding=binding);out.update(N=n,moves=moves,seed=seed,seconds=time.time()-tick,status='PROVISIONAL_SMC_CHECK_NOT_EXACT_TRUTH',binding=binding,input_sha256=sha(ROOT/'data/inputs.npz'));save(path.with_suffix('.npz'),samples=x);write(path,out)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--n',type=int,default=4096);a.add_argument('--seed',type=int,default=501);a.add_argument('--moves',type=int,default=10);p=a.parse_args();main(p.n,p.seed,p.moves)
