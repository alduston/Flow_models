import argparse,csv,json
from pathlib import Path
import numpy as np
from common import ROOT,read,write,rng,source_sha
from campaign import METHODS
LABELS={'joint_gaussian':'Joint Gaussian','joint_gmm_bic':'Joint GMM','warp3':'Warp-III bridge','conditional_gaussian':'Conditional Gaussian','conditional_gmm_bic':'Conditional GMM','conditional_t_mixture':'Conditional t mixture','conditional_gn_mixture':'Conditional GN mixture','conditional_fitted_flow':'Conditional fitted flow','joint_lfgi':'Joint LFGI','conditional_lfgi':'Conditional LFGI'}
def report(label):
 config=read(ROOT/'configs/campaign.json');expected=read(ROOT/'prepared/cells.json');expected=[c for c in expected if label!='pilot' or (c['seed']==101 and c['N']==1024)];rows=[];statuses=[]
 for c in expected:
  p=ROOT/'results'/label/f"seed{c['seed']}/N{c['N']}"/c['method']/'status.json'
  if not p.exists():statuses.append(dict(**c,status='MISSING'));continue
  s=read(p);statuses.append(dict(**c,status=s['status']))
  if s['status']!='COMPLETE':continue
  for r in s['records']:
   rows.append(dict(**c,repeat=r['repeat'],logZ=r['bridge']['logZ'],bridge_overlap=r['bridge']['overlap'],logratio_SD=r['logratio_SD'],mean_logq_p=r['mean_logq_p'],ELBO=r['ELBO'],entropy_q=r['entropy_q'],ESS=r['bridge']['IS_ESS'],new_E=r['new_E'],posterior_E_once=(s['posterior_E'] if r['repeat']==0 else 0),new_G=r['new_G'],new_H=r['new_H'],diagnostic_forward=r.get('geometry',{}).get('extra_diagnostic_forward',0),fit_seconds=s['fit_seconds'],evaluation_seconds=r['seconds'],space=r['space']))
 out=ROOT/'reports'/label;out.mkdir(parents=True,exist_ok=True);write(out/'status.json',dict(expected=len(expected),complete=sum(s['status']=='COMPLETE' for s in statuses),failed=sum(s['status']=='FAILED' for s in statuses),cells=statuses,exact_reference_logZ=None))
 if rows:
  with (out/'per_repeat.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 aggregates=[]
 for n in config['bank_sizes']:
  for m in METHODS:
   rs=[r for r in rows if r['N']==n and r['method']==m]
   if not rs:continue
   byseed={s:[r for r in rs if r['seed']==s] for s in sorted(set(r['seed'] for r in rs))};a=dict(N=n,method=m,bank_groups=len(byseed),proposal_repeats=len(rs));random=rng(n,METHODS.index(m),998)
   for metric in ['logZ','bridge_overlap','logratio_SD','mean_logq_p','ELBO','entropy_q']:
    means=np.array([np.mean([r[metric] for r in v]) for v in byseed.values() if all(r[metric] is not None for r in v)])
    a[metric]=float(means.mean()) if len(means) else None
    if len(means)>1 and np.isfinite(means).all():a[metric+'_bank_CI95']=np.quantile(np.mean(random.choice(means,(2000,len(means))),axis=1),[.025,.975]).tolist()
   a['mean_within_fit_bridge_SD']=float(np.mean([np.std([r['logZ'] for r in v],ddof=1) if len(v)>1 else 0 for v in byseed.values()]));aggregates.append(a)
 write(out/'summary.json',aggregates)
 paired=[]
 for n in config['bank_sizes']:
  for m in METHODS:
   if m in ['warp3','conditional_lfgi']:continue
   seeds=sorted(set(r['seed'] for r in rows if r['N']==n and r['method']==m)&set(r['seed'] for r in rows if r['N']==n and r['method']=='conditional_lfgi'))
   for metric in ['mean_logq_p','ELBO']:
    differences=[]
    for seed in seeds:
     lf=[r[metric] for r in rows if r['N']==n and r['seed']==seed and r['method']=='conditional_lfgi'];bb=[r[metric] for r in rows if r['N']==n and r['seed']==seed and r['method']==m]
     if lf and bb and all(x is not None and np.isfinite(x) for x in lf+bb):differences.append(float(np.mean(lf)-np.mean(bb)))
    if differences:
     a=np.array(differences);ci=np.quantile(np.mean(rng(n,METHODS.index(m),881).choice(a,(2000,len(a))),1),[.025,.975]) if len(a)>1 else [None,None];paired.append(dict(N=n,comparator=m,metric=('forward_KL_reduction' if metric=='mean_logq_p' else 'reverse_KL_reduction'),groups=len(a),estimate=float(a.mean()),CI_low=ci[0],CI_high=ci[1]))
 if paired:
  with (out/'paired_KL.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(paired[0]));w.writeheader();w.writerows(paired)

 text='# Quake LS6 density/bridge comparison\n\nExact quake evidence is not known. log Z uses unnormalized prior/likelihood pilot convention. Bank groups randomize a fixed fitting-chain pool; repeats are nested proposal simulations. These are not independent NUTS runs. Warp-III uses a symmetrized transformed target and has no original-coordinate density/ELBO statistic.\n\n'
 text+='| N | Method | Groups | log-ratio SD | Mean log q | ELBO | Bridge log Z | Within-fit bridge SD |\n|---|---|---:|---:|---:|---:|---:|---:|\n'
 for a in aggregates:
  def fmt(k):return 'N/A' if a[k] is None else f'{a[k]:.4f}'
  text+=f"| {a['N']} | {LABELS[a['method']]} | {a['bank_groups']} | {fmt('logratio_SD')} | {fmt('mean_logq_p')} | {fmt('ELBO')} | {fmt('logZ')} | {a['mean_within_fit_bridge_SD']:.4f} |\n"
 text+='\nNo absolute evidence RMSE is computed from agreement among bridge estimates. Optional reference SMC outputs remain provisional until refinement/replication is assessed. Full failures are retained in status.json. Proposal target E counts and diagnostic forward calls are separate in per_repeat.csv; cached E/G/H acquisition is shared and recorded in prepared/acquisition.json.\n';(out/'REPORT.md').write_text(text)
 if aggregates:
  import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
  fig,ax=plt.subplots(1,3,figsize=(14,4),layout='constrained')
  for mi,m in enumerate(METHODS):
   vals=[a for a in aggregates if a['method']==m]
   for a,k in zip(ax,['logratio_SD','ELBO','mean_within_fit_bridge_SD']):
    v=[x for x in vals if x.get(k) is not None and np.isfinite(x[k])]
    if v:
     color=plt.cm.tab10(mi);a.plot([x['N'] for x in v],[x[k] for x in v],'o-',label=LABELS[m],ms=3,color=color)
     ci=k+'_bank_CI95'
     if all(ci in x for x in v):a.fill_between([x['N'] for x in v],[x[ci][0] for x in v],[x[ci][1] for x in v],color=color,alpha=.12)
  for a,title in zip(ax,['Posterior log-ratio SD','ELBO (pilot units)','Within-fit bridge log Z SD']):a.set(xlabel='Fitting bank N',title=title)
  ax[0].set_yscale('log');fig.legend(*ax[2].get_legend_handles_labels(),loc='outside lower center',ncol=5,fontsize=7);fig.savefig(out/'comparison.png',dpi=180);plt.close(fig)
 print(json.dumps(read(out/'status.json'))[:300])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--label',default='production');a=p.parse_args();report(a.label)
