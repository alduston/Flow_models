import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
import argparse,fcntl,json,pickle,sys,time,traceback,hashlib,platform
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
from common import ROOT,read,write,save,sha,source_sha,arrays_sha,rng,bridge
from target_numpy import Quake
from models import GMM,fit_gmm,ConditionalBank
from mixtures import select_gmm,ConditionalMixtures
from fitted_flow import ConditionalFittedFlow
from flows import PFModel
METHODS=['joint_gaussian','joint_gmm_bic','warp3','conditional_gaussian','conditional_gmm_bic','conditional_t_mixture','conditional_gn_mixture','conditional_fitted_flow','joint_lfgi','conditional_lfgi']
def target():return Quake(read(ROOT/'data/model_spec.json'))
def prepare():
 spec=read(ROOT/'configs/campaign.json');data=np.load(ROOT/'data/inputs.npz');raw=data['reference'];t=target();ids=rng(991).permutation(4000);excluded=np.asarray(data['posterior_ids'])-4000;allowed=np.setdiff1d(np.arange(4000),excluded);pid=4000+rng(992).permutation(allowed)[:spec['posterior_n']];post=raw[pid];save(ROOT/'prepared/posterior.npz',x=post,ids=pid,logp=t.logp(post));E,S,P=t.values(raw[:4000]);save(ROOT/'prepared/derivative_pool.npz',E=E,s=S,P=P)
 for seed in spec['bank_seeds']:
  order=rng(seed,1).permutation(4000)[:max(spec['bank_sizes'])];save(ROOT/f'prepared/seed{seed}.npz',x=raw[order],s=S[order],P=P[order],E=E[order],ids=order)
 write(ROOT/'prepared/split_ids.json',dict(posterior_ids=pid,bank_ids={str(seed):np.load(ROOT/f'prepared/seed{seed}.npz')['ids'].tolist() for seed in spec['bank_seeds']}))
 write(ROOT/'prepared/acquisition.json',dict(E=4000,G=4000,H=4000,shared_pool=True,supplied_cached_pilot_count=1024,posterior_energy_evaluations=len(post),reference_scope='fixed archived NUTS chains; bank randomizations are conditional on this pool',excluded_primary_pilot_query_ids=data['posterior_ids'].tolist()))
 cells=[dict(seed=s,N=n,method=m) for s in spec['bank_seeds'] for n in spec['bank_sizes'] for m in METHODS];write(ROOT/'prepared/cells.json',cells)
def environment():
 import scipy,sklearn
 return dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,native_binary_sha256=sha(ROOT/'code/cond_div.so'),machine=platform.machine())
def identity(spec,inp):return hashlib.sha256((source_sha()+sha(ROOT/'configs/campaign.json')+sha(ROOT/'data/inputs.npz')+json.dumps(environment(),sort_keys=True)+json.dumps(spec,sort_keys=True)+arrays_sha(inp['x'],inp['s'],inp['P'])).encode()).hexdigest()
def paths(cell,label):return ROOT/'results'/label/f"seed{cell['seed']}/N{cell['N']}"/cell['method']
def fit(cell,inp,config,dest,binding,quick=False):
 method=cell['method'];x=inp['x'];vm,vi=select_gmm(x[:,20:],[1,2],40000+cell['seed']);bank=ConditionalBank(x,inp['s'],inp['P'],vm);info={'velocity':vi};ks=config['gmm_K'];seed=50000+cell['seed'];tau=min(config['tau_cap'],float(.5*np.log1p(.01/np.linalg.eigvalsh(inp['P']).max())));solver=dict(tau=tau,T=8.,rtol=config['rtol'],atol=config['atol'],chunk=config['chunk'])
 if method=='joint_gaussian':m=fit_gmm(x,1,seed)
 elif method=='joint_gmm_bic':m,info['mixture']=select_gmm(x,ks,seed)
 elif method=='warp3':
  m=ConditionalMixtures(x,vm,'gaussian',[1],seed);mean,L=m.affine();m=(mean,L);info['whitening']='model-structured Gaussian affine whitening'
 elif method in ['conditional_gaussian','conditional_gmm_bic','conditional_t_mixture']:
  m=ConditionalMixtures(x,vm,{'conditional_gaussian':'gaussian','conditional_gmm_bic':'gmm','conditional_t_mixture':'student'}[method],ks,seed);info['blocks']=m.info
 elif method=='conditional_fitted_flow':m=ConditionalFittedFlow(x,vm,seed,epochs=(3 if quick else config['flow_epochs']),quick=quick);info['flow']=m.info
 elif method=='conditional_gn_mixture':m=bank
 else:m=PFModel(bank,method=='conditional_lfgi',solver,dest/'checkpoints',binding)
 info.update(bank_ids=inp['ids'].tolist(),tau=tau,solver=solver,new_fitting_E=0,new_fitting_G=0,new_fitting_H=0,available_cache_rows=len(x));return m,info
class EnergyLedger:
 def __init__(self):self.t=target();self.E=0
 def logp(self,x):self.E+=len(x);return self.t.logp(x)
def statistics(lp,lq,lpq,lqq,space='original'):
 b=bridge(lp,lq,lpq,lqq);w=lpq-lqq;r=lp-lq
 return dict(bridge=b,space=space,posterior_count=len(lp),proposal_count=len(lpq),logratio_SD=(float(r.std(ddof=1)) if space=='original' else None),mean_logq_p=(float(lq.mean()) if space=='original' else None),ELBO=(float(w.mean()) if space=='original' else None),ELBO_MCSE=(float(w.std(ddof=1)/np.sqrt(len(w))) if space=='original' and np.isfinite(w).all() else None),entropy_q=(float(-lqq.mean()) if space=='original' else None))
def run_cell(cell,label='production',count=None,repeats=None,quick=False,retry=False):
 config=read(ROOT/'configs/campaign.json');n=cell['N'];base=np.load(ROOT/f"prepared/seed{cell['seed']}.npz");inp={k:base[k][:n] for k in ['x','s','P','ids']};dest=paths(cell,label);dest.mkdir(parents=True,exist_ok=True)
 lock=(dest/'LOCK').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);full=dict(cell=cell,label=label,count=count or config['posterior_n'],repeats=repeats or config['proposal_repeats'],quick=quick);binding=identity(full,inp)
 status=dest/'status.json'
 if status.exists():
  old=read(status)
  if old.get('binding')!=binding:raise RuntimeError('Cell identity mismatch; use a new campaign directory: '+str(dest))
  if old['status']=='COMPLETE':return old
  if old['status']=='FAILED' and not retry:raise RuntimeError('Retained failed cell; diagnose and use explicit --retry-failed: '+str(dest))
 if status.exists():write(dest/'attempts'/('previous_'+str(time.time_ns())+'.json'),read(status))
 write(status,dict(status='RUNNING',binding=binding,cell=cell,started=time.time()));tick=time.time()
 try:
  fitfile=dest/'model.pkl';meta=dest/'fit.json'
  if fitfile.exists():
   ft=read(meta);assert ft['binding']==binding and ft['pickle_sha256']==sha(fitfile)
   with fitfile.open('rb') as f:m=pickle.load(f)
   info=ft['info'];fit_seconds=ft['seconds']
  else:
   ftick=time.time();m,info=fit(cell,inp,config,dest,binding,quick);fit_seconds=time.time()-ftick;tmp=fitfile.with_name('model.pkl.tmp')
   with tmp.open('wb') as f:pickle.dump(m,f,protocol=4)
   os.replace(tmp,fitfile);write(meta,dict(binding=binding,pickle_sha256=sha(fitfile),info=info,seconds=fit_seconds))
  pp=np.load(ROOT/'prepared/posterior.npz');post=pp['x'][:full['count']];lp=pp['logp'][:len(post)];ledger=EnergyLedger();warp=cell['method']=='warp3';nq=count or config['proposal_n'];postfile=dest/'posterior_eval.npz'
  if postfile.exists():a=dict(np.load(postfile));assert str(a['binding'])==binding;lqp=a['logq'];lpp=a['logp'];pstates=a['states'];posterior_E=int(a['E'])
  else:
   if warp:
    mu,L=m;pstates=np.linalg.solve(L,(post-mu).T).T;pstates*=rng(cell['seed'],cell['N'],3).choice([-1,1],len(post))[:,None];lqp=-.5*(pstates*pstates).sum(1)-23/2*np.log(2*np.pi);lpp=np.logaddexp(lp,ledger.logp(2*mu-post))-np.log(2)+np.log(np.diag(L)).sum()
   else:
    pstates=post;lpp=lp;lqp=m.logq(post) if not isinstance(m,ConditionalBank) else m.local_logq(post)
   posterior_E=ledger.E;save(postfile,states=pstates,logq=lqp,logp=lpp,E=posterior_E,binding=np.array(binding))
  records=[]
  for rep in range(full['repeats']):
   file=dest/f'repeat{rep:02d}.json';rawfile=dest/f'repeat{rep:02d}.npz'
   if file.exists():r=read(file);assert r['binding']==binding;records.append(r);continue
   rt=time.time();field_start=getattr(m,'calls',0);random=rng(cell['seed'],cell['N'],METHODS.index(cell['method']),rep,4);E0=ledger.E
   if warp:
    q=random.normal(size=(nq,23));lqq=-.5*(q*q).sum(1)-23/2*np.log(2*np.pi);lpq=warp_logp(m,q,ledger)
   else:
    if isinstance(m,PFModel):q,lqq=m.sample_logq(nq,random,'proposal_repeat%d'%rep)
    elif isinstance(m,ConditionalBank):q=m.local_sample(nq,random);lqq=m.local_logq(q)
    else:q=m.sample(nq,random);lqq=m.logq(q)
    lpq=ledger.logp(q)
   r=statistics(lpp,lqp,lpq,lqq,'warped_symmetrized' if warp else 'original');r.update(binding=binding,repeat=rep,seconds=time.time()-rt,new_E=ledger.E-E0,new_G=0,new_H=0,field_query_calls=getattr(m,'calls',0)-field_start)
   if not r['bridge']['success']:raise ArithmeticError('bridge failure: '+str(r['bridge']))
   if not warp:r['geometry']=geometry(q,ledger.t)
   save(rawfile,proposal=q,logq=lqq,logp=lpq,binding=np.array(binding));write(file,r);records.append(r)
  done=dict(status='COMPLETE',binding=binding,cell=cell,fit_seconds=fit_seconds,evaluation_seconds=time.time()-tick,info=info,posterior_E=posterior_E,shared_cache_access=dict(E=n,G=n,H=n),records=records,environment=environment(),source_sha256=source_sha(),normalization_id='quake_pilot_unnormalized_prior_and_likelihood_v1',reference='fixed archived held-out chains, no exact Z reference');write(status,done);return done
 except Exception as exc:
  write(status,dict(status='FAILED',binding=binding,cell=cell,error=str(exc),traceback=traceback.format_exc()));raise
 finally:lock.close()
def warp_logp(model,z,ledger):
 mu,L=model;xp=mu+z@L.T;xm=mu-z@L.T;return np.logaddexp(ledger.logp(xp),ledger.logp(xm))-np.log(2)+np.log(np.diag(L)).sum()
def geometry(x,t):
 pred=t.forward(x);ev,t0,*_=t.physical(x);zs=[]
 for j in range(5):
  ix=np.flatnonzero(t.pe==j);w=1/t.sd[ix]**2;var=1/(1/t.prior['origin_time_sd']**2+w.sum());mu=var*((t.y[ix]-(pred[:,ix]-t0[:,j,None]))*w).sum(1);zs.append((t0[:,j]-mu)/np.sqrt(var))
 z=np.array(zs).T;return dict(origin_mean=z.mean(0),origin_sd=z.std(0),all_sparse_origins_negative=np.all(z[:,1:]<0,1).mean(),mean_chi2=np.mean(np.sum(((pred-t.y)/t.sd)**2,1)),note='diagnostic forward evaluations counted separately',extra_diagnostic_forward=len(x))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','cell']);p.add_argument('--seed',type=int);p.add_argument('--N',type=int);p.add_argument('--method',choices=METHODS);p.add_argument('--label',default='production');p.add_argument('--count',type=int);p.add_argument('--repeats',type=int);p.add_argument('--quick',action='store_true');p.add_argument('--retry-failed',action='store_true');a=p.parse_args()
 if a.action=='prepare':prepare()
 else:run_cell(dict(seed=a.seed,N=a.N,method=a.method),a.label,a.count,a.repeats,a.quick,a.retry_failed)
