#include <cmath>
extern "C" void cond_div(int q,int n,int d,const double*w,const double*x,const double*S,const double*P,const double*C,const double*vel,const double*mu,const double*ms,const double*H,const double*Ai,const double*v,double a,double g,double*out){
 for(int k=0;k<q;k++){
  const double*hk=H+k*d*d;const double*ik=Ai+k*d*d;double total=0;
  for(int j=0;j<d;j++)for(int l=0;l<d;l++)total-=ik[j*d+l]*hk[l*d+j];
  for(int b=0;b<n;b++){
   double weight=w[k*n+b];if(weight<1e-300)continue;double dx[32],dxs[32],ds[32],hd[32],pv[32];
   for(int j=0;j<d;j++){dx[j]=x[b*d+j]-mu[k*d+j];ds[j]=S[b*d+j]-ms[k*d+j];for(int z=0;z<3;z++)ds[j]-=C[(b*d+j)*3+z]*vel[k*3+z];}
   for(int j=0;j<d;j++){dxs[j]=0;hd[j]=0;pv[j]=0;for(int l=0;l<d;l++){dxs[j]+=ik[j*d+l]*dx[l];hd[j]+=hk[j*d+l]*dx[l];pv[j]+=(P[(b*d+j)*d+l]-hk[j*d+l])*v[k*d+l];}}
   double one=0,two=0;for(int j=0;j<d;j++){one+=dxs[j]*(ds[j]+hd[j]);two+=dxs[j]*pv[j];}total+=weight*(a*a/g*one+two);
  }out[k]=total;
 }
}
