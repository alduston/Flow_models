"""Separate actual particle histograms from valid q/r implicit marginal integration."""
import argparse,pickle
import numpy as np
from common import ROOT,read,write,save
from campaign import paths,target
from flows import PFModel
from models import ConditionalBank

def run(label='production',seed=101,n=1024,implicit=False):
 import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
 t=target();axes=read(ROOT/'data/projection_axes.json')['axes'];methods=['joint_lfgi','conditional_lfgi','conditional_gmm_bic','conditional_t_mixture','conditional_fitted_flow'];out=ROOT/'reports'/label;out.mkdir(parents=True,exist_ok=True);config=read(ROOT/'configs/campaign.json');ref=np.load(ROOT/'data/inputs.npz')['reference'][4000:];clouds={'NUTS reference':ref};info={};models={}
 for m in methods:
  d=paths(dict(seed=seed,N=n,method=m),label)
  if not (d/'status.json').exists() or read(d/'status.json')['status']!='COMPLETE':continue
  clouds[m]=np.concatenate([np.load(p)['proposal'] for p in sorted(d.glob('repeat*.npz'))]);ft=read(d/'fit.json')
  from common import sha
  assert ft['pickle_sha256']==sha(d/'model.pkl')
  with (d/'model.pkl').open('rb') as f:models[m]=pickle.load(f)
  if isinstance(models[m],PFModel):models[m].cache=d/'marginal_checkpoints'
 def proj(x,e):
  events=t.physical(x)[0];xy=events[:,e,:2]-axes[e]['mean'];return np.c_[xy@np.asarray(axes[e]['direction']),events[:,e,2]]
 def figure(data,weights,name):
  fig,aa=plt.subplots(2,len(data),figsize=(3*len(data),6),layout='constrained',squeeze=False)
  for j,(m,x) in enumerate(data.items()):
   for row,e in enumerate([2,4]):
    a=aa[row,j];z=proj(x,e);window=axes[e].get('window',None)
    # Common windows from the reference, with no in-window renormalization.
    zr=proj(ref,e);lo=np.quantile(zr,.002,axis=0);hi=np.quantile(zr,.998,axis=0);bins=[np.linspace(lo[k],hi[k],41) for k in range(2)];w=weights.get(m,np.ones(len(x)));h=np.histogram2d(z[:,0],z[:,1],bins=bins,weights=w)[0]/len(x)/np.diff(bins[0])[0]/np.diff(bins[1])[0];href=np.histogram2d(zr[:,0],zr[:,1],bins=bins)[0]/len(zr)/np.diff(bins[0])[0]/np.diff(bins[1])[0];a.pcolormesh(bins[0],bins[1],h.T,shading='auto',vmin=0,vmax=href.max(),cmap='viridis');a.invert_yaxis();a.set(title=m if row==0 else '',xlabel='E%d horizontal offset (km)'%(e+1),ylabel='Depth (km)');save(out/(name+'_'+m+'_E%d.npz'%(e+1)),hist=h,bins0=bins[0],bins1=bins[1])
  fig.suptitle('Implicit density marginals via q/r (reference: actual NUTS)' if weights else 'Actual particle histograms: one bank, independent proposal repeats');fig.savefig(out/(name+'.png'),dpi=160);plt.close(fig)
 figure(clouds,{},'actual_particle_histograms')
 if implicit:
  d=paths(dict(seed=seed,N=n,method='conditional_gmm_bic'),label);p=sorted(d.glob('repeat*.npz'))[-1];a=np.load(p);x=a['proposal'];lr=a['logq'];data={'NUTS reference':ref};weights={}
  for m,model in models.items():
   lq=model.logq(x,tag='marginal_cubature') if isinstance(model,PFModel) else model.local_logq(x) if isinstance(model,ConditionalBank) else model.logq(x)
   with np.errstate(over='ignore'):w=np.exp(lq-lr)
   if not np.isfinite(w).all():raise ArithmeticError('Nonfinite cubature weights; no implicit histogram created for '+m)
   info[m]=dict(proposal='conditional_gmm_bic',count=len(x),mass_estimate=float(w.mean()),mass_MCSE=float(w.std(ddof=1)/np.sqrt(len(w))),cubature_ESS=float(w.sum()**2/(w*w).sum()),note='raw integral weights, no hidden renormalization to mass one');data[m]=x;weights[m]=w
  figure(data,weights,'implicit_density_histograms');write(out/'implicit_density_integration.json',info)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--label',default='production');p.add_argument('--seed',type=int,default=101);p.add_argument('--N',type=int,default=1024);p.add_argument('--implicit',action='store_true');a=p.parse_args();run(a.label,a.seed,a.N,a.implicit)
