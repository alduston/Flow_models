# Quake conditional density / bridge campaign — Lonestar6 CPU

This is the executable follow-up to `LFGI_Quake_Refresh_Handoff_20261116.zip`. It includes the frozen earthquake forward model, archived posterior/reference arrays, cached pilot derivatives, all ten method implementations, a resumable campaign worker, LS6 setup/smoke/production/report jobs, numerical tests, and result export. It needs no GAD checkout or remote dataset. Nothing has been submitted to LS6 by the assistant.

## Run it

Upload the single ZIP (under 25 MB):

```bash
scp LFGI_Quake_LS6_CPU_20261116.zip ald4435@ls6.tacc.utexas.edu:/work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/
```

On LS6:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP
mkdir -p sweeps/lfgi_quake_conditional_20261116
unzip -q LFGI_Quake_LS6_CPU_20261116.zip -d sweeps/lfgi_quake_conditional_20261116
cd sweeps/lfgi_quake_conditional_20261116/LFGI_Quake_LS6_CPU
bash submit.sh
```

Default submission: **setup → native smoke → production → implicit marginal plots → report**. The report runs after terminal production/plot states, including failures. Production cannot start until the native smoke passes. Installation, derivative preparation, fitting and evaluation all run on compute nodes. The existing acoustic/Tanh run tree is not modified.

For a smaller first campaign, use `bash submit.sh --pilot`: ten methods at N=1024, bank seed 101, 128 posterior queries and one 128-proposal repeat. It still runs the full native smoke. `--smoke-only` submits setup and smoke only. `--no-marginals` omits the separate integrated-density plotting job. `--with-reference` adds an independently initialized provisional tempered-SMC check (six runs across two particle/move settings) after smoke. Its agreement is not automatically accepted as exact evidence.

## Main production matrix

- Bank sizes **256, 1024, 2048**, nested within five bank seeds **101–105**: **150 fits** across ten methods.
- **512 shared held-out posterior states** per fit; **five independent repeats of 512 actual proposal draws** per fitted model. Repeated q draws are nested Monte Carlo repeats, not additional bank replicates.
- Bank seeds randomize the first-two-chain fitting pool. The last-two-chain evaluation pool excludes the previous 128 pilot query states. The archived reference pool has already been inspected; this is not five new independent NUTS runs or an untouched confirmatory posterior dataset.
- Conditional Gaussian/GMM/t mixtures, conditional GN mixture, conditional fitted flow and conditional LFGI use the same fitted velocity marginal and model-known partition. Global Gaussian/GMM, structured-affine Warp-III bridge, and joint LFGI are also run. See `docs/METHODS.md`.
- Corrected endpoint `tau=min(1e-6, .5*log1p(.01/lambda_max_bank_GN))`, T=8 and matched generation/density evaluation. The adaptive rule uses fitting data only.

## Environment and resources

Defaults follow the previous working acoustic CPU bundle: account **DMS22021**, `normal`, one node/task, `gcc/11.2.0`, `python3/3.9.7`. A new venv is created at `/work/10812/ald4435/ls6/venvs/lfgi_quake_cpu_py39`; it does not change the acoustic CPU or working GAD GPU environments. Numerical dependencies are pinned for Python 3.9. The fitted flow is implemented in NumPy with tested analytic training gradients; **Torch/GPU packages are not required**.

Production starts with **8 single-thread worker subprocesses**, bounded by native-smoke RSS and CPU affinity. Increase `QUAKE_WORKERS` only after observing node memory; the safety cap is 32, two-times measured process RSS and 30% node reserve. The main wall reservation is **12 hours**, a restartable allowance, not a measured completion promise. The full joint-bank arm and repeated density evaluations can be expensive. Native LS6 performance and compatibility remain unverified until the smoke actually runs there. Common-host timings from a busy worker pool are not an isolated speed ranking.

Optional overrides before submission:

```bash
export QUAKE_WORKERS=8
export QUAKE_WALL=12:00:00
# QUAKE_ACCOUNT, QUAKE_QUEUE, QUAKE_GCC_MODULE, QUAKE_PYTHON_MODULE,
# QUAKE_CPU_VENV, QUAKE_SMOKE_WALL, QUAKE_MARGINALS_WALL,
# QUAKE_REFERENCE_WALL are supported.
```

Check live `qlimits`, account and module availability. Heavy work and wheel installation stay off login nodes. Official guide: https://docs.tacc.utexas.edu/hpc/lonestar6/ .

## Monitor, resume and retrieve

```bash
cat logs/submitted_ids.txt
squeue -u "$USER"
tail -n 30 logs/quake-production-*.out
cat logs/production_progress.json
python -c 'import json; print(json.load(open("reports/production/status.json"))["complete"])'
```

Each cell retains `status.json`, model/fit identity, posterior evaluations, `repeat*.json/.npz`, worker output and atomic ODE checkpoints under `results/production/seed*/N*/METHOD/`. Incomplete flows resume at saved log-time segments/chunks. Completed cells are skipped only when full input/recipe/source/runtime identity matches. Fits reuse a verified local pickle written by this campaign. Science failures stay failed; inspect them before explicitly setting `QUAKE_RETRY_FAILED=1` for resubmission. Earlier status records are archived under `attempts/`. A wall-time kill leaves RUNNING/incomplete cells resumable. Do not modify frozen science/config/input files in place; use a new campaign tree after changes.

When all previously submitted jobs are terminal, rerun `bash submit.sh` to resume. If a setup/smoke failure leaves descendants dependency-blocked, inspect and cancel those exact blocked IDs before resubmitting. The duplicate guard prevents submitting another DAG while a recorded job is active. Setup/smoke revalidation does not replace completed science fits. Job-level `sacct` wall/CPU accounting is needed to include interrupted work; per-fit timings alone omit killed fitting attempts.

After jobs stop, export compact results **on a compute node** (or use file-management tooling to collect them):

```bash
python pack_results.py
```

This creates independent `exports/Quake_LS6_results_001.zip`, etc., each below 25 MB, plus checksums in `exports/INDEX.json`. Default export includes raw evaluation arrays/reports/logs, excluding large model pickles and resumable checkpoints. Add `--include-models` if needed. From your computer:

```bash
scp 'ald4435@ls6.tacc.utexas.edu:/work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/sweeps/lfgi_quake_conditional_20261116/LFGI_Quake_LS6_CPU/exports/*' .
```

## Outputs and scientific limits

`reports/production/REPORT.md`, `summary.json`, `per_repeat.csv`, `paired_KL.csv`, `comparison.png`, explicit failure counts and actual/implicit 2D histograms are generated from completed cells. The implicit-density figure uses **q/r importance cubature**, reports mass/ESS/MC error, and never silently normalizes away integration error. It uses one predeclared bank, not pooled bank seeds. The NUTS reference panel is labeled as a particle histogram.

The pilot's unnormalized-prior/likelihood convention is preserved: log Z values near -24 need **−21.1355862637** added to match normalized-prior/omitted-observation-constant units, or **+11.1412898086** for fully normalized Gaussian model evidence. See `docs/NORMALIZATION_AND_UNCERTAINTY.md`. There is no exact quake evidence reference; no absolute bridge-error RMSE is manufactured from agreement among estimators. Warp-III uses a symmetrized transformed target; its bridge result is comparable, but it is not assigned an original-coordinate density/ELBO statistic.

This bundle does not rerun the existing acoustic/Tanh campaign or edit the paper. Warp-U and exact-Hessian/causal gate ablations remain outside this production matrix. The original planned work notes are included as historical context; this README and the executable configs describe current readiness.
