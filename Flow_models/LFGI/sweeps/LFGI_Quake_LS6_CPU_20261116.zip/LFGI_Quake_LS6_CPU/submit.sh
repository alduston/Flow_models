#!/bin/bash
# All installation/numerical work is on compute nodes. No remote submission is performed by unpacking.
set -euo pipefail
BUNDLE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$BUNDLE"
profile=production
reference=0
marginals=1
while [[ $# -gt 0 ]]; do
 case "$1" in --pilot) profile=pilot;; --smoke-only) profile=smoke;; --with-reference) reference=1;; --no-marginals) marginals=0;; *) echo "Usage: bash submit.sh [--pilot|--smoke-only] [--with-reference] [--no-marginals]"; exit 2;; esac
 shift
done
mkdir -p logs
exec 9>.submission.lock
flock -n 9 || { echo 'Submission already in progress'; exit 2; }
if [[ -f logs/submitted_ids.txt ]]; then
 while read -r stage id; do
  if [[ -n "$(squeue -h -j "$id" 2>/dev/null)" ]]; then echo "Existing $stage job $id is active; monitor it instead of duplicating."; exit 2; fi
 done < logs/submitted_ids.txt
 cp logs/submitted_ids.txt "logs/submitted_ids_$(date +%s).txt"
fi
: > logs/submitted_ids.txt
submit() {
 local stage=$1 wall=$2 cpus=$3 dep=${4:-}
 local args=(-A "${QUAKE_ACCOUNT:-DMS22021}" -p "${QUAKE_QUEUE:-normal}" -N 1 -n 1 -c "$cpus" -t "$wall" -J "quake-$stage" -o 'logs/%x-%j.out' -e 'logs/%x-%j.err')
 if [[ -n "$dep" ]]; then args+=(--dependency="$dep"); fi
 local raw id
 raw=$(sbatch --parsable "${args[@]}" ls6/job.sh "$BUNDLE" "$stage" "$profile")
 id=${raw%%;*}
 [[ "$id" =~ ^[0-9]+$ ]] || { echo "Unexpected sbatch response: $raw" >&2; exit 2; }
 printf '%s %s\n' "$stage" "$id" >> logs/submitted_ids.txt
 echo "$id"
}
setup=$(submit setup 00:30:00 1)
smoke=$(submit smoke "${QUAKE_SMOKE_WALL:-01:30:00}" 8 "afterok:$setup")
if [[ "$profile" != smoke ]]; then
 run=$(submit "$profile" "${QUAKE_WALL:-12:00:00}" 128 "afterok:$smoke")
 dep="afterany:$run"
 if [[ "$marginals" == 1 ]]; then marg=$(submit marginals "${QUAKE_MARGINALS_WALL:-03:00:00}" 1 "afterany:$run");dep="$dep:$marg"; fi
 if [[ "$reference" == 1 ]]; then ref=$(submit reference "${QUAKE_REFERENCE_WALL:-12:00:00}" 1 "afterok:$smoke");dep="$dep:$ref"; fi
 report=$(submit report 00:30:00 1 "$dep")
fi
cat logs/submitted_ids.txt
echo 'Native smoke gates production. Monitor squeue, logs/* and per-cell worker.log; no automatic science-failure retries.'
