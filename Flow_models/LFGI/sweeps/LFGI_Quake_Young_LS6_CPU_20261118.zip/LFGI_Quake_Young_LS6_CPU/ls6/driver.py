"""Validate, route and report the Young-only Quake LS6 campaign."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
from pathlib import Path
import platform
import resource
import subprocess
import sys
import time

for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'

B = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(B / 'code'))
from campaign import METHOD, environment, load_model, paths, prepare
from common import read, sha, source_sha, write
from partition import build, fingerprint


def check():
    for relative, digest in read(B / 'provenance/IMMUTABLE_SHA256.json').items():
        if sha(B / relative) != digest:
            raise RuntimeError(f'Frozen input/source hash mismatch for {relative}')
    return environment()


def launch(cell, label, count=None, repeats=None, retry=False):
    if cell['method'] != METHOD:
        raise ValueError('Only Young-gate cells may be launched')
    dest = paths(cell, label)
    dest.mkdir(parents=True, exist_ok=True)
    args = [sys.executable, str(B / 'code/campaign.py'), 'cell',
            '--seed', str(cell['seed']), '--N', str(cell['N']), '--label', label]
    if count is not None:
        args += ['--count', str(count)]
    if repeats is not None:
        args += ['--repeats', str(repeats)]
    if retry:
        args += ['--retry-failed']
    with (dest / 'worker.log').open('a') as logfile:
        process = subprocess.run(args, cwd=B, stdout=logfile, stderr=subprocess.STDOUT)
    status = dest / 'status.json'
    return dict(**cell, returncode=process.returncode,
                status=read(status)['status'] if status.exists() else 'INCOMPLETE')


def smoke():
    import numpy as np
    import psutil
    from marginals import run

    env = check()
    subprocess.run([sys.executable, str(B / 'tests/gate.py')], cwd=B, check=True)
    label = 'smoke_' + os.getenv('SLURM_JOB_ID', str(time.time_ns()))
    cell = dict(seed=101, N=1024, method=METHOD)
    record = launch(cell, label, count=32, repeats=1)
    if record['returncode'] or record['status'] != 'COMPLETE':
        raise RuntimeError(f'Native full-bank smoke failed for {record}')
    dest = paths(cell, label)
    model, _ = load_model(dest)
    with np.load(dest / 'repeat00.npz') as data:
        logq = model.logq(data['proposal'][:2], tag='independent_roundtrip')
        error = float(np.max(np.abs(logq - data['logq'][:2])))
    if not error < 1e-3:
        raise ArithmeticError(f'Native flow roundtrip mismatch {error:.3g}')
    run(label=label, n=1024, draws=16, cubature=16)
    peak = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss * 1024
    workers = max(1, min(32, int(.7 * psutil.virtual_memory().total / max(2 * peak, 1024**3))))
    write(B / 'logs/smoke_passed.json', dict(
        passed=True, source_sha256=source_sha(), orchestration_sha256=sha(Path(__file__)),
        native_host=platform.node(), job=os.getenv('SLURM_JOB_ID'), environment=env,
        chunk_workers=int(os.getenv('QUAKE_CHUNK_WORKERS', '8')), max_process_RSS_bytes=peak,
        recommended_workers=workers, record=record, roundtrip_max_error=error,
        appendix_smoke=dict(draws=16, cubature=16),
    ))


def verified_native_smoke():
    env = check()
    gate = read(B / 'logs/smoke_passed.json')
    chunks = int(os.getenv('QUAKE_CHUNK_WORKERS', '8'))
    if (not gate['passed'] or gate['environment'] != env or gate['source_sha256'] != source_sha()
            or gate.get('orchestration_sha256') != sha(Path(__file__))
            or gate.get('chunk_workers') != chunks):
        raise RuntimeError('Native smoke does not match this source, runtime or chunk configuration')
    return gate, chunks


def production(profile, retry=False, task_index=None, task_count=None):
    gate, chunks = verified_native_smoke()
    jobs = read(B / 'prepared/cells.json')
    if profile == 'pilot':
        jobs = [cell for cell in jobs if cell['seed'] == 101 and cell['N'] == 1024]
    if any(cell['method'] != METHOD for cell in jobs):
        raise ValueError('Unexpected method in run matrix')
    count = int(os.getenv('SLURM_ARRAY_TASK_COUNT', '1')) if task_count is None else task_count
    index = int(os.getenv('SLURM_ARRAY_TASK_ID', '0')) if task_index is None else task_index
    plan = build(jobs, count, chunks)
    if not 0 <= index < count:
        raise ValueError('Array task index is outside the run matrix')
    plan_id = fingerprint(plan)
    jobs = plan['shards'][index]
    write(B / f'logs/{profile}_task{index:02d}_partition_{plan_id[:12]}.json', plan)

    workers = min(int(os.getenv('QUAKE_WORKERS', '8')), len(jobs),
                  gate['recommended_workers'], max(1, len(os.sched_getaffinity(0)) // chunks))
    if workers < 1:
        raise ValueError('QUAKE_WORKERS must be positive')
    records = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [
            pool.submit(launch, cell, profile, 128 if profile == 'pilot' else None,
                        1 if profile == 'pilot' else None, retry)
            for cell in jobs
        ]
        for future in as_completed(futures):
            records.append(future.result())
            write(B / f'logs/{profile}_task{index:02d}_progress.json', dict(
                task=index, tasks=count, partition=plan_id, expected=len(jobs), workers=workers,
                chunk_workers=chunks, records=records,
            ))
            print(records[-1], flush=True)
    if any(record['returncode'] or record['status'] != 'COMPLETE' for record in records):
        raise RuntimeError('Retained failed or incomplete cells; inspect per-cell logs')


def display(profile, task_index=None):
    from marginals import run

    verified_native_smoke()
    config = read(B / 'configs/campaign.json')
    sizes = config['display_bank_sizes']
    index = int(os.getenv('SLURM_ARRAY_TASK_ID', '0')) if task_index is None else task_index
    if profile != 'production' or not 0 <= index < len(sizes):
        raise ValueError('Appendix array is defined only for the production display bank sizes')
    run(label=profile, seed=config['display_seed'], n=sizes[index],
        draws=config['display_draws'], cubature=config['display_cubature'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=['check', 'prepare', 'smoke', 'pilot', 'production', 'report', 'marginals'])
    parser.add_argument('--profile', default='production', choices=['production', 'pilot', 'smoke'])
    parser.add_argument('--retry-failed', action='store_true')
    parser.add_argument('--task-index', type=int)
    parser.add_argument('--task-count', type=int)
    args = parser.parse_args()
    if args.stage == 'check':
        print(check())
    elif args.stage == 'prepare':
        check()
        prepare()
    elif args.stage == 'smoke':
        smoke()
    elif args.stage in ['pilot', 'production']:
        production(args.stage, args.retry_failed, args.task_index, args.task_count)
    elif args.stage == 'marginals':
        display(args.profile, args.task_index)
    else:
        check()
        from report import report
        report(args.profile)
