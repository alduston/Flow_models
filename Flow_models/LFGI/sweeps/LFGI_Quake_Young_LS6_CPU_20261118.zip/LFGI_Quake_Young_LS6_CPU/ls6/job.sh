#!/bin/bash
#SBATCH -N 1
#SBATCH -n 1
#SBATCH --no-requeue
set -euo pipefail
BUNDLE=$1
stage=$2
profile=$3
cd "$BUNDLE"
source ls6/environment.sh
if [[ "$stage" == setup ]]; then
 if [[ ! -x "$QUAKE_CPU_VENV/bin/python" ]]; then
  mkdir -p "$(dirname "$QUAKE_CPU_VENV")"
  python3 -m venv "$QUAKE_CPU_VENV"
 fi
 source "$QUAKE_CPU_VENV/bin/activate"
 python -m pip install --only-binary=:all: -r ls6/requirements.txt
 g++ -O3 -shared -fPIC -o code/cond_div.so code/cond_div.cpp
 python ls6/driver.py prepare
else
 source "$QUAKE_CPU_VENV/bin/activate"
 args=("$stage" --profile "$profile")
 if [[ "${QUAKE_RETRY_FAILED:-0}" == 1 ]]; then args+=(--retry-failed); fi
 python ls6/driver.py "${args[@]}"
 if [[ "$stage" == report ]]; then python pack_results.py --profile "$profile"; fi
fi
