"""Balance archive-matched Young cells by their reference bank size."""
import hashlib
import json


def key(cell):
    return int(cell['seed']), int(cell['N']), cell['method']


def build(cells, count, chunks=8):
    if not 1 <= count <= len(cells):
        raise ValueError('Array task count must be in the range of available cells')
    quotas = [len(cells) // count + (i < len(cells) % count) for i in range(count)]
    shards = [[] for _ in range(count)]
    loads = [0.] * count
    for cell in sorted(cells, key=lambda c: (-c['N'], key(c))):
        i = min((i for i in range(count) if len(shards[i]) < quotas[i]),
                key=lambda i: (loads[i], len(shards[i]), i))
        shards[i].append(cell)
        loads[i] += cell['N'] / (1024 * chunks)
    return dict(tasks=count, chunk_workers=chunks, quotas=quotas, estimated_relative_load=loads,
                shards=shards, weight_scope='static bank-size scheduling weights')


def fingerprint(plan):
    return hashlib.sha256(json.dumps(plan, sort_keys=True).encode()).hexdigest()
