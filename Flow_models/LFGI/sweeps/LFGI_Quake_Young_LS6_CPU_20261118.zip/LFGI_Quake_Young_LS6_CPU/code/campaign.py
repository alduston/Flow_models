"""Frozen-bank Quake campaign for the Young time-only matrix gate."""
import argparse
import csv
import fcntl
import hashlib
import json
import os
import pickle
import platform
import time
import traceback

for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[key] = '1'

import numpy as np
from common import ROOT, arrays_sha, bridge, read, rng, save, sha, source_sha, write
from flows import PFModel
from mixtures import select_gmm
from models import ConditionalBank
from target_numpy import Quake

METHOD = 'conditional_young'
METHODS = [METHOD]
# Match the archived Conditional LFGI proposal innovations (method index 9).
PROPOSAL_STREAM = 9


def target():
    return Quake(read(ROOT / 'data/model_spec.json'))


def prepare():
    config = read(ROOT / 'configs/campaign.json')
    model = target()
    with np.load(ROOT / 'data/inputs.npz') as data:
        raw = data['reference']
        excluded = data['posterior_ids']
    eligible = np.setdiff1d(np.arange(4000), excluded - 4000)
    posterior_ids = 4000 + rng(992).permutation(eligible)[:config['posterior_n']]
    bank_ids = {
        str(seed): rng(seed, 1).permutation(4000)[:max(config['bank_sizes'])]
        for seed in config['bank_seeds']
    }
    split = dict(posterior_ids=posterior_ids.tolist(),
                 bank_ids={seed: rows.tolist() for seed, rows in bank_ids.items()})
    if split != read(ROOT / 'data/archived_split_ids.json'):
        raise RuntimeError('The archived Quake bank or held-out split does not match the campaign')

    posterior = raw[posterior_ids]
    save(ROOT / 'prepared/posterior.npz', x=posterior, ids=posterior_ids,
         logp=model.logp(posterior))
    energy, score, curvature = model.values(raw[:4000])
    for seed, ids in bank_ids.items():
        save(ROOT / f'prepared/seed{seed}.npz',
             x=raw[ids], s=score[ids], P=curvature[ids], E=energy[ids], ids=ids)
    write(ROOT / 'prepared/split_ids.json', split)
    write(ROOT / 'prepared/acquisition.json', dict(
        E=4000, G=4000, H=4000, shared_pool=True, supplied_cached_pilot_count=1024,
        posterior_energy_evaluations=len(posterior),
        reference_scope='fixed archived NUTS chains',
        excluded_primary_pilot_query_ids=excluded.tolist(),
        curvature_use='preserved conditional score rebasing and integration endpoint',
    ))
    with (ROOT / 'configs/RUN_MATRIX.csv').open(newline='') as handle:
        cells = [dict(seed=int(row['seed']), N=int(row['N']), method=row['method'])
                 for row in csv.DictReader(handle)]
    expected = [dict(seed=seed, N=n, method=METHOD)
                for seed in config['bank_seeds'] for n in config['bank_sizes']]
    if cells != expected:
        raise RuntimeError('Run matrix must contain exactly the archived bank selections for Young')
    write(ROOT / 'prepared/cells.json', cells)


def environment():
    import scipy
    import sklearn

    return dict(
        python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
        sklearn=sklearn.__version__, native_binary_sha256=sha(ROOT / 'code/cond_div.so'),
        machine=platform.machine(),
    )


def identity(spec, inp):
    source = source_sha() + sha(ROOT / 'configs/campaign.json') + sha(ROOT / 'data/inputs.npz')
    bank = arrays_sha(inp['x'], inp['s'], inp['P'], inp['ids'])
    return hashlib.sha256((source + bank + json.dumps(environment(), sort_keys=True)
                           + json.dumps(spec, sort_keys=True)).encode()).hexdigest()


def paths(cell, label):
    return ROOT / 'results' / label / f"seed{cell['seed']}" / f"N{cell['N']}" / cell['method']


def fit(cell, inp, config, dest, binding):
    x, score, curvature = inp['x'], inp['s'], inp['P']
    velocity, velocity_info = select_gmm(x[:, 20:], [1, 2], 40000 + cell['seed'])
    bank = ConditionalBank(x, score, curvature, velocity)
    tau = min(config['tau_cap'], float(.5 * np.log1p(.01 / np.linalg.eigvalsh(curvature).max())))
    solver = dict(tau=tau, T=8., rtol=config['rtol'], atol=config['atol'],
                  chunk=config['chunk'], homogeneous_gate=True)
    model = PFModel(bank, True, solver, dest / 'checkpoints', binding)
    fisher = [
        score[:, j:j+4].T @ score[:, j:j+4] / len(score)
        for j in range(0, 20, 4)
    ]
    info = dict(
        velocity=velocity_info, bank_ids=inp['ids'].tolist(), tau=tau, solver=solver,
        new_fitting_E=0, new_fitting_G=0, new_fitting_H=0, available_cache_rows=len(x),
        gate='Young et al. Proposition 3, isotropic OU',
        gate_information='uncentered clean-score second moment, pooled within each event over the bank',
        event_information_matrices=fisher,
        curvature_use='same conditional score rebasing and integration endpoint as Conditional LFGI-GN',
        proposal_stream=PROPOSAL_STREAM,
    )
    return model, info


def load_model(dest, binding=None):
    model_file = dest / 'model.pkl'
    meta = read(dest / 'fit.json')
    if (binding is not None and meta['binding'] != binding) or meta['pickle_sha256'] != sha(model_file):
        raise RuntimeError('Stored model binding or checksum mismatch')
    with model_file.open('rb') as handle:
        model = pickle.load(handle)
    model.cache = dest / 'checkpoints'
    return model, meta


def statistics(logp, logq, logp_prop, logq_prop, logz):
    proposal_ratio = logp_prop - logq_prop
    ratio = logp - logq
    normalized_ratio = ratio - logz
    value = bridge(logp, logq, logp_prop, logq_prop)
    reverse_support_ok = bool(np.isfinite(proposal_ratio).all())
    bridge_error = value['logZ'] - logz if value['success'] else None
    ess_fraction = value['IS_ESS'] / len(proposal_ratio) if value['success'] else None
    return dict(
        bridge=value, space='original', posterior_count=len(logp), proposal_count=len(logp_prop),
        logratio_SD=float(ratio.std(ddof=1)), mean_logq_p=float(logq.mean()),
        ELBO=float(proposal_ratio.mean()) if reverse_support_ok else None,
        ELBO_MCSE=float(proposal_ratio.std(ddof=1) / np.sqrt(len(proposal_ratio))) if reverse_support_ok else None,
        entropy_q=float(-logq_prop.mean()), reverse_support_ok=reverse_support_ok,
        logdensity_RMSE=float(np.sqrt(np.mean(normalized_ratio**2))),
        forward_KL=float(normalized_ratio.mean()),
        reverse_KL=float(logz - proposal_ratio.mean()) if reverse_support_ok else None,
        bridge_logZ_error=bridge_error, importance_ESS_fraction=ess_fraction,
    )


def origin_residuals(model, x):
    predicted = model.forward(x)
    origin = model.physical(x)[1]
    residuals = []
    for event in range(5):
        indices = np.flatnonzero(model.pe == event)
        weights = 1 / model.sd[indices]**2
        var = 1 / (1 / model.prior['origin_time_sd']**2 + weights.sum())
        mean = var * ((model.y[indices] - (predicted[:, indices] - origin[:, event, None])) * weights).sum(1)
        residuals.append((origin[:, event] - mean) / np.sqrt(var))
    return np.stack(residuals, axis=1), (predicted - model.y) / model.sd


def geometry(x, model):
    origin, residual = origin_residuals(model, x)
    valid = np.isfinite(origin).all(1) & np.isfinite(residual).all(1)
    return dict(
        origin_mean=origin[valid].mean(0) if valid.any() else [None] * 5,
        origin_sd=origin[valid].std(0) if valid.any() else [None] * 5,
        all_sparse_origins_negative=float(np.all(origin[valid, 1:] < 0, axis=1).mean()) if valid.any() else None,
        mean_chi2=float(np.sum(residual[valid]**2, axis=1).mean()) if valid.any() else None,
        extra_diagnostic_forward=len(x), invalid_forward_draws=int((~valid).sum()),
    )


def run_cell(cell, label='production', count=None, repeats=None, retry=False):
    if cell['method'] != METHOD:
        raise ValueError('Only the Young gate is scheduled by this campaign')
    config = read(ROOT / 'configs/campaign.json')
    n = cell['N']
    with np.load(ROOT / f"prepared/seed{cell['seed']}.npz") as base:
        if n <= 0 or n > len(base['x']):
            raise ValueError('Bank size is outside the prepared range')
        inp = {key: base[key][:n] for key in ('x', 's', 'P', 'ids')}
    posterior_count = config['posterior_n'] if count is None else count
    proposal_count = config['proposal_n'] if count is None else count
    repeats = config['proposal_repeats'] if repeats is None else repeats
    if not 2 <= posterior_count <= config['posterior_n'] or repeats < 1:
        raise ValueError('Counts must fit the held-out archive, with at least two draws and one repeat')
    dest = paths(cell, label)
    dest.mkdir(parents=True, exist_ok=True)
    binding = identity(dict(cell=cell, label=label, posterior_count=posterior_count,
                            proposal_count=proposal_count, repeats=repeats), inp)
    status = dest / 'status.json'
    with (dest / 'LOCK').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if status.exists():
            old = read(status)
            if old['binding'] != binding:
                raise RuntimeError(f'Cell identity mismatch at {dest}')
            if old['status'] == 'COMPLETE':
                return old
            if old['status'] == 'FAILED' and not retry:
                raise RuntimeError(f'Failed cell at {dest}. Inspect the traceback before retrying.')
            write(dest / 'attempts' / f'previous_{time.time_ns()}.json', old)
        write(status, dict(status='RUNNING', binding=binding, cell=cell, started=time.time()))
        tick = time.time()
        try:
            fit_file = dest / 'model.pkl'
            meta_file = dest / 'fit.json'
            if fit_file.exists() and meta_file.exists():
                model, meta = load_model(dest, binding)
            else:
                fit_start = time.time()
                model, info = fit(cell, inp, config, dest, binding)
                tmp = fit_file.with_name('model.pkl.tmp')
                with tmp.open('wb') as handle:
                    pickle.dump(model, handle, protocol=4)
                os.replace(tmp, fit_file)
                meta = dict(binding=binding, pickle_sha256=sha(fit_file), info=info,
                            seconds=time.time() - fit_start)
                write(meta_file, meta)

            posterior_file = dest / 'posterior_eval.npz'
            if posterior_file.exists():
                with np.load(posterior_file) as data:
                    if str(data['binding']) != binding:
                        raise RuntimeError('Saved posterior evaluation binding mismatch')
                    logp, logq = data['logp'], data['logq']
            else:
                with np.load(ROOT / 'prepared/posterior.npz') as data:
                    states = data['x'][:posterior_count]
                    logp = data['logp'][:posterior_count]
                    ids = data['ids'][:posterior_count]
                logq = model.logq(states)
                save(posterior_file, states=states, ids=ids, logq=logq, logp=logp,
                     E=0, binding=np.array(binding))

            records = []
            quake = target()
            for repeat in range(repeats):
                result_file = dest / f'repeat{repeat:02d}.json'
                raw_file = dest / f'repeat{repeat:02d}.npz'
                if result_file.exists():
                    record = read(result_file)
                    if record['binding'] != binding or not raw_file.exists():
                        raise RuntimeError('Saved proposal record binding or raw output mismatch')
                    records.append(record)
                    continue
                start = time.time()
                calls = model.calls
                random = rng(cell['seed'], n, PROPOSAL_STREAM, repeat, 4)
                proposal, logq_prop = model.sample_logq(proposal_count, random, f'proposal_repeat{repeat}')
                logp_prop = quake.logp(proposal)
                record = statistics(logp, logq, logp_prop, logq_prop, config['reference_logZ'])
                record.update(binding=binding, repeat=repeat, seconds=time.time() - start,
                              new_E=len(proposal), new_G=0, new_H=0,
                              field_query_calls=model.calls - calls)
                record['geometry'] = geometry(proposal, quake)
                save(raw_file, proposal=proposal, logq=logq_prop, logp=logp_prop, binding=np.array(binding))
                if not record['bridge']['success']:
                    write(dest / f'repeat{repeat:02d}_failed.json', record)
                    raise ArithmeticError(f"Bridge root failed {record['bridge']}")
                write(result_file, record)
                records.append(record)
            done = dict(
                status='COMPLETE', binding=binding, cell=cell, fit_seconds=meta['seconds'],
                evaluation_seconds=time.time() - tick, info=meta['info'], posterior_E=0,
                shared_cache_access=dict(E=0, G=n, H=n), records=records, environment=environment(),
                source_sha256=source_sha(), normalization_id='quake_pilot_unnormalized_prior_and_likelihood_v1',
                reference='fixed held-out NUTS chain split; paper quadrature normalizer',
            )
            write(status, done)
            return done
        except Exception as exc:
            write(status, dict(status='FAILED', binding=binding, cell=cell,
                               error=str(exc), traceback=traceback.format_exc()))
            raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'cell'])
    parser.add_argument('--seed', type=int)
    parser.add_argument('--N', type=int)
    parser.add_argument('--method', default=METHOD, choices=METHODS)
    parser.add_argument('--label', default='production')
    parser.add_argument('--count', type=int)
    parser.add_argument('--repeats', type=int)
    parser.add_argument('--retry-failed', action='store_true')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    else:
        if args.seed is None or args.N is None:
            parser.error('cell requires --seed and --N')
        run_cell(dict(seed=args.seed, N=args.N, method=args.method), args.label,
                 args.count, args.repeats, args.retry_failed)
