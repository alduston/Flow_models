"""Young et al.'s time-only full-matrix gate for an OU event score."""
import ctypes

import numpy as np
from scipy.special import logsumexp

from common import ROOT


class HomogeneousField:
    def __init__(self, bank, velocity, event):
        self.x, shifted_scores, _, self.cross_curvature = bank.event[event]
        self.n, self.d = self.x.shape
        self.velocity = np.ascontiguousarray(velocity)
        self.velocity_logweights = bank.logweights(self.velocity)
        self.half_norm = 0.5 * np.sum(self.x**2, axis=1)

        # Estimate E[s_e s_e^T] over joint posterior draws (e, v).
        # The gate averages over velocity as well as the noisy event state.
        event_slice = slice(4 * event, 4 * event + 4)
        scores = bank.s[:, event_slice]
        self.fisher = scores.T @ scores / self.n
        self.eigenvalues, self.eigenvectors = np.linalg.eigh(self.fisher)
        self.residual = np.ascontiguousarray(shifted_scores + self.x @ self.fisher)
        self.cross_flat = np.ascontiguousarray(self.cross_curvature.reshape(self.n, -1))

        library = ctypes.CDLL(str(ROOT / 'code' / 'cond_div.so'))
        self.divergence = library.homogeneous_div
        double_array = np.ctypeslib.ndpointer(dtype=np.float64, flags='C_CONTIGUOUS')
        self.divergence.argtypes = (
            [ctypes.c_int] * 3 + [double_array] * 8 + [ctypes.c_double] * 2 + [double_array]
        )
        self.divergence.restype = None
        self.calls = 0

    def calc(self, y, t, div=True):
        alpha = np.exp(-t)
        alpha_squared = alpha**2
        gamma = -np.expm1(-2 * t)
        self.calls += len(y)

        logweights = (alpha * y @ self.x.T - alpha_squared * self.half_norm) / gamma
        logweights += self.velocity_logweights
        weights = np.exp(logweights - logsumexp(logweights, axis=1)[:, None])
        mean_cross = (weights @ self.cross_flat).reshape(-1, self.d, 3)
        mean_residual = weights @ self.residual - np.einsum('nij,nj->ni', mean_cross, self.velocity)

        # The TSI coefficient is I minus Young et al.'s coefficient on Tweedie.
        # Combine the two signals algebraically before dividing to stay stable near t=0.
        inverse_eigenvalues = 1 / (alpha_squared + gamma * self.eigenvalues)
        inverse_shift = (self.eigenvectors * inverse_eigenvalues) @ self.eigenvectors.T
        score = (alpha * mean_residual - y @ self.fisher) @ inverse_shift
        if not div:
            return score

        mean_x = weights @ self.x
        trace = self.eigenvalues @ inverse_eigenvalues
        out = np.empty(len(y))
        arrays = (
            weights, self.x, self.residual, self.cross_curvature, self.velocity,
            mean_x, mean_residual, inverse_shift,
        )
        self.divergence(
            len(y), self.n, self.d, *(np.ascontiguousarray(z) for z in arrays),
            alpha_squared / gamma, trace, out,
        )
        return score, out
