"""Build append-ready manuscript statistics from completed Young-gate quake cells."""
import argparse
import csv
from collections import defaultdict

import numpy as np

from common import ROOT, read, write

METHOD = "conditional_young"
BASELINE = "conditional_lfgi"
NBOOT = 10_000
BOOT_SEED = 20261117
CORE = ("logdensity_RMSE", "forward_KL", "reverse_KL", "bridge_RMSE")
FIGURE_COLUMNS = ("target", "N", "method", "metric", "value", "low", "high", "groups")
TABLE_METRICS = (
    "logratio_SD", "mean_logq_p", "ELBO", "ESS", "bridge_repeat_SD", "logZ", *CORE,
)
ORIGIN_COLUMNS = tuple(
    f"origin_{moment}_{j}" for j in range(1, 6) for moment in ("mean", "sd")
)
REPEAT_COLUMNS = (
    "seed", "N", "method", "repeat", "status", "space", "logratio_SD", "mean_logq_p",
    "ELBO", "entropy_q", "forward_KL", "reverse_KL", "logdensity_RMSE",
    "bridge_logZ_error", "new_E", "new_G", "new_H", "logZ", "bridge_overlap",
    "ESS", "posterior_E_once", "required_G", "required_H", "roundtrip", "mean_chi2",
    *(f"origin_mean_{j}" for j in range(1, 6)),
    *(f"origin_sd_{j}" for j in range(1, 6)),
)


def csv_write(path, fields, rows):
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def cell_rows(cell, state, logz_ref, count, repeats):
    """Keep whole completed banks together and check the recorded density units."""
    records = state["records"]
    if sorted(r["repeat"] for r in records) != list(range(repeats)):
        raise ValueError("Completed cell does not contain exactly the planned repeats")
    rows = []
    for record in sorted(records, key=lambda r: r["repeat"]):
        if (record["posterior_count"], record["proposal_count"]) != count:
            raise ValueError("Completed cell does not use the planned posterior/proposal counts")
        result = record["bridge"]
        if not result["success"] or record.get("space", "original") != "original":
            raise ValueError("Completed cell lacks an original-coordinate bridge estimate")
        geometry = record["geometry"]
        shared = state["shared_cache_access"]
        row = dict(
            **cell, repeat=record["repeat"], status="COMPLETE", space="original",
            logratio_SD=record["logratio_SD"], mean_logq_p=record["mean_logq_p"],
            ELBO=record["ELBO"], entropy_q=record["entropy_q"],
            forward_KL=record["forward_KL"], reverse_KL=record["reverse_KL"],
            logdensity_RMSE=record["logdensity_RMSE"],
            bridge_logZ_error=record["bridge_logZ_error"],
            new_E=record["new_E"], new_G=record["new_G"], new_H=record["new_H"],
            logZ=result["logZ"], bridge_overlap=result["overlap"], ESS=result["IS_ESS"],
            posterior_E_once=state["posterior_E"] if record["repeat"] == 0 else 0,
            required_G=shared["G"], required_H=shared["H"],
            roundtrip=state.get("roundtrip"), mean_chi2=geometry["mean_chi2"],
        )
        for j, (mean, sd) in enumerate(zip(geometry["origin_mean"], geometry["origin_sd"]), 1):
            row[f"origin_mean_{j}"] = mean
            row[f"origin_sd_{j}"] = sd
        if not np.isclose(row["bridge_logZ_error"], row["logZ"] - logz_ref, rtol=0, atol=1e-10):
            raise ValueError("Cell evidence calibration differs from the frozen quadrature reference")
        if record.get("reverse_support_ok", True):
            if not np.isclose(row["reverse_KL"], logz_ref - row["ELBO"], rtol=0, atol=1e-10):
                raise ValueError("Cell reverse-KL calibration differs from the frozen quadrature reference")
        elif row["reverse_KL"] is not None or row["ELBO"] is not None:
            raise ValueError("Cell records a finite reverse KL or ELBO despite a support violation")
        if not np.isclose(record["importance_ESS_fraction"], row["ESS"] / count[1]):
            raise ValueError("Cell ESS fraction disagrees with raw batch ESS and draw count")
        if not np.isfinite([row[k] for k in (
            "logratio_SD", "mean_logq_p", "forward_KL", "logdensity_RMSE", "logZ",
            "bridge_logZ_error", "ESS", "bridge_overlap",
        )]).all():
            raise ValueError("Cell records a nonfinite held-out or bridge estimate")
        rows.append(row)
    return rows


def groups(rows):
    out = defaultdict(lambda: defaultdict(list))
    for row in rows:
        out[row["N"]][row["seed"]].append(row)
    return out


def group_values(by_seed, metric, proposal_count):
    by_seed = [by_seed[s] for s in sorted(by_seed)]
    if metric == "bridge_RMSE":
        return np.array([np.mean([r["bridge_logZ_error"] ** 2 for r in rows]) for rows in by_seed])
    if metric == "bridge_repeat_SD":
        return np.array([np.std([r["logZ"] for r in rows], ddof=1) for rows in by_seed
                         if len(rows) > 1])
    if metric == "bridge_bias":
        metric = "bridge_logZ_error"
    values = np.array([np.mean(np.asarray([r[metric] for r in rows], dtype=float))
                       for rows in by_seed])
    return values / proposal_count if metric == "ESS" else values


def bootstrap_indices(count):
    return np.random.default_rng(BOOT_SEED).integers(0, count, (NBOOT, count))


def interval(draws, count):
    if count < 2:
        return None, None, None
    low, high = np.quantile(draws, [0.025, 0.975])
    return float(low), float(high), float(np.std(draws, ddof=1))


def stats(rows, proposal_count):
    result = []
    for n, by_seed in sorted(groups(rows).items()):
        indices = bootstrap_indices(len(by_seed))
        for metric in (*TABLE_METRICS, "bridge_overlap", "bridge_bias", "mean_chi2", *ORIGIN_COLUMNS):
            values = group_values(by_seed, metric, proposal_count)
            if not len(values) or not np.isfinite(values).all():
                continue
            point = values.mean()
            draws = values[indices].mean(axis=1)
            if metric == "bridge_RMSE":
                point, draws = np.sqrt(point), np.sqrt(draws)
            low, high, se = interval(draws, len(by_seed))
            result.append(dict(
                target="quake", N=n, method=METHOD, metric=metric, value=float(point),
                low=low, high=high, groups=len(by_seed), se=se,
            ))
    return result


def paired_stats(rows, logz_ref, proposal_count):
    archive = ROOT / "data/archived_conditional_lfgi.csv"
    with archive.open(newline="") as f:
        baseline = {}
        for row in csv.DictReader(f):
            if row["method"] != BASELINE or row["status"] != "COMPLETE":
                continue
            key = (int(row["N"]), int(row["seed"]), int(row["repeat"]))
            if key in baseline:
                raise ValueError("Duplicate archived Conditional LFGI-GN batch")
            baseline[key] = {
                "logdensity_RMSE": float(row.get("logdensity_RMSE_reference") or row["logdensity_RMSE"]),
                "forward_KL": float(row.get("forward_KL_reference") or row["forward_KL"]),
                "reverse_KL": float(row.get("reverse_KL_reference") or row["reverse_KL"]),
                "bridge_logZ_error": float(row["logZ"]) - logz_ref,
                "ESS": float(row["ESS"]),
            }

    result = []
    for n, by_seed in sorted(groups(rows).items()):
        paired = {
            seed: [baseline[n, seed, r["repeat"]] for r in batches]
            for seed, batches in by_seed.items()
        }
        indices = bootstrap_indices(len(by_seed))
        for metric in (*CORE, "ESS"):
            a = group_values(paired, metric, proposal_count)
            b = group_values(by_seed, metric, proposal_count)
            if not np.isfinite(a).all() or not np.isfinite(b).all():
                continue
            transform = np.sqrt if metric == "bridge_RMSE" else np.asarray
            point = transform(a.mean()) - transform(b.mean())
            draws = transform(a[indices].mean(axis=1)) - transform(b[indices].mean(axis=1))
            low, high, se = interval(draws, len(by_seed))
            result.append(dict(
                N=n, baseline=BASELINE, comparator=METHOD, metric=metric,
                difference="baseline_minus_comparator", estimate=float(point), low=low,
                high=high, se=se, groups=len(by_seed),
                banks_favoring_baseline=int(np.count_nonzero(a > b if metric == "ESS" else a < b)),
            ))
    return result


def plot(out, summaries):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(7, 2.7), layout="constrained")
    for ax, metric, label in zip(
        axes, ("logdensity_RMSE", "bridge_RMSE"),
        ("Held-out log-density RMSE (nats)", r"Bridge RMSE of $\log\widehat{Z}$ (nats)"),
    ):
        curve = [r for r in summaries if r["metric"] == metric]
        n = [r["N"] for r in curve]
        values = [r["value"] for r in curve]
        ax.plot(n, values, "o-", color="#52529d", markersize=4, label="Young time-only gate")
        if all(r["low"] is not None for r in curve):
            ax.fill_between(n, [r["low"] for r in curve], [r["high"] for r in curve],
                            color="#52529d", alpha=.18, linewidth=0)
        ax.set(xscale="log", xlabel="Reference bank size", ylabel=label)
        if all(v > 0 for v in values) and all(r["low"] is None or r["low"] > 0 for r in curve):
            ax.set_yscale("log")
        ax.set_xticks(n, labels=[f"{i:,}" for i in n])
        ax.grid(alpha=.18)
    axes[0].legend(frameon=False, fontsize=8)
    fig.savefig(out / "young_density_evidence.pdf")
    fig.savefig(out / "young_density_evidence.png", dpi=300)
    plt.close(fig)


def report(label):
    config = read(ROOT / "configs/campaign.json")
    reference = read(ROOT / "data/reference.json")
    logz_ref = reference["logZ"]
    cells = [c for c in read(ROOT / "prepared/cells.json") if c["method"] == METHOD]
    count = (config["posterior_n"], config["proposal_n"])
    repeats = config["proposal_repeats"]
    if label == "pilot":
        cells = [c for c in cells if c["seed"] == 101 and c["N"] == 1024]
        count = (128, 128)
        repeats = 1

    rows, statuses = [], []
    for cell in cells:
        path = ROOT / "results" / label / f"seed{cell['seed']}" / f"N{cell['N']}" / METHOD / "status.json"
        if not path.exists():
            statuses.append(dict(**cell, status="MISSING"))
            continue
        state = read(path)
        status = dict(**cell, status=state["status"])
        if state["status"] == "COMPLETE":
            try:
                rows.extend(cell_rows(cell, state, logz_ref, count, repeats))
                status["batches_without_reverse_KL"] = sum(
                    not r.get("reverse_support_ok", True) for r in state["records"]
                )
                status["invalid_forward_draws"] = sum(
                    r["geometry"].get("invalid_forward_draws", 0) for r in state["records"]
                )
            except (KeyError, ValueError) as exc:
                status.update(status="INVALID", error=str(exc))
        elif "error" in state:
            status["error"] = state["error"]
        statuses.append(status)

    out = ROOT / "reports" / label
    out.mkdir(parents=True, exist_ok=True)
    complete = sum(r["status"] == "COMPLETE" for r in statuses)
    write(out / "status.json", dict(
        label=label, expected=len(cells), complete=complete, cells=statuses,
        failed=sum(r["status"] == "FAILED" for r in statuses),
        invalid=sum(r["status"] == "INVALID" for r in statuses),
        missing=sum(r["status"] == "MISSING" for r in statuses),
        reference_logZ=logz_ref, reference_accuracy_nats=reference.get("empirical_accuracy_budget_nats"),
    ))
    for filename in ("per_repeat.csv", "per_repeat_calibrated.csv"):
        csv_write(out / filename, REPEAT_COLUMNS, rows)

    summaries = stats(rows, count[1])
    write(out / "summary.json", summaries)
    curve_metrics = {*TABLE_METRICS, "bridge_overlap"}
    csv_write(out / "figure_statistics_calibrated.csv", FIGURE_COLUMNS, (
        {key: r[key] for key in FIGURE_COLUMNS} for r in summaries if r["metric"] in curve_metrics
    ))

    largest_bank = max(config["bank_sizes"])
    table_fields = ("method", "groups", "mean_chi2", "bridge_bias",
                    *(key for metric in TABLE_METRICS for key in (metric, metric + "_low", metric + "_high")),
                    *ORIGIN_COLUMNS)
    metrics = {r["metric"]: r for r in summaries if r["N"] == largest_bank}
    largest_rows = []
    if metrics:
        table_row = dict(method=METHOD, groups=metrics["logdensity_RMSE"]["groups"])
        for key in ("mean_chi2", "bridge_bias", *ORIGIN_COLUMNS):
            if key in metrics:
                table_row[key] = metrics[key]["value"]
        for metric in TABLE_METRICS:
            if metric in metrics:
                table_row.update({metric: metrics[metric]["value"],
                                  metric + "_low": metrics[metric]["low"],
                                  metric + "_high": metrics[metric]["high"]})
        largest_rows.append(table_row)
    csv_write(out / "largest_bank_summary_calibrated.csv", table_fields, largest_rows)
    csv_write(out / "table_statistics_calibrated.csv", (*FIGURE_COLUMNS, "se"), (
        r for r in summaries if r["metric"] in {*CORE, "bridge_bias", "ESS"}
    ))

    if label == "production":
        paired_columns = ("N", "baseline", "comparator", "metric", "difference", "estimate",
                          "low", "high", "se", "groups", "banks_favoring_baseline")
        csv_write(out / "paired_lfgi_differences.csv", paired_columns,
                  paired_stats(rows, logz_ref, count[1]) if rows else [])
    if summaries:
        plot(out, summaries)

    lines = [
        "# Young time-only gate for earthquake location", "",
        f"Completed bank selections {complete}/{len(cells)}.",
        f"The frozen quadrature log-evidence reference is {logz_ref:.12f} nats in the campaign's target units.",
        "Intervals and table standard errors resample whole bank selections, keeping the nested bridge batches together.",
        "Uncertainty is conditional on the archived chains and fixed held-out posterior evaluation set.", "",
        "| Bank size | Groups | Density RMSE | Forward KL | Reverse KL | Bridge RMSE | Importance ESS fraction |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for n in sorted(groups(rows)):
        current = {r["metric"]: r for r in summaries if r["N"] == n}
        estimates = [f'{current[m]["value"]:.5g}' if m in current else "unavailable"
                     for m in (*CORE, "ESS")]
        lines.append(f'| {n:,} | {current["logdensity_RMSE"]["groups"]} | ' + " | ".join(estimates) + " |")
    if any(s.get("batches_without_reverse_KL", 0) for s in statuses):
        lines.extend(["", "Some proposal draws leave target support. Affected reverse KL and ELBO summaries "
                      "are unavailable. Inspect the per-cell status and raw batch arrays for the affected draws."])
    lines.extend(["", "Output CSV files retain a method identifier for appending to the manuscript comparison.",
                  "The paired file uses Conditional LFGI-GN minus Young and matches bank seeds and repeat IDs.", ""])
    (out / "REPORT.md").write_text("\n".join(lines))
    print(f"Reported {complete}/{len(cells)} completed {METHOD} cells to {out}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--label", default="production", choices=("production", "pilot"))
    report(parser.parse_args().label)
