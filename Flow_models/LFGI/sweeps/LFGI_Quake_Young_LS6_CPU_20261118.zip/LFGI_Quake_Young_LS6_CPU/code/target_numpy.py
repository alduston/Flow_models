"""NumPy port of the archived analytic earthquake map; exact first derivatives."""
import json,numpy as np
from pathlib import Path
class Quake:
 d=23
 def __init__(self,spec):
  self.spec=spec;p=spec['prior'];self.prior=p;self.stations=np.array(spec['stations']);self.pe=np.array([p[0] for p in spec['picks']]);self.ps=np.array([p[1] for p in spec['picks']]);self.phase=np.array([p[2]=='S' for p in spec['picks']]);self.sd=np.array([spec['pick_sd'][p[2]] for p in spec['picks']]);tr=spec['truth'];ev=np.column_stack([(np.array(tr['events'])[:,0]-p['epicentre_mean'][0])/p['epicentre_sd'],(np.array(tr['events'])[:,1]-p['epicentre_mean'][1])/p['epicentre_sd'],(np.array(tr['events'])[:,2]-p['depth_mean'])/p['depth_sd'],np.array(tr['t0'])/p['origin_time_sd']]);self.true=np.r_[ev.ravel(),np.log(tr['v0']/p['v0_median'])/p['log_v0_sd'],np.log(tr['gradient']/p['gradient_median'])/p['log_gradient_sd'],np.log((tr['kappa']-1)/(p['kappa_median']-1))/p['log_kappa_minus_one_sd']];self.y=np.asarray(spec['observations'],dtype=float) if 'observations' in spec else self.forward(self.true[None])[0]+self.sd*np.random.default_rng(71).normal(size=len(self.sd))
 def physical(self,u):
  u=np.atleast_2d(u);p=self.prior;e=u[:,:20].reshape(-1,5,4);ev=e[:,:,:3]*np.array([p['epicentre_sd'],p['epicentre_sd'],p['depth_sd']])+np.array([*p['epicentre_mean'],p['depth_mean']]);t0=e[:,:,3]*p['origin_time_sd'];v0=p['v0_median']*np.exp(p['log_v0_sd']*u[:,20]);g=p['gradient_median']*np.exp(p['log_gradient_sd']*u[:,21]);k=1+(p['kappa_median']-1)*np.exp(p['log_kappa_minus_one_sd']*u[:,22]);return ev,t0,v0,g,k
 def parts(self,u,jac=False):
  u=np.atleast_2d(u);ev,t0,v0,g,k=self.physical(u);src=ev[:,self.pe];rec=self.stations[self.ps];dx=src-rec;R2=np.sum(dx*dx,-1);z=src[:,:,2];zr=rec[:,2];vs=v0[:,None]+g[:,None]*z;vr=v0[:,None]+g[:,None]*zr
  with np.errstate(invalid='ignore',divide='ignore',over='ignore'):
   a=g[:,None]**2*R2/(2*vs*vr);root=np.sqrt(a*(a+2));tp=np.log1p(a+root)/g[:,None];phase=np.where(self.phase,k[:,None],1);pred=t0[:,self.pe]+phase*tp
   if not jac:return pred
   p=self.prior;ds=np.zeros((len(u),len(self.sd),23));idx=np.arange(len(self.sd));m=a/(g[:,None]*root);loc=2*dx/R2[:,:,None];loc[:,:,2]-=g[:,None]/vs
   for coord,scale in enumerate([p['epicentre_sd'],p['epicentre_sd'],p['depth_sd']]):ds[:,idx,4*self.pe+coord]=phase*m*loc[:,:,coord]*scale
   ds[:,idx,4*self.pe+3]=p['origin_time_sd'];ds[:,:,20]=phase*m*(-v0[:,None]*p['log_v0_sd']*(1/vs+1/vr));ds[:,:,21]=phase*p['log_gradient_sd']*(m*(2-g[:,None]*z/vs-g[:,None]*zr/vr)-tp);ds[:,:,22]=self.phase*(k[:,None]-1)*p['log_kappa_minus_one_sd']*tp
  return pred,ds
 def forward(self,u):return self.parts(u)
 def values(self,u):
  pred,J=self.parts(u,True);r=(pred-self.y)/self.sd;J=J/self.sd[None,:,None];E=.5*np.sum(u*u,-1)+.5*np.sum(r*r,-1);s=-u-np.einsum('nki,nk->ni',J,r);P=np.eye(self.d)+np.einsum('nki,nkj->nij',J,J);return E,s,P
 def logp(self,u):
  pred=self.parts(u);v=-.5*np.sum(u*u,-1)-.5*np.sum(((pred-self.y)/self.sd)**2,-1);return np.where(np.isfinite(v),v,-np.inf)
 def score(self,u):return self.values(u)[1]
 def bank(self,u):return self.values(u)[1:]
