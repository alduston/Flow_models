"""Appendix displays from one frozen Young-gate fit and the paper's saved cubature."""

import argparse
import fcntl
import hashlib
import json
import os
import pickle

import numpy as np

from campaign import paths, target
from common import ROOT, read, rng, save, sha, source_sha, write

METHOD = "conditional_young"
METHOD_LABEL = "Young time-only matrix"
EVENTS = (3, 5)
PAPER_DRAWS = 8192
PAPER_CUBATURE = 4096
DISPLAY_STREAM = 260397


def project(locations, axes, event):
    offset = (locations[:, event - 1, :2] - axes[event - 1]["mean"]) @ axes[event - 1]["direction"]
    return np.column_stack((offset, locations[:, event - 1, 2]))


def location_histogram(points, edges, weights):
    counts = np.histogram2d(points[:, 0], points[:, 1], bins=edges, weights=weights)[0]
    mass = counts / len(points)
    area = np.diff(edges[0])[:, None] * np.diff(edges[1])[None, :]
    return mass / area, mass


def inside_window(points, edges):
    return np.all(
        (points >= [edge[0] for edge in edges]) & (points <= [edge[-1] for edge in edges]),
        axis=1,
    )


def save_locations(out, stem, event, points, edges, weights=None):
    hist, mass = location_histogram(points, edges, weights)
    inside = inside_window(points, edges)
    if weights is None:
        outside_mass = float(np.mean(~inside))
    else:
        outside_mass = float(weights[~inside].sum() / len(points))
    save(
        out / f"{stem}_E{event}.npz",
        hist=hist,
        bins0=edges[0],
        bins1=edges[1],
        mass=mass,
        count=np.array(len(points)),
        window_mass=np.array(mass.sum()),
        outside_mass=np.array(outside_mass),
    )
    return mass


def origin_residuals(quake, x):
    prediction = quake.forward(x)
    origin = quake.physical(x)[1]
    residuals = np.empty_like(origin)
    precision = 1 / quake.sd**2
    for event in range(origin.shape[1]):
        picks = quake.pe == event
        var = 1 / (1 / quake.prior["origin_time_sd"]**2 + precision[picks].sum())
        travel = prediction[:, picks] - origin[:, event, None]
        mean = var * ((quake.y[picks] - travel) * precision[picks]).sum(axis=1)
        residuals[:, event] = (origin[:, event] - mean) / np.sqrt(var)
    return residuals


def save_origins(out, label, residuals):
    bins = np.linspace(-5, 5, 61)
    densities = np.column_stack([
        np.histogram(event, bins=bins)[0] / (len(event) * np.diff(bins))
        for event in residuals.T
    ])
    finite = np.isfinite(residuals)
    outside = finite & ((residuals < bins[0]) | (residuals > bins[-1]))
    info = {
        "count": len(residuals),
        "outside_fraction": outside.mean(axis=0),
        "invalid_fraction": (~finite).mean(axis=0),
    }
    save(
        out / f"origin_residuals_{label}.npz",
        residuals=residuals,
        bins=bins,
        density=densities,
        **info,
    )
    return densities, bins, info


def save_figure(fig, base):
    for suffix in ("pdf", "png"):
        path = base.with_suffix(f".{suffix}")
        tmp = path.with_name(f"{path.stem}.tmp.{os.getpid()}.{suffix}")
        fig.savefig(tmp, dpi=300)
        os.replace(tmp, path)


def location_figure(out, name, histograms, edges, ylabel, n):
    from matplotlib import pyplot as plt
    from matplotlib.colors import LogNorm
    from matplotlib.ticker import MaxNLocator

    fig, axes = plt.subplots(2, 2, figsize=(6.9, 5), layout="constrained")
    cmap = plt.get_cmap("magma_r").copy()
    cmap.set_bad("white")
    norm = LogNorm(vmin=1e-4, vmax=2e-2)
    for row, event in enumerate(EVENTS):
        for column, (label, hist) in enumerate(histograms.items()):
            ax = axes[row, column]
            h = hist[event].T
            im = ax.pcolormesh(
                *edges[event], np.ma.masked_where(h == 0, h), cmap=cmap, norm=norm,
                shading="auto", rasterized=True,
            )
            ax.invert_yaxis()
            ax.xaxis.set_major_locator(MaxNLocator(3))
            ax.yaxis.set_major_locator(MaxNLocator(3))
            if row == 0:
                ax.set_title(label)
            if row == len(EVENTS) - 1:
                ax.set_xlabel("Offset (km)")
            if column == 0:
                ax.set_ylabel(f"E{event} depth (km)")
    fig.colorbar(im, ax=axes, pad=0.02, ticks=[1e-4, 1e-3, 1e-2], label=ylabel)
    fig.suptitle(f"Bank size {n:,}")
    save_figure(fig, out / name)
    plt.close(fig)


def origin_figure(out, young, heldout, n):
    from matplotlib import pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.0), layout="constrained")
    grid = np.linspace(-5, 5, 400)
    for ax, event in zip(axes, EVENTS):
        col = event - 1
        for label, (density, bins, _), color in (
            ("NUTS held-out", heldout, "#222222"),
            (METHOD_LABEL, young, "#2e6f97"),
        ):
            ax.stairs(density[:, col], bins, color=color, label=label, lw=1.25)
        ax.plot(
            grid, np.exp(-grid**2 / 2) / np.sqrt(2 * np.pi), "k--", lw=1,
            label=r"Exact $\mathcal{N}(0,1)$",
        )
        ax.set(title=f"Event E{event}", xlabel="Standardized origin-time residual", xlim=(-5, 5))
        ax.set_xticks([-4, -2, 0, 2, 4])
        outside = young[2]["outside_fraction"][col]
        invalid = young[2]["invalid_fraction"][col]
        ax.text(.98, .96, f"Outside window {outside:.1%}\nInvalid {invalid:.1%}",
                transform=ax.transAxes, ha="right", va="top", fontsize=8)
        ax.grid(alpha=.12)
    axes[0].set_ylabel("Probability density")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncol=3, frameon=False)
    fig.suptitle(f"Bank size {n:,}")
    save_figure(fig, out / "origin_time_residuals")
    plt.close(fig)


def load_bound(path, binding, count, keys):
    with np.load(path) as stored:
        if str(stored["binding"]) != binding:
            raise ValueError(f"Display array identity mismatch in {path}")
        arrays = tuple(stored[key] for key in keys)
    if any(len(array) != count or not np.isfinite(array).all() for array in arrays):
        raise ValueError(f"Invalid display arrays in {path}")
    return arrays


def run(label="production", seed=101, n=1024, draws=PAPER_DRAWS, cubature=PAPER_CUBATURE):
    """Evaluate the paper's appendix rows with no new fits or cubature proposals."""
    if seed != 101 or n not in (256, 1024):
        raise ValueError("Archived appendix fixtures cover seed 101 at bank sizes 256 and 1024")
    if not 1 <= draws <= PAPER_DRAWS or not 2 <= cubature <= PAPER_CUBATURE:
        raise ValueError(f"Use 1–{PAPER_DRAWS} display draws and 2–{PAPER_CUBATURE} cubature draws")

    import matplotlib
    matplotlib.use("Agg")

    fit = paths(dict(seed=seed, N=n, method=METHOD), label)
    fit_status = read(fit / "status.json")
    meta = read(fit / "fit.json")
    model_sha = sha(fit / "model.pkl")
    if (
        fit_status["status"] != "COMPLETE" or fit_status["binding"] != meta["binding"]
        or meta["pickle_sha256"] != model_sha
    ):
        raise ValueError(f"Expected a verified completed Young-gate fit at {fit}")

    fixture_dir = ROOT / "data" / "high_resolution" / f"seed{seed}_N{n}_draws8192_cubature4096"
    proposal_file = fixture_dir / "shared_integration_proposal.npz"
    window_file = fixture_dir / "window_bins.npz"
    out = ROOT / "reports" / label / "high_resolution" / f"seed{seed}_N{n}_draws{draws}_cubature{cubature}"
    identity = {
        "seed": seed, "N": n, "draws": draws, "cubature": cubature, "method": METHOD,
        "fit_binding": meta["binding"], "model_sha": model_sha,
        "cubature_proposal_sha": sha(proposal_file), "window_bins_sha": sha(window_file),
        "projection_axes_sha": sha(ROOT / "data" / "projection_axes.json"),
        "prepared_posterior_sha": sha(ROOT / "prepared" / "posterior.npz"),
        "source_sha256": source_sha(), "display_stream": DISPLAY_STREAM,
    }
    binding = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
    out.mkdir(parents=True, exist_ok=True)
    status = out / "status.json"
    with (out / "LOCK").open("w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if status.exists() and read(status)["binding"] != binding:
            raise ValueError(f"Display identity mismatch in {out}")
        write(status, dict(status="RUNNING", binding=binding, **identity))
        try:
            diagnostics = make_displays(fit, out, identity, binding, proposal_file, window_file)
        except Exception as error:
            write(status, dict(status="FAILED", binding=binding, error=str(error), **identity))
            raise
        write(status, dict(status="COMPLETE", binding=binding, **identity, **diagnostics))
    return out


def make_displays(fit, out, identity, binding, proposal_file, window_file):
    draws, cubature = identity["draws"], identity["cubature"]
    seed, n = identity["seed"], identity["N"]

    with (fit / "model.pkl").open("rb") as model_file:
        model = pickle.load(model_file)
    if not model.conditional or not model.config.get("homogeneous_gate"):
        raise ValueError("The appendix job requires a conditional fit with the Young gate")
    model.cache = out / "checkpoints"
    model.identity = binding
    draw_file = out / f"draws_{METHOD}.npz"
    if draw_file.exists():
        x, logq = load_bound(draw_file, binding, draws, ("x", "logq"))
    else:
        display_rng = rng(seed, n, DISPLAY_STREAM)
        x, logq = model.sample_logq(draws, display_rng, "actual")
        if not np.isfinite(x).all() or not np.isfinite(logq).all():
            raise ArithmeticError("Nonfinite state or log density in display draws")
        save(draw_file, x=x, logq=logq, model_sha=np.array(identity["model_sha"]), binding=np.array(binding))

    integration_file = out / f"cubature_{METHOD}.npz"
    if integration_file.exists():
        probe, logq_probe, logr = load_bound(integration_file, binding, cubature, ("x", "logq", "logr"))
    else:
        with np.load(proposal_file) as data:
            if data["x"].shape != (PAPER_CUBATURE, 23) or data["logq"].shape != (PAPER_CUBATURE,):
                raise ValueError(f"Unexpected archive dimensions in {proposal_file}")
            probe, logr = data["x"][:cubature], data["logq"][:cubature]
        logq_probe = model.logq(probe, tag="cubature")
        if not np.isfinite(probe).all() or not np.isfinite(logq_probe).all() or not np.isfinite(logr).all():
            raise ArithmeticError("Nonfinite point or density in the shared cubature evaluations")
        save(
            integration_file, x=probe, logq=logq_probe, logr=logr, log_weights=logq_probe - logr,
            model_sha=np.array(identity["model_sha"]), binding=np.array(binding),
        )

    with np.errstate(over="ignore"):
        weights = np.exp(logq_probe - logr)
    if not np.isfinite(weights).all() or weights.max() == 0:
        raise ArithmeticError("Invalid q/r weights in the shared cubature")
    scaled = weights / weights.max()
    mass_info = {
        "proposal": "archived conditional_gmm_bic",
        "count": len(weights),
        "mass_estimate": float(weights.mean()),
        "mass_MCSE": float(weights.std(ddof=1) / np.sqrt(len(weights))),
        "cubature_ESS": float(scaled.sum()**2 / (scaled**2).sum()),
    }
    write(out / "implicit_density_integration.json", {METHOD: mass_info})

    quake = target()
    axes = read(ROOT / "data" / "projection_axes.json")["axes"]
    with np.load(window_file) as data:
        edges = {event: (data[f"bins0_E{event}"], data[f"bins1_E{event}"]) for event in EVENTS}
    if any(edge.shape != (41,) or np.any(np.diff(edge) <= 0) for pair in edges.values() for edge in pair):
        raise ValueError("Expected the paper's strictly increasing 40-by-40 location bins")
    with np.load(ROOT / "data" / "inputs.npz") as archived:
        reference = quake.physical(archived["reference"][4000:])[0]
    with np.load(ROOT / "prepared" / "posterior.npz") as posterior:
        heldout = posterior["x"]
    locations = quake.physical(x)[0]
    probe_locations = quake.physical(probe)[0]
    ref_mass, actual_mass, implicit_mass = {}, {}, {}
    for event in EVENTS:
        ref_mass[event] = save_locations(
            out, "actual_particle_histograms_NUTS reference", event, project(reference, axes, event), edges[event],
        )
        actual_mass[event] = save_locations(
            out, f"actual_particle_histograms_{METHOD}", event, project(locations, axes, event), edges[event],
        )
        implicit_mass[event] = save_locations(
            out, f"implicit_density_histograms_{METHOD}", event,
            project(probe_locations, axes, event), edges[event], weights,
        )
    location_figure(
        out, "actual_particle_histograms", {"Archived NUTS": ref_mass, METHOD_LABEL: actual_mass},
        edges, "Probability per bin", n,
    )
    location_figure(
        out, "implicit_density_histograms",
        {"Archived NUTS": ref_mass, f"{METHOD_LABEL}\nCubature": implicit_mass}, edges,
        "Probability per bin", n,
    )
    young = save_origins(out, METHOD, origin_residuals(quake, x))
    comparison = save_origins(out, "heldout", origin_residuals(quake, heldout))
    origin_figure(out, young, comparison, n)
    return {
        "cubature_diagnostics": mass_info,
        "actual_window_mass": {f"E{event}": float(mass.sum()) for event, mass in actual_mass.items()},
        "implicit_window_mass": {f"E{event}": float(mass.sum()) for event, mass in implicit_mass.items()},
        "origin_residual_diagnostics": {METHOD: young[2], "heldout": comparison[2]},
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", default="production")
    parser.add_argument("--seed", type=int, default=101)
    parser.add_argument("--N", type=int, default=1024)
    parser.add_argument("--draws", type=int, default=PAPER_DRAWS)
    parser.add_argument("--cubature", type=int, default=PAPER_CUBATURE)
    args = parser.parse_args()
    print(run(args.label, args.seed, args.N, args.draws, args.cubature))
