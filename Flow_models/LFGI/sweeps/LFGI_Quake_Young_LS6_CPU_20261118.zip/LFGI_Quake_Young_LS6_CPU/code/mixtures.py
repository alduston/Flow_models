import numpy as np
from scipy.special import logsumexp,gammaln
from models import GMM,fit_gmm,StructuredGMM

def select_gmm(x,ks,seed):
 candidates=[]
 for k in ks:
  if len(x)<max(30*k,2*x.shape[1]):continue
  m=fit_gmm(x,k,seed);bic=-2*m.logq(x).sum()+(k*(x.shape[1]+x.shape[1]*(x.shape[1]+1)/2)+k-1)*np.log(len(x));candidates.append((float(bic),m,k))
 best=min(candidates,key=lambda t:t[0]);return best[1],dict(K=best[2],BIC=[{'K':k,'BIC':v} for v,m,k in candidates])
class TMixture:
 def __init__(self,w,m,c,nu):
  self.w=w;self.m=m;self.c=c;self.nu=nu;self.d=m.shape[1];self.P=np.linalg.inv(c);self.L=np.linalg.cholesky(c)
 def components(self,x):
  dx=x[:,None]-self.m;delta=np.einsum('nki,kij,nkj->nk',dx,self.P,dx);n=self.nu;d=self.d
  return np.log(self.w)+gammaln((n+d)/2)-gammaln(n/2)-d/2*np.log(n*np.pi)-.5*np.linalg.slogdet(self.c)[1]-(n+d)/2*np.log1p(delta/n)
 def logq(self,x):return logsumexp(self.components(x),1)
 def conditional(self,v):
  ne=4;nv=3;n=self.nu;cv=self.c[:,ne:,ne:];pv=np.linalg.inv(cv);reg=self.c[:,:ne,ne:]@pv;cc=self.c[:,:ne,:ne]-reg@self.c[:,ne:,:ne];dv=v[:,None]-self.m[None,:,ne:];delta=np.einsum('nki,kij,nkj->nk',dv,pv,dv);mu=self.m[None,:,:ne]+np.einsum('kij,nkj->nki',reg,dv);lw=TMixture(self.w,self.m[:,ne:],cv,n).components(v);lw-=logsumexp(lw,1)[:,None];return lw,mu,cc,(n+delta)/(n+nv)
 def cond_logq(self,e,v):
  lw,mu,c,factor=self.conditional(v);dx=e[:,None]-mu;delta=np.einsum('nki,kij,nkj->nk',dx,np.linalg.inv(c),dx)/factor;n=self.nu+3;return logsumexp(lw+gammaln((n+4)/2)-gammaln(n/2)-2*np.log(n*np.pi)-.5*np.linalg.slogdet(c)[1]-2*np.log(factor)-(n+4)/2*np.log1p(delta/n),1)
 def cond_sample(self,v,rng):
  lw,mu,c,factor=self.conditional(v);u=rng.random(len(v));ids=np.minimum((u[:,None]>np.cumsum(np.exp(lw),1)).sum(1),len(self.w)-1);noise=rng.normal(size=(len(v),4))/np.sqrt(rng.chisquare(self.nu+3,len(v))[:,None]/(self.nu+3));return mu[np.arange(len(v)),ids]+np.sqrt(factor[np.arange(len(v)),ids,None])*np.einsum('nij,nj->ni',np.linalg.cholesky(c)[ids],noise)
def fit_t(x,k,nu,seed,max_iter=150):
 mean=x.mean(0);scale=np.maximum(x.std(0),1e-4);z=(x-mean)/scale;g=fit_gmm(z,k,seed);w=g.w.copy();m=g.m.copy();c=g.c.copy();previous=-np.inf
 for it in range(max_iter):
  tm=TMixture(w,m,c,nu);ll=tm.components(z);total=logsumexp(ll,1);resp=np.exp(ll-total[:,None]);dx=z[:,None]-m;delta=np.einsum('nki,kij,nkj->nk',dx,np.linalg.inv(c),dx);lam=(nu+z.shape[1])/(nu+delta);rw=resp*lam;mass=resp.sum(0)+1e-12;w=mass/mass.sum();m=(rw.T@z)/(rw.sum(0)[:,None]+1e-12);dx=z[:,None]-m;c=np.einsum('nk,nki,nkj->kij',rw,dx,dx)/mass[:,None,None]+1e-5*np.eye(z.shape[1]);score=float(total.sum())
  if it>4 and abs(score-previous)<1e-5*(1+abs(previous)):break
  previous=score
 return TMixture(w,m*scale+mean,c*scale[None,:,None]*scale[None,None,:],nu)
class ConditionalMixtures:
 def __init__(self,x,velocity,kind,ks,seed):
  self.velocity=velocity;self.blocks=[];self.info=[]
  for j in range(5):
   xx=x[:,np.r_[4*j:4*j+4,20:23]]
   if kind=='gaussian':m=fit_gmm(xx,1,seed+j);inf={'K':1}
   else:
    m,inf=select_gmm(xx,ks,seed+j)
    if kind=='student':
     allfits=[(inf['BIC'][i]['BIC'],None,k) for i,k in enumerate([a['K'] for a in inf['BIC']])];candidates=[(float(-2*m.logq(xx).sum()+(36*len(m.w)-1)*np.log(len(xx))),m)]
     for k in ks:
      if len(xx)<30*k:continue
      for nu in [4,8,16]:
       t=fit_t(xx,k,nu,seed+j);bic=-2*t.logq(xx).sum()+(36*k)*np.log(len(xx));candidates.append((float(bic),t))
     score,m=min(candidates,key=lambda z:z[0]);inf={'K':len(m.w),'nu':getattr(m,'nu','infinity'),'BIC':score,'candidate_count':len(candidates)}
   self.blocks.append(m);self.info.append(inf)
 def logq(self,x):
  v=x[:,20:];out=self.velocity.logq(v)
  for j,m in enumerate(self.blocks):
   e=x[:,4*j:4*j+4]
   if isinstance(m,TMixture):out+=m.cond_logq(e,v)
   else:
    lw,mu,c=m.conditional(v);dx=e[:,None]-mu;out+=logsumexp(lw-2*np.log(2*np.pi)-.5*np.linalg.slogdet(c)[1]-.5*np.einsum('nki,kij,nkj->nk',dx,np.linalg.inv(c),dx),1)
  return out
 def sample(self,n,rng):
  v=self.velocity.sample(n,rng);x=np.zeros((n,23));x[:,20:]=v
  for j,m in enumerate(self.blocks):
   if isinstance(m,TMixture):e=m.cond_sample(v,rng)
   else:
    lw,mu,c=m.conditional(v);ids=np.minimum((rng.random(n)[:,None]>np.cumsum(np.exp(lw),1)).sum(1),len(m.w)-1);e=mu[np.arange(n),ids]+np.einsum('nij,nj->ni',np.linalg.cholesky(c)[ids],rng.normal(size=(n,4)))
   x[:,4*j:4*j+4]=e
  return x
 def affine(self):
  # Exactly the structured Gaussian model, used by Warp-III whitening.
  vm=self.velocity;mv=vm.w@vm.m;dv=vm.m-mv;cv=np.einsum('k,kij->ij',vm.w,vm.c)+np.einsum('k,ki,kj->ij',vm.w,dv,dv);mean=np.zeros(23);mean[20:]=mv;cov=np.zeros((23,23));cov[20:,20:]=cv;regs=[]
  for j,m in enumerate(self.blocks):
   P=np.linalg.inv(m.c[0,4:,4:]);A=m.c[0,:4,4:]@P;cc=m.c[0,:4,:4]-A@m.c[0,4:,:4];mean[4*j:4*j+4]=m.m[0,:4]+A@(mv-m.m[0,4:]);regs.append(A);cov[4*j:4*j+4,4*j:4*j+4]=cc
  for j,A in enumerate(regs):
   sj=slice(4*j,4*j+4);cov[sj,20:]=A@cv;cov[20:,sj]=cv@A.T
   for k,B in enumerate(regs):cov[sj,4*k:4*k+4]+=A@cv@B.T
  return mean,np.linalg.cholesky(cov+np.eye(23)*1e-10)
