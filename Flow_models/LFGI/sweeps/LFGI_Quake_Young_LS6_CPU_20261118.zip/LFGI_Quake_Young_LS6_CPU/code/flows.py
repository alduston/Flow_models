import ctypes,hashlib,os
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from pathlib import Path
from scipy.integrate import solve_ivp
from scipy.special import logsumexp
from common import ROOT,save,arrays_sha,source_sha
from models import ConditionalBank
from homogeneous import HomogeneousField
class Field:
 def __init__(self,bank,v=None,j=None):
  self.calls=0
  if j is None:
   self.x=bank.x;self.S=bank.s;self.H=bank.P;self.C=np.zeros((len(self.x),self.x.shape[1],3));self.vel=None
  else:self.x,self.S,self.H,self.C=bank.event[j];self.vel=np.ascontiguousarray(v)
  self.n,self.d=self.x.shape;assert 1<=self.d<=32;self.lw=None if j is None else bank.logweights(v);self.norm=(self.x*self.x).sum(1);self.Hflat=np.ascontiguousarray(self.H.reshape(self.n,-1));self.Cflat=np.ascontiguousarray(self.C.reshape(self.n,-1));self.lib=ctypes.CDLL(str(ROOT/'code/cond_div.so'));self.fun=self.lib.cond_div;pt=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS');self.fun.argtypes=[ctypes.c_int]*3+[pt]*11+[ctypes.c_double]*2+[pt];self.fun.restype=None
 def calc(self,y,t,div=True):
  a=np.exp(-t);g=-np.expm1(-2*t);self.calls+=len(y);lw=(a*y@self.x.T-a*a/2*self.norm)/g
  if self.lw is not None:lw+=self.lw
  w=np.exp(lw-logsumexp(lw,1)[:,None]);mu=w@self.x;ms=w@self.S;vel=np.zeros((len(y),3)) if self.vel is None else self.vel
  if self.vel is not None:ms-=np.einsum('nij,nj->ni',(w@self.Cflat).reshape(-1,self.d,3),vel)
  H=(w@self.Hflat).reshape(-1,self.d,self.d);Ai=np.linalg.inv(a*a*np.eye(self.d)+g*H);f=np.einsum('nij,nj->ni',Ai,a*ms+np.einsum('nij,nj->ni',H,a*mu-y))
  if not div:return f
  u=a*((a*mu-y)/g-f);out=np.empty(len(y));args=[np.ascontiguousarray(z) for z in [w,self.x,self.S,self.H,self.C,vel,mu,ms,H,Ai,u]];self.fun(len(y),self.n,self.d,*args,a,g,out);return f,out

def integrate(bank,x,v,j,backward,config,cache,identity):
 d=x.shape[1];chunk=config['chunk'];tau=config['tau'];T=config['T']
 def one(first):
  xx=x[first:first+chunk];vv=None if v is None else v[first:first+chunk];key=hashlib.sha256((identity+str((j,backward,config))+arrays_sha(xx,*([] if vv is None else [vv]))).encode()).hexdigest();p=Path(cache)/('chunk%06d.npz'%first);n=len(xx);y=xx.copy();L=np.zeros(n);start=0;cc=0
  if p.exists():
   z=np.load(p);assert str(z['binding'])==key,'checkpoint identity mismatch';y=z['y'];L=z['L'];start=int(z['step']);cc=int(z['calls'])
  f=HomogeneousField(bank,vv,j) if config.get('homogeneous_gate') else Field(bank,vv,j);ts=np.linspace(np.log(T if backward else tau),np.log(tau if backward else T),17)
  for step in range(start,16):
   def rhs(u,state):
    yy=state[:n*d].reshape(n,d);t=np.exp(u);s,dv=f.calc(yy,t);return np.r_[t*(-yy-s).ravel(),t*(-d-dv)]
   z=solve_ivp(rhs,ts[step:step+2],np.r_[y.ravel(),L],method='DOP853',rtol=config['rtol'],atol=config['atol'])
   if not z.success:raise ArithmeticError(z.message)
   y=z.y[:n*d,-1].reshape(n,d);L=z.y[n*d:,-1]
   if not np.isfinite(y).all() or not np.isfinite(L).all() or np.abs(y).max()>1e8:raise ArithmeticError('nonfinite/escaped flow')
   save(p,y=y,L=L,step=step+1,calls=cc+f.calls,binding=np.array(key))
  return y,L,cc+f.calls
 starts=list(range(0,len(x),chunk));workers=min(int(os.getenv('QUAKE_CHUNK_WORKERS','1')),len(starts))
 if workers<1:raise ValueError('QUAKE_CHUNK_WORKERS must be positive')
 if workers==1:out=[one(first) for first in starts]
 else:
  with ThreadPoolExecutor(max_workers=workers) as pool:out=list(pool.map(one,starts))
 return np.concatenate([a[0] for a in out]),np.concatenate([a[1] for a in out]),sum(a[2] for a in out)

class PFModel:
 def __init__(self,bank,conditional,config,cache,identity):self.bank=bank;self.conditional=conditional;self.config=config;self.cache=Path(cache);self.identity=identity;self.calls=0
 def logq(self,x,tag='posterior'):
  if not self.conditional:
   z,L,cc=integrate(self.bank,x,None,None,False,self.config,self.cache/tag,self.identity);self.calls+=cc;return -.5*(z*z).sum(1)-23/2*np.log(2*np.pi)+L
  v=x[:,20:];out=self.bank.velocity.logq(v)
  for j in range(5):
   z,L,cc=integrate(self.bank,x[:,4*j:4*j+4],v,j,False,self.config,self.cache/tag/str(j),self.identity);self.calls+=cc;out+=-.5*(z*z).sum(1)-2*np.log(2*np.pi)+L
  return out
 def sample_logq(self,n,rng,tag):
  if not self.conditional:
   z=rng.normal(size=(n,23));q,L,cc=integrate(self.bank,z,None,None,True,self.config,self.cache/tag,self.identity);self.calls+=cc;return q,-.5*(z*z).sum(1)-23/2*np.log(2*np.pi)-L
  v=self.bank.velocity.sample(n,rng);q=np.zeros((n,23));q[:,20:]=v;out=self.bank.velocity.logq(v)
  for j in range(5):
   z=rng.normal(size=(n,4));e,L,cc=integrate(self.bank,z,v,j,True,self.config,self.cache/tag/str(j),self.identity);self.calls+=cc;q[:,4*j:4*j+4]=e;out+=-.5*(z*z).sum(1)-2*np.log(2*np.pi)-L
  return q,out
