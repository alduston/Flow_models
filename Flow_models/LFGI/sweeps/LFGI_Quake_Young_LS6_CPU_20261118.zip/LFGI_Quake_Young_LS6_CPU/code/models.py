"""Normalized conditional models, with event/velocity partition fixed by the likelihood."""
import numpy as np
from scipy.special import logsumexp
from sklearn.mixture import GaussianMixture
LOG2PI=np.log(2*np.pi)

def fit_gmm(x,k,seed=84000):
 scale=np.std(x,axis=0);scale=np.maximum(scale,1e-4);mean=x.mean(0);z=(x-mean)/scale
 g=GaussianMixture(k,covariance_type='full',reg_covar=1e-5,n_init=3,max_iter=500,random_state=seed).fit(z)
 return GMM(g.weights_,g.means_*scale+mean,g.covariances_*scale[None,:,None]*scale[None,None,:])
class GMM:
 def __init__(self,w,m,c):
  self.w=w;self.m=m;self.c=c;self.L=np.linalg.cholesky(c);self.P=np.linalg.inv(c);self.d=m.shape[1]
  self.const=np.log(w)-np.log(np.diagonal(self.L,axis1=-2,axis2=-1)).sum(-1)-self.d/2*LOG2PI
 def components(self,x):
  dx=x[:,None,:]-self.m;return self.const-.5*np.einsum('nki,kij,nkj->nk',dx,self.P,dx)
 def logq(self,x):return logsumexp(self.components(x),axis=1)
 def sample(self,n,rng):
  k=rng.choice(len(self.w),n,p=self.w);return self.m[k]+np.einsum('nij,nj->ni',self.L[k],rng.normal(size=(n,self.d)))
 def conditional(self,v,ne=4):
  cv=self.c[:,ne:,ne:];pv=np.linalg.inv(cv);cross=self.c[:,:ne,ne:];reg=cross@pv;cc=self.c[:,:ne,:ne]-reg@self.c[:,ne:,:ne]
  dv=v[:,None,:]-self.m[None,:,ne:];mu=self.m[None,:,:ne]+np.einsum('kij,nkj->nki',reg,dv)
  vv=GMM(self.w,self.m[:,ne:],cv);lw=vv.components(v);lw-=logsumexp(lw,axis=1)[:,None]
  return lw,mu,cc
class StructuredGMM:
 def __init__(self,x,k,velocity):
  self.velocity=velocity;self.blocks=[fit_gmm(x[:,np.r_[np.arange(4*j,4*j+4),20:23]],k,84010+j) for j in range(5)]
 def logq(self,x):
  out=self.velocity.logq(x[:,20:])
  for j,g in enumerate(self.blocks):
   lw,mu,c=g.conditional(x[:,20:]);dx=x[:,None,4*j:4*j+4]-mu;P=np.linalg.inv(c);const=-2*LOG2PI-.5*np.linalg.slogdet(c)[1];out+=logsumexp(lw+const-.5*np.einsum('nki,kij,nkj->nk',dx,P,dx),axis=1)
  return out
 def sample(self,n,rng,velocity=None):
  v=self.velocity.sample(n,rng) if velocity is None else velocity;x=np.zeros((n,23));x[:,20:]=v
  for j,g in enumerate(self.blocks):
   lw,mu,c=g.conditional(v);u=rng.random(n);ids=(u[:,None]>np.cumsum(np.exp(lw),axis=1)).sum(1);ids=np.minimum(ids,len(g.w)-1);L=np.linalg.cholesky(c);x[:,4*j:4*j+4]=mu[np.arange(n),ids]+np.einsum('nij,nj->ni',L[ids],rng.normal(size=(n,4)))
  return x
class ConditionalBank:
 def __init__(self,x,s,P,velocity,h=None):
  self.x=x;self.s=s;self.P=P;self.velocity=velocity;self.n=len(x);self.h=self.n**(-1/7) if h is None else h
  self.cv=np.cov(x[:,20:].T);self.pv=np.linalg.inv(self.cv)/self.h**2
  self.event=[]
  for j in range(5):
   sl=slice(4*j,4*j+4);H=P[:,sl,sl].copy();C=P[:,sl,20:].copy();self.event.append((x[:,sl].copy(),s[:,sl].copy()+np.einsum('nij,nj->ni',C,x[:,20:]),H,C))
 def logweights(self,v):
  dx=v[:,None,:]-self.x[None,:,20:];lw=-.5*np.einsum('nki,ij,nkj->nk',dx,self.pv,dx);return lw-logsumexp(lw,axis=1)[:,None]
 def conditional_params(self,j,v):
  e,S,H,C=self.event[j];score=S[None]-np.einsum('kij,nj->nki',C,v);cov=np.linalg.inv(H);mu=e[None]+np.einsum('kij,nkj->nki',cov,score);return self.logweights(v),mu,cov
 def local_logq(self,x,chunk=64):
  out=[]
  for first in range(0,len(x),chunk):
   xx=x[first:first+chunk];v=xx[:,20:];val=self.velocity.logq(v)
   for j in range(5):
    lw,mu,cov=self.conditional_params(j,v);H=self.event[j][2];dx=xx[:,None,4*j:4*j+4]-mu;const=-2*LOG2PI+.5*np.linalg.slogdet(H)[1];val+=logsumexp(lw+const-.5*np.einsum('nki,kij,nkj->nk',dx,H,dx),axis=1)
   out.append(val)
  return np.concatenate(out)
 def local_sample(self,n,rng,velocity=None):
  v=self.velocity.sample(n,rng) if velocity is None else velocity;x=np.zeros((n,23));x[:,20:]=v;lw=self.logweights(v);u=rng.random((n,5));cum=np.cumsum(np.exp(lw),axis=1)
  for j in range(5):
   ids=(u[:,j,None]>cum).sum(1);ids=np.minimum(ids,self.n-1);e,S,H,C=self.event[j];cov=np.linalg.inv(H);score=S[ids]-np.einsum('nij,nj->ni',C[ids],v);mu=e[ids]+np.einsum('nij,nj->ni',cov[ids],score);L=np.linalg.cholesky(cov[ids]);x[:,4*j:4*j+4]=mu+np.einsum('nij,nj->ni',L,rng.normal(size=(n,4)))
  return x
