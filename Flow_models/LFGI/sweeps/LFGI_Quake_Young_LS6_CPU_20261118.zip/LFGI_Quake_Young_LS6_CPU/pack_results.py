"""Collect completed cells, display outputs, diagnostics and reports in compact ZIPs."""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
MAX_BYTES = 23_000_000


def pack(profile, dest, include_models=False):
    files = []
    for folder in [f'results/{profile}', f'reports/{profile}', 'logs', 'configs', 'provenance', 'prepared']:
        for file in (ROOT / folder).rglob('*'):
            if not file.is_file() or file.name == 'LOCK' or '.tmp' in file.name:
                continue
            if folder == 'prepared' and file.suffix != '.json':
                continue
            if not include_models and (file.suffix == '.pkl' or any('checkpoints' in p for p in file.parts)):
                continue
            files.append(file)
    for relative in ('data/reference.json', 'data/projection_axes.json'):
        files.append(ROOT / relative)

    dest.mkdir(exist_ok=True, parents=True)
    parts, group, total = [], [], 0
    for file in sorted(files):
        size = file.stat().st_size
        if size > MAX_BYTES:
            raise ValueError(f'Single file exceeds export chunk size at {file}')
        if group and total + size > MAX_BYTES:
            parts.append(group)
            group, total = [], 0
        group.append(file)
        total += size
    if group:
        parts.append(group)

    manifest = []
    for number, files in enumerate(parts, 1):
        path = dest / f'Quake_Young_{profile}_{number:03d}.zip'
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as archive:
            for file in files:
                archive.write(file, str(file.relative_to(ROOT)))
        manifest.append(dict(file=path.name, bytes=path.stat().st_size,
                             sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    (dest / 'INDEX.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', choices=['production', 'pilot'], default='production')
    parser.add_argument('--include-models', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    pack(args.profile, args.output or ROOT / 'exports' / args.profile, args.include_models)
