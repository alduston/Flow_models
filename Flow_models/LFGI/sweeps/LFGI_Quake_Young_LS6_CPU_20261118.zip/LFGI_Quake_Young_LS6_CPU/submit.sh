#!/bin/bash
set -euo pipefail
BUNDLE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$BUNDLE"
profile=production
displays=1
while [[ $# -gt 0 ]]; do
 case "$1" in
  --pilot) profile=pilot ;;
  --smoke-only) profile=smoke ;;
  --no-displays) displays=0 ;;
  *) echo 'Usage: bash submit.sh [--pilot|--smoke-only] [--no-displays]' >&2; exit 2 ;;
 esac
 shift
done
mkdir -p logs
exec 9>.submission.lock
flock -n 9 || { echo 'Submission already in progress' >&2; exit 2; }
if [[ -f logs/submitted_ids.txt ]]; then
 while read -r stage id; do
  if ! state=$(squeue -h -j "$id" 2>/dev/null); then
   state=$(sacct -n -X -j "$id" --format=State --parsable2) || {
    echo "Cannot confirm prior $stage job $id in accounting." >&2; exit 2;
   }
   if [[ -z "$state" ]] || [[ -n "$(printf '%s\n' "$state" | sed '/^$/d' | grep -Ev '^(COMPLETED|FAILED|CANCELLED|TIMEOUT|NODE_FAIL|OUT_OF_MEMORY|PREEMPTED|BOOT_FAIL|DEADLINE)[^|]*\|?$' || true)" ]]; then
    echo "Prior $stage job $id is not confirmed terminal." >&2; exit 2
   fi
   state=''
  fi
  if [[ -n "$state" ]]; then
   echo "Existing $stage job or array $id is still active." >&2; exit 2
  fi
 done < logs/submitted_ids.txt
 cp logs/submitted_ids.txt "logs/submitted_ids_$(date +%s).txt"
fi
read -r tasks concurrency display_tasks display_concurrency < <(
 python3 ls6/limits.py --profile "$profile" --displays "$displays"
) || { echo 'Queue preflight failed. No jobs submitted.' >&2; exit 2; }
: > logs/submitted_ids.txt
submit() {
 local stage=$1 wall=$2 cpus=$3 dep=${4:-} arr=${5:-}
 local args=(-A "${QUAKE_ACCOUNT:-DMS22021}" -p "${QUAKE_QUEUE:-normal}" -N 1 -n 1 -c "$cpus" -t "$wall" -J "quake-young-$stage")
 if [[ -n "$arr" ]]; then
  args+=(--array="$arr" -o 'logs/%x-%A_%a.out' -e 'logs/%x-%A_%a.err')
 else
  args+=(-o 'logs/%x-%j.out' -e 'logs/%x-%j.err')
 fi
 if [[ -n "$dep" ]]; then args+=(--dependency="$dep"); fi
 local raw id
 raw=$(sbatch --parsable "${args[@]}" ls6/job.sh "$BUNDLE" "$stage" "$profile")
 id=$(printf '%s\n' "$raw" | sed -nE 's/^([0-9]+)(;[^[:space:]]+)?$/\1/p; s/^Submitted batch job ([0-9]+)$/\1/p')
 [[ "$id" =~ ^[0-9]+$ ]] || { echo "Unexpected sbatch response: $raw" >&2; exit 2; }
 printf '%s %s\n' "$stage" "$id" >> logs/submitted_ids.txt
 echo "$id"
}
chunks=${QUAKE_CHUNK_WORKERS:-8}
[[ "$chunks" =~ ^[1-9][0-9]*$ ]] || { echo 'QUAKE_CHUNK_WORKERS must be positive.' >&2; exit 2; }
setup=$(submit setup 00:30:00 1)
smoke=$(submit smoke "${QUAKE_SMOKE_WALL:-01:30:00}" "$chunks" "afterok:$setup")
if [[ "$profile" != smoke ]]; then
 run=$(submit "$profile" "${QUAKE_WALL:-04:00:00}" "${QUAKE_CPUS_PER_TASK:-64}" "afterok:$smoke" "0-$((tasks-1))%$concurrency")
 dep="afterany:$run"
 if [[ "$display_tasks" -gt 0 ]]; then
  display=$(submit marginals "${QUAKE_MARGINALS_WALL:-04:00:00}" "$chunks" "afterany:$run" "0-$((display_tasks-1))%$display_concurrency")
  dep="$dep:$display"
 fi
 submit report 00:30:00 1 "$dep" > /dev/null
fi
cat logs/submitted_ids.txt
