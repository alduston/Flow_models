# Young time-only matrix gate on Quake

This bundle adds one method, `conditional_young`, to the frozen Quake campaign. The production array covers all 15 combinations of bank sizes 256, 1,024, and 2,048 and bank seeds 101–105. Each cell evaluates the same 512 held-out posterior draws and uses five independent batches of 512 proposal draws. It pairs the proposal innovations with the archived Conditional LFGI-GN run.

For event $j$, the empirical score information is $F_j=N^{-1}\sum_i s_j(x_i)s_j(x_i)^\top$, where $s_j(x_i)$ is the event block of the clean score at a bank draw. With $\alpha_t=e^{-t}$ and $\gamma_t=1-e^{-2t}$, the coefficient on the target-score identity is $\alpha_t^2(\alpha_t^2 I+\gamma_t F_j)^{-1}$. Young et al.'s opposite coefficient weights the Tweedie estimate. The matrix is shared across noisy states and velocities within each event. The conditional kernel weights, Gauss–Newton event score rebase, velocity marginal, flow tolerances, and curvature-controlled endpoint follow the archived Quake campaign. The gate matrix itself uses clean score second moments.

## Run on Lonestar6

1. Extract the archive to a new work directory.
2. From `LFGI_Quake_Young_LS6_CPU`, run:

   ```bash
   bash submit.sh
   ```

The submission creates a setup job, a Young-only native smoke, a 15-cell Young production array, a two-element array for the appendix displays, and a report/export job. The launcher checks queue headroom, reduces the number of production shards when needed, and records all IDs in `logs/submitted_ids.txt`. All derivative evaluation, numeric work, and dependency installation run on compute nodes. The fixed target inputs and shared cubature proposals are included.

`bash submit.sh --pilot` runs the seed-101 bank at $N=1{,}024$ with 128 held-out draws and one batch of 128 proposals. `bash submit.sh --smoke-only` runs setup and the reduced native smoke. Production generates the full appendix arrays unless `--no-displays` is passed. The default allocation is `DMS22021`; set `QUAKE_ACCOUNT` for another allocation. Existing overrides include `QUAKE_QUEUE`, `QUAKE_ARRAY_TASKS`, `QUAKE_ARRAY_CONCURRENCY`, `QUAKE_CHUNK_WORKERS`, `QUAKE_WORKERS`, `QUAKE_CPUS_PER_TASK`, `QUAKE_WALL`, `QUAKE_MARGINALS_WALL`, `QUAKE_CPU_VENV`, `QUAKE_GCC_MODULE`, and `QUAKE_PYTHON_MODULE`.

The high-resolution array uses seed 101 at $N=256$ and 1,024. Each array cell saves 8,192 actual display draws and evaluates the paper's exact 4,096 archived proposal points for marginal-density cubature. It uses the archived E3/E5 projection axes and bin edges, records window/outside mass and cubature diagnostics, and exports location/depth, standardized origin time, and implicit marginal plots as PDFs and PNGs. Display draws use a recorded independent seed. The archived display files preserve the original particles and model hashes.

When the DAG finishes, collect `exports/production/INDEX.json` and the listed `Quake_Young_production_*.zip` files. Each ZIP can be extracted into the same directory. The bundle exports:

- `reports/production/{status.json,per_repeat_calibrated.csv,figure_statistics_calibrated.csv,table_statistics_calibrated.csv,largest_bank_summary_calibrated.csv,paired_lfgi_differences.csv}` and density/evidence curves.
- `reports/production/high_resolution` with both display banks, raw arrays, plots, and per-display status.
- `results/production` with draw, log-density, bridge, target-call, and residual records for each cell.

The reports use the manuscript's numerical log-evidence reference $-24.02049029511186$ and resample whole bank groups for uncertainty. They also read frozen Conditional LFGI-GN summary inputs for paired uncertainty. If a flow terminates with a time limit, resubmitting the same command after all prior stages are terminal resumes its saved chunks. An arithmetic failure is recorded as a failed cell. After diagnosing it, set `QUAKE_RETRY_FAILED=1` to retry. If desired, regenerate exports using `python pack_results.py --profile production` in the campaign environment.

## Validation

Local checks exercised the Young score and divergence against the direct blend and complex-step differentiation, matched the archived bank and evaluation IDs, and exercised the queue DAG with mock Slurm commands. The reduced local native run validates fit, sample, bridge, independent density roundtrip, and display generation. Slurm submission and full production runs take place on LS6.
