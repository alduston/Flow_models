"""Build the distributed source and fixture integrity manifest."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
paths = [root / 'submit.sh', root / 'pack_results.py']
valid = {'.py', '.cpp', '.sh', '.txt', '.json', '.npz', '.csv'}
for directory in ('code', 'ls6', 'configs', 'data', 'tests'):
    paths.extend(p for p in (root / directory).rglob('*') if p.is_file() and p.suffix in valid)
manifest = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(paths)}
(root / 'provenance/IMMUTABLE_SHA256.json').write_text(json.dumps(manifest, indent=2) + '\n')
