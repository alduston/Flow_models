"""Check the OO gate convention and the differentiated conditional blend."""
import os
from pathlib import Path
import sys

os.environ['OPENBLAS_NUM_THREADS'] = '1'
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'code'))

import numpy as np
from scipy.special import softmax
from common import ROOT, rng
from homogeneous import HomogeneousField
from mixtures import select_gmm
from models import ConditionalBank

with np.load(ROOT / 'prepared/seed101.npz') as data:
    x, score, precision = (data[key][:1024] for key in ('x', 's', 'P'))
velocity, _ = select_gmm(x[:, 20:], [1, 2], 40101)
bank = ConditionalBank(x, score, precision, velocity)
with np.load(ROOT / 'prepared/posterior.npz') as data:
    query = data['x'][rng(84).choice(512, 4, replace=False)]
v = query[:, 20:]
log_velocity = bank.logweights(v)
max_score_error = 0.
max_trace_error = 0.
for event in range(5):
    field = HomogeneousField(bank, v, event)
    block = slice(4 * event, 4 * event + 4)
    x_event, shifted, _, cross = bank.event[event]
    moment = score[:, block].T @ score[:, block] / len(x)
    np.testing.assert_allclose(field.fisher, moment, rtol=0, atol=0)
    y = query[:, block]
    c = shifted[None, :, :] - np.einsum('nck,bk->bnc', cross, v)
    for time in (1e-6, .003, .05, .15, 1., 8.):
        alpha = np.exp(-time)
        gamma = -np.expm1(-2 * time)
        weights = softmax(log_velocity -
                          np.sum((y[:, None] - alpha * x_event[None])**2, axis=2) / (2 * gamma),
                          axis=1)
        tweedie = (alpha * (weights @ x_event) - y) / gamma
        tsi = np.einsum('bn,bnc->bc', weights, c) / alpha
        target_weight = alpha**2 * np.linalg.inv(alpha**2 * np.eye(4) + gamma * moment)
        direct = tweedie @ (np.eye(4) - target_weight) + tsi @ target_weight
        actual, trace = field.calc(y, time)
        max_score_error = max(max_score_error, np.max(np.abs(direct - actual)))
        np.testing.assert_allclose(actual, direct, rtol=3e-8, atol=2e-8)
        complex_trace = np.zeros(len(y))
        for coordinate in range(4):
            perturbed = y.astype(complex)
            perturbed[:, coordinate] += 1e-30j
            complex_trace += field.calc(perturbed, time, div=False)[:, coordinate].imag / 1e-30
        max_trace_error = max(max_trace_error, np.max(np.abs(complex_trace - trace)))
        np.testing.assert_allclose(trace, complex_trace, rtol=1e-8, atol=1e-7)
print(f'Young direct blend error {max_score_error:.3g}; complex-step divergence error {max_trace_error:.3g}')
