"""Exercise actual dispatch routing and Slurm headroom with local mocks."""
import csv
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'ls6'), str(ROOT / 'code')]
import driver

with (ROOT / 'configs/RUN_MATRIX.csv').open() as handle:
    cells = [dict(seed=int(row['seed']), N=int(row['N']), method=row['method'])
             for row in csv.DictReader(handle)]
assert len(cells) == 15 and all(cell['method'] == 'conditional_young' for cell in cells)

with tempfile.TemporaryDirectory() as temp:
    root = Path(temp)
    driver.write(root / 'prepared/cells.json', cells)
    (root / 'configs').mkdir()
    shutil.copyfile(ROOT / 'configs/campaign.json', root / 'configs/campaign.json')
    seen = []
    displays = []

    def launch(cell, label, count=None, repeats=None, retry=False):
        seen.append((cell, label, count, repeats))
        return dict(**cell, returncode=0, status='COMPLETE')

    with patch.object(driver, 'B', root), patch.object(driver, 'launch', launch), \
            patch.object(driver, 'verified_native_smoke', lambda: ({'recommended_workers': 8}, 1)):
        for tasks in (1, 3, 15):
            seen.clear()
            for i in range(tasks):
                driver.production('production', task_index=i, task_count=tasks)
            assert sorted((c['seed'], c['N']) for c, _, _, _ in seen) == sorted((c['seed'], c['N']) for c in cells)
            assert all((label, count, repeats) == ('production', None, None)
                       for _, label, count, repeats in seen)
        seen.clear()
        driver.production('pilot', task_index=0, task_count=1)
        assert seen == [(dict(seed=101, N=1024, method='conditional_young'), 'pilot', 128, 1)]
        with patch('marginals.run', side_effect=lambda **kw: displays.append(kw)):
            driver.display('production', task_index=0)
            driver.display('production', task_index=1)
    assert displays == [
        dict(label='production', seed=101, n=n, draws=8192, cubature=4096)
        for n in (256, 1024)
    ]

scripts = {
    'sbatch': """#!/usr/bin/env python3
import json,sys
from pathlib import Path
f=Path("calls.jsonl")
n=len(f.read_text().splitlines()) if f.is_file() else 0
with f.open("a") as log: print(json.dumps(sys.argv[1:]),file=log)
print("TACC notice from wrapper")
print(f"{1000+n};ls6")
""",
    'squeue': """#!/usr/bin/env python3
import os,sys
if "-j" in sys.argv:
    if os.getenv("MOCK_ACTIVE") == "1": print("active")
else:
    for i in range(int(os.getenv("MOCK_EXISTING","0"))): print(f"{2000+i}|normal|PENDING")
""",
    'qlimits': """#!/usr/bin/env python3
import os
print("normal MaxJobsPU=" + os.environ["MOCK_MAX_RUN"] + " MaxSubmitPU=100")
""",
    'scontrol': """#!/usr/bin/env python3
import sys
print("PartitionName=normal QoS=normal" if "partition" in sys.argv else "MaxArraySize = 1001")
""",
    'sacctmgr': """#!/usr/bin/env python3
import os
print("normal|" + os.environ["MOCK_MAX_RUN"] + "|100|")
""",
}

def submission(args, existing, expected, production_array=None, display_array=None, max_run=20):
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        (root / 'bin').mkdir()
        for folder in ('configs', 'ls6'):
            shutil.copytree(ROOT / folder, root / folder)
        shutil.copyfile(ROOT / 'submit.sh', root / 'submit.sh')
        for name, source in scripts.items():
            path = root / 'bin' / name
            path.write_text(source)
            path.chmod(0o755)
        env = {k: v for k, v in os.environ.items() if not k.startswith('QUAKE_')}
        env.update(PATH=str(root / 'bin') + os.pathsep + env['PATH'],
                   MOCK_EXISTING=str(existing), MOCK_MAX_RUN=str(max_run))
        run = subprocess.run(['bash', 'submit.sh', *args], cwd=root, env=env,
                             capture_output=True, text=True)
        file = root / 'calls.jsonl'
        if expected == 0:
            assert run.returncode and not file.exists(), (run.stdout, run.stderr)
            return
        assert not run.returncode, (run.stdout, run.stderr)
        calls = [json.loads(line) for line in file.read_text().splitlines()]
        stages = {call[-2]: call for call in calls}
        assert len(calls) == expected and '--dependency=afterok:1000' in stages['smoke']
        if production_array:
            stage = 'pilot' if '--pilot' in args else 'production'
            assert production_array in stages[stage] and '--dependency=afterok:1001' in stages[stage]
            dependency = '--dependency=afterany:1002'
            if display_array:
                assert display_array in stages['marginals']
                assert dependency in stages['marginals']
                dependency += ':1003'
            assert dependency in stages['report']
        env['MOCK_ACTIVE'] = '1'
        duplicate = subprocess.run(['bash', 'submit.sh', *args], cwd=root, env=env,
                                   capture_output=True, text=True)
        assert duplicate.returncode and len(file.read_text().splitlines()) == expected

submission([], 0, 5, '--array=0-14%15', '--array=0-1%2')
submission([], 94, 5, '--array=0-0%1', '--array=0-1%2')
submission([], 95, 0)
submission([], 0, 5, '--array=0-14%1', '--array=0-1%1', max_run=1)
submission(['--pilot'], 0, 4, '--array=0-0%1')
submission(['--smoke-only'], 0, 2)
submission(['--no-displays'], 0, 4, '--array=0-14%15')
print('Verified one-to-one 15-cell production coverage, both appendix tasks, pilot routing, queue limits, and duplicate guard.')
