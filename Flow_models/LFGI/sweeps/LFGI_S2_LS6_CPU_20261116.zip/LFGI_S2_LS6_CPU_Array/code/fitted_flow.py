"""Unconditional 2D NumPy affine coupling flow, adapted from quake's tested MLE code."""
import copy
import numpy as np
class CouplingFlow:
 def __init__(self,layers,width,seed):
  self.layers=layers;self.width=width;self.params=[];random=np.random.default_rng(seed)
  for k in range(layers):self.params.append([random.normal(size=(1,width)),np.zeros(width),random.normal(size=(width,width))/np.sqrt(width),np.zeros(width),np.zeros((width,2)),np.zeros(2)])
 def network(self,z,k):
  a=k%2;b=1-a;net=z[:,a:a+1].copy();W1,b1,W2,b2,W3,b3=self.params[k];h1=np.tanh(net@W1+b1);h2=np.tanh(h1@W2+b2);o=h2@W3+b3;return a,b,net,h1,h2,o
 def forward(self,x,grad=False):
  z=x.copy();ld=np.zeros(len(z));cache=[]
  for k in range(self.layers):
   a,b,net,h1,h2,o=self.network(z,k);l=1.5*np.tanh(o[:,1]);z[:,b]=(z[:,b]-o[:,0])*np.exp(-l);ld-=l;cache.append((a,b,net,h1,h2,o,z[:,b].copy(),l))
  ll=-.5*(z*z).sum(1)-np.log(2*np.pi)+ld
  if not grad:return ll
  dz=z/len(z);grads=[]
  for k in range(self.layers-1,-1,-1):
   a,b,net,h1,h2,o,zb,l=cache[k];W1,b1,W2,b2,W3,b3=self.params[k];db=dz[:,b].copy();do=np.c_[-db*np.exp(-l),(-db*zb+1/len(z))*1.5*(1-np.tanh(o[:,1])**2)];gW3=h2.T@do;gb3=do.sum(0);dh2=(do@W3.T)*(1-h2*h2);gW2=h1.T@dh2;gb2=dh2.sum(0);dh1=(dh2@W2.T)*(1-h1*h1);gW1=net.T@dh1;gb1=dh1.sum(0);din=dh1@W1.T;dz[:,a]+=din[:,0];dz[:,b]=db*np.exp(-l);grads.append([gW1,gb1,gW2,gb2,gW3,gb3])
  return -ll.mean(),grads[::-1]
 def inverse(self,z):
  e=z.copy()
  for k in range(self.layers-1,-1,-1):
   a,b,net,h1,h2,o=self.network(e,k);e[:,b]=e[:,b]*np.exp(1.5*np.tanh(o[:,1]))+o[:,0]
  return e
 def train(self,x,epochs,random,validation=None,patience=30):
  moments=[[np.zeros_like(a) for a in layer] for layer in self.params];squares=copy.deepcopy(moments);step=0;best=np.inf;bestpar=None;bestepoch=0;stale=0
  for epoch in range(1,epochs+1):
   order=random.permutation(len(x))
   for first in range(0,len(x),128):
    ix=order[first:first+128];loss,gr=self.forward(x[ix],True);norm=np.sqrt(sum((g*g).sum() for layer in gr for g in layer));clip=min(1,10/max(norm,1e-12));step+=1
    for j in range(self.layers):
     for k in range(6):
      g=gr[j][k]*clip;moments[j][k]=.9*moments[j][k]+.1*g;squares[j][k]=.999*squares[j][k]+.001*g*g;self.params[j][k]-=.001*(moments[j][k]/(1-.9**step))/(np.sqrt(squares[j][k]/(1-.999**step))+1e-8)
   val=-self.forward(x if validation is None else validation).mean()
   if not np.isfinite(val):raise ArithmeticError('nonfinite fitted-flow loss')
   if val<best-1e-5:best=val;bestepoch=epoch;bestpar=copy.deepcopy(self.params);stale=0
   else:stale+=1
   if validation is not None and epoch>=50 and stale>=patience:break
  if validation is not None:self.params=bestpar
  return dict(best_validation_loss=float(best),best_epoch=bestepoch,epochs_run=epoch)
class Preprocess:
 def __init__(self,x):self.mean=x.mean(0);self.L=np.linalg.cholesky(np.cov(x.T)+1e-6*np.eye(2));self.logdet=np.log(np.diag(self.L)).sum()
 def encode(self,x):return np.linalg.solve(self.L,(x-self.mean).T).T
 def decode(self,z):return self.mean+z@self.L.T
class FittedFlow:
 def __init__(self,x,seed,epochs=300,quick=False):
  random=np.random.default_rng(seed);order=random.permutation(len(x));split=int(.8*len(x));it,iv=order[:split],order[split:]
  if len(iv)<8:raise ValueError('Too few validation states for fitted flow')
  prep=Preprocess(x[it]);et,ev=prep.encode(x[it]),prep.encode(x[iv]);choices=[]
  for layers,width in ([(2,16)] if quick else [(4,32),(6,64)]):
   for restart in range(1 if quick else 2):
    sd=seed+10*layers+restart;f=CouplingFlow(layers,width,sd);info=f.train(et,epochs,np.random.default_rng(sd+1),validation=ev);choices.append((info['best_validation_loss']+prep.logdet,layers,width,sd,info))
  score,layers,width,sd,selection=min(choices,key=lambda a:a[0]);self.prep=Preprocess(x);self.flow=CouplingFlow(layers,width,sd);self.flow.train(self.prep.encode(x),max(1,selection['best_epoch']),np.random.default_rng(sd+1));self.info=dict(layers=layers,width=width,seed=sd,selection=selection,refit_epochs=selection['best_epoch'],candidates=len(choices),split_seed=seed,criterion='internal validation NLL, followed by refit on full bank')
 def logq(self,x):return self.flow.forward(self.prep.encode(x))-self.prep.logdet
 def sample(self,n,random):return self.prep.decode(self.flow.inverse(random.normal(size=(n,2))))
