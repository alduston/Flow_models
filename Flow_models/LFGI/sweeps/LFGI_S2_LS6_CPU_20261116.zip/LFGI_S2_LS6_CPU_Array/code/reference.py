"""Deterministic evidence/entropy reference; never used to select fitted proposals."""
import numpy as np
from scipy.special import ndtr
from scipy.optimize import minimize
from common import ROOT,write,save
from target import TanhIP
from models import GMM

def quadrature(L,n):
 t=TanhIP();z,w=np.polynomial.legendre.leggauss(n);z*=L;w*=L;xx,yy=np.meshgrid(z,z,indexing='ij');x=np.c_[xx.ravel(),yy.ravel()];ww=(w[:,None]*w[None,:]).ravel();lp=t.logp(x);Z=ww@np.exp(lp);p=ww*np.exp(lp)/Z
 return dict(L=L,n=n,logZ=float(np.log(Z)),prior_tail_mass_bound=float(4*ndtr(-L)),mean=p@x,second=np.einsum('n,ni,nj->ij',p,x,x),entropy=float(-p@(lp-np.log(Z))))
def prepare_reference():
 rows=[quadrature(8,160),quadrature(10,256),quadrature(10,384)];last=rows[-1];delta=max(abs(r['logZ']-last['logZ']) for r in rows[-2:]);assert delta<1e-9,(delta,rows)
 tail=last['prior_tail_mass_bound']/np.exp(last['logZ']);write(ROOT/'reference/quadrature.json',dict(**last,refinements=rows,refinement_logZ_delta=delta,relative_tail_mass_bound=tail,scope='converged deterministic quadrature, not a formal quadrature-error bound',normalization='normalized standard Gaussian prior, omitted Gaussian observation constant'))
 t=TanhIP();ledger=dict(E=0,G=0,H=0)
 def fun(x):ledger['E']+=1;return -float(t.logp(x[None])[0])
 def jac(x):ledger['G']+=1;return -t.score(x[None])[0]
 rows=[]
 for x in [np.zeros(2),np.array([1.,-1.]),np.array([-1.,1.])]:
  r=minimize(fun,x,jac=jac,method='BFGS',options=dict(gtol=1e-10,maxiter=1000));rows.append(r)
 r=min(rows,key=lambda r:r.fun);ledger['H']+=1;H=t.exact_hessian(r.x[None])[0];gnorm=float(np.linalg.norm(jac(r.x)));assert np.linalg.eigvalsh(H).min()>0 and gnorm<1e-7
 save(ROOT/'prepared/laplace.npz',mean=r.x,cov=np.linalg.inv(H));write(ROOT/'prepared/laplace.json',dict(target_query_ledger=ledger,mode=r.x,gradient_norm=gnorm,scope='one shared target-only fit; extra queries charged separately from bank acquisition'))
 return last
if __name__=='__main__':prepare_reference()
