"""Actual draws and separate implicit 2D density integration via a common mixture q/r.
The mixture includes every available normalized model, so q/r <= model count.
All integral weights are raw, without renormalizing mass to one or inside windows.
"""
import argparse,pickle
import numpy as np
from scipy.special import logsumexp
from common import ROOT,read,write,save,rng,sha,arrays_sha
from campaign import METHODS,paths,target
from flows import PFModel
from report import LABELS

def run(label='production',small=False):
 import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
 config=read(ROOT/'configs/campaign.json');seed=config['display_seed'];true=read(ROOT/'reference/quadrature.json');out=ROOT/'reports'/label;out.mkdir(parents=True,exist_ok=True);t=target();reference=t.sample(32768 if not small else 1024,rng(901));reference_E=t.candidates;lo=np.quantile(reference,.001,axis=0);hi=np.quantile(reference,.999,axis=0);nb=40;bins=[np.linspace(lo[j],hi[j],nb+1) for j in range(2)];area=np.diff(bins[0])[0]*np.diff(bins[1])[0];href=np.histogram2d(*reference.T,bins=bins)[0]/len(reference)/area
 sizes=[config['pilot_N']] if label=='pilot' else config['display_N'];summary={}
 for n in sizes:
  models={};clouds={'Target: exact rejection':reference};all_lqq={};skipped=[]
  for mi,m in enumerate(METHODS):
   if m=='warp3':continue
   d=paths(dict(seed=seed,N=n,method=m),label);p=d/'status.json'
   if not p.exists() or read(p)['status']!='COMPLETE':skipped.append(m);continue
   ft=read(d/'fit.json');assert ft['pickle_sha256']==sha(d/'model.pkl')
   with (d/'model.pkl').open('rb') as f:model=pickle.load(f)
   if isinstance(model,PFModel):model.cache=d/'marginal_checkpoints'
   models[m]=model;raw=out/f'actual_N{n}_{m}.npz';ns=32 if small else config['histogram_n']
   if raw.exists():
    a=np.load(raw);assert int(a['count'])==ns and str(a['binding'])==read(p)['binding'];x=a['x'];lq=a['logq']
   else:
    if isinstance(model,PFModel):x,lq=model.sample_logq(ns,rng(n,mi,902),'display_draws')
    else:x=model.sample(ns,rng(n,mi,902));lq=model.logq(x)
    save(raw,x=x,logq=lq,count=ns,binding=np.array(read(p)['binding']))
   clouds[m]=x;all_lqq[m]=lq
  if not models:summary[str(n)]={'skipped':skipped,'status':'no complete normalized models'};continue
  # Balanced stratified mixture draws, shared for every implicit density.
  names=list(models);per=16 if small else 512;per=min(per,min(len(clouds[m]) for m in names));points=np.concatenate([clouds[m][:per] for m in names]);logs=[];self_errors={}
  for j,m in enumerate(names):
   model=models[m];file=out/f'cubature_N{n}_{m}.npz';binding=sha(paths(dict(seed=seed,N=n,method=m),label)/'status.json')+arrays_sha(points)
   if file.exists():
    a=np.load(file);assert str(a['binding'])==binding and a['logq'].shape==(len(points),);lq=a['logq']
   else:
    lq=model.logq(points,tag='common_mixture_cubature') if isinstance(model,PFModel) else model.logq(points);save(file,logq=lq,binding=np.array(binding))
   self_errors[m]=float(np.max(abs(lq[j*per:(j+1)*per]-all_lqq[m][:per])))
   if isinstance(model,PFModel) and self_errors[m]>1e-3:raise ArithmeticError('Density/generation disagreement in display cubature: '+m)
   logs.append(lq)
  log_r=logsumexp(logs,axis=0)-np.log(len(names));implicit={'Target: exact rejection':np.exp(t.logp(points)-true['logZ']-log_r)};weights_info={};data={'Target: exact rejection':points}
  for m,lq in zip(names,logs):implicit[m]=np.exp(lq-log_r);data[m]=points
  for m,w in implicit.items():
   if not np.isfinite(w).all():raise ArithmeticError('Nonfinite density cubature weights: '+m)
   strata=w.reshape(len(names),per);mcse=np.sqrt(np.var(strata,axis=1,ddof=1).sum()/per)/len(names);weights_info[m]=dict(mass_estimate=float(w.mean()),mass_MCSE=float(mcse),ESS_diagnostic=float(w.sum()**2/(w*w).sum()),max_weight=float(w.max()),normalized_model_bound=(None if m.startswith('Target:') else len(names)))
  def figure(data,weights,kind):
   fig,axes=plt.subplots(3,4,figsize=(13,10),layout='constrained');axes=axes.ravel()
   for axis,(m,x) in zip(axes,data.items()):
    w=weights.get(m,np.ones(len(x)));h=np.histogram2d(*x.T,bins=bins,weights=w)[0]/len(x)/area;mass=float(h.sum()*area);axis.pcolormesh(bins[0],bins[1],h.T,shading='auto',vmin=0,vmax=href.max(),cmap='viridis');axis.set(title=(LABELS.get(m,m)+'\nwindow mass %.3f'%mass),xlabel='x1',ylabel='x2');axis.title.set_fontsize(9);save(out/f'{kind}_hist_N{n}_{m.replace(":","_").replace(" ","_")}.npz',hist=h,bins0=bins[0],bins1=bins[1],window_mass=mass)
   for axis in axes[len(data):]:axis.axis('off')
   fig.suptitle(('Actual particle histograms' if kind=='actual' else 'Implicit density histograms: shared mixture q/r cubature')+f' | bank seed {seed}, N={n}\nCommon bins/color scale; no window or integral renormalization',fontsize=12);fig.savefig(out/f'{kind}_density_N{n}.png',dpi=160);plt.close(fig)
  figure(clouds,{},'actual');figure(data,implicit,'implicit');summary[str(n)]=dict(status='complete',models=names,skipped=skipped,cubature_count=len(points),per_component=per,proposal='equal mixture of all displayed normalized models; balanced independent strata',weights=weights_info,generation_density_max_errors=self_errors,note='implicit histograms integrate evaluated densities on common mixture draws; they are not individual model particle histograms; raw weights retained')
 write(out/'histogram_integration.json',dict(seed=seed,sizes=summary,reference_rejection_E=reference_E,reference_display_only=True,extra_target_cubature_E=sum(s.get('cubature_count',0) for s in summary.values()),warp3='bridge-only transformed target; omitted from original-coordinate density panels'))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--label',default='production');p.add_argument('--small',action='store_true');a=p.parse_args();run(a.label,a.small)
