"""Paired bank-level uncertainty and absolute known-evidence density diagnostics."""
import argparse,csv,json
import numpy as np
from common import ROOT,read,write,rng
from campaign import METHODS
LABELS={'laplace':'MAP-Laplace','gaussian':'Fitted Gaussian','gmm2':'Two-component GMM','gmm_bic':'Selected GMM','t_mixture':'Selected t/Gaussian mixture','fitted_flow':'Validated fitted flow','gn_mixture':'GN local mixture','warp3':'Warp-III bridge','lfgi':'LFGI, small endpoint','lfgi_legacy_tmin':'LFGI, old endpoint','scalar':'Scalar gate, small endpoint'}
METRICS=['logZ','bridge_logZ_error','bridge_overlap','logratio_SD','forward_KL','reverse_KL','logdensity_RMSE','ELBO','entropy_q']
def report(label):
 config=read(ROOT/'configs/campaign.json');truth=read(ROOT/'reference/quadrature.json');expected=read(ROOT/'prepared/cells.json');expected=[c for c in expected if label!='pilot' or (c['seed']==config['pilot_seed'] and c['N']==config['pilot_N'])];rows=[];statuses=[]
 for c in expected:
  p=ROOT/'results'/label/f"seed{c['seed']}/N{c['N']}"/c['method']/'status.json'
  if not p.exists():statuses.append(dict(**c,status='MISSING'));continue
  s=read(p);statuses.append(dict(**c,status=s['status'],error=s.get('error')))
  if s['status']!='COMPLETE':continue
  for r in s['records']:
   row=dict(**c,repeat=r['repeat'],logZ=r['bridge']['logZ'],bridge_overlap=r['bridge']['overlap'],ESS=r['bridge']['IS_ESS'],new_E=r['new_E'],posterior_E_once=(s['posterior_E'] if r['repeat']==0 else 0),new_G=r['new_G'],new_H=r['new_H'],required_bank_G=s['shared_cache_access']['G'],required_bank_H=s['shared_cache_access']['H'],fit_seconds=s['fit_seconds'],evaluation_seconds=r['seconds'],cell_seconds=s['evaluation_seconds'],roundtrip_logq_max_error=s['roundtrip_logq_max_error'],space=r['space'])
   for metric in METRICS:
    if metric not in row:row[metric]=r.get(metric)
   rows.append(row)
 out=ROOT/'reports'/label;out.mkdir(parents=True,exist_ok=True);write(out/'status.json',dict(expected=len(expected),complete=sum(s['status']=='COMPLETE' for s in statuses),failed=sum(s['status']=='FAILED' for s in statuses),cells=statuses,reference_logZ=truth['logZ']))
 def csvout(name,data):
  if not data:return
  with (out/name).open('w') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
 csvout('per_repeat.csv',rows);aggregates=[]
 for n in config['bank_sizes']:
  for m in METHODS:
   rs=[r for r in rows if r['N']==n and r['method']==m]
   if not rs:continue
   byseed={s:[r for r in rs if r['seed']==s] for s in sorted(set(r['seed'] for r in rs))};a=dict(N=n,method=m,bank_groups=len(byseed),proposal_repeats=len(rs));random=rng(n,METHODS.index(m),998)
   for metric in METRICS:
    means=np.array([np.mean([r[metric] for r in v]) for v in byseed.values() if all(r[metric] is not None for r in v)]);a[metric]=float(means.mean()) if len(means) else None
    if len(means)>1 and np.isfinite(means).all():a[metric+'_bank_CI95']=np.quantile(np.mean(random.choice(means,(2000,len(means))),axis=1),[.025,.975]).tolist()
   a['bridge_logZ_RMSE']=float(np.sqrt(np.mean([np.mean([r['bridge_logZ_error']**2 for r in v]) for v in byseed.values()])))
   mse=np.array([np.mean([r['bridge_logZ_error']**2 for r in v]) for v in byseed.values()]);a['bridge_logZ_RMSE_bank_CI95']=np.sqrt(np.quantile(np.mean(random.choice(mse,(2000,len(mse))),axis=1),[.025,.975])).tolist()
   a['mean_within_fit_bridge_SD']=float(np.mean([np.std([r['logZ'] for r in v],ddof=1) if len(v)>1 else 0 for v in byseed.values()]));a['mean_cell_seconds']=float(np.mean([v[0]['cell_seconds'] for v in byseed.values()]));aggregates.append(a)
 write(out/'summary.json',aggregates);paired=[]
 for n in config['bank_sizes']:
  for m in METHODS:
   if m=='lfgi':continue
   seeds=sorted(set(r['seed'] for r in rows if r['N']==n and r['method']==m)&set(r['seed'] for r in rows if r['N']==n and r['method']=='lfgi'))
   for metric in ['forward_KL','reverse_KL','logdensity_RMSE','bridge_logZ_error']:
    differences=[]
    for seed in seeds:
     lf=[r[metric] for r in rows if r['N']==n and r['seed']==seed and r['method']=='lfgi'];bb=[r[metric] for r in rows if r['N']==n and r['seed']==seed and r['method']==m]
     if lf and bb and all(x is not None and np.isfinite(x) for x in lf+bb):
      differences.append(float(np.mean(np.square(bb))-np.mean(np.square(lf))) if metric=='bridge_logZ_error' else float(np.mean(bb)-np.mean(lf)))
    if differences:
     a=np.array(differences);ci=np.quantile(np.mean(rng(n,METHODS.index(m),881).choice(a,(2000,len(a))),1),[.025,.975]) if len(a)>1 else [None,None];paired.append(dict(N=n,comparator=m,metric=('bridge_logZ_MSE_reduction' if metric=='bridge_logZ_error' else metric+'_reduction'),groups=len(a),estimate=float(a.mean()),CI_low=ci[0],CI_high=ci[1]))
 csvout('paired_improvements.csv',paired)
 text='# Updated S2 density/bridge comparison\n\nTarget unchanged: 2D tanh inverse problem. Prior is normalized; Gaussian observation constant is omitted. Deterministic quadrature log Z = %.12f; posterior entropy = %.10f.\n\n'%(truth['logZ'],truth['entropy'])
 text+='Independent rejection groups are the uncertainty unit. Five proposal repeats are nested within each fitted bank. Paired intervals bootstrap group means, never treating 100 proposal repeats as 100 independent fits. Positive paired improvements favor small-endpoint LFGI. Warp-III metrics refer to its transformed symmetrized target; original-coordinate density/entropy/KL are not assigned to it. Finite-sample KL estimates may be negative and are not clipped.\n\n'
 text+='| N | Method | Groups | log-density RMSE | forward KL | reverse KL | Bridge log Z RMSE |\n|---|---|---:|---:|---:|---:|---:|\n'
 for a in aggregates:
  def fmt(k):return 'N/A' if a[k] is None else '%.5f'%a[k]
  text+='| %d | %s | %d | %s | %s | %s | %s |\n'%(a['N'],LABELS[a['method']],a['bank_groups'],fmt('logdensity_RMSE'),fmt('forward_KL'),fmt('reverse_KL'),fmt('bridge_logZ_RMSE'))
 text+='\nFailures/missing cells are retained in status.json. Shared rejection and derivative acquisition and the one target-only Laplace fit are recorded separately in prepared/acquisition.json. This is post-processing given posterior banks, not an end-to-end sampler-cost comparison. Timing is common-host wall time; total Slurm accounting must include interrupted work.\n'
 (out/'REPORT.md').write_text(text)
 if aggregates:
  import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
  fig,ax=plt.subplots(1,4,figsize=(17,4.8),layout='constrained')
  for mi,m in enumerate(METHODS):
   vals=[a for a in aggregates if a['method']==m]
   for axis,k in zip(ax,['logdensity_RMSE','forward_KL','reverse_KL','bridge_logZ_RMSE']):
    v=[x for x in vals if x.get(k) is not None and np.isfinite(x[k])]
    if not v:continue
    color=plt.cm.tab20(mi);axis.plot([x['N'] for x in v],[x[k] for x in v],'o-',label=LABELS[m],ms=3,color=color)
    ci=k+'_bank_CI95'
    if all(ci in x for x in v):axis.fill_between([x['N'] for x in v],[x[ci][0] for x in v],[x[ci][1] for x in v],color=color,alpha=.1)
  for axis,title in zip(ax,['Posterior log-density RMSE','Forward KL (Monte Carlo)','Reverse KL (Monte Carlo)','Bridge log Z RMSE']):axis.set(xlabel='Fitting bank N',title=title)
  ax[0].set_yscale('log');ax[3].set_yscale('log');fig.legend(*ax[3].get_legend_handles_labels(),loc='outside lower center',ncol=4,fontsize=7);fig.savefig(out/'comparison.png',dpi=170);plt.close(fig)
 print(json.dumps(read(out/'status.json'))[:250])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--label',default='production');a=p.parse_args();report(a.label)
