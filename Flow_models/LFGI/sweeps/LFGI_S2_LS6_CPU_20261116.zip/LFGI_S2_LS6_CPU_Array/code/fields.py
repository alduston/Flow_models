"""Chunked empirical fields and derivatives of the actual safeguarded maps.

Original unconstrained LFGI derivative: Pearson lfgi_core.py. General spectral
guard uses its Frechet derivative. Regression objectives use w^2 and w-centering.
"""
from dataclasses import dataclass
import numpy as np
from scipy.special import logsumexp,expit
@dataclass
class Bank:
 x:np.ndarray
 s:np.ndarray
 P:np.ndarray
 def __post_init__(self):
  self.x=np.asarray(self.x,float);self.s=np.asarray(self.s,float);self.P=np.asarray(self.P,float);self.n,self.d=self.x.shape
def softclip(x,eps=.01):
 # C1 polynomial clipping: exact 0/1 outside [0,1], identity away from
 # boundary strips. In particular g=0 stays zero at late OU times.
 u=np.clip(x/eps,0,1);v=np.clip((1-x)/eps,0,1)
 lo=eps*(2*u*u-u*u*u);hi=1-eps*(2*v*v-v*v*v)
 value=np.where(x<eps,lo,np.where(x>1-eps,hi,x))
 deriv=np.where(x<eps,4*u-3*u*u,np.where(x>1-eps,4*v-3*v*v,1.))
 deriv=np.where((x<=0)|(x>=1),0.,deriv)
 return value,deriv
class Field:
 def __init__(self,bank,method='lfgi',ridge=1e-4,chunk=64,uniform=None,floor=1e-4,width=1e-5,gate_bank=None):
  self.bank=bank;self.method=method;self.ridge=ridge;self.chunk=chunk;self.uniform=uniform;self.floor=floor;self.width=width;self.calls=0;self.gate_bank=gate_bank
 def __call__(self,y,t,jac=True):
  y=np.atleast_2d(y);rows=[self._part(z,t,jac) for z in np.array_split(y,max(1,int(np.ceil(len(y)/self.chunk))))]
  return {k:np.concatenate([r[k] for r in rows],axis=0) for k in rows[0]}
 def _part(self,y,t,jac):
  x,s,P=self.bank.x,self.bank.s,self.bank.P;d=x.shape[1];I=np.eye(d);a=np.exp(-t);g=-np.expm1(-2*t);self.calls+=len(y)
  dx0=y[:,None]-a*x;lw=-np.sum(dx0*dx0,axis=2)/(2*g);w=np.exp(lw-logsumexp(lw,axis=1)[:,None]);anchor=np.argmax(w,axis=1)
  # Center about an actual bank point before averaging. Subtracting E[z]
  # directly from a large z loses all conditional variance when ESS is near1.
  xoffset=x[None]-x[anchor,None];soffset=s[None]-s[anchor,None];xm=np.einsum('qn,qni->qi',w,xoffset);sm=np.einsum('qn,qni->qi',w,soffset);mu=x[anchor]+xm;ms=s[anchor]+sm;dx=xoffset-xm[:,None];ds=soffset-sm[:,None]
  b=(a*mu-y)/g;c=ms/a;delta=c-b
  Cov=np.einsum('qn,qni,qnj->qij',w,dx,dx);Cs=np.einsum('qn,qni,qnj->qij',w,ds,dx)
  Jb=a*a/g**2*Cov-I/g;Jc=Cs/g;Jd=Jc-Jb
  out=dict(ess=1/np.sum(w*w,axis=1),active=np.zeros(len(y)),raw_min=np.full(len(y),np.nan))
  if self.method=='tweedie':value=b;J=Jb
  elif self.method=='tsi':value=c;J=Jc
  elif self.method=='uniform':
   G=self.uniform;value=b+delta@G.T;J=Jb+np.einsum('ij,qjk->qik',G,Jd)
  elif self.method in ['lfgi','lfgi_raw']:
   if self.gate_bank is None:wg=w;Pg=P;dxg=dx
   else:
    xg=self.gate_bank.x;Pg=self.gate_bank.P;lg=-np.sum((y[:,None]-a*xg)**2,axis=2)/(2*g);wg=np.exp(lg-logsumexp(lg,axis=1)[:,None]);dxg=xg[None]-(wg@xg)[:,None]
   H=np.einsum('qn,nij->qij',wg,Pg);A=a*a*I+g*H;ev,U=np.linalg.eigh(A);out['raw_min']=ev[:,0];out['shift_min_abs']=np.min(np.abs(ev),axis=1);out['active']=np.mean(ev<self.floor+5*self.width,axis=1)
   if self.gate_bank is None and (self.method=='lfgi_raw' or np.all(ev>self.floor+40*self.width)):
    # Algebraically cancelled form, also avoiding large 1/g subtraction.
    u=a*ms+np.einsum('qij,qj->qi',H,a*mu-y);value=np.linalg.solve(A,u[...,None])[...,0]
    v=a*(b-value);Pv=np.einsum('nij,qj->qni',P,v)-np.einsum('qij,qj->qi',H,v)[:,None]
    K=np.einsum('qn,qni,qnj->qij',w,Pv,dx)
    J=np.linalg.solve(A,a*a/g*(Cs+H@Cov)-H+K)
   else:
    if self.method=='lfgi_raw':den=ev;h=a*a/den;hp=-a*a/den**2
    else:den=self.floor+self.width*np.logaddexp(0,(ev-self.floor)/self.width);h=a*a/den;hp=-a*a*expit((ev-self.floor)/self.width)/den**2
    G=np.einsum('qik,qk,qjk->qij',U,h,U);value=b+np.einsum('qij,qj->qi',G,delta);J=Jb+G@Jd
    diff=ev[:,:,None]-ev[:,None,:];num=h[:,:,None]-h[:,None,:];near=np.abs(diff)<1e-8*(1+np.abs(ev[:,:,None])+np.abs(ev[:,None,:]));F=np.divide(num,diff,out=np.zeros_like(num),where=~near);F=np.where(near,.5*(hp[:,:,None]+hp[:,None,:]),F)
    ud=np.einsum('qki,qk->qi',U,delta)
    for j in range(d):
     dA=a*np.einsum('qn,nab,qn->qab',wg,Pg,dxg[:,:,j]);D=U.swapaxes(1,2)@dA@U;dG=U@(F*D)@U.swapaxes(1,2);J[:,:,j]+=np.einsum('qik,qk->qi',dG,delta)
  elif self.method=='scalar':
   z=a/g*x;r=s/a-z;zo=z[None]-z[anchor,None];ro=r[None]-r[anchor,None];zc=zo-np.einsum('qn,qni->qi',w,zo)[:,None];rc=ro-np.einsum('qn,qni->qi',w,ro)[:,None];w2=w*w
   cross=np.sum(zc*rc,axis=2);norm=np.sum(rc*rc,axis=2);A0=-np.sum(w2*cross,axis=1);D0=np.sum(w2*norm,axis=1);wsum=np.sum(w2,axis=1);den=(1+self.ridge)*D0+self.ridge*d*wsum*1e-12
   raw=A0/den;gate,gp=softclip(raw);value=b+gate[:,None]*delta
   dz=a*a/g**2*Cov;dr=a/g*np.einsum('qn,qni,qnj->qij',w,rc,dx);sr=np.einsum('qn,qni->qi',w2,rc);sz=np.einsum('qn,qni->qi',w2,zc)
   gradA=-2*a/g*np.einsum('qn,qni,qn->qi',w2,dx,cross)+np.einsum('qi,qij->qj',sr,dz)+np.einsum('qi,qij->qj',sz,dr)
   gradD=2*a/g*np.einsum('qn,qni,qn->qi',w2,dx,norm)-2*np.einsum('qi,qij->qj',sr,dr)
   gradDen=(1+self.ridge)*gradD+self.ridge*d*1e-12*2*a/g*np.einsum('qn,qni->qi',w2,dx)
   grad=(gradA-raw[:,None]*gradDen)/den[:,None];J=Jb+gate[:,None,None]*Jd+delta[:,:,None]*(gp[:,None]*grad)[:,None,:]
  elif self.method=='matrix':
   z=a/g*x;r=s/a-z;zo=z[None]-z[anchor,None];ro=r[None]-r[anchor,None];zc=zo-np.einsum('qn,qni->qi',w,zo)[:,None];rc=ro-np.einsum('qn,qni->qi',w,ro)[:,None];w2=w*w
   M=np.einsum('qn,qni,qnj->qij',w2,zc,rc);R=np.einsum('qn,qni,qnj->qij',w2,rc,rc)
   scale=np.trace(R,axis1=1,axis2=2)/d;reg=self.ridge*(scale+np.sum(w2,axis=1)*1e-12);B=R+reg[:,None,None]*I
   G=-np.linalg.solve(B,M.swapaxes(1,2)).swapaxes(1,2)
   if self.method=='scalar':
    den=np.trace(R,axis1=1,axis2=2)+d*reg;raw=-np.trace(M,axis1=1,axis2=2)/den;gate,gp=softclip(raw);value=b+gate[:,None]*delta;J=Jb+gate[:,None,None]*Jd
   else:value=b+np.einsum('qij,qj->qi',G,delta);J=Jb+G@Jd
   for j in range(d):
    dw=a/g*w*dx[:,:,j];dw2=2*w*dw;dz=np.einsum('qn,qni->qi',dw,zc);dr=np.einsum('qn,qni->qi',dw,rc)
    dm=np.einsum('qn,qni,qnj->qij',dw2,zc,rc)-np.einsum('qi,qj->qij',dz,np.einsum('qn,qni->qi',w2,rc))-np.einsum('qi,qj->qij',np.einsum('qn,qni->qi',w2,zc),dr)
    dR=np.einsum('qn,qni,qnj->qij',dw2,rc,rc)-np.einsum('qi,qj->qij',dr,np.einsum('qn,qni->qi',w2,rc))-np.einsum('qi,qj->qij',np.einsum('qn,qni->qi',w2,rc),dr)
    dreg=self.ridge*(np.trace(dR,axis1=1,axis2=2)/d+np.sum(dw2,axis=1)*1e-12)
    if self.method=='scalar':
     draw=(-np.trace(dm,axis1=1,axis2=2)-raw*(np.trace(dR,axis1=1,axis2=2)+d*dreg))/den;J[:,:,j]+=gp[:,None]*draw[:,None]*delta
    else:
     dG=-np.linalg.solve(B,(dm+G@(dR+dreg[:,None,None]*I)).swapaxes(1,2)).swapaxes(1,2);J[:,:,j]+=np.einsum('qik,qk->qi',dG,delta)
  else:raise ValueError(self.method)
  out.update(score=value,J=J,div=np.trace(J,axis1=1,axis2=2));return out
