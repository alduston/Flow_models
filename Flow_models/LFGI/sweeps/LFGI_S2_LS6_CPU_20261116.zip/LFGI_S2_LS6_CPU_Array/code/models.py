"""Normalized conditional models, with event/velocity partition fixed by the likelihood."""
import numpy as np
from scipy.special import logsumexp
from sklearn.mixture import GaussianMixture
LOG2PI=np.log(2*np.pi)

def fit_gmm(x,k,seed=84000):
 scale=np.std(x,axis=0);scale=np.maximum(scale,1e-4);mean=x.mean(0);z=(x-mean)/scale
 g=GaussianMixture(k,covariance_type='full',reg_covar=1e-5,n_init=5,max_iter=500,random_state=seed).fit(z)
 return GMM(g.weights_,g.means_*scale+mean,g.covariances_*scale[None,:,None]*scale[None,None,:])
class GMM:
 def __init__(self,w,m,c):
  self.w=w;self.m=m;self.c=c;self.L=np.linalg.cholesky(c);self.P=np.linalg.inv(c);self.d=m.shape[1]
  self.const=np.log(w)-np.log(np.diagonal(self.L,axis1=-2,axis2=-1)).sum(-1)-self.d/2*LOG2PI
 def components(self,x):
  dx=x[:,None,:]-self.m;return self.const-.5*np.einsum('nki,kij,nkj->nk',dx,self.P,dx)
 def logq(self,x):return logsumexp(self.components(x),axis=1)
 def sample(self,n,rng):
  k=rng.choice(len(self.w),n,p=self.w);return self.m[k]+np.einsum('nij,nj->ni',self.L[k],rng.normal(size=(n,self.d)))
 def conditional(self,v,ne=4):
  cv=self.c[:,ne:,ne:];pv=np.linalg.inv(cv);cross=self.c[:,:ne,ne:];reg=cross@pv;cc=self.c[:,:ne,:ne]-reg@self.c[:,ne:,:ne]
  dv=v[:,None,:]-self.m[None,:,ne:];mu=self.m[None,:,:ne]+np.einsum('kij,nkj->nki',reg,dv)
  vv=GMM(self.w,self.m[:,ne:],cv);lw=vv.components(v);lw-=logsumexp(lw,axis=1)[:,None]
  return lw,mu,cc
