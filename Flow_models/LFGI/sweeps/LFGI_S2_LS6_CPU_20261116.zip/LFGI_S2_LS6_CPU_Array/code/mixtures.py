import numpy as np
from scipy.special import logsumexp,gammaln
from models import fit_gmm
class TMixture:
 def __init__(self,w,m,c,nu):
  self.w=w;self.m=m;self.c=c;self.nu=nu;self.d=m.shape[1];self.P=np.linalg.inv(c);self.L=np.linalg.cholesky(c)
 def components(self,x):
  dx=x[:,None]-self.m;delta=np.einsum('nki,kij,nkj->nk',dx,self.P,dx);n=self.nu;d=self.d
  return np.log(self.w)+gammaln((n+d)/2)-gammaln(n/2)-d/2*np.log(n*np.pi)-.5*np.linalg.slogdet(self.c)[1]-(n+d)/2*np.log1p(delta/n)
 def logq(self,x):return logsumexp(self.components(x),1)
 def sample(self,n,rng):
  ids=rng.choice(len(self.w),n,p=self.w);z=rng.normal(size=(n,self.d))/np.sqrt(rng.chisquare(self.nu,n)[:,None]/self.nu)
  return self.m[ids]+np.einsum('nij,nj->ni',self.L[ids],z)
def fit_t(x,k,nu,seed,max_iter=150):
 mean=x.mean(0);scale=np.maximum(x.std(0),1e-4);z=(x-mean)/scale;g=fit_gmm(z,k,seed);w=g.w.copy();m=g.m.copy();c=g.c.copy();previous=-np.inf
 for it in range(max_iter):
  tm=TMixture(w,m,c,nu);ll=tm.components(z);total=logsumexp(ll,1);resp=np.exp(ll-total[:,None]);dx=z[:,None]-m;delta=np.einsum('nki,kij,nkj->nk',dx,np.linalg.inv(c),dx);lam=(nu+z.shape[1])/(nu+delta);rw=resp*lam;mass=resp.sum(0)+1e-12;w=mass/mass.sum();m=(rw.T@z)/(rw.sum(0)[:,None]+1e-12);dx=z[:,None]-m;c=np.einsum('nk,nki,nkj->kij',rw,dx,dx)/mass[:,None,None]+1e-5*np.eye(z.shape[1]);score=float(total.sum())
  if it>4 and abs(score-previous)<1e-5*(1+abs(previous)):break
  previous=score
 return TMixture(w,m*scale+mean,c*scale[None,:,None]*scale[None,None,:],nu)

def select_gmm(x,ks,seed):
 fits=[]
 for k in ks:
  if len(x)<max(10*k,2*x.shape[1]+2):continue
  m=fit_gmm(x,k,seed);p=k*(x.shape[1]+x.shape[1]*(x.shape[1]+1)/2)+k-1;bic=float(-2*m.logq(x).sum()+p*np.log(len(x)));fits.append((bic,m,k))
 bic,m,k=min(fits,key=lambda a:a[0]);return m,dict(K=k,candidates=[dict(K=k,BIC=b) for b,m,k in fits],criterion='bank-only BIC')
def select_t(x,ks,seed):
 gm,gi=select_gmm(x,ks,seed);fits=[(min(a['BIC'] for a in gi['candidates']),gm,'infinity')];d=x.shape[1]
 for k in ks:
  if len(x)<max(10*k,2*d+2):continue
  for nu in [4,8,16]:
   tm=fit_t(x,k,nu,seed);p=k*(d+d*(d+1)/2)+k-1+1;bic=float(-2*tm.logq(x).sum()+p*np.log(len(x)));fits.append((bic,tm,nu))
 bic,m,nu=min(fits,key=lambda a:a[0]);return m,dict(K=len(m.w),nu=nu,candidates=[dict(K=len(m.w),nu=nu,BIC=b) for b,m,nu in fits],criterion='bank-only BIC including Gaussian limit')
