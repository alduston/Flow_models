import os
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
import argparse,fcntl,json,pickle,sys,time,traceback,hashlib,platform
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
from common import ROOT,read,write,save,sha,source_sha,arrays_sha,rng,bridge
from target import TanhIP
from models import GMM,fit_gmm
from mixtures import select_gmm,select_t
from fitted_flow import FittedFlow
from flows import PFModel
from fields import Bank
METHODS=['laplace','gaussian','gmm2','gmm_bic','t_mixture','fitted_flow','gn_mixture','warp3','lfgi','lfgi_legacy_tmin','scalar']
def target():return TanhIP()
def prepare():
 from reference import prepare_reference
 config=read(ROOT/'configs/campaign.json');prepare_reference();acquisition=[];allids={}
 for seed in config['bank_seeds']:
  t=target();x=t.sample(max(config['bank_sizes']),np.random.default_rng(seed));bank_E=t.candidates;post=t.sample(config['posterior_n'],np.random.default_rng(seed+200000));posterior_E=t.candidates-bank_E;s,P=t.bank(x);lp=t.logp(post)
  save(ROOT/f'prepared/seed{seed}.npz',x=x,s=s,P=P,ids=np.arange(len(x)))
  save(ROOT/f'prepared/posterior_seed{seed}.npz',x=post,ids=np.arange(len(post)),logp=lp)
  acquisition.append(dict(seed=seed,bank_rejection_E=bank_E,posterior_rejection_E=posterior_E,bank_EG_H=dict(E=0,G=len(x),H=len(x)),posterior_energy_E=len(post),scope='exact independent rejection groups; prefix E/G/H requirements differ from actual shared maximum-bank acquisition'))
 write(ROOT/'prepared/acquisition.json',dict(groups=acquisition,laplace=read(ROOT/'prepared/laplace.json'),reference_quadrature='separate deterministic evaluation; never used for fitting/tuning'))
 write(ROOT/'prepared/cells.json',[dict(seed=s,N=n,method=m) for s in config['bank_seeds'] for n in config['bank_sizes'] for m in METHODS])
def environment():
 import scipy,sklearn
 return dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,machine=platform.machine())
def identity(spec,inp):
 post=ROOT/f"prepared/posterior_seed{spec['cell']['seed']}.npz"
 return hashlib.sha256((source_sha()+sha(ROOT/'configs/campaign.json')+sha(ROOT/'data/model_spec.json')+sha(post)+sha(ROOT/'prepared/laplace.npz')+json.dumps(environment(),sort_keys=True)+json.dumps(spec,sort_keys=True)+arrays_sha(inp['x'],inp['s'],inp['P'])).encode()).hexdigest()
def paths(cell,label):return ROOT/'results'/label/f"seed{cell['seed']}/N{cell['N']}"/cell['method']
def fit(cell,inp,config,dest,binding,quick=False):
 method=cell['method'];x=inp['x'];seed=50000+cell['seed'];info={};tau=min(config['tau_cap'],float(.5*np.log1p(.01/(1+np.linalg.norm(target().a,2)**2/target().sigma**2))))
 if method=='lfgi_legacy_tmin':tau=config['legacy_tau']
 solver=dict(tau=tau,T=config['T'],rtol=config['rtol'],atol=config['atol'],chunk=config['chunk'],scalar_ridge=config['scalar_ridge'])
 if method=='laplace':
  a=np.load(ROOT/'prepared/laplace.npz');m=GMM(np.array([1.]),a['mean'][None],a['cov'][None]);info['setup']=read(ROOT/'prepared/laplace.json')
 elif method in ['gaussian','gmm2']:m=fit_gmm(x,1 if method=='gaussian' else 2,seed)
 elif method=='gmm_bic':m,info['selection']=select_gmm(x,config['gmm_K'],seed)
 elif method=='t_mixture':m,info['selection']=select_t(x,config['gmm_K'],seed)
 elif method=='fitted_flow':m=FittedFlow(x,seed,epochs=(3 if quick else config['flow_epochs']),quick=quick);info['flow']=m.info
 elif method=='gn_mixture':
  cov=np.linalg.inv(inp['P']);mu=x+np.einsum('nij,nj->ni',cov,inp['s']);m=GMM(np.full(len(x),1/len(x)),mu,cov);info['weights']='equal weights on normalized one-step GN local Gaussian components'
 elif method=='warp3':m=(x.mean(0),np.linalg.cholesky(np.cov(x.T)+1e-6*np.eye(2)))
 else:m=PFModel(Bank(x,inp['s'],inp['P']),'scalar' if method=='scalar' else 'lfgi',solver,dest/'checkpoints',binding)
 info.update(bank_ids=inp['ids'].tolist(),tau=tau,solver=solver,new_fitting_E=0,new_fitting_G=0,new_fitting_H=0,available_cache_rows=len(x),factorization=False,tau_rule='cap plus model-known global GN eigenvalue bound; no held-out/known-Z tuning');return m,info
class EnergyLedger:
 def __init__(self):self.t=target();self.E=0
 def logp(self,x):self.E+=len(x);return self.t.logp(x)
def statistics(lp,lq,lpq,lqq,space='original'):
 b=bridge(lp,lq,lpq,lqq);w=lpq-lqq;r=lp-lq
 return dict(bridge=b,space=space,posterior_count=len(lp),proposal_count=len(lpq),logratio_SD=(float(r.std(ddof=1)) if space=='original' else None),mean_logq_p=(float(lq.mean()) if space=='original' else None),ELBO=(float(w.mean()) if space=='original' else None),ELBO_MCSE=(float(w.std(ddof=1)/np.sqrt(len(w))) if space=='original' and np.isfinite(w).all() else None),entropy_q=(float(-lqq.mean()) if space=='original' else None))
def run_cell(cell,label='production',count=None,repeats=None,quick=False,retry=False):
 config=read(ROOT/'configs/campaign.json');n=cell['N'];base=np.load(ROOT/f"prepared/seed{cell['seed']}.npz");inp={k:base[k][:n] for k in ['x','s','P','ids']};dest=paths(cell,label);dest.mkdir(parents=True,exist_ok=True)
 lock=(dest/'LOCK').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);full=dict(cell=cell,label=label,count=count or config['posterior_n'],repeats=repeats or config['proposal_repeats'],quick=quick);binding=identity(full,inp)
 status=dest/'status.json'
 if status.exists():
  old=read(status)
  if old.get('binding')!=binding:raise RuntimeError('Cell identity mismatch; use a new campaign directory: '+str(dest))
  if old['status']=='COMPLETE':return old
  if old['status']=='FAILED' and not retry:raise RuntimeError('Retained failed cell; diagnose and use explicit --retry-failed: '+str(dest))
 if status.exists():write(dest/'attempts'/('previous_'+str(time.time_ns())+'.json'),read(status))
 write(status,dict(status='RUNNING',binding=binding,cell=cell,started=time.time()));tick=time.time()
 try:
  fitfile=dest/'model.pkl';meta=dest/'fit.json'
  if fitfile.exists():
   ft=read(meta);assert ft['binding']==binding and ft['pickle_sha256']==sha(fitfile)
   with fitfile.open('rb') as f:m=pickle.load(f)
   info=ft['info'];fit_seconds=ft['seconds']
  else:
   ftick=time.time();m,info=fit(cell,inp,config,dest,binding,quick);fit_seconds=time.time()-ftick;tmp=fitfile.with_name('model.pkl.tmp')
   with tmp.open('wb') as f:pickle.dump(m,f,protocol=4)
   os.replace(tmp,fitfile);write(meta,dict(binding=binding,pickle_sha256=sha(fitfile),info=info,seconds=fit_seconds))
  pp=np.load(ROOT/f"prepared/posterior_seed{cell['seed']}.npz");post=pp['x'][:full['count']];lp=pp['logp'][:len(post)];ledger=EnergyLedger();warp=cell['method']=='warp3';nq=count or config['proposal_n'];postfile=dest/'posterior_eval.npz'
  if postfile.exists():a=dict(np.load(postfile));assert str(a['binding'])==binding;lqp=a['logq'];lpp=a['logp'];pstates=a['states'];posterior_E=int(a['E'])
  else:
   if warp:
    mu,L=m;pstates=np.linalg.solve(L,(post-mu).T).T;pstates*=rng(cell['seed'],cell['N'],3).choice([-1,1],len(post))[:,None];lqp=-.5*(pstates*pstates).sum(1)-np.log(2*np.pi);lpp=np.logaddexp(lp,ledger.logp(2*mu-post))-np.log(2)+np.log(np.diag(L)).sum()
   else:
    pstates=post;lpp=lp;lqp=m.logq(post)
   posterior_E=ledger.E;save(postfile,states=pstates,logq=lqp,logp=lpp,E=posterior_E,binding=np.array(binding))
  records=[]
  for rep in range(full['repeats']):
   file=dest/f'repeat{rep:02d}.json';rawfile=dest/f'repeat{rep:02d}.npz'
   if file.exists():r=read(file);assert r['binding']==binding;records.append(r);continue
   rt=time.time();field_start=getattr(m,'calls',0);random=rng(cell['seed'],cell['N'],METHODS.index(cell['method']),rep,4);E0=ledger.E
   if warp:
    q=random.normal(size=(nq,2));lqq=-.5*(q*q).sum(1)-np.log(2*np.pi);lpq=warp_logp(m,q,ledger)
   else:
    if isinstance(m,PFModel):q,lqq=m.sample_logq(nq,random,'proposal_repeat%d'%rep)
    else:q=m.sample(nq,random);lqq=m.logq(q)
    lpq=ledger.logp(q)
   r=statistics(lpp,lqp,lpq,lqq,'warped_symmetrized' if warp else 'original');r.update(binding=binding,repeat=rep,seconds=time.time()-rt,new_E=ledger.E-E0,new_G=0,new_H=0,field_query_calls=getattr(m,'calls',0)-field_start)
   if not r['bridge']['success']:raise ArithmeticError('bridge failure: '+str(r['bridge']))
   if not warp:
    true=read(ROOT/'reference/quadrature.json');r.update(forward_KL=float(np.mean(lpp-lqp)-true['logZ']),reverse_KL=float(true['logZ']-r['ELBO']),logdensity_RMSE=float(np.sqrt(np.mean((lqp-lpp+true['logZ'])**2))),target_entropy=true['entropy'])
   r['bridge_logZ_error']=r['bridge']['logZ']-read(ROOT/'reference/quadrature.json')['logZ']
   save(rawfile,proposal=q,logq=lqq,logp=lpq,binding=np.array(binding));write(file,r);records.append(r)
  roundtrip=None
  if isinstance(m,PFModel):
   a=np.load(dest/'repeat00.npz');check=m.logq(a['proposal'][:config['roundtrip_n']],tag='independent_roundtrip');roundtrip=float(np.max(abs(check-a['logq'][:len(check)])))
   if roundtrip>config['roundtrip_tolerance']:raise ArithmeticError('generation/evaluation log density mismatch: '+str(roundtrip))
  done=dict(roundtrip_logq_max_error=roundtrip,status='COMPLETE' ,binding=binding,cell=cell,fit_seconds=fit_seconds,evaluation_seconds=time.time()-tick,info=info,posterior_E=posterior_E,shared_cache_access=dict(E=0,G=(n if cell['method'] in ['gn_mixture','lfgi','lfgi_legacy_tmin','scalar'] else 0),H=(n if cell['method'] in ['gn_mixture','lfgi','lfgi_legacy_tmin'] else 0)),records=records,environment=environment(),source_sha256=source_sha(),normalization_id='S2_normalized_prior_omitted_likelihood_constant_v1',reference='independent exact-rejection groups; converged deterministic quadrature Z');write(status,done);return done
 except Exception as exc:
  write(status,dict(status='FAILED',binding=binding,cell=cell,error=str(exc),traceback=traceback.format_exc()));raise
 finally:lock.close()
def warp_logp(model,z,ledger):
 mu,L=model;xp=mu+z@L.T;xm=mu-z@L.T;return np.logaddexp(ledger.logp(xp),ledger.logp(xm))-np.log(2)+np.log(np.diag(L)).sum()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','cell']);p.add_argument('--seed',type=int);p.add_argument('--N',type=int);p.add_argument('--method',choices=METHODS);p.add_argument('--label',default='production');p.add_argument('--count',type=int);p.add_argument('--repeats',type=int);p.add_argument('--quick',action='store_true');p.add_argument('--retry-failed',action='store_true');a=p.parse_args()
 if a.action=='prepare':prepare()
 else:run_cell(dict(seed=a.seed,N=a.N,method=a.method),a.label,a.count,a.repeats,a.quick,a.retry_failed)
