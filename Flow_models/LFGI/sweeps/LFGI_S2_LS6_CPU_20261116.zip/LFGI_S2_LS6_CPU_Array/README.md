# Updated S2 comparison on LS6 CPUs

Standalone update of the paper's **two-dimensional tanh inverse problem (S2)**, using the earlier LS6 S2 campaign and the refreshed quake CPU array campaign as implementation references. It can be queued beside quake and the earlier acoustic run in its own directory and environment. No GAD checkout, posterior download, GPU, Torch installation or native C++ extension is required.

## Launch

Copy the ZIP to your sweeps directory. On LS6:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/LFGI/sweeps
unzip LFGI_S2_LS6_CPU_20261116.zip
cd LFGI_S2_LS6_CPU_Array
bash submit.sh
```

The directory may live elsewhere: the launcher resolves its own location and passes it to every job. Do not merge it into an active quake or old LS6 checkout. The supplied defaults are account DMS22021, normal queue, one CPU node per job, Python module python3/3.9.7 and gcc/11.2.0. Its separate venv is `/work/10812/ald4435/ls6/venvs/lfgi_s2_array_cpu_py39`. Nothing in the quake environment or run tree is edited.

Default DAG: **setup → native smoke → 20-task production array → histogram integration → report**. There are five sbatch submissions and normally 24 submitted task slots. The production array covers **660 fits**, with **33 fits in each of 20 cost-balanced tasks**. It uses up to eight cell subprocesses per task, up to four independent 32-query ODE chunks per PF model, and single-threaded BLAS. Scheduling weights are estimates, not measured LS6 runtime predictions. The default four-hour production and two-hour histogram reservations are restartable allowances, not completion promises.

The published normal queue limits are 20 running and 100 submitted jobs per user. The preflight reads live qlimits/QoS where permitted, expands all existing user arrays, and budgets setup/smoke/report/histogram jobs as well as array elements. Existing quake/acoustic jobs count against those same user limits. If submission headroom is reduced, the launcher uses fewer tasks while retaining all 660 fits. The scheduler enforces the combined running limit: two campaigns each allowing 20 array elements do not create an entitlement to 40 simultaneous nodes. If all 20 slots are occupied, the new campaign waits normally. Current policy must be checked with qlimits; official reference: https://docs.tacc.utexas.edu/hpc/lonestar6/ . No jobs have been submitted by the assistant.

For a smaller numerical pilot:

```bash
bash submit.sh --pilot
```

This runs all 11 methods at N=150, seed 22000, using 128 held-out queries and one 128-proposal repeat. It normally creates an 11-element array. Use a separate extracted checkout for simultaneous pilot and production runs; their smoke and submission records are shared within a checkout. `--smoke-only` stops after setup and smoke. `--no-marginals` omits the separate histogram integration stage.

## What is updated

The target, observation realization and normalization are unchanged. Bank seeds **22000–22019** reproduce the previous 20 S2 groups. Bank sizes remain **50, 150, 450**, nested within each group. Each group has an independent exact rejection bank and independent 512-state held-out posterior set, with the same bank/posterior seeds as before. The old group-00 bank, clean scores, GN matrices and held-out states are included as a regression fixture. These are independent rejection groups, unlike quake's randomizations of a fixed NUTS archive.

Every fitted model uses the same N posterior locations for its group. Cached exact clean scores and GN matrices are supplied at those locations; derivative-informed competitors can use them. Fitted models use their own internal bank validation or bank-only BIC. Neither the 512 held-out states nor quadrature evidence enters proposal fitting or model selection. Each fit has **five independent 512-proposal repeats**; those repeats are nested Monte Carlo evaluations, not five new fits.

| Method | Definition / selection | Information beyond bank locations |
|---|---|---|
| MAP-Laplace | Target-only mode and exact local Hessian; shared cached fit | Extra target E/G/H calls, logged separately |
| Fitted Gaussian | Full covariance MLE, with fixed numerical regularization | None |
| Two-component GMM | Fixed K=2, full covariances, five EM initializations | None |
| Selected GMM | K in {1,2,4,8}, bank-only BIC, five EM initializations | None |
| Selected t/Gaussian mixture | K in {1,2,4,8}, nu in {4,8,16}, Gaussian limit included; bank-only BIC | None |
| Validated fitted flow | 2D affine coupling: 4/6 layers, width 32/64, two initializations, internal validation and full-bank refit | None |
| GN local mixture | Equal mixture of normalized Gaussian tangent models, centers x + H_GN^-1 s and covariances H_GN^-1 | Cached score and GN matrix |
| Warp-III bridge | Gaussian affine whitening and random sign symmetrization; transformed standard-normal proposal | Additional target E calls, including reflections |
| LFGI, small endpoint | Original joint OU weights and GN gate; matched generation and density evaluation | Cached score and GN matrix |
| LFGI, old endpoint | Same field, tau=0.001 control | Cached score and GN matrix |
| Scalar gate, small endpoint | Earlier empirical scalar gate, frozen ridge=0.0001; same endpoint/solver protocol as LFGI | Cached score |

The small endpoint is `min(1e-6, 0.5*log1p(0.01/L_global))`, where `L_global = 1 + ||A||_2^2/sigma^2` bounds the S2 GN curvature because tanh's derivative is at most one. Here the 1e-6 cap binds. This uses model-known constants and does not require scalar-gate access to bank Hessians. All numerical models use T=8, DOP853 in log time, rtol=1e-8 and atol=1e-10. The old-endpoint control uses the same tightened solver, isolating endpoint effects from solver effects. No zero-time density is attached to particles generated at a different cutoff.

The implementation retains dominant-particle centering in weighted score/position covariances and analytic derivatives of the full empirical field, including derivatives of the weights and gate. The scalar gate's frozen ridge and smooth clipping are preserved. A factorized or conditional weighting model is **not used** for S2. See `docs/METHODS_AND_INTERPRETATION.md`.

## Evidence, KL and entropy

A deterministic quadrature reference is recomputed during setup, at several domains/orders, and compared to the archived reference. The convention is a normalized N(0,I2) prior and likelihood exp(-Phi), omitting the Gaussian observation constant. Its log evidence is approximately **-2.127379376772**. To include the normalized two-observation Gaussian likelihood, add `-log(2*pi*sigma^2)` to log Z and ELBO; KL values are unchanged.

Reported metrics include absolute bridge log-Z error/RMSE, within-fit bridge repeat SD, overlap, direct importance and reciprocal estimates, normalized posterior log-density RMSE, centered log-ratio SD, forward KL, reverse KL, ELBO and surrogate entropy. Finite Monte Carlo KL estimates may be negative; they are retained without clipping. Entropy of the true posterior is also available by quadrature, but surrogate entropy is an attribute of q, not automatically an estimator of target entropy. Warp-III estimates the same evidence after transformation/symmetrization; no original-coordinate density, entropy or KL statistic is assigned to it.

Uncertainty uses independent bank/held-out groups. The report bootstraps bank-level means (and bank-level mean squared evidence errors), with proposal repeats nested inside each bank. Paired LFGI-versus-baseline differences use matching groups. Missing/failed cells remain explicit; nominal 20-group uncertainty is not claimed from fewer complete pairs. Post-processing costs conditional on supplied posterior samples are separated from rejection/reference acquisition, shared derivative acquisition and the shared Laplace fit. This is not an end-to-end posterior sampler speed comparison.

## Actual and implicit 2D histograms

The histogram job uses one predeclared group, seed 22000, at N=50 and N=450, without pooling banks. It creates two genuinely different displays for every completed normalized model:

1. **Actual particle histograms:** 8192 fresh draws from each frozen proposal.
2. **Implicit density histograms:** integrate evaluated model densities over the same bins using one shared mixture proposal. The integration proposal is an equal mixture of all displayed normalized models, using 512 draws from each component and balance weights q_model/r. Each model weight is bounded by the number of mixture components. This avoids a coarse Cartesian grid missing narrow scalar-gate peaks, while still checking the implied density independently of that model's own particle histogram.

Raw integral weights are retained, with total mass estimates, stratified Monte Carlo standard errors, integration ESS diagnostics, and generation/evaluation agreement checks. No in-window or total-mass renormalization is applied. All panels share bins and a color scale set by a separate exact-rejection reference. The target's implicit panel uses evaluated normalized target density; Warp-III is omitted from original-coordinate density panels. Cubature is still a finite Monte Carlo approximation: inspect the reported mass/MCSE alongside shape. Each plot is a single-bank display, not a replicated performance conclusion.

## Validation and monitoring

The full native smoke checks frozen sources, old input reproduction, target gradients/Hessians, Gaussian cancellation at concentrated weights, analytic field divergences, fitted-flow MLE gradients and inverse Jacobians, every model adapter, generation/evaluation agreement, tighter ODE tolerances, serial/parallel equality, checkpoint resumption and complete task routing. Production is dependency-blocked until smoke passes. Each numerical production fit independently re-evaluates up to 16 generated states and fails if max log-density disagreement exceeds 0.001. Local checks are summarized in `provenance/LOCAL_VALIDATION.json`; native LS6 execution remains unverified until your smoke passes.

```bash
cat logs/submitted_ids.txt
squeue -r -u "$USER"
sacct -X -j SMOKE_ID,ARRAY_ID --format=JobID,JobName%24,State,Elapsed,ExitCode
tail -n 40 logs/s2-smoke-*.out
tail -n 40 logs/s2-smoke-*.err
ls logs/production_task*_progress.json
```

Mock routing output is explicitly labeled as mock execution. The smoke prints `NATIVE NUMERICAL SMOKE PASSED` only after the actual numerical checks finish. Production results live under `results/production/seed*/N*/METHOD/`. Report outputs include `REPORT.md`, `summary.json`, `per_repeat.csv`, `paired_improvements.csv`, `comparison.png`, `status.json`, actual/implicit histogram figures and `histogram_integration.json` under `reports/production/`.

The launcher contains the LS6 banner-safe job-ID parser and raw submission logs. If an sbatch response is ambiguous, inspect the saved raw output and queue before retrying: an accepted job may exist. To finish a partially submitted graph with an accepted setup job, run:

```bash
python3 resume_submission.py --setup ACCEPTED_SETUP_ID
```

This verifies setup's name/state/directory, reuses completed successful setup without an obsolete dependency and records/reuses already accepted children. Use the same `--pilot` or `--no-marginals` options if used originally. Do not run a second launcher while its recorded jobs are active.

## Resume and retrieve

ODE checkpoints, serialized fits and repeat files resume only when the data/config/source/runtime identity matches. Completed cells are skipped. Scientific failures are retained and require diagnosis before explicit retry with `export S2_RETRY_FAILED=1`. Incomplete wall-time kills resume from saved chunks. Once all previously submitted jobs are terminal, rerun `bash submit.sh` to continue. If a failed setup/smoke leaves descendants dependency-blocked, inspect and cancel those exact blocked jobs first. Do not overwrite frozen sources/configs in an active tree.

Run compact export on a compute node after the campaign:

```bash
python pack_results.py
```

Independent result ZIPs stay below 25 MB; `--include-models` includes model/checkpoint payload. From your workstation:

```bash
scp 'ald4435@ls6.tacc.utexas.edu:/work/10812/ald4435/frontera/Flow_models/Flow_models/LFGI/sweeps/LFGI_S2_LS6_CPU_Array/exports/*' .
```

Optional overrides before submission: `S2_ARRAY_TASKS`, `S2_ARRAY_CONCURRENCY`, `S2_WORKERS`, `S2_CHUNK_WORKERS`, `S2_WALL`, `S2_SMOKE_WALL`, `S2_MARGINALS_WALL`, `S2_CPU_VENV`, `S2_ACCOUNT`, `S2_QUEUE`, `S2_GCC_MODULE`, `S2_PYTHON_MODULE`. Use a normal-queue preflight unless explicit current limits are supplied for another queue. The LS6 billing minimum means splitting work into more nodes improves potential elapsed time but does not itself guarantee lower allocation usage.
