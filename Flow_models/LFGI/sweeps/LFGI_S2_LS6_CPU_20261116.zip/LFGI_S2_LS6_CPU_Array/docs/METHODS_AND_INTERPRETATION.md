# Scientific scope and integration notes

S2 is the tanh inverse problem, not the high-dimensional seismic model and not the acoustic source inverse. The likelihood and standard normal prior are recovered from the earlier LS6 execution source. Rejection samples provide exact independent groups, while quadrature provides a separate converged evidence/entropy reference.

The quake discovery motivates rechecking the terminal cutoff and the competitiveness of density/bridge baselines; it does not establish that S2 needs factorized weights. This campaign deliberately keeps the original joint kernel weights. A factorized weighting scheme would add unnecessary structure in this two-dimensional problem and change the comparison being tested.

## Separating causes

The new primary LFGI fit ends at tau=1e-6, with tau selected from the same fixed model-bound rule as the scalar comparator. The old-endpoint arm ends at tau=0.001. Both use the same integration tolerances and dominant-point centering. A paired difference between these arms therefore tests endpoint effects conditional on the fixed S2 bank and numerical implementation. It does not retune either arm against known evidence.

The scalar field retains the original bank regression objective: weights squared, weighted centering, ridge=0.0001 and the original differentiable clipping. It receives the same exact clean scores. The LFGI field receives the cached GN matrices H=I+J^T J. The GN-mixture competitor receives those same score/GN rows, then constructs normalized local Gaussian components. This directly tests whether simple access to local derivative information is sufficient to account for the result.

Raw Hessian inversion without PSD safeguards is not included as an extra gate arm. Exact Hessians are used for the conventional MAP-Laplace fit and derivative validation, with all target calls charged separately. The experiment does not resolve which exact-Hessian gate would perform best. It does not test a generic high-dimensional superiority claim.

## Stronger proposals and fair fitting

Fixed K=2 GMM reproduces the old baseline class; the selected GMM and selected t/Gaussian mixture allow more appropriate complexity and tails. BIC uses bank locations only. The finite candidate grid is frozen before the production run. The t-mixture search includes a Gaussian limit, and all models have explicit normalized log densities and samplers.

The fitted-flow architecture is based on the quake NumPy coupling implementation, adapted to two alternating scalar coordinates. Candidate selection uses only the 80/20 internal bank split. Early stopping and model selection use validation NLL, then the chosen architecture/epoch is refit on the full bank. No held-out production posterior states, proposal metrics or reference evidence select the model. Analytic training derivatives and inverse Jacobians are independently checked. This is a finite architecture/training budget, not a claim that all normalizing-flow designs have been exhausted.

Warp-III follows the established affine-whitening and random-sign symmetrization construction already used in quake. If x is from the posterior, z=sign*L^-1(x-mu) is from the normalized symmetrized transformed target. Its unnormalized log density is logaddexp(log p(mu+Lz),log p(mu-Lz))-log 2+log|L|. The standard-normal proposal is normalized. This changes neither the target evidence nor its units. Density-shape and KL plots in original coordinates do not apply to this bridge-only arm.

No Warp-U implementation is silently substituted or claimed. The bridge equation itself is the common stabilized optimal bridge equation for every proposal, so the experiment compares proposal construction under the same evaluation allocation.

## Numerical model and endpoints

The normalized surrogate is the pushforward of a standard normal at T=8 under the frozen empirical probability-flow ODE, ending at tau. Its inverse ODE and the full analytic divergence define its density at that same tau. It approximates the clean posterior as tau becomes small; neither finite T nor nonzero tau is mathematically zero. The old endpoint is explicitly a control, not an alternative density convention.

At concentrated weights, dominant-particle centering prevents subtracting nearly equal large empirical moments. The LFGI expression uses algebraic cancellation instead of subtracting 1/g terms. GN curvature is PSD and the S2 prior contributes I; no raw indefinite exact-Hessian gate is inverted. Full derivatives of weights and gate enter divergence. The Gaussian regression test verifies the exact affine cancellation case even with ESS effectively one. ESS alone is not a surrogate-quality criterion.

Initial local accuracy testing caught a scalar-gate generation/evaluation discrepancy at N=450 using the looser quake-style tolerances. The shared S2 tolerances were tightened based on numerical consistency, without looking at production evidence error, and the final settings are rechecked against a solver with tolerances twenty times tighter. Per-cell roundtrip failures remain failures; they are not dismissed as Monte Carlo variance.

## What to carry into the paper

Replace S2 numbers only after the native smoke and full bank matrix finish, with complete/failed/missing counts retained. Compare LFGI with the best competitive baseline using paired group uncertainty; report the legacy endpoint arm to distinguish changed numerical specification from changed competitors. Plot bridge log-evidence RMSE against the fixed quadrature reference, and forward/reverse KL with the proper orientation and nested proposal uncertainty.

Use the single-bank actual/implicit density histograms to show what the score and normalized flow imply. Inspect the generation/evaluation guard and implicit integral mass before interpreting visual shape. Better evidence repeat variance is not automatically evidence accuracy: S2 has a reference and therefore should use absolute error. Surrogate entropy is not target entropy without a correction argument. A favorable result here does not establish the corresponding result for acoustic or quake.

Retain the score-estimation framing of the LFGI paper. This experiment is an application of the fixed score estimator to normalized density surrogates and evidence/entropy diagnostics, not a replacement for the paper's variance-reduction objective. No manuscript changes are performed by this bundle.
