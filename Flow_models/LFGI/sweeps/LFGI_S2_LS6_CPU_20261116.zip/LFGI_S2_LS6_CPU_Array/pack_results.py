"""Create independent result ZIPs below 24 MB; model/checkpoint payload optional."""
import argparse,hashlib,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent;p=argparse.ArgumentParser();p.add_argument('--include-models',action='store_true');p.add_argument('--output',type=Path,default=R/'exports');a=p.parse_args();a.output.mkdir(exist_ok=True,parents=True)
files=[]
for folder in ['results','reports','reference','logs','configs','provenance','prepared']:
 for f in (R/folder).rglob('*'):
  if folder=='prepared' and f.suffix!='.json':continue
  if not f.is_file() or f.name=='LOCK' or '.tmp.' in f.name:continue
  if not a.include_models and (f.suffix=='.pkl' or 'checkpoints' in f.parts or '.checkpoint.' in f.name):continue
  files.append(f)
cap=23_000_000;parts=[];group=[];total=0
for f in sorted(files):
 if f.stat().st_size>cap:raise SystemExit('Single file exceeds cap; omit model/checkpoint payload or split it explicitly: '+str(f))
 if group and total+f.stat().st_size>cap:parts.append(group);group=[];total=0
 group.append(f);total+=f.stat().st_size
if group:parts.append(group)
manifest=[]
for k,group in enumerate(parts,1):
 path=a.output/('S2_LS6_results_%03d.zip'%k)
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for f in group:z.write(f,'LFGI_S2_LS6_CPU_Array/'+str(f.relative_to(R)))
 assert path.stat().st_size<25_000_000
 manifest.append(dict(file=path.name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(a.output/'INDEX.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
