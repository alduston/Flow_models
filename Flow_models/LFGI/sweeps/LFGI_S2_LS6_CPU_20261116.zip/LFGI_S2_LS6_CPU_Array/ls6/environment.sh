#!/bin/bash
if [[ "${S2_SKIP_MODULES:-0}" != 1 ]]; then
 module purge
 module load "${S2_GCC_MODULE:-gcc/11.2.0}" "${S2_PYTHON_MODULE:-python3/3.9.7}"
fi
export S2_CPU_VENV="${S2_CPU_VENV:-/work/10812/ald4435/ls6/venvs/lfgi_s2_array_cpu_py39}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 MPLBACKEND=Agg PYTHONUNBUFFERED=1 CUDA_VISIBLE_DEVICES=""

# Independent 16-query ODE solves run in parallel, with BLAS still single-threaded.
export S2_CHUNK_WORKERS="${S2_CHUNK_WORKERS:-4}"
