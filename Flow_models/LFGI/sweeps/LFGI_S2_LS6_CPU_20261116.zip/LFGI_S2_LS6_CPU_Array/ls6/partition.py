"""Deterministic bounded-size, cost-balanced fit partition; no scientific inputs changed."""
import hashlib,json,math
from pathlib import Path
METHOD_COST={'laplace':.01,'gaussian':.01,'gmm2':.05,'gmm_bic':.15,'t_mixture':.5,'fitted_flow':.5,'gn_mixture':.1,'warp3':.05,'lfgi':3.,'lfgi_legacy_tmin':2.,'scalar':12.}
def key(c):return (int(c['seed']),int(c['N']),c['method'])
def effort(c,chunks=4):
 w=METHOD_COST[c['method']]
 if c['method'] in ['lfgi','lfgi_legacy_tmin','scalar']:w/=chunks
 return w*(c['N']/450.)**(1.1 if c['method'] in ['lfgi','lfgi_legacy_tmin','scalar'] else 1.)
def build(cells,count,chunks=4):
 count=min(int(count),len(cells))
 if count<1:raise ValueError('at least one array task required')
 quotas=[len(cells)//count+(i<len(cells)%count) for i in range(count)];bins=[[] for _ in range(count)];loads=[0.]*count
 for c in sorted(cells,key=lambda c:(-effort(c,chunks),key(c))):
  i=min((i for i in range(count) if len(bins[i])<quotas[i]),key=lambda i:(loads[i],len(bins[i]),i));bins[i].append(c);loads[i]+=effort(c,chunks)
 assert sorted(key(c) for b in bins for c in b)==sorted(key(c) for c in cells)
 return dict(tasks=count,chunk_workers=chunks,quotas=quotas,estimated_relative_load=loads,shards=bins,weight_scope='static relative scheduling estimates; not benchmarked LS6 runtimes')
def fingerprint(plan):return hashlib.sha256(json.dumps(plan,sort_keys=True).encode()).hexdigest()
