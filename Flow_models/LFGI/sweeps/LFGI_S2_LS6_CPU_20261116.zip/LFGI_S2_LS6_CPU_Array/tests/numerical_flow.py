import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,tempfile
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from common import read,write
from fields import Bank
from flows import PFModel,integrate
from target import TanhIP
from models import GMM

config=read(R/'configs/campaign.json');a=np.load(R/'prepared/seed22000.npz');post=np.load(R/'prepared/posterior_seed22000.npz')['x'];records=[]
with tempfile.TemporaryDirectory() as temp:
 root=Path(temp)
 for n in [50,450]:
  bank=Bank(a['x'][:n],a['s'][:n],a['P'][:n])
  for method in ['lfgi','scalar']:
   base=dict(tau=1e-6,T=8.,rtol=config['rtol'],atol=config['atol'],chunk=8,scalar_ridge=.0001);tight=dict(base,rtol=base['rtol']/20,atol=base['atol']/20);os.environ['S2_CHUNK_WORKERS']='1';m=PFModel(bank,method,base,root/f'{n}_{method}_base','test');ref=PFModel(bank,method,tight,root/f'{n}_{method}_tight','test');lb=m.logq(post[:8]);lt=ref.logq(post[:8]);err=float(np.max(abs(lb-lt)));assert err<1e-3,(n,method,err)
   q,lq=m.sample_logq(8,np.random.default_rng(77),'draws');roundtrip=float(np.max(abs(m.logq(q,tag='inverse_check')-lq)));assert roundtrip<1e-3,(n,method,roundtrip)
   records.append(dict(N=n,method=method,endpoint=base['tau'],tightened_logq_max_difference=err,roundtrip_max_error=roundtrip))
 # Independent chunks must give identical scientific answers across worker counts.
 bank=Bank(a['x'][:150],a['s'][:150],a['P'][:150]);cfg=dict(base);y=post[:16];os.environ['S2_CHUNK_WORKERS']='1';serial=integrate(bank,y,'lfgi',False,cfg,root/'serial','chunk_test');os.environ['S2_CHUNK_WORKERS']='2';parallel=integrate(bank,y,'lfgi',False,cfg,root/'parallel','chunk_test');assert all(np.array_equal(x,y) for x,y in zip(serial,parallel));cached=integrate(bank,y,'lfgi',False,cfg,root/'parallel','chunk_test');assert all(np.array_equal(x,y) for x,y in zip(cached,parallel))
 # Analytic transported Gaussian law, including finite T and endpoint tau.
 mu=np.array([.4,-.7]);C=np.array([[.3,.1],[.1,.8]]);P=np.linalg.inv(C);xx=np.random.default_rng(5).normal(size=(5,2));bank=Bank(xx,-(xx-mu)@P,np.repeat(P[None],len(xx),axis=0));tau=cfg['tau'];T=cfg['T'];Ct=np.exp(-2*tau)*C-np.expm1(-2*tau)*np.eye(2);CT=np.exp(-2*T)*C-np.expm1(-2*T)*np.eye(2);cov=Ct@np.linalg.inv(CT);ev,U=np.linalg.eigh(cov);A=(U*np.sqrt(ev))@U.T;mean=np.exp(-tau)*mu-A@(np.exp(-T)*mu);known=GMM(np.array([1.]),mean[None],cov[None]);m=PFModel(bank,'lfgi',cfg,root/'gaussian','gaussian_test');z=post[:8];err=float(np.max(abs(m.logq(z)-known.logq(z))));assert err<1e-5,err
write(R/'logs/numerical_flow_checks.json',dict(passed=True,checks=records,parallel_bitwise=True,checkpoint_resume_bitwise=True,analytic_finite_endpoint_gaussian_logq_max_error=err,scope='small held-out arrays; full production per-cell roundtrip guard also required'))
print('Tightened tolerances, density/generation, independent chunks, checkpoint resume and analytic Gaussian flow passed')
