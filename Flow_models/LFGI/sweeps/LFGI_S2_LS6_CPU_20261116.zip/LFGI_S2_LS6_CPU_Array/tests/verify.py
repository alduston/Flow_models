import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from common import write
from target import TanhIP
from models import GMM
from fitted_flow import CouplingFlow
from fields import Bank,Field
from reference import quadrature

t=TanhIP();a=np.load(R/'tests/previous_group00_fixture.npz');x=t.sample(450,np.random.default_rng(22000));posterior=t.sample(512,np.random.default_rng(222000));s,P=t.bank(x)
for actual,k in [(x,'x'),(s,'s'),(P,'P'),(posterior,'posterior')]:assert np.allclose(actual,a[k],rtol=1e-13,atol=1e-13),k
random=np.random.default_rng(123);z=random.normal(size=(5,2));h=1e-5;eye=np.eye(2);score_fd=np.column_stack([(t.logp(z+h*e)-t.logp(z-h*e))/(2*h) for e in eye]);assert np.max(abs(t.score(z)-score_fd))<1e-7
Hfd=np.stack([-(t.score(z+h*e)-t.score(z-h*e))/(2*h) for e in eye],axis=2);assert np.max(abs(Hfd-t.exact_hessian(z)))<1e-6 and np.linalg.eigvalsh(P).min()>.99999
q=quadrature(10,256);prev=json.loads((R/'provenance/previous_reference.json').read_text());assert abs(q['logZ']-prev['logZ'])<1e-9
# Exact Gaussian cancellation at arbitrarily concentrated empirical weights.
mu=np.array([.4,-.7]);C=np.array([[.3,.1],[.1,.8]]);Prec=np.linalg.inv(C);xx=random.normal(size=(7,2));bank=Bank(xx,-(xx-mu)@Prec,np.repeat(Prec[None],len(xx),axis=0));gauss_error=0.
for time in [1e-6,.001,.03,.5,8.]:
 alpha=np.exp(-time);g=-np.expm1(-2*time);Ct=alpha*alpha*C+g*np.eye(2);out=Field(bank)(z,time);expected=-(z-alpha*mu)@np.linalg.inv(Ct);gauss_error=max(gauss_error,float(np.max(abs(out['score']-expected))));assert np.max(abs(out['score']-expected))<1e-8 and np.max(abs(out['div']+np.trace(np.linalg.inv(Ct))))<1e-7
# Include weight/gate derivatives in both divergences.
bank=Bank(x[:50],s[:50],P[:50]);derivatives={}
for method in ['lfgi','scalar']:
 f=Field(bank,method);errors=[]
 for time in [.001,.03,.5]:
  y=x[50:54];fd=np.stack([(f(y+h*e,time)['score']-f(y-h*e,time)['score'])/(2*h) for e in eye],axis=2);analytic=f(y,time)['J'];err=np.max(abs(fd-analytic)/(1+abs(analytic)));errors.append(float(err));assert err<2e-4,(method,time,err)
 derivatives[method]=errors
# Reverse-mode MLE derivative and inverse Jacobian for the new 2D fitted flow.
f=CouplingFlow(4,5,4)
for par in f.params:
 for v in par:v+=random.normal(size=v.shape)*.05
zz=random.normal(size=(6,2));loss,gr=f.forward(zz,True);graderr=0.
for j,par in enumerate(f.params):
 for k,p in enumerate(par):
  ix=tuple(0 for _ in p.shape);old=p[ix];eps=1e-6;p[ix]=old+eps;u=-f.forward(zz).mean();p[ix]=old-eps;v=-f.forward(zz).mean();p[ix]=old;err=abs((u-v)/(2*eps)-gr[j][k][ix]);graderr=max(graderr,float(err));assert err<1e-6,(j,k,err)
for y in zz:
 end=f.inverse(y[None])[0];jac=np.column_stack([(f.inverse((y+1e-6*e)[None])[0]-f.inverse((y-1e-6*e)[None])[0])/(2e-6) for e in eye]);expected=-.5*y@y-np.log(2*np.pi)-np.linalg.slogdet(jac)[1];assert abs(f.forward(end[None])[0]-expected)<1e-7
write(R/'logs/local_unit_checks.json',dict(passed=True,old_bank_and_heldout_fixture=True,target_score_hessian=True,reference_logZ=q['logZ'],gaussian_score_max_error=gauss_error,field_relative_J_errors=derivatives,flow_gradient_max_error=graderr,flow_inverse_density=True))
print('Target/old-input regression, quadrature, score/divergence, fitted-flow gradients and inverse Jacobians passed')
