import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['S2_CHUNK_WORKERS']='4';os.environ['S2_WORKERS']='8'
import sys,tempfile,json,contextlib,io
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'));sys.path.insert(0,str(R/'ls6'))
import driver
from common import write,sha,source_sha
from partition import key
from campaign import METHODS
cells=[dict(seed=s,N=n,method=m) for s in range(22000,22020) for n in [50,150,450] for m in METHODS]
seen=[]
with tempfile.TemporaryDirectory() as temp:
 B=Path(temp);driver.B=B;driver.check=lambda:{}
 write(B/'logs/smoke_passed.json',dict(passed=True,source_sha256=source_sha(),environment={},orchestration_sha256=sha(Path(driver.__file__)),chunk_workers=4,recommended_workers=8));write(B/'prepared/cells.json',cells);write(B/'configs/campaign.json',dict(pilot_seed=22000,pilot_N=150))
 def fake(c,*args,**kw):seen.append(c);return dict(**c,status='COMPLETE',returncode=0)
 driver.launch=fake
 with contextlib.redirect_stdout(io.StringIO()):
  for i in range(20):driver.production('production',task_index=i,task_count=20)
 assert sorted(map(key,seen))==sorted(map(key,cells));assert len(list((B/'logs').glob('production_task*_progress.json')))==20;assert len(list((B/'logs').glob('production_task*_partition_*.json')))==20
 seen.clear()
 with contextlib.redirect_stdout(io.StringIO()):
  for i in range(11):driver.production('pilot',task_index=i,task_count=11)
 assert len(seen)==11 and all(c['seed']==22000 and c['N']==150 for c in seen)
write(R/'logs/task_routing_checks.json',dict(passed=True,production_tasks=20,production_cells=660,pilot_tasks=11,pilot_cells=11,distinct_task_outputs=True,remote_jobs_submitted=False))
print('MOCK ROUTING CHECK ONLY: all 660 cells covered once; these are not production results')
