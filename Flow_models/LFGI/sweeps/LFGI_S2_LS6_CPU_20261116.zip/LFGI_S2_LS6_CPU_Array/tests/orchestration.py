import os,sys,tempfile,json,subprocess,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'));sys.path.insert(0,str(R/'ls6'))
from common import write
from partition import build,key
cells=[dict(seed=s,N=n,method=m) for s in range(22000,22020) for n in [50,150,450] for m in ['laplace','gaussian','gmm2','gmm_bic','t_mixture','fitted_flow','gn_mixture','warp3','lfgi','lfgi_legacy_tmin','scalar']]
for k in [1,3,7,20,25]:
 plan=build(cells,k);flat=[key(c) for b in plan['shards'] for c in b];assert len(flat)==len(set(flat))==660 and max(map(len,plan['shards']))-min(map(len,plan['shards']))<=1
assert sorted(map(len,build(cells,20)['shards']))==[33]*20

def case(existing=0,max_submit=100,reference=False,pilot=False,expected_tasks=20,max_run=20,output="plain"):
 with tempfile.TemporaryDirectory() as temp:
  d=Path(temp);shutil.copy(R/'submit.sh',d);(d/'bin').mkdir();(d/'ls6').mkdir();(d/'configs').mkdir()
  for n in ['job.sh','limits.py','parse_sbatch.py']:shutil.copy(R/'ls6'/n,d/'ls6'/n)
  shutil.copy(R/'configs/RUN_MATRIX.csv',d/'configs/RUN_MATRIX.csv')
  scripts={
  'sbatch':'''#!/usr/bin/env python3
import os,json,sys
from pathlib import Path
p=Path(os.environ['MOCK_ROOT']);f=p/'counter';n=int(f.read_text())+1 if f.exists() else 1;f.write_text(str(n))
with (p/'calls.jsonl').open('a') as o:o.write(json.dumps(sys.argv[1:])+'\\n')
style=os.getenv('MOCK_OUTPUT','plain')
if style=='banner':print('Welcome to the Lonestar6 Supercomputer\\n--> Checking available allocation (DMS22021)...OK')
if style=='cluster':print(str(1000+n)+';ls6')
elif style=='submitted':print('Submitted batch job '+str(1000+n))
else:print(1000+n)
''',
  'squeue':'''#!/usr/bin/env python3
import os,sys
if '-j' in sys.argv:
 if os.getenv('MOCK_ACTIVE')=='1':print('active')
else:
 for i in range(int(os.getenv('MOCK_EXISTING','0'))):print(f'{2000+i}|normal|PENDING')
''',
  'qlimits':'''#!/usr/bin/env python3
import os
print('normal MaxJobsPU='+os.environ['MOCK_MAX_RUN']+' MaxSubmitPU='+os.environ['MOCK_MAX_SUBMIT'])
''',
  'sacctmgr':'''#!/usr/bin/env python3
import os
print('normal|'+os.environ['MOCK_MAX_RUN']+'|'+os.environ['MOCK_MAX_SUBMIT']+'|')
''',
  'scontrol':'''#!/usr/bin/env python3
import sys
print('PartitionName=normal QoS=normal' if 'partition' in sys.argv else 'MaxArraySize = 1001')
'''}
  for n,t in scripts.items():p=d/'bin'/n;p.write_text(t);p.chmod(0o755)
  env=os.environ.copy();env.update(PATH=str(d/'bin')+os.pathsep+env['PATH'],MOCK_ROOT=str(d),MOCK_EXISTING=str(existing),MOCK_MAX_SUBMIT=str(max_submit),MOCK_MAX_RUN=str(max_run),MOCK_OUTPUT=output)
  for k in list(env):
   if k.startswith('S2_'):del env[k]
  args=['bash','submit.sh']+(['--with-reference'] if reference else [])+(['--pilot'] if pilot else []);result=subprocess.run(args,cwd=d,env=env,capture_output=True,text=True)
  if expected_tasks==0:
   assert result.returncode!=0 and not (d/'counter').exists(),result.stdout+result.stderr;return
  assert result.returncode==0,result.stdout+result.stderr;calls=[json.loads(x) for x in (d/'calls.jsonl').read_text().splitlines()];assert len(calls)==5+int(reference)
  stages={c[-2]:c for c in calls};work='pilot' if pilot else 'production';cap=min(expected_tasks,max_run-int(reference));assert '--array=0-%d%%%d'%(expected_tasks-1,cap) in stages[work]
  assert '--dependency=afterok:1002' in stages[work] and '--dependency=afterany:1003' in stages['marginals'];assert stages['report'][stages['report'].index('-J')+1]=='s2-report'
  dep='--dependency=afterany:1003:1004'+(':1005' if reference else '');assert dep in stages['report'];assert all(c[c.index('-N')+1]=='1' and c[c.index('-n')+1]=='1' for c in calls)
  pre=json.loads((d/'logs/submission_preflight.json').read_text());assert pre['new_task_slots']+existing<=max_submit
  env['MOCK_ACTIVE']='1';rr=subprocess.run(['bash','submit.sh'],cwd=d,env=env,capture_output=True);assert rr.returncode!=0 and int((d/'counter').read_text())==len(calls)
case();case(output="banner");case(output="cluster");case(output="submitted");case(existing=80,expected_tasks=16);case(existing=94,expected_tasks=2);case(existing=96,expected_tasks=0);case(max_submit=50,existing=38,expected_tasks=8);case(max_run=10);case(pilot=True,expected_tasks=11)
assert 'python ls6/driver.py "$stage" --profile "$profile"' in (R/'ls6/job.sh').read_text()
write(R/'logs/array_orchestration_checks.json',dict(passed=True,coverage=660,default_array_tasks=20,default_new_task_slots=24,default_concurrency=20,optional_reference_concurrency=19,live_lower_limit_tests=True,headroom_reduction_tests=True,duplicate_guard=True,array_dependency_tests=True,marginals_dispatch=True,remote_jobs_submitted=False))
print('Array partition, queue limits/headroom, DAG, duplicate and dispatch tests passed')
