"""End-to-end model fitting, pickle resume, q draws, density, and bridge adapters."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,time,tempfile,shutil
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'code'))
from common import write,read
from campaign import METHODS,run_cell,paths
label='adapter_validation_'+str(time.time_ns());rows=[]
for method in METHODS:
 c=dict(seed=22000,N=50,method=method);row=run_cell(c,label,count=8,repeats=1,quick=True);assert row['status']=='COMPLETE';again=run_cell(c,label,count=8,repeats=1,quick=True);assert again['binding']==row['binding'];rows.append(dict(method=method,status=row['status'],roundtrip_logq_max_error=row['roundtrip_logq_max_error']))
# Run report and actual-versus-density histogram code on numerical output, not mocked cells.
import report,marginals
old=read(R/'configs/campaign.json')
# Visualization and reporting must work for arbitrary labels and partial completed cells.
report.report(label)
# The small visualization checks the N=50 display; N=450 is intentionally missing and reported.
marginals.run(label,small=True)
assert (R/'reports'/label/'actual_density_N50.png').exists()
assert (R/'reports'/label/'implicit_density_N50.png').exists()
info=read(R/'reports'/label/'histogram_integration.json');assert info['sizes']['50']['status']=='complete'
write(R/'logs/adapter_checks.json',dict(passed=True,checks=rows,label=label,quick_flow=True,real_fits_draws_densities_bridge=True,pickle_resume=True,report=True,actual_and_implicit_histograms=True,validation_scope='small query counts and three-epoch fitted-flow smoke, not production results'))
print('All eleven numerical adapters, resume, report and separate actual/implicit histograms passed')
