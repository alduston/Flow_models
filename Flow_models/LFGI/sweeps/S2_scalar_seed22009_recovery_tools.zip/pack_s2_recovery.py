#!/usr/bin/env python3
"""Package just one completed recovery, never the whole production campaign."""
import argparse,hashlib,json,zipfile
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path.cwd());p.add_argument('--seed',type=int,default=22009);p.add_argument('--n',type=int,default=450);p.add_argument('--profile');a=p.parse_args();root=a.root.resolve();base=root/f'recovery/scalar_seed{a.seed}_N{a.n}'
 candidates=[p for p in base.glob('*/status.json') if json.loads(p.read_text()).get('status')=='COMPLETE'];candidates=[p for p in candidates if not a.profile or p.parent.name==a.profile]
 if not candidates:raise SystemExit('No completed recovery found; inspect recovery/*/*/status.json')
 if len(candidates)>1 and not a.profile:raise SystemExit('Multiple complete profiles; choose --profile explicitly')
 selected=candidates[0].parent;src=root/f'results/production/seed{a.seed}/N{a.n}/scalar';out=root/'exports';out.mkdir(exist_ok=True);path=out/f'S2_scalar_seed{a.seed}_N{a.n}_recovery.zip';files={}
 for f in selected.iterdir():
  if f.is_file() and f.suffix in ['.json','.npz']:files['recovery/'+selected.parent.name+'/'+selected.name+'/'+f.name]=f
 for f in [src/'status.json',src/'fit.json']:
  files['original_failed_cell/'+f.name]=f
 for rel in ['reference/quadrature.json','configs/campaign.json','provenance/IMMUTABLE_SHA256.json']:
  files[rel]=root/rel
 for name in ['recover_s2_scalar.py','pack_s2_recovery.py']:
  f=Path(__file__).resolve().parent/name
  if f.exists():files['scripts/'+name]=f
 manifest={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in sorted(files.items())}
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for k,f in sorted(files.items()):z.write(f,k)
  z.writestr('MANIFEST_SHA256.json',json.dumps(manifest,indent=2));z.writestr('README.txt','Supplement for the originally failed scalar seed %d N=%d. Original files are retained for audit. Only status COMPLETE in recovery/ is the replacement result. Reuse and numerical checks are explicit. No checkpoints/model pickle or other fits are included.\n'%(a.seed,a.n))
 if path.stat().st_size>=25_000_000:raise SystemExit('Recovery exceeds 25 MB; retain this file and split before upload')
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 index=dict(file=path.name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),profile=selected.name);(out/'INDEX_recovery.json').write_text(json.dumps(index,indent=2));print(json.dumps(index,indent=2))
if __name__=='__main__':main()
