# Recover the scalar seed 22009, N=450 result

Add the three supplied scripts to the existing `LFGI_S2_LS6_CPU_Array` directory. Do not overwrite any existing code, configuration or scientific result. From that directory submit exactly one CPU job:

```bash
sbatch recover_s2_scalar.slurm
```

The job activates the existing S2 environment, verifies frozen source/input hashes and the cached model checksum, and uses the already fitted scalar field. It does not refit the model, regenerate the bank, request new gradients/Hessians, or rerun other seeds/methods.

It first checks saved posterior densities at 32 spread-out states. For each of the five saved proposal batches, it compares the first 16 draws against a tighter backward integration with the original random stream and an independently tighter forward density evaluation. A batch is reused only when both log-density checks meet the original 0.001 threshold and coordinate change is <=1e-5. Posterior evaluations are reused when their screen passes. This is explicitly screened reuse, not exhaustive validation of every saved point, and is disclosed in the output.

Failed screens trigger recomputation of just that posterior array or proposal batch, using the same field/endpoint and original random stream. Default rtol=2e-10, atol=2e-12; independent checks are ten times tighter. Replacement draws require new target energy evaluations; all new E counts are logged, with G=H=0. A still-failing consistency guard stops recovery rather than accepting a bad result.

Recovery writes to a separate `recovery/scalar_seed22009_N450/rtol2e-10_atol2e-12/` tree. It keeps the original failed status and all original files intact. Numerical checkpoints and complete batches resume on resubmitting this same job. If tighter tolerances are needed after a further failure, run `python recover_s2_scalar.py --rtol 2e-11 --atol 2e-13` in the activated compute-node environment; this creates a separate profile. Choose `--profile` explicitly when packaging if multiple profiles completed.

After success, the job automatically packages only the supplement:

```
exports/S2_scalar_seed22009_N450_recovery.zip
exports/INDEX_recovery.json
```

The supplement includes replacement arrays and metrics, reuse/accuracy diagnostics, the original failed status and fit metadata, the quadrature reference, configuration, source hashes and script copies. It excludes other fits, model pickles and ODE checkpoints. It stays below 25 MB. It is an explicit replacement replicate for subsequent analysis; the original campaign's report is not silently edited.

To package again without numerical work:

```bash
python3 pack_s2_recovery.py
```

Run on your Oden workstation after the job finishes:

```bash
scp 'ald4435@ls6.tacc.utexas.edu:/work/10812/ald4435/frontera/Flow_models/Flow_models/LFGI/sweeps/LFGI_S2_LS6_CPU_Array/exports/S2_scalar_seed22009_N450_recovery.zip' /oden/aduston/Desktop/S2_LS6_results/
```

Four hours is a restartable reservation for the worst case of recomputing all batches, not a runtime estimate. No LS6 job was submitted by the assistant. Local validation tests use a small actual scalar model and temporary fixture trees; they do not reproduce the missing cluster model pickle or certify the failed production replicate in advance.
