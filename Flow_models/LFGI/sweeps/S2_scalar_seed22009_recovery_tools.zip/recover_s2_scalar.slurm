#!/bin/bash
#SBATCH -A DMS22021
#SBATCH -p normal
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 32
#SBATCH -t 04:00:00
#SBATCH -J s2-scalar-recover
#SBATCH -o logs/s2-scalar-recover-%j.out
#SBATCH -e logs/s2-scalar-recover-%j.err
set -euo pipefail
source ls6/environment.sh
source "$S2_CPU_VENV/bin/activate"
export S2_CHUNK_WORKERS=8
python recover_s2_scalar.py
python pack_s2_recovery.py
