#!/usr/bin/env python3
"""Recover one completed-but-guard-failed S2 scalar cell, without editing frozen files.
Run on a compute node from the original S2 bundle. Original results stay untouched.
"""
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
import argparse,fcntl,hashlib,json,pickle,sys,time,traceback
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path.cwd());p.add_argument('--seed',type=int,default=22009);p.add_argument('--n',type=int,default=450);p.add_argument('--rtol',type=float,default=2e-10);p.add_argument('--atol',type=float,default=2e-12);a=p.parse_args();root=a.root.resolve()
 if not (root/'code/campaign.py').is_file():raise RuntimeError('Run from LFGI_S2_LS6_CPU_Array, or pass --root')
 if not (0<a.rtol<1e-8 and 0<a.atol<1e-10):raise RuntimeError('Recovery must use tighter tolerances than the original run')
 sys.path.insert(0,str(root/'code'))
 import numpy as np
 from common import read,write,save,sha,rng,source_sha,arrays_sha
 from campaign import METHODS,statistics,environment,target
 from flows import PFModel
 for rel,h in read(root/'provenance/IMMUTABLE_SHA256.json').items():
  if sha(root/rel)!=h:raise RuntimeError('Frozen source/config/input mismatch: '+rel)
 src=root/f'results/production/seed{a.seed}/N{a.n}/scalar';old=read(src/'status.json');fit=read(src/'fit.json');binding=old['binding'];config=read(root/'configs/campaign.json');tolerance=config['roundtrip_tolerance'];check_n=config['roundtrip_n']
 if old['status']!='FAILED' or 'generation/evaluation log density mismatch' not in old.get('error',''):raise RuntimeError('Only an existing generation/evaluation-guard failure can be recovered by this script')
 if fit['binding']!=binding or fit['pickle_sha256']!=sha(src/'model.pkl'):raise RuntimeError('Cached fitted model does not match failed cell')
 if environment()!=read(root/'logs/smoke_passed.json')['environment']:raise RuntimeError('Runtime differs; use the original S2 environment')
 files=sorted(src.glob('repeat[0-9][0-9].npz'))
 if len(files)!=config['proposal_repeats']:raise RuntimeError('Expected every original proposal batch; incomplete jobs need their original worker')
 manifest={p.name:sha(p) for p in [src/'status.json',src/'fit.json',src/'model.pkl',src/'posterior_eval.npz']+files+[src/(f.stem+'.json') for f in files]}
 profile=f'rtol{a.rtol:g}_atol{a.atol:g}';out=root/f'recovery/scalar_seed{a.seed}_N{a.n}'/profile;out.mkdir(parents=True,exist_ok=True);lock=(out/'LOCK').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 jobbinding=hashlib.sha256(json.dumps(dict(original=manifest,rtol=a.rtol,atol=a.atol,script=sha(Path(__file__))),sort_keys=True).encode()).hexdigest()
 if (out/'provenance.json').exists() and read(out/'provenance.json')['binding']!=jobbinding:raise RuntimeError('Recovery identity changed; retain this attempt and use another output directory')
 write(out/'provenance.json',dict(binding=jobbinding,original_binding=binding,original_files=manifest,script_sha256=sha(Path(__file__)),source_sha256=source_sha(),environment=environment(),original_failure=old['error'],rtol=a.rtol,atol=a.atol,roundtrip_tolerance=tolerance,check_n=check_n,scope='same fitted field, endpoint and random streams; only numerical integration refined; original cell is never promoted or overwritten'))
 if (out/'status.json').exists() and read(out/'status.json')['status']=='COMPLETE':print('Recovery already complete:',out);return
 write(out/'status.json',dict(status='RUNNING',binding=jobbinding,cell=old['cell'],started=time.time()));tick=time.time()
 try:
  with (src/'model.pkl').open('rb') as f:model=pickle.load(f)
  if not isinstance(model,PFModel) or model.method!='scalar':raise RuntimeError('Unexpected cached model')
  # A pickle contains its old absolute checkpoint directory. Always replace it.
  solver=dict(model.config,rtol=a.rtol,atol=a.atol);tight=PFModel(model.bank,'scalar',solver,out/'checkpoints',jobbinding);strict=PFModel(model.bank,'scalar',dict(solver,rtol=a.rtol/10,atol=a.atol/10),out/'verification_checkpoints',jobbinding)
  true=read(root/'reference/quadrature.json');post=dict(np.load(src/'posterior_eval.npz'));assert str(post['binding'])==binding
  posterior_file=out/'posterior_eval.npz'
  if posterior_file.exists():postnew=dict(np.load(posterior_file));postdiag=read(out/'posterior_check.json')
  else:
   ix=np.unique(np.linspace(0,len(post['states'])-1,min(32,len(post['states'])),dtype=int));check=tight.logq(post['states'][ix],tag='posterior_screen');error=float(np.max(abs(check-post['logq'][ix])));reuse=error<=tolerance
   lq=post['logq'] if reuse else tight.logq(post['states'],tag='posterior_refined');postdiag=dict(screen_count=len(ix),max_logq_change=error,reused=reuse,scope='32 spread-out saved posterior points screened; reuse follows the declared 0.001 log-density accuracy threshold')
   save(posterior_file,states=post['states'],logp=post['logp'],logq=lq,E=post['E'],binding=np.array(jobbinding));write(out/'posterior_check.json',postdiag);postnew=dict(np.load(posterior_file))
  records=[];checks=[];new_E=0
  for rep,file in enumerate(files):
   dest=out/(file.stem+'.npz');meta=out/(file.stem+'.json');checkfile=out/(file.stem+'_check.json')
   if meta.exists():records.append(read(meta));checks.append(read(checkfile));continue
   original=dict(np.load(file));assert str(original['binding'])==binding;random=rng(a.seed,a.n,METHODS.index('scalar'),rep,4);base=random.normal(size=original['proposal'].shape);ncheck=min(check_n,len(base));cfgsmall=dict(solver) # same chunk size as original solver
   # Validate old generation against a tighter backward solve, then independently
   # validate density on the *saved* states. No model refit or target query here.
   from flows import integrate
   qb,Lb,cc=integrate(model.bank,base[:ncheck],'scalar',True,cfgsmall,out/f'checks/rep{rep}/backward',jobbinding);lb=-.5*(base[:ncheck]**2).sum(1)-np.log(2*np.pi)-Lb
   lf=strict.logq(original['proposal'][:ncheck],tag=f'old_rep{rep}_forward');state_error=float(np.max(abs(qb-original['proposal'][:ncheck])));back_error=float(np.max(abs(lb-original['logq'][:ncheck])));forward_error=float(np.max(abs(lf-original['logq'][:ncheck])));reuse=state_error<=1e-5 and back_error<=tolerance and forward_error<=tolerance
   print(f'Repeat {rep}: saved density changes backward={back_error:.6g}, forward={forward_error:.6g}; reuse={reuse}',flush=True)
   if reuse:q=original['proposal'];lqq=original['logq'];lpq=original['logp'];extraE=0;final_error=forward_error
   else:
    q,lqq=tight.sample_logq(len(base),rng(a.seed,a.n,METHODS.index('scalar'),rep,4),f'refined_repeat{rep}');lpq=target().logp(q);extraE=len(q)
    independent=strict.logq(q[:ncheck],tag=f'new_rep{rep}_forward');final_error=float(np.max(abs(independent-lqq[:ncheck])))
    if final_error>tolerance:raise ArithmeticError(f'Refined repeat {rep} still fails consistency: {final_error}; rerun with smaller --rtol/--atol in a new profile')
   diag=dict(repeat=rep,reused_original_batch=reuse,old_state_change=state_error,old_backward_logq_change=back_error,old_forward_logq_change=forward_error,final_roundtrip_logq_max_error=final_error,checked_count=ncheck,new_E=extraE,new_G=0,new_H=0)
   r=statistics(postnew['logp'],postnew['logq'],lpq,lqq);r.update(binding=jobbinding,repeat=rep,new_E=extraE,new_G=0,new_H=0,forward_KL=float(np.mean(postnew['logp']-postnew['logq'])-true['logZ']),reverse_KL=float(true['logZ']-r['ELBO']),logdensity_RMSE=float(np.sqrt(np.mean((postnew['logq']-postnew['logp']+true['logZ'])**2))),target_entropy=true['entropy'])
   if not r['bridge']['success']:raise ArithmeticError('Recovery bridge failure: '+str(r['bridge']))
   r['bridge_logZ_error']=r['bridge']['logZ']-true['logZ'];save(dest,proposal=q,logq=lqq,logp=lpq,binding=np.array(jobbinding));write(checkfile,diag);write(meta,r);records.append(r);checks.append(diag)
  write(out/'status.json',dict(status='COMPLETE',binding=jobbinding,original_binding=binding,cell=old['cell'],fit_seconds=fit['seconds'],info=dict(fit['info'],recovery_solver=solver),posterior_check=postdiag,records=records,checks=checks,roundtrip_logq_max_error=max(c['final_roundtrip_logq_max_error'] for c in checks),recovery_seconds=time.time()-tick,new_target_queries=dict(E=sum(c['new_E'] for c in checks),G=0,H=0),reused_batches=sum(c['reused_original_batch'] for c in checks),normalization_id='S2_normalized_prior_omitted_likelihood_constant_v1',note='Supplement replaces the failed replicate in analysis; original failure remains intact. Screened reuse is not an exhaustive all-point accuracy certificate.'))
  print('COMPLETE:',out,flush=True)
 except Exception as e:
  write(out/'status.json',dict(status='FAILED',binding=jobbinding,cell=old['cell'],error=str(e),traceback=traceback.format_exc()));raise
if __name__=='__main__':main()
