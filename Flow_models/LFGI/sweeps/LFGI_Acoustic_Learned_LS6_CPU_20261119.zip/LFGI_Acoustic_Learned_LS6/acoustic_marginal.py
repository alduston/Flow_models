"""Exploratory Rao-Blackwell score identity for the transverse marginal."""
import acoustic_pilot as p
import time,argparse,json
import numpy as np
from scipy.special import logsumexp

class GNMixture:
    def __init__(self,x,s,H):
        self.H=H;self.inv=np.linalg.inv(H);self.L=np.linalg.cholesky(self.inv)
        self.mu=x+(self.inv@s[...,None])[...,0];self.ld=np.linalg.slogdet(H)[1]
    def lp(self,x):
        diff=x[:,None]-self.mu
        return logsumexp(.5*self.ld[None]-4*np.log(2*np.pi)-.5*np.einsum("qni,nij,qnj->qn",diff,self.H,diff,optimize=True),axis=1)-np.log(len(self.mu))
    def draw(self,z,rng):
        i=rng.integers(0,len(self.mu),size=len(z))
        return self.mu[i]+(self.L[i]@z[...,None])[...,0]

def run(seed,N,M):
    t=p.Target();ref=np.load(p.REF)["samples_by_chain"]
    bank=ref[:2].reshape(-1,16);test=ref[2:].reshape(-1,16)
    idx=np.random.default_rng(seed).permutation(len(bank))[:N]
    ids=np.random.default_rng(seed+200000).permutation(len(test))[:M]
    x=t.to_new(bank[idx]);y=t.to_new(test[ids]);lp=t.lp(y)
    s,H=t.bank(x);v=x[:,8:];h=x[:,:8]
    Hhh=H[:,:8,:8];Hhv=H[:,:8,8:];Hvh=H[:,8:,:8];Hvv=H[:,8:,8:]
    # A fixed coefficient preserves E[s_v - B s_h | v]=E[s_v | v]
    # exactly at the population level. Schur GN is a local curvature proxy.
    B=Hvh.mean(0)@np.linalg.inv(Hhh.mean(0))
    sv=s[:,8:]-s[:,:8]@B.T
    Hv=Hvv-Hvh@np.linalg.solve(Hhh,Hhv)
    rng=np.random.default_rng(seed+500000);zv=rng.normal(size=(M,8));zh=rng.normal(size=(M,8))
    g=p.fit_gmm(v,seed);gg=p.GNConditional(x,s,H)
    gm=GNMixture(v,sv,Hv)
    lqg=g.score_samples(y[:,8:])
    print("marginal GMM components",g.n_components,"mean_logq",lqg.mean(),flush=True)
    tick=time.monotonic()
    newv,L=p.integrate(v,sv,Hv,zv,True,rtol=2e-5)
    end,Lt=p.integrate(v,sv,Hv,y[:,8:],False,rtol=2e-5)
    lqv=p.normal_lp(end)+Lt;lqqv=p.normal_lp(zv)-L
    print("marginal LFGI mean_logq",lqv.mean(),"delta",np.mean(lqv-lqg),"seconds",time.monotonic()-tick,flush=True)
    print("marginal GN mixture mean_logq",gm.lp(y[:,8:]).mean(),flush=True)
    results=[]
    # Compare full normalized densities with both the GN conditional and LFGI conditional.
    for name,vv,lq,lv in [("LFGI_marginal_GN_cond",newv,lqv,lqqv),("GN_marginal_GN_cond",gm.draw(zv,rng),gm.lp(y[:,8:]),None)]:
        tick=time.monotonic()
        if lv is None:lv=gm.lp(vv)
        hh=gg.draw(vv,rng);qq=np.c_[hh,vv]
        ql=lq+gg.logq(y[:,:8],y[:,8:]);qlq=lv+gg.logq(hh,vv)
        results.append(p.summarise(name,lp,ql,t.lp(qq),qlq,time.monotonic()-tick))
    # Reuse exact same conditional LFGI held-out evaluations when available.
    cached=p.OUT/f"conditional_LFGI_{seed}_{N}_{M}.npz"
    if cached.exists():
        a=np.load(cached);assert np.array_equal(y,a["y"]);qh_lp=a["lq"]-lqg
    else:
        print("conditional held-out evaluation repeated",flush=True)
        yy,LL=p.integrate(h,s[:,:8],Hhh,y[:,:8],False,(v,Hhv),y[:,8:],rtol=2e-5)
        qh_lp=p.normal_lp(yy)+LL
    tick=time.monotonic()
    qh,Lh=p.integrate(h,s[:,:8],Hhh,zh,True,(v,Hhv),newv,rtol=2e-5)
    qq=np.c_[qh,newv];ql=qh_lp+lqv;qlq=lqqv+p.normal_lp(zh)-Lh
    results.append(p.summarise("LFGI_marginal_LFGI_cond",lp,ql,t.lp(qq),qlq,time.monotonic()-tick))
    np.savez_compressed(p.OUT/f"LFGI_marginal_LFGI_cond_{seed}_{N}_{M}.npz",y=y,q=qq,lq=ql,lqq=qlq,lp=lp,lpq=t.lp(qq),lqv=lqv,lqg=lqg)
    (p.OUT/f"{seed}_{N}_{M}_marginal.json").write_text(json.dumps(results,indent=2))

if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--seed",type=int,default=23000);parser.add_argument("--N",type=int,default=256);parser.add_argument("--M",type=int,default=256);a=parser.parse_args()
    run(a.seed,a.N,a.M)
