#!/bin/bash
#SBATCH -N 1
#SBATCH -n 1
#SBATCH --no-requeue
set -euo pipefail
BUNDLE=$1
stage=$2
profile=$3
shards=${4:-1}
cd "$BUNDLE"
source ls6/environment.sh
workers=${ACOUSTIC_WORKERS:-48}
workers=$((workers < ${SLURM_CPUS_PER_TASK:-1} ? workers : ${SLURM_CPUS_PER_TASK:-1}))
if [[ "$stage" == setup ]]; then
 if [[ ! -x "$ACOUSTIC_CPU_VENV/bin/python" ]]; then python3 -m venv "$ACOUSTIC_CPU_VENV"; fi
 source "$ACOUSTIC_CPU_VENV/bin/activate"
 python -m pip install --only-binary=:all: -r ls6/requirements.txt
 python -m py_compile campaign.py production_models.py report.py acoustic_attention.py acoustic_learned.py
else
 source "$ACOUSTIC_CPU_VENV/bin/activate"
 case "$stage" in
 smoke)
   python -u campaign.py run --profile smoke --workers "$workers"
   python -u campaign.py display --profile smoke --workers "$workers"
   python -u report.py --profile smoke
   python ls6/check_smoke.py
   ;;
 run|display) python -u campaign.py "$stage" --profile "$profile" --shard "${SLURM_ARRAY_TASK_ID:-0}" --shards "$shards" --workers "$workers";;
 reference) python -u campaign.py reference --profile "$profile" --workers "$workers";;
 report) python -u report.py --profile "$profile";python -u pack_results.py --profile "$profile";;
 *) exit 2;;
 esac
fi
