"""Login-safe submission headroom and shard count; reuses Quake live limits."""
import os,json,argparse
from pathlib import Path
import limits

ap=argparse.ArgumentParser();ap.add_argument("--profile",required=True);ap.add_argument("--reference",type=int,default=1);ap.add_argument("--display",type=int,default=1);a=ap.parse_args()
for k in ["QUEUE","MAX_RUNNING","MAX_SUBMIT","REQUIRE_LIVE_LIMITS"]:
    if "ACOUSTIC_"+k in os.environ:os.environ["QUAKE_"+k]=os.environ["ACOUSTIC_"+k]
os.environ["QUAKE_QUEUE"]=os.getenv("ACOUSTIC_QUEUE","normal")
r=limits.live()
overhead=2 if a.profile=="smoke" else 3+a.reference+2*a.display
available=r["max_submit"]-r["existing_submitted"]-overhead
if available<0:raise SystemExit("Insufficient queue headroom.")
if a.profile=="smoke":tasks=0;conc=0
else:
    cells=30 if a.profile=="production" else 2
    tasks=min(cells,int(os.getenv("ACOUSTIC_ARRAY_TASKS","20")),available,r["max_array_size"])
    conc=min(tasks,r["max_running"],int(os.getenv("ACOUSTIC_ARRAY_CONCURRENCY","12")))
    if tasks<1 or conc<1:raise SystemExit("Insufficient array headroom.")
r.update(profile=a.profile,overhead=overhead,tasks=tasks,concurrency=conc)
out=Path(__file__).resolve().parents[1]/"logs/submission_preflight.json";out.write_text(json.dumps(r,indent=2));print(tasks,conc)
