"""Do not submit production if core model routes did not execute."""
import csv,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
status=json.loads((root/"reports/smoke/status.json").read_text())
essential={"lfgi","gn_opt","full_move_dpsmc","dpsmc_tuned","gmm","gaussian","student","fitted_flow","full_fitted_flow","spline","warp3","joint_lfgi"}
bad=[r for r in status["cells"] if r["method"] in essential and r["status"]!="COMPLETE"]
if bad:raise SystemExit("Core smoke routes failed: "+str(bad))
checks=list(csv.DictReader((root/"reports/smoke/numerical_checks.csv").open()))
bad=[r for r in checks if r["method"] in {"lfgi","full_move_dpsmc","gn_opt","gmm","fitted_flow","warp3"} and r["accepted"]!="True"]
if bad:raise SystemExit("Core smoke numerical checks failed: "+str(bad))
print("Core smoke fit/sample/evaluate/bridge completed.")
