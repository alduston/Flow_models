"""Mock native Slurm CLI; never contacts Slurm. Validates actual launcher DAG."""
import tempfile,shutil,os,subprocess,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    t=Path(td);(t/"ls6").mkdir();(t/"bin").mkdir()
    shutil.copy(root/"submit.sh",t/"submit.sh")
    for name in ["limits.py","preflight.py","job.sh"]:shutil.copy(root/"ls6"/name,t/"ls6"/name)
    for name in ["qlimits","squeue","scontrol","sacctmgr"]:
        f=t/"bin"/name;f.write_text("#!/bin/sh\nexit 0\n");f.chmod(0o755)
    f=t/"bin/sbatch";f.write_text("#!/usr/bin/env python3\nimport sys,os,json\nfrom pathlib import Path\np=Path(os.environ['MOCK_RECORD']);a=[] if not p.exists() else json.loads(p.read_text());a.append(sys.argv[1:]);p.write_text(json.dumps(a));print(1000+len(a))\n");f.chmod(0o755)
    env=os.environ.copy();env["PATH"]=str(t/"bin")+":"+env["PATH"];env["MOCK_RECORD"]=str(t/"mock.json")
    env.update(ACOUSTIC_QUEUE="normal",ACOUSTIC_ARRAY_TASKS="20",ACOUSTIC_ARRAY_CONCURRENCY="12")
    subprocess.run(["bash","submit.sh"],cwd=t,env=env,check=True)
    jobs=json.loads((t/"mock.json").read_text());assert len(jobs)==6
    assert "--dependency=afterok:1001" in jobs[1]
    assert "--array=0-19%12" in jobs[2] and "--dependency=afterok:1002" in jobs[2]
    assert "--array=0-1%2" in jobs[3] and "--dependency=afterany:1003" in jobs[3]
    assert "--dependency=afterok:1002" in jobs[4]
    assert "--dependency=afterany:1003:1004:1005" in jobs[5]
    print("Mock submission DAG passed.")
