"""Login-safe progress counts; no scientific imports or expensive work."""
import argparse,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument("--profile",choices=["smoke","pilot","production"],default="production");args=ap.parse_args()
cfg=json.loads((ROOT/"configs/campaign.json").read_text())[args.profile]
print("Method                         N     done/partial/failed/pending")
for n in cfg["sizes"]:
    for m in cfg["methods"]:
        count=[0,0,0,0]
        total=(cfg["held"]+cfg["chunk"]-1)//cfg["chunk"]+cfg["repeats"]*((cfg["draw"]+cfg["chunk"]-1)//cfg["chunk"])
        for s in cfg["seeds"]:
            d=ROOT/"results"/args.profile/f"seed{s}"/f"N{n}"/m
            fs=list((d/"chunks").glob("held_*.npz"))+list((d/"chunks").glob("proposal_*.npz"))
            errors=list((d/"chunks").glob("held_*.error.json"))+list((d/"chunks").glob("proposal_*.error.json"))
            q=0 if len(fs)==total else 2 if errors or (d/"fit_error.json").exists() and not (d/"model.pkl").exists() else 1 if fs else 3
            count[q]+=1
        print(f"{m:29s} {n:5d}  "+"/".join(str(i) for i in count))
