"""Publication data: calibrated metrics, group bootstrap, figures, raw ledgers."""
import os
os.environ["OPENBLAS_NUM_THREADS"]="1"
os.environ["MPLBACKEND"]="Agg"
import argparse,csv,json
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import campaign as c
import acoustic_pilot as p
import acoustic_learned as l
from common import write,save,bridge,read

ROOT=c.ROOT
LABEL={"lfgi":"Learned LFGI-GN","dpsmc_matched":"DPSMC (matched)","dpsmc_tuned":"DPSMC (tuned)","full_move_dpsmc":"DPSMC (full movement)",
       "gn_opt":"Conditional GN mixture (tuned)","gn_matched":"Conditional GN mixture (matched)","gaussian":"Conditional Gaussian",
       "gmm":"Conditional selected GMM","gmm2":"Conditional two-GMM","student":"Conditional selected t/Gaussian","fitted_flow":"Conditional fitted flow",
       "full_fitted_flow":"Full conditional fitted flow","spline":"Conditional spline Gaussian","scalar":"Conditional Scalar Blend",
       "static_lfgi":"Static conditional LFGI","full_move_lfgi":"Full-movement LFGI","full_cond_lfgi":"Unsplit conditional LFGI",
       "joint_lfgi":"Original joint LFGI","joint_gmm":"Original joint GMM","joint_gaussian":"Original joint Gaussian","joint_gn":"Original joint GN mixture",
       "map_laplace":"MAP-Laplace","warp3":"Warp-III"}
MAIN=["lfgi","dpsmc_matched","full_move_dpsmc","gn_opt","gaussian","gmm","fitted_flow","spline","warp3"]
CURVE=["lfgi","dpsmc_matched","full_move_dpsmc","gn_opt","gaussian","gmm","fitted_flow","spline","warp3"]
METRICS=["density_RMSE","forward_KL","reverse_KL","bridge_RMSE","bridge_bias","within_bridge_SD","ESS_fraction"]
def expected_files(profile,seed,N,method,kind,rep):
    cfg=c.profile_config(profile);n=cfg[{"held":"held","proposal":"draw","display":"display","cubature":"cubature"}[kind]]
    base=c.model_dir(profile,seed,N,method)/"chunks"
    return [base/f"{kind}_{rep:02d}_{i:05d}.npz" for i in range(0,n,cfg["chunk"])]
def combine(profile,seed,N,method,kind,rep=0):
    fs=expected_files(profile,seed,N,method,kind,rep)
    if not all(f.exists() for f in fs):return None
    ds=[np.load(f) for f in fs]
    result={k:np.concatenate([r[k] for r in ds]) for k in ["points","logp","logq","roundtrip_error","refinement_error"]}
    result["seconds"]=sum(float(r["seconds"]) for r in ds)
    for r in ds:r.close()
    return result
def status(profile):
    cfg=c.profile_config(profile);rows=[]
    for seed,N in c.cells(profile):
        for method in cfg["methods"]:
            d=c.model_dir(profile,seed,N,method);files=expected_files(profile,seed,N,method,"held",0)
            files+=sum([expected_files(profile,seed,N,method,"proposal",r) for r in range(cfg["repeats"])],[])
            n=sum(f.exists() for f in files);errors=len(list((d/"chunks").glob("*.error.json"))) if (d/"chunks").exists() else 0
            complete=n==len(files)
            state="COMPLETE" if complete else "FAILED" if ((d/"fit_error.json").exists() and not (d/"model.pkl").exists()) or errors else "PARTIAL" if n else "PENDING"
            rows.append(dict(seed=seed,N=N,method=method,status=state,chunks=n,expected=len(files),errors=errors))
    return dict(expected=len(rows),complete=sum(r["status"]=="COMPLETE" for r in rows),failed=sum(r["status"]=="FAILED" for r in rows),cells=rows)
def csvout(dest,rows):
    dest.parent.mkdir(parents=True,exist_ok=True)
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with dest.open("w") as f:
        if keys:
            w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def reference():
    pilot=read(ROOT/"data/reference_qmc_pilot.json");refined=[read(f) for f in sorted((ROOT/"reference").glob("*_p18.json"))]
    rows=refined if len(refined)==16 else pilot
    z=np.array([r["logZ"] for r in rows]);Z=float(logsumexp(z)-np.log(len(z)))
    groups=[]
    for df in [0,10]:
        zz=np.array([r["logZ"] for r in rows if r["df"]==df]);val=float(logsumexp(zz)-np.log(len(zz)))
        se=float(np.std(np.exp(zz-val),ddof=1)/np.sqrt(len(zz)))
        groups.append(dict(df=df,replicates=len(zz),logZ=val,logZ_SE=se))
    tolerance=max(.002,3*max(q["logZ_SE"] for q in groups),abs(groups[0]["logZ"]-groups[1]["logZ"]))
    return dict(logZ=Z,source="refined_QMC" if len(refined)==16 else "pilot_QMC_provisional",complete_refinement=len(refined)==16,uncertainty_tolerance=tolerance,by_proposal=groups,replicates=rows)
def metrics(profile,Z):
    cfg=c.profile_config(profile);groups=[];repeats=[];ledger=[];qc=[]
    for seed,N in c.cells(profile):
        for m in cfg["methods"]:
            pp=combine(profile,seed,N,m,"held")
            batches=[combine(profile,seed,N,m,"proposal",r) for r in range(cfg["repeats"])]
            if pp is None or any(q is None for q in batches):continue
            rt=np.concatenate([b["roundtrip_error"] for b in batches]);rf=np.concatenate([b["refinement_error"] for b in batches])
            err=float(np.max(np.abs(rt))) if len(rt) else 0.;fine=float(np.max(np.abs(rf))) if len(rf) else 0.
            valid=err<=1e-3 and fine<=1e-3
            qc.append(dict(seed=seed,N=N,method=m,roundtrip_max=err,refinement_max=fine,accepted=valid))
            r=pp["logp"]-pp["logq"];items=[]
            for j,q in enumerate(batches):
                br=bridge(pp["logp"],pp["logq"],q["logp"],q["logq"])
                if not br["success"]:valid=False;break
                item=dict(seed=seed,N=N,method=m,rep=j,logZ=br["logZ"],bridge_error=br["logZ"]-Z,ESS_fraction=br["IS_ESS"]/len(q["points"]),
                          bridge_residual=br["residual"],bridge_overlap=br["overlap"],direct_IS_logZ=br["direct_IS_logZ"],reciprocal_logZ=br["reciprocal_logZ"],
                          reverse_KL=float(np.mean(Z-q["logp"]+q["logq"])) if m!="warp3" else np.nan)
                items.append(item)
            for item in items:item["accepted"]=valid
            repeats.extend(items)
            if not valid:continue
            e=np.array([q["bridge_error"] for q in items]);den=np.sqrt(np.mean((r-Z)**2)) if m!="warp3" else np.nan
            g=dict(seed=seed,N=N,method=m,density_RMSE=float(den),forward_KL=float(np.mean(r-Z)) if m!="warp3" else np.nan,
                   reverse_KL=float(np.mean([q["reverse_KL"] for q in items])) if m!="warp3" else np.nan,
                   bridge_RMSE=float(np.sqrt(np.mean(e*e))),bridge_bias=float(e.mean()),within_bridge_SD=float(e.std(ddof=1)) if len(e)>1 else 0.,
                   ESS_fraction=float(np.mean([q["ESS_fraction"] for q in items])),centered_logratio_SD=float(r.std()),mean_logratio=float(r.mean()),
                   bridge_errors=e.tolist(),seconds=sum(q["seconds"] for q in batches)+pp["seconds"])
            groups.append(g)
            info=read(c.model_dir(profile,seed,N,m)/"fit.json").get("info",{})
            isjoint=m.startswith("joint_") or m=="map_laplace" or m=="warp3"
            uses_GN=(not isjoint) or m in ["joint_lfgi","joint_gn"]
            use_G=uses_GN
            eprop=cfg["draw"]*cfg["repeats"]*(2 if m=="warp3" else 1)
            ledger.append(dict(seed=seed,N=N,method=m,common_cached_G=N,common_cached_H=N,
                required_G=N if use_G else 0,required_H_GN=N if uses_GN else 0,
                proposal_E=eprop,common_allowance_W=2*N+eprop+info.get("map_energy_calls",0)+info.get("map_gradient_calls",0),
                required_W=(N if use_G else 0)+(N if uses_GN else 0)+eprop+info.get("map_energy_calls",0)+info.get("map_gradient_calls",0),
                heldout_E=cfg["held"]*(2 if m=="warp3" else 1),coordinate_validation=0 if isjoint else 64,
                map_E=info.get("map_energy_calls",0),map_G=info.get("map_gradient_calls",0),map_H_FD=info.get("map_hessian_fd_gradient_calls",0)))
    return groups,repeats,qc,ledger
def aggregate(groups,Zshift=0):
    rows=[];paired=[];rng=np.random.default_rng(20261119)
    for N in sorted(set(g["N"] for g in groups)):
        relevant=[g for g in groups if g["N"]==N]
        methods=sorted(set(g["method"] for g in relevant))
        for m in methods:
            gg=sorted([g for g in relevant if g["method"]==m],key=lambda g:g["seed"]);n=len(gg)
            v=np.array([[g[k] for k in METRICS] for g in gg])
            if Zshift:
                if m!="warp3":
                    v[:,0]=[np.hypot(g["centered_logratio_SD"],g["forward_KL"]-Zshift) for g in gg]
                    v[:,1]-=Zshift;v[:,2]+=Zshift
                v[:,3]=[np.sqrt(np.mean((np.array(g["bridge_errors"])-Zshift)**2)) for g in gg];v[:,4]-=Zshift
            v[:,3]**=2
            draws=rng.integers(0,n,(10000,n));bs=v[draws].mean(1);mean=v.mean(0);mean[3]=np.sqrt(mean[3]);bs[:,3]=np.sqrt(bs[:,3])
            for i,k in enumerate(METRICS):
                rows.append(dict(N=N,method=m,metric=k,groups=n,estimate=float(mean[i]),SE=float(bs[:,i].std(ddof=1)),lo=float(np.quantile(bs[:,i],.025)),hi=float(np.quantile(bs[:,i],.975)),reference_shift=Zshift))
        # Paired resampling on common accepted banks, retaining entire batches.
        base={g["seed"]:g for g in relevant if g["method"]=="lfgi"}
        for m in methods:
            if m=="lfgi":continue
            other={g["seed"]:g for g in relevant if g["method"]==m};keys=sorted(set(base)&set(other))
            if not keys:continue
            def arr(dic):
                v=np.array([[dic[s][k] for k in METRICS] for s in keys])
                if Zshift:
                    if dic[keys[0]]["method"]!="warp3":
                        v[:,0]=[np.hypot(dic[s]["centered_logratio_SD"],dic[s]["forward_KL"]-Zshift) for s in keys];v[:,1]-=Zshift;v[:,2]+=Zshift
                    v[:,3]=[np.sqrt(np.mean((np.array(dic[s]["bridge_errors"])-Zshift)**2)) for s in keys];v[:,4]-=Zshift
                v[:,3]**=2;return v
            A,B=arr(base),arr(other);idx=rng.integers(0,len(keys),(10000,len(keys)))
            aa,bb=A[idx].mean(1),B[idx].mean(1);aa[:,3]=np.sqrt(aa[:,3]);bb[:,3]=np.sqrt(bb[:,3]);delta=aa-bb
            MA,MB=A.mean(0),B.mean(0);MA[3]=np.sqrt(MA[3]);MB[3]=np.sqrt(MB[3])
            for i,k in enumerate(METRICS):
                paired.append(dict(N=N,comparator=m,metric=k,groups=len(keys),difference=float(MA[i]-MB[i]),SE=float(delta[:,i].std(ddof=1)),lo=float(np.quantile(delta[:,i],.025)),hi=float(np.quantile(delta[:,i],.975)),reference_shift=Zshift))
    return rows,paired
def plot_curves(dest,rows):
    fig,ax=plt.subplots(1,2,figsize=(10,4),layout="constrained")
    for a,metric in zip(ax,["density_RMSE","bridge_RMSE"]):
        for m in CURVE:
            q=sorted([r for r in rows if r["method"]==m and r["metric"]==metric and np.isfinite(r["estimate"])],key=lambda r:r["N"])
            if not q:continue
            x=np.array([r["N"] for r in q]);y=np.array([r["estimate"] for r in q])
            a.plot(x,y,marker="o",label=LABEL[m]);a.fill_between(x,[r["lo"] for r in q],[r["hi"] for r in q],alpha=.14)
        a.set_xscale("log");a.set_yscale("log");a.set_xlabel("Reference bank size");a.set_ylabel({"density_RMSE":"Normalized log-density RMSE","bridge_RMSE":"Bridge log-evidence RMSE"}[metric]);a.grid(alpha=.2)
    ax[0].legend(fontsize=7);fig.savefig(dest/"Acoustic_density_evidence.pdf");fig.savefig(dest/"Acoustic_density_evidence.png",dpi=180);plt.close(fig)
def tables(dest,rows):
    largest=max((r["N"] for r in rows),default=0);rs=[r for r in rows if r["N"]==largest]
    for name,methods,metrics in [("acoustic_results",MAIN+["map_laplace"],["density_RMSE","forward_KL","reverse_KL","bridge_RMSE","ESS_fraction"]),
                                ("acoustic_extended",list(LABEL),METRICS)]:
        # Data-only TeX fragment to insert into manuscript table.
        lines=[]
        for m in methods:
            q={r["metric"]:r for r in rs if r["method"]==m}
            if not q:continue
            vals=[]
            for k in metrics:
                r=q.get(k);vals.append("--" if not r or not np.isfinite(r["estimate"]) else "$%.4g\\pm%.3g$"%(r["estimate"],r["SE"]))
            lines.append(LABEL[m]+" & "+" & ".join(vals)+r" \\")
        (dest/(name+".tex")).write_text("\n".join(lines)+"\n");csvout(dest/(name+".csv"),rs)
def display(profile,dest,Z):
    cfg=c.profile_config(profile);s=cfg["seeds"][0];sizes=[cfg["sizes"][0],cfg["sizes"][-1]] if len(cfg["sizes"])>1 else cfg["sizes"]
    ref=np.load(p.REF)["samples_by_chain"][2:].reshape(-1,16)
    basis=np.load(p.DATA/"basis.npz");B=basis["Bmid"][0,:8];Bfine=basis["Bfine"][:,:8]
    def midpoint(x):return np.c_[x[:,:8]@B,x[:,8:]@B]
    xy=midpoint(ref);lo,hi=np.quantile(xy,[.001,.999],axis=0);pad=.05*(hi-lo);lo-=pad;hi+=pad
    bins=[np.linspace(lo[j],hi[j],41) for j in range(2)]
    methods=c.DISPLAY;data=[];arrs={"reference":xy,"bins_x":bins[0],"bins_y":bins[1]};events=[]
    for N in sizes:
        row=[("Reference",ref)]
        for m in methods:
            q=combine(profile,s,N,m,"display")
            if q is not None:row.append((m,q["points"]))
        data.append(row)
        for m,x in row:
            y=midpoint(x);h=np.histogram2d(y[:,0],y[:,1],bins=bins)[0]/len(x);arrs[f"N{N}_{m}_hist"]=h;arrs[f"N{N}_{m}_points"]=y
            pathx=x[:,:8]@Bfine.T;pathy=x[:,8:]@Bfine.T
            arrs[f"N{N}_{m}_trajectory_quantiles"]=np.stack([np.quantile(pathx,[.05,.5,.95],axis=0),np.quantile(pathy,[.05,.5,.95],axis=0)])
            residual=p.Target().old_lp(x)+.5*np.sum(x*x,1)
            events.append(dict(N=N,method=m,draws=len(x),outside_mass=1-h.sum(),mean_noise_whitened_residual_square=float(-2*residual.mean()),midpoint_below_zero=float((y[:,1]<0).mean()),enters_disk=float((np.sqrt(pathx**2+(pathy-2)**2).min(1)<=1).mean()),crosses_zero=float(((pathy.min(1)<0)&(pathy.max(1)>0)).mean())))
    save(dest/"physical_display_arrays.npz",**arrs);csvout(dest/"physical_diagnostics.csv",events)
    fig,ax=plt.subplots(len(sizes),len(methods)+1,figsize=(2.3*(len(methods)+1),2.4*len(sizes)),squeeze=False,layout="constrained")
    top=max([arrs[k].max() for k in arrs if k.endswith("_hist")]);norm=LogNorm(vmin=1/max(len(ref),cfg["display"]),vmax=max(top,1e-3))
    for i,N in enumerate(sizes):
        for j,m in enumerate(["Reference"]+methods):
            a=ax[i,j];key=f"N{N}_{m}_hist";a.set_title(m if m=="Reference" else LABEL[m],fontsize=8)
            if key in arrs:im=a.pcolormesh(*bins,np.ma.masked_equal(arrs[key].T,0),cmap="viridis",norm=norm);a.set_aspect("equal")
            else:a.text(.5,.5,"Incomplete",ha="center",transform=a.transAxes)
            a.set_xlabel("Midpoint x (m)");a.set_ylabel(f"N={N}: y (m)" if j==0 else "")
    fig.colorbar(im,ax=ax.ravel().tolist(),label="Probability per bin",shrink=.8)
    fig.savefig(dest/"Acoustic_particle_histograms.pdf");fig.savefig(dest/"Acoustic_particle_histograms.png",dpi=180);plt.close(fig)
    times=basis["fine_times"];N=sizes[-1];fig,ax=plt.subplots(1,2,figsize=(9,4),layout="constrained")
    for j,a in enumerate(ax):
        for m in ["Reference","lfgi","full_move_dpsmc","gn_opt","gmm","fitted_flow"]:
            q=arrs.get(f"N{N}_{m}_trajectory_quantiles")
            if q is None:continue
            a.plot(times,q[j,1],label=m if m=="Reference" else LABEL[m]);a.fill_between(times,q[j,0],q[j,2],alpha=.10)
        a.set_xlabel("Time (s)");a.set_ylabel(["x (m)","y (m)"][j])
    ax[0].legend(fontsize=6);fig.savefig(dest/"Acoustic_trajectory_intervals.pdf");plt.close(fig)
    # Physical setup, independent of density method and bank.
    target=p.Target();data=read(p.DATA/"arrival120.json");truth=basis["truth_path"];t0=basis["master_times"]
    points=np.stack([np.interp(data["pulse_times_s"],t0,truth[:,j]) for j in [0,1]],axis=1)
    receivers=np.asarray(data["receiver_positions_m"]);fig,ax=plt.subplots(figsize=(5,4),layout="constrained")
    ax.plot(truth[:,0],truth[:,1],label="Synthetic source trajectory",color="#2b6f9e");ax.scatter(points[:,0],points[:,1],s=19,label="Observation times",color="#e88b34")
    ax.scatter(receivers[:,0],receivers[:,1],marker="^",s=60,color="#444444",label="Receivers")
    ax.set_xlabel("x (m)");ax.set_ylabel("y (m)");ax.set_aspect("equal");ax.legend(fontsize=8)
    fig.savefig(dest/"Acoustic_setup.pdf");fig.savefig(dest/"Acoustic_setup.png",dpi=180);plt.close(fig)
    # Structural plot for the chosen largest bank.
    q=c.path(profile,s,N)/"bank_arrays.npz"
    if q.exists():
        b=np.load(q);W=l.couplings(b["GN"]);WW=l.couplings(b["chart_GN"]);info=read(c.path(profile,s,N)/"bank.json")
        att=np.zeros((8,8))
        for rr in info["lfgi_tuning"]:
            for j in rr["B"]:att[j,rr["attention"]]=1
        fig,ax=plt.subplots(1,3,figsize=(10,3),layout="constrained")
        for a,m,title in zip(ax,[W,WW,att],["Original GN couplings","Learned chart GN couplings","Learned attention masks"]):
            img=a.imshow(m,vmin=0,vmax=1,cmap="magma");a.set_title(title,fontsize=9)
        fig.colorbar(img,ax=ax.ravel().tolist(),shrink=.7);fig.savefig(dest/"Acoustic_learned_structure.pdf");plt.close(fig)
    # Importance cubature of physical midpoint marginals using a deterministic
    # equally weighted mixture of three normalized surrogate proposals.
    cubdiag=[];cubarrays={};cubrows=[]
    for N in sizes:
        records={m:combine(profile,s,N,m,"cubature") for m in methods}
        if any(records[m] is None for m in ["lfgi","gmm","fitted_flow"]):continue
        common=records["lfgi"]["points"];lr=logsumexp(np.stack([records[m]["logq"] for m in ["lfgi","gmm","fitted_flow"]]),axis=0)-np.log(3)
        y=midpoint(common);vals={"Target":records["lfgi"]["logp"]-Z}
        vals.update({m:r["logq"] for m,r in records.items() if r is not None})
        one=[]
        for m,xlog in vals.items():
            lw=xlog-lr;w=np.exp(lw-np.log(len(y)));h=np.histogram2d(y[:,0],y[:,1],bins=bins,weights=w)[0]
            cubarrays[f"N{N}_{m}_mass"]=h;cubarrays[f"N{N}_{m}_log_weight"]=lw;one.append((m,h))
            cubdiag.append(dict(N=N,method=m,total_mass=float(w.sum()),window_mass=float(h.sum()),ESS_fraction=float(np.exp(2*logsumexp(lw)-logsumexp(2*lw))/len(y))))
        cubarrays[f"N{N}_points"]=common;cubarrays[f"N{N}_log_proposal"]=lr;cubrows.append((N,one))
    if cubrows:
        save(dest/"implicit_marginal_arrays.npz",**cubarrays);csvout(dest/"implicit_marginal_diagnostics.csv",cubdiag)
        fig,ax=plt.subplots(len(cubrows),len(methods)+1,figsize=(2.2*(len(methods)+1),2.5*len(cubrows)),squeeze=False,layout="constrained")
        vmax=max(h.max() for _,row in cubrows for _,h in row);norm=LogNorm(vmin=max(1e-6,vmax*1e-4),vmax=vmax)
        for i,(N,row) in enumerate(cubrows):
            dd=dict(row)
            for j,m in enumerate(["Target"]+methods):
                a=ax[i,j];a.set_title(m if m=="Target" else LABEL[m],fontsize=8)
                if m in dd:im=a.pcolormesh(*bins,np.ma.masked_equal(dd[m].T,0),cmap="viridis",norm=norm);a.set_aspect("equal")
                a.set_xlabel("Midpoint x (m)");a.set_ylabel(f"N={N}: y (m)" if j==0 else "")
        fig.colorbar(im,ax=ax.ravel().tolist(),shrink=.8,label="Importance-integrated mass per bin")
        fig.savefig(dest/"Acoustic_implicit_marginals.pdf");plt.close(fig)
def run(profile):
    dest=ROOT/"reports"/profile;dest.mkdir(parents=True,exist_ok=True)
    st=status(profile);write(dest/"status.json",st);ref=reference();write(dest/"reference.json",ref)
    groups,repeats,qc,ledger=metrics(profile,ref["logZ"])
    csvout(dest/"per_group.csv",groups);csvout(dest/"per_repeat.csv",repeats);csvout(dest/"numerical_checks.csv",qc);csvout(dest/"target_ledger.csv",ledger)
    rows,pairs=aggregate(groups);csvout(dest/"figure_statistics_calibrated.csv",rows);csvout(dest/"paired_lfgi_differences.csv",pairs);tables(dest,rows)
    sensitivity=[]
    for shift in [-ref["uncertainty_tolerance"],ref["uncertainty_tolerance"]]:
        a,b=aggregate(groups,shift);sensitivity.extend(b)
    csvout(dest/"reference_sensitivity_paired.csv",sensitivity)
    if rows:plot_curves(dest,rows)
    cfg=c.profile_config(profile)
    ds=[]
    for N in sorted(set([cfg["sizes"][0],cfg["sizes"][-1]])):
        for m in c.DISPLAY:
            for kind in ["display","cubature"]:
                fs=expected_files(profile,cfg["seeds"][0],N,m,kind,0);count=sum(f.exists() for f in fs)
                ds.append(dict(seed=cfg["seeds"][0],N=N,method=m,kind=kind,complete=count==len(fs),chunks=count,expected=len(fs)))
    write(dest/"display_status.json",ds)
    display(profile,dest,ref["logZ"])
    summary=dict(status=st["complete"],expected=st["expected"],failed=st["failed"],accepted=len(groups),logZ=ref["logZ"],reference_source=ref["source"])
    (dest/"REPORT.md").write_text("# Learned acoustic density study\n\n"+json.dumps(summary,indent=2)+"\n\nSee calibrated CSVs, figures and numerical checks. Incomplete or excluded cells are retained in status and numerical records.\n")
    print(json.dumps(summary),flush=True)
if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--profile",default="production",choices=["smoke","pilot","production"]);args=ap.parse_args();run(args.profile)
