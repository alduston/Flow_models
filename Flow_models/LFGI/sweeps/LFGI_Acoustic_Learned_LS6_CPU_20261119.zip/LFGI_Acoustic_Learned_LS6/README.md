# Acoustic-120 learned conditional LFGI: production LS6 campaign

**Purpose:** replace the Tanh density/evidence example with the **original 16-dimensional acoustic moving-source inverse problem**, using the learned affine decomposition and query-dependent attention developed in the exploratory pilot. This is not the separate 2D acoustic study.

The bundle is self-contained: it includes all four 10,000-state archived NUTS chains, the unchanged observation data and KL basis, NUTS diagnostic provenance, pilot normalizer estimates, the learned-structure pilot report, and code. No further data transfer from Vista or the older GAD runs is required to launch.

## Run on LS6

Transfer the ZIP to the desired sweep directory and extract it. On an LS6 login node:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/LFGI/sweeps/LFGI_Acoustic_Learned_LS6
bash submit.sh
```

The default allocation is DMS22021, normal CPU queue. The launcher runs live queue/headroom preflight, setup, a small native smoke, production bank arrays, display/cubature arrays, independent reference refinement, and report/export. Setup and every numerical task run on compute nodes. It uses the pinned Python 3.9.7 CPU environment, separate from the Quake and Tanh environments.

Optional:

```bash
bash submit.sh --smoke-only   # cheap smoke only
bash submit.sh --pilot        # one bank seed; N=256,1024; 128 held-out/proposals
ACOUSTIC_ARRAY_TASKS=30 ACOUSTIC_ARRAY_CONCURRENCY=12 bash submit.sh
```

Production is the default, not pilot. Do not launch pilot/smoke and production simultaneously against the same environment. The submission ledger in logs/submitted_ids_production.txt prevents duplicate active DAGs for the same profile. After all previous jobs are terminal, running the same command resumes saved bank fits and atomic completed chunks, including displays/reference. Failed chunks retain error JSONs and are retried on resubmission; no completed chunk is deliberately recomputed. If code is changed, the frozen-bank hash check requires a new directory or explicitly archiving the old results first. Increasing walltime or per-chunk timeout without modifying code is safe.

Useful overrides:

- ACOUSTIC_ACCOUNT, ACOUSTIC_QUEUE; ACOUSTIC_MAX_RUNNING and ACOUSTIC_MAX_SUBMIT for nonstandard queues.
- ACOUSTIC_ARRAY_TASKS (20 default), ACOUSTIC_ARRAY_CONCURRENCY (12), ACOUSTIC_CPUS_PER_TASK (64), ACOUSTIC_WORKERS (48, capped by Slurm allocation).
- ACOUSTIC_WALL (12:00:00 per shard), ACOUSTIC_DISPLAY_WALL (08:00:00), ACOUSTIC_REFERENCE_WALL (03:00:00), ACOUSTIC_CHUNK_TIMEOUT (1800 seconds production, 90 seconds smoke).
- ACOUSTIC_CPU_VENV, ACOUSTIC_GCC_MODULE, ACOUSTIC_PYTHON_MODULE.
- --no-displays and --no-reference are resume/debug options; leave both enabled for the paper.

The matrix has 30 bank cells; the launcher distributes them across up to 20 array elements by default. Each element can run multiple cells serially, with process-parallel fit and ODE query chunks. Joint probability flow and Scalar Blend are slow controls and may consume much of the runtime. The scalar method is allowed to fail if numerically pathological; the error is retained and not silently replaced by LFGI. These are conservative wall allocations, not a measured cluster time guarantee.

## Frozen experimental protocol

- **10 bank selections:** seeds 23000–23009; nested N=256,1024,2048. First two NUTS chains form fitting pool. The other two form held-out pool. Each bank selection uses the same 512 test states at all bank sizes and across all methods, with independent bank-seed-specific permutations; as in Quake, uncertainty is conditional on the archived chains and fixed posterior, not ten independent problem realizations. The 64 coordinate-only validation states come from the fitting pool outside the maximum bank and are common across N for each seed. There are no derivative queries on validation states.
- Fit learned likelihood-curvature subspaces after removing known prior information. Use the learned affine chart, eight high-information directions and eight contexts. Learn normal partition and local context masks by GN conditional NLL. Validation tunes bandwidth and mark movement independently for LFGI and DPSMC. The direct GN mixture also has its own bandwidth tune. Static and full-movement controls use the earlier bandwidth search. All learned methods share the chart/partition learning information and BIC-selected context marginal. The product conditional density is approximate because of nonzero prior normal-normal couplings; all evaluations use the true unchanged joint posterior.
- **512 held-out states + 5 independent batches of 512 proposal states per fit**, with common marginal and terminal innovation streams wherever applicable. Use full original posterior density, including exact affine Jacobian. Record each raw log-density and point, no offset fitting, no pooling for displays.
- Production PF T=8, DOP853 in log time on 16 segments, rtol=1e-8, atol=1e-10. Common endpoint min(1e-6, 0.5 log(1+.01/lambda_max)) based on whole learned-chart GN bank; original joint flow uses the original chart's corresponding rule. Pilot model selection retains the previously validated looser solver for validation, not for production density/sample results. Re-evaluate first 16 proposals; tighten tolerances 20x on four of them. An error above 1e-3 excludes that fit from statistics, not from raw records. No final noninvertible denoising.
- Numerical evidence: original unnormalized posterior convention `-||x||²/2 - ||r(x)||²/2` (omits prior and observation normalizers). The independent QMC reference uses a receiver-coordinate change solely for numerical integration, not learned method fitting. Eight independently scrambled 2^18-node batches per mixture component for each of two proposal families (inflated Gaussian mixture and Student-t mixture), 16 total independent replicates and 16,777,216 likelihood evaluations. Original pilot logZ ≈ -10.29346 is included; report labels calibration provisional until all 16 refinement replicates finish. Average evidence before taking logarithm; sensitivity uses max(.002, 3×replicate SE, between-family difference).
- Main metrics: mean group held-out log-density RMSE, forward KL, reverse KL, pooled bridge logZ RMSE, mean ESS fraction; supplement bridge bias and within-fit bridge SD. Group bootstraps (10,000 replicates) retain all five proposal repeats together, with paired LFGI-minus-comparator intervals on common accepted groups. Bridge evidence sensitivity recomputed at both endpoints of the reference tolerance. All numerical checks and excluded/failed fits recorded.
- Target-output ledger records common N scores/N GN marks, required output counts, proposal and held-out energies, coordinate-only validation, and MAP optimization energies/gradients. MAP exact observed information is approximated here by central differentiation of the analytic score (32 extra gradient queries), rather than mislabeling it one Hessian request. Warp-III uses two energy evaluations per proposal, and both held-out original/reflected energies are evaluated and counted. Shared holdout energy evaluation and numerical reference integration are separate from per-fit proposal costs.

## Methods (23 per bank; 690 total)

**Main comparison:** learned LFGI-GN (tuned), matched DPSMC, DPSMC with fixed full movement, independently PF-validation-tuned DPSMC, independently GN-bandwidth-tuned conditional GN mixture, conditional Gaussian, selected GMM, conditional fitted flow, conditional spline Gaussian, Warp-III, and MAP-Laplace.

**Extended/ablation:** GN mixture with LFGI-matched bandwidth; conditional two-GMM and selected Student-t/Gaussian; full eight-dimensional conditional fitted affine-coupling flow; Scalar Blend using archived weighted regression gate and C1 safeguard; static LFGI; full reference movement; unsplit eight-dimensional conditional LFGI; original naive joint LFGI; joint Gaussian, GMM and GN mixture.

Selected GMM uses K=1,2,4,8 and five starts; conditional GMM and Student fits select either full conditioning or learned sparse mask by validation. The scalar conditional fitted flow is conditional-affine (a neural conditional location-scale density in 1D); for multivariate blocks it is an affine-coupling density. The additional full eight-dimensional conditional flow is a strong nonfactorized neural alternative in the same chart and context marginal. Both use 4×32 or 6×64, two initializations, internal 80/20 validation, Adam 1e-3, 128 batch and max 300 epochs, refitting full bank. The spline conditional additionally learns nonlinear mean/log-scale. Warp-III uses original-coordinate bank covariance whitening and does not report a density in original coordinates. All conditional comparators get the same learned partition/context; the full conditional flow/unsplit control explicitly ablate factorization.

See docs/ACOUSTIC_LEARNED_PARTITION.md for the preliminary results, geometry derivation and caveats. The learned scalar normal factors do not demonstrate off-diagonal matrix-gate mixing; avoid such claims. Do not promise superiority on evidence until production paired intervals and sensitivity justify it.

## Figures and data for manuscript replacement

For a single prespecified bank seed 23000 at N=256 and 2048:

- 8192 actual draws per selected method, reference midpoint histogram from the archived held-out chains. Common 40×40 physical bins, log probability scale, zero bins white; probabilities divided by full draw count. No pooling.
- Common 1536-point stratified implicit marginal diagnostic (512 draws each from learned LFGI, GMM, fitted flow), evaluating all selected normalized densities on identical points and retaining deterministic-mixture importance weights, marginal bin masses, total/window mass and ESS.
- 90% trajectory coordinate intervals; midpoint, disk entry and crossing probabilities; mean noise-normalized data residuals. Exact setup geometry with receivers and the synthetic source trajectory.
- Learned full GN coupling and selected attention masks from that bank; actual partition, bandwidth and moved-mark parameter choices stored for every bank.

Outputs under reports/production:

- REPORT.md and status.json (partial results explicitly marked)
- reference.json, figure_statistics_calibrated.csv, per_group.csv, per_repeat.csv, paired_lfgi_differences.csv, reference_sensitivity_paired.csv
- acoustic_results.tex/.csv and acoustic_extended.tex/.csv (numeric row fragments for the manuscript; no hard-coded claims)
- numerical_checks.csv and target_ledger.csv
- Acoustic_density_evidence.pdf/.png, Acoustic_particle_histograms.pdf/.png, Acoustic_trajectory_intervals.pdf, Acoustic_setup.pdf/.png, Acoustic_learned_structure.pdf, Acoustic_implicit_marginals.pdf
- physical_display_arrays.npz, physical_diagnostics.csv, implicit_marginal_arrays.npz, implicit_marginal_diagnostics.csv

Raw results contain every bank ID, validation ID, held-out ID, cached derivative array, learned affine matrix, per-block validation candidates, raw held-out/proposal/display/cubature points and original logp/logq, seeds, timings and failure records. The report is the counterpart of the current Tanh main table/figure, extended table, normalized density/evidence metrics, QMC reference description, numerical checks, and histogram appendix. No manuscript editing occurs in this runner.

## Monitor and retrieve

```bash
cat logs/submitted_ids_production.txt
squeue -u "$USER" -o "%.18i %.18j %.10T %.10M %.6D %R"
python3 ls6/status.py --profile production
# After the production DAG completes:
ls -lh exports/production/INDEX.json exports/production/*.zip
```

The final report job automatically packs raw and summary results into ZIP parts under 25 MB, with SHA256 and a single INDEX.json. Each part extracts into the same relative path tree. Only files listed in the latest INDEX.json belong to that export; old export parts may remain after resumes. To regenerate the export without rerunning expensive fits, submit another report job on a compute node or run `python report.py --profile production && python pack_results.py --profile production` in the campaign environment on a compute node.

The input ZIP contains the fully reproducible reference archive. Output parts omit large Python model caches, but retain bank marks, all model tuning records, raw points/log-densities, checks and table/figure arrays. Keep the original input bundle alongside them.
