"""Blind derivative-bank learning of a coordinate chart and conditional attention."""
import os
for k in ["OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS"]: os.environ[k]="1"
import json,time,argparse,itertools
from pathlib import Path
import numpy as np
from scipy.special import logsumexp, expit
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares
from sklearn.mixture import GaussianMixture
import acoustic_pilot as p
from acoustic_marginal import GNMixture
from quake_partition.learn_partition import couplings,fit,fit_budget,exclusion

OUT=Path(__file__).with_name("learned_results")
LOGZ=-10.293457732920755

def original_marks(t,x):
    """Only target-specific derivative evaluation; the learner receives x,s,H."""
    pos=np.stack([x[:,:8]@t.B.T,x[:,8:]@t.B.T],-1)
    receivers=t.mid+np.array([-t.a,t.a])[:,None]*t.e
    delta=pos[:,:,None,:]-receivers[None,None]
    dist=np.sqrt(np.sum(delta*delta,-1)+t.eps2)
    r=(t.c/(2*t.a)*(dist[:,:,1]-dist[:,:,0])-t.y)/t.sd
    dp=(t.c/(2*t.a*t.sd))*(delta[:,:,1,:]/dist[:,:,1,None]-delta[:,:,0,:]/dist[:,:,0,None])
    J=np.concatenate([dp[:,:,0,None]*t.B[None],dp[:,:,1,None]*t.B[None]],-1)
    return -x-np.einsum("ni,nij->nj",r,J),np.eye(16)+J.transpose(0,2,1)@J

def learn_linear(x,H,seed):
    d=x.shape[1];P=H-np.eye(d)
    ev,U=np.linalg.eigh(P.mean(0))
    if ev.min()<=0: raise ValueError("Need identifiable likelihood curvature on average")
    A=U*ev**(-.5)
    T=A.T@P@A
    # One generic spectral basis preserves each invariant likelihood subspace.
    # Use several random projections and select the first exact-block result.
    for k in range(6):
        w=np.random.default_rng(seed+19+k).normal(size=len(x))
        _,Q=np.linalg.eigh(np.einsum("n,nij->ij",w,T))
        R=A@Q;C=couplings(R.T@P@R)
        part=fit(C,tolerance=1e-7,max_block=4,max_shared=0)
        if part is not None and all(len(b)==2 for b in part["blocks"]):break
    if part is None or any(len(b)!=2 for b in part["blocks"]):
        raise ValueError("Did not recover 2D likelihood blocks")
    # Recover row-space coordinates rather than using the eccentric whitening
    # metric for the nonlinear fit. Orient each by its local mean information.
    V=np.vstack([np.linalg.qr(np.linalg.inv(R)[list(b)].T)[0].T for b in part["blocks"]])
    L=np.linalg.inv(V);PP=L.T@P@L
    for j in range(d//2):
        _,U=np.linalg.eigh(PP[:,2*j:2*j+2,2*j:2*j+2].mean(0))
        V[2*j:2*j+2]=U[:,::-1].T@V[2*j:2*j+2]
    # first all normal coordinates, then transverse
    perm=np.r_[np.arange(0,d,2),np.arange(1,d,2)]
    V=V[perm];A=np.linalg.inv(V)
    newx=x@V.T;newH=A.T@H@A
    info=dict(blocks=part["blocks"],max_off=float(exclusion(C,part["blocks"]).max()),
              eigen_min=float(ev.min()),eigen_max=float(ev.max()),
              original_exact=fit(couplings(H)),original_min_cut=fit_budget(couplings(H),max_block=4,max_shared=4),
              full_curvature_likelihood_block_max=float(exclusion(couplings(R.T@H@R),part["blocks"]).max()))
    return V,A,newx,newH,info

class RidgeChart:
    """Smooth, triangular, invertible data-derived residual and scale map."""
    def __init__(self,t,u,score,Huu,Huv,seed):
        self.mean=t.mean();self.sd=t.std();tt=(t-self.mean)/self.sd
        # smoothly growing features with linear asymptotes; no brittle extrapolation
        self.centers=np.array([-2.,-1.,0.,1.,2.])
        self.widths=[.4,.8,1.5]
        self.sf=None
        rng=np.random.default_rng(seed);ids=rng.permutation(len(t))
        cut=max(int(.8*len(t)),len(t)-max(8,len(t)//5));tr,va=ids[:cut],ids[cut:]
        if not len(va):tr,va=ids,ids
        # derivative consistency target for the level-set ridge
        slope=-Huv/Huu*self.sd
        newton=u+score/Huu
        def train(ids,width,lam,kind,ridge):
            F,D=self.features(tt[ids],width);w=np.sqrt(Huu[ids]/np.median(Huu[ids]))
            label=u[ids] if kind=="raw" else newton[ids]
            A=F*w[:,None];b=label*w
            if lam:
                A=np.vstack([A,np.sqrt(lam)*D*w[:,None]])
                b=np.r_[b,np.sqrt(lam)*slope[ids]*w]
            coef=np.linalg.solve(A.T@A+ridge*np.eye(A.shape[1]),A.T@b)
            S,_=self.scale_features(tt[ids])
            scl=np.linalg.solve(S.T@S+.01*np.eye(S.shape[1]),S.T@(-.5*np.log(Huu[ids])))
            # calibrate variance using bank residuals, not target calls
            sig=np.exp(S@scl);rz=(u[ids]-F@coef)/sig
            adjust=np.clip(np.sqrt(np.mean(rz*rz)),.5,2.)
            scl[0]+=np.log(adjust)
            return coef,scl
        best=None
        for width,lam,kind,ridge in itertools.product(self.widths,[0.,.1,.5,2.],["raw","newton"],[1e-4,.01]):
            coef,scl=train(tr,width,lam,kind,ridge)
            F,_=self.features(tt[va],width);S,_=self.scale_features(tt[va])
            l=S@scl;z=(u[va]-F@coef)*np.exp(-l)
            nll=np.mean(.5*z*z+l)
            if best is None or nll<best[0]:best=(float(nll),width,lam,kind,ridge)
        _,self.width,self.lam,self.kind,self.ridge=best
        self.coef,self.scl=train(ids,self.width,self.lam,self.kind,self.ridge)
        self.selected=best
    def features(self,t,w):
        d=t[:,None]-self.centers
        R=np.sqrt(d*d+w*w)
        return np.c_[np.ones(len(t)),t,R],np.c_[np.zeros(len(t)),np.ones(len(t)),d/R]
    def scale_features(self,t):
        d=t[:,None]-self.centers
        R=np.exp(-.5*d*d)
        return np.c_[np.ones(len(t)),R],np.c_[np.zeros(len(t)),-d*R]
    def functions(self,t):
        F,D=self.features(np.asarray(t),self.width);S,L=self.scale_features(np.asarray(t))
        f=F@self.coef;df=D@self.coef;l=S@self.scl;dl=L@self.scl
        return f,df,np.exp(l),dl

class ResidualChart:
    """Recover a local scalar residual from likelihood score and rank-one GN.

    A monotone inverse chart u=f(v)+sigma(v)*(r+c(v)(sqrt(1+r²)-1))
    is fit to position, residual and both inverse derivatives.
    """
    def __init__(self,t,u,sl,Huu,Huv,seed,safe=False):
        self.mean=t.mean();self.sd=t.std();tt=(t-self.mean)/self.sd
        self.centers=np.linspace(-2.5,2.5,7)
        r=-sl/np.sqrt(Huu);b=Huu**-.5;slope=-Huv/Huu*self.sd
        self.unit=np.median(b)
        self.safe=safe
        self.lo,self.hi=np.quantile(tt,[.005,.995])
        self.scale_lo,self.scale_hi=np.quantile(np.log(b),[.005,.995])+[-.5,.5]
        perm=np.random.default_rng(seed).permutation(len(t));n=max(8,int(.2*len(t)))
        tr,va=perm[:-n],perm[-n:]
        def train(ids,width,nonlin,reg):
            v=tt[ids];rr=r[ids];uu=u[ids];bb=b[ids];dd=slope[ids]
            F,D,G,DG,C,DC=self.features(v,width)
            z=np.linalg.solve(G.T@G+.01*np.eye(G.shape[1]),G.T@np.log(bb))
            ff=np.linalg.solve(F.T@F+1e-6*np.eye(F.shape[1]),F.T@(uu-bb*rr))
            nc=C.shape[1] if nonlin else 0;nf=F.shape[1];ng=G.shape[1]
            init=np.r_[ff/self.unit,z,np.zeros(nc)]
            k=np.sqrt(1+rr*rr)-1;kr=rr/np.sqrt(1+rr*rr)
            def fun(par):
                f=F@par[:nf]*self.unit;df=D@par[:nf]*self.unit
                g=G@par[nf:nf+ng];dg=DG@par[nf:nf+ng]
                if self.safe:g,dg=self.bound(g,dg)
                else:g=np.clip(g,-15,8)
                sig=np.exp(g)
                if nc:
                    tanh=np.tanh(C@par[-nc:]);c=.8*tanh;dc=.8*(1-tanh*tanh)*(DC@par[-nc:])
                else:c=dc=0.
                ur=sig*(1+c*kr)
                pred=f+sig*(rr+c*k)
                uv=df+sig*dg*(rr+c*k)+sig*dc*k
                return np.r_[(pred-uu)/bb,np.log(ur/bb),.25*(uv-dd)/bb,np.sqrt(reg)*par]
            opt=least_squares(fun,init,max_nfev=100,ftol=1e-7,xtol=1e-7)
            par=opt.x
            return par[:nf]*self.unit,par[nf:nf+ng],(par[-nc:] if nc else None)
        best=None
        for width,nonlin,reg in itertools.product([.45,.9,1.5],[False,True],[.01,.1,1.] if safe else [.001,.1]):
            coef,scl,cc=train(tr,width,nonlin,reg)
            self.width,self.coef,self.scl,self.cc=width,coef,scl,cc
            pred,_,_,_,_=self.inverse_local(r[va],tt[va])
            error=np.mean(((pred-u[va])/b[va])**2)
            if best is None or error<best[0]:best=(float(error),width,nonlin,reg)
        _,self.width,nonlin,reg=best
        self.coef,self.scl,self.cc=train(perm,self.width,nonlin,reg)
        self.selected=best
    def features_raw(self,t,w):
        q=t[:,None]-self.centers;R=np.sqrt(q*q+w*w);E=np.exp(-.5*q*q)
        L=np.sqrt(1+t*t)
        F=np.c_[np.ones(len(t)),t,R];D=np.c_[np.zeros(len(t)),np.ones(len(t)),q/R]
        G=np.c_[np.ones(len(t)),np.log(L),t/L,E];DG=np.c_[np.zeros(len(t)),t/(L*L),1/(L**3),-q*E]
        C=np.c_[np.ones(len(t)),t/L,np.exp(-.5*t*t)];DC=np.c_[np.zeros(len(t)),1/(L**3),-t*np.exp(-.5*t*t)]
        return F,D,G,DG,C,DC
    def features(self,t,w):
        if not self.safe:return self.features_raw(t,w)
        # Smooth linear tails for the ridge, constant tails for scale/asymmetry.
        k=8.;a=np.logaddexp(0,k*(self.lo-t))/k;b=np.logaddexp(0,k*(t-self.hi))/k
        sa=expit(k*(self.lo-t));sb=expit(k*(t-self.hi));dc=1-sa-sb
        tt=t+a-b
        F,D,G,DG,C,DC=self.features_raw(tt,w)
        _,D1,_,_,_,_=self.features_raw(np.array([self.lo]),w)
        _,D2,_,_,_,_=self.features_raw(np.array([self.hi]),w)
        return F-a[:,None]*D1+b[:,None]*D2,D*dc[:,None]+sa[:,None]*D1+sb[:,None]*D2,G,DG*dc[:,None],C,DC*dc[:,None]
    def bound(self,g,dg):
        k=8.;lo,hi=self.scale_lo,self.scale_hi
        ll=lo+np.logaddexp(0,k*(g-lo))/k-np.logaddexp(0,k*(g-hi))/k
        return ll,dg*(expit(k*(g-lo))-expit(k*(g-hi)))
    def local(self,v):
        F,D,G,DG,C,DC=self.features(v,self.width)
        f=F@self.coef;df=D@self.coef
        logscale=G@self.scl;dg=DG@self.scl
        # Bound scale smoothly in extreme tails, differentiating the actual map.
        # The bound is many orders wider than the fitted range.
        if self.safe:ll,dg=self.bound(logscale,dg)
        else:
            ll=-15+np.logaddexp(0,logscale+15)-np.logaddexp(0,logscale-8)
            dg=dg*(expit(logscale+15)-expit(logscale-8))
        sig=np.exp(ll)
        if self.cc is not None:
            tanh=np.tanh(C@self.cc);c=.8*tanh;dc=.8*(1-tanh*tanh)*(DC@self.cc)
        else:c=np.zeros(len(v));dc=np.zeros(len(v))
        return f,df,sig,dg,c,dc
    def inverse_local(self,r,v):
        f,df,sig,dg,c,dc=self.local(v)
        L=np.sqrt(1+r*r);k=L-1;kr=r/L;krr=L**-3
        u=f+sig*(r+c*k);ur=sig*(1+c*kr)
        uv=df+sig*dg*(r+c*k)+sig*dc*k
        gr=c*krr/(1+c*kr);gv=dg+dc*kr/(1+c*kr)
        return u,ur,uv,gr,gv
    def forward_local(self,u,v):
        f,df,sig,dg,c,dc=self.local(v)
        w=(u-f)/sig+c
        return (w-c*np.sqrt(w*w+1-c*c))/(1-c*c)

class Chart:
    def __init__(self,x,s,H,seed,nonlinear=True,residual=False,safe=False):
        V,A,y,P,self.info=learn_linear(x,H,seed);self.V=V;self.A=A;self.d=y.shape[1]//2
        S=s@A;SL=(s+x)@A;PL=A.T@(H-np.eye(x.shape[1]))@A
        self.parts=[];self.nonlinear=nonlinear;self.residual=residual
        for i in range(self.d):
            if residual:self.parts.append(ResidualChart(y[:,i+self.d],y[:,i],SL[:,i],PL[:,i,i],PL[:,i,i+self.d],seed+41+i,safe))
            elif nonlinear:self.parts.append(RidgeChart(y[:,i+self.d],y[:,i],S[:,i],P[:,i,i],P[:,i,i+self.d],seed+41+i))
            else:self.parts.append(None)
        self.mean=y.mean(0);self.sd=y.std(0)
        self.const=np.linalg.slogdet(A)[1]
    def transform(self,x):
        y=x@self.V.T
        if not self.nonlinear:return (y-self.mean)/self.sd
        h=y[:,:self.d];v=y[:,self.d:];z=np.empty_like(y)
        for j,m in enumerate(self.parts):
            z[:,j+self.d]=(v[:,j]-m.mean)/m.sd
            if self.residual:z[:,j]=m.forward_local(h[:,j],z[:,j+self.d])
            else:
                f,_,sig,_=m.functions(z[:,j+self.d]);z[:,j]=(h[:,j]-f)/sig
        return z
    def inverse(self,z,derivatives=False):
        z=np.asarray(z);n=len(z);d=self.d;J=np.zeros((n,2*d,2*d));g=np.zeros_like(z);ld=np.full(n,self.const)
        if not self.nonlinear:
            Y=z*self.sd+self.mean;ld+=np.log(self.sd).sum()
            J[:]=np.diag(self.sd)
        else:
            Y=np.empty_like(z)
            for j,m in enumerate(self.parts):
                v=z[:,j+d];h=z[:,j]
                if self.residual:
                    u,ur,uv,gr,gv=m.inverse_local(h,v);Y[:,j]=u;J[:,j,j]=ur;J[:,j,j+d]=uv
                    ld+=np.log(ur)+np.log(m.sd);g[:,j]=gr;g[:,j+d]=gv
                else:
                    f,df,sig,dl=m.functions(v)
                    Y[:,j]=f+sig*h;J[:,j,j]=sig;J[:,j,j+d]=df+sig*dl*h
                    ld+=np.log(sig)+np.log(m.sd);g[:,j+d]=dl
                Y[:,j+d]=m.mean+m.sd*v;J[:,j+d,j+d]=m.sd
        x=Y@self.A.T
        if derivatives:return x,ld,self.A@J,g
        return x,ld
    def marks(self,x,s,H):
        z=self.transform(x);_,ld,J,g=self.inverse(z,True)
        return z,np.einsum("nij,ni->nj",J,s)+g,J.transpose(0,2,1)@H@J
    def validate(self,t,x):
        z=self.transform(x);xp,ld,J,g=self.inverse(z,True)
        eps=1e-5;Js=np.stack([(self.inverse(z+eps*d)[0]-self.inverse(z-eps*d)[0])/(2*eps) for d in np.eye(z.shape[1])],axis=-1)
        s,H=original_marks(t,x);_,ss,_=self.marks(x,s,H)
        def lp(z):
            a,b=self.inverse(z);return t.old_lp(a)+b
        fd=np.stack([(lp(z+eps*d)-lp(z-eps*d))/(2*eps) for d in np.eye(z.shape[1])],axis=-1)
        return dict(inverse=float(np.max(np.abs(x-xp))),jacobian=float(np.max(np.abs(J-Js))),
                    logdet=float(np.max(np.abs(np.linalg.slogdet(Js)[1]-ld))),score=float(np.max(np.abs(ss-fd))))

def learned_structure(H):
    d=H.shape[1]//2;W=couplings(H)
    # Allow an approximate split only after checking all cross-block couplings.
    # Choose smallest threshold giving a separator-free partition, max block 2.
    part=fit_budget(W[:d,:d],max_block=2,max_shared=0)
    return part, W

if __name__=="__main__":
    ap=argparse.ArgumentParser();ap.add_argument("--seed",type=int,default=23000);ap.add_argument("--N",type=int,default=256);a=ap.parse_args()
    t=p.Target();r=np.load(p.REF)["samples_by_chain"];train=r[:2].reshape(-1,16);test=r[2:].reshape(-1,16)
    x=train[np.random.default_rng(a.seed).permutation(len(train))[:a.N]]
    s,H=original_marks(t,x)
    for nonlinear in [False,True]:
        chart=Chart(x,s,H,a.seed,nonlinear);z,S,P=chart.marks(x,s,H);part,W=learned_structure(P)
        y=chart.transform(test[:1024]);print("nonlinear",nonlinear,"std",np.round(y.std(0),2),"structure",chart.info,flush=True)
        print("partition",part,"Wzz",np.round(W[:8,:8],3),"Wzv",np.round(W[:8,8:],3),flush=True)
        print("validation",chart.validate(t,test[:8]),flush=True)
        if nonlinear:print("selected",[q.selected for q in chart.parts],flush=True)
