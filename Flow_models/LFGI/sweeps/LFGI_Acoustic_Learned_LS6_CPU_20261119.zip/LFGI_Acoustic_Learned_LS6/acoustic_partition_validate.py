"""Structural, coordinate and query-conditioned flow checks."""
import acoustic_learned as l
import acoustic_attention as a
import acoustic_pilot as p
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.integrate import solve_ivp
import json

def subspace_error(V,t):
    # Physical time rows are used ONLY for validation, after learning.
    Q=[]
    for row in t.B:
        Q.append(np.stack([np.r_[row,np.zeros_like(row)],np.r_[np.zeros_like(row),row]])/np.linalg.norm(row))
    d=len(Q);err=np.empty((d,d))
    for i in range(d):
        basis=V[[i,i+d]]
        ortho=np.linalg.qr(basis.T)[0].T
        for j,q in enumerate(Q):
            err[i,j]=np.linalg.norm(ortho.T@ortho-q.T@q,2)
    i,j=linear_sum_assignment(err)
    return dict(max_projector_error=float(err[i,j].max()),assignment=j.tolist())

def pf_details(m,y,v,reverse,rtol):
    f=m.field(v,"lfgi",1.);n,d=y.shape
    def rhs(u,state):
        dy,dl=f.rhs(state[:n*d].reshape(n,d),np.exp(u))
        return np.exp(u)*np.r_[dy.ravel(),dl]
    lo,hi=np.log(m.tau),np.log(8.)
    res=solve_ivp(rhs,(hi,lo) if reverse else (lo,hi),np.r_[y.ravel(),np.zeros(n)],method="DOP853",rtol=rtol,atol=.01*rtol)
    assert res.success
    q=res.y[:n*d,-1].reshape(n,d);L=res.y[n*d:,-1]
    return q,L

def main():
    t=p.Target();ref=np.load(p.REF)["samples_by_chain"];train=ref[:2].reshape(-1,16);test=ref[2:].reshape(-1,16)
    rows=[]
    for N in [256,1024]:
        for seed in [23000,23001,23002]:
            idx=np.random.default_rng(seed).permutation(len(train));x=train[idx[:N]];s,H=l.original_marks(t,x)
            c=l.Chart(x,s,H,seed,False)
            _,_,P,_=c.inverse(c.transform(x),True)
            Q=np.linalg.qr(np.random.default_rng(seed+55).normal(size=(16,16)))[0]
            V,_,_,_,info=l.learn_linear(x@Q,Q.T@H@Q,seed)
            # Projector error in original coordinate system after blind rotation.
            row=dict(seed=seed,N=N,structure=c.info,subspace=subspace_error(c.V,t),blind_rotation=subspace_error(V@Q.T,t),rotated_likelihood_max_excluded=info["max_off"])
            Hlik=c.A.T@(H-np.eye(16))@c.A
            sl=Hlik[:,np.r_[np.arange(8),np.arange(8,16)]]
            eig=np.stack([np.linalg.eigvalsh(Hlik[:,[j,j+8]][:,:,[j,j+8]]) for j in range(8)],axis=1)
            row["rank_one_ratio_max"]=float(np.max(np.abs(eig[:,:,0])/eig[:,:,1]))
            rows.append(row)
    x=train[np.random.default_rng(23000).permutation(len(train))[:256]];s,H=l.original_marks(t,x)
    c=l.Chart(x,s,H,23000,False);z,ss,PP=c.marks(x,s,H)
    yy=c.transform(test[:8]);v=yy[:,8:]
    control={}
    for B in [[0],[0,1]]:
        b=a.Block(z,ss,PP,B,np.arange(8,16),B,.5)
        f=b.field(v,"lfgi",1.);m=b.field(v,"lfgi",0.)
        # Algebraic invariance of the GN component centers.
        centers=f.x+np.einsum("nij,qnj->qni",b.inv,f.sc,optimize=True)
        mu,_=b.gn_params(v);control[str(B)]={"Newton_center_max_error":float(np.max(np.abs(centers-mu)))}
        for t0 in [b.tau, .003, .1,1.]:
            y=yy[:,B];d=len(B);eps=1e-5
            drift,div=f.rhs(y,t0);num=np.zeros(len(y))
            for j in range(d):
                delta=eps*np.eye(d)[j]
                num+=(f.rhs(y+delta,t0)[0][:,j]-f.rhs(y-delta,t0)[0][:,j])/(2*eps)
            control[str(B)][f"divergence_error_{t0:g}"]=float(np.max(np.abs(div-num)))
        y=yy[:4,B];vv=v[:4]
        end,L=pf_details(b,y,vv,False,2e-5)
        back,Lb=pf_details(b,end,vv,True,2e-5)
        end2,L2=pf_details(b,y,vv,False,1e-8)
        control[str(B)].update(state_roundtrip=float(np.max(np.abs(y-back))),logdet_roundtrip=float(np.max(np.abs(L+Lb))),logq_refined=float(np.max(np.abs(p.normal_lp(end2)+L2-p.normal_lp(end)-L))))
    (l.OUT/"structure_validation.json").write_text(json.dumps(dict(rows=rows,dynamic_controls=control),indent=2))
    print(json.dumps(dict(max_projector=max(r["subspace"]["max_projector_error"] for r in rows),
                          max_rotated=max(r["blind_rotation"]["max_projector_error"] for r in rows),
                          max_off=max(r["structure"]["max_off"] for r in rows),
                          max_rank_one_ratio=max(r["rank_one_ratio_max"] for r in rows),
                          controls=control),indent=2))

if __name__=="__main__":main()
