#!/usr/bin/env python3
"""Acoustic-120 density surrogate screen, exact receiver-coordinate change."""
import os
os.environ["OPENBLAS_NUM_THREADS"]="1"
os.environ["OMP_NUM_THREADS"]="1"
import argparse,json,time
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.linear_model import Ridge

ROOT=Path(__file__).parent
OLD=ROOT/"old/LFGI_Acoustic_vs_S2_Investigation/Experiment"
DATA=OLD/"acoustic/data"
REF=OLD/"acoustic/saved/arrival120/reference/samples.npz"
OUT=ROOT/"pilot_results"

class Target:
    def __init__(self):
        d=json.loads((DATA/"arrival120.json").read_text())
        self.B=np.load(DATA/"basis.npz")["Bobs"][:,:8]
        self.Bi=np.linalg.inv(self.B)
        receivers=np.array(d["receiver_positions_m"])
        self.mid=receivers.mean(0)
        vec=receivers[1]-receivers[0]
        self.a=np.linalg.norm(vec)/2
        self.e=vec/(2*self.a)
        self.n=np.array([-self.e[1],self.e[0]])
        self.mpar=self.mid@self.e
        self.mperp=self.mid@self.n
        self.c=2*self.a*1e6/d["sound_speed_m_s"]
        self.sd=d["tdoa_noise_sd_us"]
        self.y=np.array(d["y"]).ravel()
        self.eps2=d["range_regularization_m"]**2
        self.h0=-self.y/self.c
        self.eta0=np.arctanh(self.h0)
        self.eta_scale=self.sd/self.c/(1-self.h0**2)
        self.const=np.sum(np.log(self.eta_scale))-np.linalg.slogdet(self.B)[1]
    def split(self,x):
        return x[:,:8]*self.e[0]+x[:,8:]*self.e[1],x[:,:8]*self.n[0]+x[:,8:]*self.n[1]
    def to_new(self,x):
        ax,v=self.split(x)
        p=ax@self.B.T-self.mpar
        u=v@self.B.T-self.mperp
        d1=np.sqrt((p+self.a)**2+u*u+self.eps2)
        d2=np.sqrt((p-self.a)**2+u*u+self.eps2)
        h=2*p/(d1+d2)
        eta=np.arctanh(h)
        return np.c_[(eta-self.eta0)/self.eta_scale,v]
    def parts(self,z):
        eta=self.eta0+z[:,:8]*self.eta_scale
        v=z[:,8:]
        u=v@self.B.T-self.mperp
        h=np.tanh(eta)
        ch=np.cosh(eta)
        W=(u*u+self.eps2)*ch*ch
        M=self.a**2+W
        p=h*np.sqrt(M)
        ax=(p+self.mpar)@self.Bi.T
        R=np.c_[ax,v,(-self.c*h-self.y)/self.sd]
        logdet=np.log(self.a**2/(ch*ch)+W)-.5*np.log(M)
        return R,logdet.sum(1)+self.const
    def to_old(self,z):
        r,_=self.parts(z)
        ax=r[:,:8];v=r[:,8:16]
        return np.c_[ax*self.e[0]+v*self.n[0],ax*self.e[1]+v*self.n[1]]
    def old_lp(self,x):
        ax,v=self.split(x)
        p=ax@self.B.T-self.mpar;u=v@self.B.T-self.mperp
        d1=np.sqrt((p+self.a)**2+u*u+self.eps2)
        d2=np.sqrt((p-self.a)**2+u*u+self.eps2)
        r=(self.c*(d2-d1)/(2*self.a)-self.y)/self.sd
        return -.5*(np.sum(x*x,1)+np.sum(r*r,1))
    def lp(self,z):
        r,l=self.parts(z)
        return -.5*np.sum(r*r,1)+l
    def bank(self,z):
        r,l=self.parts(z)
        J=np.empty((len(z),24,16));g=np.empty_like(z)
        for j in range(16):
            w=z.astype(complex);w[:,j]+=1e-25j
            rr,ll=self.parts(w);J[:,:,j]=rr.imag/1e-25;g[:,j]=ll.imag/1e-25
        s=g-np.einsum("nri,nr->ni",J,r)
        H=J.transpose(0,2,1)@J
        return s,H
    def check(self,x):
        z=self.to_new(x);delta=np.max(np.abs(self.to_old(z)-x))
        lp_error=np.max(np.abs(self.lp(z)-self.old_lp(x)-self.parts(z)[1]))
        s,H=self.bank(z)
        fd=np.column_stack([(self.lp(z+1e-5*np.eye(16)[j])-self.lp(z-1e-5*np.eye(16)[j]))/2e-5 for j in range(16)])
        return dict(inverse_max=delta,log_density_max=lp_error,score_fd_max=np.max(np.abs(s-fd)),GN_min=np.min(np.linalg.eigvalsh(H)))

def normal_lp(z):
    return -.5*np.sum(z*z,1)-.5*z.shape[1]*np.log(2*np.pi)

class Field:
    """Analytic divergence, same shared-bank GN resolvent as manuscript."""
    def __init__(self,x,s,H,v=None,cond=None):
        self.x=x;self.s=s;self.H=H
        self.Hflat=H.reshape(len(x),-1)
        self.d=x.shape[1];self.I=np.eye(self.d)
        self.cond=cond
        if v is not None:
            vv,cross=v
            C=np.cov(vv.T);Cinv=np.linalg.inv(C);beta=len(x)**(-1/(vv.shape[1]+4))
            dv=cond[:,None]-vv[None]
            self.logw=-np.sum((dv@Cinv)*dv,2)/(2*beta*beta)
            self.sc=s[None]-np.einsum("nij,qnj->qni",cross,dv,optimize=True)
        else:self.logw=0.;self.sc=s[None]
    def rhs(self,y,t):
        a=np.exp(-t);g=-np.expm1(-2*t)
        dx=y[:,None]-a*self.x
        logw=-np.sum(dx*dx,axis=2)/(2*g)+self.logw
        w=np.exp(logw-logsumexp(logw,axis=1)[:,None])
        mu=w@self.x
        sc=np.sum(w[:,:,None]*self.sc,axis=1)
        H=(w@self.Hflat).reshape(-1,self.d,self.d)
        A=a*a*self.I+g*H;Ai=np.linalg.inv(A)
        delta=a*mu-y
        sval=(Ai@(a*sc+(H@delta[...,None])[...,0])[...,None])[...,0]
        dx=self.x[None]-mu[:,None]
        ds=self.sc-sc[:,None]
        # Trace of A^{-1} [a²/g (Cov(s,x)+H Cov(x,x)) - H + K],
        # K=Cov(H_i a(b-sval), x).  Pi v computed with one GEMM.
        Bdx=dx@Ai
        hd=dx@H
        v=a*(delta/g-sval)
        Pv=(self.H.reshape(-1,self.d)@v.T).T.reshape(len(y),len(self.x),self.d)
        hv=(H@v[...,None])[...,0]
        tr=np.sum(w*np.sum(Bdx*(a*a/g*(ds+hd)+Pv-hv[:,None]),2),1)-np.sum(Ai*H,axis=(1,2))
        return -y-sval,-self.d-tr

def integrate(x,s,H,z,reverse=False,vbank=None,cond=None,tau=1e-4,rtol=2e-5):
    y=[];l=[]
    for i in range(0,len(z),16):
        zz=z[i:i+16];m,d=zz.shape
        f=Field(x,s,H,vbank,None if cond is None else cond[i:i+16])
        def rhs(logt,state):
            t=np.exp(logt);dy,dl=f.rhs(state[:m*d].reshape(m,d),t)
            return t*np.r_[dy.ravel(),dl]
        lo,hi=np.log(tau),np.log(8)
        res=solve_ivp(rhs,(hi,lo) if reverse else (lo,hi),np.r_[zz.ravel(),np.zeros(m)],method="DOP853",rtol=rtol,atol=rtol*.01)
        if not res.success:raise RuntimeError(res.message)
        yy=res.y[:m*d,-1].reshape(m,d);ll=res.y[m*d:,-1]
        y.append(yy);l.append(ll)
    return np.concatenate(y),np.concatenate(l)

def bridge(lp,lq,lpq,lqq):
    rp=lp-lq;rq=lpq-lqq
    def logmean(x):return logsumexp(x)-np.log(len(x))
    def fn(z):
        return logmean(rq-np.logaddexp(rq,z))-logmean(-np.logaddexp(rp,z))-z
    Z=brentq(fn,min(rp.min(),rq.min())-40,max(rp.max(),rq.max())+40)
    return dict(logZ=Z,overlap=float(np.mean(2/(1+np.exp(np.clip(Z-rq,-700,700))))),IS_ESS_fraction=float(np.exp(2*logsumexp(rq)-logsumexp(2*rq))/len(rq)))

def fit_gmm(x,seed):
    reg=1e-5*np.trace(np.cov(x.T))/x.shape[1]
    fits=[GaussianMixture(k,reg_covar=reg,n_init=3,max_iter=400,random_state=seed).fit(x) for k in [1,2,4,8] if len(x)>=k*10]
    return min(fits,key=lambda f:f.bic(x))

def draw_gmm(g,rng,n):
    i=rng.choice(g.n_components,size=n,p=g.weights_)
    return g.means_[i]+np.einsum("nij,nj->ni",np.linalg.cholesky(g.covariances_)[i],rng.normal(size=(n,g.means_.shape[1])))

def cond_gmm(g,v):
    # X first, conditioning variables last. Exact conditional mixture.
    mu=g.means_;C=g.covariances_;d=mu.shape[1]-v.shape[1]
    G=C[:,:d,d:]@np.linalg.inv(C[:,d:,d:])
    S=C[:,:d,:d]-G@C[:,d:,:d]
    dv=v[:,None]-mu[None,:,d:]
    m=mu[None,:,:d]+np.einsum("kij,qkj->qki",G,dv)
    V=C[:,d:,d:];vi=np.linalg.inv(V)
    W=np.log(g.weights_)[None]-.5*np.linalg.slogdet(V)[1][None]-.5*np.einsum("qki,kij,qkj->qk",dv,vi,dv)
    W-=logsumexp(W,axis=1)[:,None]
    return m,S,W

def condlp(g,h,v):
    m,S,W=cond_gmm(g,v);dx=h[:,None]-m
    return logsumexp(W-.5*h.shape[1]*np.log(2*np.pi)-.5*np.linalg.slogdet(S)[1][None]-.5*np.einsum("qki,kij,qkj->qk",dx,np.linalg.inv(S),dx),axis=1)

def conddraw(g,v,rng):
    m,S,W=cond_gmm(g,v);i=(rng.random(len(v))[:,None]>np.cumsum(np.exp(W),axis=1)).sum(1).clip(max=g.n_components-1)
    return m[np.arange(len(v)),i]+np.einsum("nij,nj->ni",np.linalg.cholesky(S)[i],rng.normal(size=(len(v),m.shape[2])))

def summarise(name,lp,lq,lpq,lqq,seconds):
    r=lp-lq
    result=dict(method=name,centered_SD=float(r.std()),mean_log_ratio=float(r.mean()),mean_logq=float(lq.mean()),mean_proposal_logratio=float((lpq-lqq).mean()),seconds=seconds,**bridge(lp,lq,lpq,lqq))
    print(json.dumps(result),flush=True);return result

class GNConditional:
    def __init__(self,x,s,H):
        self.x=x[:,:8];self.v=x[:,8:];self.s=s[:,:8];self.H=H[:,:8,:8];self.cross=H[:,:8,8:]
        self.inv=np.linalg.inv(self.H);self.L=np.linalg.cholesky(self.inv);self.ld=np.linalg.slogdet(self.H)[1]
        self.Ci=np.linalg.inv(np.cov(self.v.T));self.beta=len(x)**(-1/12)
    def params(self,v):
        dv=v[:,None]-self.v
        lw=-.5*np.sum((dv@self.Ci)*dv,axis=2)/self.beta**2;lw-=logsumexp(lw,axis=1)[:,None]
        s=self.s[None]-np.einsum("nij,qnj->qni",self.cross,dv,optimize=True)
        mu=self.x[None]+np.einsum("nij,qnj->qni",self.inv,s,optimize=True)
        return mu,lw
    def logq(self,h,v):
        out=[]
        for i in range(0,len(h),64):
            mu,lw=self.params(v[i:i+64]);d=h[i:i+64,None]-mu
            out.append(logsumexp(lw+.5*self.ld[None]-4*np.log(2*np.pi)-.5*np.einsum("qni,nij,qnj->qn",d,self.H,d,optimize=True),axis=1))
        return np.concatenate(out)
    def draw(self,v,rng):
        mu,lw=self.params(v);i=(rng.random(len(v))[:,None]>np.cumsum(np.exp(lw),axis=1)).sum(1).clip(max=len(self.x)-1)
        return mu[np.arange(len(v)),i]+np.einsum("nij,nj->ni",self.L[i],rng.normal(size=(len(v),8)))

class NonlinearConditional:
    """Validation-selected conditional Gaussian with nonlinear mean."""
    def __init__(self,x,target,seed):
        self.target=target
        self.poly=PolynomialFeatures(degree=2,include_bias=False)
        self.poly.fit(x[:,8:])
        rng=np.random.default_rng(seed+20);order=rng.permutation(len(x));k=int(.8*len(x));tr,va=order[:k],order[k:]
        h=x[:,:8];v=x[:,8:]
        best=None
        for features in ["linear","poly","geometry","both"]:
            xx=self.feat(v,features)
            for ridge in [0.1,1,10,100]:
                sc=StandardScaler().fit(xx[tr]);rr=Ridge(alpha=ridge).fit(sc.transform(xx[tr]),h[tr]);res=h[tr]-rr.predict(sc.transform(xx[tr]))
                C=np.cov(res.T)+.02*np.eye(8);ll=self.gauss(h[va]-rr.predict(sc.transform(xx[va])),C).mean()
                if best is None or ll>best[0]:best=(ll,features,ridge)
        _,self.features,self.ridge=best
        xx=self.feat(v,self.features);self.scaler=StandardScaler().fit(xx);self.reg=Ridge(alpha=self.ridge).fit(self.scaler.transform(xx),h)
        self.C=np.cov((h-self.mu(v)).T)+.02*np.eye(8);self.L=np.linalg.cholesky(self.C)
    def feat(self,v,kind):
        u=v@self.target.B.T-self.target.mperp
        geo=np.sqrt(self.target.a**2+(u*u+self.target.eps2)/(1-self.target.h0**2))
        if kind=="linear":return v
        if kind=="poly":return self.poly.transform(v)
        if kind=="geometry":return np.c_[v,geo]
        return np.c_[self.poly.transform(v),geo]
    def mu(self,v):return self.reg.predict(self.scaler.transform(self.feat(v,self.features)))
    @staticmethod
    def gauss(d,C):
        return -.5*np.sum((d@np.linalg.inv(C))*d,1)-.5*np.linalg.slogdet(C)[1]-4*np.log(2*np.pi)
    def logq(self,h,v):return self.gauss(h-self.mu(v),self.C)
    def draw(self,v,rng):return self.mu(v)+rng.normal(size=(len(v),8))@self.L.T

def run(seed,N,M,method,rtol):
    target=Target();ref=np.load(REF)["samples_by_chain"]
    bank=ref[:2].reshape(-1,16);test=ref[2:].reshape(-1,16)
    idx=np.random.default_rng(seed).permutation(len(bank))[:N]
    ids=np.random.default_rng(seed+200000).permutation(len(test))[:M]
    oldx=bank[idx];oldt=test[ids];x=target.to_new(oldx);y=target.to_new(oldt)
    score,H=target.bank(x)
    lp=target.lp(y)
    print("checks",json.dumps(target.check(oldt[:8])),flush=True)
    print("new bank mean/std",np.round(x.mean(0),2),np.round(x.std(0),2),flush=True)
    rng=np.random.default_rng(seed+300000)
    results=[]
    g=fit_gmm(x,seed);gv=fit_gmm(x[:,8:],seed)
    print("GMM components",g.n_components,gv.n_components,flush=True)
    if method in ("all","baseline"):
        for name,g0 in [("transformed_GMM",g),("original_GMM",fit_gmm(oldx,seed))]:
            tick=time.monotonic()
            if name.startswith("original"):
                pp=draw_gmm(g0,rng,M);q=target.to_new(pp)
                lq=g0.score_samples(oldt)+target.parts(y)[1];lqq=g0.score_samples(pp)+target.parts(q)[1]
            else:
                q=draw_gmm(g0,rng,M);lq=g0.score_samples(y);lqq=g0.score_samples(q)
            results.append(summarise(name,lp,lq,target.lp(q),lqq,time.monotonic()-tick))
        for name,model in [("conditional_GN_mixture",GNConditional(x,score,H)),("conditional_nonlinear_regression",NonlinearConditional(x,target,seed))]:
            tick=time.monotonic();v=draw_gmm(gv,rng,M);q=np.c_[model.draw(v,rng),v]
            lq=gv.score_samples(y[:,8:])+model.logq(y[:,:8],y[:,8:]);lqq=gv.score_samples(v)+model.logq(q[:,:8],v)
            results.append(summarise(name,lp,lq,target.lp(q),lqq,time.monotonic()-tick))
        for name,cg in [("conditional_Gaussian",GaussianMixture(1,reg_covar=1e-5).fit(x)),("conditional_GMM",g)]:
            tick=time.monotonic();v=draw_gmm(gv,rng,M);q=np.c_[conddraw(cg,v,rng),v]
            lq=gv.score_samples(y[:,8:])+condlp(cg,y[:,:8],y[:,8:]);lqq=gv.score_samples(v)+condlp(cg,q[:,:8],v)
            results.append(summarise(name,lp,lq,target.lp(q),lqq,time.monotonic()-tick))
    if method in ("all","joint"):
        tick=time.monotonic()
        z=rng.normal(size=(M,16));q,L=integrate(x,score,H,z,True,rtol=rtol)
        yt,Lt=integrate(x,score,H,y,rtol=rtol)
        lq=normal_lp(yt)+Lt;lqq=normal_lp(z)-L
        results.append(summarise("transformed_joint_LFGI",lp,lq,target.lp(q),lqq,time.monotonic()-tick))
        np.savez_compressed(OUT/f"joint_{seed}_{N}_{M}.npz",y=y,q=q,lq=lq,lqq=lqq,lp=lp,lpq=target.lp(q))
    if method in ("all","conditional","dpsmc"):
        tick=time.monotonic();v=draw_gmm(gv,rng,M);z=rng.normal(size=(M,8))
        vb=(x[:,8:],H[:,:8,8:]);sx=score[:,:8];HH=H[:,:8,:8];xx=x[:,:8]
        cases=[]
        if method!="dpsmc":cases.append(("conditional_LFGI",HH))
        if method in ("all","dpsmc"):cases.append(("conditional_DPSMC",np.broadcast_to(sx.T@sx/len(sx),HH.shape).copy()))
        for name,HH0 in cases:
            tick=time.monotonic()
            qh,L=integrate(xx,sx,HH0,z,True,vb,v,rtol=rtol)
            yT,Lt=integrate(xx,sx,HH0,y[:,:8],False,vb,y[:,8:],rtol=rtol)
            lq=normal_lp(yT)+Lt+gv.score_samples(y[:,8:]);lqq=normal_lp(z)-L+gv.score_samples(v);q=np.c_[qh,v]
            results.append(summarise(name,lp,lq,target.lp(q),lqq,time.monotonic()-tick))
            np.savez_compressed(OUT/f"{name}_{seed}_{N}_{M}.npz",y=y,q=q,lq=lq,lqq=lqq,lp=lp,lpq=target.lp(q))
    (OUT/f"{seed}_{N}_{M}_{method}.json").write_text(json.dumps(results,indent=2))

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--seed",type=int,default=23000);p.add_argument("--N",type=int,default=256);p.add_argument("--M",type=int,default=64);p.add_argument("--method",default="all");p.add_argument("--rtol",type=float,default=2e-5);a=p.parse_args()
    OUT.mkdir(exist_ok=True)
    run(a.seed,a.N,a.M,a.method,a.rtol)
