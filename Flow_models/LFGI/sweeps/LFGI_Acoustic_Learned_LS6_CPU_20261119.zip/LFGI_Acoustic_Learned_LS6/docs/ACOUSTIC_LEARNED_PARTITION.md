# Learned curvature decomposition and conditional attention for Acoustic-120

19 November 2026 — exploratory screen, not production figures.

## Conclusion

There is a workable analogue of the earthquake partition learner for the unchanged 16-dimensional acoustic trajectory posterior. Unlike earthquake, the exact hard separator is not visible in the supplied KL basis. A spectral congruence transformation of the cached likelihood-curvature marks recovers eight two-dimensional local subspaces (one per observation time). The allocation of one local normal coordinate and one clean context coordinate per subspace is learned from mean likelihood curvature, without the receiver geometry. The full posterior is not an exact conditional product because of the trajectory prior, but the excluded normal-normal couplings are small in the recovered basis.

The preferred construction uses **only an affine learned chart**, a sample-fitted joint context marginal, and eight conditional scalar LFGI flows with learned masks, bandwidths and query-dependent movement of cached reference particles. This retains the original nonlinear conditional geometry; the local matrix gate (a scalar for a singleton) is useful. A nonlinear learned chart can also be fit, but largely Gaussianizes the conditionals and makes the DPSMC gate/direct GN mixture much more competitive. We do not need the previous bespoke range-difference inverse to obtain a useful surrogate.

The strongest LFGI configuration has the lowest held-out mean density RMSE in six of six comparisons with the independently bandwidth-tuned direct GN mixture, with gains of 6–8% relative to that strong comparator. It has substantially better held-out density than the matched DPSMC gate and selected GMM. Bridge estimates are not uniformly best, and small pilot batches do not establish evidence dominance.

## Inputs, provenance and protocol

The target, NUTS chains and independent QMC evidence reference are unchanged from the earlier acoustic viability pilot. Four archived chains with ten thousand retained states per chain; the first two constitute the fitting pool, the last two the test pool. The target is 8 KL coefficients per physical trajectory coordinate, 8 measurements, arrival noise 120 microseconds. The learner is given only the fitting (x_i,s_i,P_i) and the known whitened Gaussian prior (score (-x), information (I)). The code computes these from unchanged target data. The physical sensor locations, forward map formula, time labels and KL basis are **not inputs to the learner**. The original target is evaluated for true full-dimensional density/evidence, numerical validation, and derivative-mark acquisition.

Three nested bank selections (seeds 23000–23002) at N=256,1024. Each uses 64 additional fitting-pool coordinate-only states, disjoint from its bank, for model selection. The same 128 held-out posterior points and 128 proposal draws per bank are used for all metrics; the held-out set is a subset of the earlier pilot's 256 points for that seed. The bank sizes count states with cached derivatives; the 64 validation states are additional coordinate-only information, supplied equally to all comparators. Bridge batches use a common context proposal and terminal random stream where possible. Finite errors are calibrated with the previous independent QMC logZ=-10.293457732920755. No new physical target is introduced. Uncertainty remains conditional on the overlapping bank selections in a single fixed archived posterior.

## 1. Learning subspaces rather than just coordinate masks

Write the posterior GN matrix as (P_i=I+L_i). The original-coordinate normalized GN graph has *all 120 possible off-diagonal edges*, so the supplied earthquake exact separator optimization is infeasible (up to 4 shared coordinates, max local size 8). A representative approximate cut under four shared coordinates and max local size four needs to discard coupling as high as 0.43. Direct use of such a partition is a poor density surrogate (one N=256 screen: LFGI density RMSE 85.6).

The likelihood information family (L_i), however, is simultaneously block diagonalizable **by congruence** in an unknown basis. Let (L_star=N^{-1}sum_i L_i). It is positive definite on average in the acoustic bank, even though individual (L_i) have rank eight. Construct a whitening (A_0) with (A_0^T L_star A_0=I), and form (C_i=A_0^T L_i A_0). Diagonalize a generic random linear combination of (C_i) to get an orthogonal (Q). Set (A=A_0 Q). If the (C_i) share orthogonal invariant blocks, generic eigenvectors are block-local apart from accidental eigenvalue ties. Run the supplied RMS-coupling graph search on (A^T L_i A) at threshold (10^{-7}). The discovered blocks do not require the physical ordering or labels.

Recover well-scaled row-space coordinates by taking the rows of (A^{-1}) associated with each block and orthonormalizing them inside that block. Stack these local row bases; the full matrix is generally not orthogonal. Rotate each pair by the eigenvectors of its mean local likelihood information. The larger-information eigenvector defines the normal coordinate, the lower-information one the context coordinate. Empirically center and scale each coordinate. This learner specifically handles identifiable rank-one likelihood factors on two-dimensional subspaces of a whitened Gaussian-prior problem; do not claim universal latent-basis recovery.

Structural checks:

- All 6 bank selections recovered exactly eight 2D likelihood blocks. Maximum excluded likelihood coupling (2.77\times10^{-11}).
- Physical observation-time row spaces were used only after fitting to check recovery: maximum projector error (2.74\times10^{-12}), allowing arbitrary signs and order.
- Repeat learning after independent dense orthogonal rotations of the entire prior-whitened bank and marks: projector error (1.25\times10^{-11}) after undoing the rotation.
- Each recovered local likelihood curvature block is rank one in every evaluated bank state (largest absolute small/large eigenvalue ratio (1.66\times10^{-15})).
- In the learned affine normal/context chart, for the selected singleton normal blocks, maximal between-normal RMS full-GN couplings range 0.01594–0.01767. These are nonzero because of the prior; we retain the full original energy to test the approximation.

See learned_results/learned_structure.png and structure_validation.json. The original graph is dense; the likelihood-only graph becomes block diagonal after learning; full posterior normal/context interactions are sparse but not exactly separable.

## 2. Learning conditional partition and attention

Let (z) contain the eight centered/scaled high-information normal coordinates and (v) the eight lower-information context coordinates. Fit a normalized surrogate

    q(z,v) = q_v(v) product_b q_b(z_b | v).

The joint context (q_v) is a full-covariance BIC-selected Gaussian mixture, just as in the earthquake construction. In the normal block, select among partitions with maximum local size 1,2,4 and an unsplit eight-dimensional conditional. For each size cap, use the supplied minimum-cutoff RMS-coupling graph rule. For each candidate block (B), rank context coordinates by the maximum normalized RMS (P_{BC}) coupling to it, and consider top 0, |B|, 2|B|, 4, or all 8 coordinates. Candidate attention bandwidths multiply Scott's rule based on selected context dimension. Learn a partition and masks by the conditional GN-mixture validation NLL; this fast model-selection proxy also favors the derivative-aware comparator.

For a query clean context (v), let (C_B) be the selected mask. The context logits are

    - (v-v_i)[C_B]^T Cov(v[C_B])^{-1} (v-v_i)[C_B]
      / (2 beta_B^2 N^{-2/(|C_B|+4)}).

Every block can depend through its score linearization on *all* clean context coordinates, including those omitted from the attention kernel. This is important: dropping a context from attention does not assert its conditional effect is zero. The product approximation does omit dependencies between normal blocks; the full-target density and bridge evaluation checks their consequences.

In all 6 selections the validation NLL chose 8 singleton normal blocks. Of 48 local kernels, 42 choose one context coordinate, 5 choose two, 1 chooses four. These are the learned spatially local attention masks, not a physical partition supplied to the density estimator.

## 3. Context-dependent movement of reference marks

The earthquake method shifts conditional scores at their original reference locations. This experiment tests a closely related **query-conditioned movement of both marked locations and scores**. For a block (B), define

    delta_i(v) = -P_i,BB^{-1} P_i,BC (v-v_i).

For a scalar movement fraction kappa in [0,1], use

    z_i'(v) = z_i + kappa delta_i(v)
    s_i'(v) = s_i,B - (1-kappa) P_i,BC (v-v_i).

The usual local OU kernel now attends to z_i'(v) instead of z_i. The LFGI matrix gate uses the pooled P_i,BB, transformed scores and reference states. At kappa=0 this is the original earthquake-style score shift; at kappa=1 the reference is moved along the estimated conditional mean displacement and its score is retained under the same local linearization.

Crucially the direct GN component mean is unchanged:

    z_i'+P_i,BB^{-1}s_i' = z_i+P_i,BB^{-1}(s_i,B-P_i,BC(v-v_i)).

Hence the standalone conditional GN mixture does not benefit merely from moving its reference points. Conditional movement changes how empirical points are pooled in the LFGI flow, not the Newton prediction of the comparator. Since context is fixed through each local ODE, these context-dependent locations and scores are fixed in the local flow variable and the analytic divergence remains valid. The normalized conditional PF construction is unchanged. This is an approximation based on local GN cross information, not a claim that the shifted marks are exact derivatives of the new conditional posterior.

The fixed-movement ablation uses kappa=0 or 1 for all blocks. The tuned construction first learns masks and partition using the GN proxy and a wider bandwidth grid .25,.35,.5,.75,1,1.5,2,3. Then for each block evaluates the actual LFGI conditional log density on the validation set, choosing kappa=0,.5,1 and beta in {max(.125,beta_GN/2), beta_GN, min(4,1.5 beta_GN)}. Validation tuning is local per factor. Of 48 tuned factors, 14 choose kappa=0, 11 choose .5, 23 choose 1. The selected bandwidths are mostly narrow: 26 choose .125, 11 choose .25; this is distinct from a single globally chosen bandwidth. Selection uses no test-chain labels.

The direct GN comparator is evaluated both at the LFGI-selected bandwidth and independently at its validation-optimized bandwidth. The DPSMC control keeps the selected context, moved bank and score marks, with constant empirical Fisher matrix from the clean bank; also test all-kappa=1 as an alternate gate-friendly control. We separately evaluate DPSMC with independent PF validation tuning under the same candidate grid. This differentiates matched-construction gate ablation from a comparator given its own model-selection opportunity.

## 4. Numerical results

All entries are means across three matched bank selections (mean within-bank density RMSE); bridge RMSE is across three proposal batches, one per bank. Lower RMSE/KL better. The sample-only Gaussian/GMM/spline comparators receive the identical learned coordinate chart and context marginal; the flexible spline conditional fits nonlinear mean and log-variance to bank samples using smooth features, with validation-selected complexity/regularization. This is an additional strong scalar conditional alternative to Gaussian mixtures, not the earlier full-dimensional neural fitted flow. A fully fitted neural conditional flow in the learned affine chart is a remaining production comparison.

| Method / construction | N=256 density RMSE | N=1024 density RMSE |
|---|---:|---:|
| Learned affine, LFGI, original score shift | 1.435 | 1.083 |
| Learned affine, LFGI, full movement | 1.224 | 0.971 |
| **Learned affine, LFGI, validation-tuned movement and bandwidth** | **1.125** | **0.948** |
| Conditional GN mixture, LFGI-matched bandwidth | 1.214 | 1.037 |
| Conditional GN mixture, independently bandwidth-tuned | 1.201 | 1.034 |
| DPSMC, matched tuned movement/bandwidth | 4.474 | 3.323 |
| DPSMC, fixed full movement | 1.635 | 1.237 |
| DPSMC, independently PF-validation-tuned | 3.502 | 1.867 |
| Conditional selected GMM, tuned partition | 2.697 | 1.420 |
| Flexible scalar conditional spline Gaussian | 1.894 | 1.226 |
| Conditional Gaussian, tuned partition | 15.308 | 15.127 |

At N=1024, the individual tuned LFGI density RMSEs are .9332, 1.0483, .8639; independently bandwidth-tuned GN comparator 1.0404,1.1402,.9217. At N=256 they are 1.1386,1.1858,1.0492 versus 1.2792,1.2278,1.0950. The LFGI advantage in these six comparisons does not establish independent-dataset generalization. DPSMC matched tuning is a test of the gate, not a substitute for tuning DPSMC independently. The independent validation tune is less favorable to DPSMC than its fixed-full-movement control; report the latter as the stronger observed DPSMC comparator (improvement by LFGI 31% at N=256 and 23% at N=1024). Do not imply that the restricted validation grid exhausts possible DPSMC settings.

| Method (N=1024) | Forward KL | Reverse KL | Bridge logZ RMSE | Importance ESS fraction |
|---|---:|---:|---:|---:|
| LFGI tuned | .407 | .542 | .078 | .468 |
| GN mixture, independently bandwidth-tuned | .475 | .593 | .093 | .424 |
| GN mixture, LFGI-matched bandwidth | .473 | .683 | .080 | .362 |
| DPSMC, matched tuning | 1.157 | 1.421 | .060 | .274 |
| DPSMC, independently tuned | .812 | 1.159 | .063 | .317 |
| GMM | .850 | 1.468 | .115 | .280 |

The bridge ranking is mixed (one 128-draw batch per fit). This is insufficient for an evidence headline. The stronger empirical claim is a useful learned conditional density construction with moderate consistent incremental gain over GN mixture.

### Contrast with the previous bespoke construction

The prior exact receiver-specific transform in the same physical target gives mean log-density RMSE on the same 128 held-out points:

| Prior exact chart | N=256 | N=1024 |
|---|---:|---:|
| Bespoke receiver chart, GMM marginal + conditional LFGI | .977 | .889 |
| Bespoke receiver chart, derivative-informed GN marginal + conditional LFGI | .692 | .670 |
| Learned affine, GMM marginal, tuned conditional LFGI | 1.125 | .948 |

Thus the learned affine method is about 7% worse than the bespoke GMM-marginal version at N=1024, and not better than the previous derivative-informed hybrid in absolute density accuracy. Its advantage is the removal of the receiver-specific map and discovery of the decomposition/attention from cached marks, with more pronounced distinction between the LFGI gate and alternatives. The comparison uses the same subset of archived held-out states (the earlier pilot's reported table used 256 states).

### Nonlinear learned chart and margin ablations

We tested a learned nonlinear shear/scale chart in each recovered 2D pair. This can be learned from data with smooth regression and an inverse-gradient/curvature-based scale. A more derivative-informed version identifies the scalar likelihood residual from the rank-one marks: after removing the known prior,

    r_i = -s_likelihood,u,i / sqrt(P_likelihood,uu,i)

up to a consistent choice of sign, when the observation derivative along the learned normal does not change sign. Its inverse derivative du/dr is 1/sqrt(P_likelihood,uu), and du/dv at fixed r is -P_likelihood,uv/P_likelihood,uu. Fit a monotone smooth inverse chart (u=f(v)+sigma(v)[r+c(v)(sqrt(1+r^2)-1)]), (|c|<.8), to these derivative marks and residuals, with an analytic inverse/Jacobian/Jacobian gradient. The conditional density estimates use transformed full target marks (s'=J^Ts+grad log|det J|), (P'=J^TPJ), not score approximations from a fitted likelihood. No forward-model-specific formula is used to fit the chart.

Unconstrained extrapolation of the learned log-scale can generate extremely bad tail proposals even when held-out density RMSE is good. The safeguarded variant learns smooth linear ridge tails, bounded scale tails and bounded asymmetry, with bank-derived limits. Its LFGI density RMSE is 1.135 (N=256) and .972 (N=1024), versus GN mixture 1.121 and .998, DPSMC 1.152 and .970. It is not preferable to the tuned affine construction: the nonlinear chart substantially removes conditional curvature variation and gate-specific benefit. Absolute accuracy is quite good but close to simpler methods. We retain these negative results and raw tail diagnostics rather than silently suppressing them.

The derivative-informed GN context marginal from the bespoke study was also tested in the learned affine/nonlinear charts. It has severe rare component/scale extrapolation and can generate pathological reverse KL despite favorable held-out density for some learned charts. It is not used in the recommended construction. Use the BIC sample GMM marginal; any future derivative-aware marginal requires a separately validated regularization/control-variate design.

## 5. Numerical controls and limitations

The affine map is exact and includes its absolute determinant in density evaluation. Learned nonlinear charts include the exact change-of-variables Jacobian and transformed score; finite-difference checks are in each result JSON. The moved-reference divergence uses the same analytic trace formula as the manuscript, with query-dependent frozen reference positions/marks. On scalar and two-dimensional validation blocks the GN-center invariance is 2.7e-15, finite-difference divergence absolute errors are below 1.6e-4 at the smallest cutoff and below 3e-7 at ordinary times; solver refinement of log density gives changes below 7.5e-6. Forward-backward state discrepancy below 1.6e-6, integrated divergence round trip below 4.2e-4. These are local checks with pilot tolerances (DOP853 rtol=2e-5, atol=2e-7 in log time, endpoint min(1e-4, .005/max local GN eigenvalue)); use tighter production tolerances and broad numerical checks.

The learned spectral chart relies on the known isotropic Gaussian prior and average likelihood identifiability. Other inverse problems may not have a simultaneously block-diagonalizable likelihood family, or may have more than one normal per local group. In that case the exact likelihood graph test may fail and approximate joint diagonalization/model selection would be necessary. The prior-induced inter-normal coupling is an approximation, not exact conditional independence. The normalized product model and full-posterior evaluation remain valid. Validation uses 64 extra coordinate-only observations from the fitting pool, not new derivative calls; record this in any informational matching. Do not claim theoretical optimality of a gate applied to approximate shifted/moved marks. As the learned normal partition consists of singletons, the query-dependent LFGI gate is scalar in this example; this demonstrates adaptive curvature-dependent gating and density reconstruction, not the advantage of off-diagonal matrix blending. A forced two-dimensional-block ablation would be informative if a matrix-gate illustration is essential.

## 6. Reproduce / next LS6 experiment

The original acoustic chains, basis and data are included at the relative paths expected by acoustic_pilot.py. The graph learner is copied from the attached earthquake partition experiment; all new runs use the same original acoustic target. Python 3.12, NumPy, SciPy, scikit-learn, Matplotlib; each task sets BLAS threads to one.

Run from package root:

    python acoustic_partition_validate.py
    python acoustic_attention.py --variant affine --mode adaptive --marg gmm --seed 23000 --N 256 --M 128
    python acoustic_attention.py --variant affine --mode adaptive --marg gmm --seed 23000 --N 256 --M 128 --move 1 --methods lfgi dpsmc
    python acoustic_attention.py --variant affine --mode adaptive --marg gmm --seed 23000 --N 256 --M 128 --tune
    python acoustic_attention.py --variant affine --mode adaptive --marg gmm --seed 23000 --N 256 --M 128 --tune --tune-gate dpsmc --methods dpsmc
    python acoustic_attention.py --variant affine --mode adaptive --marg gmm --seed 23000 --N 256 --M 128 --move 1 --methods spline
    python acoustic_attention.py --variant residual_safe --mode adaptive --marg gmm --seed 23000 --N 256 --M 128
    python acoustic_partition_summary.py

Repeat with seeds 23000–23002 and N=256,1024. JSON per fit records all partition/mask/bandwidth validation choices; raw NPZ points/densities/proposals and logs retained. The supplementary variants original, nonlinear, residual and residual_safe reproduce exploratory ablations. The raw archive from earlier pilot additionally contains the original bespoke chart and QMC evidence script.

For production: freeze the learner, use 5–10 distinct bank selections and a common disjoint 512-state test set, 5×512 proposal batches per fit, N=256,1024,2048; compare jointly (same learned chart, context marginal, cache) tuned LFGI, independently tuned DPSMC, separately tuned GN mixture, GMM, flexible conditional spline/flow, static and full-movement LFGI; optional prior exact bespoke transform as an oracle-style accuracy control labeled accordingly. Assess numerical convergence and reference accuracy. If evidence ranking remains mixed, state that frankly and use density error as the principal result. No need for a new nonlinear chart or new theory to use the learned affine construction.
