"""Independent randomized QMC estimate of original acoustic normalization."""
import acoustic_pilot as p
from scipy.stats import qmc,norm,chi2
from scipy.special import gammaln,logsumexp
import numpy as np
import json
from sklearn.mixture import GaussianMixture
import time

def integrate(target,g,df,inflate,logn,seed):
    d=16
    C=g.covariances_*inflate*((df-2)/df if df else 1)
    L=np.linalg.cholesky(C);P=np.linalg.inv(C)
    ld=np.linalg.slogdet(C)[1]
    if df:
        const=gammaln((df+d)/2)-gammaln(df/2)-d/2*np.log(df*np.pi)-.5*ld+np.log(g.weights_)
    else:const=-d/2*np.log(2*np.pi)-.5*ld+np.log(g.weights_)
    logs=[];sqs=[];maxw=[]
    for i in range(g.n_components):
        U=qmc.Sobol(d+bool(df),scramble=True,seed=seed*100+i).random_base2(logn)
        out=[]
        for j in range(0,len(U),4096):
            v=U[j:j+4096]
            z=norm.ppf(v[:,:d])
            if df:z/=np.sqrt(chi2.ppf(v[:,d],df)/df)[:,None]
            z=z@L[i].T+g.means_[i]
            dx=z[:,None]-g.means_
            r=np.einsum("qki,kij,qkj->qk",dx,P,dx,optimize=True)
            lq=logsumexp(const[None]-(df+d)/2*np.log1p(r/df) if df else const[None]-.5*r,axis=1)
            out.append(target.lp(z)-lq)
        w=np.concatenate(out);logs.append(logsumexp(w)-np.log(len(w))+np.log(g.weights_[i]));sqs.append(logsumexp(2*w)-np.log(len(w))+np.log(g.weights_[i]));maxw.append(w.max())
    logZ=logsumexp(logs)
    return dict(logZ=float(logZ),ESS_fraction=float(np.exp(2*logZ-logsumexp(sqs))),max_ratio=float(np.exp(max(maxw)-logZ)))

if __name__=="__main__":
    target=p.Target()
    train=target.to_new(np.load(p.REF)["samples_by_chain"][:2].reshape(-1,16))
    # No evaluation-chain inputs. The proposal is a numerical integration aid,
    # not a competitor at fixed N.
    g=GaussianMixture(4,n_init=2,reg_covar=1e-5,random_state=901,max_iter=400).fit(train)
    results=[]
    for df,inf in [(0,1.25),(10,1.3)]:
        for i in range(6):
            tick=time.monotonic()
            row=dict(df=df,inflate=inf,seed=i,**integrate(target,g,df,inf,16,100+i+100*bool(df)),seconds=time.monotonic()-tick)
            results.append(row);print(json.dumps(row),flush=True)
    (p.OUT/"evidence_qmc.json").write_text(json.dumps(results,indent=2))
