"""LS6 campaign, atomic chunk checkpoints, matched inputs, no login-node compute."""
import os
for k in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):os.environ[k]="1"
import argparse,json,pickle,time,traceback,hashlib,signal
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
import acoustic_pilot as p
import acoustic_learned as l
import acoustic_attention as a
from production_models import LearnedModel,JointModel,WarpModel,fits_mixture
from common import write,save,bridge,read,arrays_sha
from sklearn.mixture import GaussianMixture

ROOT=Path(__file__).resolve().parent
METHODS=["lfgi","dpsmc_matched","dpsmc_tuned","full_move_dpsmc","gn_opt","gn_matched",
         "gaussian","gmm","gmm2","student","fitted_flow","full_fitted_flow","spline","scalar",
         "static_lfgi","full_move_lfgi","full_cond_lfgi","joint_lfgi","joint_gmm",
         "joint_gaussian","joint_gn","map_laplace","warp3"]
DISPLAY=["lfgi","full_move_dpsmc","gn_opt","gmm","fitted_flow","spline"]
SEEDS=list(range(23000,23010));SIZES=[256,1024,2048]
def profile_config(profile):
    if profile=="smoke":return dict(seeds=[23000],sizes=[64],methods=METHODS,held=8,draw=8,repeats=1,display=16,cubature=24,chunk=8,quick=True)
    if profile=="pilot":return dict(seeds=[23000],sizes=[256,1024],methods=METHODS,held=128,draw=128,repeats=1,display=128,cubature=96,chunk=32,quick=False)
    return dict(seeds=SEEDS,sizes=SIZES,methods=METHODS,held=512,draw=512,repeats=5,display=8192,cubature=1536,chunk=32,quick=False)
def cells(profile):
    c=profile_config(profile);return [(s,n) for s in c["seeds"] for n in c["sizes"]]
def path(profile,seed,N):return ROOT/"results"/profile/f"seed{seed}"/f"N{N}"
def atomic_pickle(dest,value):
    dest.parent.mkdir(parents=True,exist_ok=True);tmp=dest.with_name(dest.name+f".tmp.{os.getpid()}")
    with tmp.open("wb") as f:pickle.dump(value,f,protocol=4)
    os.replace(tmp,dest)
def load_pickle(f):
    with open(f,"rb") as fp:return pickle.load(fp)
def code_hash():
    h=hashlib.sha256()
    for f in sorted(ROOT.glob("*.py")):
        if f.name in ("report.py","pack_results.py"):continue
        h.update(f.name.encode());h.update(f.read_bytes())
    h.update((ROOT/"quake_partition/learn_partition.py").read_bytes())
    return h.hexdigest()
def prepare_bank(profile,seed,N):
    d=path(profile,seed,N);f=d/"bank.pkl";c=profile_config(profile)
    if f.exists():
        b=load_pickle(f)
        if b["source_sha"]!=code_hash():raise RuntimeError("Code changed since frozen bank; use new directory or explicitly archive outputs")
        return
    tick=time.monotonic();t=p.Target();ref=np.load(p.REF)["samples_by_chain"]
    train=ref[:2].reshape(-1,16);test=ref[2:].reshape(-1,16)
    ids=np.random.default_rng(seed).permutation(len(train));bank_ids=ids[:N];val_ids=ids[max(c["sizes"]):max(c["sizes"])+64]
    # Same independent held-out set within seed across every N and method.
    held_ids=np.random.default_rng(seed+200000).permutation(len(test))[:c["held"]]
    x=train[bank_ids];val=train[val_ids];held=test[held_ids];s,H=l.original_marks(t,x)
    chart=l.Chart(x,s,H,seed,False);z,ss,PP=chart.marks(x,s,H);vv=chart.transform(val)
    base,base_sel,base_choices=a.fit_partition(z,ss,PP,vv,"adaptive",False)
    gnopt,selected,choices=a.fit_partition(z,ss,PP,vv,"adaptive",True)
    # Smoke exercises the same train/evaluation route but tunes on eight
    # validation points; production always uses full 64.
    tune_val=vv[:8] if c["quick"] else vv
    tuned,records=a.tune_pf(z,ss,PP,gnopt,np.arange(8,16),tune_val,"lfgi")
    dpsmc,records_d=a.tune_pf(z,ss,PP,gnopt,np.arange(8,16),tune_val,"dpsmc")
    qv=fits_mixture(z[:,8:],"gmm",22001,c["quick"])
    tau=min(1e-6,.5*np.log1p(.01/np.linalg.eigvalsh(PP).max()))
    b=dict(source_sha=code_hash(),original=x,s_original=s,H_original=H,chart=chart,z=z,s=ss,H=PP,
           val=vv,held=held,held_lp=t.old_lp(held),qv=qv,tau=tau,base=base,tuned=tuned,dpsmc=dpsmc,gn_opt=gnopt)
    save(d/"bank_arrays.npz",original=x,score=s,GN=H,chart=z,chart_score=ss,chart_GN=PP,validation=val,held=held,held_lp=b["held_lp"],bank_ids=bank_ids,validation_ids=val_ids,heldout_ids=held_ids)
    write(d/"bank.json",dict(seed=seed,N=N,source_sha=b["source_sha"],array_hash=arrays_sha(x,s,H,held,val),structure=chart.info,chart_matrix=chart.V,chart_mean=chart.mean,chart_scale=chart.sd,
                             selected_partition=selected,candidates=choices,base_partition=base_sel,base_candidates=base_choices,
                             lfgi_tuning=records,dpsmc_tuning=records_d,context_components=len(qv.w),tau=tau,
                             validation_checks=chart.validate(t,held[:4]),seconds=time.monotonic()-tick,
                             target_requests={"E_held":len(held),"G_bank":N,"H_GN_bank":N,"additional_coordinate_only_validation":len(val)}))
    atomic_pickle(f,b)
def model_dir(profile,seed,N,method):return path(profile,seed,N)/method
def fit_job(args):
    profile,seed,N,method=args;d=model_dir(profile,seed,N,method);f=d/"model.pkl"
    if f.exists():return method,"cached"
    d.mkdir(parents=True,exist_ok=True);tick=time.monotonic()
    try:
        b=load_pickle(path(profile,seed,N)/"bank.pkl");c=profile_config(profile)
        if method=="warp3":model=WarpModel(b)
        elif method.startswith("joint_") or method=="map_laplace":model=JointModel(b,method,seed,c["quick"])
        else:model=LearnedModel(b,method,seed,c["quick"])
        write(d/"fit.json",dict(method=method,seconds=time.monotonic()-tick,info=getattr(model,"info",{}),source_sha=code_hash()));atomic_pickle(f,model)
        return method,"fit"
    except Exception as exc:
        write(d/"fit_error.json",dict(error=repr(exc),traceback=traceback.format_exc()));return method,"failed"
def chunk_seed(seed,rep,first,kind):
    # Deterministic paired streams across all methods and N; display is separate.
    return int(np.random.SeedSequence([seed,rep,first,{"held":1,"proposal":2,"display":3,"cubature":4}[kind],20261119]).generate_state(1)[0])
def chunk_job(args):
    profile,seed,N,method,kind,rep,first,count=args
    d=model_dir(profile,seed,N,method);out=d/"chunks"/f"{kind}_{rep:02d}_{first:05d}.npz"
    if out.exists():return str(out),"cached"
    tick=time.monotonic()
    def deadline(signum,frame):raise TimeoutError("Chunk exceeded ACOUSTIC_CHUNK_TIMEOUT, retained as failure; adjust and resume if appropriate")
    signal.signal(signal.SIGALRM,deadline)
    signal.alarm(int(os.getenv("ACOUSTIC_CHUNK_TIMEOUT","90" if profile=="smoke" else "1800")))
    try:
        m=load_pickle(d/"model.pkl");b=load_pickle(path(profile,seed,N)/"bank.pkl") if kind=="held" else None
        rngseed=chunk_seed(seed,rep,first,kind)
        if kind=="held":
            x=b["held"][first:first+count]
            if method=="warp3":x,lp,lq=m.held(x,rngseed)
            else:lp=b["held_lp"][first:first+count];lq=m.logq(x)
            rt=np.empty(0);refine=np.empty(0)
        elif kind=="cubature":
            rec=np.load(path(profile,seed,N)/"cubature_points.npz")
            x=rec["points"][first:first+count];lp=rec["logp"][first:first+count];rec.close()
            lq=m.logq(x);rt=np.empty(0);refine=np.empty(0)
        elif method=="warp3":
            x,lp,lq=m.proposal(count,rngseed);rt=np.empty(0);refine=np.empty(0)
        else:
            x,lq=m.sample(count,rngseed);lp=p.Target().old_lp(x);rt=np.empty(0);refine=np.empty(0)
            if kind=="proposal" and rep==0 and first==0:
                k=min(16,count);check=m.logq(x[:k]);rt=check-lq[:k]
                # Stricter density evaluator on same four draws, not fit selection.
                if hasattr(m,"rtol"):
                    m.rtol/=20;refine=m.logq(x[:min(4,k)])-check[:min(4,k)]
        if not all(np.isfinite(q).all() for q in [x,lp,lq,rt,refine]):raise ArithmeticError("nonfinite evaluation")
        save(out,points=x,logp=lp,logq=lq,roundtrip_error=rt,refinement_error=refine,seconds=np.array(time.monotonic()-tick),rngseed=np.array(rngseed))
        return str(out),"done"
    except Exception as exc:
        write(out.with_suffix(".error.json"),dict(error=repr(exc),traceback=traceback.format_exc()));return str(out),"failed"
    finally:signal.alarm(0)
def work_pool(fn,jobs,workers):
    with ProcessPoolExecutor(max_workers=workers) as pool:
        fs=[pool.submit(fn,j) for j in jobs]
        for f in as_completed(fs):
            try:
                result=f.result()
                if result[1]!="cached":print(result,flush=True)
            except Exception as e:print("worker failure",repr(e),flush=True)
def chunks(profile,seed,N,methods,display=False):
    c=profile_config(profile);jobs=[]
    for method in methods:
        if not (model_dir(profile,seed,N,method)/"model.pkl").exists():continue
        if display:
            if method not in DISPLAY:continue
            kinds=[("display",0,c["display"])]
        else:kinds=[("held",0,c["held"])]+[("proposal",r,c["draw"]) for r in range(c["repeats"])]
        for kind,rep,total in kinds:
            for first in range(0,total,c["chunk"]):
                jobs.append((profile,seed,N,method,kind,rep,first,min(c["chunk"],total-first)))
    return jobs
def run_cell(profile,seed,N,workers,stage):
    c=profile_config(profile)
    prepare_bank(profile,seed,N)
    if stage=="run":
        work_pool(fit_job,[(profile,seed,N,m) for m in c["methods"]],workers)
        jobs=chunks(profile,seed,N,c["methods"])
    else:
        work_pool(fit_job,[(profile,seed,N,m) for m in DISPLAY],workers)
        jobs=chunks(profile,seed,N,DISPLAY,True)
    # Mix chunk tasks across methods/batches; costly joint PF first so it does
    # not become a long tail after easy methods complete.
    jobs.sort(key=lambda j: (j[3]!="joint_lfgi",j[5],j[6],j[3]))
    work_pool(chunk_job,jobs,workers)
    if stage=="display":
        # Common stratified cubature sample, independent of any test reference.
        # Reuse recorded display draws (512 from each of three proposals).
        from report import combine
        common_methods=["lfgi","gmm","fitted_flow"]
        records=[combine(profile,seed,N,m,"display") for m in common_methods]
        if all(q is not None for q in records):
            k=c["cubature"]//3
            d=path(profile,seed,N)
            save(d/"cubature_points.npz",points=np.concatenate([q["points"][:k] for q in records]),logp=np.concatenate([q["logp"][:k] for q in records]),stratum=np.repeat(np.arange(3),k))
            jobs=[(profile,seed,N,m,"cubature",0,first,min(c["chunk"],c["cubature"]-first))
                  for m in DISPLAY for first in range(0,c["cubature"],c["chunk"]) if (model_dir(profile,seed,N,m)/"model.pkl").exists()]
            work_pool(chunk_job,jobs,workers)
def ref_job(args):
    df,inflate,seed,power=args
    from acoustic_evidence import integrate
    t=p.Target();train=t.to_new(np.load(p.REF)["samples_by_chain"][:2].reshape(-1,16))
    g=GaussianMixture(4,n_init=2,reg_covar=1e-5,random_state=901,max_iter=400).fit(train)
    dest=ROOT/"reference"/f"df{df}_seed{seed}_p{power}.json"
    if not dest.exists():
        row=integrate(t,g,df,inflate,power,seed);write(dest,dict(df=df,inflate=inflate,seed=seed,power=power,**row))
    return str(dest),"done"
def main():
    ap=argparse.ArgumentParser();ap.add_argument("stage",choices=["matrix","run","display","reference","status"]);ap.add_argument("--profile",choices=["smoke","pilot","production"],default="production");ap.add_argument("--shard",type=int,default=0);ap.add_argument("--shards",type=int,default=1);ap.add_argument("--workers",type=int,default=8);ap.add_argument("--seed",type=int);ap.add_argument("--N",type=int);a0=ap.parse_args()
    c=profile_config(a0.profile);cc=cells(a0.profile)
    if a0.stage=="matrix":
        print(json.dumps(dict(cells=len(cc),fits=len(cc)*len(c["methods"]),methods=c["methods"],sizes=c["sizes"],seeds=c["seeds"])))
    elif a0.stage=="reference":
        jobs=[(df,inf,200+i+100*bool(df),12 if c["quick"] else 18) for df,inf in [(0,1.25),(10,1.3)] for i in range(2 if c["quick"] else 8)]
        work_pool(ref_job,jobs,a0.workers)
    elif a0.stage=="status":
        from report import status
        print(json.dumps(status(a0.profile),indent=2))
    else:
        if a0.seed is not None:cc=[(a0.seed,a0.N)]
        elif a0.stage=="display":cc=[(c["seeds"][0],n) for n in [c["sizes"][0],c["sizes"][-1]]] if len(c["sizes"])>1 else cc
        for seed,N in cc[a0.shard::a0.shards]:run_cell(a0.profile,seed,N,a0.workers,a0.stage)
if __name__=="__main__":main()
