#!/bin/bash
set -euo pipefail
BUNDLE=$(cd "$(dirname "$0")" && pwd)
cd "$BUNDLE"
profile=production
reference=1
displays=1
while [[ $# -gt 0 ]]; do
 case "$1" in
 --pilot) profile=pilot;;
 --smoke-only) profile=smoke;;
 --no-reference) reference=0;;
 --no-displays) displays=0;;
 *) echo "Usage: bash submit.sh [--pilot|--smoke-only] [--no-reference] [--no-displays]" >&2;exit 2;;
 esac
 shift
done
mkdir -p logs
exec 9>.submission.lock
flock -n 9 || { echo "Submission already in progress";exit 2; }
ledger="logs/submitted_ids_${profile}.txt"
if [[ -f "$ledger" ]]; then
 while read -r stage id; do
  [[ -n "$id" ]] || continue
  if ! current=$(squeue -h -j "$id" 2>/dev/null);then
    states=$(sacct -n -X -j "$id" --format=State --parsable2) || { echo "Cannot verify previous $id" >&2;exit 2; }
    [[ -n "$states" && -z "$(printf '%s\n' "$states" | sed '/^$/d'|grep -Ev '^(COMPLETED|FAILED|CANCELLED|TIMEOUT|NODE_FAIL|OUT_OF_MEMORY|PREEMPTED|BOOT_FAIL|DEADLINE)[^|]*\|?$' || true)" ]] || { echo "Previous $id not confirmed terminal";exit 2; }
    current=''
  fi
  [[ -z "$current" ]] || { echo "Existing $stage job $id is active; do not duplicate.";exit 2; }
 done < "$ledger"
 cp "$ledger" "${ledger%.txt}_$(date +%s).txt"
fi
read -r tasks concurrency < <(python3 ls6/preflight.py --profile "$profile" --reference "$reference" --display "$displays")
: > "$ledger"
submit(){
 local stage=$1 wall=$2 cpus=$3 dependency=${4:-} array=${5:-} shards=${6:-1}
 local flags=(-A "${ACOUSTIC_ACCOUNT:-DMS22021}" -p "${ACOUSTIC_QUEUE:-normal}" -N 1 -n 1 -c "$cpus" -t "$wall" -J "aclfgi-$stage")
 if [[ -n "$array" ]];then flags+=(--array="$array" -o 'logs/%x-%A_%a.out' -e 'logs/%x-%A_%a.err');else flags+=(-o 'logs/%x-%j.out' -e 'logs/%x-%j.err');fi
 [[ -z "$dependency" ]] || flags+=(--dependency="$dependency")
 local id raw
 raw=$(sbatch --parsable "${flags[@]}" ls6/job.sh "$BUNDLE" "$stage" "$profile" "$shards")
 id=${raw%%;*};[[ "$id" =~ ^[0-9]+$ ]] || { echo "Unexpected sbatch response: $raw" >&2;exit 2; }
 printf '%s %s\n' "$stage" "$id" >> "$ledger"
 echo "$id"
}
setup=$(submit setup "${ACOUSTIC_SETUP_WALL:-00:30:00}" 1)
smoke=$(submit smoke "${ACOUSTIC_SMOKE_WALL:-01:00:00}" 16 "afterok:$setup")
if [[ "$profile" != smoke ]]; then
 run=$(submit run "${ACOUSTIC_WALL:-12:00:00}" "${ACOUSTIC_CPUS_PER_TASK:-64}" "afterok:$smoke" "0-$((tasks-1))%$concurrency" "$tasks")
 dep="afterany:$run"
 if [[ "$displays" == 1 ]];then
  display=$(submit display "${ACOUSTIC_DISPLAY_WALL:-08:00:00}" "${ACOUSTIC_CPUS_PER_TASK:-64}" "afterany:$run" "0-1%2" 2)
  dep="$dep:$display"
 fi
 if [[ "$reference" == 1 ]];then
  ref=$(submit reference "${ACOUSTIC_REFERENCE_WALL:-03:00:00}" 16 "afterok:$smoke")
  dep="$dep:$ref"
 fi
 report=$(submit report "${ACOUSTIC_REPORT_WALL:-01:00:00}" 4 "$dep")
fi
cat "$ledger"
echo "Profile=$profile, array shards=$tasks, array concurrency=$concurrency. Resume by rerunning after the prior DAG is terminal."
