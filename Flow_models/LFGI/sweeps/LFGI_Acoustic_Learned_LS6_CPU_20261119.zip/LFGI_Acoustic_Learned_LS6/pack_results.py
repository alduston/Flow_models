"""Export complete/partial raw records in independently verified <=25 MB ZIPs."""
import argparse,hashlib,json,time,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for q in iter(lambda:f.read(1024*1024),b""):h.update(q)
    return h.hexdigest()
def export(profile):
    dst=ROOT/"exports"/profile;dst.mkdir(parents=True,exist_ok=True)
    stamp=time.strftime("%Y%m%d_%H%M%S");files=[]
    for base in [ROOT/"reports"/profile,ROOT/"results"/profile,ROOT/"reference"]:
        if base.exists():
            files.extend(f for f in sorted(base.rglob("*")) if f.is_file() and f.suffix in [".json",".csv",".npz",".md",".tex",".pdf",".png"] and ".tmp." not in f.name)
    # Metadata and data files also supply method provenance, no huge pickle cache.
    files=sorted(set(files),key=lambda x:(0 if "/reports/" in str(x) else 1,str(x)))
    parts=[];batch=[];size=0
    def flush():
        nonlocal batch,size
        if not batch:return
        name=f"Acoustic_Learned_{profile}_{stamp}_{len(parts)+1:03d}.zip";path=dst/name
        with zipfile.ZipFile(path,"w",zipfile.ZIP_DEFLATED,compresslevel=3) as z:
            for f in batch:z.write(f,str(f.relative_to(ROOT)))
        if path.stat().st_size>25_000_000:raise RuntimeError("Export exceeded 25 MB: "+name)
        with zipfile.ZipFile(path) as z:
            if z.testzip() is not None:raise RuntimeError("CRC failure")
        parts.append(dict(file=name,size=path.stat().st_size,sha256=sha(path),files=len(batch)))
        batch=[];size=0
    for f in files:
        n=f.stat().st_size
        if n>21_000_000:raise RuntimeError("Individual export file too large: "+str(f))
        if size+n>21_000_000:flush()
        batch.append(f);size+=n+256
    flush();out=dict(profile=profile,generated=stamp,parts=parts,total_files=len(files))
    tmp=dst/"INDEX.json.tmp";tmp.write_text(json.dumps(out,indent=2));tmp.replace(dst/"INDEX.json")
    print(json.dumps(out,indent=2))
if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--profile",default="production");a=p.parse_args();export(a.profile)
