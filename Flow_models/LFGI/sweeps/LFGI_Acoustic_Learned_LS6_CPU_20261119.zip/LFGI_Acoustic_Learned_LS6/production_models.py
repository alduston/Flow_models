"""Normalized models and solver controls for learned acoustic production.

All densities are evaluated in the original prior-whitened coordinates.
"""
import numpy as np
from scipy.special import logsumexp,gammaln
from scipy.optimize import minimize
from scipy.integrate import solve_ivp
from sklearn.mixture import GaussianMixture
import acoustic_pilot as p
import acoustic_attention as a
import acoustic_learned as l
from acoustic_flow import Flow

class ScalarField:
    def __init__(self,x,s,lw):
        self.x=x;self.sc=s;self.lw=lw;self.d=x.shape[-1]
    def rhs(self,y,t):
        a0=np.exp(-t);g=-np.expm1(-2*t);d=self.d
        w=-np.sum((y[:,None]-a0*self.x)**2,2)/(2*g)+self.lw
        w=np.exp(w-logsumexp(w,axis=1)[:,None]);w2=w*w
        # Center before taking second moments: near one-reference domination matters.
        j=np.argmax(w,axis=1);anchor=np.arange(len(y));xo=self.x-self.x[anchor,j,None];so=self.sc-self.sc[anchor,j,None]
        xm=np.sum(w[:,:,None]*xo,1);sm=np.sum(w[:,:,None]*so,1)
        mu=self.x[anchor,j]+xm;ms=self.sc[anchor,j]+sm
        dx=xo-xm[:,None];ds=so-sm[:,None]
        b=(a0*mu-y)/g;c=ms/a0;delta=c-b
        cov=np.einsum("qn,qni,qnj->qij",w,dx,dx);cs=np.einsum("qn,qni,qnj->qij",w,ds,dx)
        Jb=a0*a0/g**2*cov-np.eye(d)/g;Jc=cs/g
        zc=a0/g*dx;rc=ds/a0-zc;cross=np.sum(zc*rc,2);norm=np.sum(rc*rc,2)
        A=-np.sum(w2*cross,1);D=np.sum(w2*norm,1);reg=1e-4
        den=(1+reg)*D+reg*d*np.sum(w2,1)*1e-12;raw=A/den
        # Same C1 safeguard as archived scalar blend.
        ep=.01;u=np.clip(raw/ep,0,1);v=np.clip((1-raw)/ep,0,1)
        gate=np.where(raw<ep,ep*(2*u*u-u*u*u),np.where(raw>1-ep,1-ep*(2*v*v-v*v*v),raw))
        gp=np.where(raw<ep,4*u-3*u*u,np.where(raw>1-ep,4*v-3*v*v,1.))
        gp=np.where((raw<=0)|(raw>=1),0.,gp)
        dz=a0*a0/g**2*cov;dr=a0/g*np.einsum("qn,qni,qnj->qij",w,rc,dx)
        sr=np.sum(w2[:,:,None]*rc,1);sz=np.sum(w2[:,:,None]*zc,1)
        gradA=-2*a0/g*np.einsum("qn,qni,qn->qi",w2,dx,cross)+np.einsum("qi,qij->qj",sr,dz)+np.einsum("qi,qij->qj",sz,dr)
        gradD=2*a0/g*np.einsum("qn,qni,qn->qi",w2,dx,norm)-2*np.einsum("qi,qij->qj",sr,dr)
        gradDen=(1+reg)*gradD+reg*d*1e-12*2*a0/g*np.sum(w2[:,:,None]*dx,1)
        grad=(gradA-raw[:,None]*gradDen)/den[:,None]
        score=b+gate[:,None]*delta
        tr=np.trace(Jb+gate[:,None,None]*(Jc-Jb),axis1=1,axis2=2)+np.sum(delta*grad*gp[:,None],1)
        return -y-score,-d-tr

def scalar_field(block,v,move):
    s,lw=block.context(v);ds=s-block.s
    dx=np.einsum("nij,qnj->qni",block.inv,ds,optimize=True)
    return ScalarField(block.x[None]+move*dx,block.s[None]+(1-move)*ds,lw)

def pf(block,y,v,gate,move,tau,rtol,reverse=False):
    """Exact divergence and 16 log-time segments, chunked for bounded memory."""
    if gate!="scalar":
        block.tau=tau
        return block.pf(y,v,gate,reverse,rtol,move,16)
    out=[];logs=[]
    for j in range(0,len(y),16):
        yy=y[j:j+16];nn,dd=yy.shape;field=scalar_field(block,v[j:j+16],move)
        def rhs(u,state):
            dy,dl=field.rhs(state[:nn*dd].reshape(nn,dd),np.exp(u))
            return np.exp(u)*np.r_[dy.ravel(),dl]
        lo,hi=np.log(tau),np.log(8.)
        grid=np.linspace(hi,lo,17) if reverse else np.linspace(lo,hi,17)
        val=np.r_[yy.ravel(),np.zeros(nn)]
        for aa,bb in zip(grid[:-1],grid[1:]):
            sol=solve_ivp(rhs,(aa,bb),val,method="DOP853",rtol=rtol,atol=rtol*.01)
            if not sol.success:raise ArithmeticError(sol.message)
            val=sol.y[:,-1]
        if not np.isfinite(val).all():raise ArithmeticError("nonfinite scalar PF")
        zz=val[:nn*dd].reshape(nn,dd);ld=val[nn*dd:]
        out.append(zz);logs.append(p.normal_lp(yy)-ld if reverse else p.normal_lp(zz)+ld)
    return (np.concatenate(out),np.concatenate(logs)) if reverse else np.concatenate(logs)

class Mixture:
    def __init__(self,w,mu,cov,nu=None):
        self.w=w;self.mu=mu;self.cov=cov;self.nu=nu
    @staticmethod
    def components(x,w,mu,cov,nu):
        d=x.shape[-1];dx=x[:,None]-mu;P=np.linalg.inv(cov);ld=np.linalg.slogdet(cov)[1]
        r=np.einsum("qki,kij,qkj->qk",dx,P,dx)
        if nu is None:return np.log(w)-.5*(d*np.log(2*np.pi)+ld+r)
        return np.log(w)+gammaln((nu+d)/2)-gammaln(nu/2)-d/2*np.log(nu*np.pi)-.5*ld-(nu+d)/2*np.log1p(r/nu)
    def logq(self,x):return logsumexp(self.components(x,self.w,self.mu,self.cov,self.nu),1)
    def draw(self,n,rng):
        ids=rng.choice(len(self.w),n,p=self.w);z=rng.normal(size=(n,self.mu.shape[1]))
        if self.nu is not None:z/=np.sqrt(rng.chisquare(self.nu,n)/self.nu)[:,None]
        return self.mu[ids]+np.einsum("nij,nj->ni",np.linalg.cholesky(self.cov)[ids],z)
    def conditional(self,v,d):
        V=self.cov[:,d:,d:];Pi=np.linalg.inv(V);R=self.cov[:,:d,d:]@Pi
        S=self.cov[:,:d,:d]-R@self.cov[:,d:,:d]
        dv=v[:,None]-self.mu[:,d:];m=self.mu[None,:,:d]+np.einsum("kij,qkj->qki",R,dv)
        w=self.components(v,self.w,self.mu[:,d:],V,self.nu);w-=logsumexp(w,1)[:,None]
        if self.nu is None:factor=np.ones(w.shape)
        else:factor=(self.nu+np.einsum("qki,kij,qkj->qk",dv,Pi,dv))/(self.nu+v.shape[1])
        return m,S,w,factor
    def cond_lp(self,x,v):
        m,S,w,f=self.conditional(v,x.shape[1]);r=x[:,None]-m;d=x.shape[1]
        D=np.einsum("qki,kij,qkj->qk",r,np.linalg.inv(S),r)/f
        ld=np.linalg.slogdet(S)[1]+d*np.log(f)
        if self.nu is None:return logsumexp(w-.5*(d*np.log(2*np.pi)+ld+D),1)
        nu=self.nu+v.shape[1]
        return logsumexp(w+gammaln((nu+d)/2)-gammaln(nu/2)-d/2*np.log(nu*np.pi)-.5*ld-(nu+d)/2*np.log1p(D/nu),1)
    def cond_draw(self,v,d,rng):
        m,S,w,f=self.conditional(v,d);n=len(v);ids=(rng.random(n)[:,None]>np.cumsum(np.exp(w),1)).sum(1).clip(max=len(self.w)-1)
        z=rng.normal(size=(n,d))
        if self.nu is not None:
            nu=self.nu+v.shape[1];z/=np.sqrt(rng.chisquare(nu,n)/nu)[:,None]
        return m[np.arange(n),ids]+np.sqrt(f[np.arange(n),ids,None])*np.einsum("nij,nj->ni",np.linalg.cholesky(S)[ids],z)

def fits_mixture(x,kind,seed,quick=False):
    mean=x.mean(0);sd=np.maximum(x.std(0),1e-6);z=(x-mean)/sd;d=x.shape[1];n=len(x)
    ks=[1] if kind=="gaussian" else [2] if kind=="gmm2" else [1,2,4,8]
    best=None
    for k in ks:
        if n<max(10*k,2*d):continue
        g=GaussianMixture(k,reg_covar=1e-5,n_init=1 if quick else 5,max_iter=400,random_state=seed).fit(z)
        pars=k*(d+d*(d+1)/2)+k-1
        for nu in ([None,4,8,16] if kind=="student" else [None]):
            w=g.weights_.copy();m=g.means_.copy();c=g.covariances_.copy()
            if nu is not None:
                prev=-np.inf
                for it in range(25 if quick else 150):
                    ll=Mixture.components(z,w,m,c,nu);s=logsumexp(ll,1);r=np.exp(ll-s[:,None])
                    dx=z[:,None]-m;delta=np.einsum("nki,kij,nkj->nk",dx,np.linalg.inv(c),dx)
                    rw=r*(nu+d)/(nu+delta);mass=r.sum(0)+1e-10;w=mass/mass.sum()
                    m=(rw.T@z)/(rw.sum(0)[:,None]+1e-10);dx=z[:,None]-m
                    c=np.einsum("nk,nki,nkj->kij",rw,dx,dx)/mass[:,None,None]+1e-5*np.eye(d)
                    if abs(s.sum()-prev)<1e-5*(1+abs(prev)):break
                    prev=s.sum()
            model=Mixture(w,m*sd+mean,c*sd[None,:,None]*sd[None,None,:],nu)
            bic=-2*model.logq(x).sum()+pars*np.log(n)
            if best is None or bic<best[0]:best=(bic,model)
    if best is None:raise ValueError("no eligible mixture")
    return best[1]

def conditional_mix(block,z,validation,kind,seed,quick):
    B=block.B;C=block.C
    masks=[np.arange(len(C)),block.att]
    best=None
    for idx,att in enumerate(masks):
        if len(att)==0:continue
        m=fits_mixture(np.c_[z[:,B],z[:,C][:,att]],kind,seed+idx,quick)
        nll=-m.cond_lp(validation[:,B],validation[:,C][:,att]).mean()
        if best is None or nll<best[0]:best=(nll,m,att)
    return best[1:]

def fit_flow(x,d,seed,quick=False):
    rng=np.random.default_rng(seed);ids=rng.permutation(len(x));k=int(.8*len(x));tr,va=x[ids[:k]],x[ids[k:]]
    best=None
    for layers,width in ([(2,16)] if quick else [(4,32),(6,64)]):
        for j in range(1 if quick else 2):
            sd=seed+100*layers+j;f=Flow(tr,layers,width,sd,d)
            ll,ep=f.train(tr,sd,5 if quick else 300,va)
            if best is None or ll>best[0]:best=(ll,ep,layers,width,sd)
    _,ep,layers,width,sd=best
    f=Flow(x,layers,width,sd,d);f.train(x,sd,ep)
    return f,dict(validation_NLL=-best[0],epochs=ep,layers=layers,width=width,seed=sd)

class LearnedModel:
    def __init__(self,bank,method,seed,quick=False):
        self.chart=bank["chart"];self.qv=bank["qv"];self.method=method;self.info={}
        z,ss,HH=bank["z"],bank["s"],bank["H"];self.C=np.arange(8,16)
        self.blocks=bank["tuned"]
        if method in ("static_lfgi","full_move_lfgi","full_move_dpsmc"):self.blocks=bank["base"]
        if method=="dpsmc_tuned":self.blocks=bank["dpsmc"]
        if method=="gn_opt":self.blocks=bank["gn_opt"]
        if method=="full_cond_lfgi":self.blocks=[a.Block(z,ss,HH,list(range(8)),self.C,list(range(8)),1.)]
        self.tau=bank["tau"];self.quick=quick;self.rtol=1e-8
        self.submodels=[]
        if method in ("gaussian","gmm","gmm2","student"):
            for i,b in enumerate(self.blocks):
                g,att=conditional_mix(b,z,bank["val"],method,seed+20*i,quick);self.submodels.append((g,att))
                self.info[str(i)]=dict(block=b.B.tolist(),context_mask=att.tolist(),components=len(g.w),degrees_of_freedom=g.nu)
        elif method=="spline":
            # For a multi-dimensional learned block, use its scalar factors
            # with the same clean context; disclose this additional approximation.
            tmp=[]
            for b in self.blocks:
                for k in b.B:tmp.append(a.Block(z,ss,HH,[int(k)],self.C,b.att.tolist(),b.beta))
            self.blocks=tmp
            self.submodels=[a.SplineConditional(b,bank["val"]) for b in self.blocks]
            self.info={str(i):dict(block=b.B.tolist(),context_mask=f.att.tolist(),width=f.width,all_linear=f.all_linear,ridge=f.reg) for i,(b,f) in enumerate(zip(self.blocks,self.submodels))}
        elif method in ("fitted_flow","full_fitted_flow"):
            if method=="full_fitted_flow":self.blocks=[a.Block(z,ss,HH,list(range(8)),self.C,list(range(8)),1.)]
            for i,b in enumerate(self.blocks):
                # All eight contexts are available to the neural comparator.
                f,inf=fit_flow(np.c_[z[:,b.B],z[:,self.C]],len(b.B),seed+20*i,quick);self.submodels.append(f);self.info[str(i)]=inf
    def gate_move(self,b):
        m=self.method
        if m=="static_lfgi":return "lfgi",0.
        if m=="full_move_lfgi":return "lfgi",1.
        if m=="full_move_dpsmc":return "dpsmc",1.
        if m=="full_cond_lfgi":return "lfgi",0.
        return ("dpsmc" if m.startswith("dpsmc") else "scalar" if m=="scalar" else "lfgi"),getattr(b,"move",0.)
    def logq_z(self,z):
        v=z[:,self.C];out=self.qv.logq(v)
        for i,b in enumerate(self.blocks):
            u=z[:,b.B];m=self.method
            if m in ("gaussian","gmm","gmm2","student"):
                g,att=self.submodels[i];out+=g.cond_lp(u,v[:,att])
            elif m=="spline":out+=self.submodels[i].logp(u,v)
            elif m in ("fitted_flow","full_fitted_flow"):out+=self.submodels[i].logq(u,v)
            elif m.startswith("gn_"):out+=b.gn_lp(u,v)
            else:
                gate,move=self.gate_move(b);out+=pf(b,u,v,gate,move,self.tau,self.rtol)
        return out
    def logq(self,x):
        z=self.chart.transform(x);_,ld=self.chart.inverse(z)
        return self.logq_z(z)-ld
    def sample(self,n,seed):
        rng=np.random.default_rng(seed);v=self.qv.draw(n,rng);base=rng.normal(size=(n,8));rng2=np.random.default_rng(seed+9182)
        z=np.zeros((n,16));z[:,self.C]=v;lp=self.qv.logq(v)
        for i,b in enumerate(self.blocks):
            m=self.method
            if m in ("gaussian","gmm","gmm2","student"):
                g,att=self.submodels[i];u=g.cond_draw(v[:,att],len(b.B),rng2);ll=g.cond_lp(u,v[:,att])
            elif m=="spline":
                f=self.submodels[i];u=f.draw(v,rng2);ll=f.logp(u,v)
            elif m in ("fitted_flow","full_fitted_flow"):
                f=self.submodels[i];u=f.draw(v,base[:,b.B]);ll=f.logq(u,v)
            elif m.startswith("gn_"):
                u=b.gn_draw(v,rng2);ll=b.gn_lp(u,v)
            else:
                gate,move=self.gate_move(b);u,ll=pf(b,base[:,b.B],v,gate,move,self.tau,self.rtol,True)
            z[:,b.B]=u;lp+=ll
        x,ld=self.chart.inverse(z);return x,lp-ld

class JointModel:
    def __init__(self,bank,method,seed,quick=False):
        self.method=method;self.info={};self.quick=quick;self.rtol=1e-8
        x,s,H=bank["original"],bank["s_original"],bank["H_original"]
        if method=="joint_lfgi":
            self.block=a.Block(x,s,H,np.arange(16),np.array([],int),[],1.)
            self.tau=min(1e-6,.5*np.log1p(.01/np.linalg.eigvalsh(H).max()))
        elif method=="joint_gmm":self.model=fits_mixture(x,"gmm",seed,quick)
        elif method=="joint_gaussian":self.model=fits_mixture(x,"gaussian",seed,quick)
        elif method=="joint_gn":
            cov=np.linalg.inv(H);self.model=Mixture(np.full(len(x),1/len(x)),x+(cov@s[...,None])[...,0],cov)
        elif method=="map_laplace":
            t=p.Target();calls=0
            def fun(y):
                nonlocal calls
                calls+=1;g,_=l.original_marks(t,y[None]);return -t.old_lp(y[None])[0],-g[0]
            starts=np.vstack([np.zeros(16),np.random.default_rng(613).normal(size=(2,16))])
            rs=[minimize(fun,i,jac=True,method="BFGS",options={"gtol":1e-8,"maxiter":500}) for i in starts]
            best=min(rs,key=lambda r:r.fun);eps=1e-5;D=np.eye(16)*eps
            P=-(l.original_marks(t,best.x+D)[0]-l.original_marks(t,best.x-D)[0]).T/(2*eps);P=(P+P.T)/2
            if np.linalg.eigvalsh(P).min()<=0:raise ValueError("MAP Hessian not PD")
            self.model=Mixture(np.ones(1),best.x[None],np.linalg.inv(P)[None]);self.info=dict(map_energy_calls=calls,map_gradient_calls=calls+32,map_hessian_fd_gradient_calls=32,map_gradient_norm=float(np.linalg.norm(best.jac)),map_min_curvature=float(np.linalg.eigvalsh(P).min()))
    def logq(self,x):
        if self.method=="joint_lfgi":return pf(self.block,x,np.empty((len(x),0)),"lfgi",0.,self.tau,self.rtol)
        return self.model.logq(x)
    def sample(self,n,seed):
        rng=np.random.default_rng(seed)
        if self.method=="joint_lfgi":return pf(self.block,rng.normal(size=(n,16)),np.empty((n,0)),"lfgi",0.,self.tau,self.rtol,True)
        x=self.model.draw(n,rng);return x,self.model.logq(x)

class WarpModel:
    def __init__(self,bank):
        x=bank["original"];self.mean=x.mean(0);self.L=np.linalg.cholesky(np.cov(x.T)+np.eye(16)*1e-9);self.ld=np.linalg.slogdet(self.L)[1]
    def transformed_lp(self,y):
        t=p.Target();return np.logaddexp(t.old_lp(self.mean+y@self.L.T),t.old_lp(self.mean-y@self.L.T))-np.log(2)+self.ld
    def held(self,x,seed):
        rng=np.random.default_rng(seed);y=np.linalg.solve(self.L,(x-self.mean).T).T*rng.choice([-1,1],len(x))[:,None]
        # The original posterior energy is cached in campaign; here both terms
        # are recomputed for clarity and actual energy calls recorded.
        return y,self.transformed_lp(y),p.normal_lp(y)
    def proposal(self,n,seed):
        y=np.random.default_rng(seed).normal(size=(n,16));return y,self.transformed_lp(y),p.normal_lp(y)
