"""Automatically learned local partitions and kernel masks, evaluated on acoustic."""
import acoustic_learned as l
import acoustic_pilot as p
from acoustic_marginal import GNMixture
import numpy as np
from scipy.special import logsumexp
from scipy.integrate import solve_ivp
from scipy.optimize import minimize
from sklearn.mixture import GaussianMixture
import json,time,argparse,itertools

OUT=l.OUT
LOGZ=l.LOGZ

class Block:
    def __init__(self,x,s,H,B,C,att,beta):
        self.B=np.array(B);self.C=np.array(C);self.att=np.array(att,dtype=int)
        self.x=x[:,self.B];self.s=s[:,self.B];self.H=H[:,self.B][:,:,self.B]
        self.cross=H[:,self.B][:,:,self.C];self.v=x[:,self.C]
        self.n,self.d=self.x.shape
        self.beta=beta
        self.inv=np.linalg.inv(self.H);self.L=np.linalg.cholesky(self.inv);self.ld=np.linalg.slogdet(self.H)[1]
        if len(self.att):
            cov=np.atleast_2d(np.cov(self.v[:,self.att].T))
            self.Ci=np.linalg.inv(cov)*self.n**(2/(len(self.att)+4))/beta**2
        self.F=self.s.T@self.s/self.n
        self.tau=min(1e-4,.005/np.linalg.eigvalsh(self.H).max())
    def context(self,v):
        dv=v[:,None]-self.v[None]
        shifted=self.s[None]-np.einsum("nij,qnj->qni",self.cross,dv,optimize=True)
        if len(self.att):
            da=dv[:,:,self.att];lw=-.5*np.sum((da@self.Ci)*da,2)
        else:lw=np.zeros((len(v),self.n))
        return shifted,lw
    def gn_params(self,v):
        s,lw=self.context(v);lw-=logsumexp(lw,axis=1)[:,None]
        m=self.x+np.einsum("nij,qnj->qni",self.inv,s,optimize=True)
        return m,lw
    def gn_lp(self,y,v):
        out=[]
        for j in range(0,len(y),64):
            yy=y[j:j+64];mu,w=self.gn_params(v[j:j+64]);dx=yy[:,None]-mu
            lp=w+.5*self.ld[None]-.5*self.d*np.log(2*np.pi)-.5*np.einsum("qni,nij,qnj->qn",dx,self.H,dx,optimize=True)
            out.append(logsumexp(lp,axis=1))
        return np.concatenate(out)
    def gn_draw(self,v,rng):
        mu,lw=self.gn_params(v)
        i=(rng.random(len(v))[:,None]>np.cumsum(np.exp(lw),axis=1)).sum(1).clip(max=self.n-1)
        return mu[np.arange(len(v)),i]+np.einsum("nij,nj->ni",self.L[i],rng.normal(size=(len(v),self.d)))
    def field(self,v,method,transport=0.):
        P=self.H if method=="lfgi" else np.broadcast_to(self.F,self.H.shape).copy()
        shifted,lw=self.context(v)
        if transport:
            # Move cached particles along the local conditional Newton shift;
            # simultaneously update their score by the same linearization.
            # The direct Gaussian component centers are invariant to transport.
            ds=shifted-self.s[None]
            dx=np.einsum("nij,qnj->qni",self.inv,ds,optimize=True)
            f=DynamicField(self.x[None]+transport*dx,self.s[None]+(1-transport)*ds,P,lw)
        else:
            f=p.Field(self.x,self.s,P)
            f.sc,f.logw=shifted,lw
        return f
    def pf(self,y,v,method,reverse=False,rtol=2e-5,transport=0.,segments=1):
        xx=[];ll=[]
        for i in range(0,len(y),32):
            zz=y[i:i+32];n,d=zz.shape
            f=self.field(v[i:i+32],method,transport)
            def rhs(u,state):
                dy,dl=f.rhs(state[:n*d].reshape(n,d),np.exp(u))
                return np.exp(u)*np.r_[dy.ravel(),dl]
            lo,hi=np.log(self.tau),np.log(8.)
            grid=np.linspace(hi,lo,segments+1) if reverse else np.linspace(lo,hi,segments+1)
            out=np.r_[zz.ravel(),np.zeros(n)]
            for start,stop in zip(grid[:-1],grid[1:]):
                res=solve_ivp(rhs,(start,stop),out,method="DOP853",rtol=rtol,atol=rtol*.01)
                if not res.success:raise RuntimeError(res.message)
                out=res.y[:,-1]
            if not np.isfinite(out).all():raise ArithmeticError("nonfinite probability flow")
            xx.append(out[:n*d].reshape(n,d));ll.append(out[n*d:])
        end=np.concatenate(xx);L=np.concatenate(ll)
        if reverse:return end,p.normal_lp(y)-L
        return p.normal_lp(end)+L

class DynamicField:
    """Same exact LFGI divergence with context-dependent, frozen marks."""
    def __init__(self,x,s,H,lw):
        self.x=x;self.sc=s;self.H=H;self.logw=lw
        self.d=x.shape[-1];self.I=np.eye(self.d)
        self.Hflat=H.reshape(len(H),-1)
    def rhs(self,y,t):
        a=np.exp(-t);g=-np.expm1(-2*t)
        dx0=y[:,None]-a*self.x
        lw=-np.sum(dx0*dx0,2)/(2*g)+self.logw
        w=np.exp(lw-logsumexp(lw,axis=1)[:,None])
        mu=np.sum(w[:,:,None]*self.x,1);sc=np.sum(w[:,:,None]*self.sc,1)
        H=(w@self.Hflat).reshape(-1,self.d,self.d)
        A=a*a*self.I+g*H;Ai=np.linalg.inv(A);delta=a*mu-y
        sval=(Ai@(a*sc+(H@delta[...,None])[...,0])[...,None])[...,0]
        dx=self.x-mu[:,None];ds=self.sc-sc[:,None]
        Bdx=dx@Ai;hd=dx@H;u=a*(delta/g-sval)
        Pv=(self.H.reshape(-1,self.d)@u.T).T.reshape(len(y),self.x.shape[1],self.d)
        hv=(H@u[...,None])[...,0]
        tr=np.sum(w*np.sum(Bdx*(a*a/g*(ds+hd)+Pv-hv[:,None]),2),1)-np.sum(Ai*H,axis=(1,2))
        return -y-sval,-self.d-tr

class SplineConditional:
    """Flexible sample-only scalar conditional mean and log-scale control."""
    def __init__(self,model,validation):
        assert model.d==1
        self.model=model;v=model.v;u=model.x[:,0]
        C=model.C;B=model.B
        self.centers=np.linspace(-2.5,2.5,7)
        vp=validation[:,C];up=validation[:,B][:,0]
        self.center=v.mean(0);self.scale=v.std(0)
        self.att=model.att if len(model.att) else np.array([0])
        best=None
        for width,all_linear,reg in itertools.product([.45,.9,1.5],[False,True],[.001,.03,.3]):
            X,G=self.features(v,width,all_linear)
            Xp,Gp=self.features(vp,width,all_linear)
            nf=X.shape[1];ng=G.shape[1]
            coef=np.linalg.solve(X.T@X+reg*np.eye(nf),X.T@u)
            sd=max(.02,np.sqrt(np.mean((u-X@coef)**2)))
            p0=np.r_[coef,np.log(sd),np.zeros(ng-1)]
            def fun(p0):
                m=X@p0[:nf];lograw=G@p0[nf:];ll,j=self.limit(lograw);e=u-m;w=np.exp(-2*ll)
                loss=np.mean(.5*e*e*w+ll)+reg*np.sum(p0[1:nf]**2)/len(u)+.1*np.sum(p0[nf+1:]**2)/len(u)
                dm=-(X.T@(e*w))/len(u);dl=G.T@((1-e*e*w)*j)/len(u)
                dm[1:]+=2*reg*p0[1:nf]/len(u);dl[1:]+=.2*p0[nf+1:]/len(u)
                return loss,np.r_[dm,dl]
            opt=minimize(fun,p0,jac=True,method="L-BFGS-B",options=dict(maxiter=300,ftol=1e-9))
            mean=Xp@opt.x[:nf];ll,_=self.limit(Gp@opt.x[nf:])
            nll=float(np.mean(.5*(up-mean)**2*np.exp(-2*ll)+ll))
            if best is None or nll<best[0]:best=(nll,width,all_linear,reg,opt.x,nf)
        _,self.width,self.all_linear,self.reg,self.par,self.nf=best
    @staticmethod
    def limit(x):
        k=8.;lo=-6.;hi=1.5
        from scipy.special import expit
        return lo+np.logaddexp(0,k*(x-lo))/k-np.logaddexp(0,k*(x-hi))/k,expit(k*(x-lo))-expit(k*(x-hi))
    def features(self,v,width,all_linear):
        w=(v-self.center)/self.scale;t=w[:,self.att]
        d=t[:,:,None]-self.centers
        R=np.sqrt(d*d+width*width).reshape(len(v),-1);E=np.exp(-.5*d*d).reshape(len(v),-1)
        X=np.c_[np.ones(len(v)),w if all_linear else t,R]
        G=np.c_[np.ones(len(v)),.5*np.log1p(t*t),E]
        return X,G
    def params(self,v):
        X,G=self.features(v,self.width,self.all_linear)
        return X@self.par[:self.nf],self.limit(G@self.par[self.nf:])[0]
    def logp(self,u,v):
        m,l=self.params(v);return -.5*(u[:,0]-m)**2*np.exp(-2*l)-l-.5*np.log(2*np.pi)
    def draw(self,v,rng):
        m,l=self.params(v);return (m+rng.normal(size=len(v))*np.exp(l))[:,None]

def fit_mask(x,s,H,B,C,W,validation,mode="adaptive",tight=False):
    # Order candidate context dimensions by measured normalized cross curvature.
    rank=np.argsort(-W[np.ix_(B,C)].max(0))
    v=validation[:,C];u=validation[:,B];d=len(C)
    if mode=="full":choices=[d];betas=[1.]
    elif mode=="local":choices=[min(len(B),d)];betas=[1.]
    else:choices=sorted(set([0,min(len(B),d),min(2*len(B),d),min(4,d),d]));betas=([.25,.35,.5,.75,1.,1.5,2.,3.] if tight else [.5,1.,1.5,2.,3.])
    best=None
    for k in choices:
        att=sorted(rank[:k].tolist())
        for beta in (betas if k else [1.]):
            m=Block(x,s,H,B,C,att,beta)
            nll=-m.gn_lp(u,v).mean()
            if best is None or nll<best[0]:best=(float(nll),m)
    return best

def fit_partition(x,s,H,validation,mode,tight=False):
    d=x.shape[1]//2;C=np.arange(d,2*d);W=l.couplings(H)
    candidates=[]
    if mode in ["adaptive","scalar"]:
        caps=[1,2,4] if mode=="adaptive" else [1]
        for cap in caps:
            part=l.fit_budget(W[:d,:d],max_block=cap,max_shared=0)
            candidates.append((part["blocks"],part["tolerance"]))
    if mode in ["adaptive","full"]: candidates.append(((tuple(range(d)),),0.))
    best=None;records=[]
    for BB,eps in candidates:
        fits=[fit_mask(x,s,H,list(B),C,W,validation,"full" if mode=="full" else "adaptive",tight) for B in BB]
        nll=float(sum(q[0] for q in fits));mods=[q[1] for q in fits]
        records.append(dict(blocks=[list(b) for b in BB],cutoff=eps,nll=nll,attention=[m.att.tolist() for m in mods],bandwidth=[m.beta for m in mods]))
        if best is None or nll<best[0]:best=(nll,mods,records[-1])
    return best[1],best[2],records

def tune_pf(x,s,H,blocks,C,validation,gate="lfgi"):
    """Select bandwidth and movement on an independent coordinate-only split."""
    out=[];records=[]
    # All 64 validation points are used for local NLL; none from the test chains.
    for old in blocks:
        B=old.B;v=validation[:,C];u=validation[:,B]
        beta_set=sorted(set([max(.125,old.beta/2),old.beta,min(4.,old.beta*1.5)])) if len(old.att) else [1.]
        best=None;options=[]
        for beta in beta_set:
            model=Block(x,s,H,B,C,old.att,beta)
            for transport in [0.,.5,1.]:
                try:
                    nll=-model.pf(u,v,gate,transport=transport).mean()
                    if not np.isfinite(nll):raise ArithmeticError("nonfinite validation NLL")
                except (RuntimeError,ArithmeticError,ValueError) as exc:
                    options.append(dict(beta=beta,transport=transport,error=repr(exc)));continue
                options.append(dict(beta=beta,transport=transport,nll=float(nll)))
                if best is None or nll<best[0]:best=(float(nll),model,transport)
        if best is None:raise ArithmeticError("All candidate conditional flows failed validation")
        _,model,transport=best;model.move=transport;model.gn_opt=old
        out.append(model);records.append(dict(B=B.tolist(),attention=old.att.tolist(),beta=model.beta,move=transport,nll=best[0],candidates=options))
    return out,records

def marginal(x,s,H,C,B,marg="gn"):
    if marg=="gmm":return p.fit_gmm(x[:,C],22001)
    Hbb=H[:,B][:,:,B];Hbc=H[:,B][:,:,C];Hcb=H[:,C][:,:,B];Hcc=H[:,C][:,:,C]
    control=Hcb.mean(0)@np.linalg.inv(Hbb.mean(0))
    sv=s[:,C]-s[:,B]@control.T
    Hv=Hcc-Hcb@np.linalg.solve(Hbb,Hbc)
    return GNMixture(x[:,C],sv,Hv)

def log_marg(q,v):return q.lp(v) if isinstance(q,GNMixture) else q.score_samples(v)
def draw_marg(q,rng,M,d):
    if isinstance(q,GNMixture):return q.draw(rng.normal(size=(M,d)),rng)
    return p.draw_gmm(q,rng,M)

def evaluate(name,blocks,C,qm,Z,validation,chart,t,lp,rng,methods=("lfgi","dpsmc","gn","gmm","gaussian"),transport=0.):
    M=len(Z);v=Z[:,C];vp=draw_marg(qm,rng,M,len(C));logqv=log_marg(qm,v);logqpv=log_marg(qm,vp)
    zbase=rng.normal(size=Z.shape);out=[]
    for method in methods:
        tick=time.monotonic();lq=logqv.copy();lqq=logqpv.copy();Q=np.zeros_like(Z);Q[:,C]=vp
        for model in blocks:
            B=model.B
            if method in ["lfgi","dpsmc"]:
                move=getattr(model,"move",transport)
                lq+=model.pf(Z[:,B],v,method,transport=move)
                q,lqqb=model.pf(zbase[:,B],vp,method,True,transport=move)
            elif method in ["gn","gnopt"]:
                gm=getattr(model,"gn_opt",model) if method=="gnopt" else model
                lq+=gm.gn_lp(Z[:,B],v);q=gm.gn_draw(vp,rng);lqqb=gm.gn_lp(q,vp)
            elif method=="spline":
                spline=SplineConditional(model,validation)
                lq+=spline.logp(Z[:,B],v);q=spline.draw(vp,rng);lqqb=spline.logp(q,vp)
            else:
                # Fit conditional GMM using all context or learned mask, select
                # by conditional validation NLL (same validation set).
                best=None
                for att in [list(range(len(C))),model.att.tolist()]:
                    if not att:continue
                    rows=np.c_[model.x,model.v[:,att]]
                    # Single Gaussian baseline or BIC-selected GMM.
                    if method=="gaussian":g=GaussianMixture(1,reg_covar=1e-5).fit(rows)
                    else:g=p.fit_gmm(rows,1234)
                    val=-p.condlp(g,validation[:,B],validation[:,C][:,att]).mean()
                    if best is None or val<best[0]:best=(val,g,att)
                _,g,att=best
                lq+=p.condlp(g,Z[:,B],v[:,att]);q=p.conddraw(g,vp[:,att],rng);lqqb=p.condlp(g,q,vp[:,att])
            Q[:,B]=q;lqq+=lqqb
        if chart is None:lpq=t.old_lp(Q);ld=np.zeros(M)
        else:
            xo,ld=chart.inverse(Q);lpq=t.old_lp(xo)+ld
        res=p.summarise(name+"_"+method,lp,lq,lpq,lqq,time.monotonic()-tick)
        res["density_RMSE"]=float(np.sqrt(np.mean((lp-lq-LOGZ)**2)))
        res["bridge_error"]=res["logZ"]-LOGZ
        res["forward_KL"]=res["mean_log_ratio"]-LOGZ
        res["reverse_KL"]=LOGZ-res["mean_proposal_logratio"]
        out.append(res)
        np.savez_compressed(OUT/f"{name}_{method}_arrays.npz",points=Z,logp=lp,logq=lq,proposal=Q,logp_proposal=lpq,logq_proposal=lqq)
    return out

def run(seed,N,M,variant,mode,marg="gn",transport=0.,methods_override=None,tune=False,tune_gate="lfgi"):
    OUT.mkdir(exist_ok=True)
    t=p.Target();ref=np.load(p.REF)["samples_by_chain"]
    train=ref[:2].reshape(-1,16);test=ref[2:].reshape(-1,16)
    ids=np.random.default_rng(seed).permutation(len(train));x=train[ids[:N]]
    # Extra coordinate-only validation set from training pool, disjoint bank.
    val=train[ids[N:N+64]]
    y=test[np.random.default_rng(seed+200000).permutation(len(test))[:M]]
    s,H=l.original_marks(t,x)
    if variant=="original":
        chart=None;z=x;ss=s;PP=H;Z=y;validation=val;W=l.couplings(PP)
        part=l.fit_budget(W,max_block=4,max_shared=4)
        C=np.array(part["shared"]);B=tuple(part["blocks"]);pool=[fit_mask(z,ss,PP,list(b),C,W,validation,"adaptive") for b in B]
        blocks=[m[1] for m in pool]
        selected=dict(blocks=[list(b) for b in B],shared=C.tolist(),cutoff=part["tolerance"],attention=[m.att.tolist() for m in blocks],bandwidth=[m.beta for m in blocks]);candidates=[selected]
        qm=marginal(z,ss,PP,C,np.array([i for b in B for i in b]),"gmm");lp=t.old_lp(Z)
        info=dict()
    else:
        chart=l.Chart(x,s,H,seed,variant!="affine",variant.startswith("residual"),variant=="residual_safe")
        z,ss,PP=chart.marks(x,s,H);Z=chart.transform(y);validation=chart.transform(val)
        lp=t.old_lp(y)+chart.inverse(Z)[1]
        C=np.arange(8,16)
        blocks,selected,candidates=fit_partition(z,ss,PP,validation,mode,tune)
        if tune:
            blocks,tuning=tune_pf(z,ss,PP,blocks,C,validation,tune_gate)
            selected["PF_tuning"]=tuning
        qm=marginal(z,ss,PP,C,np.arange(8),marg)
        info=chart.info|dict(validation=chart.validate(t,y[:8]),std=Z.std(0).tolist(),
             W=l.couplings(PP).tolist(),selected_chart=[m.selected for m in chart.parts] if chart.nonlinear else [])
    print("structure",json.dumps(selected),flush=True)
    print("candidates",json.dumps(candidates),flush=True)
    tag=f"{variant}_{mode}_{seed}_{N}_{M}"+("_"+marg if marg!="gn" else "")+(f"_move{transport:g}" if transport else "")+("_tuned" if tune else "")
    if tune and tune_gate!="lfgi":tag+="_"+tune_gate
    if methods_override==["spline"]:tag+="_spline"
    if variant=="original":methods=["lfgi","gn","gmm"]
    else:methods=["gn","gaussian","gmm","lfgi","dpsmc"]+(["gnopt"] if tune else [])
    if methods_override:methods=methods_override
    result=evaluate(tag,blocks,C,qm,Z,validation,chart,t,lp,np.random.default_rng(seed+800000),methods,transport)
    (OUT/f"{tag}.json").write_text(json.dumps(dict(seed=seed,N=N,M=M,variant=variant,mode=mode,marginal=marg,transport=transport,selected=selected,candidates=candidates,structure=info,results=result),indent=2))

if __name__=="__main__":
    a=argparse.ArgumentParser();a.add_argument("--seed",type=int,default=23000);a.add_argument("--N",type=int,default=256);a.add_argument("--M",type=int,default=128);a.add_argument("--variant",choices=["original","affine","nonlinear","residual","residual_safe"],default="nonlinear");a.add_argument("--mode",choices=["adaptive","scalar","full"],default="adaptive");a.add_argument("--marg",choices=["gn","gmm"],default="gn");a.add_argument("--move",type=float,default=0.);a.add_argument("--methods",nargs="+");a.add_argument("--tune",action="store_true");a.add_argument("--tune-gate",choices=["lfgi","dpsmc"],default="lfgi");args=a.parse_args()
    run(args.seed,args.N,args.M,args.variant,args.mode,args.marg,args.move,args.methods,args.tune,args.tune_gate)
