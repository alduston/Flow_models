"""Small conditional affine-coupling density; NumPy Adam and validation."""
import acoustic_pilot as p
from acoustic_marginal import GNMixture
import numpy as np
import argparse,json,time

class Flow:
    def __init__(self,x,blocks,width,seed,d=8):
        self.blocks=blocks;self.width=width;self.d=d;self.k=x.shape[1]-d
        rng=np.random.default_rng(seed)
        h,v=x[:,:d],x[:,d:]
        self.vm=v.mean(0);self.vL=np.linalg.cholesky(np.atleast_2d(np.cov(v.T))+1e-5*np.eye(self.k))
        V=np.linalg.solve(self.vL,(v-self.vm).T).T
        Q=np.c_[np.ones(len(V)),V];self.beta=np.linalg.solve(Q.T@Q+1e-4*np.eye(self.k+1),Q.T@h)
        r=h-Q@self.beta;self.L=np.linalg.cholesky(np.atleast_2d(np.cov(r.T))+1e-5*np.eye(d))
        self.ld=np.log(np.diag(self.L)).sum()
        self.params=[]
        for i in range(blocks):
            self.params.append([rng.normal(scale=np.sqrt(2/(d+self.k+width)),size=(d+self.k,width)),np.zeros(width),
                                rng.normal(scale=np.sqrt(1/width),size=(width,width)),np.zeros(width),
                                np.zeros((width,2*d)),np.zeros(2*d)])
        self.masks=[(np.arange(d)+i)%2 for i in range(blocks)]
        self.avg=[[np.zeros_like(k) for k in q] for q in self.params]
        self.sq=[[np.zeros_like(k) for k in q] for q in self.params];self.step=0
    def condition(self,v):
        V=np.linalg.solve(self.vL,(v-self.vm).T).T
        return V,np.c_[np.ones(len(V)),V]@self.beta
    def network(self,y,v,i):
        mask=self.masks[i];W1,b1,W2,b2,W3,b3=self.params[i]
        X=np.c_[y*mask,v];a=np.tanh(X@W1+b1);b=np.tanh(a@W2+b2);o=b@W3+b3
        ss=np.tanh(o[:,:self.d]/2);s=2*ss*(1-mask);t=o[:,self.d:]*(1-mask)
        return s,t,(X,a,b,ss)
    def forward(self,h,v,cache=False):
        v,mu=self.condition(v);y=np.linalg.solve(self.L,(h-mu).T).T
        ld=np.full(len(y),-self.ld);c=[]
        for i in range(self.blocks):
            s,t,nn=self.network(y,v,i);z=y*np.exp(s)+t
            if cache:c.append((y,s,nn))
            ld+=s.sum(1);y=z
        return -.5*np.sum(y*y,axis=1)-self.d/2*np.log(2*np.pi)+ld,y,c
    def logq(self,h,v):return self.forward(h,v)[0]
    def draw(self,v,z):
        V,mu=self.condition(v);y=z.copy()
        for i in range(self.blocks-1,-1,-1):
            s,t,_=self.network(y,V,i);y=(y-t)*np.exp(-s)
        return y@self.L.T+mu
    def update(self,h,v):
        lp,z,cache=self.forward(h,v,True);dy=z/len(z);grads=[]
        for i in range(self.blocks-1,-1,-1):
            y,s,(X,a,b,ss)=cache[i];mask=self.masks[i];W1,b1,W2,b2,W3,b3=self.params[i];es=np.exp(s)
            ds=(dy*y*es-1/len(z))*(1-mask)*(1-ss*ss);dt=dy*(1-mask)
            do=np.c_[ds,dt];gW3=b.T@do;gb3=do.sum(0);db=(do@W3.T)*(1-b*b)
            gW2=a.T@db;gb2=db.sum(0);da=(db@W2.T)*(1-a*a)
            gW1=X.T@da;gb1=da.sum(0);dinput=da@W1.T
            dy=dy*es+dinput[:,:self.d]*mask
            grads.insert(0,[gW1,gb1,gW2,gb2,gW3,gb3])
        norm=np.sqrt(sum(np.sum(g*g) for l in grads for g in l));scale=min(1.,5/(norm+1e-20))
        self.step+=1
        for i,l in enumerate(grads):
            for j,grad in enumerate(l):
                grad=grad*scale;m=self.avg[i][j];w=self.sq[i][j]
                m*=.9;m+=.1*grad;w*=.999;w+=.001*grad*grad
                self.params[i][j]-=.001*(m/(1-.9**self.step))/(np.sqrt(w/(1-.999**self.step))+1e-8)
        return -lp.mean()
    def train(self,x,seed,epochs,validation=None):
        rng=np.random.default_rng(seed);best=-np.inf;bestepoch=1
        for ep in range(1,epochs+1):
            perm=rng.permutation(len(x))
            for i in range(0,len(x),128):
                a=x[perm[i:i+128]];self.update(a[:,:self.d],a[:,self.d:])
            if validation is not None:
                ll=self.logq(validation[:,:self.d],validation[:,self.d:]).mean()
                if ll>best:best=ll;bestepoch=ep
                if ep-bestepoch>=25:break
        return best,bestepoch

def run(seed,N,M):
    t=p.Target();ref=np.load(p.REF)["samples_by_chain"]
    train=ref[:2].reshape(-1,16);test=ref[2:].reshape(-1,16)
    x=t.to_new(train[np.random.default_rng(seed).permutation(len(train))[:N]])
    y=t.to_new(test[np.random.default_rng(seed+200000).permutation(len(test))[:M]])
    tick=time.monotonic();rng=np.random.default_rng(seed+700000)
    order=rng.permutation(N);k=int(.8*N);tr,va=x[order[:k]],x[order[k:]]
    best=None
    for blocks,width in [(4,32),(6,64)]:
        for i in range(2):
            f=Flow(tr,blocks,width,seed+i);ll,ep=f.train(tr,seed+i,300,va)
            print("validation",blocks,width,i,ll,ep,flush=True)
            if best is None or ll>best[0]:best=(ll,ep,blocks,width,i)
    _,ep,blocks,width,i=best;f=Flow(x,blocks,width,seed+i);f.train(x,seed+i,ep)
    print("selected",best,"fit_seconds",time.monotonic()-tick,flush=True)
    # Round-trip conditional flow (exact affine coupling).
    z=rng.normal(size=(M,8));v=y[:,8:];h=f.draw(v,z)
    lp,z2,c=f.forward(h,v);print("roundtrip",np.max(np.abs(z-z2)),flush=True)
    out=[];s,H=t.bank(x);Hhh=H[:,:8,:8];Hhv=H[:,:8,8:];Hvh=H[:,8:,:8];Hvv=H[:,8:,8:]
    B=Hvh.mean(0)@np.linalg.inv(Hhh.mean(0));sv=s[:,8:]-s[:,:8]@B.T;Hv=Hvv-Hvh@np.linalg.solve(Hhh,Hhv)
    gm=GNMixture(x[:,8:],sv,Hv);g=p.fit_gmm(x[:,8:],seed)
    for name,v,lv,ly in [
        ("GMM_marginal_fitted_flow", (vg:=p.draw_gmm(g,rng,M)),g.score_samples(vg),g.score_samples(y[:,8:])),
        ("GN_marginal_fitted_flow", (vn:=gm.draw(rng.normal(size=(M,8)),rng)),gm.lp(vn),gm.lp(y[:,8:]))]:
        tick=time.monotonic();h=f.draw(v,z);q=np.c_[h,v]
        out.append(p.summarise(name,t.lp(y),ly+f.logq(y[:,:8],y[:,8:]),t.lp(q),lv+f.logq(h,v),time.monotonic()-tick))
    (p.OUT/f"{seed}_{N}_{M}_flow.json").write_text(json.dumps(out,indent=2))

if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--seed",type=int,default=23000);parser.add_argument("--N",type=int,default=256);parser.add_argument("--M",type=int,default=256);a=parser.parse_args()
    run(a.seed,a.N,a.M)
