"""Learn hard local and separator coordinate masks from cached GN marks."""
from itertools import combinations

import numpy as np


def couplings(curvature):
    """RMS of the normalized signed off-diagonal interactions."""
    diagonal = np.diagonal(curvature, axis1=1, axis2=2)
    if np.any(diagonal <= 0) or not np.isfinite(curvature).all():
        raise ValueError("Expected finite marks with positive diagonals")
    scaled = curvature / np.sqrt(diagonal[:, :, None] * diagonal[:, None, :])
    rms = np.sqrt(np.mean(scaled**2, axis=0))
    np.fill_diagonal(rms, 0)
    return rms


def connected_components(adjacency, removed):
    remaining = ((1 << len(adjacency)) - 1) ^ sum(1 << i for i in removed)
    blocks = []
    while remaining:
        frontier = remaining & -remaining
        block = []
        while frontier:
            bit = frontier & -frontier
            i = bit.bit_length() - 1
            remaining ^= bit
            block.append(i)
            frontier = (frontier ^ bit) | (adjacency[i] & remaining)
        blocks.append(tuple(sorted(block)))
    return tuple(blocks)


def fit(coupling, tolerance=1e-8, max_block=8, max_shared=4):
    """Find the smallest separator. Each local mask is a graph component."""
    adjacency = [sum(1 << int(j) for j in np.flatnonzero(row > tolerance))
                 for row in coupling]
    for size in range(max_shared + 1):
        best = None
        feasible = 0
        for shared in combinations(range(len(coupling)), size):
            blocks = connected_components(adjacency, shared)
            sizes = [len(block) for block in blocks]
            if len(sizes) < 2 or max(sizes) > max_block:
                continue
            feasible += 1
            key = (max(sizes), sum(n*n for n in sizes), shared)
            if best is None or key < best[0]:
                best = (key, shared, blocks)
        if best is not None:
            return dict(shared=best[1], blocks=best[2],
                        min_size_feasible=feasible, tolerance=float(tolerance))
    return None


def fit_budget(coupling, max_block=8, max_shared=2):
    """Minimize the largest excluded RMS coupling under a shared-size cap."""
    grid = np.unique(coupling[np.triu_indices_from(coupling, k=1)])
    low, high = 0, len(grid)-1
    while low < high:
        middle = (low + high) // 2
        if fit(coupling, grid[middle], max_block, max_shared) is None:
            low = middle + 1
        else:
            high = middle
    return fit(coupling, grid[low], max_block, max_shared)


def canonical(partition, permutation):
    """Map the learned sets from blinded coordinates back to source coordinates."""
    shared = tuple(sorted(int(permutation[j]) for j in partition["shared"]))
    blocks = tuple(sorted(tuple(sorted(int(permutation[j]) for j in block))
                          for block in partition["blocks"]))
    return shared, blocks


def exclusion(coupling, blocks):
    edges = [coupling[np.ix_(a, b)].ravel()
             for i, a in enumerate(blocks) for b in blocks[i+1:]]
    return np.concatenate(edges) if edges else np.zeros(1)
