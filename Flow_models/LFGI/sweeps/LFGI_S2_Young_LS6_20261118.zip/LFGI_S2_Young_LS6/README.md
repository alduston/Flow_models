# Tanh Young-only follow-up for LS6

The production array adds one Young time-only full-matrix fit per original Tanh reference bank. It runs **60 fits** over seeds 22000–22019 and the three nested bank sizes 50, 150 and 450. The published target, rejection splits, 512 held-out states, five batches of 512 proposals, solver, matched $10^{-6}$ endpoint and 16-point density round-trip tolerance of 0.001 remain in use. The proposal and display streams use the original LFGI terminal Gaussian seeds so the Gaussian inputs are shared. Every other proposal in the delivered comparisons is read from archived results.

## Launch

Extract in a new directory on LS6 and submit from the bundle root.

    unzip LFGI_S2_Young_LS6_20261118.zip
    cd LFGI_S2_Young_LS6
    bash submit.sh

The dependency graph runs setup, a native **Young-only** numerical smoke, the production array, the appendix display job, and the report. With full queue headroom the array has 20 tasks and three fits per task. The report runs after the array and display stages so it can record failures and missing cells. The original LS6 defaults for compute modules and normal queue are retained. The Young Tanh venv is separate from the other campaigns. Current queue headroom is checked by the launcher. Use the command below to leave more slots available for the Quake campaign.

    S2_ARRAY_TASKS=8 S2_ARRAY_CONCURRENCY=4 bash submit.sh

The command below runs one Young fit for seed 22000 and N=150 with 128 held-out states and one 128-draw proposal batch. It exercises production routing and reporting. The appendix displays run with the production bank sizes N=50 and 450. The --smoke-only option performs setup and native validation. The --no-marginals option omits the appendix stage.

    bash submit.sh --pilot

## Gate and validation

For each clean-score bank, the code computes $F=N^{-1}\sum_i s(x_i)s(x_i)^\top$. Young et al.'s full matrix schedule in the standard Gaussian OU convention gives the target-score weight $G_t=\alpha_t^2(\alpha_t^2 I+\gamma_t F)^{-1}$, with $\alpha_t=e^{-t}$ and $\gamma_t=1-e^{-2t}$. The score field uses the original query-dependent OU weights to estimate Tweedie and the target-score signal. This implementation estimates $F$ from the clean scores already available with the bank. The field uses the algebraically equivalent stable score form and differentiates the empirical weights in the probability-flow divergence. [Young et al., Proposition 3](https://arxiv.org/abs/2601.21951)

The normalization uses the same normalized Gaussian prior and likelihood with its Gaussian observation constant omitted. The independent deterministic quadrature reference is approximately −2.127379376772. Local checks verify the archived bank and held-out fixture, formula and divergence, tightened solver tolerances, checkpoint reuse, array routing, recovery against a mock scheduler and the reduced appendix writer. The LS6 smoke must pass on the installed cluster environment before the production array starts. See provenance/LOCAL_VALIDATION.json for the local check scope.

## Retrieve and merge

Check logs/submitted_ids.txt, logs/production_task*_progress.json, and reports/production/status.json. Compact exports include raw repetitions, diagnostics, reported figure data and appendix artifacts.

    python pack_results.py

The split ZIPs and INDEX.json are written under exports/. Keep these together when transferring results.

- **per_repeat.csv** in reports/production contains Young rows keyed by seed, N, method and repeat for appending to the existing Tanh records. The method identifier is **young**. The result tree also retains the raw proposal, target and held-out density arrays.
- **figure_statistics.csv**, **largest_bank_summary.csv** and **paired_lfgi_differences.csv** give manuscript-scale metrics and paired differences against the frozen LFGI-GN rows. Resampling uses the paper's 6,000 whole-bank bootstrap draws. Proposal repeats remain nested within a group.
- **actual_N{N}_young.npz** carries 8,192 actual particles per display bank, seed 22000 at N=50 and 450. The comparison displays reuse the archived 40-by-40 bins, normalization, color scale and original comparator bins. **S2_young_actual.pdf** and its PNG show Young beside the published panels, including the target's two-by-two bin quadrature.
- **S2_young_implicit.pdf**, its PNG, **implicit_hist_N{N}_young.npz** and the matching raw cubature and diagnostics files use a shared mixture of the three retained archived comparator strata. Each bank uses 512 points from each stratum, with archived densities and a recomputed common denominator. The implicit panel is a supporting integration diagnostic. Its 1,536-point common proposal uses the archived coordinates retained for the three displayed comparators. The historical auxiliary mixture used ten strata, of which seven lack retained sample coordinates. Young's raw importance weights are untruncated. The export records mass, stratified MCSE and ESS for the implicit panels.

When all jobs from a submission are terminal, the launcher can restart it and will reuse identity-matched checkpoints and completed cells. Diagnose a failed numerical cell before explicit retry with S2_RETRY_FAILED=1. To finish a partially accepted submission, resume with the original profile/options once you have the accepted setup job ID.

    python3 resume_submission.py --setup ACCEPTED_SETUP_ID

