"""Regression checks for the exact archived Tanh split and the Young field."""
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
import sys
from pathlib import Path

import numpy as np
from scipy.special import softmax

R = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(R/'code'))
from common import read, write
from fields import Bank, Field
from reference import quadrature
from target import TanhIP

target = TanhIP()
x = target.sample(450, np.random.default_rng(22000))
posterior = target.sample(512, np.random.default_rng(222000))
scores = target.score(x)
with np.load(R/'tests/previous_group00_fixture.npz') as archived:
    for actual, key in [(x, 'x'), (scores, 's'), (posterior, 'posterior')]:
        np.testing.assert_allclose(actual, archived[key], rtol=1e-13, atol=1e-13)

quadrature_reference = quadrature(10, 256)
assert abs(quadrature_reference['logZ'] - read(R/'provenance/previous_reference.json')['logZ']) < 1e-9
random = np.random.default_rng(123)
y = random.normal(size=(5, 2))
step = 1e-5
eye = np.eye(2)
score_fd = np.column_stack([(target.logp(y+step*e) - target.logp(y-step*e))/(2*step) for e in eye])
np.testing.assert_allclose(target.score(y), score_fd, rtol=1e-7, atol=1e-7)

bank = Bank(x[:50], scores[:50])
field = Field(bank)
errors = []
formula_errors = []
for t in [1e-6, .001, .03, .5, 8.]:
    points = x[50:54]
    result = field(points, t)
    alpha, gamma = np.exp(-t), -np.expm1(-2*t)
    weights = softmax(-np.sum((points[:, None]-alpha*bank.x)**2, axis=2)/(2*gamma), axis=1)
    b = (alpha*(weights @ bank.x) - points)/gamma
    c = (weights @ bank.s)/alpha
    gate = alpha**2 * np.linalg.inv(alpha**2*eye + gamma*bank.fisher)
    direct = b + (c-b) @ gate.T
    np.testing.assert_allclose(result['score'], direct, rtol=1e-7, atol=1e-7)
    # Small complex steps differentiate the implemented weighted field without finite-difference noise.
    jacobian = np.stack([
        field(points.astype(complex) + 1e-24j*e, t)['score'].imag/1e-24 for e in eye
    ], axis=2)
    np.testing.assert_allclose(result['J'], jacobian, rtol=1e-8, atol=1e-8)
    errors.append(float(np.max(abs(jacobian-result['J'])/(1+abs(jacobian)))))
    formula_errors.append(float(np.max(abs(result['score']-direct)/(1+abs(direct)))))

write(R/'logs/local_unit_checks.json', dict(
    passed=True, old_bank_and_heldout_fixture=True, target_score_check=True,
    reference_logZ=quadrature_reference['logZ'], field_relative_J_errors=errors,
    field_relative_direct_gate_errors=formula_errors,
))
print('Archived bank/held-out data, quadrature, exact Young blend and analytic derivative passed')
