"""Mock scheduler coverage for accepted setup recovery; never submits real jobs."""
import json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

R = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(R / 'ls6'))
from parse_sbatch import parse

for raw in ['123\n', '123;ls6\n', 'Submitted batch job 123\n',
            'Welcome to the Lonestar6 Supercomputer\n--> Checking allocation...OK\n123\n']:
    assert parse(raw) == '123'
for raw in ['', 'No reservation for this job', '123\n456\n']:
    try:
        parse(raw)
    except ValueError:
        pass
    else:
        raise AssertionError(raw)

SCHEDULER = r'''#!/usr/bin/env python3
import json, os, sys
from pathlib import Path
p=Path(os.environ['MOCK_ROOT']);name=Path(sys.argv[0]).name;a=sys.argv[1:]
if name=='scontrol':
 if 'job' in a:
  id=a[a.index('job')+1]
  if os.getenv('MOCK_ACCOUNTING')=='1':sys.exit(1)
  if id=='3586793':
   n='s2-young-setup';state=os.getenv('MOCK_STATE','PENDING');wd=str(p) if os.getenv('MOCK_WRONG_DIR')!='1' else '/somewhere/else'
  else:
   row=json.loads((p/('job'+id+'.json')).read_text());n=row[row.index('-J')+1];state='PENDING';wd=str(p)
  print('JobId='+id+' JobName='+n+' JobState='+state+' WorkDir='+wd)
 elif 'partition' in a:print('PartitionName=normal QoS=normal')
 else:print('MaxArraySize = 1001')
elif name=='sacct':
 id=a[a.index('-j')+1];print(id+'|s2-young-setup|'+os.getenv('MOCK_STATE','COMPLETED')+'|'+str(p)+'|')
elif name=='qlimits':print('normal MaxJobsPU=20 MaxSubmitPU=100')
elif name=='sacctmgr':print('normal|20|100|')
elif name=='squeue':print('3586793|normal|PENDING')
elif name=='sbatch':
 f=p/'counter';n=int(f.read_text())+1 if f.exists() else 1;f.write_text(str(n));id=str(4000+n)
 with (p/'calls.jsonl').open('a') as out:out.write(json.dumps(a)+'\n')
 (p/('job'+id+'.json')).write_text(json.dumps(a))
 print('Welcome to the Lonestar6 Supercomputer\nNo reservation for this job\n--> Checking available allocation...OK')
 if os.getenv('MOCK_FAIL')=='1':print('Mock rejection',file=sys.stderr);sys.exit(1)
 print(id)
'''

def case(state='PENDING', wrong=False, accounting=False, fail=False):
    with tempfile.TemporaryDirectory() as temp:
        d=Path(temp);(d/'bin').mkdir();(d/'ls6').mkdir();(d/'configs').mkdir()
        shutil.copy(R/'resume_submission.py',d)
        for n in ['job.sh','limits.py']:shutil.copy(R/'ls6'/n,d/'ls6'/n)
        shutil.copy(R/'configs/RUN_MATRIX.csv',d/'configs/RUN_MATRIX.csv')
        for n in ['sbatch','scontrol','sacct','squeue','qlimits','sacctmgr']:
            p=d/'bin'/n;p.write_text(SCHEDULER);p.chmod(0o755)
        env={k:v for k,v in os.environ.items() if not k.startswith('S2_')}
        env.update(PATH=str(d/'bin')+os.pathsep+env['PATH'],MOCK_ROOT=str(d),MOCK_STATE=state,
                   MOCK_WRONG_DIR=str(int(wrong)),MOCK_ACCOUNTING=str(int(accounting)),MOCK_FAIL=str(int(fail)))
        args=[sys.executable,'resume_submission.py','--setup','3586793']
        r=subprocess.run(args,cwd=d,env=env,capture_output=True,text=True)
        if wrong or state=='FAILED':
            assert r.returncode!=0 and not (d/'counter').exists(),r.stdout+r.stderr
            return
        if fail:
            assert r.returncode!=0 and (d/'counter').read_text()=='1',r.stdout+r.stderr
            assert 'Mock rejection' in (d/'logs/submission_responses.log').read_text()
            return
        assert r.returncode==0,r.stdout+r.stderr
        calls=[json.loads(s) for s in (d/'calls.jsonl').read_text().splitlines()]
        assert len(calls)==4
        stages={c[-2]:c for c in calls};assert 'setup' not in stages
        if state=='COMPLETED':assert not any(s.startswith('--dependency') for s in stages['smoke'])
        else:assert '--dependency=afterok:3586793' in stages['smoke']
        assert '--dependency=afterok:4001' in stages['production']
        assert '--array=0-19%20' in stages['production']
        assert '--dependency=afterany:4002' in stages['marginals']
        assert '--dependency=afterany:4002:4003' in stages['report']
        rr=subprocess.run(args,cwd=d,env=env,capture_output=True,text=True)
        # Accounting mock only knows setup, so duplicate reuse uses the controller mock.
        if not accounting:
            assert rr.returncode==0 and (d/'counter').read_text()=='4',rr.stdout+rr.stderr

case();case(state='COMPLETED');case(state='COMPLETED',accounting=True)
case(state='FAILED');case(wrong=True);case(fail=True)
out=dict(passed=True,banner_parser=True,ambiguous_response_rejected=True,
         accepted_setup_reused=True,completed_setup_no_stale_dependency=True,
         accounting_fallback=True,duplicate_child_guard=True,wrong_directory_rejected=True,
         failed_setup_rejected=True,sbatch_failure_logged=True,remote_jobs_submitted=False)
(R/'logs/submission_recovery_checks.json').write_text(json.dumps(out,indent=2))
print('Banner parsing and submission recovery checks passed (mock scheduler only)')
