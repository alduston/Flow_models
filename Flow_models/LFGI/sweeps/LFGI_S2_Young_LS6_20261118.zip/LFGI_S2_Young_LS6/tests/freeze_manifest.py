"""Release-time source/data freeze; do not run this to bypass an active campaign check."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[1];paths=[]
for folder in ['code','ls6','configs','data','tests']:
 paths.extend(p for p in (R/folder).glob('*') if p.is_file() and p.suffix in ['.py','.sh','.txt','.json','.npz','.csv'])
paths.extend(R/n for n in ['submit.sh','resume_submission.py','pack_results.py', 'provenance/previous_reference.json', 'provenance/build_display_reference.py'])
(R/'provenance/IMMUTABLE_SHA256.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)},indent=2))
