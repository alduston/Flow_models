"""Round-trip, tightened tolerance and deterministic checkpoint regression tests."""
import os
os.environ['OPENBLAS_NUM_THREADS'] = '1'
import sys
import tempfile
from pathlib import Path

import numpy as np

R = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(R/'code'))
from common import read, write
from fields import Bank
from flows import PFModel, integrate

config = read(R/'configs/campaign.json')
a = np.load(R/'prepared/seed22000.npz')
post = np.load(R/'prepared/posterior_seed22000.npz')['x']
records = []
with tempfile.TemporaryDirectory() as temp:
    root = Path(temp)
    base = dict(tau=config['tau_cap'], T=config['T'], rtol=config['rtol'], atol=config['atol'], chunk=8)
    tight = dict(base, rtol=base['rtol']/20, atol=base['atol']/20)
    os.environ['S2_CHUNK_WORKERS'] = '1'
    for n in [50, 450]:
        bank = Bank(a['x'][:n], a['s'][:n])
        model = PFModel(bank, 'young', base, root/f'{n}_base', 'test')
        ref = PFModel(bank, 'young', tight, root/f'{n}_tight', 'test')
        err = float(np.max(abs(model.logq(post[:8])-ref.logq(post[:8]))))
        assert err < 1e-3, (n, err)
        q, lq = model.sample_logq(8, np.random.default_rng(77), 'draws')
        roundtrip = float(np.max(abs(model.logq(q, tag='inverse_check') - lq)))
        assert roundtrip < config['roundtrip_tolerance'], (n, roundtrip)
        records.append(dict(N=n, method='young', tightened_logq_max_difference=err, roundtrip_max_error=roundtrip))

    bank = Bank(a['x'][:150], a['s'][:150])
    y = post[:16]
    serial = integrate(bank, y, 'young', False, base, root/'serial', 'chunk_test')
    os.environ['S2_CHUNK_WORKERS'] = '2'
    parallel = integrate(bank, y, 'young', False, base, root/'parallel', 'chunk_test')
    cached = integrate(bank, y, 'young', False, base, root/'parallel', 'chunk_test')
    assert all(np.array_equal(x, y) for x,y in zip(serial, parallel))
    assert all(np.array_equal(x, y) for x,y in zip(cached, parallel))

write(R/'logs/numerical_flow_checks.json', dict(
    passed=True, checks=records, parallel_bitwise=True, checkpoint_resume_bitwise=True,
    scope='small held-out arrays; full production still performs the per-cell 16-point roundtrip guard',
))
print('Tightened Young tolerances, normalized-density round-trip, parallel equality and checkpoint resume passed')
