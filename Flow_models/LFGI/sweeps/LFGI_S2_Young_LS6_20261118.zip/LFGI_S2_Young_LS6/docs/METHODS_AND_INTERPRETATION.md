# Protocol for the Tanh Young gate

## Score and probability flow

The two-dimensional Tanh target and its normalized prior match the published experiment. At each bank size, let $S$ contain the exact clean scores, row by row, of the same posterior locations used by the other proposals. Estimate the pooled second moment $F=S^\top S/N$. In the OU parameterization of Young et al.'s Proposition 3, with a unit Gaussian base, the target-score coefficient is $G_t=\alpha^2(\alpha^2 I+\gamma F)^{-1}$. This uses Young's population schedule in the archived finite-bank probability-flow pipeline. The original DPSMC estimator uses auxiliary SMC samples. [Young et al., Proposition 3](https://arxiv.org/abs/2601.21951)

The score computation uses $b+G_t(c-b)$, with the original empirical OU weights and the original definitions of Tweedie signal $b$ and target-score signal $c$. The code evaluates the equivalent expression below, which avoids cancelling two large terms at small noise.

    inverse(alpha^2 I + gamma F) [ alpha weighted_mean(s_i + F x_i) - F y ]

For fixed $t$, the score Jacobian is the same left inverse times $(\alpha^2/\gamma)\operatorname{Cov}_w(s_i+Fx_i,x_i)-F$. The anchored covariance supports the numerically concentrated regime near the matched endpoint. The pooled $F$ is estimated once for each nested reference prefix.

The reference acquisition is identical in its rejection location and held-out seeds. The post-processing fit reads one clean score per bank location and records zero use of bank Hessians. The table comparison combines the time-only schedule with its pooled score moment and LFGI-GN with its local curvature estimates.

## Reporting and displays

Independent reference groups are the bootstrap unit. A group-level proposal metric uses all five proposal batches before resampling. The bridge RMSE starts with the mean squared bridge errors within each group, then averages over groups before taking the square root. Paired comparisons resample matching groups. The bundled archived_lfgi_per_repeat.csv is the slice of the manuscript Data/Applications/s2/per_repeat.csv with method lfgi.

The frozen display arrays were extracted from Data/Applications/s2/high_resolution in the manuscript source. The script provenance/build_display_reference.py reconstructs the bundle fixture. The bundle preserves the paper's actual-particle display settings and uses common weights for the supporting implicit panels. The frozen implicit proposal uses the sample coordinates that were retained, taking the first 512 points of each archived LFGI-GN, Selected GMM and Fitted flow cloud and the corresponding density evaluations. All panels retain raw in-window mass with the full draw count as denominator. The script retains density integration and generation/evaluation diagnostics by bank size.
