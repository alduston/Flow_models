"""Deterministic bounded-size, cost-balanced fit partition; no scientific inputs changed."""
import hashlib,json,math
from pathlib import Path
def key(c):return (int(c['seed']),int(c['N']),c['method'])
def effort(c,chunks=4):
 if c['method'] != 'young':raise ValueError('Unexpected method in Young-only array')
 return (c['N']/450.)**1.1/chunks
def build(cells,count,chunks=4):
 count=min(int(count),len(cells))
 if count<1:raise ValueError('at least one array task required')
 quotas=[len(cells)//count+(i<len(cells)%count) for i in range(count)];bins=[[] for _ in range(count)];loads=[0.]*count
 for c in sorted(cells,key=lambda c:(-effort(c,chunks),key(c))):
  i=min((i for i in range(count) if len(bins[i])<quotas[i]),key=lambda i:(loads[i],len(bins[i]),i));bins[i].append(c);loads[i]+=effort(c,chunks)
 assert sorted(key(c) for b in bins for c in b)==sorted(key(c) for c in cells)
 return dict(tasks=count,chunk_workers=chunks,quotas=quotas,estimated_relative_load=loads,shards=bins,weight_scope='static relative scheduling estimates; not benchmarked LS6 runtimes')
def fingerprint(plan):return hashlib.sha256(json.dumps(plan,sort_keys=True).encode()).hexdigest()
