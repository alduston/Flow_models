"""Parse Slurm IDs even when a site wrapper writes a banner to stdout."""
import re,sys

def parse(text):
 candidates=[]
 for line in text.splitlines():
  s=line.strip();m=re.fullmatch(r'(?:Submitted batch job\s+)?([0-9]+)(?:;[A-Za-z0-9_.-]+)?',s)
  if m:candidates.append(m.group(1))
 ids=set(candidates)
 if len(ids)!=1:raise ValueError('No unique job ID in sbatch output; inspect submission_responses.log before retrying')
 return candidates[-1]
if __name__=='__main__':
 try:print(parse(sys.stdin.read()))
 except ValueError as e:print(str(e),file=sys.stderr);sys.exit(2)
