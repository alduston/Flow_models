"""Deterministic evidence/entropy reference; never used to select fitted proposals."""
import numpy as np
from scipy.special import ndtr
from common import ROOT,write
from target import TanhIP

def quadrature(L,n):
 t=TanhIP();z,w=np.polynomial.legendre.leggauss(n);z*=L;w*=L;xx,yy=np.meshgrid(z,z,indexing='ij');x=np.c_[xx.ravel(),yy.ravel()];ww=(w[:,None]*w[None,:]).ravel();lp=t.logp(x);Z=ww@np.exp(lp);p=ww*np.exp(lp)/Z
 return dict(L=L,n=n,logZ=float(np.log(Z)),prior_tail_mass_bound=float(4*ndtr(-L)),mean=p@x,second=np.einsum('n,ni,nj->ij',p,x,x),entropy=float(-p@(lp-np.log(Z))))
def prepare_reference():
 rows=[quadrature(8,160),quadrature(10,256),quadrature(10,384)];last=rows[-1];delta=max(abs(r['logZ']-last['logZ']) for r in rows[-2:]);assert delta<1e-9,(delta,rows)
 tail=last['prior_tail_mass_bound']/np.exp(last['logZ']);write(ROOT/'reference/quadrature.json',dict(**last,refinements=rows,refinement_logZ_delta=delta,relative_tail_mass_bound=tail,scope='converged deterministic quadrature, not a formal quadrature-error bound',normalization='normalized standard Gaussian prior, omitted Gaussian observation constant'))
 return last
if __name__=='__main__':prepare_reference()
