"""The unchanged S2 tanh inverse problem from the previous LS6 campaign."""
import numpy as np
LOG2PI=np.log(2*np.pi)
class TanhIP:
 d=2
 def __init__(self):
  self.a=np.array([[1.2,.5],[-.5,1.]]);self.c=np.array([.2,-.1]);self.sigma=.25;self.yobs=np.tanh(self.a@np.array([.7,-.5])+self.c)+.25*np.array([.11,-.07]);self.candidates=0
 def parts(self,x):
  T=np.tanh(x@self.a.T+self.c);r=T-self.yobs;D=1-T*T;return T,r,D
 def phi(self,x):return .5*np.sum(self.parts(x)[1]**2,axis=1)/self.sigma**2
 def logp(self,x):return -.5*np.sum(x*x,axis=1)-LOG2PI-self.phi(x)
 def score(self,x):
  T,r,D=self.parts(x);return -x-(r*D)@self.a/self.sigma**2
 def bank(self,x):
  T,r,D=self.parts(x);s=-x-(r*D)@self.a/self.sigma**2;P=np.eye(2)+np.einsum('qk,ki,kj->qij',D*D/self.sigma**2,self.a,self.a);return s,P
 def exact_hessian(self,x):
  T,r,D=self.parts(x);return np.eye(2)+np.einsum('qk,ki,kj->qij',(D*D-2*r*T*D)/self.sigma**2,self.a,self.a)
 def sample(self,n,rng):
  out=[];count=0
  while count<n:
   m=max(128,min(20000,10*(n-count)));x=rng.normal(size=(m,2));keep=np.log(rng.random(m))<=-self.phi(x);a=x[keep];out.append(a);count+=len(a);self.candidates+=m
  return np.concatenate(out)[:n]
