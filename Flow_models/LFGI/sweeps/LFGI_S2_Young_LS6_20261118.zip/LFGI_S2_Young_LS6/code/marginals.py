"""Generate Young-only Tanh appendix data on the paper's archived display grid."""
import argparse
import pickle

import numpy as np
from scipy.special import logsumexp

from campaign import paths, target
from common import ROOT, arrays_sha, read, rng, save, sha, write

METHOD = "young"
DISPLAY_STREAM = 8  # Same terminal normals as the archived LFGI display.
COMPARATORS = {"lfgi": "LFGI-GN", "gmm_bic": "Selected GMM", "fitted_flow": "Fitted flow"}


def target_mass(bins, log_z):
    """The same two-by-two Gauss–Legendre rule as the manuscript."""
    x, y = np.meshgrid(*[(axis[:-1] + axis[1:]) / 2 for axis in bins], indexing="ij")
    dx, dy = [np.diff(axis)[0] for axis in bins]
    masses = np.zeros_like(x)
    density = target()
    for sx in (-1, 1):
        for sy in (-1, 1):
            points = np.c_[(x + sx * dx / (2 * np.sqrt(3))).ravel(),
                           (y + sy * dy / (2 * np.sqrt(3))).ravel()]
            masses += np.exp(density.logp(points) - log_z).reshape(x.shape) * (dx * dy / 4)
    return masses


def save_histogram(file, mass, bins):
    area = np.diff(bins[0])[0] * np.diff(bins[1])[0]
    save(file, hist=mass / area, probability_mass=mass, bins0=bins[0], bins1=bins[1],
         window_mass=mass.sum())


def weight_diagnostics(log_weights, per_component):
    normalizer = logsumexp(log_weights)
    count = len(log_weights)
    components = count // per_component
    weights = np.exp(log_weights)
    strata = weights.reshape(components, per_component)
    mcse = np.sqrt(np.var(strata, axis=1, ddof=1).sum() / per_component) / components
    effective_sample_size = np.exp(2 * normalizer - logsumexp(2 * log_weights))
    if not np.isfinite(weights).all() or not np.isfinite(mcse) or not np.isfinite(effective_sample_size):
        raise ArithmeticError("Nonfinite weights or mass diagnostics in display density integration")
    return weights, dict(mass_estimate=weights.mean(), mass_MCSE=mcse,
                         ESS_diagnostic=effective_sample_size, max_weight=weights.max())


def actual_draws(model, out, n, count, binding):
    file = out / f"actual_N{n}_{METHOD}.npz"
    if file.exists():
        with np.load(file, allow_pickle=False) as data:
            if int(data["count"]) != count or str(data["binding"]) != binding:
                raise RuntimeError(f"Display-particle cache identity mismatch at N={n}")
            return data["x"], data["logq"]
    points, log_q = model.sample_logq(count, rng(n, DISPLAY_STREAM, 902), "display_draws")
    save(file, x=points, logq=log_q, count=np.array(count), binding=np.array(binding))
    return points, log_q


def evaluate_size(config, label, n, archived, bins, out, small):
    cell = paths(dict(seed=config["display_seed"], N=n, method=METHOD), label)
    status_file = cell / "status.json"
    if not status_file.exists():
        raise RuntimeError(f"Young fit status missing for N={n}")
    status = read(status_file)
    if status["status"] != "COMPLETE":
        raise RuntimeError(f"Young fit for N={n} is {status['status']}")
    fit = read(cell / "fit.json")
    if fit["binding"] != status["binding"] or sha(cell / "model.pkl") != fit["pickle_sha256"]:
        raise RuntimeError(f"Young fit/cache identity mismatch at N={n}")
    with (cell / "model.pkl").open("rb") as serialized:
        model = pickle.load(serialized)
    model.cache = cell / ("marginal_smoke_checkpoints" if small else "marginal_checkpoints")

    prefix = f"N{n}_"
    per = int(archived[prefix + "per_component"])
    strata = archived[prefix + "stratum_names"].tolist()
    take = 8 if small else per
    rows = np.concatenate([np.arange(j * per, j * per + take) for j in range(len(strata))])
    points = archived[prefix + "points"][rows]
    log_r = archived[prefix + "log_r"][rows]
    digest = arrays_sha(points, log_r)
    count = 32 if small else config["histogram_n"]
    display_points, generation_log_q = actual_draws(model, out, n, count, status["binding"])
    if display_points.shape != (count, 2) or generation_log_q.shape != (count,):
        raise RuntimeError(f"Malformed Young display-particle cache for N={n}")
    check_count = take
    check_log_q = model.logq(display_points[:check_count], tag="display_roundtrip")
    roundtrip_error = float(np.max(np.abs(check_log_q - generation_log_q[:check_count])))
    if not np.isfinite(roundtrip_error) or roundtrip_error > config["roundtrip_tolerance"]:
        raise ArithmeticError(f"Young display density/generation discrepancy at N={n}: {roundtrip_error}")

    cache = out / f"cubature_N{n}_{METHOD}.npz"
    binding = sha(status_file) + digest
    if cache.exists():
        with np.load(cache, allow_pickle=False) as data:
            if str(data["binding"]) != binding or data["logq"].shape != (len(points),):
                raise RuntimeError(f"Display-cubature cache identity mismatch at N={n}")
            log_q = data["logq"]
    else:
        log_q = model.logq(points, tag="archived_mixture_cubature")
        save(cache, x=points, logq=log_q, log_r=log_r, binding=np.array(binding),
             archived_row_ids=archived[prefix + "archived_row_ids"][rows])
    weights, stats = weight_diagnostics(log_q - log_r, take)
    actual = np.histogram2d(*display_points.T, bins=bins)[0] / count
    implicit = np.histogram2d(*points.T, bins=bins, weights=weights)[0] / len(points)
    save_histogram(out / f"actual_hist_N{n}_{METHOD}.npz", actual, bins)
    save_histogram(out / f"implicit_hist_N{n}_{METHOD}.npz", implicit, bins)

    context_actual, context_implicit = {}, {}
    for j, name in enumerate(archived["model_names"].tolist()):
        context_actual[name] = archived[prefix + "actual_mass"][j]
        weights_j = np.exp(archived[prefix + "comparator_logq"][j, rows] - log_r)
        context_implicit[name] = np.histogram2d(*points.T, bins=bins, weights=weights_j)[0] / len(points)
    context_actual[METHOD] = actual
    context_implicit[METHOD] = implicit
    stats["normalized_model_bound"] = None
    summary = dict(status="complete", models=[METHOD], display_draws=count, cubature_count=len(points),
                   per_component=take, strata=strata, proposal_digest=digest,
                   weights={METHOD: stats}, generation_density_max_errors={METHOD: roundtrip_error},
                   actual_window_mass=float(actual.sum()), implicit_window_mass=float(implicit.sum()),
                   proposal="equal mixture of the three retained archived comparison densities",
                   note="Raw q/r weights. Young is outside the proposal mixture and has no component-weight bound.")
    return context_actual, context_implicit, summary


def plot(out, bins, densities, target_bins, kind):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import LogNorm

    titles = ["Target\n(quadrature)", *COMPARATORS.values(), "Young et al.\n(time-only matrix)"]
    norm = LogNorm(vmin=1e-4, vmax=2e-2)
    cmap = plt.get_cmap("magma_r").copy()
    cmap.set_bad("white")
    fig, axes = plt.subplots(len(densities), 5, figsize=(10.4, 2.35 * len(densities)),
                             squeeze=False, layout="constrained")
    for row, (n, data) in enumerate(densities.items()):
        panels = [target_bins, *[data[method] for method in COMPARATORS], data[METHOD]]
        for col, (axis, mass) in enumerate(zip(axes[row], panels)):
            im = axis.pcolormesh(*bins, np.ma.masked_where(mass.T == 0, mass.T), norm=norm,
                                 cmap=cmap, shading="auto", rasterized=True)
            axis.set_xticks([.5, 1.5, 2.5])
            axis.set_yticks([-2, -1, 0])
            if row == 0:
                axis.set_title(titles[col], fontsize=9.2)
            if row == len(densities) - 1:
                axis.set_xlabel("$x_1$")
            else:
                axis.tick_params(labelbottom=False)
            if col == 0:
                axis.set_ylabel(f"$N={n}$\n$x_2$")
            else:
                axis.tick_params(labelleft=False)
    colorbar = fig.colorbar(im, ax=axes, pad=.02, ticks=[1e-4, 1e-3, 1e-2])
    colorbar.set_label("Probability per bin")
    name = out / f"S2_young_{kind}"
    fig.savefig(name.with_suffix(".pdf"), dpi=300)
    fig.savefig(name.with_suffix(".png"), dpi=300)
    plt.close(fig)


def run(label="production", small=False):
    out = ROOT / "reports" / label
    if small:
        out /= "display_smoke"
    out.mkdir(parents=True, exist_ok=True)
    summary_file = out / "histogram_integration.json"
    if label != "production":
        write(summary_file, dict(status="skipped", reason="Appendix uses the production banks at N=50 and 450"))
        return

    config = read(ROOT / "configs/campaign.json")
    reference = ROOT / "data/display_reference.npz"
    actual, implicit, summary = {}, {}, {}
    with np.load(reference, allow_pickle=False) as archived:
        if int(archived["seed"]) != config["display_seed"]:
            raise RuntimeError("Archived display seed differs from the campaign configuration")
        bins = [archived["bins0"], archived["bins1"]]
        target_bins = target_mass(bins, read(ROOT / "reference/quadrature.json")["logZ"])
        save_histogram(out / "target_hist.npz", target_bins, bins)
        for n in config["display_N"]:
            try:
                draws, integrals, summary[str(n)] = evaluate_size(config, label, n, archived, bins, out, small)
            except (ArithmeticError, FileNotFoundError, RuntimeError) as error:
                summary[str(n)] = dict(status="incomplete", reason=str(error))
                continue
            actual[n] = draws
            implicit[n] = integrals
    write(summary_file, dict(seed=config["display_seed"], sizes=summary, archive_sha256=sha(reference),
                             smoke=small, target_window_mass=target_bins.sum(), target_bin_quadrature="2x2 Gauss–Legendre"))
    if actual:
        plot(out, bins, actual, target_bins, "actual")
        plot(out, bins, implicit, target_bins, "implicit")
    if len(actual) != len(config["display_N"]):
        raise RuntimeError(f"Some Tanh appendix outputs are incomplete. See {summary_file}.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--label", default="production")
    parser.add_argument("--small", action="store_true", help="Exercise the display pipeline on reduced arrays")
    args = parser.parse_args()
    run(args.label, args.small)
