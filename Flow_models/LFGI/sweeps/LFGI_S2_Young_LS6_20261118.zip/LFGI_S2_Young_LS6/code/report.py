"""Summarize Young's results using the manuscript's whole-bank bootstrap."""
import argparse
import csv
from collections import defaultdict

import numpy as np

from campaign import paths
from common import ROOT, read, write


LABELS = {'young': 'Young time-only matrix', 'lfgi': 'LFGI-GN (archived)'}
NBOOT = 6000
BANK_METRICS = ['logdensity_RMSE', 'logratio_SD', 'mean_logq_p', 'ELBO',
                'forward_KL', 'reverse_KL', 'ESS', 'bridge_overlap', 'logZ', 'entropy_q']
TABLE_METRICS = ['logdensity_RMSE', 'forward_KL', 'reverse_KL', 'bridge_RMSE', 'ESS']
PAIRED_NAMES = ['logdensity_RMSE', 'bridge_RMSE', 'forward_KL', 'reverse_KL']
METRIC_TITLES = {
    'logdensity_RMSE': 'Held-out log-density RMSE',
    'forward_KL': 'Forward KL',
    'reverse_KL': 'Reverse KL',
    'bridge_RMSE': 'Bridge log-evidence RMSE',
    'ESS': 'Importance ESS fraction',
}


def write_csv(path, columns, rows):
    with path.open('w') as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def bootstrap(n, seed=20261116):
    return np.random.default_rng(seed).integers(0, n, (NBOOT, n))


def group_by_seed(rows, n):
    groups = defaultdict(list)
    for row in rows:
        if int(row['N']) == n:
            groups[int(row['seed'])].append(row)
    return dict(sorted(groups.items()))


def group_values(groups, name):
    if name == 'bridge_RMSE':
        return [np.mean([float(r['bridge_logZ_error'])**2 for r in rows]) for rows in groups.values()]
    if name == 'bridge_bias':
        return [np.mean([float(r['bridge_logZ_error']) for r in rows]) for rows in groups.values()]
    if name == 'bridge_repeat_SD':
        return [np.std([float(r['logZ']) for r in rows], ddof=1) for rows in groups.values()]
    if name == 'ESS':
        return [np.mean([float(r['ESS'])/float(r.get('proposal_count') or 512) for r in rows])
                for rows in groups.values()]
    return [np.mean([float(r[name]) for r in rows]) for rows in groups.values()]


def statistics(rows, method, config):
    output = []
    for n in config['bank_sizes']:
        groups = group_by_seed(rows, n)
        if not groups:
            continue
        m = len(groups)
        idx = bootstrap(m, 20261116 if m == len(config['bank_seeds']) else 88)
        for name in BANK_METRICS + ['bridge_RMSE', 'bridge_bias', 'bridge_repeat_SD']:
            if name == 'bridge_repeat_SD' and any(len(r) == 1 for r in groups.values()):
                continue
            x = np.asarray(group_values(groups, name))
            point = x.mean()
            samples = x[idx].mean(-1)
            if name == 'bridge_RMSE':
                point, samples = np.sqrt(point), np.sqrt(samples)
            low, high = np.quantile(samples, [.025, .975]) if m > 1 else (None, None)
            se = samples.std(ddof=1) if m > 1 else None
            output.append(dict(target='s2', N=n, method=method, metric=name, value=point,
                               low=low, high=high, groups=m, se=se))
    return output


def paired(young, archive, config):
    output = []
    for n in config['bank_sizes']:
        a, b = group_by_seed(archive, n), group_by_seed(young, n)
        seeds = sorted(a.keys() & b.keys())
        if not seeds:
            continue
        idx = bootstrap(len(seeds))
        a, b = ({s: g[s] for s in seeds} for g in [a, b])
        for key in PAIRED_NAMES:
            x, y = [np.asarray(group_values(g, key)) for g in [a,b]]
            points = x.mean(), y.mean()
            means = x[idx].mean(-1), y[idx].mean(-1)
            if key == 'bridge_RMSE':
                points, means = np.sqrt(points), np.sqrt(means)
            draws = means[0] - means[1]
            low, high = np.quantile(draws, [.025,.975]) if len(seeds) > 1 else (None,None)
            output.append(dict(N=n, comparator='young', metric=key+'_difference',
                               estimate=points[0]-points[1], low=low, high=high, groups=len(seeds),
                               se=draws.std(ddof=1) if len(seeds) > 1 else None))
    return output


def comparison_plot(out, stats, archive):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 3, figsize=(10, 3.35), layout='constrained')
    for method, rows, color in [('lfgi', archive, '#1d5a97'), ('young', stats, '#ac411e')]:
        for axis, key in zip(axes, ['logdensity_RMSE', 'bridge_RMSE', 'ESS']):
            found = [x for x in rows if x['metric'] == key]
            if not found:
                continue
            n = [x['N'] for x in found]
            axis.plot(n, [x['value'] for x in found], 'o-', label=LABELS[method], color=color)
            if all(x['low'] is not None for x in found):
                axis.fill_between(n, [x['low'] for x in found], [x['high'] for x in found],
                                  alpha=.16, color=color)
    for axis, key in zip(axes, ['logdensity_RMSE', 'bridge_RMSE', 'ESS']):
        axis.set(xlabel='Bank size', title=METRIC_TITLES[key])
    axes[0].set_yscale('log')
    axes[1].set_yscale('log')
    axes[2].set_ylim(0, 1.01)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='outside lower center', ncol=2, frameon=False)
    fig.savefig(out/'comparison.pdf')
    fig.savefig(out/'comparison.png', dpi=240)
    plt.close(fig)


def repeat_row(cell, status, r):
    return dict(
        **cell, repeat=r['repeat'], status='COMPLETE', space=r['space'],
        logratio_SD=r['logratio_SD'], mean_logq_p=r['mean_logq_p'], ELBO=r['ELBO'],
        entropy_q=r['entropy_q'], forward_KL=r['forward_KL'], reverse_KL=r['reverse_KL'],
        logdensity_RMSE=r['logdensity_RMSE'], bridge_logZ_error=r['bridge_logZ_error'],
        new_E=r['new_E'], new_G=r['new_G'], new_H=r['new_H'], logZ=r['bridge']['logZ'],
        bridge_overlap=r['bridge']['overlap'], ESS=r['bridge']['IS_ESS'],
        posterior_E_once=status['posterior_E'] if r['repeat']==0 else 0,
        required_G=status['shared_cache_access']['G'], required_H=status['shared_cache_access']['H'],
        roundtrip=status['roundtrip_logq_max_error'], fit_seconds=status['fit_seconds'],
        evaluation_seconds=r['seconds'], cell_seconds=status['evaluation_seconds'],
        roundtrip_logq_max_error=status['roundtrip_logq_max_error'],
        proposal_count=r['proposal_count'], posterior_count=r['posterior_count'],
    )


def report(label):
    config = read(ROOT/'configs/campaign.json')
    truth = read(ROOT/'reference/quadrature.json')
    expected = read(ROOT/'prepared/cells.json')
    if label == 'pilot':
        expected = [c for c in expected if c['seed'] == config['pilot_seed'] and c['N'] == config['pilot_N']]
    rows, statuses = [], []
    for cell in expected:
        path = paths(cell, label)/'status.json'
        s = read(path) if path.is_file() else dict(status='MISSING')
        statuses.append(dict(**cell, status=s['status'], error=s.get('error')))
        if s['status'] == 'COMPLETE':
            if label == 'production':
                assert len(s['records']) == config['proposal_repeats']
                assert all(r['proposal_count'] == config['proposal_n'] and
                           r['posterior_count'] == config['posterior_n'] for r in s['records'])
            rows.extend(repeat_row(cell, s, r) for r in s['records'])

    out = ROOT/'reports'/label
    out.mkdir(exist_ok=True, parents=True)
    write(out/'status.json', dict(expected=len(expected), complete=sum(s['status']=='COMPLETE' for s in statuses),
                                  failed=sum(s['status']=='FAILED' for s in statuses),
                                  cells=statuses, reference_logZ=truth['logZ']))
    with (ROOT/'data/archived_lfgi_per_repeat.csv').open() as f:
        archive = list(csv.DictReader(f))
        archived_columns = tuple(archive[0])
    write_csv(out/'per_repeat.csv', archived_columns+('proposal_count','posterior_count'), rows)
    stats = statistics(rows, 'young', config)
    archive_stats = statistics(archive, 'lfgi', config) if label == 'production' else []
    differences = paired(rows, archive, config) if label == 'production' else []
    statistic_columns = ('target','N','method','metric','value','low','high','groups','se')
    write(out/'summary.json', stats)
    write_csv(out/'figure_statistics.csv', statistic_columns, stats)
    write_csv(out/'largest_bank_summary.csv', statistic_columns,
              [r for r in stats if r['N']==max(config['bank_sizes']) and r['metric'] in TABLE_METRICS+['bridge_bias']])
    write_csv(out/'paired_lfgi_differences.csv', ('N','comparator','metric','estimate','low','high','groups','se'),
              differences)
    lines = ['# Tanh Young-only gate campaign', '',
             f"Quadrature log evidence {truth['logZ']:.12f}.", '',
             'Table entries give the estimate ± whole-bank bootstrap standard error where available. '
             'Uncertainty uses the independent reference groups, with proposal repeats nested in each group. '
             'Paired differences in the CSV are archived LFGI-GN minus Young.', '',
             '| Bank size | Groups | Log-density RMSE | Forward KL | Reverse KL | Bridge RMSE | Importance ESS fraction |',
             '|---:|---:|---:|---:|---:|---:|---:|']
    for n in config['bank_sizes']:
        group = {r['metric']: r for r in stats if r['N']==n}
        if group:
            vals = [group[key] for key in TABLE_METRICS]
            cells = [f"{r['value']:.5g}" + (f" ± {r['se']:.2g}" if r['se'] is not None else '') for r in vals]
            lines.append(f"| {n} | {vals[0]['groups']} | " + ' | '.join(cells) + ' |')
    if not rows:
        lines.extend(['', 'No complete cells.'])
    lines.extend(['', 'See status.json for missing or failed cells.', ''])
    (out/'REPORT.md').write_text('\n'.join(lines))
    if rows:
        comparison_plot(out, stats, archive_stats)
    print(f'Tanh report finished with {len(rows)} accepted Young proposal batches')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', default='production')
    report(parser.parse_args().label)
