"""Young et al.'s full-matrix, spatially homogeneous OU score gate."""
from dataclasses import dataclass

import numpy as np
from scipy.special import logsumexp


@dataclass
class Bank:
    x: np.ndarray
    s: np.ndarray

    def __post_init__(self):
        self.x = np.asarray(self.x, dtype=float)
        self.s = np.asarray(self.s, dtype=float)
        self.fisher = self.s.T @ self.s / len(self.s)
        self.eigenvalues, self.eigenvectors = np.linalg.eigh(self.fisher)
        # Roundoff can give a tiny negative eigenvalue for a rank-deficient Gram matrix.
        self.eigenvalues = np.maximum(self.eigenvalues, 0)
        self.residual = self.s + self.x @ self.fisher.T


class Field:
    def __init__(self, bank):
        self.bank = bank
        self.calls = 0

    def __call__(self, y, t):
        x, residual = self.bank.x, self.bank.residual
        alpha = np.exp(-t)
        alpha_squared = alpha**2
        gamma = -np.expm1(-2*t)
        self.calls += len(y)
        delta = y[:, None, :] - alpha*x
        logw = -np.sum(delta**2, axis=2) / (2*gamma)
        weights = np.exp(logw - logsumexp(logw, axis=1, keepdims=True))

        # Center covariance calculations on the dominant particle first.
        # This preserves small differences when normalized weights nearly collapse.
        anchor = np.argmax(weights, axis=1)
        residual_offset = residual[None] - residual[anchor, None]
        mean_offset = np.einsum('qn,qni->qi', weights, residual_offset)
        mean_residual = residual[anchor] + mean_offset
        position_offset = x[None] - x[anchor, None]
        mean_position_offset = np.einsum('qn,qni->qi', weights, position_offset)
        cov = np.einsum(
            'qn,qni,qnj->qij', weights, residual_offset - mean_offset[:, None],
            position_offset - mean_position_offset[:, None],
        )

        # For G = alpha^2 (alpha^2 I + gamma F)^-1, expand
        # b + G(c-b) in terms of residual = s + F x to avoid 1/gamma cancellation.
        eigenvalues, eigenvectors = self.bank.eigenvalues, self.bank.eigenvectors
        inverse_shift = (eigenvectors / (alpha_squared + gamma*eigenvalues)) @ eigenvectors.T
        score = (alpha*mean_residual - y @ self.bank.fisher.T) @ inverse_shift.T
        jacobian = inverse_shift @ (alpha_squared/gamma*cov - self.bank.fisher)
        return dict(score=score, J=jacobian, div=np.trace(jacobian, axis1=1, axis2=2))
