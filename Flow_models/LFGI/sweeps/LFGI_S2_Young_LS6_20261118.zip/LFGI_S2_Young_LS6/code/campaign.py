"""One new Tanh proposal per archived seed and bank size."""
import os
for key in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    os.environ[key] = '1'

import argparse
import fcntl
import hashlib
import json
import pickle
import platform
import time
import traceback
import numpy as np

from common import ROOT, arrays_sha, bridge, read, rng, save, sha, source_sha, write
from fields import Bank
from flows import PFModel
from target import TanhIP

METHODS = ['young']
# Common terminal Gaussian random numbers with the archived small-endpoint LFGI run.
LFGI_RNG_KEY = 8


def target():
    return TanhIP()


def prepare():
    from reference import prepare_reference

    config = read(ROOT/'configs/campaign.json')
    prepare_reference()
    acquisition = []
    for seed in config['bank_seeds']:
        model = target()
        x = model.sample(max(config['bank_sizes']), np.random.default_rng(seed))
        bank_energy = model.candidates
        post = model.sample(config['posterior_n'], np.random.default_rng(seed + 200000))
        save(ROOT/f'prepared/seed{seed}.npz', x=x, s=model.score(x), ids=np.arange(len(x)))
        save(ROOT/f'prepared/posterior_seed{seed}.npz', x=post, ids=np.arange(len(post)), logp=model.logp(post))
        acquisition.append(dict(
            seed=seed, bank_rejection_E=bank_energy, posterior_rejection_E=model.candidates-bank_energy,
            bank_EG_H=dict(E=0, G=len(x), H=0), posterior_energy_E=len(post),
            scope='Independent exact-rejection groups with nested reference prefixes',
        ))
    write(ROOT/'prepared/acquisition.json', dict(
        groups=acquisition, reference_quadrature='Separate deterministic evaluation',
    ))
    write(ROOT/'prepared/cells.json', [
        dict(seed=seed, N=n, method='young')
        for seed in config['bank_seeds'] for n in config['bank_sizes']
    ])


def environment():
    import scipy
    return dict(
        python=platform.python_version(), numpy=np.__version__,
        scipy=scipy.__version__, machine=platform.machine(),
    )


def identity(spec, inp, post):
    return hashlib.sha256((
        source_sha() + sha(ROOT/'configs/campaign.json') + sha(ROOT/'data/model_spec.json')
        + sha(ROOT/'reference/quadrature.json') + json.dumps(environment(), sort_keys=True)
        + json.dumps(spec, sort_keys=True) + arrays_sha(inp['x'], inp['s'], inp['ids'], post['x'], post['logp'])
    ).encode()).hexdigest()


def paths(cell, label):
    return ROOT/'results'/label/f"seed{cell['seed']}"/f"N{cell['N']}"/cell['method']


def fit(cell, inp, config, dest, binding):
    model = target()
    max_curvature = 1 + np.linalg.norm(model.a, 2)**2 / model.sigma**2
    tau = min(config['tau_cap'], float(.5*np.log1p(.01/max_curvature)))
    solver = dict(tau=tau, T=config['T'], rtol=config['rtol'], atol=config['atol'], chunk=config['chunk'])
    bank = Bank(inp['x'], inp['s'])
    proposal = PFModel(bank, cell['method'], solver, dest/'checkpoints', binding)
    info = dict(
        bank_ids=inp['ids'].tolist(), tau=tau, solver=solver, available_cache_rows=len(bank.x),
        new_fitting_E=0, new_fitting_G=0, new_fitting_H=0, factorization=False,
        tau_rule='Original S2 cap and model-known global curvature bound',
        fisher=bank.fisher, fisher_eigenvalues=bank.eigenvalues, fit_uses_clean_scores=True,
        gate='Young et al. Proposition 3, standard Gaussian OU base, one pooled score moment per bank',
    )
    return proposal, info


def statistics(lp, lq, lpq, lqq, logz, entropy):
    b = bridge(lp, lq, lpq, lqq)
    if not b['success']:
        raise ArithmeticError('bridge failure: ' + str(b))
    weights = lpq - lqq
    logratio = lp - lq
    elbo = float(weights.mean())
    return dict(
        bridge=b, space='original', posterior_count=len(lp), proposal_count=len(lpq),
        logratio_SD=float(logratio.std(ddof=1)), mean_logq_p=float(lq.mean()),
        ELBO=elbo, ELBO_MCSE=float(weights.std(ddof=1)/np.sqrt(len(lpq))),
        entropy_q=float(-lqq.mean()), forward_KL=float(logratio.mean()-logz),
        reverse_KL=float(logz-elbo), logdensity_RMSE=float(np.sqrt(np.mean((lq-lp+logz)**2))),
        target_entropy=entropy, bridge_logZ_error=b['logZ']-logz,
    )


def run_cell(cell, label='production', count=None, repeats=None, retry=False):
    config = read(ROOT/'configs/campaign.json')
    n = cell['N']
    seed = cell['seed']
    if cell['method'] not in METHODS or seed not in config['bank_seeds'] or n not in config['bank_sizes']:
        raise ValueError(f'Cell outside the Young-only campaign: {cell}')
    n_posterior = config['posterior_n'] if count is None else count
    n_proposal = config['proposal_n'] if count is None else count
    n_repeats = config['proposal_repeats'] if repeats is None else repeats
    if not 2 <= n_posterior <= config['posterior_n'] or not 2 <= n_proposal or n_repeats < 1:
        raise ValueError('At least two states and one proposal batch are required')

    with np.load(ROOT/f'prepared/seed{seed}.npz') as base:
        inp = {key: base[key][:n] for key in ['x', 's', 'ids']}
    with np.load(ROOT/f'prepared/posterior_seed{seed}.npz') as base:
        posterior = {key: base[key][:n_posterior] for key in ['x', 'logp']}
    full = dict(cell=cell, label=label, posterior_count=n_posterior, proposal_count=n_proposal, repeats=n_repeats)
    binding = identity(full, inp, posterior)
    dest = paths(cell, label)
    dest.mkdir(parents=True, exist_ok=True)
    with (dest/'LOCK').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return evaluate_cell(cell, dest, config, inp, posterior, full, binding, retry)


def evaluate_cell(cell, dest, config, inp, posterior, spec, binding, retry):
    status = dest/'status.json'
    if status.exists():
        old = read(status)
        if old.get('binding') != binding:
            raise RuntimeError('Cell identity mismatch; use a new campaign directory: '+str(dest))
        if old['status'] == 'COMPLETE':
            return old
        if old['status'] == 'FAILED' and not retry:
            raise RuntimeError('Retained failed cell; diagnose and use explicit --retry-failed: '+str(dest))
        write(dest/'attempts'/f'previous_{time.time_ns()}.json', old)

    tick = time.time()
    write(status, dict(status='RUNNING', binding=binding, cell=cell, started=tick))
    try:
        fitfile, meta = dest/'model.pkl', dest/'fit.json'
        if fitfile.exists() and meta.exists():
            ft = read(meta)
            assert ft['binding'] == binding and ft['pickle_sha256'] == sha(fitfile)
            with fitfile.open('rb') as f:
                proposal = pickle.load(f)
            proposal.cache = dest/'checkpoints'
            info, fit_seconds = ft['info'], ft['seconds']
        else:
            begin = time.time()
            proposal, info = fit(cell, inp, config, dest, binding)
            fit_seconds = time.time() - begin
            tmp = dest/'model.pkl.tmp'
            with tmp.open('wb') as f:
                pickle.dump(proposal, f, protocol=4)
            os.replace(tmp, fitfile)
            write(meta, dict(binding=binding, pickle_sha256=sha(fitfile), info=info, seconds=fit_seconds))

        postfile = dest/'posterior_eval.npz'
        if postfile.exists():
            with np.load(postfile) as raw:
                assert str(raw['binding']) == binding
                lp, lq = raw['logp'], raw['logq']
        else:
            lp, lq = posterior['logp'], proposal.logq(posterior['x'])
            save(postfile, states=posterior['x'], logq=lq, logp=lp, E=0, binding=np.array(binding))

        truth = read(ROOT/'reference/quadrature.json')
        model = target()
        records = []
        for rep in range(spec['repeats']):
            json_file, rawfile = dest/f'repeat{rep:02d}.json', dest/f'repeat{rep:02d}.npz'
            if json_file.exists() and rawfile.exists():
                record = read(json_file)
                assert record['binding'] == binding
            else:
                start, field_start = time.time(), proposal.calls
                random = rng(cell['seed'], cell['N'], LFGI_RNG_KEY, rep, 4)
                x, lqq = proposal.sample_logq(spec['proposal_count'], random, f'proposal_repeat{rep}')
                lpq = model.logp(x)
                record = statistics(lp, lq, lpq, lqq, truth['logZ'], truth['entropy'])
                record.update(
                    binding=binding, repeat=rep, seconds=time.time()-start, new_E=len(x), new_G=0, new_H=0,
                    field_query_calls=proposal.calls-field_start,
                )
                save(rawfile, proposal=x, logq=lqq, logp=lpq, binding=np.array(binding))
                write(json_file, record)
            records.append(record)

        with np.load(dest/'repeat00.npz') as first:
            check = proposal.logq(first['proposal'][:config['roundtrip_n']], tag='independent_roundtrip')
            roundtrip = float(np.max(abs(check-first['logq'][:len(check)])))
        if not np.isfinite(roundtrip) or roundtrip > config['roundtrip_tolerance']:
            raise ArithmeticError('generation/evaluation log density mismatch: '+str(roundtrip))
        done = dict(
            roundtrip_logq_max_error=roundtrip, status='COMPLETE', binding=binding, cell=cell,
            fit_seconds=fit_seconds, evaluation_seconds=time.time()-tick, info=info, posterior_E=0,
            shared_cache_access=dict(E=0, G=cell['N'], H=0), records=records, environment=environment(),
            source_sha256=source_sha(), normalization_id='S2_normalized_prior_omitted_likelihood_constant_v1',
            reference='Independent exact-rejection groups with converged deterministic quadrature evidence',
        )
        write(status, done)
        return done
    except Exception as exc:
        write(status, dict(status='FAILED', binding=binding, cell=cell, error=str(exc), traceback=traceback.format_exc()))
        raise


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('action', choices=['prepare', 'cell'])
    p.add_argument('--seed', type=int)
    p.add_argument('--N', type=int)
    p.add_argument('--method', choices=METHODS, default='young')
    p.add_argument('--label', default='production')
    p.add_argument('--count', type=int)
    p.add_argument('--repeats', type=int)
    p.add_argument('--retry-failed', action='store_true')
    a = p.parse_args()
    if a.action == 'prepare':
        prepare()
    else:
        run_cell(dict(seed=a.seed, N=a.N, method=a.method), a.label, a.count, a.repeats, a.retry_failed)
