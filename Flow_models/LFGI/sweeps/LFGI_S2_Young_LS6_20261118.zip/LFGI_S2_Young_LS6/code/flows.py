"""Matched generation/density at the same endpoint, with resumable log-time DOP853."""
import hashlib,os
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
from scipy.integrate import solve_ivp
from common import save,arrays_sha
from fields import Field

def integrate(bank,x,method,backward,config,cache,identity):
 chunk=config['chunk'];tau=config['tau'];T=config['T']
 def one(first):
  xx=x[first:first+chunk];key=hashlib.sha256((identity+method+str((backward,config))+arrays_sha(xx)).encode()).hexdigest();p=Path(cache)/('chunk%06d.npz'%first);n=len(xx);y=xx.copy();L=np.zeros(n);start=0;cc=0
  if p.exists():
   z=np.load(p);assert str(z['binding'])==key,'checkpoint identity mismatch';y=z['y'];L=z['L'];start=int(z['step']);cc=int(z['calls'])
  f=Field(bank);ts=np.linspace(np.log(T if backward else tau),np.log(tau if backward else T),17)
  for step in range(start,16):
   def rhs(u,state):
    yy=state[:n*2].reshape(n,2);t=np.exp(u);out=f(yy,t);return np.r_[t*(-yy-out['score']).ravel(),t*(-2-out['div'])]
   z=solve_ivp(rhs,ts[step:step+2],np.r_[y.ravel(),L],method='DOP853',rtol=config['rtol'],atol=config['atol'])
   if not z.success:raise ArithmeticError(z.message)
   y=z.y[:n*2,-1].reshape(n,2);L=z.y[n*2:,-1]
   if not np.isfinite(y).all() or not np.isfinite(L).all() or np.abs(y).max()>1e8:raise ArithmeticError('nonfinite/escaped flow')
   save(p,y=y,L=L,step=step+1,calls=cc+f.calls,binding=np.array(key))
  return y,L,cc+f.calls
 starts=list(range(0,len(x),chunk));workers=min(int(os.getenv('S2_CHUNK_WORKERS','1')),len(starts))
 if workers<1:raise ValueError('S2_CHUNK_WORKERS must be positive')
 if workers==1:out=[one(i) for i in starts]
 else:
  with ThreadPoolExecutor(max_workers=workers) as pool:out=list(pool.map(one,starts))
 return np.concatenate([a[0] for a in out]),np.concatenate([a[1] for a in out]),sum(a[2] for a in out)
class PFModel:
 def __init__(self,bank,method,config,cache,identity):self.bank=bank;self.method=method;self.config=config;self.cache=Path(cache);self.identity=identity;self.calls=0
 def logq(self,x,tag='posterior'):
  z,L,cc=integrate(self.bank,x,self.method,False,self.config,self.cache/tag,self.identity);self.calls+=cc;return -.5*(z*z).sum(1)-np.log(2*np.pi)+L
 def sample_logq(self,n,random,tag):
  z=random.normal(size=(n,2));q,L,cc=integrate(self.bank,z,self.method,True,self.config,self.cache/tag,self.identity);self.calls+=cc;return q,-.5*(z*z).sum(1)-np.log(2*np.pi)-L
