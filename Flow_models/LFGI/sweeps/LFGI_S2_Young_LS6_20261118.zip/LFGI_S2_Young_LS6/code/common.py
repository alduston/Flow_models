import json,hashlib,os,tempfile
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(Path(p).read_text())
def convert(x):
 if isinstance(x,dict):return {k:convert(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [convert(v) for v in x]
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 return x
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp.'+str(os.getpid()));tmp.write_text(json.dumps(convert(x),indent=2,allow_nan=True));os.replace(tmp,p)
def save(p,**a):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp.'+str(os.getpid()))
 with tmp.open('wb') as f:np.savez_compressed(f,**a)
 os.replace(tmp,p)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def arrays_sha(*a):
 h=hashlib.sha256()
 for x in a:
  x=np.ascontiguousarray(x);h.update(str((x.shape,x.dtype.str)).encode());h.update(x.tobytes())
 return h.hexdigest()
def source_sha():return hashlib.sha256(''.join(p.name+sha(p) for p in sorted((ROOT/'code').glob('*')) if p.suffix in ['.py','.cpp']).encode()).hexdigest()
def rng(*keys):return np.random.default_rng(np.random.SeedSequence([20261116]+list(keys)))
def logmean(x):
 from scipy.special import logsumexp
 return float(logsumexp(x)-np.log(len(x)))
def bridge(lp_p,lq_p,lp_q,lq_q):
 from scipy.special import logsumexp
 from scipy.optimize import brentq
 rp=lp_p-lq_p;rq=lp_q-lq_q
 if not np.isfinite(rp).all() or np.isnan(rq).any() or np.isposinf(rq).any():return dict(success=False,reason='invalid density array')
 finite=rq[np.isfinite(rq)]
 if not len(finite):return dict(success=False,reason='no positive target support among proposals')
 sp=len(rp)/(len(rp)+len(rq));sq=1-sp
 def f(z):return logmean(rq-np.logaddexp(np.log(sp)+rq,np.log(sq)+z))-logmean(-np.logaddexp(np.log(sp)+rp,np.log(sq)+z))-z
 low=float(min(rp.min(),finite.min())-50);high=float(max(rp.max(),finite.max())+50)
 try:z=brentq(f,low,high,xtol=1e-10)
 except Exception as e:return dict(success=False,reason=str(e))
 return dict(success=True,logZ=float(z),residual=float(f(z)),overlap=float(np.exp(logmean(-np.logaddexp(np.log(sp),np.log(sq)+z-rq)))),IS_ESS=float(np.exp(2*logsumexp(rq)-logsumexp(2*rq))),zero_target_fraction=float(np.mean(np.isneginf(rq))),direct_IS_logZ=logmean(rq),reciprocal_logZ=-logmean(-rp))
