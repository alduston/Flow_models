"""Freeze the archived display data needed by the Young-only LS6 campaign."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import logsumexp

COMPARATORS = ("lfgi", "gmm_bic", "fitted_flow")


def load(path, key):
    with np.load(path, allow_pickle=False) as archive:
        return archive[key]


def main(archive, output):
    metadata = json.loads((archive / "histogram_integration.json").read_text())
    payload = {"seed": np.array(metadata["seed"])}
    common = [load(archive / "actual_hist_N450_lfgi.npz", key) for key in ("bins0", "bins1")]
    assert all(len(axis) == 41 for axis in common)
    area = np.diff(common[0])[0] * np.diff(common[1])[0]
    payload.update(bins0=common[0], bins1=common[1], model_names=np.array(COMPARATORS))

    for n in (50, 450):
        spec = metadata["sizes"][str(n)]
        names = spec["models"]
        per = spec["per_component"]
        assert len(names) * per == spec["cubature_count"]
        # The manuscript retains raw coordinates for the three displayed comparators.
        # Use their rows in the all-component logq arrays, recalculate the denominator,
        # and keep the original balanced 512 draws per stratum.
        rows = np.concatenate([np.arange(names.index(m) * per, (names.index(m) + 1) * per) for m in COMPARATORS])
        points = np.concatenate([load(archive / f"actual_N{n}_{m}.npz", "x")[:per] for m in COMPARATORS])
        all_logs = np.stack([load(archive / f"cubature_N{n}_{m}.npz", "logq") for m in COMPARATORS])
        assert all_logs.shape == (len(COMPARATORS), spec["cubature_count"])
        logs = all_logs[:, rows]
        assert points.shape == (1536, 2)
        log_r = logsumexp(logs, axis=0) - np.log(len(COMPARATORS))
        assert np.isfinite(points).all() and np.isfinite(log_r).all()
        actual_mass = []
        for j, m in enumerate(COMPARATORS):
            source = load(archive / f"actual_N{n}_{m}.npz", "x")
            with np.load(archive / f"actual_hist_N{n}_{m}.npz", allow_pickle=False) as actual:
                assert all(np.array_equal(actual[key], axis) for key, axis in zip(("bins0", "bins1"), common))
                mass = np.histogram2d(*source.T, bins=common)[0] / len(source)
                np.testing.assert_allclose(mass, actual["hist"] * area, atol=1e-12, rtol=0)
                actual_mass.append(mass)
            # The archived own-stratum density and generation agree under the native
            # round-trip tolerance. This verifies the slice in the retained rows.
            generation = load(archive / f"actual_N{n}_{m}.npz", "logq")[:per]
            np.testing.assert_allclose(logs[j, j * per:(j + 1) * per], generation, atol=1e-3, rtol=0)
        payload.update({
            f"N{n}_points": points,
            f"N{n}_log_r": log_r,
            f"N{n}_stratum_names": np.array(COMPARATORS),
            f"N{n}_archived_row_ids": rows,
            f"N{n}_comparator_logq": logs,
            f"N{n}_per_component": np.array(per),
            f"N{n}_actual_mass": np.stack(actual_mass),
        })
        print(f"{n}: reproduced the archived actual panels and verified {len(points)} corresponding cubature rows.")
    np.savez_compressed(output, **payload)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    main(args.archive, args.output)
