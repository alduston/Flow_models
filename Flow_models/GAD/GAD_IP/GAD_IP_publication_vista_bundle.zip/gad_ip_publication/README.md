# GAD inverse-problem publication run bundle

This bundle freezes the supplied screening models, GAD sampler and checkpoint MALA controller, then adds independent NUTS references, fixed-data sampler repeats, posterior-reference comparisons, publication figures and aggregation. It does not change the theory or tune the baseline.

## Run on Vista

```bash
unzip GAD_IP_publication_vista_bundle.zip
cd gad_ip_publication

# Only needed if reference extras are absent or the ArviZ API check fails.
# Uses the existing CUDA-capable hlsi environment and constrains its core packages.
bash install_reference_extras.sh

# Review the submission plan without submitting anything.
bash submit.sh --dry-run --batch ../batches/gad_ip_pub_plan --account YOUR_ALLOCATION

# Submit the actual frozen batch. Omit --account if your Slurm default is correct.
bash submit.sh --batch ../batches/gad_ip_pub_20261026 --account YOUR_ALLOCATION
```

Use a fresh batch path for the actual submission. Alternatively, submit a previously dry-run snapshot with `--resume-batch ../batches/gad_ip_pub_plan`. No computation is run on the login node by these submission commands. The first compute job checks actual CUDA operations in both JAX and PyTorch, ArviZ diagnostic calls, and NumPyro continuation before releasing any expensive job.

The default environment follows the supplied working Vista setup: `gcc/13.2.0`, `python3/3.11.8`, and `$SCRATCH/venvs/hlsi`. To use another existing environment:

```bash
export GP_VENV_DIR=/absolute/path/to/working/venv
# Optional module overrides:
export GP_GCC_MODULE=gcc/13.2.0
export GP_PYTHON_MODULE=python3/3.11.8
```

If you have already activated the correct environment, `export GP_SKIP_MODULES=1` preserves it in the jobs. Set `GP_PYTHON=/path/to/python` only if the submission controller should use another Python interpreter. The controller itself needs only the standard library. Do not replace the working JAX/PyTorch CUDA installs with a Colab CUDA13 setup. The notebook documents the screening environment, not a portable Vista installer.

The inherited default JAX memory fraction remains 0.20, as in the supplied workflow. `GP_JAX_MEM_FRACTION` can override that reservation if a large exact-Hessian preparation needs more memory; recorded GPU preflight details and job logs remain available for diagnosis.

ArviZ must provide the 0.x `from_dict(posterior=...)` API used by the supplied Darcy driver. The extras installer requests `arviz>=0.18,<1`; it constrains installed JAX, jaxlib, CUDA plugin packages, PyTorch, NumPy, SciPy, pandas and Matplotlib rather than upgrading them. An incompatible solver request fails instead of silently replacing those packages. No package installs happen inside submitted jobs. All package versions are recorded by preflight and the original screening runner.

## Exact experiment plan

| Problem key | Unknown | Particles and bank | GAD rounds | Sampler repeats | Shared NUTS reference |
| --- | --- | ---: | ---: | ---: | --- |
| `afwi` | Acoustic velocity | 300 | 4 | 10 | 4 x 5,000 retained draws |
| `allen_cahn` | Initial condition | 300 | 4 | 10 | 4 x 5,000 retained draws |
| `navier_stokes` | Initial vorticity | 300 | 4 | 10 | 4 x 5,000 retained draws |
| `helmholtz` | Scattering contrast | 1,500 | 4 | 10 | 4 x 5,000 retained draws |

Each synthetic problem stays at **data seed 42**. Independent sampler seeds are **42 through 51**. This estimates sampler variability on one posterior, exactly the fixed-data repeat pattern in the supplied Darcy frontier bundle. It does not estimate robustness across new truths, sensor selections or noise realizations. Model initialization is still the original seed-42 code. The adapter separates that from the original `seed+10000` transport and `seed+20000` MALA streams; it does not edit model or sampler files.

All four runs use 200 transport steps, the canonical OU interval `[10^-2.5, 10]`, a shared reference/gate bank equal to the particle count, the original GN curvature settings, and every other screening default. `settings.json` is the full specification. In particular, MALA remains `checkpoints`, `guarded`, 32 chains, thinning 1, requested dt `1e-4`, and budget multiplier 1. No independent warmup or optimization sweep is added to the comparison baseline.

| Particles | GAD cumulative work by round | MALA cumulative work by round | MALA warmup | Transitions per chain by round | Output draws / chain |
| ---: | --- | --- | ---: | --- | ---: |
| 300 | 900, 1800, 2700, 3600 | 896, 1792, 2688, 3584 | 3 | 13, 27, 41, 55 | 10 |
| 1500 | 4500, 9000, 13500, 18000 | 4480, 8960, 13440, 17984 | 22 | 69, 139, 209, 280 | 47 |

These are the canonical derivative-count work proxies: three per GN bank particle, two per MALA transition/chain plus initialization, including warmup. They are not FLOPs, actual linear-system right-hand sides or elapsed seconds. The existing runtime counters are preserved. A short-budget MALA chain can have high acceptance and still mix poorly; its diagnostics are retained without relabeling it as a converged reference. MALA tuning remains deferred as requested.

## What is submitted

The default DAG has **22 Slurm submissions representing 38 task slots**, producing 40 independently seeded algorithm runs:

1. One GPU preflight job.
2. For each problem, one model/derivative/MAP preparation job, a four-task NUTS chain array, a two-task repeat worker array, one reference-certification/summary job, and one reference-evaluation job.
3. One CPU aggregation process on an allocated GH node, after all branches terminate.

Each repeat worker executes five independent seeds sequentially. Every seed has its own directory, RNG streams, status and output clouds. This grouping keeps the default submission below Vista's documented 40 submitted-job limit and avoids one new job for every small seed run. It does not merge or average the repetitions during sampling. The usual limits still apply to any unrelated jobs already in your queue.

Preparation releases NUTS and comparison runs concurrently. Evaluation waits for that problem's certified reference and for both repeat workers to terminate. A failed repeat is recorded and the remaining seeds in its worker still run. Aggregation uses `afterany` so that a failed branch still produces a failure inventory and review ZIP. References are isolated by problem: one failed NUTS reference does not invalidate the other models' completed outputs.

Defaults: two concurrent chain tasks and two repeat workers **per problem**, and two reference-evaluation jobs at once. Change scheduler concurrency or wall time without changing the scientific configuration:

```bash
bash submit.sh --account YOUR_ALLOCATION \
  --max-parallel 1 --chain-parallel 1 --post-parallel 1 \
  --time chain=36:00:00 --time evaluate=08:00:00
```

GH jobs request one node and one task. The scripts do not pass Vista-unsupported memory/GPU flags or override the inherited environment with `--export`. Default wall limits are 20 minutes preflight, 4 hours preparation, 24 hours per chain, 4 hours per repeat worker, 4 hours reference certification/summary, 4 hours reference evaluation and 2 hours aggregation. These are reservations, not measured runtime estimates. Actual costs and timings will be available after the run.

## NUTS reference design and failure handling

The reference uses the **same discretized posterior** as the comparison run, not a finer PDE grid or a different sensor/noise model. “High fidelity” here means a longer, independently sampled posterior reference. Fingerprints bind the model source, realized basis, truth, observations, holdouts, observation geometry, noise scale and data seed. A mismatch fails rather than allowing a comparison between different posteriors.

The exact potential is `0.5 * ||alpha||^2 + 0.5 * ||F(alpha)-y||^2 / noise_std^2`. MAP starts use zero and independent prior draws, never generating truth or GAD/MALA output. The supplied Darcy routines perform four-start MAP optimization, select distinct candidate basins, regularize the exact MAP Hessian and construct a fixed invertible affine whitening map. The chains adapt dense mass matrices and use independent overdispersed starts, target acceptance 0.95, warmup tree depth 10 and production depth 12. Whitening changes coordinates, not the target potential; its constant Jacobian has no effect on the chain.

Per problem, the reference has 3,000 warmup and 5,000 retained draws per chain, four chains, and no thinning. Production saves atomic chunks of 250 draws together with full adaptation state and RNG state. Completed chunks resume without restarting or duplicating production draws; an interrupted incomplete warmup restarts warmup. Pickle checkpoints are trusted, locally generated state files and must not be replaced with files from untrusted sources. Resuming with different numerical package versions is refused.

Certification follows the Darcy thresholds on every latent coefficient plus potential energy, coefficient norm, four field-quadrant means and field RMS:

- Rank-normalized R-hat <= 1.01; bulk ESS >= 1000; tail ESS >= 400.
- Zero divergences; tree-depth saturation <= 1% in every chain.
- E-BFMI >= 0.30 and mean acceptance >= 0.80 in every chain.
- Finite draws and all required diagnostics.

Diagnostics are necessary evidence of mixing, not a proof that all possible modes were explored. Multi-start initialization and the trace/functional diagnostics make failures visible; a diagnostic pass is not mathematical ground truth. Unsuccessful checks write `reference_samples_uncertified.npz` and detailed diagnostics, but do **not** write a usable canonical reference or publication comparisons. There is no automatic override or silent reference substitution.

The NUTS mean has coefficient MCSE and approximate field-mean/SD Monte Carlo intervals from a within-chain block bootstrap (block length 100, 500 bootstrap replicates). Posterior spread and reference MC uncertainty are displayed separately. Inspect block-length sensitivity and the diagnostic table before making final reference-accuracy claims. The plotted repeat confidence intervals condition on the shared reference; they do not propagate its MC error into every distance metric.

## Results and publication outputs

The submission command prints the absolute batch path. After completion, download:

```text
BATCH/gad_ip_publication_results.zip
```

The ZIP includes the complete source snapshot and configuration, all original method clouds and all-round canonical metrics, reference chains and summaries, new reference metrics, diagnostic evidence and publication outputs. Repeated generated model-data directories, obsolete attempts and trusted restart pickles stay in the Vista batch and are excluded from the review ZIP.

Main review files under `meta_results/`:

- `dashboard.pdf`: all publication figures, prefaced by the experiment and uncertainty conventions.
- `all_metrics.csv`: every method/round/seed, with both original and additional metrics.
- `summary.csv`: mean, sample SD, bootstrap 95% interval and explicit `n/expected_n` for every scalar metric.
- `paired_comparisons.csv`: GAD minus same-round MALA and GAD minus GAD-1, paired bootstrap intervals, ratios/reductions for positive errors, and win counts.
- `run_manifest.csv`, `reference_quality.csv`, `missing_or_failed.csv`, `completion.json`.
- `tables/*.tex`: editable mean +/- SD numeric tables for primary, posterior and secondary metrics.
- `metric_definitions.json`: exact definitions and estimator conventions.

Every problem gets the same figure family, with editable SVG, embedded-font PDF and **600 dpi PNG**, consistent serif typography, common method colors, matched axes and documented color scales:

- Primary field/state/forward errors versus round with repeat-mean confidence intervals.
- Six posterior-reference functionals versus cumulative canonical work: whitened mean/covariance errors, physical-field mean/SD errors, 95% interval endpoint error, and sliced Wasserstein error.
- Secondary exact-score, predictive and baseline diagnostics.
- Manuscript-style rows of posterior mean, absolute error and pointwise posterior SD, with truth/NUTS/GAD-1/GAD-4/MALA-4 columns and shared unsaturated row scales.
- Mean estimates and their spatial SD across independent sampler repeats.
- Physical-state reconstructions with the original full-state metric definition preserved.
- Three reference-PCA projection pairs, all four GAD rounds, NUTS and final MALA, with common coordinates and disclosed mass outside the displayed window.
- Held-out predictive intervals, sensor/source geometry, NUTS traces and reference MC uncertainty maps.
- Sampler runtime and conditional reference ESS diagnostics.

The map/PCA/predictive illustrations use **preselected sampler seed 42**, not the best seed. Aggregate curves use all ten seeds; no round is selected separately by seed. Physical-field posterior means average the transformed fields, important for nonlinear velocity/contrast maps; the original `RMSE_field` remains the field evaluated at the mean coefficient. Both are reported under distinct names. Posterior SD uses `ddof=1`, explicitly differing from the archived manuscript illustration's `ddof=0`.

The original `postprocess_seed.py` is retained unchanged in `vendor/screening/` and works on these run directories:

```bash
python "$BATCH/code/vendor/screening/postprocess_seed.py" \
  --root "$BATCH/runs" --seed 42 --output "$BATCH/seed42_legacy_review"
```

Original KL diagnostics have an unknown normalizer and are not true KL estimates. The canonical predictive NLL's absolute jitter floor is preserved for reproducibility. An additional `ScaledHeldoutPredNLL` uses noise-relative jitter, and clean held-out relative error is reported separately to expose small-amplitude/low-signal FWI effects. Unbiased reference `RefMMD2` can be negative; it is never truncated or relabeled a nonnegative distance. The SW2 subcloud band compares a candidate-size subcloud with all remaining disjoint NUTS draws. It is a finite-sample comparison scale, not a rigorous lower bound or an autocorrelation correction. All finite tails remain in the metrics.

Incomplete branches yield `INCOMPLETE_dashboard.pdf` and a nonzero aggregate job exit, while retaining numeric evidence and the review ZIP. A complete publication-ready claim requires every configured repeat and each reference to pass the checks; unavailable values are never silently treated as zero or as a ten-run average.

## Monitor, restart and extend references

```bash
export BATCH=/absolute/path/printed/by/submit
squeue -u "$USER"
python "$BATCH/code/workflow.py" status --batch "$BATCH"

# After earlier jobs have finished or obsolete dependent jobs have been canceled:
bash submit.sh --resume-batch "$BATCH" --account YOUR_ALLOCATION

# Rebuild reports only, with no sampling or PDE evaluations:
python "$BATCH/code/aggregate_publication.py" --batch "$BATCH"
```

Submission IDs and exact commands are persisted after each successful `sbatch`. A partial submission failure leaves earlier jobs visible and resumable. Resubmission refuses to race existing live jobs. Completed canonical runs and reference chains are checked and skipped; production checkpoints resume; failed repeat directories are moved to `failed_attempts/` before a retry. Reference comparison jobs may recompute saved prediction summaries; they do not change the canonical sampler outputs. Frozen scientific settings and code may not be edited in place.

If NUTS fails scientific diagnostics, resubmitting the same batch cannot improve the already completed draws. Make a new configuration with longer reference runs or more conservative NUTS settings and reuse the completed GAD/MALA repeats:

```bash
cp settings.json extended_reference.json
# Edit only the nuts/evaluation reference settings in extended_reference.json.
bash submit.sh --config extended_reference.json --batch ../batches/gad_ip_pub_ref2 \
  --reuse-runs "$BATCH" --account YOUR_ALLOCATION
```

Reusing runs requires identical data seed, sampler seeds, comparison settings, particle counts and model/sampler source hashes. All reference comparisons are recomputed against the new independently validated reference. Any problem/setup change requires a genuinely new comparison run.

## Provenance and checks

`vendor/screening/` is the supplied screening bundle, byte-for-byte, plus the supplied postprocessor. The Darcy NUTS driver and settings are archived in `provenance/`; generic MAP/whitening/diagnostic routines in `reference_core.py` are copied verbatim and checked by AST in the tests. The supplied metrics/manifest are preserved as screening evidence. Scientific defaults in this bundle take precedence over earlier report suggestions: the requested four rounds and particle counts are used exactly.

Run local tests in a suitable Python environment:

```bash
python -m unittest discover -s tests -v
python -m unittest discover -s vendor/screening/tests -v
bash -n submit.sh install_reference_extras.sh slurm/job.slurm slurm/environment.sh
```

`VALIDATION.md` records which numerical, restart, scheduler, identity and visual checks were actually performed while preparing this bundle. Local CPU smoke checks do not establish production NUTS mixing or Vista GPU performance; the submitted preflight and actual reference diagnostics remain required.

Official API/scheduler references consulted: [NumPyro MCMC](https://num.pyro.ai/en/latest/mcmc.html) and [Vista running jobs](https://docs.tacc.utexas.edu/hpc/vista/running/). Queue limits can change; use `qlimits` on Vista for the current values.
