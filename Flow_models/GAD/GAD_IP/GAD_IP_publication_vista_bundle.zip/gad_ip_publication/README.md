# GAD inverse-problem publication run bundle — follow-up revision

This revision implements the supplied follow-up selection report: validate NS and Allen-Cahn as the core pair and Helmholtz as the complementary candidate. The screening models, GAD sampler, compute-matched checkpoint MALA and strict Darcy NUTS criteria remain canonical. No tuning sweeps or theory work are scheduled. FWI stays a reserve; existing Darcy work stays in place.

## Target snapshot fix for existing campaigns

**All four problems now use the exact prepared target in every worker**, including NUTS, repeats, reference summaries and evaluations. The original model/sampler files, numerical settings and convergence criteria remain unchanged. New preparations also freeze PDE/source constants and validation probes.

**Existing frozen batches need the one-time repair in [TARGET_SNAPSHOT_FIX.md](TARGET_SNAPSHOT_FIX.md).** Extracting the updated ZIP alone does not update their `code/` snapshots. The repair preserves saved targets/MAPs/results and pending job IDs; it backs up source/manifests and refuses to edit a batch while its jobs are running. Resume the existing batch afterward, adding `--retry-failed` for jobs that already failed at the target check.

## Run on Vista

The standard workflow is a **detached incremental submission watcher**: it keeps filling eligible missing jobs after the SSH connection closes. See **[RUN_ON_VISTA.md](RUN_ON_VISTA.md)** for the current campaign and **[SUBMISSION_WATCHER.md](SUBMISSION_WATCHER.md)** for the reusable start/resume/monitor/stop recipe.

For a new campaign, run from this bundle directory:

```bash
source slurm/environment.sh
GP_BATCH=../batches/gad_ip_followup_20261026_v2
GP_DRIVER_LOG=../gad_ip_followup_20261026_v2_submit.log

nohup bash submit.sh --batch "$GP_BATCH" \
  --reuse-from ../batches/gad_ip_publication_20261026 \
  --import-runs .. --repeats 5 --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown

tail -n 20 "$GP_DRIVER_LOG"
```

Check for normal plans or successful submission completion in the log before disconnecting. For an existing batch, use the detached **resume** recipe in the guides. Keep one watcher per batch. For this target-loader code update, stop polling, apply the one-time repair in TARGET_SNAPSHOT_FIX.md once running batch jobs finish, then resume the same batch. The driver PID and login host are recorded separately from Slurm job IDs; inspect the recorded host when checking that process after reconnecting.

Create a new batch for these changed settings. Existing frozen batches retain their code/settings and submitted time limits. The planner searches sibling batches plus explicit `--reuse-from` sources, checks each problem/seed separately, copies valid outputs and waits for compatible active jobs. Missing or changed work alone is submitted.

`--import-runs ..` searches full canonical screening/follow-up outputs under GAD_IP, skipping snapshots, model-data caches and failed attempts. Imports require actual metadata seeds, exact realized target arrays, source hashes, settings, complete finite raw clouds and moving canonical MALA. A six-round canonical Helmholtz trajectory may supply a verified five-round prefix. Independent-MALA repair outputs are excluded. A PDF/CSV/report alone cannot replace raw samples. Add another `--import-runs /path/to/raw_outputs` if needed.

The submission controller performs metadata, array and checksum checks, using NumPy in the existing environment. Sampling/PDE work runs on allocated nodes. Default jobs load `gcc/13.2.0`, `python3/3.11.8` and `$SCRATCH/venvs/hlsi`, matching the supplied Vista setup. Override `GP_VENV_DIR`, `GP_GCC_MODULE`, `GP_PYTHON_MODULE` if needed, or set `GP_SKIP_MODULES=1` when already in the correct environment. `GP_PYTHON` selects the submission interpreter. The original JAX memory fraction 0.20 remains, overridable by `GP_JAX_MEM_FRACTION`.

No reinstall is needed if the earlier preflight passed. If reference extras are missing, `install_reference_extras.sh` adds NumPyro and ArviZ 0.x while constraining the existing JAX/CUDA/PyTorch/NumPy/SciPy stack. Jobs never install packages. A compute-node preflight checks actual CUDA operations, reference APIs and fresh-kernel NumPyro continuation.

## Experiment plan

| Problem | Particles / bank | GAD rounds | Initial repeats | Optional final repeats |
| --- | ---: | ---: | ---: | ---: |
| Navier-Stokes | 1,000 | 5 | 5 | 10 |
| Allen-Cahn | 1,000 | 5 | 5 | 10 |
| Helmholtz | 2,000 | 5 | 5 | 10 |
| Acoustic FWI, reserve only | 300 | 4 | Explicit opt-in | 10 registered |

Use `--problems afwi` in a new batch to opt into the reserve. No more same-seed exploratory extensions, heat runs or independent-MALA audits are scheduled.

Data seed stays **42**; requested independent sampler seeds initially are **42–46**, expandable to **42–51**. These repeats estimate sampler variability on one posterior, not robustness across new truths, noise or sensor layouts. The model-loader adapter separates data randomness from the original `seed+10000` transport and `seed+20000` MALA streams. Metadata and target fingerprints are checked rather than trusting directory suffixes.

Every active problem uses 200 transport steps, canonical OU interval `[10^-2.5, 10]`, a shared reference/gate bank equal to particles, original curvature settings and the supplied checkpoint MALA: guarded adaptation, 32 chains, thinning 1, requested dt `1e-4`, work multiplier 1. No baseline tuning is folded into the primary comparison.

| Particles | GAD cumulative work | MALA cumulative work | Shared warmup | Transitions / chain | Draws / chain |
| ---: | --- | --- | ---: | --- | ---: |
| 1000 | 3000, 6000, 9000, 12000, 15000 | 2944, 5952, 8960, 11968, 14976 | 13 | 45, 92, 139, 186, 233 | 32 |
| 2000 | 6000, 12000, 18000, 24000, 30000 | 5952, 11968, 17984, 24000, 29952 | 29 | 92, 186, 280, 374, 467 | 63 |

These are the original derivative-count proxies (three per GN bank particle, two per MALA transition/chain plus initialization). They include warmup and are not FLOPs or elapsed time. A compute-matched short MALA trajectory is not relabelled a converged reference.

## Incremental submission and reservations

A fresh initial campaign has **50 task slots**: one preflight, three preparations, twelve NUTS chains, three reference certification/summary jobs, fifteen repeats, fifteen evaluations and one aggregate. Each sampler seed is a separate one-hour job; its evaluation is also separate. Existing work removes the corresponding submissions.

| Stage | Default wall limit | Reserved node-hours, fresh initial campaign |
| --- | --- | ---: |
| Preflight | 20 minutes | 0.33 |
| Prepare | 1 hour / problem | 3 |
| NUTS | 12 hours / chain | 144 |
| Reference certification / summary | 1 hour / problem | 3 |
| Sampler repeats | 1 hour / seed | 15 |
| Evaluation | 1 hour / seed | 15 |
| Aggregate | 1 hour | 1 |
| **Total across the campaign** | | **181.33** |

At GH's documented 1 SU per node-hour, this requests about **181.33 SU before reuse**, compared with 466.33 for the original four-problem reservations. It is a reservation estimate, not measured usage. Vista bills elapsed node time with a 15-minute minimum per running job. Your submission error shows queued/running requests encumbering the allocation; shorter limits lower that encumbrance. Splitting seeds also adds minimum-duration charges for very short jobs, but keeps a one-hour limit from covering five sequential repeats.

The controller caps **all your outstanding task slots at 32**, including unrelated jobs and expanded old arrays. `--watch` checks every 30 seconds and fills deferred work until all tasks have been submitted. A scheduler balance/submit-limit rejection pauses further attempts in that pass and retains accepted IDs. This limits simultaneous reservations; it cannot increase the remaining allocation. If balance stays insufficient, work remains deferred. Site limits can change; check `qlimits`.

To lower the cap or override a reservation, stop the previous watcher while it is polling, then use the detached resume recipe with `--max-outstanding-tasks 24 --time chain=12:00:00 --time repeat=01:00:00`. These flags affect new submissions; supply intended operational overrides again after a later driver restart.

The watcher runs on a login node; workers never call `sbatch`. `nohup` detaches it from the connection, while `--watch` supplies the repeated planning/submission behavior. If it stops, submitted jobs continue; resume the same batch to fill deferred work. It exits once every task is cached/submitted, while compute jobs may still run. A login-node restart or process termination still requires a manual resume.

Deferral can also mean waiting for prepared target arrays to verify raw imports. For example, the current default campaign may initially submit 19 preparation/reference tasks and defer the remaining 31. Repeated `0 new submissions; 1 cached; 31 deferred; 0 failed` messages are healthy polling; consult each node's reason in `submission_plan.json` for the actual blocker.

Preparation releases independent NUTS chains and repeats. Each evaluation waits for its own repeat and certified reference. Valid NUTS clouds/chains survive particle-count and round changes if target and NUTS settings match; particle-dependent floor summaries and evaluations are rebuilt when needed. Active legacy chain arrays are recognized by individual task IDs. Completed chunks support timeout restart.

`submission_plan.json` lists cached, existing, submitted, deferred and failed nodes with reuse sources. `jobs.json` persists each successful submission immediately. Repeated invocation retains live IDs. Failed/cancelled jobs or completed jobs with invalid output need inspection and explicit `--retry-failed`; watch mode permits only one deliberate retry per task per invocation.

Changing scientific settings requires a new batch with `--reuse-from OLD_BATCH`. The planner compares individual problems/seeds, so changing only Helmholtz retains valid NS/Allen-Cahn outputs. Growing from five to ten repeats retains the original five. Wait for the current aggregate job before changing the requested repeat count. GH jobs request one node and one task, without unsupported memory/GPU flags or `--export`.

## NUTS reference design and failure handling

The reference uses the **same discretized posterior** as the comparison run, not a finer PDE grid or a different sensor/noise model. “High fidelity” here means a longer, independently sampled posterior reference. Fingerprints bind the model source, realized basis, truth, observations, holdouts, observation geometry, noise scale and data seed. A mismatch fails rather than allowing a comparison between different posteriors.

The exact potential is `0.5 * ||alpha||^2 + 0.5 * ||F(alpha)-y||^2 / noise_std^2`. MAP starts use zero and independent prior draws, never generating truth or GAD/MALA output. The supplied Darcy routines perform four-start MAP optimization, select distinct candidate basins, regularize the exact MAP Hessian and construct a fixed invertible affine whitening map. The chains adapt dense mass matrices and use independent overdispersed starts, target acceptance 0.95, warmup tree depth 10 and production depth 12. Whitening changes coordinates, not the target potential; its constant Jacobian has no effect on the chain.

Per problem, the reference has 3,000 warmup and 5,000 retained draws per chain, four chains, and no thinning. Production saves atomic chunks of 250 draws together with full adaptation state and RNG state. Completed chunks resume without restarting or duplicating production draws; an interrupted incomplete warmup restarts warmup. Pickle checkpoints are trusted, locally generated state files and must not be replaced with files from untrusted sources. Resuming with different numerical package versions is refused.

Certification follows the Darcy thresholds on every latent coefficient plus potential energy, coefficient norm, four field-quadrant means and field RMS:

- Rank-normalized R-hat <= 1.01; bulk ESS >= 1000; tail ESS >= 400.
- Zero divergences; tree-depth saturation <= 1% in every chain.
- E-BFMI >= 0.30 and mean acceptance >= 0.80 in every chain.
- Finite draws and all required diagnostics.

Diagnostics are necessary evidence of mixing, not a proof that all possible modes were explored. Multi-start initialization and the trace/functional diagnostics make failures visible; a diagnostic pass is not mathematical ground truth. Unsuccessful checks write `reference_samples_uncertified.npz` and detailed diagnostics, but do **not** write a usable canonical reference or publication comparisons. There is no automatic override or silent reference substitution.

The NUTS mean has coefficient MCSE and approximate field-mean/SD Monte Carlo intervals from a within-chain block bootstrap (block length 100, 500 bootstrap replicates). Posterior spread and reference MC uncertainty are displayed separately. Inspect block-length sensitivity and the diagnostic table before making final reference-accuracy claims. The plotted repeat confidence intervals condition on the shared reference; they do not propagate its MC error into every distance metric.

## Results and publication outputs

The submission command prints the absolute batch path. After completion, download:

```text
BATCH/gad_ip_publication_results.zip
```

The ZIP includes the complete source snapshot and configuration, all original method clouds and all-round canonical metrics, reference chains and summaries, new reference metrics, diagnostic evidence and publication outputs. Repeated generated model-data directories, obsolete attempts and trusted restart pickles stay in the Vista batch and are excluded from the review ZIP.

Main review files under `meta_results/`:

- `dashboard.pdf`: all publication figures, prefaced by the experiment and uncertainty conventions.
- `all_metrics.csv`: every method/round/seed, with both original and additional metrics.
- `summary.csv`: mean, median, sample SD, bootstrap 95% interval and explicit `n/expected_n` for every scalar metric.
- `paired_comparisons.csv`: GAD minus same-round MALA and GAD minus GAD-1, paired bootstrap intervals, ratios/reductions for positive errors, and win counts.
- `run_manifest.csv`, `reference_quality.csv`, `missing_or_failed.csv`, `completion.json`.
- `tables/*.tex`: editable mean +/- SD numeric tables for primary, posterior and secondary metrics.
- `metric_definitions.json`: exact definitions and estimator conventions.

Every problem gets the same figure family, with editable SVG, embedded-font PDF and **600 dpi PNG**, consistent serif typography, common method colors, matched axes and documented color scales:

- Primary field/state/forward errors versus round with repeat-mean confidence intervals.
- Six posterior-reference functionals versus cumulative canonical work: whitened mean/covariance errors, physical-field mean/SD errors, 95% interval endpoint error, and sliced Wasserstein error.
- Secondary exact-score, predictive and baseline diagnostics.
- Manuscript-style rows of posterior mean, absolute error and pointwise posterior SD, with truth/NUTS/GAD-1/GAD-final/MALA-final columns and shared unsaturated row scales.
- Mean estimates and their spatial SD across independent sampler repeats.
- Physical-state reconstructions with the original full-state metric definition preserved.
- Three reference-PCA projection pairs, all requested GAD rounds, NUTS and final MALA, with common coordinates and disclosed mass outside the displayed window.
- Held-out predictive intervals, sensor/source geometry, NUTS traces and reference MC uncertainty maps.
- Sampler runtime and conditional reference ESS diagnostics.

The map/PCA/predictive illustrations use **preselected sampler seed 42**, not the best seed. Aggregate curves use all requested seeds (five initially; ten after expansion); no round is selected separately by seed. Physical-field posterior means average the transformed fields, important for nonlinear velocity/contrast maps; the original `RMSE_field` remains the field evaluated at the mean coefficient. Both are reported under distinct names. Posterior SD uses `ddof=1`, explicitly differing from the archived manuscript illustration's `ddof=0`.

The original `postprocess_seed.py` is retained unchanged in `vendor/screening/` and works on these run directories:

```bash
python "$GP_BATCH/code/vendor/screening/postprocess_seed.py" \
  --root "$GP_BATCH/runs" --seed 42 --output "$GP_BATCH/seed42_legacy_review"
```

Original KL diagnostics have an unknown normalizer and are not true KL estimates. The canonical predictive NLL's absolute jitter floor is preserved for reproducibility. An additional `ScaledHeldoutPredNLL` uses noise-relative jitter, and clean held-out relative error is reported separately to expose small-amplitude/low-signal FWI effects. Unbiased reference `RefMMD2` can be negative; it is never truncated or relabeled a nonnegative distance. The SW2 subcloud band compares a candidate-size subcloud with all remaining disjoint NUTS draws. It is a finite-sample comparison scale, not a rigorous lower bound or an autocorrelation correction. All finite tails remain in the metrics.

Incomplete branches yield `INCOMPLETE_dashboard.pdf` and a nonzero aggregate job exit, while retaining numeric evidence and the review ZIP. A complete publication-ready claim requires every requested repeat and each reference to pass the checks; unavailable values are never silently treated as zero or as a ten-run average.

## Monitor, restart and expand

After reconnecting, return to the bundle directory and restore the paths:

```bash
GP_BATCH=../batches/gad_ip_followup_20261026_v2
GP_DRIVER_LOG=../gad_ip_followup_20261026_v2_submit.log

tail -n 30 "$GP_DRIVER_LOG"
squeue -u "$USER"
python workflow.py status --batch "$GP_BATCH"
```

If the previous watcher has stopped, load the working environment and resume it in the background:

```bash
source slurm/environment.sh
nohup bash submit.sh --resume-batch "$GP_BATCH" --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown
```

The selection and reuse/import roots are retained. Use this same detached resume recipe with `--repeats 10` after the five-repeat aggregate finishes, or with `--retry-failed` after inspecting a failed task. See [SUBMISSION_WATCHER.md](SUBMISSION_WATCHER.md) for process/host checks and stopping only the watcher. Use `--resume-batch` for operational restarts; reserve a new `--batch` for a new scientific campaign.

To build a partial or complete diagnostic review directly on an allocated node:

```bash
python "$GP_BATCH/code/aggregate_publication.py" --batch "$GP_BATCH"
```

Automatic aggregation waits until all required evaluation jobs can be submitted. For an upstream failure that prevented an evaluation submission, use the direct aggregate command to obtain a partial report/failure inventory. A diagnostic report never silently substitutes missing seeds.

If NUTS fails scientific diagnostics, repeating identical completed draws cannot improve convergence. Create another batch with longer/more conservative NUTS settings and `--reuse-from "$GP_BATCH"`. Compatible GAD/MALA repeats are retained and comparisons against the newly validated reference are rebuilt. Frozen settings/code must not be edited in place.

## Provenance and validation

`vendor/screening/` preserves all 44 supplied screening files byte-for-byte, plus the supplied postprocessor. The Darcy driver/settings and follow-up report/dashboard are in `provenance/`. Six generic MAP/whitening/diagnostic functions in `reference_core.py` match the supplied Darcy AST exactly. The attached report determines the active cases, particles, rounds and staged repeat counts; the screening ZIP determines canonical MALA. `BUNDLE_MANIFEST.json` inventories the deliverable.

```bash
python -m unittest discover -s tests -v
python -m unittest discover -s vendor/screening/tests -v
bash -n submit.sh install_reference_extras.sh slurm/job.slurm slurm/environment.sh
```

`VALIDATION.md` records actual local checks and distinguishes historical CPU smoke evidence from this revision's scheduler/cache/figure checks. Production convergence and Vista GPU performance still require the submitted jobs.

Official references: [Vista running jobs and accounting](https://docs.tacc.utexas.edu/hpc/vista/running/) and [NumPyro MCMC](https://num.pyro.ai/en/latest/mcmc.html). Queue limits can change; use `qlimits` on Vista.
