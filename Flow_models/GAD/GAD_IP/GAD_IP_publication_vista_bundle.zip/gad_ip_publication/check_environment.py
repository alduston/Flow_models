"""Exercise APIs, float64 PDE prerequisites, CUDA, and NUTS continuation before expensive jobs."""
import argparse
import importlib.metadata
import os
import platform
from pathlib import Path
from common import write_json


def check(*, imports_only=False, allow_cpu=False, record=None):
    import numpy as np
    import scipy
    import pandas
    import matplotlib
    import jax
    import jax.numpy as jnp
    import torch
    import numpyro
    import arviz as az
    import pypdf
    from numpyro.infer import MCMC, NUTS
    # Check actual callability, not only find_spec: this catches partially broken ArviZ installs.
    try:
        idata=az.from_dict(posterior={'probe':np.random.default_rng(4).normal(size=(4,200,2))})
    except (TypeError,AttributeError) as exc:
        raise RuntimeError('This workflow uses the supplied Darcy ArviZ 0.x API. Run install_reference_extras.sh (arviz>=0.18,<1); the installed ArviZ API is incompatible.') from exc
    for function,method in [(az.rhat,'rank'),(az.ess,'bulk'),(az.ess,'tail'),(az.mcse,'mean')]:
        if not np.isfinite(function(idata,method=method)['probe'].values).all():raise RuntimeError('ArviZ API check failed')
    result=dict(python=platform.python_version(),machine=platform.machine(),
                packages={k:importlib.metadata.version(k) for k in
                          ['numpy','scipy','pandas','matplotlib','jax','jaxlib','torch','numpyro','arviz','pypdf']})
    if not imports_only:
        jax.config.update('jax_enable_x64',True)
        if not allow_cpu:
            if not any(d.platform=='gpu' for d in jax.devices()):raise RuntimeError('JAX CUDA GPU required')
            if not torch.cuda.is_available():raise RuntimeError('PyTorch CUDA GPU required')
        a=jax.jit(lambda x: x@x)(jnp.eye(8,dtype=jnp.float64));a.block_until_ready()
        if a.dtype!=jnp.float64:raise RuntimeError('JAX float64 disabled')
        device='cuda' if torch.cuda.is_available() else 'cpu'
        b=torch.eye(8,dtype=torch.float64,device=device);(b@b).sum().item()
        energy=lambda z:.5*jnp.sum(z*z)
        sampler=MCMC(NUTS(potential_fn=energy,dense_mass=True),num_warmup=25,num_samples=8,progress_bar=False)
        sampler.run(jax.random.PRNGKey(5),init_params=jnp.zeros(2),extra_fields=('energy','num_steps','accept_prob','adapt_state.step_size'))
        state=sampler.last_state
        sampler=MCMC(NUTS(potential_fn=energy,dense_mass=True),num_warmup=25,num_samples=8,progress_bar=False)
        sampler.post_warmup_state=state
        sampler.run(state.rng_key,init_params=state.z,extra_fields=('energy','num_steps','accept_prob','adapt_state.step_size'))
        if sampler.get_samples().shape!=(8,2):raise RuntimeError('NumPyro continuation failed')
        result.update(jax_devices=[str(x) for x in jax.devices()],torch_device=device,
                      torch_gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)
    if record:write_json(record,result)
    print(result,flush=True)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--imports-only',action='store_true')
    p.add_argument('--allow-cpu',action='store_true');p.add_argument('--record',type=Path)
    args=p.parse_args();check(**vars(args))
