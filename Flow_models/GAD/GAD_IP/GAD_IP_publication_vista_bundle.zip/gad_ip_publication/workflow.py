#!/usr/bin/env python3
"""Standard-library batch freezing, Slurm submission, restart, and stage dispatch."""
import argparse
import datetime
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

from common import ROOT, digest, read_json, run_directory, settings, signature, stage_status, write_json


def validate_config(c):
    if set(c['problems'])-{'afwi','allen_cahn','navier_stokes','helmholtz'}:raise ValueError('Unknown problem')
    seeds=c['sampler_seeds'];n=c['nuts'];e=c['evaluation']
    if not seeds or len(seeds)!=len(set(seeds)) or any(not isinstance(s,int) or s<0 for s in seeds):raise ValueError('Distinct nonnegative sampler seeds required')
    if n['num_chains']<4 or n['num_samples']<4 or n['num_warmup']<1 or n['chunk_size']<1:raise ValueError('Invalid NUTS sizes')
    if n['max_tree_depth']<1 or n['max_tree_depth_warmup']<1:raise ValueError('Invalid NUTS tree depth')
    if not 0<n['target_accept']<1:raise ValueError('Invalid target acceptance')
    if not 0<c['aggregation']['confidence']<1:raise ValueError('Invalid confidence')
    if c['aggregation']['illustration_seed'] not in seeds:raise ValueError('Illustration seed must be a registered repeat')
    if c['aggregation']['bootstrap_replicates']<100 or e['reference_bootstrap']<20:raise ValueError('Too few bootstrap draws')
    for p in c['problems']:
        from common import sampler_settings
        sampler_settings(c,p)
    return c


def freeze(config_path,batch,problems=None,reuse_runs=None):
    c=validate_config(read_json(config_path));batch=Path(batch).resolve()
    if ROOT in batch.parents and batch.relative_to(ROOT).parts[0]!='batches':
        raise ValueError('Place batches outside the bundle or under its batches/ directory, so source snapshots cannot include themselves')
    if batch.exists():raise FileExistsError(f'Use --resume-batch for existing {batch}')
    problems=problems or list(c['problems'])
    if any(p not in c['problems'] for p in problems):raise ValueError('Requested problem absent from config')
    batch.mkdir(parents=True)
    shutil.copytree(ROOT,batch/'code',ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','batches','output','*.pyc'))
    write_json(batch/'settings.json',c)
    (batch/'logs').mkdir();(batch/'stages').mkdir()
    hashes={str(p.relative_to(batch/'code')):digest(p) for p in sorted((batch/'code').rglob('*')) if p.is_file()}
    write_json(batch/'source_manifest.json',hashes)
    write_json(batch/'batch.json',dict(problems=problems,settings_sha256=digest(batch/'settings.json'),
                                     created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                     source_manifest_sha256=digest(batch/'source_manifest.json'),reuse_runs=str(reuse_runs) if reuse_runs else None))
    if reuse_runs:
        old=Path(reuse_runs).resolve();previous=settings(old)
        for key in ('data_seed','sampler_seeds','sampler','problems'):
            if c[key]!=previous[key]:raise ValueError(f'Cannot reuse runs: changed {key}')
        for p in problems:
            for seed in c['sampler_seeds']:
                source=run_directory(old,p,seed)
                if not (source/'repeat_identity.json').exists():continue
                binding=read_json(source/'repeat_identity.json')
                if binding['samples_sha256']!=digest(source/'samples_all_rounds.npz'):raise ValueError('Reused run checksum failed')
                config=read_json(source/'experiment_config.json')
                if config['sampling_sha256']!=digest(batch/'code/vendor/screening/sampling.py') or config['model_sha256']!=digest(batch/f'code/vendor/screening/models/{p}.py'):
                    raise ValueError('Reused run sampler/model source changed')
                dest=run_directory(batch,p,seed);dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copytree(source,dest,ignore=shutil.ignore_patterns('publication_*','publication_model'))
    return batch


def verify_frozen(batch):
    b=read_json(batch/'batch.json')
    if digest(batch/'settings.json')!=b['settings_sha256']:raise ValueError('Frozen settings changed; create a new batch with --reuse-runs')
    if digest(batch/'source_manifest.json')!=b['source_manifest_sha256']:raise ValueError('Source manifest changed')
    for name,sha in read_json(batch/'source_manifest.json').items():
        if digest(batch/'code'/name)!=sha:raise ValueError(f'Frozen source changed: {name}')


def refuse_active(batch):
    saved=read_json(batch/'jobs.json') if (batch/'jobs.json').exists() else {}
    ids={str(v['id']) for v in saved.values()}
    if not ids:return
    command=['squeue','--noheader','--format=%A %T']
    if os.getenv('USER'):command+=['--user',os.environ['USER']]
    p=subprocess.run(command,capture_output=True,text=True)
    if p.returncode:raise RuntimeError('Could not check squeue; stopped to avoid duplicate submissions: '+p.stderr)
    active=[line for line in p.stdout.splitlines() if line.split() and re.split(r'[_\[]',line.split()[0])[0] in ids]
    if active:raise RuntimeError('Batch still has active jobs; wait or cancel obsolete jobs before resuming:\n'+'\n'.join(active))


def submit(args):
    if args.resume_batch:
        batch=Path(args.resume_batch).resolve();verify_frozen(batch)
        if not args.dry_run:refuse_active(batch)
    else:
        batch=Path(args.batch or f'batches/gad_ip_publication_{datetime.datetime.now():%Y%m%d_%H%M%S}_{os.getpid()}').resolve()
        freeze(args.config,batch,args.problems,args.reuse_runs)
    c=settings(batch);slurm=dict(c['slurm']);problems=read_json(batch/'batch.json')['problems']
    for name,value in [('max_parallel',args.max_parallel),('chain_parallel',args.chain_parallel),('post_parallel',args.post_parallel)]:
        if value is not None:slurm[name]=value
        if slurm[name]<1:raise ValueError('Parallel limits must be positive')
    if args.partition:slurm['partition']=args.partition
    for item in args.time or []:
        key,value=item.split('=',1)
        if key+'_time' not in slurm or not re.fullmatch(r'\d+:\d{2}:\d{2}',value):raise ValueError('Use --time chain=24:00:00 etc.')
        slurm[key+'_time']=value
    # Two repeat workers/problem: 38 task slots in the default all-four DAG.
    # This stays within Vista's documented 40 submitted jobs/user limit.
    workers=min(2,len(c['sampler_seeds']))
    jobs=read_json(batch/'jobs.json') if (batch/'jobs.json').exists() else {};plan=[]
    def queue(key,stage,problem='all',afterok=(),afterany=(),array=None):
        command=['sbatch','--parsable','-p',slurm['partition'],'-N','1','-n','1',
                 '--time='+slurm[stage+'_time'],'--job-name=gp-'+key,
                 '--output='+str(batch/'logs'/(key+'-%A_%a.out'))]
        account=args.account or os.getenv('GP_ACCOUNT')
        if account:command+=['-A',account]
        if array:command+=['--array='+array]
        dependencies=[]
        if afterok:dependencies.append('afterok:'+':'.join(afterok))
        if afterany:dependencies.append('afterany:'+':'.join(afterany))
        if dependencies:command+=['--dependency='+','.join(dependencies),'--kill-on-invalid-dep=yes']
        command+=[str(batch/'code/slurm/job.slurm'),str(batch),stage,problem]
        plan.append(dict(key=key,command=command))
        if args.dry_run:
            import shlex
            print(shlex.join(command));return str(900000+len(plan))
        log=batch/'logs'/f'submit-{key}-{time.time_ns()}.log'
        result=subprocess.run(command,text=True,capture_output=True);log.write_text(result.stdout+result.stderr)
        if result.returncode:raise RuntimeError(f'sbatch failed for {key}; earlier submissions retained. See {log}: '+result.stderr.strip())
        ids=re.findall(r'^\s*(?:Submitted batch job\s+)?(\d+)(?:;[^\s;]+)?\s*$',result.stdout,re.MULTILINE)
        if len(ids)!=1:raise RuntimeError(f'Cannot identify submitted job ID; inspect {log} before retrying')
        jid=ids[0];jobs[key]=dict(id=jid,command=command,submitted_unix=time.time())
        write_json(batch/'jobs.json',jobs);(batch/f'{key}_job_id.txt').write_text(jid+'\n')
        print(f'{key}: {jid}',flush=True);return jid
    try:
        preflight=queue('preflight','preflight');terminal=[];evaluation_lanes=[]
        for problem in problems:
            prep=queue(problem+'-prepare','prepare',problem,afterok=[preflight])
            chains=queue(problem+'-chains','chain',problem,afterok=[prep],array=f'0-{c["nuts"]["num_chains"]-1}%{slurm["chain_parallel"]}')
            repeats=queue(problem+'-repeats','repeat',problem,afterok=[prep],array=f'0-{workers-1}%{slurm["max_parallel"]}')
            certified=queue(problem+'-reference','certify',problem,afterok=[chains])
            previous=[]
            if len(evaluation_lanes)>=slurm['post_parallel']:previous=[evaluation_lanes[-slurm['post_parallel']]]
            evaluated=queue(problem+'-evaluation','evaluate',problem,afterok=[certified],afterany=[repeats]+previous)
            evaluation_lanes.append(evaluated)
            terminal += [prep,chains,repeats,certified,evaluated]
        queue('aggregate','aggregate',afterany=terminal)
    finally:write_json(batch/'submission_plan.json',plan)
    print(f'Batch: {batch}\nResults: {batch}/gad_ip_publication_results.zip')
    return 0


def stage(args):
    batch=Path(args.batch).resolve();verify_frozen(batch);c=settings(batch);p=args.problem
    task=args.task;stage=args.stage
    path=batch/'stages'/f'{p}-{stage}-{task}.json'
    def execute():
        if stage=='preflight':
            from check_environment import check
            return check(record=batch/'logs/environment-preflight.json',allow_cpu=args.allow_cpu)
        if p not in read_json(batch/'batch.json')['problems'] and stage!='aggregate':raise ValueError('Problem not registered')
        if stage=='prepare':
            from reference import prepare
            return prepare(batch,p)
        if stage=='chain':
            from reference import chain
            return chain(batch,p,task)
        if stage=='certify':
            from reference import certify,summarize
            certify(batch,p);return summarize(batch,p)
        if stage=='repeat':
            from repeat import run_repeat
            workers=min(2,len(c['sampler_seeds']));outcomes=[];errors=[]
            if not 0<=task<workers:raise ValueError('Invalid repeat worker index')
            for seed in c['sampler_seeds'][task::workers]:
                try:outcomes.append(run_repeat(batch,p,seed,allow_cpu=args.allow_cpu))
                except Exception as exc:
                    errors.append(dict(seed=seed,error=f'{type(exc).__name__}: {exc}'))
                    print(f'{p} seed{seed} failed; proceeding to the remaining independent seeds: {exc}',flush=True)
            if errors:
                write_json(batch/'stages'/f'{p}-repeat-{task}-failures.json',errors)
                raise RuntimeError(f'{len(errors)} repeats failed; completed repeats retained')
            return outcomes
        if stage=='evaluate':
            from comparison import evaluate_repeat
            outcomes=[];errors=[]
            for seed in c['sampler_seeds']:
                try:outcomes.append(evaluate_repeat(batch,p,seed))
                except Exception as exc:
                    errors.append(dict(seed=seed,error=f'{type(exc).__name__}: {exc}'))
                    print(f'{p} seed{seed}: reference evaluation failed: {exc}',flush=True)
            if errors:
                write_json(batch/'stages'/f'{p}-evaluate-failures.json',errors)
                raise RuntimeError(f'{len(errors)} reference evaluations failed; completed outputs retained')
            return outcomes
        if stage=='aggregate':
            from aggregate_publication import aggregate
            result=aggregate(batch)
            if not result['complete']:raise RuntimeError('Incomplete batch; diagnostic results ZIP and failure inventory were written')
            return result
    return stage_status(path,execute)


def main():
    parser=argparse.ArgumentParser(description=__doc__);subs=parser.add_subparsers(dest='command',required=True)
    p=subs.add_parser('submit');p.add_argument('--config',type=Path,default=ROOT/'settings.json')
    p.add_argument('--batch');p.add_argument('--resume-batch');p.add_argument('--reuse-runs')
    p.add_argument('--account','-A');p.add_argument('--dry-run',action='store_true')
    p.add_argument('--problems',nargs='+');p.add_argument('--partition')
    p.add_argument('--max-parallel',type=int);p.add_argument('--chain-parallel',type=int);p.add_argument('--post-parallel',type=int)
    p.add_argument('--time',action='append',help='Override scheduling only, e.g. --time chain=36:00:00')
    p=subs.add_parser('stage');p.add_argument('--batch',type=Path,required=True)
    p.add_argument('--stage',choices=['preflight','prepare','chain','certify','repeat','evaluate','aggregate'],required=True)
    p.add_argument('--problem',default='all');p.add_argument('--task',type=int,default=0);p.add_argument('--allow-cpu',action='store_true')
    p=subs.add_parser('status');p.add_argument('--batch',type=Path,required=True)
    a=parser.parse_args()
    if a.command=='submit':return submit(a)
    if a.command=='stage':stage(a);return 0
    for p in sorted((a.batch/'stages').glob('*.json')):
        value=read_json(p)
        if isinstance(value,dict):print(p.name, value.get('state',''),value.get('error',''))
    return 0


if __name__=='__main__':sys.exit(main())
