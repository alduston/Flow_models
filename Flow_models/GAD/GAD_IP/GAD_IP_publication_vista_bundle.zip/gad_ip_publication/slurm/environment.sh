#!/bin/bash
# Matches the supplied working Vista hlsi environment. Overrides are optional.
if [[ "${GP_SKIP_MODULES:-0}" != 1 ]]; then
  module purge
  module load "${GP_GCC_MODULE:-gcc/13.2.0}"
  module load "${GP_PYTHON_MODULE:-python3/3.11.8}"
  source "${GP_VENV_DIR:-${SCRATCH:?Set SCRATCH or GP_VENV_DIR}/venvs/hlsi}/bin/activate"
fi
export OMP_NUM_THREADS="${GP_THREADS:-8}"
export MKL_NUM_THREADS="$OMP_NUM_THREADS" OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS" NUMEXPR_NUM_THREADS="$OMP_NUM_THREADS"
export MPLBACKEND=Agg JAX_ENABLE_X64=true
export XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION="${GP_JAX_MEM_FRACTION:-0.20}"
