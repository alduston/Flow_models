#!/bin/bash
# Preserve the known-working CUDA stacks; never install CPU JAX or replace PyTorch.
set -eo pipefail
GP_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$GP_ROOT/slurm/environment.sh"
GP_CONSTRAINTS="$(mktemp)"
trap 'rm -f "$GP_CONSTRAINTS"' EXIT
python - "$GP_CONSTRAINTS" <<'PY'
import importlib.metadata,sys
from pathlib import Path
names=['jax','jaxlib','torch','numpy','scipy','pandas','matplotlib','jax-cuda12-plugin','jax-cuda12-pjrt','jax-cuda13-plugin','jax-cuda13-pjrt']
rows=[]
for name in names:
    try: rows.append(name+'=='+importlib.metadata.version(name))
    except importlib.metadata.PackageNotFoundError: pass
Path(sys.argv[1]).write_text('\n'.join(rows)+'\n')
PY
python -m pip install -c "$GP_CONSTRAINTS" numpyro 'arviz>=0.18,<1' pypdf
python "$GP_ROOT/check_environment.py" --imports-only
