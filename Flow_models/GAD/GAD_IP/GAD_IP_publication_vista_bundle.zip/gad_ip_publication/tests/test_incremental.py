"""Exercise reservation limits, reuse and recovery without contacting Slurm."""
import copy
from dataclasses import asdict
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import digest,load_npz,read_json,run_directory,save_npz,settings,write_json
from cache import adopt_reference,adopt_run,compatible_sources,evaluation_valid,import_screening_run,run_valid,summary_valid
from fixtures import synthetic_batch
from planner import report_signature
from workflow import freeze


class IncrementalTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name)
        binary=self.base/'bin';binary.mkdir()
        self.calls=self.base/'calls.json';self.states=self.base/'states.json'
        write_json(self.states,{})
        programs={
          'sbatch':'''import json,os,sys
from pathlib import Path
p=Path(os.environ['QA_CALLS']);calls=json.loads(p.read_text()) if p.exists() else []
calls.append(sys.argv[1:]);p.write_text(json.dumps(calls))
if len(calls)==int(os.environ.get('QA_FAIL_AT','-1')):
 print('ERROR: Insufficient balance for Project TEST',file=sys.stderr);sys.exit(1)
jid=str(1000+len(calls));s=Path(os.environ['QA_STATES']);states=json.loads(s.read_text());states[jid]='PENDING';s.write_text(json.dumps(states))
print('Site wrapper preamble');print('Submitted batch job '+jid)
''',
          'squeue':'''import json,os
from pathlib import Path
for jid,state in json.loads(Path(os.environ['QA_STATES']).read_text()).items():
 if state in {'PENDING','RUNNING'}:print(jid+'|'+state)
''',
          'sacct':'''import json,os
from pathlib import Path
for jid,state in json.loads(Path(os.environ['QA_STATES']).read_text()).items():print(jid+'|'+state+'|')
'''}
        for name,program in programs.items():
            path=binary/name;path.write_text('#!'+sys.executable+'\n'+program);path.chmod(0o755)
        self.env={**os.environ,'PATH':str(binary)+os.pathsep+os.environ['PATH'],'QA_CALLS':str(self.calls),'QA_STATES':str(self.states)}

    def tearDown(self):self.temp.cleanup()

    def cli(self,*args):
        result=subprocess.run([sys.executable,str(ROOT/'workflow.py'),'submit',*map(str,args)],env=self.env,capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        return result

    def commands(self):return read_json(self.calls) if self.calls.exists() else []

    def install_fixture(self,problem='afwi'):
        old=synthetic_batch(self.base,problem)
        config=self.base/'config.json';write_json(config,settings(old))
        batch=freeze(config,self.base/'current',[problem]);meta=read_json(batch/'batch.json');meta['workflow_version']=2;write_json(batch/'batch.json',meta)
        write_json(batch/'selection.json',dict(sampler_seeds=settings(old)['sampler_seeds'][:5],maximum=10))
        write_json(batch/'reuse_sources.json',dict(batches=[str(old)],screening_runs=[]))
        return old,batch

    def test_default_timing_slot_cap_and_no_duplicate_live_submission(self):
        write_json(self.states,{str(i):'RUNNING' for i in range(8)})
        batch=self.base/'batch with spaces';self.cli('--batch',batch,'-A','TEST')
        commands=self.commands();self.assertEqual(len(commands),24)
        self.assertTrue(all(not any(c.startswith('--array') for c in cmd) for cmd in commands))
        for cmd in commands:
            stage=cmd[-3];expected='12:00:00' if stage=='chain' else ('00:20:00' if stage=='preflight' else '01:00:00')
            self.assertIn('--time='+expected,cmd);self.assertIn('TEST',cmd)
        self.assertIn('--dependency=afterok:1001',commands[1])
        self.cli('--resume-batch',batch);self.assertEqual(len(self.commands()),24)
        plan=read_json(batch/'submission_plan.json');self.assertEqual(plan['initial_user_task_count'],32)
        self.assertEqual(plan['failed_tasks'],0);self.assertGreater(plan['deferred_tasks'],0)

    def test_budget_rejection_preserves_ids_and_refills_later(self):
        self.env['QA_FAIL_AT']='5';batch=self.base/'batch';self.cli('--batch',batch)
        jobs=read_json(batch/'jobs.json');self.assertGreaterEqual(len(jobs),4)
        self.assertNotIn('navier_stokes-chain-2',jobs)
        original={k:v['id'] for k,v in jobs.items()}
        self.env.pop('QA_FAIL_AT');self.cli('--resume-batch',batch,'--max-outstanding-tasks','100')
        later=read_json(batch/'jobs.json');self.assertTrue(all(later[k]['id']==v for k,v in original.items()))
        self.assertIn('navier_stokes-chain-2',later)

    def test_watch_refills_from_queue_cap(self):
        batch=self.base/'batch';self.cli('--batch',batch,'--max-outstanding-tasks','1')
        self.assertEqual(len(self.commands()),1)
        # Make the preflight output available and release its task slot.
        write_json(batch/'stages/all-preflight-0.json',dict(state='complete'))
        write_json(self.states,{'1001':'COMPLETED'})
        self.cli('--resume-batch',batch,'--watch','--poll-seconds','1','--max-passes','1')
        self.assertGreater(len(self.commands()),1)

    def test_all_complete_source_then_identical_resume_submits_nothing(self):
        old,batch=self.install_fixture();before=digest(old/'settings.json')
        self.cli('--resume-batch',batch)
        self.assertEqual(len(self.commands()),1);self.assertEqual(self.commands()[0][-3],'aggregate')
        self.assertTrue(evaluation_valid(batch,'afwi',42))
        write_json(batch/'meta_results/completion.json',dict(complete=True,input_signature=report_signature(batch,['afwi'],list(range(42,47)))))
        self.cli('--resume-batch',batch);self.assertEqual(len(self.commands()),1)
        self.assertEqual(digest(old/'settings.json'),before)

    def test_missing_single_seed_only_runs_that_seed_and_evaluation(self):
        old,batch=self.install_fixture();shutil.rmtree(run_directory(old,'afwi',44))
        self.cli('--resume-batch',batch)
        stages=[c[-3:] for c in self.commands()]
        self.assertEqual(stages,[['preflight','all','0'],['repeat','afwi','44'],['evaluate','afwi','44'],['aggregate','all','0']])
        self.assertTrue(summary_valid(batch,'afwi'))

    def test_five_to_ten_expansion_only_adds_missing_seeds(self):
        old,batch=self.install_fixture()
        for seed in range(47,52):shutil.rmtree(run_directory(old,'afwi',seed))
        self.cli('--resume-batch',batch)
        write_json(self.states,{str(v['id']):'COMPLETED' for v in read_json(batch/'jobs.json').values()})
        write_json(batch/'meta_results/completion.json',dict(complete=True,input_signature=report_signature(batch,['afwi'],list(range(42,47)))))
        start=len(self.commands());self.cli('--resume-batch',batch,'--repeats','10')
        later=self.commands()[start:]
        self.assertEqual([int(c[-1]) for c in later if c[-3]=='repeat'],list(range(47,52)))
        self.assertFalse(any(c[-3] in {'prepare','chain','certify'} for c in later))

    def test_live_legacy_chains_waited_on_and_never_resubmitted(self):
        old,batch=self.install_fixture();out=old/'reference/afwi'
        for name in ['reference_samples.npz','nuts_diagnostics.json','summary.json']:(out/name).unlink()
        for file in (out/'chains').glob('*'):file.unlink()
        write_json(old/'jobs.json',{'afwi-chains':dict(id='777')})
        write_json(self.states,{f'777_{i}':'RUNNING' for i in range(4)})
        self.cli('--resume-batch',batch)
        self.assertFalse(any(c[-3] in {'prepare','chain','repeat'} for c in self.commands()))
        ref=next(c for c in self.commands() if c[-3]=='certify')
        dep=next(c for c in ref if c.startswith('--dependency='))
        for i in range(4):self.assertIn('777_'+str(i),dep)

    def test_failure_requires_explicit_retry_and_retry_is_not_looped(self):
        batch=self.base/'batch';self.cli('--batch',batch,'--max-outstanding-tasks','1')
        write_json(self.states,{'1001':'FAILED'})
        result=subprocess.run([sys.executable,str(ROOT/'workflow.py'),'submit','--resume-batch',str(batch)],env=self.env,capture_output=True,text=True)
        self.assertEqual(result.returncode,2);self.assertEqual(len(self.commands()),1)
        self.cli('--resume-batch',batch,'--retry-failed','--max-outstanding-tasks','1')
        self.assertEqual(len(self.commands()),2);self.assertEqual(read_json(batch/'jobs.json')['preflight']['id'],'1002')
        self.assertTrue((batch/'job_history.jsonl').exists())

    def test_changed_particles_reuses_nuts_but_invalidates_only_sampler_and_summary(self):
        old,batch=self.install_fixture('helmholtz')
        # This is a new campaign, so changing the requested configuration is legitimate.
        c=settings(old);c['problems']['helmholtz']['particles']=96
        config=self.base/'changed.json';write_json(config,c)
        newer=freeze(config,self.base/'newer',['helmholtz']);meta=read_json(newer/'batch.json');meta['workflow_version']=2;write_json(newer/'batch.json',meta)
        self.cli('--resume-batch',newer,'--reuse-from',old)
        commands=self.commands()
        self.assertFalse(any(x[-3] in {'prepare','chain'} for x in commands))
        self.assertEqual(sum(x[-3]=='repeat' for x in commands),5)
        self.assertEqual(sum(x[-3]=='certify' for x in commands),1)
        self.assertEqual(digest(old/'reference/helmholtz/reference_samples.npz'),digest(newer/'reference/helmholtz/reference_samples.npz'))

    def test_raw_screening_import_uses_metadata_seed_and_requires_realized_target(self):
        old,batch=self.install_fixture();adopt_reference(batch,'afwi',compatible_sources(batch,'afwi',[old]))
        donor=run_directory(old,'afwi',42);raw=self.base/'run_with_misleading_seed43';shutil.copytree(donor,raw)
        got=import_screening_run(batch,'afwi',42,[raw]);self.assertIsNotNone(got);self.assertTrue(run_valid(batch,'afwi',42))
        self.assertIsNone(import_screening_run(batch,'afwi',43,[raw]))
        shutil.rmtree(run_directory(batch,'afwi',42));a=load_npz(raw/'realization.npz');a['y_obs']=a['y_obs']+1;save_npz(raw/'realization.npz',**a)
        self.assertIsNone(import_screening_run(batch,'afwi',42,[raw]))

    def test_only_changed_helmholtz_reruns_in_three_problem_campaign(self):
        sources=[]
        for problem in ['navier_stokes','allen_cahn','helmholtz']:
            parent=self.base/problem;parent.mkdir();sources.append(synthetic_batch(parent,problem))
        c=settings(sources[0]);c['problems']={p:dict(particles=80,rounds=4) for p in ['navier_stokes','allen_cahn','helmholtz']}
        c['problems']['helmholtz']['particles']=96;c['active_problems']=list(c['problems'])
        config=self.base/'changed.json';write_json(config,c);batch=self.base/'changed'
        args=['--config',config,'--batch',batch]
        for source in sources:args+=['--reuse-from',source]
        self.cli(*args)
        science=[x[-3:] for x in self.commands() if x[-3] in {'prepare','chain','repeat','evaluate','certify'}]
        self.assertTrue(science);self.assertTrue(all(x[1]=='helmholtz' for x in science))
        self.assertEqual(sum(x[0]=='repeat' for x in science),5)

    def test_longer_raw_checkpoint_run_truncates_only_verified_prefix(self):
        from common import sampler_settings
        old,batch=self.install_fixture();adopt_reference(batch,'afwi',compatible_sources(batch,'afwi',[old]))
        raw=self.base/'six_round_raw';shutil.copytree(run_directory(old,'afwi',42),raw);(raw/'repeat_identity.json').unlink()
        e=read_json(raw/'experiment_config.json');e['settings']['rounds']=6;write_json(raw/'experiment_config.json',e)
        clouds=load_npz(raw/'samples_all_rounds.npz');rows=read_json(raw/'metrics.json')
        for a in ['GAD','MALA']:
            for r in [5,6]:clouds[f'{a}-{r}']=clouds[f'{a}-4'];rows[f'{a}-{r}']=rows[f'{a}-4']
        save_npz(raw/'samples_all_rounds.npz',**clouds);write_json(raw/'metrics.json',rows)
        result=import_screening_run(batch,'afwi',42,[raw]);self.assertIsNotNone(result)
        self.assertEqual(len(load_npz(run_directory(batch,'afwi',42)/'samples_all_rounds.npz')),8)
        self.assertEqual(read_json(run_directory(batch,'afwi',42)/'import_provenance.json')['original_rounds'],6)
        shutil.rmtree(run_directory(batch,'afwi',42));e['settings']['mala_mode']='independent';write_json(raw/'experiment_config.json',e)
        self.assertIsNone(import_screening_run(batch,'afwi',42,[raw]))


if __name__=='__main__':unittest.main()
