"""Small synthetic fixtures for QA only. Never included as scientific results."""
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import (ROOT, digest, field_summary, fields_from_latents, read_json, run_directory,
                    save_npz, write_json)
from comparison import cloud_metrics, reference_geometry, reference_floors


def synthetic_batch(directory,problem='afwi'):
    batch=Path(directory)/'synthetic';batch.mkdir()
    config=read_json(ROOT/'settings.json');config['problems']={problem:{'particles':80}}
    config['nuts']['num_samples']=100;config['evaluation'].update(distribution_cap=64,sliced_directions=8,floor_replicates=4)
    config['aggregation'].update(bootstrap_replicates=200,png_dpi=85)
    write_json(batch/'settings.json',config);write_json(batch/'batch.json',dict(problems=[problem],qa_label='SYNTHETIC QA ONLY'))
    (batch/'stages').mkdir();(batch/'logs').mkdir()
    rng=np.random.default_rng(620);chains=rng.normal(0,.2,size=(4,100,6));reference=chains.reshape(-1,6);dim=6;n=8
    basis=rng.normal(0,.2,(n*n,dim));spec=dict(problem=np.asarray(problem),grid=np.asarray(n),basis=basis,mask=np.ones((n,n)),scale=np.asarray(.32),background=np.asarray(1.))
    truthalpha=np.zeros(dim);truth=fields_from_latents(truthalpha[None],spec)[0];spec['truth']=truth
    out=batch/'reference'/problem;out.mkdir(parents=True)
    save_npz(out/'physical_spec.npz',**spec)
    save_npz(out/'target_arrays.npz',alpha_true_np=truthalpha,y_obs_np=np.zeros(20),y_holdout_obs_np=np.zeros(12),
             basis=basis,receiver_flat_indices=np.array([8,9,10]),source_centers=np.array([[.2,.2],[.8,.2]]))
    write_json(out/'target.json',dict(fingerprint='synthetic-target',metadata=dict(dimension=dim)))
    save_npz(out/'reference_samples.npz',samples=reference,samples_by_chain=chains,certified=np.asarray(True),fingerprint=np.asarray('synthetic-target'))
    geometry=reference_geometry(reference,config['evaluation']);save_npz(out/'geometry.npz',**geometry)
    floor=reference_floors(reference,geometry,64,config['evaluation']);save_npz(out/'sampling_floors.npz',**floor)
    fs=field_summary(reference,spec);state=np.stack([np.sin(np.linspace(0,6,n*n).reshape(n,n))*1e-4]*2)
    summary=dict(fs,truth=truth,mean_mc_ci_low=fs['mean']-.001,mean_mc_ci_high=fs['mean']+.001,
                 state_at_mean=state,state_truth=state*1.1,predictive_mean=np.zeros(12),predictive_std=np.ones(12)*.01,
                 y_holdout_obs=rng.normal(0,.01,12),y_holdout_clean=np.zeros(12),noise_std=np.asarray(.01))
    save_npz(out/'reference_summary.npz',**summary)
    write_json(out/'summary.json',dict(reference_sha256=digest(out/'reference_samples.npz'),
               summary_sha256=digest(out/'reference_summary.npz'),geometry_sha256=digest(out/'geometry.npz'),
               floor_sha256=digest(out/'sampling_floors.npz')))
    write_json(out/'nuts_diagnostics.json',dict(certified=True,reference_sha256=digest(out/'reference_samples.npz'),
               convergence=dict(finite=True,max_rank_rhat=1.001,min_bulk_ess=300,min_tail_ess=200),
               kernel=dict(finite=True,total_divergences=0,min_ebfmi=1.2,min_mean_accept_prob=.95,per_chain=[])))
    save_npz(out/'chain_diagnostics.npz',potential_energy=(chains*chains).sum(-1)/2)
    for seed in config['sampler_seeds']:
        directory=run_directory(batch,problem,seed);directory.mkdir(parents=True)
        rows={};arrays={};predictives={};raw={};states={'truth':state*1.1};logs={}
        for algorithm in ['GAD','MALA']:
            for r in range(1,5):
                label=f'{algorithm}-{r}';offset=(.12/r if algorithm=='GAD' else .1/r**.3)
                a=rng.normal(offset,.2,(80,dim));raw[label]=a;f=field_summary(a,spec)
                for key,value in f.items():arrays[label+'__'+key]=value
                states[label]=state*(1+.3/r);predictives[label+'__mean']=rng.normal(0,.002/r,12);predictives[label+'__std']=np.ones(12)*.01
                row=cloud_metrics(a,reference,geometry,config['evaluation'],random_seed=10)
                row.update(RefFieldMeanRelL2=float(np.linalg.norm(f['mean']-fs['mean'])/np.linalg.norm(fs['mean'])),
                           RefFieldStdRelL2=float(np.linalg.norm(f['std']-fs['std'])/np.linalg.norm(fs['std'])),
                           RefFieldCI95RMSE=float(np.sqrt(np.mean((f['q025']-fs['q025'])**2))),
                           RMSE_field=offset,RMSE_state=offset*.1,FwdRelErr=offset*.5,PosteriorMeanFieldRMSE=offset*.9,
                           ScaledHeldoutPredNLL=-2+rng.normal(0,.1),HeldoutPredNLL=-1.8,HeldoutCleanRelL2=offset,
                           ScaledHeldoutCoverage95=.92,KSD=offset*1000,KLdiag=offset*5,
                           runtime_seconds=r*(2 if algorithm=='GAD' else 1),pde_solve_count=r*240)
                if algorithm=='MALA':row['mala_acceptance_rate']=.8
                rows[label]=row
                if algorithm=='GAD':logs[label]=dict(t=np.geomspace(10,.003,10),mean_ess=np.linspace(80,40-r*3,10))
        save_npz(directory/'samples_all_rounds.npz',**raw);save_npz(directory/'state_summaries.npz',**states)
        save_npz(directory/'publication_fields.npz',**arrays);save_npz(directory/'publication_predictives.npz',**predictives)
        write_json(directory/'metrics.json',rows);write_json(directory/'publication_metrics.json',rows)
        write_json(directory/'experiment_config.json',dict(sampling_sha256=digest(ROOT/'vendor/screening/sampling.py'),
                   model_sha256=digest(ROOT/f'vendor/screening/models/{problem}.py')))
        write_json(directory/'ess_logs.json',logs);write_json(directory/'status.json',dict(state='complete'))
        write_json(directory/'repeat_identity.json',dict(fingerprint='synthetic-target',samples_sha256=digest(directory/'samples_all_rounds.npz')))
        write_json(directory/'publication_identity.json',dict(fingerprint='synthetic-target',reference_sha256=digest(out/'reference_samples.npz'),
                   metrics_sha256=digest(directory/'publication_metrics.json'),fields_sha256=digest(directory/'publication_fields.npz'),
                   predictive_sha256=digest(directory/'publication_predictives.npz')))
    return batch
