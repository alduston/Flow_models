# Validation performed on 26 October 2026

The full four-problem Vista experiments have **not** been run by this bundle-authoring session. This file records local checks, not production results or evidence that the requested long references have mixed.

## Source and configuration preservation

- All 44 files in the supplied screening ZIP are preserved byte-for-byte in `vendor/screening/`.
- The supplied `postprocess_seed.py` is also preserved byte-for-byte.
- The six generic MAP/whitening/initialization/diagnostic routines copied from the Darcy NUTS driver match its original ASTs exactly. The original driver and settings are retained.
- Every executable Python file compiled; untouched archival source/prose files were treated as provenance, not executed as modules. All shell scripts passed `bash -n`.
- The default protocol was checked: four rounds, particle/bank counts 300/300/300/1500, sampler seeds 42-51, fixed data seed 42, and the canonical MALA controller and work schedules.

## Automated tests

**32 original screening tests + 14 new publication-workflow tests passed (46 total).**

The added tests cover:

- Exact empirical one-dimensional Wasserstein integration with unequal sample counts, signed unbiased MMD estimates, scale-aware predictive scoring, and nonlinear physical-field averaging.
- Paired seed bootstrap behavior, including preservation of constant paired differences.
- Model/sampler source preservation and frozen-configuration mutation rejection.
- Mocked Slurm submission with wrapper chatter, dependency wiring, the 38-task default plan, allocation rejection during partial submission, persisted IDs, recovery, and refusal to race active jobs.
- Complete versus missing-seed collection, rejection of changed or uncertified reference files, and reference-threshold failure withdrawing the canonical reference while retaining diagnostic evidence.
- Reusing completed canonical comparison runs in a new reference batch while dropping stale publication comparisons; rejecting changed data settings.
- An actual NumPyro chain interrupted after its first production chunk, resumed in a fresh sampler, and compared with an uninterrupted run. Saved production draws matched exactly. Changed settings were rejected.

## Model checks

The original seed-42 models for **acoustic FWI, Allen-Cahn, Navier-Stokes and Helmholtz** were imported at their original grid sizes/dimensions. Their forward maps, exact gradients, forward Jacobians and GN posterior curvature were checked. Independent finite-difference directional derivative relative errors were below the screening tolerance `5e-3`; the three separately logged FWI/NS/Helmholtz errors were approximately `8.7e-10`, `5.4e-9` and `6.8e-9`.

The fast host-side physical-field transforms used for posterior moment/interval summaries matched the original model transforms. The preparation stage also checks this at the truth, zero and an independent prior-scale probe before production jobs are released.

## Real reduced end-to-end CPU smoke run

A reduced **Allen-Cahn** validation used the original 32-dimensional, 32 x 32 problem, fixed data seed 42, 64 particles, 200 transport steps, two GAD rounds and two independent sampler seeds (42 and 43). Both canonical comparisons completed, used identical target fingerprints and produced their own GAD and checkpoint-MALA clouds.

Four independent short NUTS chains used 30 warmup steps and 80 retained draws each, with intentionally relaxed diagnostic thresholds solely to exercise the workflow. Preparation, exact-potential NUTS, chunk export, ArviZ diagnostics, physical/predictive reference summaries, both repeat evaluations, paired aggregation and the final results ZIP completed. The short-chain maximum rank R-hat was about 1.14: **this is a plumbing check, not a production-quality reference**. The delivered defaults retain the strict Darcy thresholds and 3,000/5,000 warmup/retained lengths.

An intentionally coarse three-step transport smoke test produced incomplete predictive metrics; the runner correctly marked it incomplete instead of silently reporting success. The actual reduced end-to-end test used the full canonical 200 steps. No coarse transport settings or relaxed NUTS thresholds are in the delivered defaults.

## Figure and artifact checks

- All 14 figure types, all three PCA pairs, CSV outputs, LaTeX table fragments and a 15-page dashboard were exercised with a ten-repeat synthetic fixture. Fixture results are not scientific outputs and are not included in the deliverable.
- The real reduced Allen-Cahn run also produced all 14 figure types and a complete results archive.
- Standalone PDFs are created from verified in-memory PDF bytes and atomically replaced. Every standalone PDF is reopened after rendering; invalid PDFs make aggregation incomplete. The completed dashboard and results ZIP were checked.
- Field/state grids, posterior-error/work curves, predictive bands, PCA histograms, repeat-variation maps, reference traces, uncertainty maps and geometry layouts were visually inspected. Final field/error/SD row labels and common color scales were checked on the real Allen-Cahn render.
- A production-resolution figure was generated at 600 dpi: its PNG was 4,329 x 2,821 pixels and its PDF was readable. PDF/SVG retain editable text and vector line work; physical grids retain their original solver resolution and are not represented as a finer numerical solution.

## Local QA environment

Python 3.12.14 on x86_64 CPU; NumPy 2.3.5, SciPy 1.17.0, pandas 2.2.3, Matplotlib 3.10.8, JAX/jaxlib 0.12.0.1, PyTorch 2.14.1+cpu, NumPyro 0.22.0, ArviZ 0.23.4, pypdf 6.10.0. These are tested local versions, not instructions to replace the working Vista environment.

The current ArviZ major-version API incompatibility and NumPyro fresh-kernel continuation requirement were reproduced during QA and handled. Production preflight checks actual API calls and CUDA operations in the selected Vista environment. Long-chain convergence, GPU runtime/memory use and all four ten-repeat outcomes must be assessed from the actual submitted jobs.
