"""Reference distances, posterior summaries, and additional predictive diagnostics.

These supplement the canonical screening metrics; no original metric is replaced.
"""
from pathlib import Path
import math

import numpy as np
from common import (check_target, digest, field_summary, load_model, load_npz, read_json,
                    run_directory, save_npz, settings, verified_reference, write_json)


def relnorm(a,b):
    denominator=float(np.linalg.norm(b))
    if denominator == 0: return None
    return float(np.linalg.norm(a-b)/denominator)


def reference_geometry(samples, config):
    mean=samples.mean(0); cov=np.cov(samples,rowvar=False)
    eigenvectors_values,eigenvectors=np.linalg.eigh(cov)
    floor=max(float(eigenvectors_values.max())*1e-10,1e-14)
    # Symmetric posterior whitening uses only the independent reference.
    whitener=(eigenvectors/np.sqrt(np.maximum(eigenvectors_values,floor)))@eigenvectors.T
    rng=np.random.default_rng(config['seed'])
    directions=rng.normal(size=(samples.shape[1],config['sliced_directions']))
    directions/=np.linalg.norm(directions,axis=0)
    order=np.argsort(eigenvectors_values)[::-1]
    return dict(mean=mean,cov=cov,whitener=whitener,directions=directions,
                pca=eigenvectors[:,order],pca_variance=eigenvectors_values[order],eigenvalue_floor=np.asarray(floor))


def sliced_w2(x,y,directions):
    """1-D empirical W2 integrated exactly over unequal empirical quantile grids."""
    a=np.sort(x@directions,axis=0);b=np.sort(y@directions,axis=0)
    boundaries=np.unique(np.concatenate([np.arange(len(a)+1)/len(a),np.arange(len(b)+1)/len(b)]))
    mid=(boundaries[1:]+boundaries[:-1])/2
    ia=np.minimum((mid*len(a)).astype(int),len(a)-1)
    ib=np.minimum((mid*len(b)).astype(int),len(b)-1)
    return float(np.sqrt(np.mean(np.sum((a[ia]-b[ib])**2*np.diff(boundaries)[:,None],axis=0))))


def mmd2(x,y):
    """Unbiased squared RBF MMD; may be negative at finite sample sizes."""
    from scipy.spatial.distance import cdist
    scale=float(x.shape[1]); n=len(x);m=len(y)
    xx=np.exp(-cdist(x,x,'sqeuclidean')/(2*scale));yy=np.exp(-cdist(y,y,'sqeuclidean')/(2*scale))
    xy=np.exp(-cdist(x,y,'sqeuclidean')/(2*scale))
    return float((xx.sum()-np.trace(xx))/(n*(n-1))+(yy.sum()-np.trace(yy))/(m*(m-1))-2*xy.mean())


def cloud_metrics(samples, reference, geometry, config, *, random_seed):
    W=geometry['whitener'];delta=(samples.mean(0)-geometry['mean'])@W.T
    covariance=W@np.cov(samples,rowvar=False)@W.T
    truthcov=W@geometry['cov']@W.T
    rng=np.random.default_rng(random_seed);cap=config['distribution_cap']
    sub=samples[rng.choice(len(samples),min(cap,len(samples)),replace=False)]
    # MMD uses an equally capped, fixed-seed reference subset. SW2 uses all reference draws.
    refsub=reference[np.random.default_rng(config['seed']).choice(len(reference),min(cap,len(reference)),replace=False)]
    x=(sub-geometry['mean'])@W.T;y=(reference-geometry['mean'])@W.T
    ym=(refsub-geometry['mean'])@W.T
    return dict(RefMeanWhitenedRMSE=float(np.sqrt(np.mean(delta**2))),
                RefCovWhitenedRelFro=relnorm(covariance,truthcov),
                RefSW2=sliced_w2(x,y,geometry['directions']),RefMMD2=mmd2(x,ym),
                distribution_eval_samples=len(sub),reference_eval_samples=len(refsub))


def reference_floors(reference, geometry, n, config):
    rng=np.random.default_rng(config['seed']+83);values=[]
    if 2*n>len(reference):raise ValueError('Reference too small for disjoint sampling-floor subclouds')
    white=(reference-geometry['mean'])@geometry['whitener'].T
    for _ in range(config['floor_replicates']):
        ii=rng.choice(len(reference),n,replace=False)
        remaining=np.ones(len(reference),dtype=bool);remaining[ii]=False
        values.append(sliced_w2(white[ii],white[remaining],geometry['directions']))
    return dict(sw2=np.asarray(values),n=np.asarray(n),
                definition=np.asarray('A size-matched candidate subcloud versus all remaining pooled NUTS draws; disjoint finite-sample scale, not a certification bound or ESS correction'))


def predictive_metrics_scaled(predictions, observed, clean, noise):
    """Full-covariance Gaussian predictive score with noise-relative jitter.

    Canonical HeldoutPredNLL retains its original 1e-8 floor. This additional
    score avoids that absolute floor dominating small-amplitude FWI signals.
    """
    mean=predictions.mean(0);cov=np.cov(predictions,rowvar=False)
    cov=np.atleast_2d(cov);p=len(mean);variance=np.diag(cov).copy()+noise**2
    jitter=max(noise**2*1e-8,float(variance.max())*1e-12,np.finfo(float).tiny)
    matrix=cov+(noise**2+jitter)*np.eye(p)
    chol=np.linalg.cholesky(matrix);residual=observed-mean
    from scipy.linalg import solve_triangular
    r=solve_triangular(chol,residual,lower=True)
    return dict(ScaledHeldoutPredNLL=float(.5*(p*np.log(2*np.pi)+2*np.log(np.diag(chol)).sum()+r@r)/p),
                scaled_predictive_jitter=jitter,scaled_jitter_to_noise_variance=jitter/noise**2,
                HeldoutCleanRelL2=relnorm(mean,np.asarray(clean)),
                HeldoutCleanRMSE=float(np.sqrt(np.mean((mean-clean)**2))),
                ScaledHeldoutCoverage95=float(np.mean(np.abs(residual)<=1.95996398454*np.sqrt(variance))))


def evaluate_repeat(batch,problem,seed):
    import jax
    import jax.numpy as jnp
    batch=Path(batch);cfg=settings(batch);directory=run_directory(batch,problem,seed)
    base=read_json(directory/'status.json')
    if base['state']!='complete':raise ValueError(f'{problem} seed{seed}: canonical run state {base["state"]}')
    binding=read_json(directory/'repeat_identity.json')
    reference,quality=verified_reference(batch,problem);out=batch/'reference'/problem
    summary_record=read_json(out/'summary.json')
    for name,key in [('reference_summary.npz','summary_sha256'),('geometry.npz','geometry_sha256'),('sampling_floors.npz','floor_sha256')]:
        if digest(out/name)!=summary_record[key]:raise ValueError('Reference summary/geometry changed')
    if binding['fingerprint']!=str(reference['fingerprint']):raise ValueError('Repeat and reference target mismatch')
    if binding['samples_sha256']!=digest(directory/'samples_all_rounds.npz'):raise ValueError('Repeat sample file changed')
    samples=load_npz(directory/'samples_all_rounds.npz');rows=read_json(directory/'metrics.json')
    model=load_model(problem,cfg['data_seed'],directory/'publication_model');check_target(batch,problem,model)
    spec=load_npz(out/'physical_spec.npz');refsummary=load_npz(out/'reference_summary.npz');geo=load_npz(out/'geometry.npz')
    field_arrays={};pred_arrays={};posterior_rows={}
    forward=jax.jit(jax.vmap(model.solve_forward_holdout));batchsize=cfg['sampler']['heldout_batch']
    selection=np.random.default_rng(seed+901).permutation(cfg['problems'][problem]['particles'])[:cfg['sampler']['eval_particles']]
    for label,values in samples.items():
        if not np.isfinite(values).all():raise ValueError(f'{label}: non-finite samples; no tail filtering allowed')
        print(f'[{problem} seed{seed} {label}] independent-reference evaluation',flush=True)
        fs=field_summary(values,spec)
        for key,value in fs.items():field_arrays[f'{label}__{key}']=value
        metrics=cloud_metrics(values,reference['samples'],geo,cfg['evaluation'],random_seed=cfg['evaluation']['seed'])
        metrics.update(RefFieldMeanRelL2=relnorm(fs['mean'],refsummary['mean']),
                       RefFieldStdRelL2=relnorm(fs['std'],refsummary['std']),
                       RefFieldCI95RMSE=float(np.sqrt(np.mean(np.concatenate([(fs['q025']-refsummary['q025']).ravel(),
                                                                                            (fs['q975']-refsummary['q975']).ravel()])**2))),
                       PosteriorMeanFieldRMSE=float(np.sqrt(np.mean((fs['mean']-spec['truth'])**2))))
        predictions=[]
        sub=values[selection]
        for i in range(0,len(sub),batchsize):
            predictions.append(np.asarray(forward(jnp.asarray(sub[i:i+batchsize]))))
        pred=np.concatenate(predictions)
        if not np.isfinite(pred).all():raise ValueError(f'{label}: non-finite predictive samples')
        metrics.update(predictive_metrics_scaled(pred,model.y_holdout_obs_np,model.y_holdout_clean_np,float(model.NOISE_STD)))
        metrics.update(RefPredictiveMeanRelL2=relnorm(pred.mean(0),refsummary['predictive_mean']),
                       RefPredictiveStdRelL2=relnorm(pred.std(0,ddof=1),refsummary['predictive_std']))
        pred_arrays[f'{label}__mean']=pred.mean(0);pred_arrays[f'{label}__std']=pred.std(0,ddof=1)
        posterior_rows[label]=dict(rows[label],**metrics)
    save_npz(directory/'publication_fields.npz',**field_arrays)
    save_npz(directory/'publication_predictives.npz',**pred_arrays)
    write_json(directory/'publication_metrics.json',posterior_rows)
    import csv
    keys=['method']+sorted({k for v in posterior_rows.values() for k in v})
    with (directory/'publication_metrics.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(dict(method=k,**v) for k,v in posterior_rows.items())
    write_json(directory/'publication_identity.json',dict(fingerprint=binding['fingerprint'],reference_sha256=quality['reference_sha256'],
                                                        metrics_sha256=digest(directory/'publication_metrics.json'),
                                                        fields_sha256=digest(directory/'publication_fields.npz'),
                                                        predictive_sha256=digest(directory/'publication_predictives.npz')))
    return dict(methods=len(posterior_rows),fingerprint=binding['fingerprint'])
