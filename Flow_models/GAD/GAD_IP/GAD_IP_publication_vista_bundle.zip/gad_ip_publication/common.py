"""Shared identity, data access and physical-field maps. No GPU import at module load."""
import contextlib
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCREEN = ROOT / 'vendor' / 'screening'
NAMES = {'afwi': 'Acoustic FWI', 'allen_cahn': 'Allen-Cahn',
         'navier_stokes': 'Navier-Stokes', 'helmholtz': 'Helmholtz'}


def screen_imports():
    if str(SCREEN) not in sys.path:
        sys.path.insert(0, str(SCREEN))


def read_json(path):
    return json.loads(Path(path).read_text())


def clean_json(value):
    if isinstance(value, dict): return {str(k): clean_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [clean_json(v) for v in value]
    if isinstance(value, Path): return str(value)
    if hasattr(value, 'tolist'): return clean_json(value.tolist())
    if isinstance(value, float) and not math.isfinite(value): return None
    return value


def write_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temporary.write_text(json.dumps(clean_json(value), indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def save_npz(path, **arrays):
    import numpy as np
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    with temporary.open('wb') as handle: np.savez_compressed(handle, **arrays)
    temporary.replace(path)


def load_npz(path):
    import numpy as np
    with np.load(path, allow_pickle=False) as archive:
        return {k: archive[k] for k in archive.files}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''): h.update(block)
    return h.hexdigest()


def signature(value):
    return hashlib.sha256(json.dumps(clean_json(value), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def fingerprint(metadata, arrays):
    import numpy as np
    h = hashlib.sha256(signature(metadata).encode())
    for key, value in sorted(arrays.items()):
        a = np.ascontiguousarray(value)
        h.update(key.encode()); h.update(str(a.dtype).encode()); h.update(str(a.shape).encode()); h.update(a.tobytes())
    return h.hexdigest()


@contextlib.contextmanager
def in_directory(path):
    path = Path(path).resolve(); path.mkdir(parents=True, exist_ok=True)
    before = Path.cwd(); os.chdir(path)
    try: yield path
    finally: os.chdir(before)


def settings(batch):
    return read_json(Path(batch) / 'settings.json')


def sampler_settings(config, problem):
    screen_imports()
    from protocol import Settings
    return Settings(**config['sampler'], particles=config['problems'][problem]['particles']).validate()


def load_model(problem, data_seed, directory):
    screen_imports()
    from run_problem import load_model as original
    with in_directory(directory):
        return original(problem, data_seed)


def model_data(problem, model, data_seed):
    import numpy as np
    arrays = {key: np.asarray(getattr(model, key), dtype=np.float64) for key in
              ('alpha_true_np', 'y_obs_np', 'y_clean_np', 'y_holdout_obs_np', 'y_holdout_clean_np')}
    arrays['basis'] = np.asarray(model.Basis, dtype=np.float64)
    for key in ('obs_indices_train', 'obs_indices_holdout', 'receiver_flat_indices',
                'holdout_receiver_flat_indices', 'source_centers', 'receiver_coords'):
        if hasattr(model, key): arrays[key] = np.asarray(getattr(model, key))
    meta = dict(problem=problem, data_seed=data_seed, noise_std=float(model.NOISE_STD),
                dimension=int(model.ACTIVE_DIM), grid=int(model.N), model_sha256=digest(SCREEN/'models'/f'{problem}.py'))
    return meta, arrays, fingerprint(meta, arrays)


def check_target(batch, problem, model):
    metadata, arrays, identity = model_data(problem, model, settings(batch)['data_seed'])
    expected = read_json(Path(batch)/'reference'/problem/'target.json')
    if expected['fingerprint'] != identity:
        raise ValueError(f'{problem}: target fingerprint mismatch (data/basis/model changed)')
    return identity


def physical_spec(problem, model):
    import numpy as np
    values = dict(basis=np.asarray(model.Basis), grid=np.asarray(model.N), problem=np.asarray(problem),
                  truth=np.asarray(model.true_field))
    if problem == 'afwi':
        values.update(mask=np.asarray(model.model_support_mask), scale=np.asarray(model.VELOCITY_LOG_PERTURB_SCALE),
                      background=np.asarray(model.BACKGROUND_VELOCITY))
    elif problem == 'helmholtz':
        values.update(mask=np.asarray(model.support_mask), scale=np.asarray(model.SCATTERER_AMPLITUDE))
    elif problem == 'navier_stokes': values['scale'] = np.asarray(model.INITIAL_VORTICITY_SCALE)
    return values


def fields_from_latents(samples, spec):
    import numpy as np
    a = np.asarray(samples, dtype=np.float64); n = int(spec['grid'])
    f = (a @ spec['basis'].T).reshape(a.shape[:-1] + (n, n))
    p = str(spec['problem'])
    if p == 'afwi': return float(spec['background'])*np.exp(float(spec['scale'])*np.tanh(f)*spec['mask'])
    if p == 'helmholtz': return float(spec['scale'])*np.tanh(f)*spec['mask']
    if p == 'navier_stokes':
        f = float(spec['scale'])*f
        return f-f.mean(axis=(-1, -2), keepdims=True)
    return f


def field_summary(samples, spec, batch_size=512):
    import numpy as np
    # Exact quantiles need all field draws. At production defaults: <=369 MB for FWI.
    fields = np.concatenate([fields_from_latents(samples[i:i+batch_size], spec)
                             for i in range(0, len(samples), batch_size)])
    return dict(mean=fields.mean(axis=0), std=fields.std(axis=0, ddof=1),
                q025=np.quantile(fields, .025, axis=0), q975=np.quantile(fields, .975, axis=0))


def verified_reference(batch, problem):
    import numpy as np
    directory = Path(batch)/'reference'/problem
    quality = read_json(directory/'nuts_diagnostics.json')
    if not quality.get('certified'): raise ValueError(f'{problem}: NUTS diagnostic checks failed')
    reference = load_npz(directory/'reference_samples.npz')
    if not bool(reference['certified']): raise ValueError('Uncertified reference cloud')
    target = read_json(directory/'target.json')
    if str(reference['fingerprint']) != target['fingerprint']: raise ValueError('Reference target mismatch')
    if digest(directory/'reference_samples.npz') != quality['reference_sha256']:
        raise ValueError('Reference bytes changed since certification')
    a = reference['samples_by_chain']
    c = settings(batch)['nuts']
    if a.shape != (c['num_chains'], c['num_samples'], target['metadata']['dimension']) or not np.isfinite(a).all():
        raise ValueError('Reference shape/finite validation failed')
    return reference, quality


def run_directory(batch, problem, seed):
    return Path(batch)/'runs'/problem/f'{problem}_seed{seed}'


def stage_status(path, action):
    """Write failure evidence even when a dependency or scientific check fails."""
    import traceback
    started = time.time()
    write_json(path, dict(state='running', started_unix=started))
    try:
        result = action()
        write_json(path, dict(state='complete', duration_seconds=time.time()-started, result=result))
        return result
    except BaseException as exc:
        write_json(path, dict(state='failed', duration_seconds=time.time()-started,
                             error=f'{type(exc).__name__}: {exc}', traceback=traceback.format_exc()))
        raise
