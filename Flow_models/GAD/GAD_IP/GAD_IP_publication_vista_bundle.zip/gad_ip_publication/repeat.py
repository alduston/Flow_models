"""Separate data and sampler seeds while preserving the screening code verbatim."""
from pathlib import Path
import shutil
import time

from common import (check_target, digest, load_model, read_json, run_directory,
                    sampler_settings, screen_imports, settings, write_json)


def run_repeat(batch, problem, seed, *, allow_cpu=False):
    batch=Path(batch);cfg=settings(batch);directory=run_directory(batch,problem,seed)
    if seed not in cfg['sampler_seeds']:raise ValueError('Seed not registered in this batch')
    if (directory/'status.json').exists():
        status=read_json(directory/'status.json')
        if status['state']=='complete' and (directory/'repeat_identity.json').exists():
            identity=read_json(directory/'repeat_identity.json')
            target=read_json(batch/'reference'/problem/'target.json')
            if identity['fingerprint']==target['fingerprint'] and identity['samples_sha256']==digest(directory/'samples_all_rounds.npz'):
                return identity
            raise ValueError('Completed run identity or samples changed')
        attempts=batch/'failed_attempts'/problem/f'seed{seed}_{time.time_ns()}'
        attempts.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(directory),str(attempts))
    screen_imports()
    import run_problem
    original=run_problem.load_model
    identity={}
    def fixed_data_model(requested_problem, requested_sampler_seed):
        model=original(requested_problem,cfg['data_seed'])
        identity['fingerprint']=check_target(batch,problem,model)
        return model
    run_problem.load_model=fixed_data_model
    try:
        result=run_problem.execute(problem,seed,sampler_settings(cfg,problem),directory,
                                   allow_cpu=allow_cpu,no_plots=True)
    finally:run_problem.load_model=original
    if result['state']!='complete':raise RuntimeError(f'Canonical screening returned {result["state"]}; inspect {directory}/status.json')
    config=read_json(directory/'experiment_config.json')
    config.update(data_seed=cfg['data_seed'],sampler_seed=seed,target_fingerprint=identity['fingerprint'],
                  seed_convention='fixed seed-42 inverse problem; only the sampler stream changes across repeats',
                  warning='Ten sampler repeats on one fixed posterior. This is not ten data realizations.')
    write_json(directory/'experiment_config.json',config)
    identity.update(samples_sha256=digest(directory/'samples_all_rounds.npz'),data_seed=cfg['data_seed'],sampler_seed=seed,
                    source='Unmodified vendor/screening; model-loader adapter only')
    write_json(directory/'repeat_identity.json',identity)
    return identity
