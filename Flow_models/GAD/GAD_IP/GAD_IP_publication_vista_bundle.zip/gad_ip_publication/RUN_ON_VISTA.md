# Updated follow-up campaign: copy, extract, submit

Run these commands on a Vista login node after copying the updated ZIP into your GAD_IP directory. Keep existing batches in place so their results and active jobs can be reused.

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP
unzip -qo GAD_IP_publication_vista_bundle.zip
cd gad_ip_publication

# Uses the same working environment as the original bundle.
source slurm/environment.sh

# A NEW batch is essential: the old batch keeps its original frozen code/settings.
# --import-runs .. searches the GAD_IP tree for full screening/follow-up outputs.
# --watch fills deferred submissions as task slots and allocation reservations free up.
bash submit.sh \
  --batch ../batches/gad_ip_followup_20261026_v2 \
  --reuse-from ../batches/gad_ip_publication_20261026 \
  --import-runs .. \
  --repeats 5 --watch
```

If the raw follow-up results are elsewhere, add `--import-runs /absolute/path/to/followup_outputs`. The supplied PDF/report contains summaries, not the raw samples needed for reuse. Screening imports are checked against actual data/sampler seeds, complete raw clouds, realized target arrays, model/sampler hashes and canonical MALA settings. A six-round canonical Helmholtz run can contribute its verified five-round prefix. Independently tuned MALA repair runs are excluded.

For a long-lived submission driver, replace the submission command above with:

```bash
nohup bash submit.sh \
  --batch ../batches/gad_ip_followup_20261026_v2 \
  --reuse-from ../batches/gad_ip_publication_20261026 \
  --import-runs .. --repeats 5 --watch \
  > ../gad_ip_followup_20261026_v2_submit.log 2>&1 &
```

Use one of these two submission commands, once. If that batch path already exists, resume it instead:

```bash
bash submit.sh --resume-batch ../batches/gad_ip_followup_20261026_v2 --watch
```

After the initial five-repeat report finishes, expand to ten; completed references, repeats and evaluations are retained:

```bash
bash submit.sh --resume-batch ../batches/gad_ip_followup_20261026_v2 \
  --repeats 10 --watch
```

The driver exits when every requested task is cached or submitted; the compute jobs may still be running. If you stop the driver, submitted jobs continue. Resume the same batch with `--watch` to submit any deferred work. A recorded scientific/job failure requires inspection and explicit `--retry-failed`; it is never repeatedly retried by the driver.

Monitor and collect:

```bash
squeue -u "$USER"
python workflow.py status --batch ../batches/gad_ip_followup_20261026_v2
# After the aggregate job completes:
ls ../batches/gad_ip_followup_20261026_v2/gad_ip_publication_results.zip
```

For a submission preview, add `--dry-run` to the initial command and omit `--watch`. This creates a frozen batch and `submission_plan.json` but no Slurm jobs. Submit that same snapshot with `--resume-batch ... --watch`. `--offline --dry-run` works away from Vista but cannot detect live jobs.

No unrelated jobs are cancelled. Existing old jobs keep their submitted time limits; the shorter defaults apply to newly submitted jobs. No numerical dependency reinstall is needed if the original preflight passed. `install_reference_extras.sh` is available if reference extras or the ArviZ 0.x API are missing.
