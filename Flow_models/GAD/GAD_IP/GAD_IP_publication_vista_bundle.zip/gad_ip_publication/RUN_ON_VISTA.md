# Vista: persistent incremental submission

> **Existing campaign:** see [TARGET_SNAPSHOT_FIX.md](TARGET_SNAPSHOT_FIX.md) before resuming. The target-loading fix also needs to be applied to the batch's frozen `code/`. A healthy watcher can be stopped while polling, the batch repaired once no batch jobs are running, and the same batch resumed. Completed work and saved MAPs are retained. This replaces the earlier documentation-only update advice for this code repair.


Use a detached `--watch` driver as the standard submission method. It checks every 30 seconds and submits eligible missing work as prerequisite outputs, task slots and allocation reservations become available. It continues after the laptop's SSH connection closes.

## Existing campaign already running

The current campaign is `../batches/gad_ip_followup_20261026_v2`. Stop its detached watcher while polling and let running batch jobs finish before applying this code repair. This code update requires a one-time frozen-batch repair and watcher restart; see TARGET_SNAPSHOT_FIX.md. Keep the frozen batch directories and their source snapshots intact.

## Prepare the bundle for a new campaign

Run on a Vista login node after copying the ZIP into GAD_IP:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP
unzip -qo GAD_IP_publication_vista_bundle.zip
cd gad_ip_publication
source slurm/environment.sh

GP_BATCH=../batches/gad_ip_followup_20261026_v2
GP_DRIVER_LOG=../gad_ip_followup_20261026_v2_submit.log
```

Use a new batch name when starting a new scientific configuration. If this batch directory already exists, use the resume recipe below. Start only one watcher for each batch.

## Start a new campaign and disconnect

```bash
nohup bash submit.sh \
  --batch "$GP_BATCH" \
  --reuse-from ../batches/gad_ip_publication_20261026 \
  --import-runs .. \
  --repeats 5 --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown

tail -n 20 "$GP_DRIVER_LOG"
```

`nohup` protects the driver from the SSH hangup; `< /dev/null` detaches input, `>> ... 2>&1` appends stdout/stderr to a persistent log, `&` runs in the background, and Bash's `disown` removes it from the terminal's job table. The printed number and saved `.pid` identify the login-node driver, separate from the Slurm job IDs printed in the log. The `.host` file records which login node owns that process.

Check for normal `Plan:` / `checking again` output without a traceback before disconnecting. A shell background PID alone proves launch, not successful initialization. A short successful run may instead print the final `Batch:` and `Results:` lines because everything is already cached or submitted.

`--import-runs ..` searches GAD_IP for complete raw screening/follow-up outputs. Add `--import-runs /absolute/path/to/followup_outputs` if they are elsewhere. Imports verify actual metadata seeds, realized target arrays, model/sampler hashes and canonical MALA. A six-round canonical Helmholtz run can supply a verified five-round prefix. Report/PDF/CSV summaries alone and independent-MALA repair outputs are insufficient.

## Resume an existing campaign in the background

After reconnecting, enter the bundle directory, load the working environment and set the paths shown above. If the watcher is still alive, keep it. If it has stopped or a previous foreground session disconnected, resume the same batch:

```bash
nohup bash submit.sh \
  --resume-batch "$GP_BATCH" --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown

tail -n 20 "$GP_DRIVER_LOG"
```

The batch retains its selected seeds and reuse/import paths. Valid outputs and compatible queued/running jobs are recognized; accepted job IDs are retained. Reconnecting is not a reason to create a new batch. Appending to the log preserves earlier submission history.

To move an existing foreground watcher into this workflow, press Ctrl+C while it says `checking again in 30s`, then launch the resume command. Submitted Slurm jobs continue.

## Monitor after reconnecting

```bash
# Restore these shell variables in each new terminal.
GP_BATCH=../batches/gad_ip_followup_20261026_v2
GP_DRIVER_LOG=../gad_ip_followup_20261026_v2_submit.log

tail -n 30 "$GP_DRIVER_LOG"
squeue -u "$USER"
python workflow.py status --batch "$GP_BATCH"

# For watchers started with the PID/host-recording recipe:
cat "$GP_DRIVER_LOG.host"
hostname
ps -p "$(cat "$GP_DRIVER_LOG.pid")" -o pid,etime,args
```

The process check is local to a login node: use the host recorded in `.host`. A watcher on login2 will not appear in login1's process table. Verify that the displayed command belongs to the expected batch; PID files can remain after a driver exits. Older watchers launched without the recording lines can still be monitored through their logs and the original launch PID on the original host.

For the default three-problem campaign, an initial `19 new submissions; 31 deferred; 0 failed` is normal. Preparation/reference jobs can be submitted first; repeats wait for prepared target arrays so existing raw runs can be verified. Repeated `0 new submissions; 1 cached; 31 deferred; 0 failed` lines therefore indicate healthy polling, not necessarily an SU rejection. Inspect `submission_plan.json` for the reason attached to each deferred node.

## What the watcher handles

- It caps all the user's outstanding task slots at 32 by default, including unrelated work and expanded arrays. Twelve-hour NUTS and one-hour standard reservations reduce requested allocation encumbrance.
- It defers work at the cap or after a scheduler balance/submit-limit rejection, then checks again. A future pass submits newly eligible missing tasks rather than duplicating completed/live work.
- It also waits for preparation outputs needed to verify raw imports. Scientific jobs themselves run on allocated compute nodes; the login-side watcher performs planning and submission.
- It exits once every requested task is cached or submitted. Slurm jobs can still be running afterward. Final `Batch:` / `Results:` lines indicate submission finished; inspect the aggregate result to establish experiment completion.
- A recorded failed/cancelled task or an unrecoverable error stops the watcher. Inspect the log and job evidence before using `--retry-failed`; ordinary reservation deferral does not require that flag.

This workflow manages simultaneous reservations and submission limits. It cannot make a campaign fit an insufficient total allocation. If balance remains insufficient, the remaining work stays deferred until allocation or workload changes. `nohup` survives connection loss, but not login-node restart, maintenance or process termination; resume the same batch afterward.

## Expand to ten repeats

After the five-repeat aggregate job has finished and the previous watcher has exited, resume with the larger selection. The first five repeats and compatible references/evaluations remain reusable:

```bash
nohup bash submit.sh \
  --resume-batch "$GP_BATCH" --repeats 10 --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown
```

## Stop, retry or preview

See [SUBMISSION_WATCHER.md](SUBMISSION_WATCHER.md) for the reusable operating recipe, stopping only the driver, deliberate failed-job retries, operational overrides and dry-run usage. Stopping the driver leaves submitted jobs in Slurm; it only pauses further submissions.

After aggregation completes, collect:

```bash
ls "$GP_BATCH/gad_ip_publication_results.zip"
```

Existing frozen batches keep their original submitted time limits. No dependency reinstall is needed if the original preflight passed. `install_reference_extras.sh` is available if reference extras or the ArviZ 0.x API are missing.
