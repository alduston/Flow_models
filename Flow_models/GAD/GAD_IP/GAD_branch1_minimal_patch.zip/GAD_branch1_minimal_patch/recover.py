#!/usr/bin/env python3
"""Infrastructure-only recovery. Frozen code/checkpoint bindings stay unchanged."""
import argparse, fcntl, json, os, re, shutil, signal, socket, subprocess, sys, time
from pathlib import Path

ORIGINAL_RUN = subprocess.run
TERMINAL = {'COMPLETED','FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY','NODE_FAIL','PREEMPTED','BOOT_FAIL','DEADLINE'}

def parse_job_id(text):
    ids = re.findall(r'(?m)^\s*(?:Submitted batch job\s+)?(\d+)(?:;[^\s]+)?\s*$', text)
    if len(ids) != 1: raise RuntimeError('Ambiguous sbatch output; inspect queue before retrying: '+text)
    return ids[0]

def accounting(state):
    completed = reserved = inflight = 0
    for t in state['tasks'].values():
        ids = [a['job_id'] for a in t.get('attempts',[])]
        if len(ids)!=len(set(ids)) or t.get('job_id') in ids: raise RuntimeError('Duplicate attempt accounting')
        completed += sum(a['elapsed_seconds'] for a in t.get('attempts',[]))
        if t['state'] in ['submitted','running']:
            reserved += t['wall_seconds']; inflight += 1
        else: completed += t.get('elapsed_seconds',0)
    return dict(completed_node_hours=completed/3600,reserved_inflight_node_hours=reserved/3600,total_committed_node_hours=(completed+reserved)/3600,inflight=inflight)

def read(p): return json.loads(Path(p).read_text())
def write(p,x):
    p=Path(p);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(x,indent=2)+'\n');tmp.replace(p)

def elapsed_rows(ids):
    if not ids:return {}
    p=ORIGINAL_RUN(['sacct','-n','-P','-j',','.join(ids),'--format=JobIDRaw,State,ElapsedRaw,AllocNodes'],capture_output=True,text=True,check=True)
    rows={}
    for line in p.stdout.splitlines():
        a=line.split('|')
        if len(a)>=4 and a[0].isdigit():rows[a[0]]=dict(state=a[1].split()[0].rstrip('+'),elapsed_seconds=int(a[2] or 0)*max(1,int(a[3] or 1)))
    return rows

def retire(t,reason,seconds):
    if not t.get('job_id'):raise RuntimeError('Cannot retire an unregistered attempt')
    entry={k:t[k] for k in ['job_id','wall_seconds','slurm_state','result','submitted'] if k in t}
    entry.update(elapsed_seconds=seconds,recovery_reason=reason)
    history=t.setdefault('attempts',[])
    if any(a['job_id']==entry['job_id'] for a in history):raise RuntimeError('Attempt already retired')
    history.append(entry)
    for key in ['job_id','elapsed_seconds','slurm_state','result','submitted','pending_replacement']:t.pop(key,None)
    t['state']='planned'

def valid_screen(batch,name):
    d=batch/'targets'/name
    needed=[d/'screen_status.json',d/'screen.json',d/'screen_reference/quality.json',d/'screen_reference/samples.npz']
    if not all(p.is_file() for p in needed):return False
    status,screen,quality=map(read,needed[:3])
    return status.get('state')=='complete' and quality.get('reference_usable') is True and screen.get('reference_usable') is True and bool(screen.get('binding')) and screen['binding']==quality.get('binding')

def patch_runtime(w,batch,minutes):
    old_refresh=w.refresh
    def refresh(state,path):
        changed=old_refresh(state,path)
        cfg=read(batch/'campaign.json');controls={s['id'] for s in cfg['targets'] if s.get('control')}
        for t in state['tasks'].values():
            if t['stage']!='screen' or t['target'] in controls:continue
            if t['state']=='planned':t['wall_seconds']=minutes*60
            if t['state']!='finished':continue
            status=batch/'targets'/t['target']/'screen_status.json'
            status=read(status) if status.exists() else {}
            # Completed-but-low-quality references are not silently resampled.
            if status.get('state')=='complete':continue
            if t.get('pending_replacement'):
                retire(t,'finish_pending_legacy_replacement',t['elapsed_seconds']);t['wall_seconds']=minutes*60;changed=True;continue
            capped=status.get('state')=='capped' or t.get('slurm_state')=='TIMEOUT'
            if capped and t.get('recovery_retries',0)<1:
                retire(t,'resume_capped_screen',t['elapsed_seconds'])
                t['recovery_retries']=t.get('recovery_retries',0)+1;t['wall_seconds']=minutes*60;changed=True
                print('Scheduled checkpoint continuation:',t['target'],flush=True)
        return changed
    w.refresh=refresh;w.accounting=accounting
    def vista_run(command,*args,**kwargs):
        result=ORIGINAL_RUN(command,*args,**kwargs)
        if command[0]=='sbatch' and result.returncode==0:
            with (batch/'logs/submission_responses.log').open('a') as log:log.write(result.stdout+'\n')
            result.stdout=parse_job_id(result.stdout)+'\n'
        return result
    subprocess.run=vista_run
    import screen
    def select(config,run):
        records=[];excluded=[]
        for spec in config['targets']:
            p=batch/'targets'/spec['id']/'screen.json'
            if valid_screen(batch,spec['id']):records.append(read(p))
            else:excluded.append(spec['id'])
        controls=[s['id'] for s in config['targets'] if s.get('control')]
        if any(not valid_screen(batch,n) for n in controls):raise RuntimeError('A completed control is missing/invalid; no automatic rerun')
        selected=[]
        for problem in ['navier_stokes','allen_cahn','helmholtz']:
            choices=[r for r in records if r['problem']==problem and not r['control'] and r['geometry_candidate']]
            selected += [r['target'] for r in sorted(choices,key=lambda r:r['geometry_score'],reverse=True)[:config['limits']['max_per_pde']]]
        selected=selected[:config['limits']['max_changed_full']]
        result=dict(targets=selected,controls=controls,records=records,excluded_incomplete_or_invalid_reference=excluded,reasons={n:'completed screen with passing reference quality' for n in selected},selection_uses_sampler_rankings=False)
        write(batch/'selection.json',result);return result
    screen.select=select

def job_details(job):
    p=ORIGINAL_RUN(['scontrol','show','job','-o',job],capture_output=True,text=True,check=True)
    return p.stdout

def field(text,name):
    m=re.search(r'(?:^|\s)'+name+r'=(\S+)',text);return m.group(1) if m else None

def live_jobs():
    p=ORIGINAL_RUN(['squeue','-h','-u',str(os.getuid()),'-o','%i|%T'],capture_output=True,text=True,check=True)
    return dict(line.strip().split('|',1) for line in p.stdout.splitlines() if '|' in line)

def reconcile(batch,state,cfg):
    # Recover an active submission orphaned between sbatch and scheduler write.
    roster={s['id'] for s in cfg['targets']};known={t['job_id'] for t in state['tasks'].values() if t.get('job_id')}
    for job,queue_state in live_jobs().items():
        if not job.isdigit() or job in known:continue
        try:text=job_details(job)
        except subprocess.CalledProcessError:continue  # Job left the queue; known jobs still reconciled by sacct.
        if field(text,'WorkDir')!=str(batch/'code'):continue
        stdout=field(text,'StdOut')
        match=re.fullmatch(re.escape(str(batch/'logs'))+r'/screen_(.+)_'+re.escape(job)+r'\.log',stdout or '')
        if not match or match[1] not in roster:raise RuntimeError('Unrecognized active job in this batch; inspect '+job)
        name=match[1];key='screen:'+name
        t=state['tasks'].setdefault(key,dict(target=name,stage='screen',wall_seconds=2700,state='planned'))
        if t.get('job_id') and t['job_id']!=job:raise RuntimeError('Possible duplicate jobs for '+name)
        t.update(job_id=job,state='running' if queue_state=='RUNNING' else 'submitted',submitted=time.time())
        print('Recovered tracked submission',job,name,flush=True)
    write(batch/'scheduler.json',state)

def acquire_pausing_controller(batch):
    handle=(batch/'controller.lock').open('a')
    try:fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB);return handle
    except BlockingIOError:pass
    target=(batch/'controller.lock').stat();owners=[]
    for path in Path('/proc').glob('[0-9]*'):
        try:
            if path.stat().st_uid!=os.getuid() or int(path.name)==os.getpid():continue
            cmd=(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
            if not ('resume_controller.py' in cmd or 'recover.py' in cmd or ('workflow.py' in cmd and 'watch' in cmd)):continue
            for fd in (path/'fd').iterdir():
                try:st=fd.stat()
                except OSError:continue
                if (st.st_dev,st.st_ino)==(target.st_dev,target.st_ino):owners.append(int(path.name));break
        except (OSError,ValueError):continue
    if len(owners)!=1:raise RuntimeError('Could not identify exactly one controller holding this batch lock; no process stopped')
    print('Pausing controller PID',owners[0],flush=True);os.kill(owners[0],signal.SIGTERM)
    for _ in range(60):
        try:fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB);return handle
        except BlockingIOError:time.sleep(.5)
    raise RuntimeError('Controller lock was not released; inspect the process before retrying')

def wait_for_submissions(batch):
    # A subprocess already inside sbatch can outlive a stopped controller.
    # Wait for such submissions to settle before reconciling job IDs.
    for _ in range(60):
        found=False
        for path in Path('/proc').glob('[0-9]*'):
            try:
                if path.stat().st_uid!=os.getuid() or int(path.name)==os.getpid():continue
                cmd=(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
                if 'sbatch' in cmd and str(batch) in cmd:found=True;break
            except (OSError,ValueError):continue
        if not found:return
        time.sleep(.5)
    raise RuntimeError('A submission subprocess is still active; controller paused. Retry after it settles.')

def apply(batch,minutes):
    sys.path.insert(0,str(batch/'code'));import workflow as w
    if w.code_identity()!=read(batch/'identity.json')['code_identity']:raise RuntimeError('Installed frozen source differs from its recorded identity; stop for review')
    cfg=read(batch/'campaign.json');state=read(batch/'scheduler.json')
    if cfg['limits']['max_inflight']!=2 or cfg['limits']['node_hours']!=48:raise RuntimeError('Unexpected campaign limits; no changes made')
    print('Live queue:',live_jobs(),flush=True)
    print('Recorded phase:',state['phase'],flush=True)
    if state['phase']!='screen':raise RuntimeError('Campaign has advanced beyond screening; inspect selection and jobs before applying this screen-only recovery')
    # A single installer owns recovery, including the pause/restart interval.
    with (batch/'recovery_install.lock').open('a') as installer:
        fcntl.flock(installer,fcntl.LOCK_EX|fcntl.LOCK_NB)
        backup=batch/'recovery_backups'/time.strftime('%Y%m%d_%H%M%S');backup.mkdir(parents=True)
        for name in ['campaign.json','scheduler.json','resume_controller.py','controller.pid','controller.host']:
            if (batch/name).exists():shutil.copy2(batch/name,backup/name)
        with acquire_pausing_controller(batch):
            wait_for_submissions(batch)
            state=read(batch/'scheduler.json');cfg=read(batch/'campaign.json')
            if state['phase']!='screen':raise RuntimeError('Phase changed while pausing; recovery stopped for review')
            # Refresh backups under the lock, before mutations.
            for name in ['campaign.json','scheduler.json']:shutil.copy2(batch/name,backup/name)
            reconcile(batch,state,cfg);w.refresh(state,batch)
            originals=[s['id'] for s in cfg['targets'] if s.get('control')]
            for name in originals:
                if not valid_screen(batch,name):raise RuntimeError('Original control not complete/valid: '+name)
            cfg['limits']['screen_minutes']=minutes
            write(batch/'campaign.json',cfg)
            for t in state['tasks'].values():
                if t['stage']!='screen' or t['target'] in originals:continue
                if t['state']=='planned':t['wall_seconds']=minutes*60;continue
                if t['state']=='finished' and t.get('pending_replacement'):
                    retire(t,'finish_pending_legacy_replacement',t['elapsed_seconds']);t['wall_seconds']=minutes*60;write(batch/'scheduler.json',state);continue
                if t['state'] not in ['submitted','running'] or t['wall_seconds']>=minutes*60:continue
                job=t['job_id'];text=job_details(job)
                if field(text,'WorkDir')!=str(batch/'code') or field(text,'StdOut')!=str(batch/'logs'/('screen_'+t['target']+'_'+job+'.log')):raise RuntimeError('Job identity mismatch; refusing to cancel '+job)
                if field(text,'JobState')!='PENDING':
                    print('Keeping running legacy job',job,'until it completes/caps; continuation will use',minutes,'minutes',flush=True);continue
                # Holding prevents a pending job starting between inspection and cancellation.
                t['pending_replacement']=True;write(batch/'scheduler.json',state)
                ORIGINAL_RUN(['scontrol','hold',job],check=True)
                if field(job_details(job),'JobState')!='PENDING':raise RuntimeError('Job state changed while holding '+job)
                ORIGINAL_RUN(['scancel',job],check=True)
                row=None
                for _ in range(30):
                    row=elapsed_rows([job]).get(job)
                    if row and row['state'] in TERMINAL:break
                    time.sleep(1)
                else:raise RuntimeError('Cancellation accounting not ready. Controller is paused; rerun recovery after sacct settles.')
                t.update(slurm_state=row['state'],result='replaced_pending_short_limit')
                retire(t,'replace_held_pending_legacy_limit',row['elapsed_seconds']);t['wall_seconds']=minutes*60
                write(batch/'scheduler.json',state)
            state['accounting']=dict(accounting(state),cap_node_hours=48,max_inflight=2)
            write(batch/'scheduler.json',state)
            print('Backups:',backup,flush=True);print('Accounting:',state['accounting'],flush=True)
        # The replacement controller will reacquire the normal lock; it never edits code/.
        script=Path(__file__).resolve();log=(batch/'logs/controller.log').open('a')
        child=subprocess.Popen([sys.executable,'-u',str(script),'controller','--batch',str(batch),'--minutes',str(minutes)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        (batch/'controller.pid').write_text(str(child.pid)+'\n');(batch/'controller.host').write_text(socket.gethostname()+'\n')
        print('Replacement controller PID:',child.pid,flush=True)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['inspect','apply','controller']);p.add_argument('--batch',required=True);p.add_argument('--minutes',type=int,default=120);args=p.parse_args()
    batch=Path(args.batch).resolve()
    if args.minutes not in [90,100,120]:raise ValueError('Choose 90, 100, or 120 minutes; default 120')
    if args.mode=='inspect':
        state=read(batch/'scheduler.json');print(json.dumps(dict(queue=live_jobs(),scheduler=state,Slurm=elapsed_rows([t['job_id'] for t in state['tasks'].values() if t.get('job_id')])),indent=2));return
    if args.mode=='apply':apply(batch,args.minutes);return
    sys.path.insert(0,str(batch/'code'));import workflow as w
    patch_runtime(w,batch,args.minutes)
    w.watch(batch,poll=60)
if __name__=='__main__':main()
