import importlib.util,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('recovery',HERE/'recover.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)

class Tests(unittest.TestCase):
 def test_banner(self):
  for s in ['Vista banner\n1116982\n','1116982;vista\n','Submitted batch job 1116982\n']:
   self.assertEqual(r.parse_job_id(s),'1116982')
  with self.assertRaises(RuntimeError):r.parse_job_id('111\n222\n')
 def test_history_charged_once(self):
  t=dict(target='ns',stage='screen',state='finished',job_id='1',wall_seconds=2700,elapsed_seconds=2600,result='capped',slurm_state='FAILED')
  r.retire(t,'resume',2600);t.update(state='submitted',job_id='2',wall_seconds=7200)
  a=r.accounting({'tasks':{'x':t}})
  self.assertEqual(a['completed_node_hours'],2600/3600);self.assertEqual(a['reserved_inflight_node_hours'],2)
  t.update(state='finished',elapsed_seconds=4000)
  self.assertEqual(r.accounting({'tasks':{'x':t}})['completed_node_hours'],6600/3600)
 def test_strict_screen(self):
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp)/'targets/ns';(d/'screen_reference').mkdir(parents=True)
   r.write(d/'screen_status.json',{'state':'complete'});r.write(d/'screen.json',{'reference_usable':True,'binding':'a'})
   r.write(d/'screen_reference/quality.json',{'reference_usable':False,'binding':'a'});(d/'screen_reference/samples.npz').write_bytes(b'checked by worker')
   self.assertFalse(r.valid_screen(Path(tmp),'ns'))
   r.write(d/'screen_reference/quality.json',{'reference_usable':True,'binding':'a'});self.assertTrue(r.valid_screen(Path(tmp),'ns'))
   r.write(d/'screen_status.json',{'state':'capped'});self.assertFalse(r.valid_screen(Path(tmp),'ns'))
 def test_retry_limited_and_pending_seconds(self):
  with tempfile.TemporaryDirectory() as tmp:
   b=Path(tmp);(b/'logs').mkdir();r.write(b/'campaign.json',{'targets':[{'id':'original','control':True}]})
   fake=SimpleNamespace(refresh=lambda state,path:False)
   with patch.dict(sys.modules,{'screen':SimpleNamespace()}):
    try:r.patch_runtime(fake,b,120)
    finally:r.subprocess.run=r.ORIGINAL_RUN
   t={'stage':'screen','target':'ns','state':'finished','result':'capped','slurm_state':'TIMEOUT','elapsed_seconds':2700,'job_id':'1','wall_seconds':2700}
   state={'tasks':{'ns':t,'plan':{'stage':'screen','target':'later','state':'planned','wall_seconds':2700}}}
   fake.refresh(state,b);self.assertEqual(t['state'],'planned');self.assertEqual(t['wall_seconds'],7200);self.assertEqual(state['tasks']['plan']['wall_seconds'],7200)
   t.update(state='finished',job_id='2',elapsed_seconds=7200,slurm_state='TIMEOUT',result='capped')
   fake.refresh(state,b);self.assertEqual(t['state'],'finished');self.assertEqual(t['recovery_retries'],1)
if __name__=='__main__':unittest.main(verbosity=2)
