# Branch-one Vista: minimal wall-time recovery

Upload this small ZIP to the existing GAD_IP directory. It contains no model/data replacements. Run on **login2**, where the current controller lives:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/
unzip -q GAD_branch1_minimal_patch.zip
source GAD_branch1_vista/slurm/environment.sh
python GAD_branch1_minimal_patch/recover.py apply \
  --batch batches/gad_branch1_20261102
```

This inspects current Slurm state at execution time. It verifies the frozen source identity and 48-node-hour/two-job limits; backs up scheduler/config/recovery-shim files; identifies and pauses only the controller holding this batch's lock; reconciles queued submissions; and starts one replacement controller with the Vista banner parser retained. A second installer/controller cannot own the same locks.

Changed-reference screen allocations become **120 minutes**, including both Slurm and the worker's internal deadline. Already-running 45-minute workers are allowed to finish or cap; a capped/timed-out screen receives at most **one** checkpoint continuation at the new limit. Already-pending short-limit jobs are held, canceled, reconciled in Slurm accounting, then replaced under their registered logical task. Only verified jobs whose working directory and log belong to this batch can be held/canceled. Separate g4pub jobs are untouched.

All prior attempts remain in scheduler `attempts`, with their real allocated elapsed seconds charged exactly once. Completed controls retain their statuses and reference files. Current running legacy jobs retain their true 45-minute reservation until completion; replacements reserve the full new 120 minutes. The global cap remains 48 allocated GH node-hours with at most two live jobs. This cap can leave part of the sweep unresolved; there are no unbounded retries.

No frozen `code/` file is edited, so existing target, MAP and NUTS checkpoint bindings remain valid. No seed, target, particle count, reference sample count or NUTS kernel changes. The existing reference loop reuses completed warmup files and restores the serialized sampler state and PRNG from each completed chunk. Completed chains/chunks are not resampled. A warmup or draw chunk interrupted before its atomic checkpoint must be repeated; that lost attempt's elapsed allocation is retained in accounting.

Candidate selection now requires a complete screen status, reference sample file, passing reference-quality record and matching screen/reference bindings. Failed, capped, timed-out or low-quality references cannot automatically promote a changed target. Full sampler comparisons of the original controls remain part of the original plan; completed *screening* controls are not repeated.

If live state has already advanced beyond screening, source identity has changed, a control is incomplete, Slurm accounting is unavailable, or the owning controller cannot be identified on this host, recovery stops explicitly rather than guessing. If accounting lags after a cancellation, the controller remains paused; rerun the same apply command once sacct has settled. Pending replacement intents are recorded before cancellation, so that rerun preserves the job's elapsed cost.

Check after applying:

```bash
tail -n 15 batches/gad_branch1_20261102/logs/controller.log
squeue -u "$USER"
python batches/gad_branch1_20261102/code/workflow.py status \
  --batch batches/gad_branch1_20261102
```

To inspect without changing jobs or state:

```bash
python GAD_branch1_minimal_patch/recover.py inspect \
  --batch batches/gad_branch1_20261102
```

Use this recovery entry point for future controller recovery. Do not relaunch the original unpatched watcher.
