# Model and synthetic data preserved from the source recorded in provenance/catalog.json.
# Import only from run_problem.py, which assigns an isolated working directory.
import os
import random
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import torch
from scipy.spatial.distance import cdist
jax.config.update("jax_enable_x64", True)
os.makedirs("data", exist_ok=True)
N = 32
x = np.linspace(0.0, 1.0, N, endpoint=False)
X, Y = np.meshgrid(x, x, indexing='ij')
coords = np.column_stack([X.ravel(), Y.ravel()])

ELL = 0.10
SIGMA_PRIOR = 1.0
q_max = 100

dists = cdist(coords, coords)
C = SIGMA_PRIOR ** 2 * np.exp(-dists / ELL)
eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]
Basis_Modes = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])
np.savetxt('data/AdvecDiff_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# 1. Configuration / data files
# ==========================================
num_observation = 25
num_holdout_observation = 25
num_truncated_series = 32
seed = int(os.environ.get("GAD_SCREEN_SEED", "42"))

dimension_of_PoI = N * N
num_modes_available = Basis_Modes.shape[1]
basis_truncated = Basis_Modes[:, :num_truncated_series]

key = jax.random.PRNGKey(seed)
obs_indices_train = np.array(
    jax.random.choice(key, jnp.arange(dimension_of_PoI), shape=(num_observation,), replace=False)
)
remaining_indices = np.setdiff1d(np.arange(dimension_of_PoI), obs_indices_train)
key_holdout = jax.random.PRNGKey(seed + 1)
obs_indices_holdout = np.array(
    jax.random.choice(key_holdout, jnp.array(remaining_indices), shape=(num_holdout_observation,), replace=False)
)
obs_indices = obs_indices_train

pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(obs_indices_train).to_csv('data/obs_locations.csv', index=False, header=False)

# ==========================================
# 2. Physics: periodic advection-diffusion
# ==========================================
jax.config.update("jax_enable_x64", True)

Basis = jnp.array(basis_truncated, dtype=jnp.float64)
obs_locations_train = jnp.array(obs_indices_train, dtype=int)
obs_locations_holdout = jnp.array(obs_indices_holdout, dtype=int)
obs_locations = obs_locations_train

x_1d = jnp.linspace(0.0, 1.0, N, endpoint=False)
X_grid, Y_grid = jnp.meshgrid(x_1d, x_1d, indexing='ij')

OBS_TIME = 0.5
DIFFUSIVITY = 2.5e-3
ADV_VX = 0.90
ADV_VY = -0.55
NOISE_STD = 0.01

kx_1d = 2.0 * jnp.pi * jnp.fft.fftfreq(N, d=1.0 / N)
ky_1d = 2.0 * jnp.pi * jnp.fft.fftfreq(N, d=1.0 / N)
KX, KY = jnp.meshgrid(kx_1d, ky_1d, indexing='ij')
K2 = KX ** 2 + KY ** 2
ADV_PHASE = ADV_VX * KX + ADV_VY * KY


def _propagate_advection_diffusion(u0_field, t=OBS_TIME):
    """Exact periodic advection-diffusion propagator in Fourier space."""
    u0_hat = jnp.fft.fftn(u0_field)
    propagator = jnp.exp((-DIFFUSIVITY * K2 - 1j * ADV_PHASE) * t)
    ut_hat = u0_hat * propagator
    ut_field = jnp.real(jnp.fft.ifftn(ut_hat))
    return ut_field


@jax.jit
def solve_forward(alpha):
    u0 = jnp.reshape(Basis @ alpha, (N, N))
    uT = _propagate_advection_diffusion(u0, OBS_TIME)
    return uT.reshape(-1)[obs_locations_train]


@jax.jit
def solve_forward_holdout(alpha):
    u0 = jnp.reshape(Basis @ alpha, (N, N))
    uT = _propagate_advection_diffusion(u0, OBS_TIME)
    return uT.reshape(-1)[obs_locations_holdout]


@jax.jit
def solve_full_state(alpha, t=OBS_TIME):
    u0 = jnp.reshape(Basis @ alpha, (N, N))
    return _propagate_advection_diffusion(u0, t)


# ==========================================
# Shared sampling configuration
# ==========================================

ACTIVE_DIM = num_truncated_series

np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
np.random.seed(seed)


def make_structured_truth_coefficients(active_dim=ACTIVE_DIM):
    """Build a structured synthetic initial condition and project it into the KL basis."""
    X_np = np.array(X_grid)
    Y_np = np.array(Y_grid)
    truth_field = (
        1.40 * np.exp(-((X_np - 0.23) ** 2 + (Y_np - 0.31) ** 2) / (2.0 * 0.075 ** 2))
        - 1.15 * np.exp(-((X_np - 0.70) ** 2 + (Y_np - 0.66) ** 2) / (2.0 * 0.11 ** 2))
        + 0.45 * np.sin(2.0 * np.pi * (X_np + 0.35 * Y_np))
        + 0.30 * np.cos(2.0 * np.pi * (2.0 * Y_np - 0.5 * X_np))
    )
    truth_field = truth_field - truth_field.mean()
    B = basis_truncated[:, :active_dim]
    coeffs, *_ = np.linalg.lstsq(B, truth_field.reshape(-1), rcond=None)
    return coeffs.astype(np.float64), truth_field.astype(np.float64)


alpha_true_np, true_u0_target = make_structured_truth_coefficients(ACTIVE_DIM)
y_clean = solve_forward(jnp.array(alpha_true_np))
y_clean_np = np.array(y_clean)
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_holdout_clean_np = np.array(solve_forward_holdout(jnp.array(alpha_true_np)))
y_holdout_obs_np = y_holdout_clean_np + np.random.normal(0.0, NOISE_STD, size=y_holdout_clean_np.shape)


def field_from_latent(alpha):
    return np.asarray(Basis @ jnp.asarray(alpha)).reshape((N, N))

true_field = field_from_latent(alpha_true_np)
y_holdout_clean_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))

def state_from_latent(alpha):
    return np.asarray(solve_full_state(jnp.asarray(alpha)))
