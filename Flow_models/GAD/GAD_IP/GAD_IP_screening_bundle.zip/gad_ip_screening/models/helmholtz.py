# Model and synthetic data preserved from the source recorded in provenance/catalog.json.
# Import only from run_problem.py, which assigns an isolated working directory.
import os
import random
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import torch
from scipy.spatial.distance import cdist
jax.config.update("jax_enable_x64", True)
os.makedirs("data", exist_ok=True)
N = 32
x = np.linspace(0.0, 1.0, N)
X, Y = np.meshgrid(x, x)
coords = np.column_stack([X.ravel(), Y.ravel()])

ell = 0.10
sigma_prior = 1.0
dists = cdist(coords, coords)
C = sigma_prior ** 2 * np.exp(-dists / ell)

eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]
q_max = 100
Basis_Modes = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])
np.savetxt('data/Helmholtz_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# Config
# ==========================================
num_truncated_series = 32
seed = int(os.environ.get("GAD_SCREEN_SEED", "42"))
HELMHOLTZ_K = 24.0
HELMHOLTZ_DAMPING = 6.0
BACKGROUND_N2 = 1.0
SCATTERER_AMPLITUDE = 0.45
SCATTERER_RADIUS = 0.30
SCATTERER_SOFTNESS = 0.035
N_SOURCES = 4
N_RECEIVERS = 64
N_HOLDOUT_RECEIVERS = None
SOURCE_WIDTH = 0.055


def _ordered_boundary_indices(n):
    idx = []
    for j in range(n):
        idx.append(0 * n + j)
    for i in range(1, n):
        idx.append(i * n + (n - 1))
    for j in range(n - 2, -1, -1):
        idx.append((n - 1) * n + j)
    for i in range(n - 2, 0, -1):
        idx.append(i * n + 0)
    return np.array(idx, dtype=int)


boundary_indices_ordered = _ordered_boundary_indices(N)
n_boundary = len(boundary_indices_ordered)
receiver_spacing = n_boundary / N_RECEIVERS
receiver_boundary_pos = np.round(np.arange(N_RECEIVERS) * receiver_spacing).astype(int)
receiver_boundary_pos = np.clip(receiver_boundary_pos, 0, n_boundary - 1)
receiver_boundary_pos = np.unique(receiver_boundary_pos)
receiver_flat_indices = boundary_indices_ordered[receiver_boundary_pos]
remaining_boundary_pos = np.setdiff1d(np.arange(n_boundary), receiver_boundary_pos)
if N_HOLDOUT_RECEIVERS is None:
    N_HOLDOUT_RECEIVERS = remaining_boundary_pos.size
else:
    N_HOLDOUT_RECEIVERS = min(int(N_HOLDOUT_RECEIVERS), remaining_boundary_pos.size)
holdout_boundary_pos = remaining_boundary_pos[:N_HOLDOUT_RECEIVERS]
holdout_receiver_flat_indices = boundary_indices_ordered[holdout_boundary_pos]
rr = np.sqrt((X - 0.5) ** 2 + (Y - 0.5) ** 2)
support_mask = 1.0 / (1.0 + np.exp((rr - SCATTERER_RADIUS) / SCATTERER_SOFTNESS))
source_centers = np.array([[0.18, 0.22], [0.82, 0.26], [0.74, 0.82], [0.24, 0.76]], dtype=np.float64)

source_terms = []
for sx, sy in source_centers:
    direction = np.array([0.5 - sx, 0.5 - sy], dtype=np.float64)
    direction /= np.linalg.norm(direction) + 1e-12
    dist2 = (X - sx) ** 2 + (Y - sy) ** 2
    envelope = np.exp(-0.5 * dist2 / (SOURCE_WIDTH ** 2))
    phase = np.exp(1j * HELMHOLTZ_K * (direction[0] * (X - sx) + direction[1] * (Y - sy)))
    src = envelope * phase
    src = src / np.sqrt(np.sum(np.abs(src) ** 2) + 1e-12)
    source_terms.append(src.reshape(-1))
source_terms = np.stack(source_terms, axis=1)

num_observation = N_SOURCES * 2 * N_RECEIVERS
num_holdout_observation = N_SOURCES * 2 * N_HOLDOUT_RECEIVERS
dimension_of_PoI = N * N

df_modes = pd.read_csv('data/Helmholtz_Basis_Modes.csv', header=None)
modes_raw = df_modes.to_numpy().flatten().astype(np.float64)
num_modes_available = modes_raw.size // dimension_of_PoI
full_basis = modes_raw.reshape((dimension_of_PoI, num_modes_available))
basis_truncated = full_basis[:, :num_truncated_series]
pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(receiver_flat_indices).to_csv('data/obs_locations.csv', index=False, header=False)

# ==========================================
# Physics
# ==========================================
jax.config.update("jax_enable_x64", True)
Basis = jnp.array(basis_truncated)
support_mask_jax = jnp.array(support_mask, dtype=jnp.float64)
receiver_indices_jax = jnp.array(receiver_flat_indices, dtype=int)
holdout_receiver_indices_jax = jnp.array(holdout_receiver_flat_indices, dtype=int)
boundary_indices_jax = jnp.array(boundary_indices_ordered, dtype=int)
source_terms_jax = jnp.array(source_terms, dtype=jnp.complex128)

h = 1.0 / (N - 1)
n_total = N * N
_xface_left = (jnp.arange(N - 1)[:, None] * N + jnp.arange(N)[None, :]).ravel()
_xface_right = _xface_left + N
_yface_bot = (jnp.arange(N)[:, None] * N + jnp.arange(N - 1)[None, :]).ravel()
_yface_top = _yface_bot + 1


def _assemble_negative_laplacian():
    weight = 1.0 / (h * h)
    A = jnp.zeros((n_total, n_total), dtype=jnp.complex128)
    A = A.at[_xface_left, _xface_left].add(weight)
    A = A.at[_xface_right, _xface_right].add(weight)
    A = A.at[_xface_left, _xface_right].add(-weight)
    A = A.at[_xface_right, _xface_left].add(-weight)
    A = A.at[_yface_bot, _yface_bot].add(weight)
    A = A.at[_yface_top, _yface_top].add(weight)
    A = A.at[_yface_bot, _yface_top].add(-weight)
    A = A.at[_yface_top, _yface_bot].add(-weight)
    return A


NEG_LAPLACIAN = _assemble_negative_laplacian()
IDENTITY_WAVE = jnp.eye(n_total, dtype=jnp.complex128)


def _flatten_measurements_by_source(meas_complex):
    parts = []
    for s in range(N_SOURCES):
        parts.append(jnp.real(meas_complex[:, s]))
        parts.append(jnp.imag(meas_complex[:, s]))
    return jnp.concatenate(parts, axis=0)


def _flatten_measurements_by_source_generic(meas_complex, n_receivers):
    parts = []
    for s in range(N_SOURCES):
        parts.append(jnp.real(meas_complex[:n_receivers, s]))
        parts.append(jnp.imag(meas_complex[:n_receivers, s]))
    return jnp.concatenate(parts, axis=0)



def _alpha_to_raw_and_contrast(alpha):
    raw_field = jnp.reshape(Basis @ alpha, (N, N))
    contrast = SCATTERER_AMPLITUDE * jnp.tanh(raw_field) * support_mask_jax
    n2_field = BACKGROUND_N2 + contrast
    return raw_field, contrast, n2_field



def _assemble_helmholtz_operator(n2_field):
    diag = -(HELMHOLTZ_K ** 2) * n2_field.reshape(-1)
    return NEG_LAPLACIAN + jnp.diag(diag.astype(jnp.complex128)) + 1j * HELMHOLTZ_DAMPING * IDENTITY_WAVE


BACKGROUND_OPERATOR = _assemble_helmholtz_operator(jnp.ones((N, N), dtype=jnp.float64) * BACKGROUND_N2)
BACKGROUND_FIELDS = jnp.linalg.solve(BACKGROUND_OPERATOR, source_terms_jax)


@jax.jit
def solve_forward(alpha):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    U_total = jnp.linalg.solve(A, source_terms_jax)
    U_scat = U_total - BACKGROUND_FIELDS
    meas = U_scat[receiver_indices_jax, :]
    return _flatten_measurements_by_source(meas)


@jax.jit
def solve_forward_holdout(alpha):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    U_total = jnp.linalg.solve(A, source_terms_jax)
    U_scat = U_total - BACKGROUND_FIELDS
    meas = U_scat[holdout_receiver_indices_jax, :]
    return _flatten_measurements_by_source_generic(meas, holdout_receiver_indices_jax.shape[0])


batch_solve_forward_holdout = jax.jit(jax.vmap(solve_forward_holdout))


@jax.jit
def solve_single_pattern(alpha, pattern_idx):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    u_total = jnp.linalg.solve(A, source_terms_jax[:, pattern_idx])
    u_scat = u_total - BACKGROUND_FIELDS[:, pattern_idx]
    return u_scat.reshape(N, N)


@jax.jit
def solve_single_total_field(alpha, pattern_idx):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    u_total = jnp.linalg.solve(A, source_terms_jax[:, pattern_idx])
    return u_total.reshape(N, N)


# === END PRESERVED HELMHOLTZ MODEL ===

# === NS-ANALOGOUS SAMPLER SETTINGS ===

ACTIVE_DIM = num_truncated_series
NOISE_STD = 4e-4

np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
mode_decay = np.linspace(1.0, 0.45, ACTIVE_DIM)
alpha_true_np = 0.95 * np.random.randn(ACTIVE_DIM) * mode_decay
y_clean_np = np.asarray(solve_forward(jnp.asarray(alpha_true_np)))
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_clean_holdout_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))
y_holdout_obs_np = y_clean_holdout_np + np.random.normal(0.0, NOISE_STD, size=y_clean_holdout_np.shape)


def field_from_latent(alpha):
    return np.asarray(_alpha_to_raw_and_contrast(jnp.asarray(alpha))[1])

true_field = field_from_latent(alpha_true_np)
y_holdout_clean_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))

def state_from_latent(alpha):
    scattered = np.asarray(solve_single_pattern(jnp.asarray(alpha), 0))
    return np.log10(np.abs(scattered) + 1e-12)
