# Model and synthetic data preserved from the source recorded in provenance/catalog.json.
# Import only from run_problem.py, which assigns an isolated working directory.
import os
import random
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import torch
from scipy.spatial.distance import cdist
jax.config.update("jax_enable_x64", True)
os.makedirs("data", exist_ok=True)
GRID_SIZE = 16
N = 15  # legacy latent dimension symbol used in prior files / old logs
num_observation = 10  # Actual length of the preserved sensor list.
num_truncated_series = 24
num_modes_available = 24
seed = int(os.environ.get("GAD_SCREEN_SEED", "42"))
prior_length_scale = 0.1
ROOT_EDGE = 'top'
SIGMA_PRIOR = 1.0

obs_indices = np.array([7, 32, 52, 110, 121, 150, 156, 177, 210, 236], dtype=int)


def build_heat_kl_basis(grid_size, q_max=15, length_scale=0.18, sigma_prior=1.0):
    """
    Build a self-contained KL-style basis on the node grid using an exponential
    covariance kernel, replacing the old external eigen/sigma files.
    """
    x = np.linspace(0.0, 1.0, grid_size)
    X, Y = np.meshgrid(x, x, indexing='ij')
    coords = np.column_stack([X.ravel(), Y.ravel()])
    dists = np.sqrt(((coords[:, None, :] - coords[None, :, :]) ** 2).sum(axis=2))
    C = sigma_prior ** 2 * np.exp(-dists / length_scale)
    C = 0.5 * (C + C.T)
    eigvals, eigvecs = np.linalg.eigh(C)
    idx = np.argsort(eigvals)[::-1]
    eigvals = np.clip(eigvals[idx], 0.0, None)
    eigvecs = eigvecs[:, idx]
    basis = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])[None, :]
    return basis.astype(np.float64), eigvals[:q_max].astype(np.float64)



def build_free_mask(grid_size, root_edge='top'):
    free_mask = np.zeros((grid_size, grid_size), dtype=bool)
    free_mask[1:-1, 1:-1] = True
    if root_edge == 'top':
        free_mask[0, 1:-1] = True
    elif root_edge == 'bottom':
        free_mask[-1, 1:-1] = True
    elif root_edge == 'left':
        free_mask[1:-1, 0] = True
    elif root_edge == 'right':
        free_mask[1:-1, -1] = True
    else:
        raise ValueError(f"Unknown ROOT_EDGE={root_edge}")
    return free_mask


full_basis, basis_eigs = build_heat_kl_basis(
    grid_size=GRID_SIZE,
    q_max=num_modes_available,
    length_scale=prior_length_scale,
    sigma_prior=SIGMA_PRIOR,
)
basis_truncated = full_basis[:, :num_truncated_series]
basis_modes_path = 'data/Heat_Basis_Modes_generated.csv'

pd.DataFrame(full_basis).to_csv(basis_modes_path, index=False, header=False)
pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(obs_indices).to_csv('data/obs_locations.csv', index=False, header=False)

free_mask_np = build_free_mask(GRID_SIZE, ROOT_EDGE)
free_index_np = np.where(free_mask_np.ravel())[0].astype(np.int64)
pd.DataFrame(free_index_np).to_csv('data/free_index.csv', index=False, header=False)

_train_obs_indices_set = set(int(i) for i in np.asarray(obs_indices).tolist())
_holdout_candidate_indices = np.array(
    [int(i) for i in free_index_np.tolist() if int(i) not in _train_obs_indices_set],
    dtype=int,
)
_holdout_rng = np.random.default_rng(seed + 137)
n_holdout_observation = min(len(np.asarray(obs_indices)), _holdout_candidate_indices.size)
if n_holdout_observation > 0:
    heldout_obs_indices = np.sort(
        _holdout_rng.choice(_holdout_candidate_indices, size=n_holdout_observation, replace=False)
    ).astype(int)
else:
    heldout_obs_indices = np.array([], dtype=int)

pd.DataFrame(heldout_obs_indices).to_csv('data/heldout_obs_locations.csv', index=False, header=False)

# ==========================================
# 1. Physics: bespoke mixed-BC heat equation
# ==========================================
jax.config.update("jax_enable_x64", True)

DIMENSION_OF_POI = GRID_SIZE ** 2
Basis = jnp.array(basis_truncated, dtype=jnp.float64)
obs_locations = jnp.array(obs_indices, dtype=int)
heldout_obs_locations = jnp.array(heldout_obs_indices, dtype=int)
free_index = jnp.array(free_index_np, dtype=int)

G = GRID_SIZE
h = 1.0 / (G - 1)
x_1d = jnp.linspace(0.0, 1.0, G)
X_grid, Y_grid = jnp.meshgrid(x_1d, x_1d, indexing='ij')
source_field = 20.0 * jnp.ones((G, G), dtype=jnp.float64)
NOISE_STD = 0.0075

free_mask = jnp.array(free_mask_np)
free_rows_np, free_cols_np = np.where(free_mask_np)
free_rows = jnp.array(free_rows_np, dtype=jnp.int32)
free_cols = jnp.array(free_cols_np, dtype=jnp.int32)
n_free = free_rows.shape[0]
free_id = -jnp.ones((G, G), dtype=jnp.int32)
free_id = free_id.at[free_rows, free_cols].set(jnp.arange(n_free, dtype=jnp.int32))

obs_operator_np = np.zeros((num_observation, n_free), dtype=np.float64)
free_lookup = {int(idx): ii for ii, idx in enumerate(np.array(free_index_np))}
for row, idx in enumerate(obs_indices):
    if int(idx) in free_lookup:
        obs_operator_np[row, free_lookup[int(idx)]] = 1.0
obs_operator = jnp.array(obs_operator_np, dtype=jnp.float64)



def _assemble_heat_system(k_field):
    """
    Assemble the dense linear system for
        -div(k(x) grad w(x)) = 20,
    with homogeneous Dirichlet on the exterior boundary except for one root edge
    carrying homogeneous Neumann data.
    """
    h2 = h * h
    k_ip = 2.0 * k_field[:-1, :] * k_field[1:, :] / (k_field[:-1, :] + k_field[1:, :] + 1e-30)
    k_jp = 2.0 * k_field[:, :-1] * k_field[:, 1:] / (k_field[:, :-1] + k_field[:, 1:] + 1e-30)

    fr = free_rows
    fc = free_cols
    idx = jnp.arange(n_free)

    c_down = jnp.where(fr < G - 1, k_ip[fr, fc] / h2, 0.0)
    c_up = jnp.where(fr > 0, k_ip[fr - 1, fc] / h2, 0.0)
    c_right = jnp.where(fc < G - 1, k_jp[fr, fc] / h2, 0.0)
    c_left = jnp.where(fc > 0, k_jp[fr, fc - 1] / h2, 0.0)

    nbr_down = jnp.where(fr < G - 1, free_id[fr + 1, fc], -1)
    nbr_up = jnp.where(fr > 0, free_id[fr - 1, fc], -1)
    nbr_right = jnp.where(fc < G - 1, free_id[fr, fc + 1], -1)
    nbr_left = jnp.where(fc > 0, free_id[fr, fc - 1], -1)

    diag = c_down + c_up + c_right + c_left
    A = jnp.zeros((n_free, n_free), dtype=jnp.float64)
    A = A.at[idx, idx].add(diag)
    A = A.at[idx, nbr_down].add(jnp.where(nbr_down >= 0, -c_down, 0.0))
    A = A.at[idx, nbr_up].add(jnp.where(nbr_up >= 0, -c_up, 0.0))
    A = A.at[idx, nbr_right].add(jnp.where(nbr_right >= 0, -c_right, 0.0))
    A = A.at[idx, nbr_left].add(jnp.where(nbr_left >= 0, -c_left, 0.0))

    rhs = source_field[fr, fc]
    return A, rhs


@jax.jit
def latent_to_log_conductivity(alpha):
    return jnp.reshape(Basis @ alpha, (G, G))


@jax.jit
def solve_forward_full(alpha):
    log_k = latent_to_log_conductivity(alpha)
    k_field = jnp.exp(log_k)
    A, rhs = _assemble_heat_system(k_field)
    w_free = jnp.linalg.solve(A, rhs)
    w_full = jnp.zeros(G * G, dtype=jnp.float64)
    w_full = w_full.at[free_index].set(w_free)
    return jnp.reshape(w_full, (G, G))


@jax.jit
def solve_forward(alpha):
    w_full = solve_forward_full(alpha)
    return w_full.reshape(-1)[obs_locations]


@jax.jit
def solve_forward_holdout(alpha):
    w_full = solve_forward_full(alpha)
    return w_full.reshape(-1)[heldout_obs_locations]


# ==========================================
# Shared sampling configuration
# ==========================================

ACTIVE_DIM = num_truncated_series

np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
np.random.seed(seed)
alpha_true_np = np.random.randn(ACTIVE_DIM) * 0.5
y_clean_np = np.array(solve_forward(jnp.array(alpha_true_np)))
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_holdout_clean_np = np.array(solve_forward_holdout(jnp.array(alpha_true_np)))
y_holdout_obs_np = y_holdout_clean_np + np.random.normal(0.0, NOISE_STD, size=y_holdout_clean_np.shape)


def field_from_latent(alpha):
    return np.asarray(Basis @ jnp.asarray(alpha)).reshape((GRID_SIZE, GRID_SIZE))

true_field = field_from_latent(alpha_true_np)
y_holdout_clean_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))

def state_from_latent(alpha):
    return np.asarray(solve_forward_full(jnp.asarray(alpha)))
