# Model and synthetic data preserved from the source recorded in provenance/catalog.json.
# Import only from run_problem.py, which assigns an isolated working directory.
import os
import random
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import torch
from scipy.spatial.distance import cdist
jax.config.update("jax_enable_x64", True)
os.makedirs("data", exist_ok=True)
N = 32
x = np.linspace(0.0, 1.0, N)
X, Y = np.meshgrid(x, x)
coords = np.column_stack([X.ravel(), Y.ravel()])

ell = 0.12
sigma_prior = 1.0
q_max = 100

dists = cdist(coords, coords)
C = sigma_prior ** 2 * np.exp(-dists / ell)
eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]
Basis_Modes = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])
np.savetxt('data/Hyperelastic_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# 1. Configuration / data files
# ==========================================
num_observation = 48
num_holdout_observation = 24
num_truncated_series = 32
seed = int(os.environ.get("GAD_SCREEN_SEED", "42"))

dimension_of_PoI = N * N

interior_mask = np.ones((N, N), dtype=bool)
interior_mask[0, :] = False
interior_mask[-1, :] = False
interior_mask[:, 0] = False
interior_mask[:, -1] = False
interior_indices = jnp.array(np.where(interior_mask.ravel())[0])

key = jax.random.PRNGKey(seed)
obs_indices_train = np.array(
    jax.random.choice(key, interior_indices, shape=(num_observation,), replace=False)
)
remaining_interior_indices = np.setdiff1d(np.asarray(interior_indices), obs_indices_train)
key_holdout = jax.random.PRNGKey(seed + 1)
obs_indices_holdout = np.array(
    jax.random.choice(
        key_holdout,
        jnp.array(remaining_interior_indices),
        shape=(num_holdout_observation,),
        replace=False,
    )
)
obs_indices = obs_indices_train

# Match the I/O pattern of the other modular experiments.
df_modes = pd.read_csv('data/Hyperelastic_Basis_Modes.csv', header=None)
if isinstance(df_modes.iloc[0, 0], str):
    df_modes = pd.read_csv('data/Hyperelastic_Basis_Modes.csv')

modes_raw = df_modes.to_numpy().flatten()
num_modes_available = modes_raw.size // dimension_of_PoI
full_basis = modes_raw.reshape((dimension_of_PoI, num_modes_available))
basis_truncated = full_basis[:, :num_truncated_series]

pd.DataFrame(basis_truncated).to_csv('data/Hyperelastic_Basis.csv', index=False, header=False)
pd.DataFrame(obs_indices_train).to_csv('data/hyperelastic_obs_locations.csv', index=False, header=False)

df_Basis = pd.read_csv('data/Hyperelastic_Basis.csv', header=None)
df_obs = pd.read_csv('data/hyperelastic_obs_locations.csv', header=None)

basis_raw = df_Basis.to_numpy().flatten()
if basis_raw.size % dimension_of_PoI == 1:
    basis_raw = basis_raw[1:]
basis_raw = basis_raw.astype(np.float64)

if basis_raw.size % dimension_of_PoI != 0:
    raise ValueError(
        f"Basis file size {basis_raw.size} is not divisible by grid size {dimension_of_PoI}."
    )

num_modes_in_file = basis_raw.size // dimension_of_PoI
full_basis = np.reshape(basis_raw, (dimension_of_PoI, num_modes_in_file))
Basis = jnp.array(full_basis[:, :num_truncated_series], dtype=jnp.float64)
Basis_np = np.array(Basis)

obs_raw = df_obs.to_numpy().flatten()
if obs_raw.size == num_observation + 1:
    obs_raw = obs_raw[1:]
obs_raw = obs_raw.astype(int)
if obs_raw.size > num_observation:
    obs_raw = obs_raw[:num_observation]
elif obs_raw.size < num_observation:
    raise ValueError(f"Obs file only has {obs_raw.size} locations, need {num_observation}.")
obs_locations_train = jnp.array(obs_raw, dtype=int)
obs_locations_holdout = jnp.array(obs_indices_holdout, dtype=int)
obs_locations = obs_locations_train

obs_locs_np = np.array(obs_locations_train)
obs_row = obs_locs_np // N
obs_col = obs_locs_np % N
holdout_locs_np = np.array(obs_locations_holdout)
holdout_row = holdout_locs_np // N
holdout_col = holdout_locs_np % N

# Plot-resolution controls: show native 32x32 fields when available; otherwise
# artificially upscale smaller grids so notebook renders match the Allen–Cahn look.
PLOT_NATIVE_MIN_RES = 32
PLOT_UPSCALE_TARGET = 96


def _prepare_plot_panel(field, rows=None, cols=None):
    arr = np.asarray(field)
    if arr.ndim != 2:
        return arr, rows, cols, 'nearest'
    min_side = int(min(arr.shape))
    if min_side >= PLOT_NATIVE_MIN_RES:
        return arr, rows, cols, 'nearest'

    factor = int(np.ceil(PLOT_UPSCALE_TARGET / float(min_side)))
    factor = max(1, factor)
    up = np.repeat(np.repeat(arr, factor, axis=0), factor, axis=1)
    row_up = None if rows is None else np.asarray(rows, dtype=np.float64) * factor + 0.5 * (factor - 1)
    col_up = None if cols is None else np.asarray(cols, dtype=np.float64) * factor + 0.5 * (factor - 1)
    return up, row_up, col_up, 'nearest'

# ==========================================
# 2. Physics: generalized neo-Hookean membrane surrogate
# ==========================================
NOISE_STD = 0.001
MU0 = 1.0
BETA_NL = 6.0
PICARD_ITERS = 3
PICARD_DAMP = 0.75
COEFF_MIN = 1e-3
COEFF_MAX = 1e3

h = 1.0 / (N - 1)
x_1d = jnp.linspace(0.0, 1.0, N)
X_grid, Y_grid = jnp.meshgrid(x_1d, x_1d, indexing='xy')

_int_mask = jnp.zeros((N, N), dtype=bool)
_int_mask = _int_mask.at[1:-1, 1:-1].set(True)
_int_rows, _int_cols = jnp.where(_int_mask)
n_int = _int_rows.shape[0]

_int_id = -jnp.ones((N, N), dtype=jnp.int32)
_int_id = _int_id.at[_int_rows, _int_cols].set(jnp.arange(n_int, dtype=jnp.int32))
int_flat = _int_rows * N + _int_cols

# Precompute neighbor bookkeeping for interior assembly.
ir = _int_rows
ic = _int_cols
idx_int = jnp.arange(n_int)

nbr_E = _int_id[ir + 1, ic]
nbr_W = _int_id[ir - 1, ic]
nbr_N = _int_id[ir, ic + 1]
nbr_S = _int_id[ir, ic - 1]

mask_E_int = nbr_E >= 0
mask_W_int = nbr_W >= 0
mask_N_int = nbr_N >= 0
mask_S_int = nbr_S >= 0

# Boundary values for RHS when a neighbor lies on the boundary.
bdry_E_r = ir + 1
bdry_E_c = ic
bdry_W_r = ir - 1
bdry_W_c = ic
bdry_N_r = ir
bdry_N_c = ic + 1
bdry_S_r = ir
bdry_S_c = ic - 1


def _make_bc(load_id: int) -> np.ndarray:
    """Construct displacement-controlled boundary actuation for one load case."""
    xx = x_1d
    yy = x_1d
    bc = np.zeros((N, N, 2), dtype=np.float64)

    if load_id == 0:
        # Horizontal pull on the right edge.
        bc[-1, :, 0] = 0.08 * np.sin(np.pi * np.asarray(yy))
    elif load_id == 1:
        # Vertical lift on the top edge plus mild lateral bias on the right.
        bc[:, -1, 1] = 0.08 * np.sin(np.pi * np.asarray(xx))
        bc[-1, :, 0] = -0.02 * np.sin(np.pi * np.asarray(yy))
    elif load_id == 2:
        # Held-out mixed load with both right-edge and top-edge actuation.
        bc[-1, :, 0] = 0.05 * np.sin(np.pi * np.asarray(yy))
        bc[-1, :, 1] = 0.03 * np.sin(2.0 * np.pi * np.asarray(yy))
        bc[:, -1, 0] += 0.02 * np.sin(np.pi * np.asarray(xx))
        bc[:, -1, 1] += 0.06 * np.sin(np.pi * np.asarray(xx))
    else:
        raise ValueError(f"Unknown load_id={load_id}")

    # Keep the left edge fixed to prevent rigid translations.
    bc[0, :, :] = 0.0
    # Bottom edge fixed as a stable support, except where another load already vanishes.
    bc[:, 0, :] = 0.0
    return bc


BC_CASES_NP = np.stack([_make_bc(0), _make_bc(1), _make_bc(2)], axis=0)
BC_CASES = jnp.array(BC_CASES_NP, dtype=jnp.float64)
TRAIN_LOAD_IDS = (0, 1)
HELDOUT_LOAD_ID = 2


@jax.jit
def _assemble_scalar_system(a_field, bc_component):
    """Assemble the interior linear system for -div(a grad u)=0 with Dirichlet BC."""
    h2 = h * h

    a_xp = 2.0 * a_field[:-1, :] * a_field[1:, :] / (a_field[:-1, :] + a_field[1:, :] + 1e-30)
    a_yp = 2.0 * a_field[:, :-1] * a_field[:, 1:] / (a_field[:, :-1] + a_field[:, 1:] + 1e-30)

    c_E = a_xp[ir, ic] / h2
    c_W = a_xp[ir - 1, ic] / h2
    c_N = a_yp[ir, ic] / h2
    c_S = a_yp[ir, ic - 1] / h2

    diag = c_E + c_W + c_N + c_S

    A = jnp.zeros((n_int, n_int), dtype=jnp.float64)
    A = A.at[idx_int, idx_int].add(diag)
    A = A.at[idx_int, nbr_E].add(jnp.where(mask_E_int, -c_E, 0.0))
    A = A.at[idx_int, nbr_W].add(jnp.where(mask_W_int, -c_W, 0.0))
    A = A.at[idx_int, nbr_N].add(jnp.where(mask_N_int, -c_N, 0.0))
    A = A.at[idx_int, nbr_S].add(jnp.where(mask_S_int, -c_S, 0.0))

    rhs = jnp.where(mask_E_int, 0.0, c_E * bc_component[bdry_E_r, bdry_E_c])
    rhs = rhs + jnp.where(mask_W_int, 0.0, c_W * bc_component[bdry_W_r, bdry_W_c])
    rhs = rhs + jnp.where(mask_N_int, 0.0, c_N * bc_component[bdry_N_r, bdry_N_c])
    rhs = rhs + jnp.where(mask_S_int, 0.0, c_S * bc_component[bdry_S_r, bdry_S_c])
    return A, rhs


@jax.jit
def _solve_scalar_dirichlet(a_field, bc_component):
    A, rhs = _assemble_scalar_system(a_field, bc_component)
    u_int = jnp.linalg.solve(A, rhs)
    u_full = jnp.array(bc_component)
    u_full = u_full.at[_int_rows, _int_cols].set(u_int)
    return u_full


@jax.jit
def _strain_measure(U):
    q = jnp.zeros((N, N), dtype=jnp.float64)
    ux = U[..., 0]
    uy = U[..., 1]

    dux_dx = (ux[2:, 1:-1] - ux[:-2, 1:-1]) / (2.0 * h)
    dux_dy = (ux[1:-1, 2:] - ux[1:-1, :-2]) / (2.0 * h)
    duy_dx = (uy[2:, 1:-1] - uy[:-2, 1:-1]) / (2.0 * h)
    duy_dy = (uy[1:-1, 2:] - uy[1:-1, :-2]) / (2.0 * h)

    q_int = dux_dx ** 2 + dux_dy ** 2 + duy_dx ** 2 + duy_dy ** 2
    q = q.at[1:-1, 1:-1].set(q_int)
    return q


@jax.jit
def _effective_coeff(mu_field, U):
    q = _strain_measure(U)
    a = mu_field * (1.0 + BETA_NL * q)
    return jnp.clip(a, COEFF_MIN, COEFF_MAX)


@jax.jit
def _solve_one_load(alpha, bc):
    log_mu = jnp.reshape(Basis @ alpha, (N, N))
    mu_field = MU0 * jnp.exp(log_mu)

    # Start from the linear membrane response.
    u0 = _solve_scalar_dirichlet(mu_field, bc[..., 0])
    v0 = _solve_scalar_dirichlet(mu_field, bc[..., 1])
    U0 = jnp.stack([u0, v0], axis=-1)

    def body_fun(_, U_prev):
        a_field = _effective_coeff(mu_field, U_prev)
        u_new = _solve_scalar_dirichlet(a_field, bc[..., 0])
        v_new = _solve_scalar_dirichlet(a_field, bc[..., 1])
        U_new = jnp.stack([u_new, v_new], axis=-1)
        return PICARD_DAMP * U_new + (1.0 - PICARD_DAMP) * U_prev

    return jax.lax.fori_loop(0, PICARD_ITERS, body_fun, U0)


@jax.jit
def solve_forward(alpha):
    obs_chunks = []
    for load_id in TRAIN_LOAD_IDS:
        U = _solve_one_load(alpha, BC_CASES[load_id])
        obs_chunks.append(U.reshape(-1, 2)[obs_locations_train].reshape(-1))
    return jnp.concatenate(obs_chunks, axis=0)


@jax.jit
def solve_forward_holdout(alpha):
    U = _solve_one_load(alpha, BC_CASES[HELDOUT_LOAD_ID])
    return U.reshape(-1, 2)[obs_locations_holdout].reshape(-1)


@jax.jit
def solve_full_displacement(alpha, load_id):
    return _solve_one_load(alpha, BC_CASES[load_id])


# ==========================================
# Shared sampling configuration
# ==========================================

ACTIVE_DIM = num_truncated_series

np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
np.random.seed(seed)
alpha_true_np = np.random.randn(ACTIVE_DIM) * 0.45

y_clean = solve_forward(jnp.array(alpha_true_np))
y_clean_np = np.array(y_clean)
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_holdout_clean_np = np.array(solve_forward_holdout(jnp.array(alpha_true_np)))
y_holdout_obs_np = y_holdout_clean_np + np.random.normal(0.0, NOISE_STD, size=y_holdout_clean_np.shape)


def field_from_latent(alpha):
    return np.asarray(Basis @ jnp.asarray(alpha)).reshape((N, N))

true_field = field_from_latent(alpha_true_np)
y_holdout_clean_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))

def state_from_latent(alpha):
    displacement = np.asarray(_solve_one_load(jnp.asarray(alpha), BC_CASES[0]))
    return np.sqrt(np.sum(displacement ** 2, axis=-1))
