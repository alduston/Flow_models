# Model and synthetic data preserved from the source recorded in provenance/catalog.json.
# Import only from run_problem.py, which assigns an isolated working directory.
import os
import random
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import torch
from scipy.spatial.distance import cdist
jax.config.update("jax_enable_x64", True)
os.makedirs("data", exist_ok=True)
N = 32
# Moderately harder inverse-problem setting: fewer and mildly anisotropic
# sensors, a somewhat larger latent state, and a rougher anisotropic prior.
# This is intentionally harder than the original uploaded script but avoids
# the previous over-hardened regime where CE-HLSI bootstrap references could
# collapse to non-finite samples.
num_observation = 80
num_holdout_observation = 40
num_truncated_series = 36
num_modes_available = 120
seed = int(os.environ.get("GAD_SCREEN_SEED", "42"))
prior_length_scale_x = 0.075
prior_length_scale_y = 0.13
INITIAL_VORTICITY_SCALE = 1.20

os.makedirs('data', exist_ok=True)
rng = np.random.default_rng(seed)


def build_anisotropic_periodic_fourier_basis(N, q_max=120, length_scale_x=0.075, length_scale_y=0.13):
    x = np.linspace(0.0, 1.0, N, endpoint=False)
    X, Y = np.meshgrid(x, x, indexing='ij')
    freq_pairs = []
    kmax = int(np.ceil(np.sqrt(q_max))) + 8
    for kx in range(0, kmax + 1):
        for ky in range(-kmax, kmax + 1):
            if kx == 0 and ky <= 0:
                continue
            freq_pairs.append((kx, ky))
    freq_pairs.sort(key=lambda kk: (kk[0] ** 2 + kk[1] ** 2, abs(kk[0]) + abs(kk[1]), kk[0], kk[1]))
    cols, meta = [], []
    for kx, ky in freq_pairs:
        phase = 2.0 * np.pi * (kx * X + ky * Y)
        k2 = float(kx * kx + ky * ky)
        # Directional spectral envelope: high-kx modes survive much longer than high-ky modes.
        # This creates an anisotropic rough/smooth split, hence a more ill-conditioned posterior.
        amp = np.exp(-0.5 * ((2.0 * np.pi * length_scale_x * kx) ** 2 + (2.0 * np.pi * length_scale_y * ky) ** 2))
        cos_mode = amp * np.cos(phase)
        cos_mode = cos_mode - cos_mode.mean()
        cos_norm = np.linalg.norm(cos_mode.ravel())
        if cos_norm > 1e-12:
            cols.append((amp * cos_mode / cos_norm).ravel())
            meta.append((kx, ky, 'cos', amp))
            if len(cols) >= q_max:
                break
        sin_mode = amp * np.sin(phase)
        sin_mode = sin_mode - sin_mode.mean()
        sin_norm = np.linalg.norm(sin_mode.ravel())
        if sin_norm > 1e-12:
            cols.append((amp * sin_mode / sin_norm).ravel())
            meta.append((kx, ky, 'sin', amp))
            if len(cols) >= q_max:
                break
    return np.column_stack(cols[:q_max]).astype(np.float64), meta[:q_max]


full_basis, basis_meta = build_anisotropic_periodic_fourier_basis(
    N=N,
    q_max=num_modes_available,
    length_scale_x=prior_length_scale_x,
    length_scale_y=prior_length_scale_y,
)
basis_truncated = full_basis[:, :num_truncated_series]
basis_modes_path = 'data/NavierStokes_Basis_Modes_generated.csv'
pd.DataFrame(full_basis).to_csv(basis_modes_path, index=False, header=False)
pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
# Mildly anisotropic sensor geometry.  Compared with the original random
# 120-sensor problem, this keeps fewer sensors and some directional structure;
# compared with the previous hard version, it restores enough spatial coverage
# that bootstrap reference banks remain numerically sane.
row_grid_np, col_grid_np = np.indices((N, N))
train_mask = (
    np.isin(col_grid_np, [int(0.55 * N), int(0.70 * N), int(0.85 * N)])
    | ((row_grid_np == int(0.25 * N)) & (col_grid_np >= int(0.25 * N)))
    | ((row_grid_np == int(0.58 * N)) & (col_grid_np <= int(0.80 * N)))
)
holdout_mask = (
    np.isin(col_grid_np, [int(0.18 * N), int(0.38 * N), int(0.62 * N)])
    | ((row_grid_np == int(0.75 * N)) & (col_grid_np <= int(0.75 * N)))
)
train_candidates = np.flatnonzero(train_mask.ravel())
holdout_candidates = np.setdiff1d(np.flatnonzero(holdout_mask.ravel()), train_candidates)
if train_candidates.size < num_observation:
    raise ValueError(f"Need at least {num_observation} training candidates, found {train_candidates.size}.")
if holdout_candidates.size < num_holdout_observation:
    raise ValueError(f"Need at least {num_holdout_observation} holdout candidates, found {holdout_candidates.size}.")
obs_indices_train = rng.choice(train_candidates, size=(num_observation,), replace=False)
obs_indices_holdout = rng.choice(holdout_candidates, size=(num_holdout_observation,), replace=False)
obs_indices = obs_indices_train
pd.DataFrame(obs_indices_train).to_csv('data/obs_locations.csv', index=False, header=False)

# ==========================================
# Physics
# ==========================================
jax.config.update("jax_enable_x64", True)
dimension_of_PoI = N ** 2
# Slightly lower viscosity and a slightly longer horizon than the original
# make the forward map harder, but not so chaotic/stiff that CE-HLSI
# bootstrapped references collapse.
nu = 7.5e-4
delta_t = 0.05
T_end = 10.5
num_time_steps = int(round(T_end / delta_t))

Basis = jnp.array(basis_truncated)
obs_locations = jnp.array(obs_indices, dtype=int)
holdout_locations = jnp.array(obs_indices_holdout, dtype=int)

x_1d = jnp.linspace(0.0, 1.0, N, endpoint=False)
X_grid, Y_grid = jnp.meshgrid(x_1d, x_1d, indexing='ij')
freq_1d = jnp.fft.fftfreq(N, d=1.0 / N)
KX, KY = jnp.meshgrid(2.0 * jnp.pi * freq_1d, 2.0 * jnp.pi * freq_1d, indexing='ij')
K2 = KX ** 2 + KY ** 2
K2_safe = jnp.where(K2 == 0.0, 1.0, K2)
freq_abs_x = jnp.abs(jnp.fft.fftfreq(N, d=1.0 / N))
freq_abs_y = jnp.abs(jnp.fft.fftfreq(N, d=1.0 / N))
DEALIAS = ((freq_abs_x[:, None] <= (N / 3.0)) & (freq_abs_y[None, :] <= (N / 3.0))).astype(jnp.float64)
# Moderate multiscale anisotropic forcing.  This is stronger and less isotropic
# than the original single diagonal forcing, but backed off from the satanic
# version that made the likelihood too stiff.
forcing_field = (
    0.14 * jnp.sin(2.0 * jnp.pi * (1.5 * X_grid + 0.35 * Y_grid))
    + 0.08 * jnp.cos(2.0 * jnp.pi * (0.25 * X_grid + 2.5 * Y_grid))
    + 0.04 * jnp.sin(2.0 * jnp.pi * (3.0 * X_grid - 0.75 * Y_grid))
)
forcing_hat = jnp.fft.fftn(forcing_field)

# Mild anisotropic observation blur.  It adds ill-posedness relative to direct
# final-vorticity sensing, but it is much less aggressive than the previous
# filter and should leave bootstrap samples finite.
OBS_FILTER = jnp.exp(-0.5 * ((freq_abs_x[:, None] / 8.0) ** 2 + (freq_abs_y[None, :] / 4.0) ** 2))


def _observed_vorticity_field(omega_field):
    return jnp.fft.ifftn(jnp.fft.fftn(omega_field) * OBS_FILTER).real
CN_NUM = 1.0 - 0.5 * delta_t * nu * K2
CN_DEN = 1.0 + 0.5 * delta_t * nu * K2


def _latent_to_initial_vorticity(alpha):
    omega0 = INITIAL_VORTICITY_SCALE * jnp.reshape(Basis @ alpha, (N, N))
    return omega0 - jnp.mean(omega0)



def _ns_step(_, omega_hat):
    omega_hat = omega_hat * DEALIAS
    psi_hat = -omega_hat / K2_safe
    psi_hat = jnp.where(K2 == 0.0, 0.0, psi_hat)
    vel_x = jnp.fft.ifftn(1j * KY * psi_hat).real
    vel_y = jnp.fft.ifftn(-1j * KX * psi_hat).real
    omega_x = jnp.fft.ifftn(1j * KX * omega_hat).real
    omega_y = jnp.fft.ifftn(1j * KY * omega_hat).real
    adv_hat = jnp.fft.fftn(vel_x * omega_x + vel_y * omega_y) * DEALIAS
    rhs_hat = CN_NUM * omega_hat - delta_t * adv_hat + delta_t * forcing_hat
    omega_hat_next = (rhs_hat / CN_DEN) * DEALIAS
    return jnp.where(K2 == 0.0, 0.0, omega_hat_next)


@jax.jit
def solve_forward_full(alpha):
    omega0 = _latent_to_initial_vorticity(alpha)
    omega_hat0 = jnp.fft.fftn(omega0)
    omega_hatT = jax.lax.fori_loop(0, num_time_steps, _ns_step, omega_hat0)
    return jnp.fft.ifftn(omega_hatT).real


@jax.jit
def solve_forward(alpha):
    omega_T = _observed_vorticity_field(solve_forward_full(alpha))
    return omega_T.reshape(-1)[obs_locations]


@jax.jit
def solve_forward_holdout(alpha):
    omega_T = _observed_vorticity_field(solve_forward_full(alpha))
    return omega_T.reshape(-1)[holdout_locations]


batch_solve_forward_holdout = jax.jit(jax.vmap(solve_forward_holdout))


# ==========================================
# Shared sampling configuration
# ==========================================

ACTIVE_DIM = num_truncated_series
NOISE_STD = 0.005

np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(seed)
alpha_true_np = np.random.randn(ACTIVE_DIM) * 0.60
y_clean = solve_forward(jnp.array(alpha_true_np))
y_clean_np = np.array(y_clean)
y_obs_np = y_clean_np + np.random.normal(0, NOISE_STD, size=y_clean_np.shape)
y_clean_holdout = solve_forward_holdout(jnp.array(alpha_true_np))
y_clean_holdout_np = np.array(y_clean_holdout)
y_holdout_obs_np = y_clean_holdout_np + np.random.normal(0, NOISE_STD, size=y_clean_holdout_np.shape)


def field_from_latent(alpha):
    return np.asarray(_latent_to_initial_vorticity(jnp.asarray(alpha)))

true_field = field_from_latent(alpha_true_np)
y_holdout_clean_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))

def state_from_latent(alpha):
    return np.asarray(solve_forward_full(jnp.asarray(alpha)))
