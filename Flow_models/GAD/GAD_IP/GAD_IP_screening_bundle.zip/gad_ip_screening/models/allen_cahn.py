# Model and synthetic data preserved from the source recorded in provenance/catalog.json.
# Import only from run_problem.py, which assigns an isolated working directory.
import os
import random
import numpy as np
import pandas as pd
import jax
from jax import lax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import torch
from scipy.spatial.distance import cdist
jax.config.update("jax_enable_x64", True)
os.makedirs("data", exist_ok=True)
N = 32
x = np.linspace(0.0, 1.0, N, endpoint=False)
X, Y = np.meshgrid(x, x, indexing='ij')
coords = np.column_stack([X.ravel(), Y.ravel()])

ELL = 0.1
SIGMA_PRIOR = 1.0
q_max = 100

dists = cdist(coords, coords)
C = SIGMA_PRIOR ** 2 * np.exp(-dists / ELL)
eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]
Basis_Modes = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])
np.savetxt('data/AllenCahn_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# 1. Configuration / data files
# ==========================================
num_observation = 40
num_holdout_observation = 40
num_truncated_series = 32
seed = int(os.environ.get("GAD_SCREEN_SEED", "42"))

dimension_of_PoI = N * N
num_modes_available = Basis_Modes.shape[1]
basis_truncated = Basis_Modes[:, :num_truncated_series]

key = jax.random.PRNGKey(seed)
obs_indices_train = np.array(
    jax.random.choice(key, jnp.arange(dimension_of_PoI), shape=(num_observation,), replace=False)
)
remaining_indices = np.setdiff1d(np.arange(dimension_of_PoI), obs_indices_train)
key_holdout = jax.random.PRNGKey(seed + 1)
obs_indices_holdout = np.array(
    jax.random.choice(key_holdout, jnp.array(remaining_indices), shape=(num_holdout_observation,), replace=False)
)
obs_indices = obs_indices_train

pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(obs_indices_train).to_csv('data/obs_locations.csv', index=False, header=False)

# ==========================================
# 2. Physics: periodic Allen–Cahn dynamics
# ==========================================
jax.config.update("jax_enable_x64", True)

Basis = jnp.array(basis_truncated, dtype=jnp.float64)
obs_locations_train = jnp.array(obs_indices_train, dtype=int)
obs_locations_holdout = jnp.array(obs_indices_holdout, dtype=int)
obs_locations = obs_locations_train

x_1d = jnp.linspace(0.0, 1.0, N, endpoint=False)
X_grid, Y_grid = jnp.meshgrid(x_1d, x_1d, indexing='ij')

OBS_TIME = 0.33
ALLEN_CAHN_EPS = 0.045
ALLEN_CAHN_DT = 5.0e-4
ALLEN_CAHN_STEPS = int(round(OBS_TIME / ALLEN_CAHN_DT))
NOISE_STD = 0.01

kx_1d = 2.0 * jnp.pi * jnp.fft.fftfreq(N, d=1.0 / N)
ky_1d = 2.0 * jnp.pi * jnp.fft.fftfreq(N, d=1.0 / N)
KX, KY = jnp.meshgrid(kx_1d, ky_1d, indexing='ij')
K2 = KX ** 2 + KY ** 2
IMEX_DENOM = 1.0 / (1.0 + ALLEN_CAHN_DT * (ALLEN_CAHN_EPS ** 2) * K2)


@jax.jit
def _allen_cahn_step(u_field):
    reaction_rhs = u_field + ALLEN_CAHN_DT * (u_field - u_field ** 3)
    reaction_hat = jnp.fft.fftn(reaction_rhs)
    next_hat = reaction_hat * IMEX_DENOM
    next_field = jnp.real(jnp.fft.ifftn(next_hat))
    return next_field


@jax.jit
def _propagate_allen_cahn_obs_time(u0_field):
    def body_fn(_, u):
        return _allen_cahn_step(u)
    return lax.fori_loop(0, ALLEN_CAHN_STEPS, body_fn, u0_field)


def _propagate_allen_cahn(u0_field, t=OBS_TIME):
    """Propagate periodic Allen–Cahn dynamics to time t."""
    if abs(float(t) - float(OBS_TIME)) < 1e-15:
        return _propagate_allen_cahn_obs_time(u0_field)
    n_steps = max(1, int(round(float(t) / ALLEN_CAHN_DT)))
    u = u0_field
    for _ in range(n_steps):
        u = _allen_cahn_step(u)
    return u


@jax.jit
def solve_forward(alpha):
    u0 = jnp.reshape(Basis @ alpha, (N, N))
    uT = _propagate_allen_cahn_obs_time(u0)
    return uT.reshape(-1)[obs_locations_train]


@jax.jit
def solve_forward_holdout(alpha):
    u0 = jnp.reshape(Basis @ alpha, (N, N))
    uT = _propagate_allen_cahn_obs_time(u0)
    return uT.reshape(-1)[obs_locations_holdout]


def solve_full_state(alpha, t=OBS_TIME):
    u0 = jnp.reshape(Basis @ alpha, (N, N))
    return _propagate_allen_cahn(u0, t)


# ==========================================
# Shared sampling configuration
# ==========================================

ACTIVE_DIM = num_truncated_series

np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
np.random.seed(seed)


def make_structured_truth_coefficients(active_dim=ACTIVE_DIM):
    """Build a phase-separated synthetic initial condition and project it into the KL basis."""
    X_np = np.array(X_grid)
    Y_np = np.array(Y_grid)
    r1 = np.sqrt((X_np - 0.30) ** 2 + (Y_np - 0.36) ** 2)
    r2 = np.sqrt((X_np - 0.69) ** 2 + (Y_np - 0.63) ** 2)
    level_set = (
        1.25 * np.tanh((0.17 - r1) / 0.035)
        - 1.05 * np.tanh((0.14 - r2) / 0.040)
        + 0.55 * np.cos(2.0 * np.pi * X_np) * np.cos(2.0 * np.pi * Y_np)
        - 0.20 * np.sin(4.0 * np.pi * (X_np - 0.35 * Y_np))
    )
    truth_field = np.tanh(1.3 * level_set)
    B = basis_truncated[:, :active_dim]
    coeffs, *_ = np.linalg.lstsq(B, truth_field.reshape(-1), rcond=None)
    return coeffs.astype(np.float64), truth_field.astype(np.float64)


alpha_true_np, true_u0_target = make_structured_truth_coefficients(ACTIVE_DIM)
y_clean = solve_forward(jnp.array(alpha_true_np))
y_clean_np = np.array(y_clean)
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_holdout_clean_np = np.array(solve_forward_holdout(jnp.array(alpha_true_np)))
y_holdout_obs_np = y_holdout_clean_np + np.random.normal(0.0, NOISE_STD, size=y_holdout_clean_np.shape)


def field_from_latent(alpha):
    return np.asarray(Basis @ jnp.asarray(alpha)).reshape((N, N))

true_field = field_from_latent(alpha_true_np)
y_holdout_clean_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))

def state_from_latent(alpha):
    return np.asarray(solve_full_state(jnp.asarray(alpha)))
