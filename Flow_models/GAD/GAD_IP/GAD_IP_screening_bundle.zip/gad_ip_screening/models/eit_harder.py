# Model and synthetic data preserved from the source recorded in provenance/catalog.json.
# Import only from run_problem.py, which assigns an isolated working directory.
import os
import random
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import torch
from scipy.spatial.distance import cdist
jax.config.update("jax_enable_x64", True)
os.makedirs("data", exist_ok=True)
N = 32
x = np.linspace(0.0, 1.0, N)
X, Y = np.meshgrid(x, x)
coords = np.column_stack([X.ravel(), Y.ravel()])

ELL_X = 0.045
ELL_Y = 0.090
SIGMA_PRIOR = 1.0
q_max = 120

# Moderately harder anisotropic KL prior.  Compared with the original isotropic
# EIT setup, this preserves more high-frequency structure along x than y, which
# produces a rough/smooth directional split and a more ill-conditioned posterior
# without making the PDE solve itself pathological.
dx = coords[:, 0][:, None] - coords[:, 0][None, :]
dy = coords[:, 1][:, None] - coords[:, 1][None, :]
r_aniso = np.sqrt((dx / ELL_X) ** 2 + (dy / ELL_Y) ** 2)
C = SIGMA_PRIOR ** 2 * np.exp(-r_aniso)
C = 0.5 * (C + C.T) + 1e-10 * np.eye(C.shape[0])
eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]
Basis_Modes = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])
np.savetxt('data/EIT_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# 1. Configuration / data files
# ==========================================
num_truncated_series = 32
seed = int(os.environ.get("GAD_SCREEN_SEED", "42"))
N_CURRENT_PATTERNS = 12

# Clustered sensor layout: dense coverage on a few boundary arcs and sparse/no
# coverage elsewhere. This is intended to create locally stiff likelihoods near
# instrumented regions while preserving genuine posterior ambiguity away from
# the sensor clusters.
SENSOR_LAYOUT_NAME = 'moderately_harder_clustered_3arc_anisotropic'
SENSOR_CLUSTER_SPECS = (
    {'center_frac': 0.08, 'half_width_frac': 0.065, 'count': 12},
    {'center_frac': 0.41, 'half_width_frac': 0.065, 'count': 12},
    {'center_frac': 0.74, 'half_width_frac': 0.065, 'count': 12},
)
SENSOR_BACKBONE_COUNT = 4
N_ELECTRODES = int(sum(spec['count'] for spec in SENSOR_CLUSTER_SPECS) + SENSOR_BACKBONE_COUNT)
dimension_of_PoI = N * N
num_modes_available = Basis_Modes.shape[1]


def _ordered_boundary_indices(n):
    idx = []
    for j in range(n):
        idx.append(0 * n + j)
    for i in range(1, n):
        idx.append(i * n + (n - 1))
    for j in range(n - 2, -1, -1):
        idx.append((n - 1) * n + j)
    for i in range(n - 2, 0, -1):
        idx.append(i * n + 0)
    return np.array(idx, dtype=int)


def _select_evenly_spaced_positions(positions, count):
    positions = np.array(sorted(set(int(p) for p in np.asarray(positions).tolist())), dtype=int)
    if count <= 0 or positions.size == 0:
        return np.array([], dtype=int)
    if count >= positions.size:
        return positions.copy()

    raw_idx = np.linspace(0, positions.size - 1, count)
    selected = []
    used = set()
    for idx in np.round(raw_idx).astype(int):
        idx = int(np.clip(idx, 0, positions.size - 1))
        pos = int(positions[idx])
        if pos not in used:
            selected.append(pos)
            used.add(pos)

    if len(selected) < count:
        remaining = np.array([p for p in positions.tolist() if int(p) not in used], dtype=int)
        if remaining.size > 0:
            extra = _select_evenly_spaced_positions(remaining, count - len(selected))
            for pos in extra.tolist():
                pos = int(pos)
                if pos not in used:
                    selected.append(pos)
                    used.add(pos)

    return np.array(sorted(selected), dtype=int)


def _circular_arc_positions(n_boundary, center_frac, half_width_frac):
    center = float(center_frac % 1.0) * n_boundary
    positions = np.arange(n_boundary, dtype=float)
    clockwise = np.mod(positions - center, n_boundary)
    counterclockwise = np.mod(center - positions, n_boundary)
    circular_distance = np.minimum(clockwise, counterclockwise)
    mask = circular_distance <= (float(half_width_frac) * n_boundary)
    return np.where(mask)[0].astype(int)


def _build_clustered_electrode_positions(n_boundary, cluster_specs, backbone_count=0):
    selected = []
    used = set()
    target_count = int(sum(int(spec['count']) for spec in cluster_specs) + int(backbone_count))

    for spec in cluster_specs:
        arc_positions = _circular_arc_positions(
            n_boundary,
            center_frac=spec['center_frac'],
            half_width_frac=spec['half_width_frac'],
        )
        arc_positions = np.array([p for p in arc_positions.tolist() if int(p) not in used], dtype=int)
        chosen = _select_evenly_spaced_positions(arc_positions, int(spec['count']))
        for pos in chosen.tolist():
            pos = int(pos)
            if pos not in used:
                selected.append(pos)
                used.add(pos)

    if backbone_count > 0:
        remaining = np.array([p for p in range(n_boundary) if p not in used], dtype=int)
        backbone = _select_evenly_spaced_positions(remaining, int(backbone_count))
        for pos in backbone.tolist():
            pos = int(pos)
            if pos not in used:
                selected.append(pos)
                used.add(pos)

    if len(selected) < target_count:
        remaining = np.array([p for p in range(n_boundary) if p not in used], dtype=int)
        filler = _select_evenly_spaced_positions(remaining, target_count - len(selected))
        for pos in filler.tolist():
            pos = int(pos)
            if pos not in used:
                selected.append(pos)
                used.add(pos)

    return np.array(sorted(selected), dtype=int)


boundary_indices_ordered = _ordered_boundary_indices(N)
n_boundary = len(boundary_indices_ordered)
electrode_boundary_pos = _build_clustered_electrode_positions(
    n_boundary,
    cluster_specs=SENSOR_CLUSTER_SPECS,
    backbone_count=SENSOR_BACKBONE_COUNT,
)
if electrode_boundary_pos.size != N_ELECTRODES:
    raise ValueError(f'Expected {N_ELECTRODES} electrodes, got {electrode_boundary_pos.size}')

electrode_flat_indices = boundary_indices_ordered[electrode_boundary_pos]
_train_electrode_set = set(int(i) for i in electrode_flat_indices.tolist())
_holdout_electrode_candidates = np.array(
    [int(i) for i in boundary_indices_ordered.tolist() if int(i) not in _train_electrode_set],
    dtype=int,
)
heldout_electrode_flat_indices = np.array(sorted(_holdout_electrode_candidates.tolist()), dtype=int)
N_HOLDOUT_ELECTRODES = int(heldout_electrode_flat_indices.size)

print(
    f"EIT sensor layout '{SENSOR_LAYOUT_NAME}': {N_ELECTRODES} training sensors across "
    f"{len(SENSOR_CLUSTER_SPECS)} dense clusters + {SENSOR_BACKBONE_COUNT} backbone sensors; "
    f"{N_HOLDOUT_ELECTRODES} boundary nodes held out."
)

boundary_theta = 2.0 * np.pi * np.arange(n_boundary) / n_boundary
current_patterns = np.zeros((N_CURRENT_PATTERNS, n_boundary), dtype=np.float64)
for l in range(N_CURRENT_PATTERNS):
    # Mildly more demanding multiscale boundary currents.  The frequencies skip
    # upward to create stiffer localized sensitivities, but each pattern remains
    # zero-net-current and RMS-normalized for Neumann compatibility.
    k = l + 1 + (l // 3)
    pat = np.cos(k * boundary_theta) + 0.30 * np.sin((2 * k + 1) * boundary_theta + 0.17 * l)
    pat = pat - pat.mean()
    pat = pat / (np.sqrt(np.mean(pat ** 2)) + 1e-12)
    current_patterns[l] = pat

num_observation = N_CURRENT_PATTERNS * N_ELECTRODES
basis_truncated = Basis_Modes[:, :num_truncated_series]

pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(electrode_flat_indices).to_csv('data/obs_locations.csv', index=False, header=False)
pd.DataFrame(heldout_electrode_flat_indices).to_csv('data/heldout_obs_locations.csv', index=False, header=False)

# ==========================================
# 2. Physics: EIT forward model
# ==========================================
jax.config.update("jax_enable_x64", True)

Basis = jnp.array(basis_truncated, dtype=jnp.float64)
obs_locations = jnp.array(electrode_flat_indices, dtype=int)
heldout_obs_locations = jnp.array(heldout_electrode_flat_indices, dtype=int)
current_patterns_jax = jnp.array(current_patterns, dtype=jnp.float64)
boundary_indices_jax = jnp.array(boundary_indices_ordered, dtype=int)

h = 1.0 / (N - 1)
NOISE_STD = 1.5e-5

_xface_left = (jnp.arange(N - 1)[:, None] * N + jnp.arange(N)[None, :]).ravel()
_xface_right = _xface_left + N
_yface_bot = (jnp.arange(N)[:, None] * N + jnp.arange(N - 1)[None, :]).ravel()
_yface_top = _yface_bot + 1
_boundary_ds = h * jnp.ones(n_boundary, dtype=jnp.float64)
_GAUGE_NODE = 0


def _assemble_eit_neumann(sigma_field):
    """
    Assemble the full Neumann stiffness matrix with a gauge pin at node 0.
    """
    n_total = N * N
    h2 = h * h

    sigma_xp = 2.0 * sigma_field[:-1, :] * sigma_field[1:, :] / (sigma_field[:-1, :] + sigma_field[1:, :] + 1e-30)
    sigma_yp = 2.0 * sigma_field[:, :-1] * sigma_field[:, 1:] / (sigma_field[:, :-1] + sigma_field[:, 1:] + 1e-30)

    kx = sigma_xp.ravel() / h2
    ky = sigma_yp.ravel() / h2

    A = jnp.zeros((n_total, n_total), dtype=jnp.float64)
    A = A.at[_xface_left, _xface_left].add(kx)
    A = A.at[_xface_right, _xface_right].add(kx)
    A = A.at[_xface_left, _xface_right].add(-kx)
    A = A.at[_xface_right, _xface_left].add(-kx)

    A = A.at[_yface_bot, _yface_bot].add(ky)
    A = A.at[_yface_top, _yface_top].add(ky)
    A = A.at[_yface_bot, _yface_top].add(-ky)
    A = A.at[_yface_top, _yface_bot].add(-ky)

    A = A.at[_GAUGE_NODE, :].set(0.0)
    A = A.at[:, _GAUGE_NODE].set(0.0)
    A = A.at[_GAUGE_NODE, _GAUGE_NODE].set(1.0)
    return A


@jax.jit
def _build_eit_rhs(current_pattern_boundary):
    rhs = jnp.zeros(N * N, dtype=jnp.float64)
    flux = current_pattern_boundary * _boundary_ds
    rhs = rhs.at[boundary_indices_jax].add(flux)
    rhs = rhs.at[_GAUGE_NODE].set(0.0)
    return rhs


_RHS_ALL_PATTERNS = jnp.stack(
    [_build_eit_rhs(current_patterns_jax[l]) for l in range(N_CURRENT_PATTERNS)],
    axis=1,
)


@jax.jit
def solve_forward(alpha):
    log_sigma = jnp.reshape(Basis @ alpha, (N, N))
    sigma_field = jnp.exp(log_sigma)
    A = _assemble_eit_neumann(sigma_field)
    U = jnp.linalg.solve(A, _RHS_ALL_PATTERNS)
    V = U[obs_locations, :]
    V = V - jnp.mean(V, axis=0, keepdims=True)
    return V.T.ravel()


@jax.jit
def solve_forward_holdout(alpha):
    log_sigma = jnp.reshape(Basis @ alpha, (N, N))
    sigma_field = jnp.exp(log_sigma)
    A = _assemble_eit_neumann(sigma_field)
    U = jnp.linalg.solve(A, _RHS_ALL_PATTERNS)
    V = U[heldout_obs_locations, :]
    V = V - jnp.mean(V, axis=0, keepdims=True)
    return V.T.ravel()


@jax.jit
def solve_single_pattern(alpha, pattern_idx):
    log_sigma = jnp.reshape(Basis @ alpha, (N, N))
    sigma_field = jnp.exp(log_sigma)
    A = _assemble_eit_neumann(sigma_field)
    rhs = _build_eit_rhs(current_patterns_jax[pattern_idx])
    u = jnp.linalg.solve(A, rhs)
    return u.reshape(N, N)


# ==========================================
# Shared sampling configuration
# ==========================================

ACTIVE_DIM = num_truncated_series

np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
np.random.seed(seed)
alpha_true_np = np.random.randn(ACTIVE_DIM) * 0.60
y_clean_np = np.array(solve_forward(jnp.array(alpha_true_np)))
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_holdout_clean_np = np.array(solve_forward_holdout(jnp.array(alpha_true_np)))
y_holdout_obs_np = y_holdout_clean_np + np.random.normal(0.0, NOISE_STD, size=y_holdout_clean_np.shape)


def field_from_latent(alpha):
    return np.asarray(Basis @ jnp.asarray(alpha)).reshape((N, N))

true_field = field_from_latent(alpha_true_np)
y_holdout_clean_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))

def state_from_latent(alpha):
    return np.asarray(solve_single_pattern(jnp.asarray(alpha), 0))
