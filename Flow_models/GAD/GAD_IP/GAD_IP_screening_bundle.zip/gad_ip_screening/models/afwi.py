# Model and synthetic data preserved from the source recorded in provenance/catalog.json.
# Import only from run_problem.py, which assigns an isolated working directory.
import os
import random
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import torch
from scipy.spatial.distance import cdist
jax.config.update("jax_enable_x64", True)
os.makedirs("data", exist_ok=True)
N = 48
x = np.linspace(0.0, 1.0, N)
X, Y = np.meshgrid(x, x)
coords = np.column_stack([X.ravel(), Y.ravel()])

ell = 0.10
sigma_prior = 1.0
dists = cdist(coords, coords)
C = sigma_prior ** 2 * np.exp(-dists / ell)

eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]

q_max = 100
Basis_Modes = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])
np.savetxt('data/AcousticFWI_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# CONFIGURATION GENERATOR (ACOUSTIC FWI)
# ==========================================
num_truncated_series = 32
num_holdout_observation = 64
seed = int(os.environ.get("GAD_SCREEN_SEED", "42"))

BACKGROUND_VELOCITY = 1.0
VELOCITY_LOG_PERTURB_SCALE = 0.32
MODEL_XMIN = 0.10
MODEL_XMAX = 0.90
MODEL_YMIN = 0.16
MODEL_YMAX = 0.88
MODEL_MASK_SOFTNESS = 0.030

N_SOURCES = 8
SOURCE_DEPTH = 0.12
RECEIVER_DEPTH = 0.09
SOURCE_WIDTH = 0.020
SOURCE_COL_INDICES = np.round(np.linspace(4, N - 5, N_SOURCES)).astype(int)
RECEIVER_COL_INDICES = np.arange(1, N - 1)
N_RECEIVERS = RECEIVER_COL_INDICES.size

N_TIME_STEPS = 240
DT = 3.5e-3
RECORD_STRIDE = 4
RICKER_FREQ = 9.0
SPONGE_WIDTH_CELLS = 5
SPONGE_MAX_DAMP = 18.0


def _smooth_box_mask(xx, yy, x_lo, x_hi, y_lo, y_hi, softness):
    sig = lambda z: 1.0 / (1.0 + np.exp(-z / softness))
    return sig(xx - x_lo) * sig(x_hi - xx) * sig(yy - y_lo) * sig(y_hi - yy)


model_support_mask = _smooth_box_mask(
    X, Y, MODEL_XMIN, MODEL_XMAX, MODEL_YMIN, MODEL_YMAX, MODEL_MASK_SOFTNESS
)

source_xs = x[SOURCE_COL_INDICES]
source_centers = np.column_stack([source_xs, np.full(N_SOURCES, SOURCE_DEPTH)])
receiver_xs = x[RECEIVER_COL_INDICES]
receiver_coords = np.column_stack([receiver_xs, np.full(N_RECEIVERS, RECEIVER_DEPTH)])

receiver_rows = np.full(N_RECEIVERS, np.argmin(np.abs(x - RECEIVER_DEPTH)), dtype=int)
receiver_cols = RECEIVER_COL_INDICES.astype(int)
receiver_flat_indices = receiver_rows * N + receiver_cols

source_patterns = []
for sx, sy in source_centers:
    dist2 = (X - sx) ** 2 + (Y - sy) ** 2
    src = np.exp(-0.5 * dist2 / (SOURCE_WIDTH ** 2))
    src = src / np.sqrt(np.sum(src ** 2) + 1e-12)
    source_patterns.append(src)
source_patterns = np.stack(source_patterns, axis=0)


def _ricker_wavelet(times, f0):
    t0 = 4.0 / f0
    arg = np.pi * f0 * (times - t0)
    return (1.0 - 2.0 * arg ** 2) * np.exp(-arg ** 2)


times_np = DT * np.arange(N_TIME_STEPS)
source_wavelet = _ricker_wavelet(times_np, RICKER_FREQ)
source_time_series = np.tile(source_wavelet[None, :], (N_SOURCES, 1))
record_step_indices_np = np.arange(0, N_TIME_STEPS, RECORD_STRIDE, dtype=int)
record_times_np = times_np[record_step_indices_np]
N_RECORD_STEPS = record_step_indices_np.size
holdout_step_indices_np = np.setdiff1d(np.arange(N_TIME_STEPS, dtype=int), record_step_indices_np)
holdout_times_np = times_np[holdout_step_indices_np]
N_HOLDOUT_RECORD_STEPS = holdout_step_indices_np.size

ii, jj = np.meshgrid(np.arange(N), np.arange(N), indexing='ij')
dist_to_edge = np.minimum.reduce([ii, jj, (N - 1) - ii, (N - 1) - jj]).astype(np.float64)
sponge_profile = np.clip((SPONGE_WIDTH_CELLS - dist_to_edge) / max(SPONGE_WIDTH_CELLS, 1), 0.0, None)
damping_field = SPONGE_MAX_DAMP * sponge_profile ** 2

num_observation = N_SOURCES * N_RECEIVERS * N_RECORD_STEPS
dimension_of_PoI = N * N

df_modes = pd.read_csv('data/AcousticFWI_Basis_Modes.csv', header=None)
modes_raw = df_modes.to_numpy().flatten().astype(np.float64)
num_modes_available = modes_raw.size // dimension_of_PoI
full_basis = modes_raw.reshape((dimension_of_PoI, num_modes_available))
basis_truncated = full_basis[:, :num_truncated_series]

pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(receiver_flat_indices).to_csv('data/obs_locations.csv', index=False, header=False)
pd.DataFrame(source_centers, columns=['x', 'y']).to_csv('data/source_locations.csv', index=False)

key_holdout = jax.random.PRNGKey(seed + 1)
num_holdout_candidates = N_SOURCES * N_RECEIVERS * N_HOLDOUT_RECORD_STEPS
obs_indices_holdout = np.array(
    jax.random.choice(key_holdout, jnp.arange(num_holdout_candidates), shape=(num_holdout_observation,), replace=False)
)

# ==========================================
# Physics engine
# ==========================================
jax.config.update("jax_enable_x64", True)
Basis = jnp.array(basis_truncated)
model_support_mask_jax = jnp.array(model_support_mask, dtype=jnp.float64)
receiver_indices_jax = jnp.array(receiver_flat_indices, dtype=int)
source_patterns_jax = jnp.array(source_patterns, dtype=jnp.float64)
source_time_series_jax = jnp.array(source_time_series, dtype=jnp.float64)
damping_field_jax = jnp.array(damping_field, dtype=jnp.float64)
record_step_indices_jax = jnp.array(record_step_indices_np, dtype=int)
holdout_step_indices_jax = jnp.array(holdout_step_indices_np, dtype=int)
obs_indices_holdout_jax = jnp.array(obs_indices_holdout, dtype=int)

h = 1.0 / (N - 1)
ZERO_FIELD = jnp.zeros((N, N), dtype=jnp.float64)


def _flatten_measurements_by_source(gathers):
    return gathers.reshape(-1)


def _alpha_to_raw_and_velocity(alpha):
    raw_field = jnp.reshape(Basis @ alpha, (N, N))
    velocity = BACKGROUND_VELOCITY * jnp.exp(
        VELOCITY_LOG_PERTURB_SCALE * jnp.tanh(raw_field) * model_support_mask_jax
    )
    return raw_field, velocity


def _enforce_zero_boundary(u):
    u = u.at[0, :].set(0.0)
    u = u.at[-1, :].set(0.0)
    u = u.at[:, 0].set(0.0)
    u = u.at[:, -1].set(0.0)
    return u


def _laplacian_dirichlet(u):
    u_pad = jnp.pad(u, ((1, 1), (1, 1)), mode='constant', constant_values=0.0)
    return (
        u_pad[2:, 1:-1] + u_pad[:-2, 1:-1] + u_pad[1:-1, 2:] + u_pad[1:-1, :-2] - 4.0 * u
    ) / (h * h)


@jax.jit
def _simulate_single_shot_gather(velocity_field, source_idx):
    c2 = velocity_field ** 2
    src_spatial = source_patterns_jax[source_idx]
    src_time = source_time_series_jax[source_idx]

    def step(carry, src_amp):
        u_prev, u_curr = carry
        lap = _laplacian_dirichlet(u_curr)
        forcing = src_amp * src_spatial
        numer = (
            2.0 * u_curr
            - (1.0 - 0.5 * DT * damping_field_jax) * u_prev
            + (DT ** 2) * (c2 * lap + forcing)
        )
        u_next = numer / (1.0 + 0.5 * DT * damping_field_jax)
        u_next = _enforce_zero_boundary(u_next)
        rec = u_next.reshape(-1)[receiver_indices_jax]
        return (u_curr, u_next), rec

    (_, _), rec_all = jax.lax.scan(step, (ZERO_FIELD, ZERO_FIELD), src_time)
    rec_sub = rec_all[record_step_indices_jax, :]
    return rec_sub.T


@jax.jit
def _simulate_single_shot_gather_holdout(velocity_field, source_idx):
    c2 = velocity_field ** 2
    src_spatial = source_patterns_jax[source_idx]
    src_time = source_time_series_jax[source_idx]

    def step(carry, src_amp):
        u_prev, u_curr = carry
        lap = _laplacian_dirichlet(u_curr)
        forcing = src_amp * src_spatial
        numer = (
            2.0 * u_curr
            - (1.0 - 0.5 * DT * damping_field_jax) * u_prev
            + (DT ** 2) * (c2 * lap + forcing)
        )
        u_next = numer / (1.0 + 0.5 * DT * damping_field_jax)
        u_next = _enforce_zero_boundary(u_next)
        rec = u_next.reshape(-1)[receiver_indices_jax]
        return (u_curr, u_next), rec

    (_, _), rec_all = jax.lax.scan(step, (ZERO_FIELD, ZERO_FIELD), src_time)
    rec_sub = rec_all[holdout_step_indices_jax, :]
    return rec_sub.T


@jax.jit
def solve_forward(alpha):
    _, velocity_field = _alpha_to_raw_and_velocity(alpha)
    shot_ids = jnp.arange(N_SOURCES)
    gathers = jax.vmap(lambda s_idx: _simulate_single_shot_gather(velocity_field, s_idx))(shot_ids)
    return _flatten_measurements_by_source(gathers)


@jax.jit
def solve_forward_holdout(alpha):
    _, velocity_field = _alpha_to_raw_and_velocity(alpha)
    shot_ids = jnp.arange(N_SOURCES)
    gathers = jax.vmap(lambda s_idx: _simulate_single_shot_gather_holdout(velocity_field, s_idx))(shot_ids)
    holdout_vec = _flatten_measurements_by_source(gathers)
    return holdout_vec[obs_indices_holdout_jax]


@jax.jit
def solve_single_pattern(alpha, pattern_idx):
    _, velocity_field = _alpha_to_raw_and_velocity(alpha)
    return _simulate_single_shot_gather(velocity_field, pattern_idx)


# ==========================================
# Shared sampling configuration
# ==========================================

ACTIVE_DIM = num_truncated_series

np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
np.random.seed(seed)


def _project_raw_field_to_latent(raw_field, active_dim=ACTIVE_DIM):
    B = basis_truncated[:, :active_dim]
    alpha, *_ = np.linalg.lstsq(B, raw_field.reshape(-1), rcond=None)
    return alpha.astype(np.float64)



def _make_synthetic_raw_truth():
    lens_fast = 1.55 * np.exp(-(((X - 0.33) / 0.10) ** 2 + ((Y - 0.38) / 0.14) ** 2) / 2.0)
    lens_slow = -1.25 * np.exp(-(((X - 0.68) / 0.12) ** 2 + ((Y - 0.56) / 0.11) ** 2) / 2.0)
    ridge_center = 0.62 - 0.09 * np.sin(2.1 * np.pi * (X - 0.08))
    channel = -0.95 * np.exp(-0.5 * ((Y - ridge_center) / 0.050) ** 2) * np.exp(-0.5 * ((X - 0.56) / 0.28) ** 2)
    ripple = 0.18 * np.sin(2.0 * np.pi * X) * np.sin(1.5 * np.pi * Y)
    raw = (lens_fast + lens_slow + channel + ripple) * model_support_mask
    return raw.astype(np.float64)


raw_truth_np = _make_synthetic_raw_truth()
alpha_true_np = _project_raw_field_to_latent(raw_truth_np)
mode_decay = np.linspace(1.0, 0.65, ACTIVE_DIM)
alpha_true_np = alpha_true_np + 0.04 * np.random.randn(ACTIVE_DIM) * mode_decay

y_clean = solve_forward(jnp.array(alpha_true_np))
y_clean_np = np.array(y_clean)
NOISE_STD = 0.05 * np.std(y_clean_np)
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_holdout_clean_np = np.array(solve_forward_holdout(jnp.array(alpha_true_np)))
y_holdout_obs_np = y_holdout_clean_np + np.random.normal(0.0, NOISE_STD, size=y_holdout_clean_np.shape)


def field_from_latent(alpha):
    return np.asarray(_alpha_to_raw_and_velocity(jnp.asarray(alpha))[1])

true_field = field_from_latent(alpha_true_np)
y_holdout_clean_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))

def state_from_latent(alpha):
    return np.asarray(solve_single_pattern(jnp.asarray(alpha), 0))
