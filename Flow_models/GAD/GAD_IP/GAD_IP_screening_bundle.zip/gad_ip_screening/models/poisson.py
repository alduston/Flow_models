# Model and synthetic data preserved from the source recorded in provenance/catalog.json.
# Import only from run_problem.py, which assigns an isolated working directory.
import os
import random
import numpy as np
import pandas as pd
import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import torch
from scipy.spatial.distance import cdist
jax.config.update("jax_enable_x64", True)
os.makedirs("data", exist_ok=True)
N = 32
x = np.linspace(0.0, 1.0, N)
X, Y = np.meshgrid(x, x)
coords = np.column_stack([X.ravel(), Y.ravel()])

ELL = 0.1
SIGMA_PRIOR = 1.0
Q_MAX = 100

dists = cdist(coords, coords)
C = SIGMA_PRIOR ** 2 * np.exp(-dists / ELL)
eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]
Basis_Modes = eigvecs[:, :Q_MAX] * np.sqrt(eigvals[:Q_MAX])
np.savetxt('data/PoissonCoeff_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# 1. Configuration / data files
# ==========================================
num_observation_generated = 160
num_observation = 140
num_truncated_series = 32
seed = int(os.environ.get("GAD_SCREEN_SEED", "42"))

dimension_of_PoI = N * N
num_modes_available = Basis_Modes.shape[1]
basis_truncated = Basis_Modes[:, :num_truncated_series]

interior_mask = np.ones((N, N), dtype=bool)
interior_mask[0, :] = False
interior_mask[-1, :] = False
interior_mask[:, 0] = False
interior_mask[:, -1] = False
interior_indices = jnp.array(np.where(interior_mask.ravel())[0])

key = jax.random.PRNGKey(seed)
obs_indices_all = np.array(
    jax.random.choice(key, interior_indices, shape=(num_observation_generated,), replace=False)
)
obs_indices_train = obs_indices_all[:num_observation]
obs_indices_holdout = obs_indices_all[num_observation:]
obs_indices = obs_indices_train

pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(obs_indices_train).to_csv('data/obs_locations.csv', index=False, header=False)

# ==========================================
# 2. Physics: Poisson coefficient inversion
# ==========================================
jax.config.update("jax_enable_x64", True)

Basis = jnp.array(basis_truncated, dtype=jnp.float64)
obs_locations_train = jnp.array(obs_indices_train, dtype=int)
obs_locations_holdout = jnp.array(obs_indices_holdout, dtype=int)
obs_locations_all = jnp.array(obs_indices_all, dtype=int)
obs_locations = obs_locations_train

NOISE_STD = 1e-5

x_1d = jnp.linspace(0.0, 1.0, N)
X_grid, Y_grid = jnp.meshgrid(x_1d, x_1d, indexing='ij')
h = 1.0 / (N - 1)
Q_FLOOR = 0.15
SOURCE_FIELD = (
    0.18
    + 1.15 * jnp.exp(-(((X_grid - 0.18) ** 2) / (2.0 * 0.050 ** 2)
                       + ((Y_grid - 0.22) ** 2) / (2.0 * 0.070 ** 2)))
    + 0.95 * jnp.exp(-(((X_grid - 0.72) ** 2) / (2.0 * 0.085 ** 2)
                       + ((Y_grid - 0.32) ** 2) / (2.0 * 0.055 ** 2)))
    + 1.05 * jnp.exp(-(((X_grid - 0.56) ** 2) / (2.0 * 0.060 ** 2)
                       + ((Y_grid - 0.78) ** 2) / (2.0 * 0.065 ** 2)))
)

_int_mask = jnp.zeros((N, N), dtype=bool)
_int_mask = _int_mask.at[1:-1, 1:-1].set(True)
_int_rows, _int_cols = jnp.where(_int_mask)
n_int = _int_rows.shape[0]

_int_id = -jnp.ones((N, N), dtype=jnp.int32)
_int_id = _int_id.at[_int_rows, _int_cols].set(jnp.arange(n_int, dtype=jnp.int32))
int_flat = _int_rows * N + _int_cols


def _build_dirichlet_laplacian_matrix():
    h2 = h * h
    idx = jnp.arange(n_int)
    ir = _int_rows
    ic = _int_cols

    A = jnp.zeros((n_int, n_int), dtype=jnp.float64)
    A = A.at[idx, idx].add(4.0 / h2)

    nbr_E = _int_id[ir + 1, ic]
    nbr_W = _int_id[ir - 1, ic]
    nbr_N = _int_id[ir, ic + 1]
    nbr_S = _int_id[ir, ic - 1]

    A = A.at[idx, nbr_E].add(jnp.where(nbr_E >= 0, -1.0 / h2, 0.0))
    A = A.at[idx, nbr_W].add(jnp.where(nbr_W >= 0, -1.0 / h2, 0.0))
    A = A.at[idx, nbr_N].add(jnp.where(nbr_N >= 0, -1.0 / h2, 0.0))
    A = A.at[idx, nbr_S].add(jnp.where(nbr_S >= 0, -1.0 / h2, 0.0))

    rhs = SOURCE_FIELD[ir, ic]
    return A, rhs


LAPLACIAN_INT, RHS_INT = _build_dirichlet_laplacian_matrix()


@jax.jit
def raw_field_from_alpha(alpha):
    return jnp.reshape(Basis @ alpha, (N, N))


@jax.jit
def coefficient_from_raw(raw_field):
    return Q_FLOOR + jax.nn.softplus(raw_field)


@jax.jit
def solve_all_sensor_observations(alpha):
    raw_q = raw_field_from_alpha(alpha)
    q_field = coefficient_from_raw(raw_q)
    q_int = q_field[_int_rows, _int_cols]
    A = LAPLACIAN_INT + jnp.diag(q_int)
    u_int = jnp.linalg.solve(A, RHS_INT)
    u_full = jnp.zeros((N * N,), dtype=jnp.float64)
    u_full = u_full.at[int_flat].set(u_int)
    return u_full[obs_locations_all]


@jax.jit
def solve_forward(alpha):
    return solve_all_sensor_observations(alpha)[:num_observation]


@jax.jit
def solve_forward_holdout(alpha):
    return solve_all_sensor_observations(alpha)[num_observation:]


@jax.jit
def solve_full_state(alpha):
    raw_q = raw_field_from_alpha(alpha)
    q_field = coefficient_from_raw(raw_q)
    q_int = q_field[_int_rows, _int_cols]
    A = LAPLACIAN_INT + jnp.diag(q_int)
    u_int = jnp.linalg.solve(A, RHS_INT)
    u_full = jnp.zeros((N * N,), dtype=jnp.float64)
    u_full = u_full.at[int_flat].set(u_int)
    return u_full.reshape(N, N)



def make_structured_truth_coefficients(latent_dim=num_truncated_series):
    """Build a moderately structured synthetic raw coefficient field and project it into the KL basis."""
    X_np = np.array(X_grid)
    Y_np = np.array(Y_grid)

    # Dial back the old "8 blobs + 2 thin ridges + 2 high-frequency waves" setup.
    # Keep clear nontrivial structure, but make the field smoother and less crowded.
    blob_specs = [
        (0.95, 0.18, 0.20, 0.060, 0.075),
        (-0.80, 0.34, 0.72, 0.085, 0.070),
        (0.72, 0.54, 0.38, 0.070, 0.060),
        (-0.78, 0.69, 0.62, 0.075, 0.085),
        (0.62, 0.80, 0.24, 0.060, 0.055),
    ]

    raw_truth = np.zeros_like(X_np, dtype=np.float64)
    for amp, cx, cy, sx, sy in blob_specs:
        raw_truth += amp * np.exp(
            -(((X_np - cx) ** 2) / (2.0 * sx ** 2) + ((Y_np - cy) ** 2) / (2.0 * sy ** 2))
        )

    # Keep one elongated channel-like feature, but make it broader and less sharp.
    ridge_center = 0.82 - 0.60 * X_np + 0.03 * np.sin(2.0 * np.pi * X_np)
    raw_truth += -0.70 * np.exp(-((Y_np - ridge_center) ** 2) / (2.0 * 0.032 ** 2))

    # Retain multiscale texture, but reduce both frequency and amplitude.
    raw_truth += 0.16 * np.sin(4.5 * np.pi * X_np + 1.5 * np.pi * Y_np)
    raw_truth += 0.11 * np.cos(3.5 * np.pi * (X_np - 0.30 * Y_np))

    # Gentle low-frequency background variation so the field is not just isolated blobs.
    raw_truth += 0.10 * np.cos(2.0 * np.pi * Y_np)

    B = np.array(Basis)[:, :latent_dim]
    coeffs, *_ = np.linalg.lstsq(B, raw_truth.reshape(-1), rcond=None)
    return coeffs.astype(np.float64), raw_truth.astype(np.float64)


# ==========================================
# Shared sampling configuration
# ==========================================

ACTIVE_DIM = num_truncated_series

np.random.seed(seed)
random.seed(seed)
torch.manual_seed(seed)
alpha_true_np, raw_truth = make_structured_truth_coefficients(ACTIVE_DIM)
true_field = np.array(coefficient_from_raw(jnp.array(raw_truth)))

# Condition on the first num_observation sensors and reserve the remaining
# generated sensors for held-out posterior predictive calibration checks.
y_all_clean = solve_all_sensor_observations(jnp.array(alpha_true_np))
y_all_clean_np = np.array(y_all_clean)
y_noise_np = np.random.normal(0.0, NOISE_STD, size=y_all_clean_np.shape)
y_obs_all_np = y_all_clean_np + y_noise_np
y_clean_np = y_all_clean_np[:num_observation]
y_obs_np = y_obs_all_np[:num_observation]
y_holdout_clean_np = y_all_clean_np[num_observation:]
y_holdout_obs_np = y_obs_all_np[num_observation:]


def field_from_latent(alpha):
    return np.asarray(coefficient_from_raw(raw_field_from_alpha(jnp.asarray(alpha))))

true_field = field_from_latent(alpha_true_np)
y_holdout_clean_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))

def state_from_latent(alpha):
    return np.asarray(solve_full_state(jnp.asarray(alpha)))
