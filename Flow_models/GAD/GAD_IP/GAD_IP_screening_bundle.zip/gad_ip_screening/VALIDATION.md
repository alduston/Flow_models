# Validation before delivery

The preparation workspace does not have PyTorch or JAX installed. Full JAX autodiff, CUDA sampling, numerical convergence, GPU memory use, Vista scheduling, and elapsed experiment runtime have not been validated here. The sampler itself is an unchanged copy of the module in the completed repeat handoffs.

## Completed checks

- All executable bundle Python sources compile. The intentionally retained malformed historical modulus upload is provenance only and is excluded from executable compilation.
- Shell syntax checks pass for the submission, environment, task, and aggregation scripts.
- All **11 included unit/integration checks pass**: recursive transport-only config, actual sampler-schema normalization, source preservation, global-name resolution, work accounting, job-ID parsing, aggregation submission failure recovery, partial result packaging, positive/negative metric arithmetic, predictive covariance, and a successful task beside a failed neighbor.
- Every extracted original function body matches its historical source at the Python AST level.
- All ten models pass a **NumPy compatibility forward/interface check**, exercising the extracted functions, training/held-out outputs, reconstructed fields, and PDE-state visualizations. This compatibility check uses a NumPy implementation of the relevant array operations and loops; it does not execute JAX, reproduce its random-number stream, or validate derivatives.
- The same compatibility check exercised all five per-problem PNG generators with synthetic particle clouds, verifying figure generation for each model. These clouds are test fixtures, not experimental results.

## Forward/interface and plot checks

| Problem | Latent dim | Training / held out | PDE-state shape | Figures generated | Result |
|---|---:|---:|---|---:|---|
| advect_diff | 32 | 25 / 25 | 32 × 32 | 5 | pass |
| afwi | 32 | 22080 / 64 | 46 × 60 | 5 | pass |
| allen_cahn | 32 | 40 / 40 | 32 × 32 | 5 | pass |
| darcy | 32 | 120 / 30 | 32 × 32 | 5 | pass |
| eit_harder | 32 | 480 / 1008 | 32 × 32 | 5 | pass |
| heat | 24 | 10 / 10 | 16 × 16 | 5 | pass |
| helmholtz | 32 | 512 / 480 | 32 × 32 | 5 | pass |
| modulus | 32 | 192 / 48 | 32 × 32 | 5 | pass |
| navier_stokes | 36 | 80 / 40 | 32 × 32 | 5 | pass |
| poisson | 32 | 140 / 20 | 32 × 32 | 5 | pass |

## Checks on the actual target environment

The supplied `--check-models` option submits the real JAX forward/gradient/GN-curvature and finite-difference checks as a separate Vista batch. Normal screening tasks also enforce CUDA availability in both frameworks and validate realized array dimensions/data before invoking the sampler.

Scientific screening output is generated only by a normal sweep. Check-only batches never enter the selection ranking. No numerical screening result, win rate, contraction rate, or uncertainty estimate is asserted in this bundle.
