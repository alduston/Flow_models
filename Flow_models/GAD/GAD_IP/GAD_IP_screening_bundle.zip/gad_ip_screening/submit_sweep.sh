#!/bin/bash
set -euo pipefail
SCREEN_SOURCE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
# Submission needs only Python's standard library, so it can run on a login node.
exec python3 "$SCREEN_SOURCE_DIR/manage.py" submit "$@"
