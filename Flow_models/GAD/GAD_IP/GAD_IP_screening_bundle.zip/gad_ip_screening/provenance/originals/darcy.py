# -*- coding: utf-8 -*-
"""Darcy flow inverse-problem LFGI-GAD versus MALA benchmark.

Runs the three paper-facing rows requested for the inverse-problem comparison:
LFGI-GAD after one and three transport rounds, plus an exact-score MALA
baseline.  The hidden GAD round 2 is executed because it is part of the
round-3 path, but it is excluded from tables and plots.  MALA uses parallel
prior-initialized chains, warmup-only dual-averaging adaptation, a frozen
production kernel, and post-warmup draws.

Useful overrides:

    export IP_ITER_N_REF=1000
    export IP_ITER_ROUNDS=3
    export IP_ITER_TRANSPORT_STEPS=200
    export IP_MALA_N_CHAINS=32
    export IP_MALA_WARMUP=107
    export IP_MALA_THIN=1
    export IP_MALA_DT=1e-4
"""
import gc
import os
import random
import sys
from collections import OrderedDict

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.20")

try:
    THIS_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:  # notebook / pasted-cell fallback
    THIS_DIR = os.getcwd()

REPO_ROOT = os.path.dirname(THIS_DIR)
if THIS_DIR not in sys.path:
    sys.path.insert(0, THIS_DIR)
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from scipy.spatial.distance import cdist

from sampling import (
    GaussianPrior,
    compute_field_summary_metrics,
    compute_heldout_predictive_metrics,
    compute_latent_metrics,
    configure_sampling,
    get_valid_samples,
    init_run_results,
    make_physics_likelihood,
    make_posterior_score_fn,
    plot_mean_ess_logs,
    plot_pca_histograms,
    resolve_plot_normalizer,
    rmse_array,
    run_standard_sampler_pipeline,
    save_reproducibility_log,
    save_results_tables,
    summarize_sampler_run,
    zip_run_results_dir,
)

# ==========================================
# Dashboard PDF utilities
# ==========================================
# Produces a single multipage PDF containing the scalar metrics tables and every
# figure produced by this script. Console progress logs are intentionally not
# captured into the dashboard.

import glob
import numbers
import re
import shutil
import textwrap
from datetime import datetime
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.image as mpimg

SAVE_DASHBOARD_PDF = True
DASHBOARD_SHOW_FIGURES = True
DASHBOARD_PDF_PATH = None  # Filled after init_run_results(), inside the active run-results directory.


def _dashboard_is_scalar_cell(x):
    if x is None:
        return True
    if isinstance(x, (str, bool)):
        return True
    if isinstance(x, numbers.Number):
        return True
    if isinstance(x, np.generic):
        return True
    return False


def _dashboard_format_cell(x, max_len=72):
    if x is None:
        return ""
    try:
        if isinstance(x, np.generic):
            x = x.item()
    except Exception:
        pass
    if isinstance(x, numbers.Number):
        try:
            xf = float(x)
            if not np.isfinite(xf):
                return str(x)
            if abs(xf) >= 1e4 or (0 < abs(xf) < 1e-3):
                return f"{xf:.4e}"
            return f"{xf:.6g}"
        except Exception:
            return str(x)
    if isinstance(x, (list, tuple, dict, np.ndarray)):
        try:
            if isinstance(x, np.ndarray):
                return f"array{tuple(x.shape)}"
            return f"{type(x).__name__}[{len(x)}]"
        except Exception:
            return type(x).__name__
    s = str(x)
    if len(s) > max_len:
        return s[: max_len - 3] + "..."
    return s


def _dashboard_sanitize_df(df, include_index=True):
    df = pd.DataFrame(df).copy()
    if include_index and not isinstance(df.index, pd.RangeIndex):
        df = df.reset_index()
    for col in df.columns:
        df[col] = df[col].map(_dashboard_format_cell)
    df.columns = [_dashboard_format_cell(c, max_len=40) for c in df.columns]
    return df


def metrics_dict_to_scalar_df(metrics_dict, display_names=None):
    """Convert the metrics dictionary into a dashboard-friendly scalar table."""
    display_names = display_names or {}
    rows = []
    for label, data in metrics_dict.items():
        if not isinstance(data, dict):
            continue
        row = OrderedDict()
        row["Method"] = display_names.get(label, label)
        for key, val in data.items():
            if _dashboard_is_scalar_cell(val):
                row[key] = val
        rows.append(row)
    return pd.DataFrame(rows)


def nested_dict_to_df(dct, row_name="Method", display_names=None):
    """Convert nested dict/list records into a table without large arrays."""
    display_names = display_names or {}
    if isinstance(dct, pd.DataFrame):
        return dct.copy()
    rows = []
    if isinstance(dct, dict):
        iterable = dct.items()
    else:
        iterable = enumerate(dct)
    for key, val in iterable:
        row = OrderedDict()
        row[row_name] = display_names.get(key, key)
        if isinstance(val, dict):
            for k, v in val.items():
                if _dashboard_is_scalar_cell(v):
                    row[k] = v
                elif isinstance(v, (list, tuple, np.ndarray)):
                    row[k] = _dashboard_format_cell(v)
                else:
                    row[k] = _dashboard_format_cell(v)
        else:
            row["value"] = _dashboard_format_cell(val)
        rows.append(row)
    return pd.DataFrame(rows)


def sampler_configs_to_df(configs):
    rows = []
    for label, cfg in configs.items():
        row = OrderedDict()
        row["Method"] = label
        row.update(cfg)
        rows.append(row)
    return pd.DataFrame(rows)


class DashboardPDF:
    def __init__(self, path, title="Dashboard"):
        self.path = os.path.abspath(path)
        self.title = title
        self.enabled = bool(SAVE_DASHBOARD_PDF)
        self.pdf = PdfPages(self.path) if self.enabled else None
        self._seen_fig_ids = {id(plt.figure(num)) for num in plt.get_fignums()}
        self.figure_pages = 0
        self.table_pages = 0
        self.text_pages = 0

    def add_text_page(self, title, lines, footer=None, mono=False):
        if not self.enabled:
            return
        if isinstance(lines, str):
            lines = lines.splitlines()
        fig = plt.figure(figsize=(11, 8.5))
        fig.patch.set_facecolor("white")
        ax = fig.add_axes([0, 0, 1, 1])
        ax.axis("off")
        ax.text(0.055, 0.93, title, fontsize=18, fontweight="bold", va="top")
        y = 0.86
        fontsize = 9.2 if mono else 10.5
        family = "monospace" if mono else "sans-serif"
        for raw in lines:
            wrapped = textwrap.wrap(str(raw), width=112 if mono else 105) or [""]
            for line in wrapped:
                ax.text(0.06, y, line, fontsize=fontsize, family=family, va="top")
                y -= 0.033 if mono else 0.038
                if y < 0.08:
                    if footer:
                        ax.text(0.055, 0.035, footer, fontsize=8.5, alpha=0.65)
                    self.pdf.savefig(fig, bbox_inches="tight")
                    plt.close(fig)
                    self.text_pages += 1
                    fig = plt.figure(figsize=(11, 8.5))
                    fig.patch.set_facecolor("white")
                    ax = fig.add_axes([0, 0, 1, 1])
                    ax.axis("off")
                    ax.text(0.055, 0.93, title + " (cont.)", fontsize=18, fontweight="bold", va="top")
                    y = 0.86
        if footer:
            ax.text(0.055, 0.035, footer, fontsize=8.5, alpha=0.65)
        self.pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        self.text_pages += 1

    def add_dataframe(self, title, df, max_rows=28, max_cols=7, include_index=True):
        if not self.enabled:
            return
        df = _dashboard_sanitize_df(df, include_index=include_index)
        if df.empty:
            self.add_text_page(title, ["No rows available."])
            return

        # Keep the first column (usually Method / metric name) pinned on horizontal splits.
        first_col = [df.columns[0]]
        other_cols = list(df.columns[1:])
        cols_per_page = max(1, max_cols - 1)
        col_chunks = [other_cols[i:i + cols_per_page] for i in range(0, len(other_cols), cols_per_page)] or [[]]

        for ci, col_chunk in enumerate(col_chunks):
            cols = first_col + col_chunk
            df_col = df.loc[:, cols]
            for ri in range(0, len(df_col), max_rows):
                df_page = df_col.iloc[ri:ri + max_rows]
                fig, ax = plt.subplots(figsize=(11, 8.5))
                fig.patch.set_facecolor("white")
                ax.axis("off")
                suffix = ""
                if len(col_chunks) > 1:
                    suffix += f" - columns {ci + 1}/{len(col_chunks)}"
                if len(df_col) > max_rows:
                    suffix += f" - rows {ri + 1}-{min(ri + max_rows, len(df_col))}"
                ax.set_title(title + suffix, fontsize=15, fontweight="bold", pad=14)

                col_width = 1.0 / max(len(df_page.columns), 1)
                table = ax.table(
                    cellText=df_page.values,
                    colLabels=df_page.columns,
                    cellLoc="center",
                    colLoc="center",
                    loc="center",
                    colWidths=[col_width] * len(df_page.columns),
                )
                table.auto_set_font_size(False)
                table.set_fontsize(7.5 if len(df_page.columns) >= 6 else 8.5)
                table.scale(1.0, 1.25)
                for (row, col), cell in table.get_celld().items():
                    if row == 0:
                        cell.set_text_props(weight="bold")
                    if col == 0 and row > 0:
                        cell.set_text_props(ha="left")
                self.pdf.savefig(fig, bbox_inches="tight")
                plt.close(fig)
                self.table_pages += 1

    def _style_table_cells(self, table, header_fontsize=None, body_fontsize=None,
                           header_facecolor="0.92", first_col_left=True):
        """Apply consistent, readable table styling for dashboard pages."""
        for (row, col), cell in table.get_celld().items():
            cell.set_edgecolor("0.72")
            cell.set_linewidth(0.45)
            if row == 0:
                cell.set_facecolor(header_facecolor)
                cell.set_text_props(weight="bold", fontsize=header_fontsize)
            else:
                if row % 2 == 0:
                    cell.set_facecolor("0.985")
                if body_fontsize is not None:
                    cell.set_text_props(fontsize=body_fontsize)
                if first_col_left and col == 0:
                    cell.set_text_props(ha="left")

    def _add_table_block(self, ax, title, df, bbox, col_widths=None,
                         header_fontsize=8.2, body_fontsize=8.0):
        """Draw one compact table block inside an existing page."""
        df_fmt = _dashboard_sanitize_df(df, include_index=False)
        ax.text(bbox[0], bbox[1] + bbox[3] + 0.012, title,
                fontsize=11.5, fontweight="bold", va="bottom", ha="left")
        if df_fmt.empty:
            ax.text(bbox[0], bbox[1] + 0.5 * bbox[3], "No rows available.", fontsize=10)
            return
        n_cols = len(df_fmt.columns)
        if col_widths is None:
            first_w = 0.24 if n_cols > 1 else 1.0
            rest_w = (1.0 - first_w) / max(n_cols - 1, 1)
            col_widths = [first_w] + [rest_w] * (n_cols - 1)
        table = ax.table(
            cellText=df_fmt.values,
            colLabels=df_fmt.columns,
            cellLoc="center",
            colLoc="center",
            loc="center",
            colWidths=col_widths,
            bbox=bbox,
        )
        table.auto_set_font_size(False)
        table.set_fontsize(body_fontsize)
        self._style_table_cells(table, header_fontsize=header_fontsize, body_fontsize=body_fontsize)

    def _rename_runinfo_columns(self, df):
        """Shorten run-info headers enough to fit while preserving content."""
        rename = {
            "display_name": "method label",
            "method": "sampler",
            "weight_mode": "weights",
            "score_norm_initial": "score norm init",
            "score_norm_mean": "score norm mean",
            "score_norm_final": "score norm final",
            "score_norm_max": "score norm max",
            "pde_likelihood_evals": "PDE logL evals",
            "pde_score_evals": "PDE score evals",
            "pde_gn_hessian_evals": "PDE GN Hess evals",
            "pde_solve_count": "PDE solves",
            "runtime_seconds": "runtime (s)",
            "local_runtime_seconds": "local runtime (s)",
            "reference_method": "reference",
            "N_ref": "N ref",
            "path_depth": "chain depth",
            "mala_n_chains": "MALA chains",
            "mala_warmup": "MALA warmup",
            "mala_thin": "MALA thin",
            "mala_draws_per_chain": "draws / chain",
            "mala_dt_initial": "MALA dt init",
            "mala_dt_final": "MALA dt final",
            "mala_acceptance_rate": "MALA accept",
            "mala_rhat_median": "Rhat median",
            "mala_rhat_max": "Rhat max",
            "mala_unique_fraction": "unique frac",
        }
        return df.rename(columns={k: v for k, v in rename.items() if k in df.columns})

    def add_results_tables(self, results_df, results_runinfo_df):
        """Add exactly two table pages: canonical metrics and readable run-info.

        The metrics page keeps the saved *_metrics.csv / tables.tex layout. The
        run-info page preserves the saved *_runinfo.csv contents, but splits the
        many accounting columns into four normal table blocks on one page so it
        remains legible instead of becoming a tiny one-line wide table.
        """
        if not self.enabled:
            return

        # Page 1: metric rows x sampler columns, matching *_metrics.csv / tables.tex.
        metrics_fmt = _dashboard_sanitize_df(results_df, include_index=True)
        fig, ax = plt.subplots(figsize=(12.5, 8.5))
        fig.patch.set_facecolor("white")
        ax.axis("off")
        ax.set_title("Metrics table (saved *_metrics.csv / tables.tex layout)",
                     fontsize=18, fontweight="bold", pad=14)
        n_rows = max(len(metrics_fmt), 1)
        n_cols = max(len(metrics_fmt.columns), 1)
        first_w = 0.34 if n_cols > 1 else 0.95
        rest_w = (0.94 - first_w) / max(n_cols - 1, 1)
        col_widths = [first_w] + [rest_w] * (n_cols - 1)
        table = ax.table(
            cellText=metrics_fmt.values,
            colLabels=metrics_fmt.columns,
            cellLoc="center",
            colLoc="center",
            loc="center",
            colWidths=col_widths,
            bbox=[0.035, 0.055, 0.93, 0.86],
        )
        table.auto_set_font_size(False)
        # Larger text than the previous version; still adapts if many methods are added.
        body_fs = min(10.5, max(7.2, 120.0 / (n_rows + 0.75 * n_cols)))
        header_fs = min(10.5, body_fs + 0.5)
        table.set_fontsize(body_fs)
        self._style_table_cells(table, header_fontsize=header_fs, body_fontsize=body_fs)
        self.pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        self.table_pages += 1

        # Page 2: normal, readable run-info blocks on one page.
        runinfo = pd.DataFrame(results_runinfo_df).copy()
        target = ""
        if "target" in runinfo.columns and len(runinfo) > 0:
            target = str(runinfo["target"].iloc[0])
        runinfo = self._rename_runinfo_columns(runinfo)
        fig, ax = plt.subplots(figsize=(15.5, 10.0))
        fig.patch.set_facecolor("white")
        ax.axis("off")
        title = "Run-info table (saved *_runinfo.csv, split for readability)"
        if target:
            title += f" - {target}"
        ax.set_title(title, fontsize=18, fontweight="bold", pad=14)

        def cols_present(cols):
            return [c for c in cols if c in runinfo.columns]

        config_cols = cols_present([
            "method label", "sampler", "weights", "N ref", "steps", "chain depth",
            "reference", "runtime (s)",
        ])
        score_cols = cols_present([
            "method label", "score_norm", "score norm init", "score norm mean",
            "score norm final", "score norm max",
        ])
        budget_cols = cols_present([
            "method label", "PDE logL evals", "PDE score evals", "PDE GN Hess evals", "PDE solves",
        ])
        mala_cols = cols_present([
            "method label", "MALA chains", "MALA warmup", "MALA thin", "draws / chain",
            "MALA dt init", "MALA dt final", "MALA accept", "Rhat median", "Rhat max",
            "unique frac",
        ])
        if mala_cols and "sampler" in runinfo.columns:
            mala_rows = runinfo.loc[runinfo["sampler"].astype(str).str.upper() == "MALA", mala_cols]
        else:
            mala_rows = runinfo[mala_cols] if mala_cols else pd.DataFrame()

        # Normalized column widths for each block. First column gets label width;
        # remaining columns share the rest.
        def widths(n, first=0.24):
            if n <= 1:
                return [1.0]
            return [first] + [(1.0 - first) / (n - 1)] * (n - 1)

        if config_cols:
            self._add_table_block(
                ax, "Sampler configuration and runtime", runinfo[config_cols],
                bbox=[0.035, 0.670, 0.93, 0.225], col_widths=widths(len(config_cols), first=0.22),
                header_fontsize=8.2, body_fontsize=8.2,
            )
        if score_cols:
            self._add_table_block(
                ax, "Score-norm diagnostics", runinfo[score_cols],
                bbox=[0.035, 0.480, 0.93, 0.115], col_widths=widths(len(score_cols), first=0.30),
                header_fontsize=8.8, body_fontsize=8.7,
            )
        if not mala_rows.empty:
            self._add_table_block(
                ax, "MALA convergence diagnostics", mala_rows,
                bbox=[0.035, 0.275, 0.93, 0.125], col_widths=widths(len(mala_cols), first=0.20),
                header_fontsize=7.6, body_fontsize=8.2,
            )
        if budget_cols:
            self._add_table_block(
                ax, "PDE evaluation budget", runinfo[budget_cols],
                bbox=[0.035, 0.085, 0.93, 0.115], col_widths=widths(len(budget_cols), first=0.30),
                header_fontsize=8.8, body_fontsize=8.7,
            )

        # If future runinfo files add columns not covered above, surface them in a small note
        # instead of silently dropping them.
        used = set(config_cols + score_cols + budget_cols + mala_cols + ["target", "label"])
        extra = [c for c in runinfo.columns if c not in used]
        if extra:
            extra_text = ", ".join(extra[:8]) + (f" (+{len(extra) - 8} more in CSV)" if len(extra) > 8 else "")
            ax.text(0.035, 0.025, "Additional run-info columns: " + extra_text,
                    fontsize=7.0, alpha=0.75, ha="left", va="bottom")
        self.pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        self.table_pages += 1

    def _figure_sort_key(self, path):
        name = os.path.basename(path)
        m = re.search(r"_figure_(\d+)_", name)
        return (int(m.group(1)) if m else 10_000, name)

    def add_image_page(self, image_path):
        """Embed one saved PNG/JPG as a full dashboard page."""
        if not self.enabled or not os.path.exists(image_path):
            return
        img = mpimg.imread(image_path)
        h, w = img.shape[:2]
        aspect = w / max(h, 1)
        if aspect > 2.2:
            figsize = (18.0, 7.0)
        elif aspect > 1.35:
            figsize = (15.5, 9.0)
        else:
            figsize = (11.0, 10.0)
        fig = plt.figure(figsize=figsize)
        fig.patch.set_facecolor("white")
        ax = fig.add_axes([0.015, 0.015, 0.97, 0.97])
        ax.imshow(img)
        ax.axis("off")
        self.pdf.savefig(fig, bbox_inches="tight", pad_inches=0.03)
        plt.close(fig)
        self.figure_pages += 1

    def add_run_results_png_figures(self, run_results_dir):
        """Append all saved run-results PNG figures, sorted by figure number.

        This is intentionally based on the files saved by sampling.py's patched
        plt.show() hook, so dashboard coverage matches the normal run-results
        directory exactly: ESS, PCA, field reconstructions, wavefields, boundary
        traces, curvature spectra, and any future diagnostics.
        """
        if not self.enabled or not run_results_dir or not os.path.isdir(run_results_dir):
            return
        pngs = sorted(glob.glob(os.path.join(run_results_dir, "*.png")), key=self._figure_sort_key)
        for path in pngs:
            self.add_image_page(path)

    def add_figure(self, fig=None, close=False):
        if not self.enabled:
            return
        if fig is None:
            fig = plt.gcf()
        try:
            fig.savefig(self.pdf, format="pdf", bbox_inches="tight")
            self.figure_pages += 1
        except Exception as exc:
            self.add_text_page("Figure capture failed", [repr(exc)])
        if close:
            plt.close(fig)

    def capture_new_figures(self, close=False):
        if not self.enabled:
            return
        for num in list(plt.get_fignums()):
            fig = plt.figure(num)
            fig_id = id(fig)
            if fig_id not in self._seen_fig_ids:
                self.add_figure(fig, close=close)
                self._seen_fig_ids.add(fig_id)

    def close(self):
        if self.enabled and self.pdf is not None:
            self.pdf.close()
            self.pdf = None


def dashboard_copy_into_run_dir(dashboard_path, results_df_path=None):
    """Copy the dashboard into the run-results directory so it is included in the zip."""
    if not dashboard_path or not os.path.exists(dashboard_path) or results_df_path is None:
        return dashboard_path
    run_dir = os.path.dirname(os.path.abspath(results_df_path))
    os.makedirs(run_dir, exist_ok=True)
    dest = os.path.join(run_dir, os.path.basename(dashboard_path))
    if os.path.abspath(dest) != os.path.abspath(dashboard_path):
        shutil.copy2(dashboard_path, dest)
    return dest




################################################################################

# ==========================================
# 0. KL basis generation (match old script)
# ==========================================
os.makedirs('data', exist_ok=True)

N = 32
x = np.linspace(0.0, 1.0, N)
X, Y = np.meshgrid(x, x)
coords = np.column_stack([X.ravel(), Y.ravel()])

ell = 0.1
sigma_prior = 1.0
q_max = 100

dists = cdist(coords, coords)
C = sigma_prior ** 2 * np.exp(-dists / ell)
eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]
Basis_Modes = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])
np.savetxt('data/Darcy_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# 1. Configuration / data files (follow old I/O path exactly)
# ==========================================
num_observation = 120
num_holdout_observation = 30
num_truncated_series = 32
seed = int(os.environ.get("IP_RUN_SEED", "42"))
dimension_of_PoI = N * N

interior_mask = np.ones((N, N), dtype=bool)
interior_mask[0, :] = False
interior_mask[-1, :] = False
interior_mask[:, 0] = False
interior_mask[:, -1] = False
interior_indices = jnp.array(np.where(interior_mask.ravel())[0])

key = jax.random.PRNGKey(seed)
obs_indices_train = np.array(
    jax.random.choice(key, interior_indices, shape=(num_observation,), replace=False)
)
remaining_interior_indices = np.setdiff1d(np.asarray(interior_indices), obs_indices_train)
key_holdout = jax.random.PRNGKey(seed + 1)
obs_indices_holdout = np.array(
    jax.random.choice(key_holdout, jnp.array(remaining_interior_indices), shape=(num_holdout_observation,), replace=False)
)
obs_indices = obs_indices_train

# Load / truncate / resave exactly like the old script rather than using the
# in-memory eigendecomposition directly. This keeps the modular version aligned
# with the old data-generation path.
df_modes = pd.read_csv('data/Darcy_Basis_Modes.csv', header=None)
if isinstance(df_modes.iloc[0, 0], str):
    df_modes = pd.read_csv('data/Darcy_Basis_Modes.csv')

modes_raw = df_modes.to_numpy().flatten()
num_modes_available = modes_raw.size // dimension_of_PoI
full_basis = modes_raw.reshape((dimension_of_PoI, num_modes_available))
basis_truncated = full_basis[:, :num_truncated_series]

pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(obs_indices_train).to_csv('data/obs_locations.csv', index=False, header=False)

# Match old script's reload-from-disk path too.
df_Basis = pd.read_csv('data/Basis.csv', header=None)
df_obs = pd.read_csv('data/obs_locations.csv', header=None)

basis_raw = df_Basis.to_numpy().flatten()
if basis_raw.size % dimension_of_PoI == 1:
    basis_raw = basis_raw[1:]
basis_raw = basis_raw.astype(np.float64)

if basis_raw.size % dimension_of_PoI != 0:
    raise ValueError(
        f"Basis file size {basis_raw.size} is not divisible by grid size {dimension_of_PoI}."
    )

num_modes_in_file = basis_raw.size // dimension_of_PoI
full_basis = np.reshape(basis_raw, (dimension_of_PoI, num_modes_in_file))
Basis = jnp.array(full_basis[:, :num_truncated_series], dtype=jnp.float64)

obs_raw = df_obs.to_numpy().flatten()
if obs_raw.size == num_observation + 1:
    obs_raw = obs_raw[1:]
obs_raw = obs_raw.astype(int)
if obs_raw.size > num_observation:
    obs_raw = obs_raw[:num_observation]
elif obs_raw.size < num_observation:
    raise ValueError(f"Obs file only has {obs_raw.size} locations, need {num_observation}.")
obs_locations_train = jnp.array(obs_raw, dtype=int)
obs_locations_holdout = jnp.array(obs_indices_holdout, dtype=int)
obs_locations = obs_locations_train

# ==========================================
# 2. Physics: Darcy flow
# ==========================================
jax.config.update("jax_enable_x64", True)

NOISE_STD = 0.001

h = 1.0 / (N - 1)
x_1d = jnp.linspace(0.0, 1.0, N)
X_grid, Y_grid = jnp.meshgrid(x_1d, x_1d)
f_darcy = jnp.ones((N, N), dtype=jnp.float64)

_int_mask = jnp.zeros((N, N), dtype=bool)
_int_mask = _int_mask.at[1:-1, 1:-1].set(True)
_int_rows, _int_cols = jnp.where(_int_mask)
n_int = _int_rows.shape[0]

_int_id = -jnp.ones((N, N), dtype=jnp.int32)
_int_id = _int_id.at[_int_rows, _int_cols].set(jnp.arange(n_int, dtype=jnp.int32))
int_flat = _int_rows * N + _int_cols


def _assemble_darcy_vectorized(k_field):
    """
    Vectorized assembly of the interior Darcy stiffness matrix using the
    5-point finite-difference stencil with harmonic face averages.
    """
    h2 = h * h

    k_xp = 2.0 * k_field[:-1, :] * k_field[1:, :] / (k_field[:-1, :] + k_field[1:, :] + 1e-30)
    k_yp = 2.0 * k_field[:, :-1] * k_field[:, 1:] / (k_field[:, :-1] + k_field[:, 1:] + 1e-30)

    ir = _int_rows
    ic = _int_cols

    c_E = k_xp[ir, ic] / h2
    c_W = k_xp[ir - 1, ic] / h2
    c_N = k_yp[ir, ic] / h2
    c_S = k_yp[ir, ic - 1] / h2

    diag = c_E + c_W + c_N + c_S
    idx = jnp.arange(n_int)

    nbr_E = _int_id[ir + 1, ic]
    nbr_W = _int_id[ir - 1, ic]
    nbr_N = _int_id[ir, ic + 1]
    nbr_S = _int_id[ir, ic - 1]

    A = jnp.zeros((n_int, n_int), dtype=jnp.float64)
    A = A.at[idx, idx].add(diag)
    A = A.at[idx, nbr_E].add(jnp.where(nbr_E >= 0, -c_E, 0.0))
    A = A.at[idx, nbr_W].add(jnp.where(nbr_W >= 0, -c_W, 0.0))
    A = A.at[idx, nbr_N].add(jnp.where(nbr_N >= 0, -c_N, 0.0))
    A = A.at[idx, nbr_S].add(jnp.where(nbr_S >= 0, -c_S, 0.0))

    rhs = f_darcy[_int_rows, _int_cols]
    return A, rhs


@jax.jit
def solve_forward(alpha):
    log_k = jnp.reshape(Basis @ alpha, (N, N))
    k_field = jnp.exp(log_k)
    A, rhs = _assemble_darcy_vectorized(k_field)
    p_int = jnp.linalg.solve(A, rhs)
    p_full = jnp.zeros(N * N, dtype=jnp.float64)
    p_full = p_full.at[int_flat].set(p_int)
    return p_full[obs_locations_train]


@jax.jit
def solve_forward_holdout(alpha):
    log_k = jnp.reshape(Basis @ alpha, (N, N))
    k_field = jnp.exp(log_k)
    A, rhs = _assemble_darcy_vectorized(k_field)
    p_int = jnp.linalg.solve(A, rhs)
    p_full = jnp.zeros(N * N, dtype=jnp.float64)
    p_full = p_full.at[int_flat].set(p_int)
    return p_full[obs_locations_holdout]


@jax.jit
def solve_full_pressure(alpha):
    log_k = jnp.reshape(Basis @ alpha, (N, N))
    k_field = jnp.exp(log_k)
    A, rhs = _assemble_darcy_vectorized(k_field)
    p_int = jnp.linalg.solve(A, rhs)
    p_full = jnp.zeros(N * N, dtype=jnp.float64)
    p_full = p_full.at[int_flat].set(p_int)
    return p_full.reshape(N, N)


# ==========================================
# Shared sampling configuration
# ==========================================
ACTIVE_DIM = num_truncated_series
PLOT_NORMALIZER = 'best'
HESS_MIN = 1e-6
HESS_MAX = 1e6
DEFAULT_N_GEN = 1000
N_REF = 1000


# ==========================================
# LFGI-GAD versus MALA benchmark configuration
# ==========================================
# GAD follows T_1 -> ... -> T_K using GN-LFGI at every round.  Round 2 remains
# in the execution DAG but is hidden.  MALA is an independent prior-initialized
# exact-score baseline.  Its default schedule is intentionally close to the
# cumulative round-3 GAD budget under the portable solve-counting proxy used by
# sampling_gad_mala_20260814.py.

def _env_int(name, default):
    return int(os.environ.get(name, str(default)))


def _env_float(name, default):
    return float(os.environ.get(name, str(default)))


N_REF = _env_int('IP_ITER_N_REF', _env_int('IP_DARCY_ITER_N_REF', N_REF))
DEFAULT_N_GEN = _env_int('IP_ITER_DEFAULT_N_GEN', _env_int('IP_DARCY_ITER_DEFAULT_N_GEN', N_REF))
ITERATIVE_TRANSPORT_ROUNDS = _env_int('IP_ITER_ROUNDS', 3)
if ITERATIVE_TRANSPORT_ROUNDS != 3:
    raise ValueError('This exact paper comparison requires IP_ITER_ROUNDS=3.')
DISPLAY_TRANSPORT_ROUNDS = {1, 3}
TRANSPORT_STEPS = _env_int('IP_ITER_TRANSPORT_STEPS', 200)

MALA_N_CHAINS = max(1, _env_int('IP_MALA_N_CHAINS', 32))
MALA_THIN = max(1, _env_int('IP_MALA_THIN', 1))
MALA_EFFECTIVE_CHAINS = max(1, min(MALA_N_CHAINS, DEFAULT_N_GEN))
MALA_DRAWS_PER_CHAIN = int(np.ceil(DEFAULT_N_GEN / MALA_EFFECTIVE_CHAINS))
GAD3_EXPECTED_PDE_PROXY = 3 * 3 * N_REF
MALA_MATCHED_WARMUP = max(
    0,
    int(np.floor(
        GAD3_EXPECTED_PDE_PROXY / float(2 * MALA_EFFECTIVE_CHAINS)
        - 1
        - MALA_DRAWS_PER_CHAIN * MALA_THIN
    )),
)
MALA_WARMUP = max(0, _env_int('IP_MALA_WARMUP', MALA_MATCHED_WARMUP))
MALA_DT = _env_float('IP_MALA_DT', 1e-4)
MALA_TARGET_ACCEPT = _env_float('IP_MALA_TARGET_ACCEPT', 0.574)
MALA_MIN_DT = _env_float('IP_MALA_MIN_DT', 1e-12)
MALA_MAX_DT = _env_float('IP_MALA_MAX_DT', 1e-1)
MALA_PROGRESS_EVERY = _env_int('IP_MALA_PROGRESS_EVERY', 25)
MALA_ADAPT = os.environ.get('IP_MALA_ADAPT', '1').strip().lower() not in {'0', 'false', 'no', 'off'}

METHOD_SPECS = OrderedDict([
    ('LFGI-GAD', {
        'score': 'lfgi',
        'display': 'LFGI-GAD',
    }),
])


def make_gad_sampler_configs(method_specs, rounds=ITERATIVE_TRANSPORT_ROUNDS):
    """Build one transport-only chain per GAD method entry."""
    configs = OrderedDict()
    for method_key, spec in method_specs.items():
        score_method = spec['score']
        display_base = spec['display']
        previous_label = None
        for round_idx in range(1, int(rounds) + 1):
            transport_label = f'{method_key}-{round_idx}'
            transport_cfg = {
                'node': 'transport',
                'score': score_method,
                'steps': TRANSPORT_STEPS,
                'n_samples': DEFAULT_N_GEN,
                'n_ref': N_REF,
                'n_gate': N_REF,
                'bank_coupling': 'shared',
                'log_mean_ess': True,
                'include_results': round_idx in DISPLAY_TRANSPORT_ROUNDS,
                'display_name': f'{display_base} {round_idx}',
            }
            if previous_label is not None:
                transport_cfg['ref_source'] = previous_label
            configs[transport_label] = transport_cfg
            previous_label = transport_label

    return configs


SAMPLER_CONFIGS = make_gad_sampler_configs(METHOD_SPECS)
SAMPLER_CONFIGS['MALA'] = {
    'node': 'mala',
    'n_samples': DEFAULT_N_GEN,
    'mala_n_chains': MALA_N_CHAINS,
    'mala_warmup': MALA_WARMUP,
    'mala_thin': MALA_THIN,
    'mala_dt': MALA_DT,
    'mala_adapt': MALA_ADAPT,
    'mala_target_accept': MALA_TARGET_ACCEPT,
    'mala_min_dt': MALA_MIN_DT,
    'mala_max_dt': MALA_MAX_DT,
    'mala_progress_every': MALA_PROGRESS_EVERY,
    'include_results': True,
    'is_reference': True,
    'display_name': 'MALA',
}

MALA_TOTAL_TRANSITIONS = MALA_WARMUP + MALA_DRAWS_PER_CHAIN * MALA_THIN
MALA_EXPECTED_PDE_PROXY = 2 * MALA_EFFECTIVE_CHAINS * (MALA_TOTAL_TRANSITIONS + 1)
MALA_TO_GAD3_PROXY_RATIO = MALA_EXPECTED_PDE_PROXY / float(max(1, GAD3_EXPECTED_PDE_PROXY))

configure_sampling(
    active_dim=ACTIVE_DIM,
    default_n_gen=DEFAULT_N_GEN,
    hess_min=HESS_MIN,
    hess_max=HESS_MAX,
)
run_ctx = init_run_results('darcy_lfgi_gad1_gad3_mala_20260814')
DASHBOARD_PDF_PATH = os.path.join(
    run_ctx['run_results_dir'],
    f"{run_ctx['run_results_stem']}_summary_dashboard.pdf",
)

RUN_COMMAND_HINT = (
    f'IP_RUN_SEED={seed} '
    'IP_ITER_N_REF={n_ref} IP_ITER_ROUNDS={rounds} '
    'IP_ITER_TRANSPORT_STEPS={transport_steps} IP_MALA_N_CHAINS={mala_chains} '
    'IP_MALA_WARMUP={mala_warmup} IP_MALA_THIN={mala_thin} IP_MALA_DT={mala_dt} '
    'python darcy.py'
).format(
    n_ref=N_REF,
    rounds=ITERATIVE_TRANSPORT_ROUNDS,
    transport_steps=TRANSPORT_STEPS,
    mala_chains=MALA_N_CHAINS,
    mala_warmup=MALA_WARMUP,
    mala_thin=MALA_THIN,
    mala_dt=MALA_DT,
)

if not 0.90 <= MALA_TO_GAD3_PROXY_RATIO <= 1.10:
    print(
        'WARNING: configured MALA budget is not within 10% of cumulative LFGI-GAD 3 '
        f'under the portable PDE proxy (ratio={MALA_TO_GAD3_PROXY_RATIO:.4f}). '
        'Unset IP_MALA_WARMUP to use the automatic matched default.'
    )

# ==========================================
# 3. Experiment execution
# ==========================================
gc.collect()
if torch.cuda.is_available():
    torch.cuda.empty_cache()

random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(seed)
alpha_true_np = np.random.randn(ACTIVE_DIM) * 0.5

y_clean = solve_forward(jnp.array(alpha_true_np))
y_clean_np = np.array(y_clean)
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_holdout_clean_np = np.array(solve_forward_holdout(jnp.array(alpha_true_np)))
y_holdout_obs_np = y_holdout_clean_np + np.random.normal(0.0, NOISE_STD, size=y_holdout_clean_np.shape)


dashboard = DashboardPDF(
    DASHBOARD_PDF_PATH,
    title='Darcy flow LFGI-GAD versus MALA dashboard',
)
dashboard.add_text_page(
    'Darcy flow LFGI-GAD versus MALA dashboard',
    [
        f"Created: {datetime.now().isoformat(timespec='seconds')}",
        'Paper-facing rows are LFGI-GAD 1, LFGI-GAD 3, and MALA. GAD round 2 is executed as a hidden dependency of round 3.',
        'MALA is prior-initialized and exact-score. Dual averaging is restricted to warmup; the production kernel is frozen before samples are retained.',
        'The MALA row is marked as the distributional reference for the legacy MMD diagnostic, so its self-MMD is zero by construction. Primary inverse-problem comparisons should use KSD, reconstruction, prediction, calibration, and work.',
        'Included PNG diagnostics: ESS vs diffusion time, PCA histograms, log-permeability reconstructions, pressure fields, and permeability fields.',
        'Tables are intentionally limited to two pages: metrics plus a readable split run-info page.',
        'Random progress output from precomputation / Hessian batching is intentionally excluded.',
        f"run_results_dir = {run_ctx['run_results_dir']}",
        '',
        f'seed = {seed}',
        f'ACTIVE_DIM = {ACTIVE_DIM}',
        f'N_REF = {N_REF}',
        f'DEFAULT_N_GEN = {DEFAULT_N_GEN}',
        f'ITERATIVE_TRANSPORT_ROUNDS = {ITERATIVE_TRANSPORT_ROUNDS}',
        f'DISPLAY_TRANSPORT_ROUNDS = {sorted(DISPLAY_TRANSPORT_ROUNDS)}',
        f'TRANSPORT_STEPS = {TRANSPORT_STEPS}',
        f'MALA_N_CHAINS = {MALA_N_CHAINS}',
        f'MALA_WARMUP = {MALA_WARMUP}',
        f'MALA_MATCHED_WARMUP (automatic default) = {MALA_MATCHED_WARMUP}',
        f'MALA_THIN = {MALA_THIN}',
        f'MALA_DT = {MALA_DT}',
        f'MALA_ADAPT = {MALA_ADAPT}',
        f'MALA_TARGET_ACCEPT = {MALA_TARGET_ACCEPT}',
        f'Expected MALA PDE proxy = {MALA_EXPECTED_PDE_PROXY}',
        f'Expected cumulative LFGI-GAD 3 PDE proxy = {GAD3_EXPECTED_PDE_PROXY}',
        f'MALA / LFGI-GAD 3 expected proxy ratio = {MALA_TO_GAD3_PROXY_RATIO:.4f}',
        f'NOISE_STD = {NOISE_STD}',
        f'N = {N}, num_observation = {num_observation}, num_holdout_observation = {num_holdout_observation}',
        f'HESS_MIN = {HESS_MIN}, HESS_MAX = {HESS_MAX}',
        f'PLOT_NORMALIZER = {PLOT_NORMALIZER}',
        f'run command = {RUN_COMMAND_HINT}',
    ],
)

batch_solve_forward_holdout = jax.jit(jax.vmap(solve_forward_holdout))

prior_model = GaussianPrior(dim=ACTIVE_DIM)
lik_model, lik_aux = make_physics_likelihood(
    solve_forward,
    y_obs_np,
    NOISE_STD,
    use_gauss_newton_hessian=True,
    log_batch_size=50,
    grad_batch_size=25,
    hess_batch_size=2,
)
posterior_score_fn = make_posterior_score_fn(lik_model)

pipeline = run_standard_sampler_pipeline(
    prior_model,
    lik_model,
    SAMPLER_CONFIGS,
    n_ref=N_REF,
)
precomp = pipeline['precomp']
samples = pipeline['samples']
ess_logs = pipeline['ess_logs']
sampler_run_info = pipeline['sampler_run_info']
display_names = pipeline['display_names']
reference_key = pipeline['reference_key']
reference_title = pipeline['reference_title']

summarize_sampler_run(sampler_run_info)
plot_mean_ess_logs(ess_logs, display_names=display_names)

metrics = compute_latent_metrics(
    samples,
    reference_key,
    alpha_true_np,
    prior_model,
    lik_model,
    posterior_score_fn,
    display_names=display_names,
)

Basis_np = np.array(Basis)
obs_locs_np = np.array(obs_locations)
obs_row = obs_locs_np // N
obs_col = obs_locs_np % N


def reconstruct_log_permeability(latents):
    if isinstance(latents, torch.Tensor):
        latents = latents.detach().cpu().numpy()
    latents = np.asarray(latents)
    if latents.ndim == 1:
        latents = latents[None, :]
    d_lat = latents.shape[1]
    B = Basis_np[:, :d_lat]
    fields_flat = latents @ B.T
    return fields_flat.reshape((-1, N, N))


def latent_to_log_permeability(alpha):
    return reconstruct_log_permeability(np.asarray(alpha)[None, :])[0]


def solve_pressure_field(alpha_vec):
    return np.array(solve_full_pressure(jnp.array(alpha_vec)))


true_field = latent_to_log_permeability(alpha_true_np)
true_pressure = solve_pressure_field(alpha_true_np)
true_perm = np.exp(true_field)

mean_fields, metrics = compute_field_summary_metrics(
    samples,
    metrics,
    alpha_true_np,
    true_field,
    field_from_latent_fn=latent_to_log_permeability,
    forward_eval_fn=lambda a: np.array(solve_forward(jnp.array(a))),
    y_ref_np=y_clean_np,
    display_names=display_names,
    min_valid=10,
    d_lat=ACTIVE_DIM,
)

try:
    metrics = compute_heldout_predictive_metrics(
        samples,
        metrics,
        heldout_forward_eval_fn=lambda a: np.array(solve_forward_holdout(jnp.array(a))),
        batched_forward_eval_fn=lambda a_batch: np.asarray(
            batch_solve_forward_holdout(jnp.asarray(a_batch, dtype=jnp.float64))
        ),
        batched_forward_eval_batch_size=8,
        y_holdout_obs_np=y_holdout_obs_np,
        noise_std=NOISE_STD,
        display_names=display_names,
        min_valid=10,
    )
except Exception as exc:
    print(f"WARNING: held-out predictive metrics failed and will be skipped: {exc}")

mean_pressures = {}
mean_permeabilities = {}
norm_true_pressure = np.linalg.norm(true_pressure) + 1e-12

print('\n=== Darcy physical-space metrics ===')
print(f"{'Method':<32} | {'LogPerm RelL2(%)':<18} | {'Pearson':<10} | {'RMSE_a':<12} | {'PressureRel':<12} | {'SensorRel':<12} | {'HeldoutNLL':<12} | {'HeldoutZ2':<12}")
print('-' * 160)
for label in [lab for lab in samples.keys() if lab in mean_fields]:
    mean_latent = np.asarray(metrics[label]['mean_latent'])
    mean_pressure = solve_pressure_field(mean_latent)
    mean_pressures[label] = mean_pressure
    mean_perm = np.exp(mean_fields[label])
    mean_permeabilities[label] = mean_perm
    pressure_rel = float(np.linalg.norm(mean_pressure - true_pressure) / norm_true_pressure)
    metrics[label]['RMSE_pressure'] = rmse_array(mean_pressure, true_pressure)
    metrics[label]['RelL2_pressure'] = pressure_rel
    logperm_rel_pct = 100.0 * float(metrics[label]['RelL2_field'])
    print(
        f"{display_names.get(label, label):<32} | {logperm_rel_pct:<18.4f} | "
        f"{metrics[label].get('Pearson_field', float('nan')):<10.4f} | {metrics[label]['RMSE_alpha']:<12.4e} | "
        f"{pressure_rel:<12.4e} | {metrics[label].get('FwdRelErr', float('nan')):<12.4e} | "
        f"{metrics[label].get('HeldoutPredNLL', np.nan):<12.4e} | {metrics[label].get('HeldoutStdResSq', np.nan):<12.4e}"
    )

plot_normalizer_key = resolve_plot_normalizer(
    PLOT_NORMALIZER,
    list(mean_fields.keys()),
    display_names=display_names,
    metrics_dict=metrics,
    fallback=reference_key,
    best_metric_keys=('RelL2_field',),
)
plot_normalizer_title = display_names.get(plot_normalizer_key, plot_normalizer_key)
plot_pca_histograms(
    samples,
    alpha_true_np,
    display_names=display_names,
    normalizer=plot_normalizer_key,
    metrics_dict=metrics,
    fallback_key=reference_key,
)

results_df, results_runinfo_df, results_df_path, results_runinfo_df_path = save_results_tables(
    metrics,
    sampler_run_info,
    n_ref=N_REF,
    target_name='Darcy flow log-permeability',
    display_names=display_names,
    reference_name=reference_title,
)

dashboard.add_results_tables(results_df, results_runinfo_df)

save_reproducibility_log(
    title='Darcy flow LFGI-GAD versus MALA reproducibility log',
    config={
        'seed': seed,
        'ACTIVE_DIM': ACTIVE_DIM,
        'DEFAULT_N_GEN': DEFAULT_N_GEN,
        'HESS_MAX': HESS_MAX,
        'HESS_MIN': HESS_MIN,
        'N': N,
        'NOISE_STD': NOISE_STD,
        'N_REF': N_REF,
        'ITERATIVE_TRANSPORT_ROUNDS': ITERATIVE_TRANSPORT_ROUNDS,
        'DISPLAY_TRANSPORT_ROUNDS': sorted(DISPLAY_TRANSPORT_ROUNDS),
        'TRANSPORT_STEPS': TRANSPORT_STEPS,
        'MALA_N_CHAINS': MALA_N_CHAINS,
        'MALA_WARMUP': MALA_WARMUP,
        'MALA_MATCHED_WARMUP': MALA_MATCHED_WARMUP,
        'MALA_THIN': MALA_THIN,
        'MALA_DT': MALA_DT,
        'MALA_ADAPT': MALA_ADAPT,
        'MALA_TARGET_ACCEPT': MALA_TARGET_ACCEPT,
        'MALA_MIN_DT': MALA_MIN_DT,
        'MALA_MAX_DT': MALA_MAX_DT,
        'MALA_EXPECTED_PDE_PROXY': MALA_EXPECTED_PDE_PROXY,
        'GAD3_EXPECTED_PDE_PROXY': GAD3_EXPECTED_PDE_PROXY,
        'MALA_TO_GAD3_PROXY_RATIO': MALA_TO_GAD3_PROXY_RATIO,
        'METHOD_SPECS': METHOD_SPECS,
        'SAMPLER_CONFIGS': SAMPLER_CONFIGS,
        'USE_GAUSS_NEWTON_HESSIAN': True,
        'PLOT_NORMALIZER': PLOT_NORMALIZER,
        'plot_normalizer_key': plot_normalizer_key,
        'plot_normalizer_title': plot_normalizer_title,
        'dimension_of_PoI': dimension_of_PoI,
        'num_modes_available': num_modes_available,
        'num_observation': num_observation,
        'num_holdout_observation': num_holdout_observation,
        'num_truncated_series': num_truncated_series,
        'obs_indices_train': obs_indices_train,
        'obs_indices_holdout': obs_indices_holdout,
        'obs_locations_train': obs_locations_train,
        'obs_locations_holdout': obs_locations_holdout,
        'sigma_prior': sigma_prior,
        'ell': ell,
    },
    extra_sections={
        'saved_results_files': {
            'metrics_csv': results_df_path,
            'runinfo_csv': results_runinfo_df_path,
            'dashboard_pdf': DASHBOARD_PDF_PATH,
        },
        'summary_stats': {
            'reference_key': reference_key,
            'reference_title': reference_title,
            'plot_normalizer_key': plot_normalizer_key,
            'plot_normalizer_title': plot_normalizer_title,
            'num_methods_evaluated': len(results_df.columns),
            'num_methods_with_samples': len(samples),
            'num_methods_with_mean_fields': len(mean_fields),
            'num_methods_with_mean_pressures': len(mean_pressures),
            'num_methods_with_ess_logs': len(ess_logs),
        },
    },
)

# ==========================================
# 4. Problem-specific visualization
# ==========================================
print('\nVisualizing Darcy field reconstructions...')
methods_to_plot = [label for label in samples.keys() if label in mean_fields]
n_cols = len(methods_to_plot) + 1

if n_cols > 1:
    fig, axes = plt.subplots(4, n_cols, figsize=(4 * n_cols, 14))

    vis_anchor_key = plot_normalizer_key if plot_normalizer_key in mean_fields else next(iter(mean_fields.keys()))

    vmin = float(np.min(true_field))
    vmax = float(np.max(true_field))

    if vis_anchor_key in samples and vis_anchor_key in mean_fields:
        anchor_vis_samps = get_valid_samples(samples[vis_anchor_key])[:1000]
        if anchor_vis_samps.shape[0] > 0:
            anchor_vis_fields = reconstruct_log_permeability(anchor_vis_samps[:, :ACTIVE_DIM])
            max_err = max(1e-12, float(np.abs(mean_fields[vis_anchor_key] - true_field).max()))
            max_std = max(1e-12, float(np.std(anchor_vis_fields, axis=0).max()))
        else:
            max_err = 1e-12
            max_std = 1e-12
    else:
        max_err = 1e-12
        max_std = 1e-12

    if vis_anchor_key not in mean_fields:
        max_err = 1e-12
        max_std = 1e-12
        for label in methods_to_plot:
            mean_f = mean_fields[label]
            max_err = max(max_err, np.abs(mean_f - true_field).max())
            samps = get_valid_samples(samples[label])[:500]
            if samps.shape[0] > 0:
                fields = reconstruct_log_permeability(samps[:, :ACTIVE_DIM])
                max_std = max(max_std, np.std(fields, axis=0).max())

    im0 = axes[0, 0].imshow(true_field, cmap='RdBu_r', origin='lower', vmin=vmin, vmax=vmax)
    axes[0, 0].scatter(obs_col, obs_row, c='lime', s=8, marker='.', alpha=0.7, label='Sensors')
    axes[0, 0].set_title('Ground Truth\nLog-Permeability $m(x)$', fontsize=18)
    axes[0, 0].axis('off')
    plt.colorbar(im0, ax=axes[0, 0], fraction=0.046, pad=0.04)

    axes[3, 0].imshow(true_field, cmap='RdBu_r', origin='lower', vmin=vmin, vmax=vmax)
    axes[3, 0].set_title('Ground Truth', fontsize=14)
    axes[3, 0].axis('off')
    axes[1, 0].axis('off')
    axes[2, 0].axis('off')

    for i, label in enumerate(methods_to_plot):
        col = i + 1
        mean_f = mean_fields[label]

        axes[0, col].imshow(mean_f, cmap='RdBu_r', origin='lower', vmin=vmin, vmax=vmax)
        axes[0, col].scatter(obs_col, obs_row, c='lime', s=8, marker='.', alpha=0.5)
        axes[0, col].set_title(f"{display_names.get(label, label)}\nMean Posterior", fontsize=18)
        axes[0, col].axis('off')

        err_f = np.abs(mean_f - true_field)
        axes[1, col].imshow(err_f, cmap='inferno', origin='lower', vmin=0, vmax=max_err)
        axes[1, col].set_title(f"Error Map\n(Max: {err_f.max():.2f})", fontsize=16)
        axes[1, col].axis('off')

        samps = get_valid_samples(samples[label])[:1000]
        if samps.shape[0] > 0:
            fields = reconstruct_log_permeability(samps[:, :ACTIVE_DIM])
            std_f = np.std(fields, axis=0)
        else:
            std_f = np.zeros_like(true_field)
        axes[2, col].imshow(std_f, cmap='viridis', origin='lower', vmin=0, vmax=max_std)
        axes[2, col].set_title(f"Uncertainty\n(Max std: {std_f.max():.2f})", fontsize=16)
        axes[2, col].axis('off')

        if samps.shape[0] > 0:
            sample_field = reconstruct_log_permeability(samps[:1, :ACTIVE_DIM])[0]
            axes[3, col].imshow(sample_field, cmap='RdBu_r', origin='lower', vmin=vmin, vmax=vmax)
            axes[3, col].set_title('Posterior Sample', fontsize=14)
        else:
            axes[3, col].text(0.5, 0.5, 'No valid\nsamples', ha='center', va='center', transform=axes[3, col].transAxes)
        axes[3, col].axis('off')

    plt.suptitle(f'Inverse Darcy flow: LFGI-GAD versus MALA (d={ACTIVE_DIM})', fontsize=22, y=1.01)
    plt.tight_layout()
    plt.show()

    print('\nVisualizing pressure fields...')
    fig2, axes2 = plt.subplots(1, n_cols, figsize=(4 * n_cols, 4))

    true_pmin = float(np.min(true_pressure))
    true_pmax = float(np.max(true_pressure))
    im_true_pressure = axes2[0].imshow(true_pressure, cmap='viridis', origin='lower', vmin=true_pmin, vmax=true_pmax)
    axes2[0].scatter(obs_col, obs_row, c='red', s=12, marker='.', alpha=0.7, label='Sensors')
    axes2[0].set_title('Ground Truth\nPressure $p(x)$', fontsize=14)
    axes2[0].axis('off')
    axes2[0].legend(fontsize=8, loc='upper right')
    plt.colorbar(im_true_pressure, ax=axes2[0], fraction=0.046, pad=0.04)

    for i, label in enumerate(methods_to_plot):
        col = i + 1
        mean_pressure = mean_pressures.get(label)
        if mean_pressure is None:
            axes2[col].axis('off')
            continue
        axes2[col].imshow(mean_pressure, cmap='viridis', origin='lower', vmin=true_pmin, vmax=true_pmax)
        axes2[col].scatter(obs_col, obs_row, c='red', s=12, marker='.', alpha=0.5)
        axes2[col].set_title(f"{display_names.get(label, label)}\nPressure", fontsize=14)
        axes2[col].axis('off')

    plt.suptitle(f'Inverse Darcy flow LFGI-GAD versus MALA (d={ACTIVE_DIM}): pressure field', fontsize=16, y=1.05)
    plt.tight_layout()
    plt.show()

    print('\nVisualizing permeability fields $k(x)=e^{m(x)}$...')
    fig3, axes3 = plt.subplots(1, n_cols, figsize=(4 * n_cols, 4))

    perm_vmin = float(np.min(true_perm))
    perm_vmax = float(np.max(true_perm))
    im_true_perm = axes3[0].imshow(true_perm, cmap='magma', origin='lower', vmin=perm_vmin, vmax=perm_vmax)
    axes3[0].set_title('Ground Truth\n$k(x)=e^{m(x)}$', fontsize=14)
    axes3[0].axis('off')
    plt.colorbar(im_true_perm, ax=axes3[0], fraction=0.046, pad=0.04)

    for i, label in enumerate(methods_to_plot):
        col = i + 1
        mean_perm = mean_permeabilities.get(label)
        if mean_perm is None:
            axes3[col].axis('off')
            continue
        axes3[col].imshow(mean_perm, cmap='magma', origin='lower', vmin=perm_vmin, vmax=perm_vmax)
        axes3[col].set_title(f"{display_names.get(label, label)}\n$k(x)=e^{{m(x)}}$", fontsize=14)
        axes3[col].axis('off')

    plt.suptitle(f'Inverse Darcy flow LFGI-GAD versus MALA (d={ACTIVE_DIM}): permeability field', fontsize=16, y=1.05)
    plt.tight_layout()
    plt.show()
else:
    print('WARNING: no Darcy methods available for visualization.')

if DASHBOARD_SHOW_FIGURES:
    dashboard.add_run_results_png_figures(run_ctx['run_results_dir'])
dashboard.close()
plt.close('all')
run_results_zip_path = zip_run_results_dir(extra_paths=[DASHBOARD_PDF_PATH])
print(f"Run-results directory: {run_ctx['run_results_dir']}")
print(f'Dashboard PDF: {DASHBOARD_PDF_PATH}')
print(f'Run-results zip: {run_results_zip_path}')
print('\n=== Darcy flow LFGI-GAD versus MALA comparison pipeline complete ===')
