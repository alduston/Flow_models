# -*- coding: utf-8 -*-
"""Helmholtz inverse scattering: NS-analogous LFGI-GAD 1/3 versus MALA.

The supplied wave solver, geometry, contrast map, truth distribution, and
noise are retained. Sampler settings match the completed Navier-Stokes repeats:
2000 particles/bank, three transport rounds, 200 Heun steps, and prior-initialized
32-chain MALA at the same portable-work convention. Density-surrogate and
MAP-Laplace experiments from the original Helmholtz script are not executed.
"""
import gc
import json
import os
import random
import sys
from collections import OrderedDict
from pathlib import Path

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.20")
os.environ.setdefault("MPLBACKEND", "Agg")
THIS_DIR = Path(__file__).resolve().parent
REPO_ROOT = THIS_DIR.parent
sys.path.insert(0, str(REPO_ROOT))

import jax
import jax.numpy as jnp
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from scipy.spatial.distance import cdist
from sampling import (
    GaussianPrior, compute_field_summary_metrics, compute_heldout_predictive_metrics,
    compute_latent_metrics, configure_sampling, get_valid_samples, init_run_results,
    make_physics_likelihood, make_posterior_score_fn, plot_mean_ess_logs,
    run_standard_sampler_pipeline, save_reproducibility_log, save_results_tables,
    summarize_sampler_run, zip_run_results_dir,
)
from plot_helmholtz import plot_contrast, plot_wavefields, plot_pca

jax.config.update("jax_enable_x64", True)
torch.set_default_dtype(torch.float64)

# === BEGIN PRESERVED HELMHOLTZ MODEL ===
os.makedirs('data', exist_ok=True)
N = 32
x = np.linspace(0.0, 1.0, N)
X, Y = np.meshgrid(x, x)
coords = np.column_stack([X.ravel(), Y.ravel()])

ell = 0.10
sigma_prior = 1.0
dists = cdist(coords, coords)
C = sigma_prior ** 2 * np.exp(-dists / ell)

eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]
q_max = 100
Basis_Modes = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])
np.savetxt('data/Helmholtz_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# Config
# ==========================================
num_truncated_series = 32
seed = int(os.environ.get("IP_RUN_SEED", "42"))
HELMHOLTZ_K = 24.0
HELMHOLTZ_DAMPING = 6.0
BACKGROUND_N2 = 1.0
SCATTERER_AMPLITUDE = 0.45
SCATTERER_RADIUS = 0.30
SCATTERER_SOFTNESS = 0.035
N_SOURCES = 4
N_RECEIVERS = 64
N_HOLDOUT_RECEIVERS = None
SOURCE_WIDTH = 0.055


def _ordered_boundary_indices(n):
    idx = []
    for j in range(n):
        idx.append(0 * n + j)
    for i in range(1, n):
        idx.append(i * n + (n - 1))
    for j in range(n - 2, -1, -1):
        idx.append((n - 1) * n + j)
    for i in range(n - 2, 0, -1):
        idx.append(i * n + 0)
    return np.array(idx, dtype=int)


boundary_indices_ordered = _ordered_boundary_indices(N)
n_boundary = len(boundary_indices_ordered)
receiver_spacing = n_boundary / N_RECEIVERS
receiver_boundary_pos = np.round(np.arange(N_RECEIVERS) * receiver_spacing).astype(int)
receiver_boundary_pos = np.clip(receiver_boundary_pos, 0, n_boundary - 1)
receiver_boundary_pos = np.unique(receiver_boundary_pos)
receiver_flat_indices = boundary_indices_ordered[receiver_boundary_pos]
remaining_boundary_pos = np.setdiff1d(np.arange(n_boundary), receiver_boundary_pos)
if N_HOLDOUT_RECEIVERS is None:
    N_HOLDOUT_RECEIVERS = remaining_boundary_pos.size
else:
    N_HOLDOUT_RECEIVERS = min(int(N_HOLDOUT_RECEIVERS), remaining_boundary_pos.size)
holdout_boundary_pos = remaining_boundary_pos[:N_HOLDOUT_RECEIVERS]
holdout_receiver_flat_indices = boundary_indices_ordered[holdout_boundary_pos]
rr = np.sqrt((X - 0.5) ** 2 + (Y - 0.5) ** 2)
support_mask = 1.0 / (1.0 + np.exp((rr - SCATTERER_RADIUS) / SCATTERER_SOFTNESS))
source_centers = np.array([[0.18, 0.22], [0.82, 0.26], [0.74, 0.82], [0.24, 0.76]], dtype=np.float64)

source_terms = []
for sx, sy in source_centers:
    direction = np.array([0.5 - sx, 0.5 - sy], dtype=np.float64)
    direction /= np.linalg.norm(direction) + 1e-12
    dist2 = (X - sx) ** 2 + (Y - sy) ** 2
    envelope = np.exp(-0.5 * dist2 / (SOURCE_WIDTH ** 2))
    phase = np.exp(1j * HELMHOLTZ_K * (direction[0] * (X - sx) + direction[1] * (Y - sy)))
    src = envelope * phase
    src = src / np.sqrt(np.sum(np.abs(src) ** 2) + 1e-12)
    source_terms.append(src.reshape(-1))
source_terms = np.stack(source_terms, axis=1)

num_observation = N_SOURCES * 2 * N_RECEIVERS
num_holdout_observation = N_SOURCES * 2 * N_HOLDOUT_RECEIVERS
dimension_of_PoI = N * N

df_modes = pd.read_csv('data/Helmholtz_Basis_Modes.csv', header=None)
modes_raw = df_modes.to_numpy().flatten().astype(np.float64)
num_modes_available = modes_raw.size // dimension_of_PoI
full_basis = modes_raw.reshape((dimension_of_PoI, num_modes_available))
basis_truncated = full_basis[:, :num_truncated_series]
pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(receiver_flat_indices).to_csv('data/obs_locations.csv', index=False, header=False)

# ==========================================
# Physics
# ==========================================
jax.config.update("jax_enable_x64", True)
Basis = jnp.array(basis_truncated)
support_mask_jax = jnp.array(support_mask, dtype=jnp.float64)
receiver_indices_jax = jnp.array(receiver_flat_indices, dtype=int)
holdout_receiver_indices_jax = jnp.array(holdout_receiver_flat_indices, dtype=int)
boundary_indices_jax = jnp.array(boundary_indices_ordered, dtype=int)
source_terms_jax = jnp.array(source_terms, dtype=jnp.complex128)

h = 1.0 / (N - 1)
n_total = N * N
_xface_left = (jnp.arange(N - 1)[:, None] * N + jnp.arange(N)[None, :]).ravel()
_xface_right = _xface_left + N
_yface_bot = (jnp.arange(N)[:, None] * N + jnp.arange(N - 1)[None, :]).ravel()
_yface_top = _yface_bot + 1


def _assemble_negative_laplacian():
    weight = 1.0 / (h * h)
    A = jnp.zeros((n_total, n_total), dtype=jnp.complex128)
    A = A.at[_xface_left, _xface_left].add(weight)
    A = A.at[_xface_right, _xface_right].add(weight)
    A = A.at[_xface_left, _xface_right].add(-weight)
    A = A.at[_xface_right, _xface_left].add(-weight)
    A = A.at[_yface_bot, _yface_bot].add(weight)
    A = A.at[_yface_top, _yface_top].add(weight)
    A = A.at[_yface_bot, _yface_top].add(-weight)
    A = A.at[_yface_top, _yface_bot].add(-weight)
    return A


NEG_LAPLACIAN = _assemble_negative_laplacian()
IDENTITY_WAVE = jnp.eye(n_total, dtype=jnp.complex128)


def _flatten_measurements_by_source(meas_complex):
    parts = []
    for s in range(N_SOURCES):
        parts.append(jnp.real(meas_complex[:, s]))
        parts.append(jnp.imag(meas_complex[:, s]))
    return jnp.concatenate(parts, axis=0)


def _flatten_measurements_by_source_generic(meas_complex, n_receivers):
    parts = []
    for s in range(N_SOURCES):
        parts.append(jnp.real(meas_complex[:n_receivers, s]))
        parts.append(jnp.imag(meas_complex[:n_receivers, s]))
    return jnp.concatenate(parts, axis=0)



def _alpha_to_raw_and_contrast(alpha):
    raw_field = jnp.reshape(Basis @ alpha, (N, N))
    contrast = SCATTERER_AMPLITUDE * jnp.tanh(raw_field) * support_mask_jax
    n2_field = BACKGROUND_N2 + contrast
    return raw_field, contrast, n2_field



def _assemble_helmholtz_operator(n2_field):
    diag = -(HELMHOLTZ_K ** 2) * n2_field.reshape(-1)
    return NEG_LAPLACIAN + jnp.diag(diag.astype(jnp.complex128)) + 1j * HELMHOLTZ_DAMPING * IDENTITY_WAVE


BACKGROUND_OPERATOR = _assemble_helmholtz_operator(jnp.ones((N, N), dtype=jnp.float64) * BACKGROUND_N2)
BACKGROUND_FIELDS = jnp.linalg.solve(BACKGROUND_OPERATOR, source_terms_jax)


@jax.jit
def solve_forward(alpha):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    U_total = jnp.linalg.solve(A, source_terms_jax)
    U_scat = U_total - BACKGROUND_FIELDS
    meas = U_scat[receiver_indices_jax, :]
    return _flatten_measurements_by_source(meas)


@jax.jit
def solve_forward_holdout(alpha):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    U_total = jnp.linalg.solve(A, source_terms_jax)
    U_scat = U_total - BACKGROUND_FIELDS
    meas = U_scat[holdout_receiver_indices_jax, :]
    return _flatten_measurements_by_source_generic(meas, holdout_receiver_indices_jax.shape[0])


batch_solve_forward_holdout = jax.jit(jax.vmap(solve_forward_holdout))


@jax.jit
def solve_single_pattern(alpha, pattern_idx):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    u_total = jnp.linalg.solve(A, source_terms_jax[:, pattern_idx])
    u_scat = u_total - BACKGROUND_FIELDS[:, pattern_idx]
    return u_scat.reshape(N, N)


@jax.jit
def solve_single_total_field(alpha, pattern_idx):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    u_total = jnp.linalg.solve(A, source_terms_jax[:, pattern_idx])
    return u_total.reshape(N, N)


# === END PRESERVED HELMHOLTZ MODEL ===

# === NS-ANALOGOUS SAMPLER SETTINGS ===
ACTIVE_DIM = num_truncated_series
NOISE_STD = 4e-4
HESS_MIN = 1e-6
HESS_MAX = 1e6
DEFAULT_N_GEN = 2000
N_REF = 2000


# ==========================================
# LFGI-GAD versus MALA benchmark configuration
# ==========================================
# GAD follows T_1 -> ... -> T_K using GN-LFGI at every round.  Round 2 remains
# in the execution DAG but is hidden.  MALA is an independent prior-initialized
# exact-score baseline.  Its default schedule is intentionally close to the
# cumulative round-3 GAD budget under the portable solve-counting proxy used by
# gad_sampling.py.

def _env_int(name, default):
    return int(os.environ.get(name, str(default)))


def _env_float(name, default):
    return float(os.environ.get(name, str(default)))


N_REF = _env_int('IP_ITER_N_REF', _env_int('IP_HELMHOLTZ_ITER_N_REF', N_REF))
DEFAULT_N_GEN = _env_int('IP_ITER_DEFAULT_N_GEN', _env_int('IP_HELMHOLTZ_ITER_DEFAULT_N_GEN', N_REF))
ITERATIVE_TRANSPORT_ROUNDS = _env_int('IP_ITER_ROUNDS', 3)
if ITERATIVE_TRANSPORT_ROUNDS != 3:
    raise ValueError('This exact paper comparison requires IP_ITER_ROUNDS=3.')
DISPLAY_TRANSPORT_ROUNDS = {1, 3}
TRANSPORT_STEPS = _env_int('IP_ITER_TRANSPORT_STEPS', 200)
HELDOUT_BATCH_SIZE = _env_int('IP_ITER_HELDOUT_BATCH_SIZE', 2)

MALA_N_CHAINS = max(1, _env_int('IP_MALA_N_CHAINS', 32))
MALA_THIN = max(1, _env_int('IP_MALA_THIN', 1))
MALA_EFFECTIVE_CHAINS = max(1, min(MALA_N_CHAINS, DEFAULT_N_GEN))
MALA_DRAWS_PER_CHAIN = int(np.ceil(DEFAULT_N_GEN / MALA_EFFECTIVE_CHAINS))
GAD3_EXPECTED_PDE_PROXY = 3 * 3 * N_REF
MALA_MATCHED_WARMUP = max(
    0,
    int(np.floor(
        GAD3_EXPECTED_PDE_PROXY / float(2 * MALA_EFFECTIVE_CHAINS)
        - 1
        - MALA_DRAWS_PER_CHAIN * MALA_THIN
    )),
)
MALA_WARMUP = max(0, _env_int('IP_MALA_WARMUP', MALA_MATCHED_WARMUP))
MALA_DT = _env_float('IP_MALA_DT', 1e-4)
MALA_TARGET_ACCEPT = _env_float('IP_MALA_TARGET_ACCEPT', 0.574)
MALA_MIN_DT = _env_float('IP_MALA_MIN_DT', 1e-12)
MALA_MAX_DT = _env_float('IP_MALA_MAX_DT', 1e-1)
MALA_PROGRESS_EVERY = _env_int('IP_MALA_PROGRESS_EVERY', 25)
MALA_ADAPT = os.environ.get('IP_MALA_ADAPT', '1').strip().lower() not in {'0', 'false', 'no', 'off'}

METHOD_SPECS = OrderedDict([
    ('LFGI-GAD', {
        'score': 'lfgi',
        'display': 'LFGI-GAD',
    }),
])


def make_gad_sampler_configs(method_specs, rounds=ITERATIVE_TRANSPORT_ROUNDS):
    """Build one transport-only chain per GAD method entry."""
    configs = OrderedDict()
    for method_key, spec in method_specs.items():
        score_method = spec['score']
        display_base = spec['display']
        previous_label = None
        for round_idx in range(1, int(rounds) + 1):
            transport_label = f'{method_key}-{round_idx}'
            transport_cfg = {
                'node': 'transport',
                'score': score_method,
                'steps': TRANSPORT_STEPS,
                'n_samples': DEFAULT_N_GEN,
                'n_ref': N_REF,
                'n_gate': N_REF,
                'bank_coupling': 'shared',
                'log_mean_ess': True,
                'include_results': round_idx in DISPLAY_TRANSPORT_ROUNDS,
                'display_name': f'{display_base} {round_idx}',
            }
            if previous_label is not None:
                transport_cfg['ref_source'] = previous_label
            configs[transport_label] = transport_cfg
            previous_label = transport_label

    return configs


SAMPLER_CONFIGS = make_gad_sampler_configs(METHOD_SPECS)
SAMPLER_CONFIGS['MALA'] = {
    'node': 'mala',
    'n_samples': DEFAULT_N_GEN,
    'mala_n_chains': MALA_N_CHAINS,
    'mala_warmup': MALA_WARMUP,
    'mala_thin': MALA_THIN,
    'mala_dt': MALA_DT,
    'mala_adapt': MALA_ADAPT,
    'mala_target_accept': MALA_TARGET_ACCEPT,
    'mala_min_dt': MALA_MIN_DT,
    'mala_max_dt': MALA_MAX_DT,
    'mala_progress_every': MALA_PROGRESS_EVERY,
    'include_results': True,
    'is_reference': True,
    'display_name': 'MALA',
}

MALA_TOTAL_TRANSITIONS = MALA_WARMUP + MALA_DRAWS_PER_CHAIN * MALA_THIN
MALA_EXPECTED_PDE_PROXY = 2 * MALA_EFFECTIVE_CHAINS * (MALA_TOTAL_TRANSITIONS + 1)
MALA_TO_GAD3_PROXY_RATIO = MALA_EXPECTED_PDE_PROXY / float(max(1, GAD3_EXPECTED_PDE_PROXY))


# === EXECUTION ===
gc.collect()
if torch.cuda.is_available():
    torch.cuda.empty_cache()
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(seed)

configure_sampling(active_dim=ACTIVE_DIM, default_n_gen=DEFAULT_N_GEN,
                   hess_min=HESS_MIN, hess_max=HESS_MAX, curvature_ridge=1e-6)
run_ctx = init_run_results('helmholtz_lfgi_gad1_gad3_mala')
run_dir = Path(run_ctx['run_results_dir'])

# Keep the original Helmholtz truth and noise distribution, including mode decay.
mode_decay = np.linspace(1.0, 0.45, ACTIVE_DIM)
alpha_true_np = 0.95 * np.random.randn(ACTIVE_DIM) * mode_decay
y_clean_np = np.asarray(solve_forward(jnp.asarray(alpha_true_np)))
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_clean_holdout_np = np.asarray(solve_forward_holdout(jnp.asarray(alpha_true_np)))
y_holdout_obs_np = y_clean_holdout_np + np.random.normal(0.0, NOISE_STD, size=y_clean_holdout_np.shape)

prior_model = GaussianPrior(dim=ACTIVE_DIM)
lik_model, lik_aux = make_physics_likelihood(
    solve_forward, y_obs_np, NOISE_STD, use_gauss_newton_hessian=True,
    log_batch_size=50, grad_batch_size=25, hess_batch_size=2)
posterior_score_fn = make_posterior_score_fn(lik_model)

run_config = dict(seed=seed, run_kind=os.environ.get('IP_RUN_KIND', 'paper'),
    N=N, ACTIVE_DIM=ACTIVE_DIM, N_REF=N_REF, DEFAULT_N_GEN=DEFAULT_N_GEN,
    ITERATIVE_TRANSPORT_ROUNDS=ITERATIVE_TRANSPORT_ROUNDS, TRANSPORT_STEPS=TRANSPORT_STEPS,
    DISPLAY_TRANSPORT_ROUNDS=sorted(DISPLAY_TRANSPORT_ROUNDS), SAMPLER_CONFIGS=SAMPLER_CONFIGS,
    MALA_N_CHAINS=MALA_N_CHAINS, MALA_EFFECTIVE_CHAINS=MALA_EFFECTIVE_CHAINS,
    MALA_DRAWS_PER_CHAIN=MALA_DRAWS_PER_CHAIN, MALA_WARMUP=MALA_WARMUP,
    MALA_THIN=MALA_THIN, MALA_DT=MALA_DT, MALA_TARGET_ACCEPT=MALA_TARGET_ACCEPT,
    MALA_ADAPT=MALA_ADAPT, MALA_MIN_DT=MALA_MIN_DT, MALA_MAX_DT=MALA_MAX_DT,
    MALA_EXPECTED_PDE_PROXY=MALA_EXPECTED_PDE_PROXY, GAD3_EXPECTED_PDE_PROXY=GAD3_EXPECTED_PDE_PROXY,
    MALA_TO_GAD3_PROXY_RATIO=MALA_TO_GAD3_PROXY_RATIO, HESS_MIN=HESS_MIN, HESS_MAX=HESS_MAX,
    CURVATURE_RIDGE=1e-6, T_MAX=10.0, T_MIN=10**(-2.5), HELDOUT_BATCH_SIZE=HELDOUT_BATCH_SIZE,
    HELMHOLTZ_K=HELMHOLTZ_K, HELMHOLTZ_DAMPING=HELMHOLTZ_DAMPING, BACKGROUND_N2=BACKGROUND_N2,
    SCATTERER_AMPLITUDE=SCATTERER_AMPLITUDE, SCATTERER_RADIUS=SCATTERER_RADIUS,
    SCATTERER_SOFTNESS=SCATTERER_SOFTNESS, SOURCE_WIDTH=SOURCE_WIDTH,
    N_SOURCES=N_SOURCES, N_RECEIVERS=int(len(receiver_flat_indices)),
    N_HOLDOUT_RECEIVERS=int(len(holdout_receiver_flat_indices)),
    num_observation=num_observation, num_holdout_observation=num_holdout_observation, NOISE_STD=NOISE_STD,
    prior_kernel='exp(-distance/0.10), variance 1',
    truth_distribution='0.95 * standard_normal(32) * linspace(1, 0.45, 32)',
    likelihood='Gaussian independent real/imaginary scattered-pressure components',
    metric_sample_rule='same as NS: finite samples inside coordinatewise Q25-5*IQR to Q75+5*IQR; retained counts reported',
    field_estimator='contrast evaluated at retained coefficient posterior mean',
    forward_error_reference='noise-free training measurements',
    state_metric='complex scattered wavefield at retained coefficient mean, all four sources',
    KLdiag_definition='legacy 5-nearest-neighbor entropy plus unnormalized negative log posterior; target log normalizer omitted',
    KSD_definition='multiscale RBF KSD, bandwidths 0.1/0.2/0.4/0.8, at most 1000 retained particles',
    pca_anchor='LFGI-GAD-3; shared basis/axes/color scales; no additional plotting-window clipping')
(run_dir / 'experiment_config.json').write_text(json.dumps(run_config, indent=2) + '\n')
print(json.dumps(run_config, indent=2), flush=True)

pipeline = run_standard_sampler_pipeline(prior_model, lik_model, SAMPLER_CONFIGS, n_ref=N_REF)
samples = pipeline['samples']
precomp = pipeline['precomp']
ess_logs = pipeline['ess_logs']
sampler_run_info = pipeline['sampler_run_info']
display_names = pipeline['display_names']
reference_key = pipeline['reference_key']
reference_title = pipeline['reference_title']
summarize_sampler_run(sampler_run_info)

# Save all rounds, including the hidden intermediate bank, before evaluation.
all_round_samples_np = {}
for label, state in precomp['states'].items():
    array = state.samples.detach().cpu().numpy()
    if array.shape != (DEFAULT_N_GEN, ACTIVE_DIM) or not np.isfinite(array).all():
        raise ValueError(f'{label}: malformed or nonfinite raw particle bank')
    all_round_samples_np[label] = array
np.savez_compressed(run_dir / 'samples_all_rounds.npz', **all_round_samples_np)

metrics = compute_latent_metrics(samples, reference_key, alpha_true_np,
    prior_model, lik_model, posterior_score_fn, display_names=display_names)
# Unlike the old scripts, a failed predictive evaluation cannot silently yield
# a completed paper run: the required finite metrics and counts are checked below.
metrics = compute_heldout_predictive_metrics(samples, metrics,
    heldout_forward_eval_fn=lambda a: np.asarray(solve_forward_holdout(jnp.asarray(a))),
    batched_forward_eval_fn=lambda a: np.asarray(batch_solve_forward_holdout(jnp.asarray(a, dtype=jnp.float64))),
    batched_forward_eval_batch_size=HELDOUT_BATCH_SIZE, y_holdout_obs_np=y_holdout_obs_np,
    noise_std=NOISE_STD, display_names=display_names, min_valid=10)

Basis_np = np.asarray(Basis)
support_mask_np = np.asarray(support_mask)


def reconstruct_contrast_field(latents):
    latents = np.asarray(latents)
    if latents.ndim == 1:
        latents = latents[None, :]
    raw = (latents @ Basis_np.T).reshape((-1, N, N))
    return SCATTERER_AMPLITUDE * np.tanh(raw) * support_mask_np[None, :, :]


@jax.jit
def solve_scattered_fields(alpha):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    operator = _assemble_helmholtz_operator(n2_field)
    return (jnp.linalg.solve(operator, source_terms_jax) - BACKGROUND_FIELDS).reshape(N, N, N_SOURCES)


true_field = reconstruct_contrast_field(alpha_true_np)[0]
true_complex_wavefields = np.asarray(solve_scattered_fields(jnp.asarray(alpha_true_np)))
mean_fields, metrics = compute_field_summary_metrics(samples, metrics, alpha_true_np, true_field,
    field_from_latent_fn=lambda a: reconstruct_contrast_field(a)[0],
    forward_eval_fn=lambda a: np.asarray(solve_forward(jnp.asarray(a))),
    y_ref_np=y_clean_np, display_names=display_names, d_lat=ACTIVE_DIM)

clean_samples, mean_wavefields, std_fields, summary_arrays = {}, {}, {}, {}
required = ['RMSE_alpha', 'RMSE_field', 'FwdRelErr', 'HeldoutPredNLL', 'KLdiag', 'KSD', 'HeldoutStdResRMS']
for label, raw in samples.items():
    clean = get_valid_samples(raw)
    clean_samples[label] = clean
    counts = dict(RawSampleCount=int(raw.shape[0]), MetricSampleCount=int(clean.shape[0]),
                  KLdiagSampleCount=int(len(get_valid_samples(torch.as_tensor(clean)))),
                  MetricRetentionFraction=float(clean.shape[0]/raw.shape[0]))
    metrics.setdefault(label, {}).update(counts)
    if len(clean) < 50:
        raise ValueError(f'{label}: fewer than 50 retained evaluation particles')
    if int(metrics[label].get('HeldoutPredNumValid', 0)) != len(clean):
        raise ValueError(f'{label}: held-out predictions missing for some retained evaluation particles')
    mean_latent = np.asarray(metrics[label]['mean_latent'])
    wave = np.asarray(solve_scattered_fields(jnp.asarray(mean_latent)))
    mean_wavefields[label] = wave
    if not np.isfinite(wave).all():
        raise ValueError(f'{label}: nonfinite reconstructed wavefield')
    wave_difference = wave - true_complex_wavefields
    metrics[label]['RMSE_wavefield'] = float(np.sqrt(np.mean(np.abs(wave_difference)**2)))
    metrics[label]['RelL2_wavefield'] = float(np.linalg.norm(wave_difference.ravel())/(np.linalg.norm(true_complex_wavefields.ravel())+1e-12))
    std_fields[label] = np.std(reconstruct_contrast_field(clean), axis=0, ddof=1)
    summary_arrays[label+'_contrast_at_mean'] = mean_fields[label]
    summary_arrays[label+'_contrast_sd'] = std_fields[label]
    summary_arrays[label+'_scattered_wavefields_at_mean'] = wave
    summary_arrays[label+'_predictive_mean'] = np.asarray(metrics[label]['HeldoutPredMean'])
    summary_arrays[label+'_predictive_variance'] = np.asarray(metrics[label]['HeldoutPredVar'])
    for key in required + ['RMSE_wavefield']:
        if not np.isfinite(float(metrics[label].get(key, np.nan))):
            raise ValueError(f'{label}: required metric {key} is missing/nonfinite')
np.savez_compressed(run_dir / 'field_summaries.npz', true_field=true_field,
                    true_complex_wavefields=true_complex_wavefields, **summary_arrays)
(run_dir / 'evaluation_diagnostics.json').write_text(json.dumps({label: {
    key: metrics[label].get(key) for key in ['RawSampleCount','MetricSampleCount','KLdiagSampleCount',
    'MetricRetentionFraction','HeldoutPredNumValid','HeldoutPredCovMode','HeldoutPredWarning']}
    for label in samples}, indent=2) + '\n')

results_df, results_runinfo_df, results_df_path, results_runinfo_df_path = save_results_tables(
    metrics, sampler_run_info, n_ref=N_REF, target_name='Helmholtz inverse scattering',
    display_names=display_names, reference_name=reference_title)
save_reproducibility_log(title='Helmholtz LFGI-GAD 1/3 versus MALA', config=run_config,
    extra_sections={'metric_sample_counts': {label: {k: metrics[label][k] for k in
        ['RawSampleCount','MetricSampleCount','MetricRetentionFraction']} for label in samples},
        'results': {'metrics_csv': results_df_path, 'runinfo_csv': results_runinfo_df_path}})

plot_mean_ess_logs(ess_logs, display_names=display_names)
plt.close('all')
plot_metadata = {}
plot_metadata['contrast'] = plot_contrast(run_dir, true_field, mean_fields, std_fields, display_names)
plot_metadata['wavefields'] = plot_wavefields(run_dir, true_complex_wavefields, mean_wavefields, display_names)
plot_metadata['pca'] = plot_pca(run_dir, clean_samples, alpha_true_np, display_names)
(run_dir / 'plot_metadata.json').write_text(json.dumps(plot_metadata, indent=2) + '\n')

# Keep a single convenient dashboard like the NS runs. Individual PDFs remain
# vector figures; the dashboard combines their already-rendered PNG previews.
from matplotlib.backends.backend_pdf import PdfPages
dashboard_path = run_dir / 'summary_dashboard.pdf'
with PdfPages(dashboard_path) as dashboard:
    for name in ['helmholtz_contrast.png','helmholtz_wavefields.png','helmholtz_pca.png']:
        fig, ax = plt.subplots(figsize=(8.3, 7.5))
        ax.imshow(plt.imread(run_dir/name)); ax.axis('off')
        dashboard.savefig(fig, bbox_inches='tight'); plt.close(fig)
run_results_zip_path = zip_run_results_dir(extra_paths=[str(dashboard_path)])
print(f'Completed seed {seed}; output {run_dir}; archive {run_results_zip_path}', flush=True)
