#!/usr/bin/env python3
"""Execute one isolated inverse problem with the shared paper sampler."""
import argparse
import csv
import hashlib
import importlib.util
import json
import os
import platform
import random
import subprocess
import sys
import time
import traceback
from dataclasses import asdict
from pathlib import Path

from protocol import PROBLEMS, Settings, add_settings_arguments, make_protocol, settings_from_arguments

ROOT = Path(__file__).resolve().parent


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_model(problem, seed):
    os.environ['GAD_SCREEN_SEED'] = str(seed)
    spec = importlib.util.spec_from_file_location('screen_model', ROOT / 'models' / f'{problem}.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def check_model(model):
    """Check finite forward maps and an independent directional derivative."""
    import jax
    import jax.numpy as jnp
    import numpy as np
    a = jnp.asarray(model.alpha_true_np, dtype=jnp.float64)
    direction = np.random.default_rng(514).normal(size=a.size)
    direction /= np.linalg.norm(direction)
    direction = jnp.asarray(direction)
    def energy(x):
        residual = model.solve_forward(x) - jnp.asarray(model.y_obs_np)
        return -.5 * jnp.sum(residual ** 2) / model.NOISE_STD ** 2 - .5 * jnp.sum(x ** 2)
    value, grad = jax.value_and_grad(energy)(a)
    jacobian = jax.jacfwd(model.solve_forward)(a)
    curvature = jnp.eye(a.size) + jacobian.T @ jacobian / model.NOISE_STD ** 2
    eps = 1e-5
    fd = float((energy(a + eps * direction) - energy(a - eps * direction)) / (2 * eps))
    ad = float(grad @ direction)
    relative = abs(fd - ad) / max(1.0, abs(ad), abs(fd))
    finite = all(np.isfinite(np.asarray(x)).all() for x in (value, grad, jacobian, curvature))
    if not finite or relative > 5e-3:
        raise RuntimeError(f'Model derivative check failed: finite={finite}, relative error={relative}')
    return dict(log_posterior=float(value), score_norm=float(jnp.linalg.norm(grad)),
                directional_fd=fd, directional_autodiff=ad, directional_relative_error=relative,
                min_GN_posterior_eigenvalue=float(np.linalg.eigvalsh(np.asarray(curvature))[0]))


def execute(problem, seed, settings, output, *, check_only=False, allow_cpu=False, no_plots=False):
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    if (output / 'status.json').exists():
        raise FileExistsError(f'{output} already has a status; use a new task or --attempt N')
    previous_dir = Path.cwd()
    os.chdir(output)
    # Set these before importing either array framework.
    os.environ.setdefault('MPLBACKEND', 'Agg')
    os.environ.setdefault('JAX_ENABLE_X64', 'true')
    os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE', 'false')
    os.environ.setdefault('XLA_PYTHON_CLIENT_MEM_FRACTION', '0.20')
    if not allow_cpu:
        os.environ.setdefault('JAX_PLATFORMS', 'cuda')
    from evaluate import evaluate, make_figures, write_json
    started = time.time()
    status = dict(problem=problem, seed=seed, state='running', mode='check' if check_only else 'screen', started_unix=started)
    write_json(output / 'status.json', status)
    try:
        import numpy as np
        import jax
        import torch
        import sampling
        if not allow_cpu and (not torch.cuda.is_available() or not any(d.platform == 'gpu' for d in jax.devices())):
            raise RuntimeError('This job requires CUDA in both PyTorch and JAX. Check the hlsi environment or use --allow-cpu explicitly.')
        torch.set_default_dtype(torch.float64)
        random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
        model = load_model(problem, seed)
        if model.ACTIVE_DIM != np.asarray(model.alpha_true_np).size:
            raise ValueError('Truth and latent dimension disagree')
        if not (float(model.NOISE_STD) > 0 and np.isfinite(float(model.NOISE_STD))):
            raise ValueError('Invalid noise standard deviation')
        for key in ('alpha_true_np', 'y_obs_np', 'y_clean_np', 'y_holdout_obs_np'):
            if not np.isfinite(np.asarray(getattr(model, key))).all():
                raise ValueError(f'Non-finite synthetic-data array: {key}')
        if np.asarray(model.solve_forward(model.alpha_true_np)).shape != np.asarray(model.y_obs_np).shape:
            raise ValueError('Training forward map and observations disagree')
        realized_dim = int(model.ACTIVE_DIM)
        configs, budget = make_protocol(settings)
        config = dict(problem=problem, seed=seed, settings=asdict(settings), protocol=configs,
                      budget=budget, latent_dim=realized_dim,
                      noise_std=float(model.NOISE_STD), n_observations=int(np.size(model.y_obs_np)),
                      n_holdout=int(np.size(model.y_holdout_obs_np)),
                      field_definition=next(x['field'] for x in json.loads((ROOT/'provenance/catalog.json').read_text()) if x['key']==problem),
                      sampling_sha256=sha256(ROOT/'sampling.py'), model_sha256=sha256(ROOT/'models'/f'{problem}.py'),
                      python=sys.version, platform=platform.platform(), hostname=platform.node(),
                      numpy=np.__version__, jax=jax.__version__, torch=torch.__version__,
                      jax_devices=[str(x) for x in jax.devices()], torch_device=str(sampling.device),
                      slurm_job_id=os.environ.get('SLURM_JOB_ID'), slurm_array_task_id=os.environ.get('SLURM_ARRAY_TASK_ID'),
                      metric_population='all finite particles; no IQR deletion; raw samples retained',
                      metric_subset='shared random index subset, capped at eval_particles; KSD further capped at 1000 by the original helper',
                      warning='One realization per problem. Field RMSE measures truth reconstruction; it is not a posterior-distance certificate.')
        write_json(output / 'experiment_config.json', config)
        np.savez_compressed(output / 'realization.npz', alpha_true=model.alpha_true_np,
                            y_obs=model.y_obs_np, y_clean=model.y_clean_np,
                            y_holdout_obs=model.y_holdout_obs_np, basis=np.asarray(model.Basis))
        with (output / 'pip_freeze.txt').open('w') as f:
            subprocess.run([sys.executable, '-m', 'pip', 'freeze'], stdout=f, stderr=subprocess.STDOUT, check=False)
        if check_only:
            result = check_model(model)
            write_json(output / 'model_check.json', result)
            status.update(state='complete', duration_seconds=time.time()-started)
            write_json(output / 'status.json', status)
            return status
        sampling.configure_sampling(active_dim=realized_dim, default_n_gen=settings.particles,
                                    hess_min=settings.hess_min, hess_max=settings.hess_max,
                                    curvature_ridge=settings.curvature_ridge)
        model.prior_model = sampling.GaussianPrior(dim=realized_dim)
        model.lik_model, _ = sampling.make_physics_likelihood(
            model.solve_forward, model.y_obs_np, model.NOISE_STD, use_gauss_newton_hessian=True,
            log_batch_size=settings.log_batch, grad_batch_size=settings.grad_batch,
            hess_batch_size=settings.hess_batch)
        # Model RNG consumption varies. Assign a separate sampler stream consistently.
        random.seed(seed + 10000); np.random.seed(seed + 10000); torch.manual_seed(seed + 10000)
        if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed + 10000)
        print(json.dumps({'problem':problem, 'seed':seed, 'budget':budget}), flush=True)
        result = sampling.run_standard_sampler_pipeline(model.prior_model, model.lik_model, configs, n_ref=settings.bank)
        sampling.summarize_sampler_run(result['sampler_run_info'])
        raw_samples = {k: v.detach().cpu().numpy() if isinstance(v, torch.Tensor) else np.asarray(v)
                       for k, v in result['samples'].items()}
        for label, array in raw_samples.items():
            if array.shape != (settings.particles, realized_dim):
                raise ValueError(f'{label} returned {array.shape}; expected {(settings.particles,realized_dim)}')
        np.savez_compressed(output / 'samples_all_rounds.npz', **raw_samples)
        write_json(output / 'run_info.json', result['sampler_run_info'])
        write_json(output / 'ess_logs.json', result['ess_logs'])
        rows, fields, clean = evaluate(model, raw_samples, settings, seed, output, problem)
        for label, row in rows.items():
            info = result['sampler_run_info'][label]
            for key in ('runtime_seconds', 'local_runtime_seconds', 'pde_solve_count',
                        'local_pde_solve_count', 'pde_likelihood_evals', 'pde_score_evals',
                        'pde_gn_hessian_evals', 'mala_acceptance_rate', 'mala_rhat_median',
                        'mala_rhat_max', 'mala_dt_final', 'mala_unique_fraction'):
                if key in info: row[key] = info[key]
        write_json(output / 'metrics.json', rows)
        columns = ['method'] + sorted({k for row in rows.values() for k in row})
        with (output / 'metrics.csv').open('w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=columns); writer.writeheader()
            writer.writerows(dict(method=k, **v) for k,v in rows.items())
        warnings = []
        for label, row in rows.items():
            if row.get('finite_fraction', 0) < 1: warnings.append(f'{label}: non-finite particles')
            if row.get('heldout_error'): warnings.append(f'{label}: held-out evaluation failed')
            if row.get('heldout_predictive_finite_fraction', 0) < 1: warnings.append(f'{label}: non-finite held-out predictions')
            if row.get('heldout_covariance_mode') == 'diag_fallback': warnings.append(f'{label}: held-out diagonal covariance fallback')
        mala = rows.get('MALA', {})
        rhat = mala.get('mala_rhat_max', float('nan'))
        if not np.isfinite(rhat) or rhat > 1.1: warnings.append('MALA split-R-hat does not establish mixing; inspect baseline diagnostics')
        if not no_plots:
            try:
                make_figures(model, rows, fields, clean, result['sampler_run_info'], output)
            except Exception as exc:
                warnings.append(f'Plotting failed, numerical results retained: {exc}')
                (output/'plot_error.txt').write_text(traceback.format_exc())
        usable = all(k in rows and rows[k].get('finite_fraction') == 1 and
                     rows[k].get('heldout_predictive_finite_fraction') == 1 and
                     all(np.isfinite(rows[k].get(m, float('nan'))) for m in ('RMSE_field','KSD','HeldoutPredNLL'))
                     for k in configs)
        status.update(state='complete' if usable else 'incomplete_metrics', warnings=warnings,
                      duration_seconds=time.time()-started)
        write_json(output / 'status.json', status)
        return status
    except BaseException as exc:
        status.update(state='failed', error=f'{type(exc).__name__}: {exc}', duration_seconds=time.time()-started)
        write_json(output / 'status.json', status)
        (output / 'traceback.txt').write_text(traceback.format_exc())
        raise
    finally:
        os.chdir(previous_dir)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--problem', required=True, choices=PROBLEMS)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--check-model', action='store_true', help='forward/gradient/GN check only; not a screening result')
    p.add_argument('--allow-cpu', action='store_true')
    p.add_argument('--no-plots', action='store_true')
    add_settings_arguments(p)
    args = p.parse_args()
    status = execute(args.problem,args.seed,settings_from_arguments(args),args.output,
                     check_only=args.check_model,allow_cpu=args.allow_cpu,no_plots=args.no_plots)
    return 0 if status['state']=='complete' else 2


if __name__ == '__main__':
    sys.exit(main())
