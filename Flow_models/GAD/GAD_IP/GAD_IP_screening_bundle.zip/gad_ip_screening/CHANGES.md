# Adaptation audit

## Preserved

- The complete historical uploads and anchor sources are under `provenance/originals/`, with their SHA-256 identifiers and extracted source ranges in `provenance/catalog.json`.
- All extracted original function bodies are unchanged at the Python AST level; the included tests check this. The new modules add only common field/state entry points and seed configuration.
- The sampler has identical bytes in the completed Darcy/NS and Helmholtz repeat handoffs. This bundle copies that module unchanged. SHA-256: `4ea89776bf70304024836b8fde37b6f13145662b6a81989e32518b3c14048955`.
- Model grids, physical parameters, truncation dimensions, sensor lists/layout rules, truth-generation functions, noise formulas, and forward discretizations are retained. EIT uses the code's actual **32** latent modes; the old dashboard prose claimed 40.
- The old LaTeX suite is included for context, without treating its historical settings/results as current measurements.

## Replaced to match the current paper

- Obsolete `init`, `init_weights`, `CE-HLSI`, `DRC`, surrogate-weight, PoU, and estimator-grid configurations are removed from execution. Every model runs the same current `node='transport', score='lfgi'` chain and exact-score MALA baseline.
- Allen–Cahn's old sampler monkey patch and non-finite-particle repair fallback are not installed. Non-finite output is recorded as a problem, with raw samples retained.
- All GAD rounds are public results; there are no hidden round-two outputs or ratio nodes.
- Default reference and output counts are standardized to 1,000 rather than the historical mixture of 500–10,000 references and 500–5,000 outputs. NS/Helmholtz repeat defaults were 2,000. These are screening settings and are recorded explicitly.
- Numerical curvature controls are standardized to the current positive precision interval `[1e-6,1e6]`. This replaces, among other old settings, AFWI's invalid negative lower precision bound and EIT's older `[5e-5,5e6]` limits.
- Small likelihood/score/curvature batch sizes replace old memory-heavy defaults without changing the model equations.
- Seed 42 is assigned explicitly to NumPy, PyTorch, and source model seed controls. Sampling uses a separate reproducible stream, so differences in model data-generation code do not implicitly select sampler RNG streams.

## Repairs and metric consistency

- The modulus upload includes a complete runner followed by a malformed, duplicated script joined to a print statement. Only the first complete model is adapted; the original upload is retained verbatim for audit. This preserves the first model's beta 6, three damped Picard iterations, and two training loads.
- Notebook `/content` path assumptions, module-reloading/debug cells, and stale `sampling` imports are removed. The copied sampler is resolved from the frozen source directory.
- Heat's declaration of 30 observations is corrected to the actual ten sensor indices. The list and forward map are unchanged.
- Reconstructed truth fields are generated from `alpha_true_np`, matching the data-generating latent model. Older scripts sometimes compared a projected reconstruction with an unprojected hand-built target, adding truncation error to the comparison.
- Every task runs in a different directory, so basis/observation CSV writes cannot collide.
- Field means use all finite particles rather than deleting finite IQR tails. The old cleaning count is retained as an audit metric, and the saved raw arrays permit alternative analysis later.
- The full predictive covariance is used for NLL, with the existing stabilization convention and an explicit fallback label. Mean-field errors, exact-score KSD, predictive calibration, and MALA disagreement are reported separately.
- Portable work and elapsed runtime are both saved; neither is used as a surrogate for the other. Round-three work/runtime are cumulative.
- Missing or failed experiments remain visible. Job IDs are saved before dependent submission; aggregation can be attached without resubmitting the experiments.
