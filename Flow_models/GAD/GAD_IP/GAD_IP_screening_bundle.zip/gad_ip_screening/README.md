# GAD inverse-problem screening sweep

Run each candidate once, then compare **GAD versus MALA** and **GAD round 3 versus round 1**. The bundle is self-contained and includes the same `sampling.py` used by the completed Darcy/NS and Helmholtz repeat batches; no imports from your surrounding GAD repository are required.

## Start on Vista

Upload `GAD_IP_screening_bundle.zip` into:

```text
/work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP
```

Run from that directory:

```bash
unzip GAD_IP_screening_bundle.zip
bash gad_ip_screening/submit_sweep.sh
squeue -u "$USER"
```

This submits **10 tasks, one per problem, seed 42**, with at most two tasks running concurrently, plus a dependent aggregation job. It uses the existing `gh` partition, GCC 13.2.0, Python 3.11.8, and `$SCRATCH/venvs/hlsi`. The default limit is two hours **per task**. Each task has a separate working directory, including its own `data/` files. No existing experiments or runner files are overwritten. The submission prints the absolute batch path and both job IDs.

The default is a screening experiment, with common particle counts rather than the larger and inconsistent counts in the historical runners. In particular, the NS and Helmholtz anchors use 1,000 particles here, compared with 2,000 in their previous repeats. Use `--particles 2000` to use 2,000 for every problem instead.

## Included problems

Training and held-out counts below are scalar measurement dimensions, not necessarily counts of spatial locations.

| Key | Model | Latent dimension | Grid | Training / held out | Role |
|---|---|---:|---:|---:|---|
| `advect_diff` | Periodic advection–diffusion initial condition | 32 | 32 × 32 | 25 / 25 | Linear Gaussian control |
| `allen_cahn` | Allen–Cahn initial condition | 32 | 32 × 32 | 40 / 40 | Candidate |
| `poisson` | Positive reaction coefficient in Poisson equation | 32 | 32 × 32 | 140 / 20 | Candidate |
| `darcy` | Log permeability | 32 | 32 × 32 | 120 / 30 | Existing-paper anchor |
| `eit_harder` | Anisotropic-prior EIT with clustered boundary sensors | 32 | 32 × 32 | 480 / 1,008 | Candidate |
| `helmholtz` | Nonlinear inverse scattering | 32 | 32 × 32 | 512 / 480 | Recent-repeat anchor |
| `afwi` | Acoustic full-waveform velocity inversion | 32 | 48 × 48 | 22,080 / 64 | Candidate |
| `navier_stokes` | Initial vorticity, moderately hardened current configuration | 36 | 32 × 32 | 80 / 40 | Existing-paper anchor |
| `heat` | Conductivity, mixed boundary conditions | 24 | 16 × 16 | 10 / 10 | Candidate |
| `modulus` | Nonlinear membrane shear modulus | 32 | 32 × 32 | 192 / 48 | Candidate |

Seven models come from the supplied scripts. Darcy/NS come from the source snapshots in the completed repeat handoff; Helmholtz comes from the subsequent repeat handoff. The old LaTeX suite is retained as a reference under `provenance/`; the adapted code and realized run configuration are authoritative.

## Shared scientific protocol

| Setting | Default |
|---|---|
| Reference bank / generated particles | 1,000 / 1,000 |
| Algorithm | Transport-only, `score='lfgi'`, shared signal/gate bank |
| GAD rounds | 3, with every round saved and evaluated |
| Steps per round | 200 stochastic reverse-OU Heun steps |
| OU time interval | `[10**(-2.5), 10]`, as in the recovered current sampler |
| Curvature precision limits | `[1e-6, 1e6]`; ridge `1e-6` |
| MALA | 32 parallel prior-initialized chains; scalar identity preconditioning |
| MALA adaptation | Warmup only, target acceptance 0.574; frozen during collection |
| MALA initial step | `1e-4`; permitted interval `[1e-12, 1e-1]` |
| MALA budget | Matched to cumulative final-round GAD under the existing derivative-count proxy |
| Default MALA warmup / draws | 107 transitions / 32 retained draws per chain; pooled output truncated to 1,000 |
| Default expected work | GAD: 9,000; MALA: 8,960 proxy evaluations |
| Numerical batching | Likelihood 8, score 4, curvature 1; held-out forward batch 2 |

The proxy counts three evaluations per GN-bank particle and two per MALA chain transition plus initialization. It does not count floating-point cost, the number of PDE right-hand sides, or evaluation/plotting overhead. Runtime is also recorded; the GAD runtime and work for a later round include preceding rounds. Matching this proxy is not a claim of equal elapsed compute.

Forward equations, discretizations, KL bases, physical parameters, sensor layouts, truth-generation rules, and observation noise follow the preserved source code. Legacy one-pass estimator grids, density-ratio corrections, sampler monkey patches, and repair/resampling fallbacks are replaced by the shared current transport-only protocol. A round takes its bank from the previous GAD round and regenerates a new cloud; it does not continue a physical-time PDE trajectory.

## What comes back

The printed batch path contains:

```text
batch_manifest.json
array_job_id.txt
aggregate_job_id.txt
source/                           frozen complete source snapshot
logs/
runs/<problem>/seed_42/attempt_000/
    experiment_config.json        realized settings, dimensions, devices, hashes
    realization.npz               latent truth, observations, basis
    samples_all_rounds.npz         GAD-1, GAD-2, GAD-3, MALA, without filtering
    run_info.json                 cumulative/local work, timings, MALA diagnostics
    metrics.csv
    metrics.json
    field_summaries.npz
    field_reconstruction.png
    state_reconstruction.png      PDE state, potential, shot gather, etc.
    posterior_pca.png              common PCA basis, window, bins, and color scale
    heldout_predictions.png
    round_metrics.png
    status.json
comparison/
    completion_status.csv
    all_metrics.csv
    selection_summary.csv
    selection_axes.png
    comparison.md
screening_results.zip
```

**Return `screening_results.zip` for the comparison and choice of paper examples.** It contains all diagnostics, plots, raw samples, configurations, source snapshots, and available failure logs. Aggregation runs after the array finishes even if some tasks fail. It packages partial results, explicitly identifies missing/failed tasks, and exits nonzero for an incomplete sweep.

## Reading the comparison

`selection_summary.csv` reports the two requested axes separately:

- `RMSE_field_gain_vs_MALA_pct`: percentage reduction in final-round field RMSE relative to MALA.
- `RMSE_field_gain_from_round1_pct`: percentage reduction from GAD round 1 to the final round.
- Corresponding KSD and latent/forward-error gains, plus absolute predictive-NLL improvements.
- Cumulative runtime/work ratios, MALA acceptance and split-R-hat, and validity warnings.

Positive values mean improvement. The summary figure places iteration gain on the horizontal axis and gain over MALA on the vertical axis; the upper-right quadrant is promising on both criteria. It shows separate field-RMSE and KSD panels. A field-RMSE Pareto flag is included, with no arbitrary combined score. The linear Gaussian control is excluded from the nonlinear Pareto shortlist.

One seed cannot establish uncertainty or posterior non-Gaussianity by itself. Field RMSE measures reconstruction of the known truth; corroborate it with exact-score KSD and held-out calibration. An apparent win over poorly mixed MALA needs further investigation. MALA is not used as ground-truth posterior samples; MMD to MALA is explicitly a disagreement diagnostic. The Gaussian control additionally saves its analytic posterior mean/covariance and oracle moment errors.

All finite particles contribute to field means. Predictive metrics and KSD use a shared random subset with the same indices across methods, capped at 1,000 by default. Raw particles are saved, non-finite outputs are flagged, and finite tail particles are never silently removed. A separate count shows how many particles the older IQR-cleaning helper would have retained. The KSD helper returns the squared multiscale V-statistic, including its finite-sample diagonal contribution. `KLdiag` is an entropy-based diagnostic with an unknown additive normalizer; it is not a normalized KL estimate. Neither predictive NLL nor `KLdiag` is converted into a percentage.

For nonlinear field maps, `RMSE_field` follows the existing field-at-mean-latent convention; `PosteriorMeanRMSE_field` separately evaluates the Monte Carlo posterior mean of the physical field. The truth field is always computed from the latent coefficients that actually generated the observations.

## Options and recovery

Run just the seven supplied problems:

```bash
bash gad_ip_screening/submit_sweep.sh \
  --problems advect_diff,afwi,allen_cahn,eit_harder,heat,modulus,poisson
```

Use the previous NS particle count across the whole sweep, or allow more walltime:

```bash
bash gad_ip_screening/submit_sweep.sh --particles 2000 --time 04:00:00
```

Useful options: `--seed 43`, `--rounds 5`, `--steps 200`, `--concurrency 1`, `--mala-budget-multiplier 5`, `--heldout-batch 1`. The multiplier expands the MALA budget; the resulting comparison records the changed work ratio. Each submission creates a new source snapshot and isolated batch.

Use the existing environment at a different location:

```bash
export IP_VENV_DIR=/path/to/your/hlsi
bash gad_ip_screening/submit_sweep.sh
```

Inspect or aggregate a known batch; substitute the printed path:

```bash
SCREEN_BATCH=/absolute/path/to/batches/ip_screening_...
python3 "$SCREEN_BATCH/source/manage.py" status --batch "$SCREEN_BATCH"
source "$SCREEN_BATCH/source/environment.sh"
python "$SCREEN_BATCH/source/manage.py" aggregate --batch "$SCREEN_BATCH"
```

If aggregation submission fails, the array job ID is already saved and a recovery command is printed. Submit only the dependent aggregation:

```bash
python3 "$SCREEN_BATCH/source/manage.py" submit-aggregate \
  --batch "$SCREEN_BATCH" --array-job "$(cat "$SCREEN_BATCH/array_job_id.txt")"
```

Retry a failed problem, using its original zero-based task index in `batch_manifest.json`:

```bash
sbatch --array=6 --time=04:00:00 \
  --export=ALL,SCREEN_BATCH_DIR="$SCREEN_BATCH" \
  --output="$SCREEN_BATCH/logs/retry-%A_%a.out" \
  "$SCREEN_BATCH/source/run_problem.slurm"
```

Retries create `attempt_001`, etc. They preserve earlier outputs. Aggregation uses the newest attempt for each task, so a failed newer attempt is visible rather than silently replaced by an older success. Re-run aggregation after retries finish. Slurm timeouts leave the last status as `running_or_interrupted`; inspect the corresponding Slurm log.

Optional model/autodiff checks on Vista, without running the sampling sweep:

```bash
bash gad_ip_screening/submit_sweep.sh --check-models
```

These evaluate the forward map, exact posterior gradient, GN curvature, and a directional finite-difference check at the truth. They are a separate batch and are never ranked as scientific screening results. For a single problem inside an interactive compute allocation:

```bash
source gad_ip_screening/environment.sh
python gad_ip_screening/run_problem.py --problem poisson --seed 42 \
  --output /absolute/new/output_directory --check-model
```

## Validation and source audit

See `VALIDATION.md` and `CHANGES.md`. Run the included checks with:

```bash
cd gad_ip_screening
python3 -m unittest discover -s tests -v
```

The tests cover recursive protocol structure, acceptance by the actual sampler's config normalizer, forward-function preservation, unresolved globals, matched-work accounting, Slurm ID parsing/recovery, failed-batch packaging, and comparison-metric arithmetic. Full CUDA sampling and Vista runtime have not been executed in the preparation workspace.
