"""Run with: python3 -m unittest discover -s tests -v"""
import argparse
import ast
import builtins
import contextlib
import hashlib
import io
import json
import math
import os
from pathlib import Path
import subprocess
import symtable
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from protocol import PROBLEMS,Settings,make_protocol
import manage
import aggregate


class ProtocolTests(unittest.TestCase):
    def test_iteration_is_transport_only_and_exports_every_round(self):
        configs,budget=make_protocol(Settings())
        self.assertEqual(list(configs),['GAD-1','GAD-2','GAD-3','MALA'])
        self.assertNotIn('ref_source',configs['GAD-1'])
        for r in (1,2,3):
            cfg=configs[f'GAD-{r}']
            self.assertEqual((cfg['node'],cfg['score'],cfg['steps']),('transport','lfgi',200))
            self.assertTrue(cfg['include_results'])
            self.assertEqual(cfg['n_ref'],1000)
            if r>1:self.assertEqual(cfg['ref_source'],f'GAD-{r-1}')
        self.assertLess(abs(budget['mala_to_gad_proxy_ratio']-1),.01)
        self.assertEqual(configs['MALA']['mala_warmup'],107)

    def test_protocol_matches_current_sampler_schema(self):
        # Exercise the actual copied sampler's normalizer without importing CUDA packages.
        tree=ast.parse((ROOT/'sampling.py').read_text())
        names={'normalize_sampler_config','canonicalize_score_method','canonicalize_ratio_mode',
               'canonicalize_bank_coupling','canonicalize_divergence_mode','_canonical_token',
               '_canonical_ref_source','_coerce_bool'}
        nodes=[]
        for node in tree.body:
            if isinstance(node,ast.FunctionDef) and node.name in names:nodes.append(node)
            if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id in
              {'_CONFIG_KEYS','SCORE_METHODS','RATIO_MODES','BANK_COUPLINGS','DIVERGENCE_MODES'} for x in node.targets):nodes.append(node)
        import numpy as np
        env={'ACTIVE_DIM':32,'DEFAULT_N_GEN':1000,'math':math,'np':np}
        exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_sampler_schema','exec'),env)
        configs,_=make_protocol(Settings())
        for label,cfg in configs.items():
            normalized=env['normalize_sampler_config'](label,cfg)
            self.assertEqual(normalized['n_samples'],1000)

    def test_invalid_bank_fails_before_submission(self):
        with self.assertRaises(ValueError):make_protocol(Settings(particles=1000,bank=2000))

    def test_job_ids_ignore_wrapper_chatter(self):
        self.assertEqual(manage.parse_job_id('site notice\n12345;vista\n'),'12345')
        self.assertEqual(manage.parse_job_id('Submitted batch job 1087200\n'),'1087200')
        with self.assertRaises(RuntimeError):manage.parse_job_id('123\n456\n')
        with self.assertRaises(RuntimeError):manage.parse_job_id('allocation error 987\n')


class ModelTests(unittest.TestCase):
    def test_all_models_compile_and_have_no_unbound_global_names(self):
        for problem in PROBLEMS:
            path=ROOT/'models'/f'{problem}.py'
            source=path.read_text();compile(source,str(path),'exec')
            functions=[n.name for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)]
            self.assertEqual(len(functions),len(set(functions)),problem)
            table=symtable.symtable(source,str(path),'exec')
            defined={s.get_name() for s in table.get_symbols() if s.is_assigned() or s.is_imported()}|set(dir(builtins))
            missing=set()
            def walk(t):
                for s in t.get_symbols():
                    if s.is_referenced() and s.is_global() and s.get_name() not in defined:missing.add(s.get_name())
                for child in t.get_children():walk(child)
            walk(table)
            self.assertEqual(missing,set(),problem)

    def test_forward_functions_are_preserved_from_sources(self):
        catalog=json.loads((ROOT/'provenance/catalog.json').read_text())
        for record in catalog:
            raw=(ROOT/'provenance/originals'/record['original']).read_bytes()
            self.assertEqual(hashlib.sha256(raw).hexdigest(),record['sha256'])
            original=raw.decode()
            if record['key']=='modulus':
                marker="print('\\n=== Hyperelastic shear-modulus HLSI pipeline complete ===')"
                original=original[:original.index(marker)]+marker+'\n'
            old={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(original)) if isinstance(n,ast.FunctionDef)}
            new={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse((ROOT/'models'/f'{record["key"]}.py').read_text())) if isinstance(n,ast.FunctionDef)}
            for name in record['preserved_functions']:self.assertEqual(old[name],new[name],record['key']+':'+name)


class AggregationTests(unittest.TestCase):
    def test_nll_uses_differences_and_failed_results_are_ineligible(self):
        entry={'task':{'problem':'poisson','seed':42},'status':{'state':'incomplete_metrics'},
               'metrics':{'GAD-1':{'RMSE_field':4,'HeldoutPredNLL':-1},
                          'GAD-3':{'RMSE_field':1,'HeldoutPredNLL':-3},
                          'MALA':{'RMSE_field':2,'HeldoutPredNLL':-2}}}
        row=aggregate.comparison(entry,3,'candidate')
        self.assertEqual(row['RMSE_field_gain_vs_MALA_pct'],50)
        self.assertEqual(row['RMSE_field_gain_from_round1_pct'],75)
        self.assertEqual(row['NLL_advantage_vs_MALA'],1)
        self.assertEqual(row['NLL_improvement_from_round1'],2)
        self.assertFalse(row['eligible_for_Pareto'])
        self.assertIsNone(aggregate.gain(0,1))

    def test_pareto_excludes_gaussian_control(self):
        rows=[dict(eligible_for_Pareto=True,RMSE_field_gain_from_round1_pct=x,RMSE_field_gain_vs_MALA_pct=y)
              for x,y in [(20,40),(10,30),(40,20)]]
        aggregate.mark_pareto(rows)
        self.assertEqual([r['RMSE_Pareto'] for r in rows],[True,False,True])

    def test_submission_snapshots_sources_and_persists_partial_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            batch=Path(temp)/'batch'
            args=argparse.Namespace(batch=batch,problems='darcy,navier_stokes',seed=42,
                allow_cpu=True,no_plots=True,check_models=False,particles=1000,bank=None,
                rounds=3,steps=200,mala_chains=32,mala_thin=1,mala_dt=1e-4,
                mala_budget_multiplier=1.,heldout_batch=2,eval_particles=1000,concurrency=2,time='02:00:00')
            replies=[subprocess.CompletedProcess([],0,'module notice\n12345;vista\n',''),
                     subprocess.CompletedProcess([],1,'','temporary dependency error')]
            with patch('manage.subprocess.run',side_effect=replies),contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(manage.submit_batch(args),2)
            self.assertEqual((batch/'array_job_id.txt').read_text().strip(),'12345')
            self.assertFalse((batch/'aggregate_job_id.txt').exists())
            self.assertTrue((batch/'source/sampling.py').is_file())
            found,status=aggregate.collect(batch)
            self.assertEqual(found,[])
            self.assertEqual([r['state'] for r in status],['missing','missing'])
            with contextlib.redirect_stdout(io.StringIO()):self.assertEqual(aggregate.aggregate(batch),2)
            self.assertTrue((batch/'screening_results.zip').is_file())
            self.assertTrue((batch/'comparison/completion_status.csv').is_file())

    def test_predictive_covariance_and_negative_nll(self):
        try:
            import numpy as np
            from evaluate import predictive_metrics
        except ImportError:self.skipTest('numpy unavailable')
        pred=np.array([[-.1,-.2],[0.,0.],[.1,.2]])
        metrics,_=predictive_metrics(pred,np.array([0.,0.]),.01)
        self.assertLess(metrics['HeldoutPredNLL'],0)
        self.assertEqual(metrics['heldout_covariance_mode'],'full')
        self.assertEqual(metrics['heldout_dimensions'],2)

    def test_valid_result_and_failed_neighbor_are_aggregated_separately(self):
        with tempfile.TemporaryDirectory() as temp:
            batch=Path(temp)/'batch'
            args=argparse.Namespace(batch=batch,problems='darcy,navier_stokes',seed=42,
                allow_cpu=True,no_plots=True,check_models=False,particles=1000,bank=None,
                rounds=3,steps=200,mala_chains=32,mala_thin=1,mala_dt=1e-4,
                mala_budget_multiplier=1.,heldout_batch=2,eval_particles=1000)
            manage.prepare(args)
            manifest=json.loads((batch/'batch_manifest.json').read_text())
            run=batch/'runs/darcy/seed_42/attempt_000';run.mkdir(parents=True)
            config=dict(settings=manifest['settings'],
                        sampling_sha256=manifest['source_sha256']['sampling.py'],
                        model_sha256=manifest['source_sha256']['models/darcy.py'])
            manage.save_json(run/'experiment_config.json',config)
            manage.save_json(run/'status.json',dict(state='complete',problem='darcy',seed=42))
            metrics={k:dict(RMSE_field=v,KSD=v,HeldoutPredNLL=-4+v,
                           finite_fraction=1.,runtime_seconds=v,pde_solve_count=9000,
                           mala_acceptance_rate=.574,mala_rhat_max=1.05)
                     for k,v in [('GAD-1',4),('GAD-2',2),('GAD-3',1),('MALA',2)]}
            manage.save_json(run/'metrics.json',metrics)
            failed=batch/'runs/navier_stokes/seed_42/attempt_000';failed.mkdir(parents=True)
            manage.save_json(failed/'status.json',dict(state='failed',problem='navier_stokes',seed=42,error='test failure'))
            with contextlib.redirect_stdout(io.StringIO()):self.assertEqual(aggregate.aggregate(batch),2)
            import csv
            with (batch/'comparison/selection_summary.csv').open() as f:rows=list(csv.DictReader(f))
            self.assertEqual(len(rows),1)
            self.assertEqual(float(rows[0]['RMSE_field_gain_vs_MALA_pct']),50.)
            self.assertEqual(rows[0]['RMSE_Pareto'],'True')
            self.assertIn('navier_stokes: failed',(batch/'comparison/comparison.md').read_text())


if __name__=='__main__':unittest.main()
