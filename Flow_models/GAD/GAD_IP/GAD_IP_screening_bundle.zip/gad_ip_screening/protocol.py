"""Shared screening protocol; standard-library only, safe on a login node."""
import math
from collections import OrderedDict
from dataclasses import asdict, dataclass

PROBLEMS = (
    'advect_diff', 'allen_cahn', 'poisson', 'darcy', 'eit_harder',
    'helmholtz', 'afwi', 'navier_stokes', 'heat', 'modulus',
)


@dataclass(frozen=True)
class Settings:
    particles: int = 1000
    bank: int = 1000
    rounds: int = 3
    steps: int = 200
    t_min: float = 10 ** -2.5
    t_max: float = 10.0
    hess_min: float = 1e-6
    hess_max: float = 1e6
    curvature_ridge: float = 1e-6
    mala_chains: int = 32
    mala_thin: int = 1
    mala_dt: float = 1e-4
    mala_budget_multiplier: float = 1.0
    log_batch: int = 8
    grad_batch: int = 4
    hess_batch: int = 1
    heldout_batch: int = 2
    eval_particles: int = 1000

    def validate(self):
        for key in ('particles', 'bank', 'rounds', 'steps', 'mala_chains',
                    'mala_thin', 'log_batch', 'grad_batch', 'hess_batch',
                    'heldout_batch', 'eval_particles'):
            if getattr(self, key) < 1:
                raise ValueError(f'{key} must be positive')
        if self.particles < 64:
            raise ValueError('Use at least 64 particles for the screening metrics')
        if self.bank > self.particles:
            raise ValueError('bank must not exceed particles in recursive rounds')
        if self.rounds < 2:
            raise ValueError('At least two rounds are required to measure iteration')
        if not 1e-4 <= self.t_min < self.t_max:
            raise ValueError('Require 1e-4 <= t_min < t_max')
        if not 0 < self.hess_min <= self.hess_max:
            raise ValueError('Require 0 < hess_min <= hess_max')
        for key in ('curvature_ridge', 'mala_dt', 'mala_budget_multiplier'):
            if not math.isfinite(getattr(self, key)) or getattr(self, key) <= 0:
                raise ValueError(f'{key} must be finite and positive')
        if self.eval_particles < 64:
            raise ValueError('eval_particles must be at least 64')
        return self


def make_protocol(settings):
    """Use the completed NS comparison's transport and MALA work convention."""
    s = settings.validate()
    configs = OrderedDict()
    for r in range(1, s.rounds + 1):
        label = f'GAD-{r}'
        cfg = dict(node='transport', score='lfgi', steps=s.steps,
                   n_samples=s.particles, n_ref=s.bank, n_gate=s.bank,
                   bank_coupling='shared', t_min=s.t_min, t_max=s.t_max,
                   include_results=True, log_mean_ess=True,
                   display_name=f'LFGI-GAD round {r}')
        if r > 1:
            cfg['ref_source'] = f'GAD-{r-1}'
        configs[label] = cfg
    chains = min(s.mala_chains, s.particles)
    draws = math.ceil(s.particles / chains)
    gad_work = 3 * s.bank * s.rounds
    target = gad_work * s.mala_budget_multiplier
    warmup = max(0, math.floor(target / (2 * chains) - 1 - draws * s.mala_thin))
    configs['MALA'] = dict(
        node='mala', n_samples=s.particles, mala_n_chains=chains,
        mala_warmup=warmup, mala_thin=s.mala_thin, mala_dt=s.mala_dt,
        mala_adapt=True, mala_target_accept=0.574, mala_min_dt=1e-12,
        mala_max_dt=1e-1, mala_progress_every=25,
        include_results=True, is_reference=True, display_name='MALA')
    mala_work = 2 * chains * (warmup + draws * s.mala_thin + 1)
    budget = dict(gad_expected_proxy=gad_work, mala_expected_proxy=mala_work,
                  mala_to_gad_proxy_ratio=mala_work / gad_work,
                  mala_warmup=warmup, mala_draws_per_chain=draws,
                  convention='3 evaluations per GN reference particle; 2 per MALA chain transition plus initialization; not elapsed time')
    return configs, budget


def add_settings_arguments(parser):
    parser.add_argument('--particles', type=int, default=1000)
    parser.add_argument('--bank', type=int, default=None)
    parser.add_argument('--rounds', type=int, default=3)
    parser.add_argument('--steps', type=int, default=200)
    parser.add_argument('--mala-chains', type=int, default=32)
    parser.add_argument('--mala-thin', type=int, default=1)
    parser.add_argument('--mala-dt', type=float, default=1e-4)
    parser.add_argument('--mala-budget-multiplier', type=float, default=1.0)
    parser.add_argument('--heldout-batch', type=int, default=2)
    parser.add_argument('--eval-particles', type=int, default=1000)


def settings_from_arguments(args):
    keys = ('particles', 'rounds', 'steps', 'mala_chains', 'mala_thin',
            'mala_dt', 'mala_budget_multiplier', 'heldout_batch', 'eval_particles')
    values = {k: getattr(args, k) for k in keys}
    values['bank'] = args.particles if args.bank is None else args.bank
    return Settings(**values).validate()
