#!/bin/bash
# Source this file from a Vista compute job or an interactive allocation.
if [[ "${IP_SKIP_MODULES:-0}" != 1 ]]; then
  module purge
  module load gcc/13.2.0
  module load python3/3.11.8
  source "${IP_VENV_DIR:-$SCRATCH/venvs/hlsi}/bin/activate"
fi
export OMP_NUM_THREADS="${SCREEN_CPU_THREADS:-8}"
export MKL_NUM_THREADS="$OMP_NUM_THREADS" OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS"
export NUMEXPR_NUM_THREADS="$OMP_NUM_THREADS" MPLBACKEND=Agg JAX_ENABLE_X64=true
export XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.20
