#!/usr/bin/env python3
"""Snapshot, submit, resume, inspect, and aggregate a one-seed problem sweep."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid
from dataclasses import asdict

from protocol import PROBLEMS, Settings, add_settings_arguments, make_protocol, settings_from_arguments

ROOT = Path(__file__).resolve().parent


def save_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + '\n')


def split_problems(text):
    result = list(PROBLEMS) if text == 'all' else [x.strip() for x in text.split(',') if x.strip()]
    if not result or len(set(result)) != len(result) or set(result)-set(PROBLEMS):
        raise ValueError(f'Choose unique problems from {", ".join(PROBLEMS)}')
    return result


def prepare(args):
    settings = settings_from_arguments(args)
    problems = split_problems(args.problems)
    base = Path.cwd()
    if base == ROOT or ROOT in base.parents:
        base = ROOT.parent
    batch = args.batch.resolve() if args.batch else base / 'batches' / (
        'ip_screening_' + dt.datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:6])
    if batch == ROOT or ROOT in batch.parents:
        raise ValueError('Put the batch outside the bundle source directory to avoid recursive snapshots')
    if any(c in str(batch) for c in (',', '\n', '\r')):
        raise ValueError('The batch path cannot contain commas or line breaks in Slurm exports')
    if batch.exists():
        raise FileExistsError(f'Refusing to overwrite existing batch {batch}')
    batch.mkdir(parents=True)
    (batch/'logs').mkdir()
    shutil.copytree(ROOT, batch/'source', ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.DS_Store'))
    tasks = [dict(task=i,problem=problem,seed=args.seed) for i,problem in enumerate(problems)]
    _, budget = make_protocol(settings)
    manifest = dict(schema_version=1, created=dt.datetime.now(dt.timezone.utc).isoformat(),
                    mode='check' if args.check_models else 'screen', tasks=tasks,
                    settings=asdict(settings), budget=budget, allow_cpu=args.allow_cpu,
                    no_plots=args.no_plots, seed=args.seed,
                    source_sha256={str(p.relative_to(batch/'source')):hashlib.sha256(p.read_bytes()).hexdigest()
                                   for p in (batch/'source').rglob('*') if p.is_file()})
    save_json(batch/'batch_manifest.json',manifest)
    return batch


def parse_job_id(stdout):
    # Accept parsable output, parsable cluster suffixes, and conventional wrappers.
    candidates = []
    for line in stdout.splitlines():
        m = re.fullmatch(r'\s*(\d+)(?:;[\w.-]+)?\s*', line)
        if m is None:
            m = re.fullmatch(r'\s*Submitted batch job (\d+)\s*',line)
        if m: candidates.append(m.group(1))
    if len(set(candidates)) != 1:
        raise RuntimeError(f'Could not unambiguously parse sbatch job ID: {stdout!r}')
    return candidates[0]


def sbatch(batch, arguments, log_stem):
    completed = subprocess.run(['sbatch','--parsable',*arguments],capture_output=True,text=True)
    (batch/'logs'/f'{log_stem}_submission.txt').write_text(completed.stdout + completed.stderr)
    if completed.returncode:
        raise RuntimeError(f'sbatch failed: {completed.stderr.strip() or completed.stdout.strip()}')
    return parse_job_id(completed.stdout)


def submit_aggregate(batch, array_job):
    export = f'ALL,SCREEN_BATCH_DIR={batch}'
    job = sbatch(batch,[f'--dependency=afterany:{array_job}',f'--export={export}',
                        f'--output={batch}/logs/aggregate-%j.out',
                        str(batch/'source'/'aggregate.slurm')],'aggregate')
    (batch/'aggregate_job_id.txt').write_text(job+'\n')
    return job


def submit_batch(args):
    if args.concurrency < 1: raise ValueError('concurrency must be positive')
    batch = prepare(args)
    manifest = json.loads((batch/'batch_manifest.json').read_text())
    array = f'0-{len(manifest["tasks"])-1}%{args.concurrency}'
    print(f'Batch: {batch}',flush=True)
    # Print and persist the first job before attempting the dependent submission.
    job = sbatch(batch,[f'--array={array}',f'--time={args.time}',
                        f'--export=ALL,SCREEN_BATCH_DIR={batch}',
                        f'--output={batch}/logs/problem-%A_%a.out',
                        str(batch/'source'/'run_problem.slurm')],'array')
    (batch/'array_job_id.txt').write_text(job+'\n')
    print(f'Problem array: {job}',flush=True)
    try:
        aggregate = submit_aggregate(batch,job)
        print(f'Aggregation: {aggregate}',flush=True)
    except Exception as exc:
        print(f'Array is submitted. Aggregation submission failed: {exc}\n'
              f'Recover without repeating experiments:\npython3 "{batch}/source/manage.py" '
              f'submit-aggregate --batch "{batch}" --array-job {job}', file=sys.stderr)
        return 2
    return 0


def run_task(args):
    batch = args.batch.resolve()
    manifest = json.loads((batch/'batch_manifest.json').read_text())
    if not 0 <= args.task < len(manifest['tasks']): raise ValueError('task out of range')
    task = manifest['tasks'][args.task]
    base = batch/'runs'/task['problem']/f'seed_{task["seed"]}'
    if args.attempt is None:
        # A requeued array task resumes to a fresh, retained attempt automatically.
        attempts = [int(p.name.split('_')[1]) for p in base.glob('attempt_*') if p.name.split('_')[1].isdigit()]
        attempt = max(attempts, default=-1)+1
    else:
        attempt = args.attempt
    output = base/f'attempt_{attempt:03d}'
    from run_problem import execute
    status = execute(task['problem'],task['seed'],Settings(**manifest['settings']),output,
                     check_only=manifest['mode']=='check',allow_cpu=manifest['allow_cpu'],
                     no_plots=manifest['no_plots'])
    return 0 if status['state']=='complete' else 2


def main():
    p = argparse.ArgumentParser(description=__doc__)
    subs = p.add_subparsers(dest='command',required=True)
    for cmd in ('prepare','submit'):
        sub = subs.add_parser(cmd)
        sub.add_argument('--batch',type=Path)
        sub.add_argument('--problems',default='all')
        sub.add_argument('--seed',type=int,default=42)
        sub.add_argument('--allow-cpu',action='store_true')
        sub.add_argument('--no-plots',action='store_true')
        sub.add_argument('--check-models',action='store_true',help='derivative checks only; do not rank as experiments')
        add_settings_arguments(sub)
        if cmd=='submit':
            sub.add_argument('--concurrency',type=int,default=2)
            sub.add_argument('--time',default='02:00:00')
    sub=subs.add_parser('run')
    sub.add_argument('--batch',type=Path,required=True)
    sub.add_argument('--task',type=int,required=True)
    sub.add_argument('--attempt',type=int)
    sub=subs.add_parser('submit-aggregate')
    sub.add_argument('--batch',type=Path,required=True)
    sub.add_argument('--array-job',required=True)
    for cmd in ('status','aggregate'):
        sub=subs.add_parser(cmd);sub.add_argument('--batch',type=Path,required=True)
    args=p.parse_args()
    if args.command=='prepare': print(prepare(args));return 0
    if args.command=='submit': return submit_batch(args)
    if args.command=='submit-aggregate':
        if not re.fullmatch(r'\d+',args.array_job): raise ValueError('numeric array job ID required')
        print(submit_aggregate(args.batch.resolve(),args.array_job));return 0
    if args.command=='run': return run_task(args)
    if args.command in ('status','aggregate'):
        from aggregate import collect, aggregate
        if args.command=='status':
            _,status=collect(args.batch.resolve())
            for row in status: print(f'{row["task"]:2d} {row["problem"]:16s} {row["state"]}')
            return 0
        return aggregate(args.batch.resolve())


if __name__=='__main__':
    sys.exit(main())
