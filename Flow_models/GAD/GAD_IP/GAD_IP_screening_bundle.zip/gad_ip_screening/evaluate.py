"""Finite-sample metrics, shared evaluation subsets, and diagnostic figures."""
import json
import math
from pathlib import Path

import numpy as np


def write_json(path, value):
    def clean(x):
        if isinstance(x, dict):
            return {str(k): clean(v) for k, v in x.items()}
        if isinstance(x, (tuple, list)):
            return [clean(v) for v in x]
        if isinstance(x, np.ndarray):
            return clean(x.tolist())
        if isinstance(x, np.generic):
            return clean(x.item())
        if isinstance(x, float) and not math.isfinite(x):
            return None
        if isinstance(x, Path):
            return str(x)
        return x
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(clean(value), indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def predictive_metrics(pred, obs, noise_std):
    """Gaussian predictive NLL with full covariance, plus marginal calibration."""
    pred = np.asarray(pred, dtype=np.float64)
    n_requested = len(pred)
    pred = pred[np.isfinite(pred).all(axis=1)]
    obs = np.asarray(obs, dtype=np.float64).reshape(-1)
    if pred.shape[0] < 2 or pred.shape[1] != obs.size or not obs.size:
        raise ValueError('Insufficient or inconsistent held-out predictions')
    mean = pred.mean(axis=0)
    centered = pred - mean
    cov = centered.T @ centered / (len(pred) - 1)
    cov.flat[::obs.size + 1] += noise_std ** 2
    var = np.diag(cov).copy()
    residual = obs - mean
    # Retain the existing metric's full-covariance definition and jitter scale.
    jitter = max(1e-8 * max(1.0, float(var.mean())), 1e-12)
    mode = 'full'
    for _ in range(8):
        try:
            chol = np.linalg.cholesky(cov + jitter * np.eye(obs.size))
            whitened = np.linalg.solve(chol, residual)
            quad = float(whitened @ whitened)
            logdet = float(2 * np.log(np.diag(chol)).sum())
            break
        except np.linalg.LinAlgError:
            jitter *= 10
    else:
        mode = 'diag_fallback'
        diagonal = np.maximum(var + jitter, 1e-18)
        quad = float(np.sum(residual ** 2 / diagonal))
        logdet = float(np.log(diagonal).sum())
    return dict(
        HeldoutPredNLL=0.5 * (obs.size * np.log(2 * np.pi) + logdet + quad) / obs.size,
        HeldoutStdResSq=float(np.mean(residual ** 2 / np.maximum(var, 1e-18))),
        HeldoutPredRMSE=float(np.sqrt(np.mean(residual ** 2))),
        HeldoutCoverage95=float(np.mean(np.abs(residual) <= 1.95996398454 * np.sqrt(var))),
        heldout_covariance_mode=mode, heldout_jitter=jitter,
        heldout_predictive_samples=int(len(pred)), heldout_dimensions=int(obs.size),
        heldout_predictive_finite_fraction=len(pred) / n_requested), mean


def gaussian_oracle(model):
    """Exact posterior for the linear Gaussian advection–diffusion control."""
    import jax
    import jax.numpy as jnp
    d = model.ACTIVE_DIM
    zero = jnp.zeros(d, dtype=jnp.float64)
    offset = np.asarray(model.solve_forward(zero))
    jac = np.asarray(jax.jacfwd(model.solve_forward)(zero))
    precision = np.eye(d) + jac.T @ jac / model.NOISE_STD ** 2
    covariance = np.linalg.solve(precision, np.eye(d))
    mean = np.linalg.solve(precision, jac.T @ (model.y_obs_np - offset) / model.NOISE_STD ** 2)
    return mean, covariance, precision


def evaluate(model, samples, settings, seed, output_dir, problem):
    import torch
    import jax
    import jax.numpy as jnp
    import sampling
    output_dir = Path(output_dir)
    # Match subset indices across methods. Never delete finite tail particles.
    indices = np.random.default_rng(seed + 901).permutation(settings.particles)[:settings.eval_particles]
    rows, fields, pca_samples, details = {}, {}, {}, {}
    true_field = np.asarray(model.field_from_latent(model.alpha_true_np))
    true_norm = np.linalg.norm(true_field) + 1e-12
    heldout_batch = jax.jit(jax.vmap(model.solve_forward_holdout))
    oracle = gaussian_oracle(model) if problem == 'advect_diff' else None
    if oracle:
        np.savez_compressed(output_dir / 'gaussian_oracle.npz', mean=oracle[0], covariance=oracle[1])
    for label, raw in samples.items():
        raw = np.asarray(raw, dtype=np.float64)
        finite_mask = np.isfinite(raw).all(axis=1)
        finite = raw[finite_mask]
        row = dict(n_total=len(raw), n_finite=len(finite), finite_fraction=float(finite_mask.mean()))
        rows[label] = row
        if len(finite) < 64:
            details[label] = {'error': 'fewer than 64 finite particles'}
            continue
        # Audit what the older IQR-cleaning helper would have removed, without using it.
        q25, q75 = np.percentile(finite, [25, 75], axis=0)
        iqr = q75 - q25
        row['legacy_IQR_retained'] = int(((finite >= q25 - 5 * iqr) & (finite <= q75 + 5 * iqr)).all(axis=1).sum())
        mean = finite.mean(axis=0)
        field = np.asarray(model.field_from_latent(mean))
        fields[label] = field
        pca_samples[label] = finite
        row.update(RMSE_alpha=float(np.sqrt(np.mean((mean - model.alpha_true_np) ** 2))),
                   RMSE_field=float(np.sqrt(np.mean((field - true_field) ** 2))),
                   RelL2_field=float(np.linalg.norm(field - true_field) / true_norm))
        # For nonlinear field maps, report both field-at-mean and posterior mean field.
        field_sum = np.zeros_like(true_field, dtype=np.float64)
        for alpha in finite:
            field_sum += np.asarray(model.field_from_latent(alpha))
        posterior_field = field_sum / len(finite)
        row['PosteriorMeanRMSE_field'] = float(np.sqrt(np.mean((posterior_field - true_field) ** 2)))
        pred_mean_parameter = np.asarray(model.solve_forward(jnp.asarray(mean)))
        row['FwdRelErr'] = float(np.linalg.norm(pred_mean_parameter - model.y_clean_np) / (np.linalg.norm(model.y_clean_np) + 1e-12))
        # Shared subsets and a reset metric RNG keep round-to-round KSD comparable.
        subset = raw[indices]
        subset = subset[np.isfinite(subset).all(axis=1)]
        if len(subset) < 64:
            subset = finite[:min(settings.eval_particles, len(finite))]
        row['eval_samples'] = len(subset)
        x = torch.as_tensor(subset, dtype=torch.float64, device=sampling.device)
        torch.manual_seed(seed + 902)
        row['KSD'] = float(sampling.compute_multiscale_ksd(x, sampling.make_posterior_score_fn(model.lik_model)))
        # The entropy-based quantity has an unknown additive normalizer and is diagnostic only.
        row['KLdiag'] = float(sampling.compute_kl_divergence(x, model.prior_model, model.lik_model))
        try:
            chunks = [np.asarray(heldout_batch(jnp.asarray(subset[i:i + settings.heldout_batch])))
                      for i in range(0, len(subset), settings.heldout_batch)]
            pred = np.concatenate(chunks)
            heldout, predictive_mean = predictive_metrics(pred, model.y_holdout_obs_np, float(model.NOISE_STD))
            row.update(heldout)
            details.setdefault(label, {})['heldout_predictive_mean'] = predictive_mean
        except Exception as exc:
            row['heldout_error'] = f'{type(exc).__name__}: {exc}'
        if oracle:
            oracle_mean, oracle_cov, precision = oracle
            emp_cov = np.cov(finite, rowvar=False)
            delta = mean - oracle_mean
            row['OracleMeanRMSE'] = float(np.sqrt(np.mean(delta ** 2)))
            row['OracleCovRelFro'] = float(np.linalg.norm(emp_cov - oracle_cov) / np.linalg.norm(oracle_cov))
            sign, logdet = np.linalg.slogdet(emp_cov)
            row['OracleGaussianMomentKL'] = float(0.5 * (
                np.trace(precision @ emp_cov) + delta @ precision @ delta - model.ACTIVE_DIM
                - np.linalg.slogdet(precision)[1] - logdet)) if sign > 0 else None
    # MALA discrepancy is explicitly not a posterior-accuracy score.
    if 'MALA' in pca_samples:
        ref = torch.as_tensor(pca_samples['MALA'][:settings.eval_particles], dtype=torch.float64, device=sampling.device)
        for label, finite in pca_samples.items():
            x = torch.as_tensor(finite[:settings.eval_particles], dtype=torch.float64, device=sampling.device)
            rows[label]['MMD_to_MALA_diagnostic'] = float(sampling.compute_mmd_rbf(x, ref))
    write_json(output_dir / 'evaluation_details.json', details)
    write_json(output_dir / 'metrics.json', rows)
    np.savez_compressed(output_dir / 'field_summaries.npz', truth=true_field, **fields)
    return rows, fields, pca_samples


def make_figures(model, rows, fields, samples, run_info, output_dir):
    import matplotlib.pyplot as plt
    output_dir = Path(output_dir)
    labels = list(fields)
    fig, axes = plt.subplots(1, len(labels) + 1, figsize=(3.1 * (len(labels) + 1), 3.3), squeeze=False)
    truth = np.asarray(model.true_field)
    panels = [truth] + [fields[k] for k in labels]
    lo, hi = min(float(x.min()) for x in panels), max(float(x.max()) for x in panels)
    for ax, field, title in zip(axes[0], panels, ['Truth'] + labels):
        im = ax.imshow(field, origin='lower', vmin=lo, vmax=hi, cmap='viridis')
        ax.set_title(title); ax.set_xticks([]); ax.set_yticks([])
    fig.colorbar(im, ax=axes.ravel().tolist(), shrink=.75)
    fig.savefig(output_dir / 'field_reconstruction.png', dpi=170, bbox_inches='tight'); plt.close(fig)
    if samples:
        # Fixed shared PCA coordinates across all methods, including identical windows.
        pool = np.concatenate([samples[k] for k in samples], axis=0)
        center = pool.mean(axis=0)
        _, _, vt = np.linalg.svd(pool - center, full_matrices=False)
        projections = {k: (v - center) @ vt[:2].T for k, v in samples.items()}
        combined = np.concatenate(list(projections.values()))
        bounds = [(float(combined[:, i].min()), float(combined[:, i].max())) for i in range(2)]
        bounds = [(lo - 1e-6, hi + 1e-6) if hi <= lo else (lo, hi) for lo, hi in bounds]
        hist = {k: np.histogram2d(v[:, 0], v[:, 1], bins=45, range=bounds)[0] for k, v in projections.items()}
        vmax = max(float(v.max()) for v in hist.values())
        fig, axes = plt.subplots(1, len(hist), figsize=(3.1 * len(hist), 3.1), squeeze=False)
        for ax, (k, h) in zip(axes[0], hist.items()):
            ax.imshow(h.T, origin='lower', extent=(*bounds[0], *bounds[1]), vmax=vmax, vmin=0, aspect='auto', cmap='magma')
            ax.set_title(k); ax.set_xlabel('PC 1'); ax.set_ylabel('PC 2')
        fig.tight_layout(); fig.savefig(output_dir / 'posterior_pca.png', dpi=170); plt.close(fig)
        np.savez_compressed(output_dir / 'pca_basis.npz', center=center, basis=vt[:2])
    gad = [k for k in rows if k.startswith('GAD-')]
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.4))
    for ax, metric in zip(axes, ('RMSE_field', 'KSD', 'HeldoutPredNLL')):
        pairs = [(int(k.split('-')[1]), rows[k].get(metric)) for k in gad]
        pairs = [(r, v) for r, v in pairs if v is not None and np.isfinite(v)]
        if pairs:
            ax.plot(*zip(*pairs), marker='o', label='GAD')
        mala = rows.get('MALA', {}).get(metric)
        if mala is not None and np.isfinite(mala):
            ax.axhline(mala, color='C1', ls='--', label='MALA')
        ax.set_title(metric); ax.set_xlabel('GAD round'); ax.grid(alpha=.2)
        ax.set_xticks([int(k.split('-')[1]) for k in gad])
        if ax.lines: ax.legend()
    fig.tight_layout(); fig.savefig(output_dir / 'round_metrics.png', dpi=170); plt.close(fig)
    details_path = output_dir / 'evaluation_details.json'
    if details_path.exists():
        details = json.loads(details_path.read_text())
        fig, ax = plt.subplots(figsize=(11, 3.5))
        obs = np.asarray(model.y_holdout_obs_np).reshape(-1)
        subset = np.linspace(0, len(obs)-1, min(600, len(obs)), dtype=int)
        ax.plot(subset, obs[subset], '.', color='gray', alpha=.6, label='Held-out observations')
        for label in rows:
            pred = details.get(label, {}).get('heldout_predictive_mean')
            if pred is not None:
                ax.plot(subset, np.asarray(pred)[subset], lw=1, alpha=.8, label=label)
        ax.set_xlabel('Held-out measurement index'); ax.set_ylabel('Observation / predictive mean')
        ax.legend(ncol=3, fontsize=8); fig.tight_layout()
        fig.savefig(output_dir / 'heldout_predictions.png', dpi=170); plt.close(fig)
    if hasattr(model, 'state_from_latent'):
        panels, titles = [], []
        for label, alpha in [('Truth', model.alpha_true_np)] + [(k, v.mean(axis=0)) for k, v in samples.items()]:
            panels.append(np.asarray(model.state_from_latent(alpha))); titles.append(label)
        lo, hi = min(v.min() for v in panels), max(v.max() for v in panels)
        fig, axes = plt.subplots(1, len(panels), figsize=(3.1 * len(panels), 3.1), squeeze=False)
        for ax, state, title in zip(axes[0], panels, titles):
            ax.imshow(state, origin='lower', vmin=lo, vmax=hi, cmap='coolwarm'); ax.set_title(title)
        fig.tight_layout(); fig.savefig(output_dir / 'state_reconstruction.png', dpi=170); plt.close(fig)
