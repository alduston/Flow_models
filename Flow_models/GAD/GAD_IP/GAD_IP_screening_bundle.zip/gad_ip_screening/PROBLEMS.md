# Model equations retained for the screening sweep

All problems use a standard normal latent prior, a finite KL/Fourier field representation `m = Basis @ alpha`, and independent additive Gaussian observation noise. The model code specifies the actual discretization and boundary treatment. Training and held-out observations share one truth realization within each problem.

| Problem | Forward model | Inferred field and observations |
|---|---|---|
| Advection–diffusion | `u_t = kappa Delta u - v . grad u`, periodic; exact spectral propagation to `t=0.5` | Initial condition; `kappa=0.0025`, `v=(0.90,-0.55)`, Gaussian noise SD 0.01. The map is linear, hence the latent posterior is exactly Gaussian. |
| Allen–Cahn | `u_t = epsilon^2 Delta u + u - u^3`, periodic; semi-implicit Fourier diffusion and explicit reaction | Initial condition; `epsilon=0.045`, time 0.33, step 0.0005, noise SD 0.01. |
| Poisson coefficient | `-Delta u + q(x) u = f(x)`, zero Dirichlet boundary | Positive reaction coefficient `q=0.15+softplus(m)`, structured source field; pointwise state observations, noise SD `1e-5`. This is reaction-coefficient inversion, not Darcy conductivity inversion. |
| Darcy | `-div(exp(m) grad p)=1`, zero Dirichlet boundary | Log permeability; interior pressure observations, noise SD 0.001. |
| EIT | `-div(exp(m) grad u_l)=0` with prescribed boundary currents; one pinned potential fixes the gauge | Log conductivity; 12 current patterns, 40 clustered/backbone training electrodes and 84 held-out boundary nodes, noise SD `1.5e-5`. |
| Helmholtz | `[-Delta - k^2 n(x)^2 + i gamma] u_l = f_l` using the preserved discrete boundary graph | Contrast `n^2-1=0.45*tanh(m)*support`; four sources, real and imaginary scattered boundary traces, `k=24`, `gamma=6`, noise SD `4e-4`. |
| Acoustic FWI | `u_tt + gamma(x) u_t = c(x)^2 Delta u + f_l`, zero outer displacement and sponge damping | Velocity from the preserved bounded log-perturbation map; eight sources, 46 receivers, 240 time steps of 0.0035, record stride four. Noise SD is 5% of the clean training-data SD. |
| Navier–Stokes | Forced incompressible two-dimensional vorticity dynamics, periodic, with spectral de-aliasing and the preserved semi-implicit step | Initial vorticity; viscosity `7.5e-4`, time horizon 10.5, step 0.05, anisotropic observation filtering and Fourier prior, noise SD 0.005. |
| Heat | `-div(exp(m) grad T)=20`, zero Dirichlet boundary except the top root edge with homogeneous Neumann data | Log conductivity; ten preserved training locations and ten held-out locations, noise SD 0.0075. |
| Membrane modulus | Energy density `W = mu*(q/2 + beta*q^2/4)`, `q=|grad u_x|^2+|grad u_y|^2`, `mu=exp(m)` | Log shear modulus; nonlinear coefficient `mu*(1+6q)` clipped to `[1e-3,1e3]`, three Picard iterations with damping 0.75. Two prescribed displacement loads train; a third mixed load is held out. Noise SD 0.001. |

The membrane code is a simplified nonlinear membrane model, rather than a full three-dimensional hyperelastic finite-element model. Its finite Picard solve and coefficient clipping are part of the preserved forward map.

`provenance/inverse_problems_legacy_notes.tex` contains the supplied earlier exposition and older results. It may use different historical parameters or estimator variants. Use the table above, `models/`, and each task's `experiment_config.json` for this sweep's actual setup.
