"""Compare within-problem MALA competitiveness and gains from GAD iteration."""
import csv
import hashlib
import json
import math
from pathlib import Path
import zipfile


def read_json(path):
    return json.loads(Path(path).read_text())


def collect(batch):
    batch=Path(batch)
    manifest=read_json(batch/'batch_manifest.json')
    found,status=[],[]
    for task in manifest['tasks']:
        base=batch/'runs'/task['problem']/f'seed_{task["seed"]}'
        attempts=sorted(base.glob('attempt_*'))
        row=dict(task=task['task'],problem=task['problem'],seed=task['seed'],state='missing',attempt='',error='')
        if attempts:
            attempt=attempts[-1]
            row['attempt']=str(attempt.relative_to(batch))
            try:
                state=read_json(attempt/'status.json')
                row['state']=state['state'];row['error']=state.get('error','')
                if row['state']=='running': row['state']='running_or_interrupted'
                if state.get('problem')!=task['problem'] or state.get('seed')!=task['seed']:
                    raise ValueError('Status identity does not match batch task')
                if manifest['mode']=='screen' and row['state'] in ('complete','incomplete_metrics'):
                    config=read_json(attempt/'experiment_config.json')
                    if config['settings']!=manifest['settings']:
                        raise ValueError('Task settings differ from batch settings')
                    for config_key,relative in [('sampling_sha256','sampling.py'),('model_sha256',f'models/{task["problem"]}.py')]:
                        if config[config_key]!=manifest['source_sha256'][relative]:
                            raise ValueError(f'Source checksum mismatch: {relative}')
                    metrics=read_json(attempt/'metrics.json')
                    found.append(dict(task=task,attempt=attempt,status=state,metrics=metrics,config=config))
            except Exception as exc:
                row.update(state='invalid',error=f'{type(exc).__name__}: {exc}')
        status.append(row)
    return found,status


def number(value):
    return isinstance(value,(float,int)) and math.isfinite(value)


def gain(base,value):
    # Percentage improvements are restricted to strictly positive-scale errors.
    return 100*(base-value)/base if number(base) and base>0 and number(value) else None


def difference(base,value):
    return base-value if number(base) and number(value) else None


def comparison(entry,rounds,role):
    metrics=entry['metrics']
    first,last,mala=(metrics.get(k,{}) for k in ('GAD-1',f'GAD-{rounds}','MALA'))
    result=dict(problem=entry['task']['problem'],seed=entry['task']['seed'],role=role,
                state=entry['status']['state'],last_round=rounds)
    for metric in ('RMSE_field','PosteriorMeanRMSE_field','RMSE_alpha','KSD','FwdRelErr','HeldoutPredRMSE'):
        result[f'{metric}_gain_vs_MALA_pct']=gain(mala.get(metric),last.get(metric))
        result[f'{metric}_gain_from_round1_pct']=gain(first.get(metric),last.get(metric))
    result['NLL_advantage_vs_MALA']=difference(mala.get('HeldoutPredNLL'),last.get('HeldoutPredNLL'))
    result['NLL_improvement_from_round1']=difference(first.get('HeldoutPredNLL'),last.get('HeldoutPredNLL'))
    result['KLdiag_advantage_vs_MALA_diagnostic']=difference(mala.get('KLdiag'),last.get('KLdiag'))
    a,b=last.get('runtime_seconds'),mala.get('runtime_seconds')
    result['GAD_to_MALA_runtime_ratio']=a/b if number(a) and number(b) and b>0 else None
    a,b=last.get('pde_solve_count'),mala.get('pde_solve_count')
    result['GAD_to_MALA_proxy_ratio']=a/b if number(a) and number(b) and b>0 else None
    result['MALA_acceptance']=mala.get('mala_acceptance_rate')
    result['MALA_split_Rhat_max']=mala.get('mala_rhat_max')
    result['MALA_unique_fraction']=mala.get('mala_unique_fraction')
    result['GAD_finite_fraction']=last.get('finite_fraction')
    result['warnings']='; '.join(entry['status'].get('warnings',[]))
    x,y=(result[k] for k in ('RMSE_field_gain_from_round1_pct','RMSE_field_gain_vs_MALA_pct'))
    result['both_RMSE_axes_positive']=number(x) and number(y) and x>0 and y>0
    result['eligible_for_Pareto']=entry['status']['state']=='complete' and role!='linear_gaussian' and number(x) and number(y)
    result['RMSE_Pareto']=False
    return result


def mark_pareto(rows):
    eligible=[r for r in rows if r.get('eligible_for_Pareto')]
    keys=('RMSE_field_gain_from_round1_pct','RMSE_field_gain_vs_MALA_pct')
    for row in eligible:
        row['RMSE_Pareto']=not any(all(other[k]>=row[k] for k in keys) and any(other[k]>row[k] for k in keys)
                                  for other in eligible if other is not row)


def write_csv(path,rows,leading=()):
    keys=list(leading)+sorted({k for r in rows for k in r}-set(leading))
    with Path(path).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=keys)
        writer.writeheader();writer.writerows(rows)


def fmt(x):
    return f'{x:.3g}' if number(x) else '—'


def plot_summary(rows,path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(13,5))
    for ax,metric,title in zip(axes,('RMSE_field','KSD'),('Field reconstruction','Exact-score squared KSD')):
        for row in rows:
            x,y=(row.get(f'{metric}_gain_from_round1_pct'),row.get(f'{metric}_gain_vs_MALA_pct'))
            if not number(x) or not number(y): continue
            color='C2' if row['role']=='linear_gaussian' else ('C1' if row['role']=='anchor' else 'C0')
            ax.scatter(x,y,color=color,marker='s' if row['role']=='linear_gaussian' else 'o',s=50)
            ax.annotate(row['problem'],(x,y),xytext=(4,4),textcoords='offset points',fontsize=8)
        ax.axhline(0,color='gray',lw=.7);ax.axvline(0,color='gray',lw=.7)
        ax.set_xlabel('Improvement from GAD round 1 (%)')
        ax.set_ylabel('Improvement over MALA (%)');ax.set_title(title);ax.grid(alpha=.15)
    fig.suptitle('One realization per problem; upper-right indicates improvement on both axes')
    fig.tight_layout();fig.savefig(path,dpi=180);plt.close(fig)


def aggregate(batch):
    batch=Path(batch)
    manifest=read_json(batch/'batch_manifest.json')
    entries,status=collect(batch)
    out=batch/'comparison';out.mkdir(exist_ok=True)
    write_csv(out/'completion_status.csv',status,('task','problem','seed','state','attempt','error'))
    complete=all(r['state']=='complete' for r in status)
    rows=[];long=[]
    catalog=read_json(batch/'source/provenance/catalog.json')
    roles={x['key']:x['role'] for x in catalog}
    for entry in entries:
        rows.append(comparison(entry,manifest['settings']['rounds'],roles[entry['task']['problem']]))
        for method,metrics in entry['metrics'].items():
            long.append(dict(problem=entry['task']['problem'],seed=entry['task']['seed'],method=method,**metrics))
    mark_pareto(rows)
    write_csv(out/'selection_summary.csv',rows,('problem','seed','role','state'))
    write_csv(out/'all_metrics.csv',long,('problem','seed','method'))
    note=[]
    if rows:
        try: plot_summary(rows,out/'selection_axes.png')
        except Exception as exc: note.append(f'Summary plot unavailable: {exc}')
    report=['# Inverse-problem screening comparison','',
            f'Completed tasks: {sum(r["state"]=="complete" for r in status)}/{len(status)}. Mode: {manifest["mode"]}.',
            '', 'Each problem uses one synthetic realization. These results select candidates for subsequent repeats; they do not estimate uncertainty.',
            '', 'Positive values in the table indicate improvement. RMSE and KSD use percentage reduction; predictive NLL uses an absolute difference, because its additive scale can be negative.',
            '', '| Problem | Role | RMSE gain vs MALA % | RMSE gain from round 1 % | KSD gain vs MALA % | KSD gain from round 1 % | NLL advantage vs MALA | NLL improvement from round 1 |',
            '|---|---|---:|---:|---:|---:|---:|---:|']
    for row in rows:
        values=[row.get(k) for k in ('RMSE_field_gain_vs_MALA_pct','RMSE_field_gain_from_round1_pct',
                  'KSD_gain_vs_MALA_pct','KSD_gain_from_round1_pct','NLL_advantage_vs_MALA','NLL_improvement_from_round1')]
        report.append('| '+row['problem']+' | '+row['role']+' | '+' | '.join(fmt(x) for x in values)+' |')
    report += ['', '## Reading the screening results', '',
               '- Favor substantial improvement on both requested axes, corroborated by KSD and held-out predictive behavior.',
               '- `RMSE_Pareto` identifies problems not dominated on the two field-RMSE axes. It is a transparent screening aid, not an overall scientific ranking.',
               '- Advection–diffusion is a linear Gaussian control and is excluded from the nonlinear shortlist. Its exact posterior mean/covariance diagnostics are saved separately.',
               '- Truth reconstruction, predictive calibration, and posterior sampling accuracy measure different things. A better posterior mean alone does not demonstrate a better posterior approximation.',
               '- MALA is a budget-matched baseline, not ground truth. Inspect acceptance, split-R-hat, and unique draws; apparent wins over a poorly mixed baseline need a stronger follow-up.',
               '- The portable derivative-count proxy is not elapsed time. Both are reported, with cumulative GAD runtime and work through the last round.',
               '- Metrics use every finite particle for field means and a shared evaluation subset for predictive metrics/KSD. No finite tails are silently removed. Raw samples and the legacy IQR-retention count are retained.',
               '- `KSD` is the existing squared multiscale V-statistic (including its finite-sample diagonal floor), not its square root. `KLdiag` is a kNN-entropy diagnostic with an unknown additive normalizer. MMD to MALA is disagreement, not accuracy.',
               '- Larger finite-particle sampling or integration error can create apparent iteration gains even in Gaussian cases. Use the Gaussian control and repeated seeds before interpreting small differences.',
               '', '## Task status', '']
    report += [f'- {r["problem"]}: {r["state"]}'+(f' — {r["error"]}' if r['error'] else '') for r in status]
    for row in rows:
        if row['warnings']: report.append(f'- {row["problem"]} diagnostics: {row["warnings"]}')
    report += ['', *note]
    (out/'comparison.md').write_text('\n'.join(report)+'\n')
    # Always package partial outcomes and failure logs; never aggregate unrelated directories.
    archive=batch/'screening_results.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for relative in ('batch_manifest.json','array_job_id.txt','aggregate_job_id.txt'):
            if (batch/relative).is_file(): z.write(batch/relative,relative)
        for folder in ('source','comparison','logs','runs'):
            for path in sorted((batch/folder).rglob('*')):
                if path.is_file() and '__pycache__' not in path.parts:
                    z.write(path,str(path.relative_to(batch)))
    print(f'Comparison: {out / "comparison.md"}\nReturn archive: {archive}',flush=True)
    return 0 if complete else 2
