"""One morphology-calibrated smooth phase prior, with a validated pCN draw pool."""
import numpy as np
import time
import jax
import jax.numpy as jnp
from io_utils import read,write,save_npz,say
from models import Physics

def calibrate(run,stop):
    started=time.monotonic()
    folder=run/'calibration/phase';folder.mkdir(parents=True,exist_ok=True)
    if (folder/'pool.json').exists():return read(folder/'pool.json')
    physics=Physics('allen_cahn');B=physics.B;ell=3/32;amplitude=1.
    def phase(x):
        u=(B@x).reshape(32,32);dx=(jnp.roll(u,-1,0)-u)*32;dy=(jnp.roll(u,-1,1)-u)*32
        return jnp.mean(.5*ell*(dx*dx+dy*dy)+(u*u-amplitude**2)**2/(4*ell))
    batch=jax.jit(jax.vmap(phase)); rng=np.random.default_rng(20261102)
    pilot=rng.normal(size=(32,32));energies=np.asarray(batch(jnp.asarray(pilot)))
    strength=4/max(float(energies.std(ddof=1)),1e-8)
    parameters=dict(ell=ell,amplitude=amplitude,strength=strength)
    write(folder/'parameters.json',dict(parameters=parameters,calibration='4 prior-predictive energy SDs; one deterministic strength, no sampler-ranking tuning',prior_predictive_energy=energies))
    x=jnp.asarray(rng.normal(size=(16,32)));e=batch(x);key=jax.random.PRNGKey(20261102);beta=.15
    @jax.jit
    def block(x,e,key,beta):
        def step(state,_):
            x,e,key=state;key,kn,ku=jax.random.split(key,3)
            y=jnp.sqrt(1-beta*beta)*x+beta*jax.random.normal(kn,x.shape,dtype=jnp.float64);en=batch(y)
            take=jnp.log(jax.random.uniform(ku,e.shape)) < jnp.minimum(0.,-strength*(en-e))
            x=jnp.where(take[:,None],y,x);e=jnp.where(take,en,e)
            return (x,e,key),(x,take.mean())
        return jax.lax.scan(step,(x,e,key),None,length=50)
    retained=[];accept=[]
    for i in range(50):
        stop();(x,e,key),(states,acc)=block(x,e,key,beta);states=np.asarray(states);a=float(np.asarray(acc).mean());accept.append(a)
        if i<10:beta=float(np.clip(beta*np.exp(a-.3),.005,.8))
        else:retained.append(states[4::10])
        if i%10==0:say(f'Phase prior: {50*(i+1)} coefficient-only pCN steps; acceptance {a:.3f}')
    # [chain,draw,coefficient], preserving chain identities for convergence checks.
    chains=np.concatenate(retained,axis=0).transpose(1,0,2)
    import arviz as az
    rh=[float(az.rhat(chains[:,:,k],method='rank')) for k in range(32)]
    ess=[float(az.ess(chains[:,:,k],method='bulk')) for k in range(32)]
    tail=[float(az.ess(chains[:,:,k],method='tail')) for k in range(32)]
    samples=chains.reshape(-1,32);fields=physics.B@jnp.asarray(samples.T)
    fields=np.asarray(fields).T
    usable=bool(np.isfinite(samples).all() and max(rh)<=1.05 and min(ess)>=200 and min(tail)>=100)
    save_npz(folder/'pool.npz',samples=samples,by_chain=chains)
    result=dict(usable=usable,parameters=parameters,max_rank_rhat=max(rh),min_bulk_ess=min(ess),min_tail_ess=min(tail),mean_acceptance=float(np.mean(accept[10:])),final_beta=beta,draws=len(samples),phase_area_quantiles=np.quantile(np.mean(fields>0,axis=1),[.05,.5,.95]),amplitude_abs_quantiles=np.quantile(abs(fields),[.1,.5,.9]),pool_is_dependent=True,prior_only_PDE_requests=0,prior_energy_requests=32+16+50*50*16,runtime_seconds=time.monotonic()-started,initialization_uses_validated_MCMC_prior_draws=True)
    write(folder/'pool.json',result);return result
