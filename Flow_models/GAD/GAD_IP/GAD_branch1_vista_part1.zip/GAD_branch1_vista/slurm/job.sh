#!/bin/bash
set -eo pipefail
G1_BATCH="${1:?batch directory}"
G1_TARGET="${2:?target}"
G1_STAGE="${3:?stage}"
G1_SECONDS="${4:?walltime seconds}"
source "$G1_BATCH/code/slurm/environment.sh"
export JAX_PLATFORMS=cuda
exec python -u "$G1_BATCH/code/workflow.py" stage --batch "$G1_BATCH" --target "$G1_TARGET" --stage "$G1_STAGE" --seconds "$G1_SECONDS"
