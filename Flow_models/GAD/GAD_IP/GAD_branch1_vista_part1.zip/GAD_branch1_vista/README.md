# GAD application redesign: branch one

One self-contained Vista campaign. No other ZIP, notebook, cached run directory, or code repository is needed. Existing frozen targets and validated original NUTS references are included. No jobs have been submitted while making this package.

## Run from the usual directory

Upload `GAD_branch1_vista.zip` to `/work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/`, then run:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP
unzip GAD_branch1_vista.zip
bash GAD_branch1_vista/run_vista.sh
```

The launcher uses the established `hlsi` environment through `slurm/environment.sh`, creates `batches/gad_branch1_20261102`, freezes a source snapshot there, and starts one detached controller. The controller submits at most **two single-node GH jobs** under **DMS22021**. It reserves each job's complete Slurm walltime before submission, enforcing a **48 allocated GH node-hour ceiling**, including reference work, preprocessing, and evaluation. Queue time consumes no allocation. There are no automatic retries or changes to old jobs/batches.

Keep this package directory intact. Rerunning the command resumes the same controller state; it does not silently reset targets. Use a different explicit batch directory for a new scientific configuration:

```bash
bash GAD_branch1_vista/run_vista.sh /absolute/path/to/new_batch
```

The default environment loads GCC 13.2.0 and Python 3.11.8, then `${SCRATCH}/venvs/hlsi`. Override `GP_VENV_DIR`, `GP_GCC_MODULE`, or `GP_PYTHON_MODULE` only if your existing Vista setup needs it. No installation helper updates that environment automatically. Required packages are listed in `requirements.txt`; JAX must already have a working CUDA backend on GH nodes. PyTorch is unnecessary for this port.

## Check progress

```bash
tail -n 30 batches/gad_branch1_20261102/logs/controller.log
python batches/gad_branch1_20261102/code/workflow.py status \
  --batch batches/gad_branch1_20261102
squeue -u "$USER"
```

Each target has stage status JSON and a separate Slurm log. `capped`, failed, and unresolved-reference cases are explicit outcomes, never sampler wins. A stage can be left incomplete by its time cap; the controller does not consume the remaining allocation on unbounded retries. Completed numerical checkpoints, NUTS chunks, raw pMALA production, bank derivatives, RNG states, and attempted-request journals remain in the batch directory.

After an accidental controller interruption, rerun the launcher from the **same login host** recorded in `controller.host`. Completed stages are preserved. Source/config mismatches fail instead of reusing stale samples.

## What runs

1. **Sixteen initial geometry screens:** three unchanged Gaussian-prior controls, four Gaussian-prior likelihood variants per PDE, and the existing radial-Laplace NS anchor.
2. **Conditional Allen-Cahn prior:** only when all four Gaussian-prior AC screens complete without a geometry candidate, calibrate one phase-field prior from prior-predictive energy variation, validate a coefficient-only pCN prior-draw pool, and screen at most two phase-prior targets. A failed prior pool withholds those targets.
3. **Full comparisons:** three original controls and at most two changed targets per PDE, six changed targets total. Selection uses MAP-Laplace error, posterior curvature variation, and reference geometry, not GAD/pMALA rankings. A short-reference failure can nominate a provisional geometry candidate, but only an adequate full reference permits ranking.
4. **At most two bank checks:** double particle count on leading or stalled completed candidates and extend pMALA to the corresponding E+G+H budgets. The original reference is shared.

Acquisition variants:

| PDE | Designs | Noise |
|---|---|---|
| NS | Both velocity components at 12 or 24 nested, fixed strip locations; original physics and T=10.5 | 5% or 10% of a fixed Gaussian-prior-predictive component RMS |
| Allen-Cahn | 16 signed 4x4-cell patch averages in the left half; T=0.33 or 1.0 | Independent patch-readout SD 0.01 or 0.03 |
| Helmholtz | Sources 0 and 3; 16 left receivers or 32 left-plus-bottom receivers; complex data | Per-real-component SD 0.0004 or 0.0008 |

NS calibration uses 32 fixed prior draws. Data seed and sampler seed are both 42. New likelihoods are frozen once, including indices, standardized-noise pairing, units, truth predictions, and checksums. Coefficient dimensions, archived bases, truths, and PDE parameters are preserved. The Helmholtz boundary matrix is the original damped finite-domain graph-Laplacian model.

## Comparison details

- Both **prior** and **MAP-Laplace** starts for GN-GAD and MAP-Hessian pMALA.
- Five GAD rounds; N=1,000 for NS/AC, N=2,000 for Helmholtz; bank checks double N.
- Four bounded truth-blind MAP starts, exact MAP Hessian, setup cost attributed to every arm that uses it. Prior-start GAD also uses this setup to choose its endpoint, so it is charged.
- A capped optimizer is followed by at most eight charged exact-Newton polishing steps. Cases with an unresolved MAP gradient or saddle curvature are flagged and cannot establish a favorable comparison.
- Stable small-time q-LFGI algebra; exact prior Hessian plus physical, noise-whitened likelihood GN. Negative clean curvature is retained until the actual shifted resolvent guard.
- Endpoint corruption is at most 1% of the narrowest MAP covariance scale, capped at t_min=1e-6. An analytic Gaussian propagation check starts at 300 Heun steps and permits up to two doublings when required. No posterior-mean denoising projection is used.
- Primary work proxy is the actual pointwise E+G+H request total. MAP search, metric construction, initialization, adaptation, all bank rebuilds, and rejected proposals are charged. Attempted-request journals preserve charges across interruptions. NUTS and diagnostic evaluation are outside the sampler work proxy but inside allocated-time limits.
- If the phase prior is used, its coefficient-only MCMC initializer is charged at its actual prior-energy request count to each prior-start arm. Both pMALA starts receive checkpoints at the union of both GAD starts' absolute budgets. CSVs also retain the legacy PDE-only count and initializer cost separately; analytic prior energies and PDE energies need not have equal elapsed cost.
- pMALA has 16 chains, 32 charged warmup transitions, acceptance-only step adaptation, then a frozen exact MH kernel. It starts from prior or independent MAP-Laplace draws. Its summaries use all post-warmup production including rejections. Distribution clouds are stratified across that history.
- Pilot references: 2 chains, 300 warmup, 500 draws, depth 10. Promoted references: 4 chains, 1,000 warmup, 1,000 draws, depth 12, target acceptance 0.95, exact potential and fixed MAP-whitened metric. Original Gaussian controls reuse their independently validated 4x5,000-draw references. New target/prior references are fresh.
- Full-reference thresholds: rank Rhat <=1.01, bulk ESS >=400, tail ESS >=200, zero divergences, depth saturation <=1%, E-BFMI >=0.3. These are exploratory reference checks, not the final paper's longer protocol or a proof of global coverage.

Reference-whitened SW2, coefficient covariance error, physical-field mean/SD errors, and both predeclared QoIs are saved. A split-reference fitted Gaussian is a labeled diagnostic. Expensive QoI distributions use fixed stratified sample caps; cheap field moments use all pMALA production. Reference-versus-reference sample scales are shown; they are not across-seed uncertainty bars.

NS/AC screens compare two representative predictions with half the time step; a change above 0.1 observation-noise SD blocks automatic promotion. This is a temporal-resolution check within the fixed 32x32 discretization, not a spatial convergence study.

QoIs: NS initial enstrophy and final right-half flow energy; AC initial phase area and smoothed interface length; Helmholtz right-half mean contrast and held-out complex-response power. A small pointwise GN-versus-exact Hessian audit covers initial/later banks and reference points. Conditional ESS is reported without treating small-t concentration alone as proof of failure.

## Results

Open `batches/gad_branch1_20261102/report/dashboard.html`. It links the complete CSVs and separate PNG/PDF work curves, common-scale field mean/SD maps, and physical-QoI CDFs. The controller also creates `GAD_branch1_results.zip` in the batch directory. It contains raw clouds/checkpoints and reports; the initial package supplies the frozen source/data needed with it.

Rebuild without sampling:

```bash
python batches/gad_branch1_20261102/code/workflow.py report \
  --batch batches/gad_branch1_20261102
python batches/gad_branch1_20261102/code/workflow.py export \
  --batch batches/gad_branch1_20261102
```

All outcomes remain exploratory single-seed comparisons. The bundle does not assume that a curvature-varying target favors GAD, or that a GAD stall identifies GN error or a population fixed point. The allocation cap can leave part of the sweep unresolved.

## Validation and provenance

`VALIDATION.md` records checks actually performed before delivery. `SOURCE_PROVENANCE.json` identifies the three retrieved source archives and hashes. `provenance/` retains the original model and sampler files; `frozen_manifest.json` authenticates the 21 archived input/reference files. The operational code imports none of the original data-regenerating model modules.

Optional CPU checks in an environment with the requirements installed:

```bash
python GAD_branch1_vista/workflow.py self-test
```
