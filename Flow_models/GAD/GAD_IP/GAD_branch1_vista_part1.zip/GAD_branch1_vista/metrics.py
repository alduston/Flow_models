"""Reference-whitened coefficient metrics and two fixed physical observables."""
import csv
from pathlib import Path
import numpy as np
import jax.numpy as jnp
from scipy.stats import ks_2samp
from io_utils import read,write,npz,save_npz,checked_cloud
from samplers import stratified_indices

def csv_write(path,rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:path.write_text('');return
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def geometry(reference,directions=128,seed=20261102):
    mean=reference.mean(0);cov=np.cov(reference,rowvar=False);e,V=np.linalg.eigh(cov)
    W=(V/np.sqrt(np.maximum(e,max(e.max()*1e-10,1e-14))))@V.T
    dirs=np.random.default_rng(seed).normal(size=(reference.shape[1],directions));dirs/=np.linalg.norm(dirs,axis=0)
    return dict(mean=mean,cov=cov,whitener=W,directions=dirs)

def sliced_w2(x,y,dirs):
    a=np.sort(x@dirs,axis=0);b=np.sort(y@dirs,axis=0)
    edges=np.unique(np.r_[np.arange(len(a)+1)/len(a),np.arange(len(b)+1)/len(b)])
    mid=(edges[1:]+edges[:-1])/2;ia=np.minimum((mid*len(a)).astype(int),len(a)-1);ib=np.minimum((mid*len(b)).astype(int),len(b)-1)
    return float(np.sqrt(np.mean(np.sum((a[ia]-b[ib])**2*np.diff(edges)[:,None],axis=0))))

def cloud_metrics(x,reference,geo,cap=1000):
    W=geo['whitener'];xx=x[stratified_indices(len(x),cap)]
    delta=(x.mean(0)-geo['mean'])@W.T;C=W@np.cov(x,rowvar=False)@W.T
    true=W@geo['cov']@W.T
    return dict(RefSW2=sliced_w2((xx-geo['mean'])@W.T,(reference-geo['mean'])@W.T,geo['directions']),RefMeanWhitenedRMSE=float(np.sqrt(np.mean(delta*delta))),RefCovWhitenedRelFro=float(np.linalg.norm(C-true)/np.linalg.norm(true)),distribution_states=len(xx))

def relative(a,b):return float(np.linalg.norm(a-b)/max(np.linalg.norm(b),1e-15))

def qoi_errors(q,r):
    row={}
    for k in range(2):
        scale=max(np.std(r[:,k],ddof=1),1e-15)
        threshold=np.quantile(r[:,k],.95)
        row.update({f'QoI{k+1}_CDF_error':float(ks_2samp(q[:,k],r[:,k]).statistic),f'QoI{k+1}_mean_SD_error':float(abs(q[:,k].mean()-r[:,k].mean())/scale),f'QoI{k+1}_q95_reference':float(threshold),f'QoI{k+1}_upper_tail_probability':float(np.mean(q[:,k]>threshold))})
    return row

def moment_gaussian(reference,n,seed):
    mean=reference.mean(0);e,V=np.linalg.eigh(np.cov(reference,rowvar=False))
    return mean+np.random.default_rng(seed).normal(size=(n,reference.shape[1]))@(V*np.sqrt(np.maximum(e,0))).T

def matched_comparisons(rows,rounds):
    final=[r for r in rows if r['method']=='GAD' and int(r['round'])==rounds and str(r.get('comparison_usable',r['reference_usable']))=='True']
    pm=[r for r in rows if r['method']=='pMALA' and str(r.get('comparison_usable',r['reference_usable']))=='True']
    results=[]
    for g in final:
        work=float(g['work'])
        matched=[r for r in pm if 0<=work-float(r['work'])<=2*int(r.get('chains') or 16)]
        if not matched:continue
        best=min(matched,key=lambda r:float(r['RefSW2']))
        results.append(dict(target=g['target'],GAD_initialization=g['initialization'],GAD_work=work,GAD_SW2=float(g['RefSW2']),pMALA_initialization=best['initialization'],pMALA_work=float(best['work']),pMALA_SW2=float(best['RefSW2']),ratio=float(g['RefSW2'])/max(float(best['RefSW2']),1e-15),single_seed_candidate_only=True))
    return results

def evaluate(backend,config,folder,reference_folder,setup,setup_info,binding,stop):
    cfg=config['evaluation'];refdata=npz(reference_folder/'samples.npz');ref=refdata['samples'];quality=read(reference_folder/'quality.json')
    geo=geometry(ref,cfg['sliced_directions'],cfg['seed']);save_npz(folder/'reference_geometry.npz',**geo)
    numerical=read(folder/'numerical_control.json')
    endpoint_ratio=float(np.expm1(2*numerical['t_min'])/np.linalg.eigvalsh(geo['cov']).min())
    comparison_usable=bool(quality['reference_usable'] and setup_info.get('map_usable',False) and endpoint_ratio<=.02)
    qdir=folder/'evaluation';qdir.mkdir(exist_ok=True)
    qfile=qdir/'reference.npz'
    if qfile.exists():cached=npz(qfile);rq=cached['qoi'];rfield=cached['field_mean'];rstd=cached['field_std']
    else:
        rf=backend.fields(ref);rfield=rf.mean(0);rstd=rf.std(0,ddof=1)
        rq=backend.qoi(ref[stratified_indices(len(ref),cfg['qoi_draws'])],stop)
        save_npz(qfile,qoi=rq,field_mean=rfield,field_std=rstd)
    candidates=[]
    for initial in ['prior','laplace']:
        for method in ['gad','pmala']:
            paths=[folder/f'{method}_{initial}'/f'round{r}' for r in range(1,config['gad']['rounds']+1)] if method=='gad' else sorted((folder/f'{method}_{initial}').glob('budget*'))
            for path in paths:
                if (path/'samples.npz').exists() and (path/'sampling.json').exists():
                    rec=read(path/'sampling.json');arr=npz(path/'samples.npz')
                    candidates.append((f'{method}_{initial}_{path.name}',arr.get('production',arr['samples']),rec))
    n=config['gad']['particles'][backend.spec['problem']]
    lap=setup['center']+np.random.default_rng(41042).normal(size=(n,backend.dim))@setup['factor'].T
    candidates.append(('MAP-Laplace',lap,dict(method='MAP-Laplace',initialization='laplace',round=0,pde_solve_count=setup_info['pde_solve_count'],runtime_seconds=setup_info.get('runtime_seconds',0))))
    # Cross-fit on chain groups, then evaluate on the held-out group; swap too.
    by=refdata.get('samples_by_chain')
    if by is not None and len(by)>=2:
        for i in range(2):
            fit=by[i::2].reshape(-1,backend.dim);test=by[1-i::2].reshape(-1,backend.dim)
            x=moment_gaussian(fit,n,cfg['seed']+78+i)
            candidates.append((f'Cross-fit Gaussian {i+1}',x,dict(method='Cross-fit Gaussian',initialization='reference diagnostic',round=0,pde_solve_count=0,runtime_seconds=0,diagnostic_only=True,heldout_reference=test)))
    rows=[];floor=[];rng=np.random.default_rng(cfg['seed']+83)
    cap=min(cfg['distribution_cap'],n,len(ref)//2)
    for _ in range(cfg['floor_replicates']):
        ii=rng.choice(len(ref),2*cap,replace=False)
        floor.append(sliced_w2((ref[ii[:cap]]-geo['mean'])@geo['whitener'].T,(ref[ii[cap:]]-geo['mean'])@geo['whitener'].T,geo['directions']))
    floor_mean=float(np.mean(floor));write(folder/'sampling_floor.json',dict(sw2=floor,mean=floor_mean,n=cap,definition='equal-size disjoint reference subclouds; a sampling scale, not independent chain uncertainty'))
    for label,x,record in candidates:
        stop();meta=qdir/(label.replace(' ','_')+'.json')
        if meta.exists():
            row=read(meta)
            if row['binding']!=binding:raise ValueError('Evaluation binding changed')
            rows.append(row);csv_write(folder/'metrics.csv',rows);continue
        checked_cloud(x,d=backend.dim); rr=record.get('heldout_reference',ref)
        g=geometry(rr,cfg['sliced_directions'],cfg['seed']) if record.get('diagnostic_only') else geo
        row=cloud_metrics(x,rr,g,cfg['distribution_cap'])
        f=backend.fields(x);mean=f.mean(0);std=f.std(0,ddof=1)
        q=backend.qoi(x[stratified_indices(len(x),cfg['qoi_draws'])],stop)
        rq_use=backend.qoi(rr[stratified_indices(len(rr),cfg['qoi_draws'])],stop) if record.get('diagnostic_only') else rq
        row.update(qoi_errors(q,rq_use))
        row.update(binding=binding,target=backend.spec['id'],problem=backend.spec['problem'],label=label,method=record['method'],initialization=record['initialization'],round=record['round'],work=record['pde_solve_count'],runtime_seconds=record['runtime_seconds'],prior_initialization_energy_requests=record.get('prior_initialization_energy_requests',0),chains=record.get('chains'),reference_usable=quality['reference_usable'],single_sampler_seed=True,RefFieldMeanRelL2=relative(mean,rfield),RefFieldStdRelL2=relative(std,rstd),field_SD_amplitude_ratio=float(np.linalg.norm(std)/max(np.linalg.norm(rstd),1e-15)),field_SD_scale_adjusted_error=relative(std*(std@rstd/max(std@std,1e-30)),rstd),production_states=len(x),qoi_evaluation_states=len(q),sampling_floor_SW2=floor_mean,diagnostic_only=record.get('diagnostic_only',False),guard_fraction=record.get('guard_fraction'),acceptance_rate=record.get('acceptance_rate'))
        row.update(map_usable=setup_info.get('map_usable',False),comparison_usable=comparison_usable,endpoint_reference_variance_ratio=endpoint_ratio)
        truth=np.asarray(backend.physics.physical['truth']).ravel()
        prediction=np.asarray(backend.physics.observe(jnp.asarray(x.mean(0)),backend.design))
        row.update(PosteriorMeanFieldRMSE=float(np.sqrt(np.mean((mean-truth)**2))),FwdRelErr=relative(prediction,backend.data['y_clean']),legacy_PDE_work=record['pde_solve_count']-record.get('prior_initialization_energy_requests',0))
        save_npz(qdir/(label.replace(' ','_')+'.npz'),qoi=q,field_mean=mean,field_std=std);write(meta,row);rows.append(row);csv_write(folder/'metrics.csv',rows)
    csv_write(folder/'metrics.csv',rows)
    write(folder/'evaluation.json',dict(binding=binding,reference_usable=quality['reference_usable'],metrics=rows,qoi_definition='NS: initial enstrophy/final right-half flow energy; AC: initial phase area/smoothed interface length; Helmholtz: right-half mean contrast/held-out complex response power. Expensive QoIs use fixed stratified caps, field moments use all production states.'))
    return rows
