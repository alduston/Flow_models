"""Budgeted MAP-pMALA, CDS and DiGS. NumPy controller; exact target callbacks.

The CDS and DiGS transition algebra is adapted from the archived toy sources
in provenance/. PDE output uses dependent terminal windows, like the existing
SLIPS/MALA campaign. Every method is restarted separately at each GAD cap.
"""
from collections import deque
import math
import time
import numpy as np
import json
from pathlib import Path


class BudgetExceeded(RuntimeError):
    pass


class CountedTarget:
    """Pointwise E/G/H requests, including rejected proposals and MAP search.

    The callback returns a joint log density and score, so each point costs
    E=1 and G=1. An exact Hessian request costs H=1 under the saved PDE proxy.
    No timing, reference sample, truth, or evaluation metric enters this API.
    """
    def __init__(self, dim, joint, hessian=None, cap=math.inf):
        self.dim, self.joint, self.hessian_callback = dim, joint, hessian
        self.cap, self.phase = cap, 'initialization'
        self.counts = dict(energy=0, gradient=0, hessian=0)
        self.by_phase = {}
        self.journal = None

    def attach_journal(self, path, base_counts=None, base_ledger=None):
        """Charge attempted requests durably, including work lost between checkpoints."""
        self.journal = Path(path)
        self.journal.parent.mkdir(parents=True, exist_ok=True)
        self.counts = dict(base_counts or dict(energy=0, gradient=0, hessian=0))
        self.by_phase = {k:dict(v) for k,v in (base_ledger or {}).items()}
        if self.journal.exists():
            for line in self.journal.read_text().splitlines():
                row = json.loads(line)  # A damaged ledger fails closed; it is never discarded.
                phase = self.by_phase.setdefault(row['phase'], dict(energy=0,gradient=0,hessian=0))
                for k,v in row['counts'].items(): self.counts[k]+=v; phase[k]+=v

    @property
    def spent(self):
        return sum(self.counts.values())

    def charge(self, **counts):
        if self.spent + sum(counts.values()) > self.cap:
            raise BudgetExceeded(f'{self.phase}: request would exceed {self.cap}')
        if self.journal is not None:
            with self.journal.open('a') as handle:
                handle.write(json.dumps(dict(phase=self.phase, counts={k:int(v) for k,v in counts.items()}))+'\n')
        phase = self.by_phase.setdefault(self.phase, dict(energy=0, gradient=0, hessian=0))
        for key, value in counts.items():
            self.counts[key] += int(value)
            phase[key] += int(value)

    def loggrad_latent(self, x):
        x = np.asarray(x, dtype=np.float64)
        if x.ndim != 2 or x.shape[1] != self.dim:
            raise ValueError('Expected [point, dimension] target query')
        self.charge(energy=len(x), gradient=len(x))
        lp, score = (np.asarray(a, dtype=np.float64) for a in self.joint(x))
        if lp.shape != (len(x),) or score.shape != x.shape:
            raise ValueError('Inconsistent exact-target callback shapes')
        return lp, score

    def hessian(self, x):
        if self.hessian_callback is None:
            raise ValueError('An exact posterior Hessian callback is required')
        self.charge(hessian=1)
        value = np.asarray(self.hessian_callback(np.asarray(x)), dtype=np.float64)
        if value.shape != (self.dim, self.dim) or not np.isfinite(value).all():
            raise ValueError('Invalid exact posterior energy Hessian')
        return .5 * (value + value.T)

    def record(self):
        return dict(oracle_counts=dict(self.counts), work_ledger=self.by_phase,
                    pde_likelihood_evals=self.counts['energy'],
                    pde_score_evals=self.counts['gradient'],
                    pde_gn_hessian_evals=self.counts['hessian'],
                    pde_solve_count=self.spent, work_cap=self.cap,
                    budget_fraction=self.spent/self.cap,
                    accounting='pointwise E + G + H; same saved GAD/MALA/SLIPS proxy')


def probabilities(logratio):
    finite = np.isfinite(logratio)
    clipped = np.where(finite, np.minimum(logratio, 0.), -np.inf)
    return clipped, np.exp(clipped)


def mala_step(x, lp, score, callback, h, rng, temperature=1.):
    """MH with arbitrary supplied drift score; forward/reverse terms explicit."""
    proposal = x + h*score + np.sqrt(2*h*temperature)*rng.normal(size=x.shape)
    lq, sq = callback(proposal)
    forward = proposal-x-h*score
    reverse = x-proposal-h*sq
    ratio = lq-lp + (np.sum(forward**2, axis=1)-np.sum(reverse**2, axis=1))/(4*h*temperature)
    valid = np.isfinite(lq) & np.isfinite(sq).all(1)
    clipped, prob = probabilities(np.where(valid, ratio, -np.inf))
    accepted = np.log(rng.random(len(x))) < clipped
    output = (np.where(accepted[:, None], proposal, x),
              np.where(accepted, lq, lp), np.where(accepted[:, None], sq, score))
    distance = np.linalg.norm(proposal-x, axis=1)
    secants = np.linalg.norm(sq-score, axis=1)/np.maximum(distance, 1e-300)
    secants = secants[np.isfinite(secants) & (secants > 0)]
    return (*output, dict(accepted=int(accepted.sum()), probability=float(prob.mean()),
                         secant=float(secants.max()) if len(secants) else 0.))


class GuardedStep:
    """Acceptance-only short warmup, followed by a frozen production step."""
    def __init__(self, h, score, max_h=1.):
        self.maximum, self.minimum = max_h, 1e-16
        norm = float(np.linalg.norm(score, axis=1).max())
        self.h = max(self.minimum, min(h, max_h, .25*math.sqrt(score.shape[1])/max(norm, 1e-300)))
        self.secant_cap, self.last_good, self.iterations = max_h, None, 0

    def update(self, info, tested_h=None):
        self.iterations += 1
        h = self.h if tested_h is None else tested_h
        if info['secant'] > 0:
            self.secant_cap = min(self.secant_cap, .5/info['secant'])
        p = info['probability']
        if p >= .1 and info['accepted']:
            self.last_good = h
        proposal = h*.1 if p < .05 else h*math.exp(min(1., math.sqrt(5/self.iterations))*(p-.574))
        self.h = max(self.minimum, min(proposal, self.maximum, self.secant_cap))

    def freeze(self):
        if self.last_good is not None:
            self.h = min(self.h, self.last_good)
        self.h = max(self.minimum, min(self.h, self.secant_cap))
        return self.h

