"""Geometry-led selection, independent of comparative sampler outcomes."""
from pathlib import Path
import numpy as np
import jax.numpy as jnp
from io_utils import read,write,npz,save_npz,say
from metrics import geometry,cloud_metrics,moment_gaussian,qoi_errors
from samplers import stratified_indices,numerical_settings

def audit(backend,config,setup,folder,reference_folder,binding,stop):
    meta=folder/'screen.json'
    if meta.exists():
        result=read(meta)
        if result['binding']!=binding:raise ValueError('Screen binding changed')
        return result
    reference=npz(reference_folder/'samples.npz')['samples'];quality=read(reference_folder/'quality.json')
    cfg=config['screen'];evcfg=config['evaluation'];geo=geometry(reference,evcfg['sliced_directions'],evcfg['seed'])
    n=min(1000,len(reference));rng=np.random.default_rng(8801)
    lap=setup['center']+rng.normal(size=(n,backend.dim))@setup['factor'].T
    moment=moment_gaussian(reference[:len(reference)//2],n,8802)
    lm=cloud_metrics(lap,reference,geo,n);gm=cloud_metrics(moment,reference[len(reference)//2:],geo,n)
    rq=backend.qoi(reference[stratified_indices(len(reference),128)],stop)
    lq=backend.qoi(lap[stratified_indices(len(lap),128)],stop)
    lqerr=qoi_errors(lq,rq)
    J=backend.jacobian(setup['center']);A=J.T@J;ev,V=np.linalg.eigh(A)
    vals=ev[::-1];gaps=(vals[:-1]+1)/(vals[1:]+1)
    # Choose rank once at MAP from a resolved spectral gap, then hold it fixed.
    best=int(np.argmax(gaps))+1;resolved=bool(gaps[best-1]>=2 and vals[best-1]>1)
    rank=best if resolved else max(1,min(backend.dim-1,int(np.sum(vals>10))))
    MAP_G=backend.gn(setup['center'][None])[0];_,Umap=np.linalg.eigh(MAP_G)
    P=Umap[:,-rank:]@Umap[:,-rank:].T
    L=setup['factor'];base=L.T@MAP_G@L
    rotation=[];variation=[];curvature=[]
    for x in reference[stratified_indices(len(reference),cfg['curvature_draws'])]:
        stop();H=backend.gn(x[None])[0];e,U=np.linalg.eigh(H)
        Q=U[:,-rank:]@U[:,-rank:].T
        rotation.append(np.linalg.norm(P-Q,'fro')/np.sqrt(2*rank))
        K=L.T@H@L;variation.append(np.linalg.norm(K-base,'fro')/max(np.linalg.norm(base,'fro'),1e-15))
        curvature.append([float(e.min()),float(e.max())])
    profile=[]
    for k in [0,1]:
        for distance in [-2.,-1.,-.25,.25,1.,2.]:
            stop();x=setup['center']+distance*L[:,k];lp,_=backend.joint(x[None])
            profile.append(dict(direction=k,MAP_SD_distance=distance,energy=float(-lp[0])))
    # A split-reference floor on the exact same sample count.
    white=(reference-geo['mean'])@geo['whitener'].T
    from metrics import sliced_w2
    half=len(reference)//2;floor=sliced_w2(white[:half],white[half:2*half],geo['directions'])
    ratio=lm['RefSW2']/max(floor,1e-12);qerr=max(lqerr['QoI1_CDF_error'],lqerr['QoI2_CDF_error'])
    nong=bool(ratio>=cfg['minimum_laplace_sw2_ratio'] or qerr>=cfg['minimum_qoi_cdf_error'])
    hetero=bool(np.median(variation)>.1 or (resolved and np.median(rotation)>=cfg['minimum_rotation']))
    numerical,control=numerical_settings(setup,config['gad'])
    gapscore=float(np.median(rotation)) if resolved else 0.
    score=float(np.log1p(max(ratio-1,0))+qerr+gapscore+np.log1p(np.median(variation)))
    map_quality=read(folder/'map/setup.json').get('map_usable',False)
    time_errors=[]
    if backend.spec['problem']!='helmholtz':
        from models import Physics
        fine=Physics(backend.spec['problem'],backend.spec.get('obs_time',.33),dt_scale=.5)
        for x in [setup['center'],reference[len(reference)//2]]:
            stop();coarse=np.asarray(backend.physics.observe(jnp.asarray(x),backend.design));refined=np.asarray(fine.observe(jnp.asarray(x),backend.design))
            time_errors.append(float(np.sqrt(np.mean(((coarse-refined)/backend.data['sigma'])**2))))
    result=dict(binding=binding,target=backend.spec['id'],problem=backend.spec['problem'],prior=backend.spec['prior'],control=backend.spec.get('control',False),reference_usable=quality['reference_usable'],map_usable=map_quality,half_timestep_RMS_change_in_noise_units=time_errors,geometry_candidate=bool(nong and hetero and vals[0]>1 and map_quality and (not time_errors or max(time_errors)<=.1)),rank=rank,resolved_MAP_spectral_gap=resolved,MAP_spectral_gap=float(gaps[best-1]),median_stiff_projector_rotation=float(np.median(rotation)),median_MAP_metric_curvature_change=float(np.median(variation)),curvature_eigenvalue_range=curvature,laplace_metrics=lm,crossfit_gaussian_metrics=gm,laplace_qoi_errors=lqerr,reference_split_SW2=floor,laplace_to_split_floor_ratio=ratio,geometry_score=score,profiles=profile,gaussian_control=control,selection_uses_sampler_rankings=False,notes='Short references make this a screening decision. Unresolved spectral gaps are reported and do not count as projector evidence. Low conditional ESS alone is not a proof of failed transport.')
    write(meta,result);return result

def select(config,run):
    run=Path(run);records=[]
    for spec in config['targets']:
        file=run/'targets'/spec['id']/'screen.json'
        if file.exists(): records.append(read(file))
    selected=[];why={}
    for problem in ['navier_stokes','allen_cahn','helmholtz']:
        eligible=[r for r in records if r['problem']==problem and not r['control'] and r['geometry_candidate']]
        eligible.sort(key=lambda r:(r['reference_usable'],r['geometry_score']),reverse=True)
        for row in eligible[:config['limits']['max_per_pde']]:
            selected.append(row['target']);why[row['target']]='geometry candidate; '+('screen reference passed' if row['reference_usable'] else 'provisional: full reference must resolve screening uncertainty')
    selected=selected[:config['limits']['max_changed_full']]
    result=dict(targets=selected,reasons=why,controls=[s['id'] for s in config['targets'] if s.get('control')],records=records,selection_uses_sampler_rankings=False)
    write(run/'selection.json',result);return result

def curvature_audit(backend,folder,setup,config,stop):
    file=folder/'curvature_audit.json'
    if file.exists():return
    ref=npz(folder/'reference/samples.npz')['samples'];points=[]
    for label,path,key in [('initial',folder/'gad_prior/round1/bank.npz','x'),('later',folder/f'gad_prior/round{config["gad"]["rounds"]}/bank.npz','x')]:
        if path.exists():points.extend((label,x) for x in npz(path)[key][stratified_indices(len(npz(path)[key]),4)])
    points.extend(('reference',x) for x in ref[stratified_indices(len(ref),4)])
    records=[]
    for label,x in points:
        stop();H=backend.hessian(x);G=backend.gn(x[None])[0];R=H-G
        for t in [.01,.3,1.]:
            a=np.exp(-t);g=-np.expm1(-2*t);A=a*a*np.eye(backend.dim)+g*G
            e,V=np.linalg.eigh(A);floor=max(config['gad']['gate_min_eval'],a*a/config['gad']['gate_max_gain']);W=(V/np.sqrt(np.maximum(e,floor)))@V.T
            records.append(dict(region=label,t=t,solve_scaled_residual_Hessian_norm=float(np.linalg.norm(g*W@R@W,2)),natural_A_min=float(e.min()),guarded_eigenvalues=int(np.sum(e<floor))))
    write(file,dict(records=records,definition='Pointwise guarded-solve-scale GN discrepancy, not an exact conditional-average error or convergence certificate.'))
