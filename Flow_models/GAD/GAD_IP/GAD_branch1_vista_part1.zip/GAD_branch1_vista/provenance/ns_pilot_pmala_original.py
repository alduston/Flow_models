"""Original MAP-pMALA transition/controller; cumulative work checkpoints.

One independent zero-start MAP and exact Hessian are charged to pMALA. Laplace
shares the numerical setup for efficiency but is separately charged the same
setup cost in the report. No GAD bank or reference geometry initializes pMALA.
"""
from collections import deque
import math
import json
import time
import numpy as np
from io_utils import read,write,npz,save_npz,checked_cloud
from vendor.sampler_core import CountedTarget,find_map,mala_step,GuardedStep

def setup_map(backend,cfg,rng):
    n=backend.dim;target=CountedTarget(n,backend.joint,backend.hessian,float('inf'))
    center,info=find_map(target,cfg['map_max_calls'])
    target.phase='map_exact_hessian';H=target.hessian(center)
    e,V=np.linalg.eigh(H);floor=max(cfg['hessian_floor'],np.max(np.abs(e))/cfg['max_condition'])
    reg=np.maximum(e,floor);L=V/np.sqrt(reg)
    info.update(target.record(),hessian_min_raw=float(e.min()),hessian_max_raw=float(e.max()),
                hessian_regularization_floor=float(floor),hessian_clipped_eigenvalues=int(np.sum(e<floor)))
    return dict(center=center,factor=L,hessian=H),info

def run(backend,config,directory,binding,progress,stop):
    cfg=config['pmala'];n=config['gad']['particles'];d=backend.dim;rounds=config['gad']['rounds']
    gd=directory.parent/'gad/initial_setup.json'
    gad_setup_work=sum(read(gd)['oracle_counts'].values()) if config['gad']['initial_bank']=='laplace' and gd.exists() else 0
    caps=[gad_setup_work+3*n*r for r in range(1,rounds+1)];directory.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(config['sampler_seed']+40000)
    setupfile=directory/'setup.npz';setupjson=directory/'setup.json'
    if setupfile.exists() and setupjson.exists():
        info=read(setupjson)
        if info['binding']!=binding:raise ValueError('pMALA setup binding changed')
        setup=npz(setupfile)
    else:
        progress('pMALA: charged zero-start MAP and exact Hessian')
        setup,info=setup_map(backend,cfg,rng);info['binding']=binding
        save_npz(setupfile,**setup);write(setupjson,info)
    center,L=setup['center'],setup['factor'];chains=min(cfg['chains'],n)
    draws=math.ceil(n/chains);warmup=cfg['warmup']
    target=CountedTarget(d,backend.joint,backend.hessian,caps[-1])
    target.counts=dict(info['oracle_counts']);target.by_phase=dict(info['work_ledger'])
    if target.spent>=caps[-1]:raise ValueError('MAP setup consumes entire pMALA budget')
    def callback(z):
        lp,s=target.loggrad_latent(center+z@L.T)
        return lp,s@L
    statefile=directory/'state.npz'
    if statefile.exists():
        state=npz(statefile);st=json.loads(str(state['metadata_json']))
        if st['binding']!=binding:raise ValueError('pMALA state binding changed')
        z,lp,s=state['z'],state['lp'],state['score']
        window=deque(list(state['window']),maxlen=draws)
        target.counts=st['oracle_counts'];target.by_phase=st['work_ledger'];rng.bit_generator.state=st['rng_state']
        transition=st['transition'];accepted=st['accepted'];production=st['production'];adapter=GuardedStep(st['h'],s)
        adapter.__dict__.update(st['adapter'])
    else:
        z=np.zeros((chains,d));target.phase='pmala_initialization';lp,s=callback(z)
        if not np.isfinite(lp).all() or not np.isfinite(s).all():raise FloatingPointError('Nonfinite pMALA initializer')
        window=deque(maxlen=draws);transition=accepted=production=0;adapter=GuardedStep(cfg['dt'],s)
    records={}
    for r,cap in enumerate(caps,1):
        path=directory/f'budget{r}';path.mkdir(exist_ok=True)
        if target.spent>cap and (path/'sampling.json').exists():
            records[f'pMALA-{r}']=read(path/'sampling.json')
            continue
        while target.spent+2*chains<=cap:
            stop();target.phase='pmala_warmup' if transition<warmup else 'pmala_sampling'
            z,lp,s,step=mala_step(z,lp,s,callback,adapter.h,rng)
            if transition<warmup:
                adapter.update(step)
                if transition+1==warmup:adapter.freeze()
            else:
                window.append(z.copy());accepted+=step['accepted'];production+=chains
            transition+=1
            if transition%25==0:progress(f'pMALA: transition {transition}, work {target.spent}/{caps[-1]}')
        if target.spent<=cap:
            record=dict(binding=binding,method=f'pMALA-{r}',round=r,**target.record(),matched_work_cap=cap,
                setup_work=sum(info['oracle_counts'].values()),transitions=transition,warmup=warmup,
                gad_initializer_work_in_cap=gad_setup_work,
                map_success=info['map_success'],map_gradient_norm=info['map_gradient_norm'],
                hessian_clipped_eigenvalues=info['hessian_clipped_eigenvalues'],
                chains=chains,acceptance_rate=accepted/max(1,production),final_dt=adapter.h,
                initialization='all chains at independently optimized MAP; no reference geometry',
                output='trailing pooled post-warmup states, including rejections; dependent')
            if len(window)*chains>=n:
                cloud=center+np.stack(window).reshape(-1,d)[:n]@L.T;checked_cloud(cloud,n,d)
                save_npz(path/'samples.npz',samples=cloud)
                record.update(state='complete',unique_fraction=len(np.unique(cloud,axis=0))/n)
            else:
                record.update(state='insufficient_output_budget',retained_states=len(window)*chains)
            write(path/'sampling.json',record);records[f'pMALA-{r}']=record
        else:
            write(path/'sampling.json',dict(binding=binding,state='setup_exceeds_checkpoint',matched_work_cap=cap))
        from io_utils import clean
        state_meta=dict(binding=binding,transition=transition,accepted=accepted,production=production,
                        h=adapter.h,adapter=adapter.__dict__,rng_state=rng.bit_generator.state,**target.record())
        save_npz(statefile,z=z,lp=lp,score=s,window=np.asarray(list(window)).reshape(-1,chains,d),
                 metadata_json=np.asarray(json.dumps(clean(state_meta))))
    # Independent Laplace draws; setup is charged to this comparator as well.
    laplace=center+np.random.default_rng(config['sampler_seed']+41000).normal(size=(n,d))@L.T
    save_npz(directory/'laplace.npz',samples=checked_cloud(laplace,n,d))
    write(directory/'laplace.json',dict(binding=binding,method='Laplace',pde_solve_count=sum(info['oracle_counts'].values()),
         oracle_counts=info['oracle_counts'],setup_numerically_shared_with_pmala=True,
         setup_charged_to_each_method=True,**{k:v for k,v in info.items() if k.startswith('map_') or k.startswith('hessian_')}))
    return setup,records
