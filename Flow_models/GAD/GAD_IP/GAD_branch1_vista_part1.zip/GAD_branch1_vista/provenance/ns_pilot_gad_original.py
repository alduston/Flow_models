"""Unweighted q-LFGI GAD with the original stochastic reverse-OU Heun update.

Negative clean curvature is retained. Only eigenvalues of A=alpha^2 I+gamma
E_q[H_GN] are guarded, along with an explicit maximum gate gain. Target queries
are confined to the reference bank. All flow evaluations reuse that bank.
"""
import math
import time
import numpy as np
import jax
import jax.numpy as jnp
from io_utils import ROOT,read,write,npz,save_npz,checked_cloud,Stopped
from priors import sample

def score_batch(y,t,x,s,H,gate_min_eval=1e-3,gate_max_gain=2.):
    a=jnp.exp(-t);g=-jnp.expm1(-2*t)
    # Quadratic distance calculation avoids a [query,bank,dimension] tensor.
    d2=jnp.maximum(jnp.sum(y*y,1)[:,None]+a*a*jnp.sum(x*x,1)[None,:]-2*a*(y@x.T),0)
    w=jax.nn.softmax(-.5*d2/g,axis=1)
    mx=w@x;ms=w@s
    h=(w@H.reshape((len(x),-1))).reshape((len(y),y.shape[1],y.shape[1]))
    h=.5*(h+jnp.swapaxes(h,-1,-2))
    ev,V=jnp.linalg.eigh(h)
    natural=a*a+g*ev
    floor=jnp.maximum(gate_min_eval,a*a/gate_max_gain)
    den=jnp.maximum(natural,floor)
    # This is exactly b+G(c-b), expressed without the cancelling 1/g terms.
    precision=jnp.where(natural<floor,(den-a*a)/g,ev)
    r=a*mx-y
    vr=jnp.einsum('bij,bi->bj',V,r);vs=jnp.einsum('bij,bi->bj',V,ms)
    result=jnp.einsum('bij,bj->bi',V,(precision*vr+a*vs)/den)
    ess=1/jnp.sum(w*w,1)
    stats=jnp.stack([jnp.sum(natural<floor),jnp.asarray(natural.size),jnp.min(natural),
                     jnp.max(a*a/den),jnp.sum(ess),jnp.min(ess),jnp.asarray(len(y))])
    return result,stats

def combine_stats(stats):
    return jnp.array([stats[:,0].sum(),stats[:,1].sum(),stats[:,2].min(),stats[:,3].max(),
                      stats[:,4].sum(),stats[:,5].min(),stats[:,6].sum()])

def make_integrator(x,s,H,cfg):
    x,s,H=(jnp.asarray(z,dtype=jnp.float64) for z in [x,s,H])
    batch=cfg['flow_batch'];minimum=cfg['gate_min_eval'];gain=cfg['gate_max_gain']
    def field(y,t):
        n=len(y);pad=(-n)%batch
        padded=jnp.pad(y,((0,pad),(0,0)),mode='edge').reshape((-1,batch,y.shape[1]))
        # Padding is only cached score arithmetic, never a target request.
        def chunk(z):return score_batch(z,t,x,s,H,minimum,gain)
        ys,st=jax.lax.map(chunk,padded)
        return ys.reshape((-1,y.shape[1]))[:n],combine_stats(st)
    def step(carry,times):
        y,key=carry;t,tn=times;h=t-tn
        key,noise_key=jax.random.split(key)
        noise=jax.random.normal(noise_key,y.shape,dtype=jnp.float64)
        sc,st=field(y,t);drift=y+2*sc
        predictor=y+h*drift+jnp.sqrt(2*h)*noise
        sn,stn=field(predictor,tn)
        y=y+.5*h*(drift+predictor+2*sn)+jnp.sqrt(2*h)*noise
        return (y,key),combine_stats(jnp.stack([st,stn]))
    @jax.jit
    def integrate(y,key,times):
        (y,key),stats=jax.lax.scan(step,(y,key),times)
        return y,key,combine_stats(stats)
    return integrate

def run(backend,spec,config,directory,binding,progress,stop):
    from vendor.sampler_core import CountedTarget
    cfg=config['gad'];n=cfg['particles'];d=backend.dim;directory.mkdir(parents=True,exist_ok=True)
    setup_work=0;initial_setup=None
    if cfg['initial_bank']=='laplace':
        from pmala import setup_map
        sf=directory/'initial_setup.npz';sj=directory/'initial_setup.json'
        if sf.exists() and sj.exists():
            si=read(sj)
            if si['binding']!=binding:raise ValueError('GAD initializer binding changed')
            initial_setup=npz(sf)
        else:
            stop();progress('GAD: charged independent zero-start MAP/Laplace initializer')
            initial_setup,si=setup_map(backend,config['pmala'],np.random.default_rng(config['sampler_seed']+700))
            si['binding']=binding;save_npz(sf,**initial_setup);write(sj,si)
        setup_work=sum(si['oracle_counts'].values())
    elif cfg['initial_bank']!='prior':raise ValueError('Unknown first GAD bank')
    target=CountedTarget(d,backend.joint,backend.hessian,setup_work+3*n*cfg['rounds'])
    if initial_setup is not None:
        target.counts=dict(si['oracle_counts']);target.by_phase={'gad_initializer_'+k:v for k,v in si['work_ledger'].items()}
    previous=None;times=np.geomspace(cfg['t_max'],cfg['t_min'],cfg['steps']+1)
    if not 0<cfg['t_min']<cfg['t_max']:raise ValueError('Invalid endpoint')
    info={};started=time.monotonic()
    for r in range(1,cfg['rounds']+1):
        path=directory/f'round{r}';path.mkdir(exist_ok=True)
        if (path/'sampling.json').exists():
            rec=read(path/'sampling.json')
            if rec['binding']!=binding:raise ValueError('GAD target/config changed')
            previous=checked_cloud(npz(path/'samples.npz')['samples'],n,d)
            target.counts=rec['oracle_counts'];target.by_phase=rec['work_ledger'];info[f'GAD-{r}']=rec
            continue
        progress(f'GAD round {r}/{cfg["rounds"]}: bank derivatives')
        bankfile=path/'bank.npz';bankinfo=path/'bank.json'
        if bankfile.exists() and bankinfo.exists():
            rec=read(bankinfo)
            if rec['binding']!=binding:raise ValueError('GAD bank binding changed')
            bank=npz(bankfile);target.counts=rec['oracle_counts'];target.by_phase=rec['work_ledger']
        else:
            if r==1:
                rng=np.random.default_rng(config['sampler_seed']+701)
                x=initial_setup['center']+rng.normal(size=(n,d))@initial_setup['factor'].T if initial_setup is not None else sample(spec,n,d,rng)
            else:x=previous
            target.phase=f'GAD-{r}_bank_value_gradient'
            lp,s=target.loggrad_latent(x)
            if not np.isfinite(lp).all() or not np.isfinite(s).all():raise FloatingPointError('Nonfinite bank target query')
            target.phase=f'GAD-{r}_bank_GN'
            hs=[]
            for i in range(0,n,cfg['hessian_batch']):
                stop();xx=x[i:i+cfg['hessian_batch']];target.charge(hessian=len(xx));hs.append(backend.gn(xx))
                if i%100==0:progress(f'GAD round {r}/{cfg["rounds"]}: curvature {i+len(xx)}/{n}')
            H=np.concatenate(hs)
            if not np.isfinite(H).all():raise FloatingPointError('Nonfinite full prior + likelihood GN curvature')
            ev=np.linalg.eigvalsh(H)
            bank=dict(x=x,s=s,H=H)
            save_npz(bankfile,**bank)
            write(bankinfo,dict(binding=binding,negative_clean_eigenvalue_fraction=float(np.mean(ev<0)),
                min_clean_eigenvalue=float(ev.min()),max_clean_eigenvalue=float(ev.max()),**target.record()))
        integrate=make_integrator(bank['x'],bank['s'],bank['H'],cfg)
        cp=path/'transport.npz'
        if cp.exists():
            state=npz(cp)
            if str(state['binding'])!=binding:raise ValueError('GAD transport binding changed')
            y=jnp.asarray(state['y']);key=jnp.asarray(state['key']);done=int(state['done']);stats=state['stats']
        else:
            key=jax.random.PRNGKey(config['sampler_seed']+1009*r);key,base=jax.random.split(key)
            y=jax.random.normal(base,(n,d),dtype=jnp.float64);done=0;stats=np.array([0,0,np.inf,0,0,np.inf,0])
        while done<cfg['steps']:
            stop();end=min(done+cfg['checkpoint_steps'],cfg['steps'])
            interval=np.stack([times[done:end],times[done+1:end+1]],axis=1)
            y,key,st=integrate(y,key,jnp.asarray(interval));st=np.asarray(st);yy=np.asarray(y)
            checked_cloud(yy,n,d)
            stats=np.asarray(combine_stats(jnp.asarray(np.stack([stats,st]))));done=end
            save_npz(cp,y=yy,key=np.asarray(key),binding=np.asarray(binding),done=np.asarray(done),stats=stats)
            progress(f'GAD round {r}/{cfg["rounds"]}: integration {done}/{cfg["steps"]}, t={times[done]:.3g}')
        previous=checked_cloud(np.asarray(y),n,d);save_npz(path/'samples.npz',samples=previous)
        rec=dict(binding=binding,method=f'GAD-{r}',round=r,**target.record(),
                 actual_t_min=float(times[-1]),steps=cfg['steps'],initial_bank=cfg['initial_bank'] if r==1 else f'GAD-{r-1}',
                 initial_setup_work=setup_work,
                 curvature='exact prior Hessian + likelihood GN; negative eigenvalues retained before gate guard',
                 guard_fraction=float(stats[0]/max(1,stats[1])),min_natural_gate_denominator=float(stats[2]),
                 max_gate_gain=float(stats[3]),mean_conditional_ess=float(stats[4]/max(1,stats[6])),
                 min_conditional_ess=float(stats[5]),stats_include_flow_padding=True,
                 elapsed_this_invocation_seconds=time.monotonic()-started)
        write(path/'sampling.json',rec);info[f'GAD-{r}']=rec
        del integrate
    return info
