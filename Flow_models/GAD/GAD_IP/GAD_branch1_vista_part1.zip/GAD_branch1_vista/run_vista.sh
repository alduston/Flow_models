#!/bin/bash
# User-run launcher. No existing jobs, environments or old batches are modified.
set -eo pipefail
G1_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
G1_BATCH="${1:-$(dirname "$G1_ROOT")/batches/gad_branch1_20261102}"
source "$G1_ROOT/slurm/environment.sh"
python -c 'import numpy, scipy, jax, numpyro, arviz, matplotlib'
python "$G1_ROOT/workflow.py" init --batch "$G1_BATCH"
mkdir -p "$G1_BATCH/logs"
exec 9> "$G1_BATCH/launcher.lock"
if ! flock -n 9; then
  printf 'A controller is already running for %s\n' "$G1_BATCH"
  exit 0
fi
nohup python -u "$G1_BATCH/code/workflow.py" watch --batch "$G1_BATCH" --poll 60 > "$G1_BATCH/logs/controller.log" 2>&1 &
G1_PID=$!
printf '%s\n' "$G1_PID" > "$G1_BATCH/controller.pid"
hostname > "$G1_BATCH/controller.host"
printf 'Controller PID: %s\nBatch: %s\nLog: %s\n' "$G1_PID" "$G1_BATCH" "$G1_BATCH/logs/controller.log"
printf 'Status: python %q status --batch %q\n' "$G1_BATCH/code/workflow.py" "$G1_BATCH"
