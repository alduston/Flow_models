"""Normalized smooth priors in the existing Fourier coefficient coordinates.

All four priors have zero mean and covariance I. Groups of two are complete
cos/sin Fourier pairs, so their laws are invariant to phase rotations.
"""
import math
import numpy as np

def validate(spec,dim):
    k=int(spec['group_size'])
    if dim%k:raise ValueError('Prior groups must partition the coordinates')
    if spec['family']=='student' and spec['df']<=2:raise ValueError('Unit covariance needs df>2')
    if spec['family']=='radial_laplace' and (k!=2 or spec['delta']<=0):raise ValueError('Smooth radial Laplace requires pairs and positive delta')
    if spec['family']=='scale_mixture':
        w=np.asarray(spec['weights']);v=np.asarray(spec['variances'])
        if np.any(w<=0) or np.any(v<=0) or not np.isclose(w.sum(),1) or not np.isclose(w@v,1):raise ValueError('Mixture must have unit covariance')

def energy_jax(x,spec):
    import jax.numpy as jnp
    from jax.scipy.special import logsumexp,gammaln
    k=int(spec['group_size']); g=x.reshape((-1,k)); r2=jnp.sum(g*g,axis=-1)
    family=spec['family']
    if family=='student':
        nu=spec['df'];c=nu-2
        log_norm=gammaln((nu+k)/2)-gammaln(nu/2)-k/2*jnp.log(jnp.pi*c)
        return jnp.sum((nu+k)/2*jnp.log1p(r2/c)-log_norm)
    if family=='radial_laplace':
        delta=spec['delta'];scale2=(delta*delta+3*delta+3)/(delta+1)
        log_norm=jnp.log(scale2)-jnp.log(2*jnp.pi*(delta+1))+delta
        return jnp.sum(jnp.sqrt(scale2*r2+delta*delta)-log_norm)
    if family=='scale_mixture':
        v=jnp.asarray(spec['variances']);w=jnp.asarray(spec['weights'])
        logp=jnp.log(w)-k/2*jnp.log(2*jnp.pi*v)-r2[:,None]/(2*v)
        return -jnp.sum(logsumexp(logp,axis=-1))
    if family=='gaussian':return .5*jnp.sum(x*x)+x.size/2*jnp.log(2*jnp.pi)
    raise ValueError(family)

def sample(spec,n,dim,rng):
    validate(spec,dim);k=int(spec['group_size']);ng=dim//k
    family=spec['family']
    if family=='student':
        scale=np.sqrt((spec['df']-2)/rng.chisquare(spec['df'],size=(n,ng,1)))
        return (rng.normal(size=(n,ng,k))*scale).reshape(n,dim)
    if family=='scale_mixture':
        ind=rng.choice(len(spec['weights']),size=(n,ng,1),p=spec['weights'])
        return (rng.normal(size=(n,ng,k))*np.sqrt(np.asarray(spec['variances'])[ind])).reshape(n,dim)
    if family=='radial_laplace':
        delta=spec['delta'];scale=math.sqrt((delta*delta+3*delta+3)/(delta+1));total=n*ng
        radii=[];count=0
        while count<total:
            r=rng.gamma(2,1,size=max(32,int((total-count)*1.2)))
            r=r[rng.random(len(r))<np.exp(r-np.sqrt(r*r+delta*delta))]
            radii.append(r);count+=len(r)
        r=np.concatenate(radii)[:total]/scale;theta=rng.uniform(0,2*np.pi,total)
        return np.column_stack([r*np.cos(theta),r*np.sin(theta)]).reshape(n,dim)
    if family=='gaussian':return rng.normal(size=(n,dim))
    raise ValueError(family)
