"""The approved bounded target list. Selection never reads GAD/pMALA rankings."""
import copy

def targets():
    rows=[]
    for p in ['navier_stokes','allen_cahn','helmholtz']:
        rows.append(dict(id=p+'_original',problem=p,kind='original',prior='gaussian',control=True))
    for n in [12,24]:
        for noise in [.05,.10]:
            rows.append(dict(id=f'ns_velocity{n}_noise{int(noise*100):02d}',problem='navier_stokes',kind='velocity',locations=n,noise_fraction=noise,prior='gaussian'))
    for t in [.33,1.]:
        for sigma in [.01,.03]:
            rows.append(dict(id=f'ac_patch_t{t:.2f}_noise{sigma:.2f}'.replace('.','p'),problem='allen_cahn',kind='patch',obs_time=t,noise_std=sigma,prior='gaussian'))
    for aperture in ['left','left_bottom']:
        for sigma in [.0004,.0008]:
            rows.append(dict(id=f'helm_{aperture}_noise{int(sigma*1e6)}',problem='helmholtz',kind='aperture',aperture=aperture,noise_std=sigma,prior='gaussian'))
    rows.append(dict(id='ns_radial_laplace',problem='navier_stokes',kind='original',prior='radial_laplace',anchor=True))
    return rows

def default_config():
    return dict(schema=1,campaign='GAD_branch1_vista',data_seed=42,sampler_seed=42,
        targets=targets(),conditional_phase_prior=True,
        limits=dict(node_hours=48.,max_inflight=2,screen_minutes=45,full_minutes=180,bank_minutes=90,max_changed_full=6,max_per_pde=2,max_bank_checks=2),
        gad=dict(rounds=5,particles=dict(navier_stokes=1000,allen_cahn=1000,helmholtz=2000),steps=300,t_max=10.,flow_batch=64,hessian_batch=1,query_batch=4,checkpoint_steps=20,gate_min_eval=.001,gate_max_gain=2.,endpoint_variance_tolerance=.01,endpoint_cap=1e-6,gaussian_error_tolerance=.02),
        map=dict(starts=4,max_calls=600,hessian_floor=1e-6,max_condition=1e8),
        pmala=dict(chains=16,warmup=32,dt=.25),
        screen_reference=dict(chains=2,warmup=300,samples=500,chunk=50,target_accept=.95,max_depth=10,max_rhat=1.05,min_bulk_ess=100.,min_tail_ess=50.,max_depth_fraction=.05,min_ebfmi=.3),
        full_reference=dict(chains=4,warmup=1000,samples=1000,chunk=50,target_accept=.95,max_depth=12,max_rhat=1.01,min_bulk_ess=400.,min_tail_ess=200.,max_depth_fraction=.01,min_ebfmi=.3),
        evaluation=dict(distribution_cap=1000,sliced_directions=128,seed=20261102,qoi_draws=512,floor_replicates=12),
        screen=dict(prior_draws=32,profile_points=12,curvature_draws=8,minimum_rotation=.05,minimum_laplace_sw2_ratio=1.25,minimum_qoi_cdf_error=.05),
        slurm=dict(account='DMS22021',partition='gh',cpus=8))

def find(config, target_id):
    for spec in config['targets']:
        if spec['id']==target_id: return copy.deepcopy(spec)
    raise KeyError(target_id)
