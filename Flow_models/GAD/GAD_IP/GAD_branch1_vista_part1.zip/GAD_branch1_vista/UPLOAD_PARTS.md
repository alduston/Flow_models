Upload BOTH GAD_branch1_vista_part1.zip and GAD_branch1_vista_part2.zip.
Both files are ordinary ZIPs below 20 MB. No concatenation or resampling is needed.

From your Vista login:
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/
unzip -q GAD_branch1_vista_part1.zip
unzip -q GAD_branch1_vista_part2.zip
bash GAD_branch1_vista/run_vista.sh

Both archives extract into the same GAD_branch1_vista/ folder.
Extract both before launching. The original code and all data are unchanged.
The original 31.8 MB ZIP is not needed.
