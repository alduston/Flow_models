"""Charged multistart MAP, stable q-LFGI-GN and cumulative fixed-metric pMALA."""
import json
import math
import time
from pathlib import Path
import numpy as np
import jax
import jax.numpy as jnp
from scipy.optimize import minimize
from io_utils import read,write,npz,save_npz,signature,checked_cloud,say
from oracle import CountedTarget,mala_step
from priors import sample
from transport import make_integrator,combine_stats,score_batch

def bind_file(path,binding):
    if path.exists() and read(path)['binding']!=binding: raise ValueError('Checkpoint target/config binding changed: '+str(path))

def setup_map(backend,cfg,folder,binding,stop):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    bind_file(folder/'binding.json',binding);write(folder/'binding.json',dict(binding=binding))
    meta=folder/'setup.json'; data=folder/'setup.npz'; bind_file(meta,binding)
    if meta.exists(): return npz(data),read(meta)
    target=CountedTarget(backend.dim,backend.joint,backend.hessian)
    target.attach_journal(folder/'oracle_requests.jsonl')
    rng=np.random.default_rng(420071)
    starts=np.vstack([np.zeros((1,backend.dim)),.5*rng.normal(size=(cfg['starts']-1,backend.dim))])
    records=[]; candidates=[]
    for i,x0 in enumerate(starts):
        stop(); say(f'MAP start {i+1}/{len(starts)}')
        part=folder/f'map_start{i}.npz'; info=folder/f'map_start{i}.json'; bind_file(info,binding)
        if part.exists() and info.exists():
            old=read(info); z=npz(part); candidates.append((old['energy'],z['position'],z['gradient'])); records.append(old)
            continue
        target.phase='map_start'+str(i)
        calls=target.by_phase.get(target.phase,{}).get('energy',0)
        partial=folder/f'map_start{i}_best.npz'
        if partial.exists():
            z=npz(partial);best=(float(z['energy']),z['position'],z['gradient']);x0=best[1]
        else:best=None
        t0=time.monotonic()
        class Cap(Exception):pass
        def objective(x):
            nonlocal calls,best
            stop()
            if calls>=cfg['max_calls']:raise Cap()
            calls+=1; lp,s=target.loggrad_latent(x[None]); v,g=-float(lp[0]),-s[0]
            if not np.isfinite(v) or not np.isfinite(g).all(): return 1e100,np.zeros(backend.dim)
            if best is None or v<best[0]:
                best=(v,x.copy(),g.copy());save_npz(partial,energy=np.asarray(v),position=x,gradient=g)
            return v,g
        try:
            opt=minimize(objective,x0,jac=True,method='L-BFGS-B',options=dict(maxiter=cfg['max_calls'],maxfun=cfg['max_calls'],maxls=30,gtol=1e-7,ftol=1e-12))
            success=bool(opt.success); message=str(opt.message)
        except Cap:success=False;message='bounded objective-call cap'
        if best is None: raise FloatingPointError('MAP start produced no finite exact posterior value')
        row=dict(binding=binding,start=i,energy=best[0],gradient_norm=np.linalg.norm(best[2]),calls=calls,success=success,message=message,runtime_seconds=time.monotonic()-t0,counts=target.by_phase[target.phase])
        save_npz(part,position=best[1],gradient=best[2]);write(info,row)
        records.append(row);candidates.append(best)
    candidates.sort(key=lambda z:z[0]);energy,m,g=candidates[0]
    target.phase='map_exact_hessian';t0=time.monotonic(); H=target.hessian(m)
    # A bounded exact-Newton polish prevents a capped L-BFGS iterate from being
    # mistaken for evidence that a competent MAP-Laplace approximation fails.
    refinements=0
    for _ in range(cfg.get('newton_polish_steps',8)):
        e,V=np.linalg.eigh(H);floor=max(cfg['hessian_floor'],max(abs(e))/cfg['max_condition']);reg=np.maximum(e,floor);L=V/np.sqrt(reg)
        if np.linalg.norm(g@L)<=cfg.get('max_whitened_gradient',.05):break
        direction=-L@(L.T@g);accepted=False;target.phase='map_newton_polish'
        for step in [1.,.5,.25,.125,.0625,.03125,.015625,.0078125]:
            stop();lp,score=target.loggrad_latent((m+step*direction)[None]);value=-float(lp[0])
            if np.isfinite(value) and np.isfinite(score).all() and value<=energy+1e-4*step*(g@direction):
                m=m+step*direction;g=-score[0];energy=value;accepted=True;refinements+=1;break
        if not accepted:break
        target.phase='map_exact_hessian';H=target.hessian(m)
    h_seconds=time.monotonic()-t0
    e,V=np.linalg.eigh(H);floor=max(cfg['hessian_floor'],max(abs(e))/cfg['max_condition']); reg=np.maximum(e,floor);L=V/np.sqrt(reg)
    candidates[0]=(energy,m,g)
    setup=dict(center=m,factor=L,hessian=H,candidates=np.stack([z[1] for z in candidates]),candidate_energy=np.array([z[0] for z in candidates]))
    save_npz(data,**setup)
    info=dict(binding=binding,records=records,energy=energy,gradient_norm=np.linalg.norm(g),whitened_gradient_norm=np.linalg.norm(g@L),map_usable=bool(np.linalg.norm(g@L)<=cfg.get('max_whitened_gradient',.05) and e.min()>=-1e-5),newton_polish_steps=refinements,hessian_min_raw=e.min(),hessian_max_raw=e.max(),hessian_floor=floor,hessian_clipped=int(np.sum(e<floor)),runtime_seconds=sum(r.get('runtime_seconds',0) for r in records)+h_seconds,**target.record())
    write(meta,info);return setup,info

def gaussian_grid_error(center,factor,t_min,steps,t_max):
    C=factor@factor.T; lam,V=np.linalg.eigh(C); m=V.T@center
    mu=np.zeros_like(m);var=np.ones_like(lam)
    ts=np.geomspace(t_max,t_min,steps+1)
    for t,tn in zip(ts[:-1],ts[1:]):
        h=t-tn;a=np.exp(-t);an=np.exp(-tn);g=-np.expm1(-2*t);gn=-np.expm1(-2*tn)
        ct=a*a*lam+g;cn=an*an*lam+gn
        A=1-2/ct;An=1-2/cn;b=2*a*m/ct;bn=2*an*m/cn
        F=1+.5*h*(A+An*(1+h*A));offset=.5*h*(b+An*h*b+bn)
        noise=np.sqrt(2*h)*(1+.5*h*An)
        mu=F*mu+offset;var=F*F*var+noise*noise
    a=np.exp(-t_min);g=-np.expm1(-2*t_min);expected=a*a*lam+g
    return dict(max_discretization_variance_relative_error=float(np.max(abs(var-expected)/expected)),whitened_mean_error=float(np.sqrt(np.mean((mu-a*m)**2/expected))),endpoint_variance_ratio=float((np.exp(2*t_min)-1)/lam.min()),clean_covariance_min=float(lam.min()),steps=steps,t_min=t_min)

def numerical_settings(setup,cfg):
    cov=setup['factor']@setup['factor'].T
    t_min=min(cfg['endpoint_cap'],.5*np.log1p(cfg['endpoint_variance_tolerance']*np.linalg.eigvalsh(cov).min()))
    if t_min<=0:raise ValueError('Unresolvable nonpositive endpoint')
    steps=cfg['steps']
    while True:
        control=gaussian_grid_error(setup['center'],setup['factor'],t_min,steps,cfg['t_max'])
        if max(control['max_discretization_variance_relative_error'],control['whitened_mean_error'])<=cfg['gaussian_error_tolerance']:break
        if steps>=4*cfg['steps']:raise ValueError('Gaussian endpoint/integrator control failed at maximum grid refinement')
        steps*=2
    return dict(cfg,t_min=t_min,steps=steps),control

def prior_sample(backend,n,rng,run):
    if backend.spec['prior']=='phase':
        pool=Path(run)/'calibration/phase/pool.npz';meta=read(pool.with_suffix('.json'))
        if not meta['usable']:raise ValueError('Phase prior has no validated initialization pool')
        if meta['parameters']!=backend.spec['phase_parameters']:raise ValueError('Phase prior pool parameter mismatch')
        x=npz(pool)['samples'];return x[rng.choice(len(x),n,replace=n>len(x))]
    return sample(backend.prior_spec,n,backend.dim,rng)

def initialization_work(backend,initial,run):
    if initial!='prior' or backend.spec['prior']!='phase':return 0
    return int(read(Path(run)/'calibration/phase/pool.json')['prior_energy_requests'])

def arm_setup(backend,initial,run,setup_info):
    counts=dict(setup_info['oracle_counts']);ledger={k:dict(v) for k,v in setup_info['work_ledger'].items()}
    prior_work=initialization_work(backend,initial,run)
    counts['energy']+=prior_work
    if prior_work:ledger['prior_pool_initialization']=dict(energy=prior_work,gradient=0,hessian=0)
    return counts,ledger,prior_work

def run_gad(backend,config,setup,setup_info,folder,binding,initial,n,run,stop):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    bind_file(folder/'binding.json',binding);write(folder/'binding.json',dict(binding=binding))
    cfg,control=numerical_settings(setup,config['gad']);write(folder/'gaussian_control.json',dict(binding=binding,**control))
    times=np.geomspace(cfg['t_max'],cfg['t_min'],cfg['steps']+1)
    counts,ledger,prior_work=arm_setup(backend,initial,run,setup_info)
    prior_seconds=read(Path(run)/'calibration/phase/pool.json').get('runtime_seconds',0) if prior_work else 0
    target=CountedTarget(backend.dim,backend.joint,backend.hessian,setup_info['pde_solve_count']+prior_work+3*n*cfg['rounds'])
    target.attach_journal(folder/'oracle_requests.jsonl',counts,ledger)
    previous=None;elapsed=0.
    for r in range(1,cfg['rounds']+1):
        path=folder/f'round{r}';path.mkdir(exist_ok=True);meta=path/'sampling.json';bind_file(meta,binding)
        if meta.exists():
            info=read(meta);previous=checked_cloud(npz(path/'samples.npz')['samples'],n,backend.dim)
            elapsed=info.get('transport_runtime_seconds',info['runtime_seconds']);continue
        t0=time.monotonic();bf=path/'bank.npz';bi=path/'bank.json';bind_file(bi,binding)
        if bf.exists() and bi.exists():
            bank=npz(bf);info=read(bi)
        else:
            rng=np.random.default_rng(config['sampler_seed']+701)
            x=(setup['center']+rng.normal(size=(n,backend.dim))@setup['factor'].T if initial=='laplace' else prior_sample(backend,n,rng,run)) if r==1 else previous
            lp_parts=[];score_parts=[];hparts=[]
            # Chunk checkpoints avoid repeating completed expensive PDE/GN work.
            chunks=path/'bank_chunks';chunks.mkdir(exist_ok=True)
            for i in range(0,n,16):
                stop();file=chunks/f'{i:06d}.npz'; mj=file.with_suffix('.json');bind_file(mj,binding)
                if file.exists() and mj.exists():
                    z=npz(file);rec=read(mj)
                else:
                    xx=x[i:i+16];before=dict(target.counts);target.phase=f'GAD-{r}_value_gradient'
                    lp,s=target.loggrad_latent(xx); hs=[];target.phase=f'GAD-{r}_GN'
                    for j in range(len(xx)):
                        stop();target.charge(hessian=1);hs.append(backend.gn(xx[j:j+1])[0])
                    z=dict(x=xx,lp=lp,s=s,H=np.stack(hs))
                    if not all(np.isfinite(v).all() for v in z.values()):raise FloatingPointError('Nonfinite GAD bank')
                    save_npz(file,**z);write(mj,dict(binding=binding,counts={k:target.counts[k]-before[k] for k in before}))
                lp_parts.append(z['lp']);score_parts.append(z['s']);hparts.append(z['H'])
                if i%128==0:say(f'GAD/{initial} round {r}: bank {min(i+16,n)}/{n}')
            bank=dict(x=x,s=np.concatenate(score_parts),H=np.concatenate(hparts));save_npz(bf,**bank)
            write(bi,dict(binding=binding,**target.record()))
        integrate=make_integrator(bank['x'],bank['s'],bank['H'],cfg)
        cp=path/'transport.npz'
        if cp.exists():
            st=npz(cp)
            if str(st['binding'])!=binding:raise ValueError('GAD flow checkpoint changed')
            y=jnp.asarray(st['y']);key=jnp.asarray(st['key']);done=int(st['done']);stats=st['stats']
        else:
            key,base=jax.random.split(jax.random.PRNGKey(config['sampler_seed']+1009*r))
            y=jax.random.normal(base,(n,backend.dim),dtype=jnp.float64);done=0;stats=np.array([0,0,np.inf,0,0,np.inf,0])
        while done<cfg['steps']:
            stop();end=min(done+cfg['checkpoint_steps'],cfg['steps'])
            interval=np.stack([times[done:end],times[done+1:end+1]],axis=1)
            y,key,new=integrate(y,key,jnp.asarray(interval)); yy=checked_cloud(np.asarray(y),n,backend.dim)
            stats=np.asarray(combine_stats(jnp.asarray(np.stack([stats,np.asarray(new)]))));done=end
            save_npz(cp,binding=np.asarray(binding),y=yy,key=np.asarray(key),done=np.asarray(done),stats=stats)
            say(f'GAD/{initial} round {r}: flow {done}/{cfg["steps"]}')
        previous=checked_cloud(np.asarray(y),n,backend.dim);save_npz(path/'samples.npz',samples=previous)
        elapsed+=time.monotonic()-t0
        # Cheap, independent noisy output queries; no additional target evaluations.
        ess_curve=[]; rng=np.random.default_rng(8800+r)
        for t in [1e-4,.01,.1,.3,1.,3.]:
            xx=previous[rng.choice(n,min(32,n),replace=False)]
            yy=np.exp(-t)*xx+np.sqrt(-np.expm1(-2*t))*rng.normal(size=xx.shape)
            _,s=score_batch(jnp.asarray(yy),t,jnp.asarray(bank['x']),jnp.asarray(bank['s']),jnp.asarray(bank['H']),cfg['gate_min_eval'],cfg['gate_max_gain']);s=np.asarray(s)
            ess_curve.append(dict(t=t,mean_ess=s[4]/s[6],min_ess=s[5],guard_fraction=s[0]/s[1]))
        write(meta,dict(binding=binding,method='GAD',initialization=initial,round=r,n=n,**target.record(),prior_initialization_energy_requests=prior_work,runtime_seconds=elapsed+setup_info.get('runtime_seconds',0)+prior_seconds,transport_runtime_seconds=elapsed,actual_t_min=cfg['t_min'],steps=cfg['steps'],guard_fraction=stats[0]/max(1,stats[1]),mean_conditional_ess=stats[4]/max(1,stats[6]),min_conditional_ess=stats[5],ess_curve=ess_curve,stats_include_flow_padding=True))

def stratified_indices(length,cap):
    return np.minimum(((np.arange(min(cap,length))+.5)*length/min(cap,length)).astype(int),length-1)

def run_pmala(backend,config,setup,setup_info,folder,binding,initial,n,run,stop):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    bind_file(folder/'binding.json',binding);write(folder/'binding.json',dict(binding=binding))
    cfg=config['pmala'];d=backend.dim;chains=min(cfg['chains'],n);warmup=cfg['warmup']
    # A phase-prior MCMC initializer has a real energy-query cost. Checkpoint both
    # pMALA starts at the union of both GAD starts' absolute work budgets.
    cap_round={setup_info['pde_solve_count']+initialization_work(backend,start,run)+3*n*r:r for start in ['laplace','prior'] for r in range(1,config['gad']['rounds']+1)}
    caps=sorted(cap_round)
    counts,ledger,prior_work=arm_setup(backend,initial,run,setup_info)
    prior_seconds=read(Path(run)/'calibration/phase/pool.json').get('runtime_seconds',0) if prior_work else 0
    target=CountedTarget(d,backend.joint,backend.hessian,caps[-1]);target.attach_journal(folder/'oracle_requests.jsonl',counts,ledger)
    center,L=setup['center'],setup['factor'];rng=np.random.default_rng(config['sampler_seed']+40000)
    def callback(z):
        lp,s=target.loggrad_latent(center+z@L.T);return lp,s@L
    cp=folder/'state.npz';history=[];elapsed=0.
    if cp.exists():
        st=npz(cp);meta=json.loads(str(st['metadata']))
        if meta['binding']!=binding:raise ValueError('pMALA state changed')
        z,lp,s=st['z'],st['lp'],st['score'];history=list(st['history'])
        transition=meta['transition'];accepted=meta['accepted'];production=meta['production'];h=meta['h'];elapsed=meta['runtime_seconds']
        rng.bit_generator.state=meta['rng_state']
    else:
        x=center+rng.normal(size=(chains,d))@L.T if initial=='laplace' else prior_sample(backend,chains,rng,run)
        z=np.linalg.solve(L,(x-center).T).T;target.phase='pmala_'+initial+'_initialization';lp,s=callback(z)
        if not np.isfinite(lp).all() or not np.isfinite(s).all():raise FloatingPointError('Nonfinite pMALA initial state')
        h=cfg['dt'];transition=accepted=production=0
    last=time.monotonic()
    def checkpoint():
        nonlocal elapsed,last
        now=time.monotonic();elapsed+=now-last;last=now
        meta=dict(binding=binding,transition=transition,accepted=accepted,production=production,h=h,rng_state=rng.bit_generator.state,runtime_seconds=elapsed,**target.record())
        save_npz(cp,z=z,lp=lp,score=s,history=np.asarray(history).reshape(-1,chains,d),metadata=np.asarray(json.dumps(meta)))
    for checkpoint_index,cap in enumerate(caps,1):
        r=cap_round[cap]
        out=folder/f'budget{checkpoint_index}';out.mkdir(exist_ok=True);meta=out/'sampling.json';bind_file(meta,binding)
        if meta.exists():continue
        if target.spent>cap:
            write(meta,dict(binding=binding,state='initialization_or_restart_work_exceeds_checkpoint',matched_work_cap=cap))
            continue
        while target.spent+2*chains<=cap:
            stop();target.phase='pmala_warmup' if transition<warmup else 'pmala_sampling'
            z,lp,s,info=mala_step(z,lp,s,callback,h,rng)
            if transition<warmup:
                # Acceptance-only adaptation; no permanent outlier secant cap.
                h=float(np.clip(h*(.1 if info['probability']<.01 else np.exp(min(1.,5/np.sqrt(transition+1))*(info['probability']-.574))),1e-12,1.))
            else:
                history.append(z.copy());accepted+=info['accepted'];production+=chains
            transition+=1
            if transition%25==0:checkpoint();say(f'pMALA/{initial}: transition {transition}, work {target.spent}/{caps[-1]}')
        checkpoint()
        record=dict(binding=binding,method='pMALA',initialization=initial,round=r,n=n,matched_work_cap=cap,**target.record(),prior_initialization_energy_requests=prior_work,runtime_seconds=elapsed+setup_info.get('runtime_seconds',0)+prior_seconds,production_runtime_seconds=elapsed,chains=chains,warmup=warmup,transitions=transition,production_states=production,acceptance_rate=accepted/max(1,production),final_dt=h,output='all cumulative post-warmup states including rejection repeats; stratified cloud cap; dependent')
        if history:
            allx=center+np.stack(history).reshape(-1,d)@L.T;checked_cloud(allx,d=d)
            ii=stratified_indices(len(allx),n);save_npz(out/'samples.npz',samples=allx[ii],production=allx,indices=ii)
            record['state']='complete';record['cloud_states']=len(ii)
        else:record['state']='no_production_at_this_budget'
        write(meta,record)
