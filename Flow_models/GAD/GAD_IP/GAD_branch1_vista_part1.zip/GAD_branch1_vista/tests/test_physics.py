import tempfile
from pathlib import Path
import unittest
import numpy as np
import jax
import jax.numpy as jnp
from models import Physics
from targets import prepare,design_for
from backend import Backend

class PhysicsTests(unittest.TestCase):
    def test_frozen_forward_probes_all_three_models(self):
        for p in ['allen_cahn','navier_stokes','helmholtz']:
            m=Physics(p);errors=m.validate_original();self.assertLess(max(errors),2e-11)

    def test_nested_sensors_and_disjoint_holdouts(self):
        ns=Physics('navier_stokes');a=design_for(dict(kind='velocity',locations=12),ns);b=design_for(dict(kind='velocity',locations=24),ns)
        self.assertTrue(set(a['train_indices']).issubset(b['train_indices']));self.assertFalse(set(a['train_indices'])&set(a['holdout_indices']))
        ac=design_for(dict(kind='patch'),Physics('allen_cahn'))
        self.assertEqual(np.asarray(ac['patch_indices']).shape,(16,16));self.assertFalse(set(np.ravel(ac['patch_indices']))&set(ac['holdout_indices']))
        h=Physics('helmholtz');a=design_for(dict(kind='aperture',aperture='left'),h);b=design_for(dict(kind='aperture',aperture='left_bottom'),h)
        self.assertEqual(len(a['train_pairs']),32);self.assertEqual(len(b['train_pairs']),64)
        self.assertTrue(set(map(tuple,a['train_pairs'])).issubset(map(tuple,b['train_pairs'])))
        self.assertFalse(set(map(tuple,b['train_pairs']))&set(map(tuple,b['holdout_pairs'])))

    def test_exact_scores_and_gn_directional_derivatives(self):
        for p in ['allen_cahn','navier_stokes','helmholtz']:
            with tempfile.TemporaryDirectory() as tmp:
                run=Path(tmp);spec=dict(id=p+'_test',problem=p,kind='original',prior='gaussian')
                prepare(spec,run);b=Backend(run/'targets'/spec['id'],query_batch=1)
                x=np.random.default_rng(13).normal(0,.03,b.dim);v=np.random.default_rng(14).normal(size=b.dim);v/=np.linalg.norm(v)
                lp,s=b.joint(x[None]);h=1e-5
                fp=float(b.energy(jnp.asarray(x+h*v)));fm=float(b.energy(jnp.asarray(x-h*v)))
                np.testing.assert_allclose(-s[0]@v,(fp-fm)/(2*h),rtol=2e-5,atol=2e-5)
                J=b.jacobian(x);G=b.gn(x[None])[0]
                np.testing.assert_allclose(G,np.eye(b.dim)+J.T@J,rtol=1e-9,atol=1e-8)
                H=b.hessian(x);np.testing.assert_allclose(H,H.T,rtol=1e-8,atol=1e-7)
                _,sp=b.joint((x+h*v)[None]);_,sm=b.joint((x-h*v)[None])
                np.testing.assert_allclose(H@v,-(sp[0]-sm[0])/(2*h),rtol=3e-4,atol=5e-4)
                jax.clear_caches()

if __name__=='__main__':unittest.main()
