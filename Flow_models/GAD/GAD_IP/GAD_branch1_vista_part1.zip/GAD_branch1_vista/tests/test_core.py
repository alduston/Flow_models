import copy
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import numpy as np
import jax.numpy as jnp
from catalog import default_config
from io_utils import read,write,npz,Stopped
from samplers import numerical_settings,run_pmala
from transport import score_batch
from workflow import accounting,watch
from oracle import CountedTarget

class Gaussian:
    dim=2
    spec={'problem':'test','prior':'gaussian'}
    prior_spec={'family':'gaussian','group_size':1}
    def joint(self,x):return -.5*np.sum(x*x,axis=1),-x
    def hessian(self,x):return np.eye(2)

class CoreTests(unittest.TestCase):
    def test_gaussian_score_cancellation_arbitrary_bank(self):
        rng=np.random.default_rng(6);x=rng.normal(size=(19,3));y=rng.normal(size=(7,3));m=np.array([.3,-.6,.2]);H=np.diag([.2,3.,1e8]);s=-(x-m)@H
        hs=np.broadcast_to(H,(len(x),3,3))
        for t in [1e-11,1e-6,.03,.7,3.]:
            out,stats=score_batch(jnp.asarray(y),t,jnp.asarray(x),jnp.asarray(s),jnp.asarray(hs))
            a=np.exp(-t);g=-np.expm1(-2*t);expected=(a*m-y)@np.linalg.inv(a*a*np.linalg.inv(H)+g*np.eye(3))
            np.testing.assert_allclose(np.asarray(out),expected,rtol=2e-10,atol=2e-7)

    def test_safe_negative_curvature_is_retained(self):
        x=np.array([[-1.,.5],[.2,-.8],[1.2,.4]]);H=np.diag([-.2,2.]);s=-x@H;y=np.array([[.1,.2]])
        out,stats=score_batch(jnp.asarray(y),.01,jnp.asarray(x),jnp.asarray(s),jnp.asarray(np.broadcast_to(H,(3,2,2))))
        a=np.exp(-.01);g=-np.expm1(-.02)
        expected=(-y)@H@np.linalg.inv(a*a*np.eye(2)+g*H)
        np.testing.assert_allclose(out,expected,rtol=1e-12,atol=1e-12);self.assertEqual(float(stats[0]),0.)

    def test_endpoint_relative_to_narrow_covariance(self):
        cfg=default_config()['gad'];setup={'center':np.array([1.,-2.]),'factor':np.diag([1e-4,2.])}
        numerical,control=numerical_settings(setup,cfg)
        self.assertLess(numerical['t_min'],1e-9)
        self.assertLessEqual(control['endpoint_variance_ratio'],.010000001)
        self.assertLessEqual(control['max_discretization_variance_relative_error'],.02)

    def test_pmala_history_and_restart_at_checkpoint(self):
        cfg=default_config();cfg['gad']['rounds']=2;cfg['pmala'].update(chains=4,warmup=4,dt=.2)
        setup={'center':np.zeros(2),'factor':np.eye(2)}
        info={'pde_solve_count':1,'oracle_counts':dict(energy=0,gradient=0,hessian=1),'work_ledger':{},'runtime_seconds':0.}
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);run_pmala(Gaussian(),cfg,setup,info,root/'a','fixed','prior',64,root,lambda:None)
            calls=[0]
            def stop():
                calls[0]+=1
                if calls[0]==24:raise Stopped('test boundary interruption')
            with self.assertRaises(Stopped):run_pmala(Gaussian(),cfg,setup,info,root/'b','fixed','prior',64,root,stop)
            run_pmala(Gaussian(),cfg,setup,info,root/'b','fixed','prior',64,root,lambda:None)
            a=npz(root/'a/budget2/samples.npz');b=npz(root/'b/budget2/samples.npz')
            np.testing.assert_array_equal(a['production'],b['production'])
            self.assertGreater(len(a['production']),len(a['samples']))
            self.assertLess(a['indices'][0],len(a['production'])//4)
            self.assertGreater(a['indices'][-1],3*len(a['production'])//4)
            self.assertLessEqual(read(root/'b/budget2/sampling.json')['pde_solve_count'],385)

    def test_scheduler_accounts_full_running_reservation(self):
        state={'tasks':{'a':dict(state='finished',elapsed_seconds=600),'b':dict(state='running',wall_seconds=3600),'c':dict(state='submitted',wall_seconds=1800)}}
        a=accounting(state);self.assertEqual(a['inflight'],2);self.assertAlmostEqual(a['total_committed_node_hours'],600/3600+1.5)

    def test_scheduler_submits_at_most_two_jobs(self):
        import workflow
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'logs').mkdir()
            write(root/'campaign.json',default_config());write(root/'identity.json',{'code_identity':workflow.code_identity()});write(root/'scheduler.json',dict(tasks={},phase='screen'))
            calls=[]
            def fake(cmd,**kwargs):
                self.assertEqual(cmd[0],'sbatch');calls.append(cmd)
                class Result:returncode=0;stdout=str(9000+len(calls))+'\n';stderr=''
                return Result()
            with patch('workflow.subprocess.run',side_effect=fake),patch('report.report',return_value=root):watch(root,once=True)
            self.assertEqual(len(calls),2);s=read(root/'scheduler.json');self.assertEqual(s['accounting']['inflight'],2)
            self.assertLessEqual(s['accounting']['total_committed_node_hours'],48)

    def test_catalog_is_bounded(self):
        rows=default_config()['targets'];self.assertEqual(len(rows),16);self.assertEqual(len({s['id'] for s in rows}),16)
        self.assertEqual(sum(s['prior']=='gaussian' for s in rows),15)
        self.assertEqual(sum(s.get('control',False) for s in rows),3)

    def test_lost_requests_remain_charged_after_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'requests.jsonl';b=Gaussian()
            t=CountedTarget(2,b.joint,b.hessian,100);t.attach_journal(path)
            t.phase='before_interrupt';t.loggrad_latent(np.zeros((3,2)))
            # No sampler-state checkpoint is needed to preserve the attempted request cost.
            resumed=CountedTarget(2,b.joint,b.hessian,100);resumed.attach_journal(path)
            self.assertEqual(resumed.spent,6)
            resumed.loggrad_latent(np.zeros((1,2)));self.assertEqual(resumed.spent,8)

if __name__=='__main__':unittest.main()
