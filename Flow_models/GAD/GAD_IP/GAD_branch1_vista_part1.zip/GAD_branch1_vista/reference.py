"""Exact-potential NUTS in fixed affine MAP coordinates, independently initialized."""
import pickle
import time
import numpy as np
import jax
import jax.numpy as jnp
from io_utils import ROOT,read,write,npz,save_npz,signature,checked_cloud,say

def dump(path,value):
    temp=path.with_name(path.name+'.tmp')
    with temp.open('wb') as f:pickle.dump(value,f,protocol=pickle.HIGHEST_PROTOCOL)
    temp.replace(path)

def diagnostics(chains,extra,cfg,derived=None):
    import arviz as az
    scalar=[chains[:,:,i] for i in range(chains.shape[-1])]
    if derived is not None: scalar.extend(derived[:,:,i] for i in range(derived.shape[-1]))
    r=np.array([float(az.rhat(v,method='rank')) for v in scalar]); b=np.array([float(az.ess(v,method='bulk')) for v in scalar]);t=np.array([float(az.ess(v,method='tail',prob=(.05,.95))) for v in scalar])
    energies=extra['energy'];bfmi=np.mean(np.diff(energies,axis=1)**2,axis=1)/np.var(energies,axis=1,ddof=1)
    div=int(extra['diverging'].sum()); depth=float(np.mean(extra['num_steps']>=2**cfg['max_depth']-1))
    finite=bool(np.isfinite(chains).all() and np.isfinite(r).all() and np.isfinite(b).all() and np.isfinite(t).all() and np.isfinite(bfmi).all())
    passed=finite and max(r)<=cfg['max_rhat'] and min(b)>=cfg['min_bulk_ess'] and min(t)>=cfg['min_tail_ess'] and div==0 and depth<=cfg['max_depth_fraction'] and min(bfmi)>=cfg['min_ebfmi']
    return dict(reference_usable=bool(passed),finite=finite,max_rank_rhat=float(max(r)),min_bulk_ess=float(min(b)),min_tail_ess=float(min(t)),divergences=div,depth_saturation_fraction=depth,min_ebfmi=float(min(bfmi)),mean_acceptance=float(extra['accept_prob'].mean()),mean_leapfrog_steps=float(extra['num_steps'].mean()),thresholds=cfg,physical_diagnostic_draws=0 if derived is None else derived.shape[1],caveat='Pilot diagnostics support comparisons but do not prove global mode coverage.')

def imported_original(backend,folder,binding):
    """Reuse only a byte-identical original Gaussian-prior posterior."""
    if backend.spec['kind']!='original' or backend.spec['prior']!='gaussian':return None
    path=ROOT/'frozen'/backend.spec['problem'];old=npz(path/'reference_samples.npz');q=read(path/'nuts_diagnostics.json')
    x=old['samples']
    # Original diagnostics are retained verbatim, not reinterpreted as a new reference run.
    usable=bool(q.get('certified',False) and q.get('checks') and all(q['checks'].values()))
    if str(old.get('fingerprint',''))!=read(path/'target.json')['fingerprint']:
        raise ValueError('Archived reference belongs to a different original target')
    if not usable:
        # Current export uses explicit quality_pass/validity fields; do not assume success.
        usable=bool(q.get('quality_pass',False))
    if not usable:return None
    folder.mkdir(parents=True,exist_ok=True)
    out=dict(samples=x)
    if 'samples_by_chain' in old:out['samples_by_chain']=old['samples_by_chain']
    elif len(x)%4==0:out['samples_by_chain']=x.reshape(4,-1,backend.dim)
    save_npz(folder/'samples.npz',**out)
    info=dict(binding=binding,reference_usable=True,origin='verified frozen original Gaussian-prior reference',archived_diagnostics=q,reference_not_charged_to_sampler=True)
    write(folder/'quality.json',info);return info

def run(backend,cfg,setup,folder,binding,stop,allow_import=False):
    import numpyro
    from numpyro.infer import NUTS,MCMC
    folder.mkdir(parents=True,exist_ok=True);quality=folder/'quality.json'
    pending=folder/'binding.json'
    if pending.exists() and read(pending)['binding']!=binding:raise ValueError('Reference setup binding changed')
    write(pending,dict(binding=binding))
    if quality.exists():
        q=read(quality)
        if q['binding']!=binding:raise ValueError('Reference binding changed')
        return q
    if allow_import:
        q=imported_original(backend,folder,binding)
        if q is not None:return q
    runtime=dict(jax=jax.__version__,numpyro=numpyro.__version__,numpy=np.__version__)
    rb=signature(dict(binding=binding,config=cfg,runtime=runtime))
    m,L=setup['center'],setup['factor'];mj,Lj=jnp.asarray(m),jnp.asarray(L)
    def potential(z):return backend.energy(mj+Lj@z)
    kernel=NUTS(potential_fn=potential,dense_mass=False,adapt_mass_matrix=False,target_accept_prob=cfg['target_accept'],max_tree_depth=cfg['max_depth'],find_heuristic_step_size=True)
    extra_fields=('potential_energy','energy','accept_prob','num_steps','adapt_state.step_size')
    candidates=setup['candidates'];ene=setup['candidate_energy'];candidates=candidates[ene-ene.min()<20]
    chains=[];ep=[]
    for c in range(cfg['chains']):
        stop();cd=folder/f'chain{c}';cd.mkdir(exist_ok=True)
        def restore(file):
            with file.open('rb') as f:q=pickle.load(f)
            if q['binding']!=rb:raise ValueError('NUTS runtime/target/config binding changed')
            q['state']=jax.tree_util.tree_map(jnp.asarray,q['state']);return q
        warm=cd/'warmup.pkl'
        if warm.exists():saved=restore(warm)
        else:
            rng=np.random.default_rng(170301+c)
            initial=np.linalg.solve(L,candidates[c%len(candidates)]-m)+rng.normal(0,1.5,backend.dim)
            for _ in range(12):
                val=potential(jnp.asarray(initial))
                if np.isfinite(val):break
                initial*=.5
            else:raise FloatingPointError('No finite independent reference initialization')
            say(f'NUTS chain {c+1}/{cfg["chains"]}: warmup {cfg["warmup"]}')
            mc=MCMC(kernel,num_warmup=cfg['warmup'],num_samples=cfg['chunk'],progress_bar=False)
            mc.warmup(jax.random.PRNGKey(100003*(c+1)+42),init_params=jnp.asarray(initial));jax.block_until_ready(mc.post_warmup_state.z)
            dump(warm,dict(binding=rb,state=jax.device_get(mc.post_warmup_state)));saved=restore(warm)
        state=saved['state'];parts=[];extras=[]
        for first in range(0,cfg['samples'],cfg['chunk']):
            stop();size=min(cfg['chunk'],cfg['samples']-first);file=cd/f'draws_{first:05d}.pkl'
            if file.exists():chunk=restore(file)
            else:
                say(f'NUTS chain {c+1}: draws {first}/{cfg["samples"]}')
                mc=MCMC(kernel,num_warmup=cfg['warmup'],num_samples=size,progress_bar=False)
                mc.post_warmup_state=state;mc.run(state.rng_key,init_params=state.z,extra_fields=extra_fields);jax.block_until_ready(mc.last_state.z)
                chunk=dict(binding=rb,state=jax.device_get(mc.last_state),first=first,draws=np.asarray(mc.get_samples()),extra={k:np.asarray(v) for k,v in mc.get_extra_fields().items()})
                checked_cloud(chunk['draws'],size,backend.dim);dump(file,chunk)
            if chunk['first']!=first or len(chunk['draws'])!=size:raise ValueError('NUTS checkpoint sequence changed')
            state=chunk['state'];parts.append(chunk['draws']);extras.append(chunk['extra'])
        x=m+np.concatenate(parts)@L.T;chains.append(x);ep.append({k:np.concatenate([e[k] for e in extras]) for k in extras[0]})
        save_npz(cd/'samples.npz',samples=x,**ep[-1])
    arr=np.stack(chains);ex={k:np.stack([e[k] for e in ep]) for k in ep[0]}
    save_npz(folder/'samples.npz',samples=arr.reshape(-1,backend.dim),samples_by_chain=arr,**ex)
    # Cheap initial-field functionals supplement coefficient diagnostics at full resolution.
    f=backend.fields(arr.reshape(-1,backend.dim)).reshape(*arr.shape[:2],-1)
    physical=np.stack([np.mean(f*f,axis=-1),np.mean(f>0,axis=-1)],axis=-1)
    # Phase fraction can be constant for a particular problem: omit constants from Rhat.
    keep=np.std(physical.reshape(-1,2),axis=0)>1e-14;physical=physical[:,:,keep]
    q=diagnostics(arr,ex,cfg,physical)
    write(quality,dict(binding=binding,runtime=runtime,**q));return q
