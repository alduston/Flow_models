#!/usr/bin/env python3
"""Bounded Vista workflow. Launch only via the user's explicit run_vista.sh command."""
import argparse
import copy
import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback
from io_utils import ROOT,read,write,signature,code_identity,verify_frozen,Deadline,Stopped,say
from catalog import default_config,find

TERMINAL={'COMPLETED','FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY','NODE_FAIL','PREEMPTED','BOOT_FAIL','DEADLINE'}

def initialize(batch):
    batch=Path(batch).resolve()
    if batch==ROOT or ROOT in batch.parents:raise ValueError('The batch directory must be outside the source package')
    if (batch/'campaign.json').exists():
        manifest=read(batch/'identity.json')
        if code_identity()!=manifest['code_identity']:raise ValueError('This batch belongs to a different source version; choose a new --batch')
        verify_frozen();return batch
    if batch.exists() and any(batch.iterdir()):raise ValueError('Refusing to populate an unrelated nonempty directory')
    batch.mkdir(parents=True,exist_ok=True);verify_frozen()
    shutil.copytree(ROOT,batch/'code',ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','*.pyc'),dirs_exist_ok=False)
    cfg=read(ROOT/'campaign.json') if (ROOT/'campaign.json').exists() else default_config()
    write(batch/'campaign.json',cfg);write(batch/'identity.json',dict(code_identity=code_identity(),created=time.time(),source=str(ROOT),data_seed=42,sampler_seed=42))
    (batch/'logs').mkdir();write(batch/'scheduler.json',dict(tasks={},phase='screen',created=time.time(),accounting={}))
    return batch

def preflight(allow_cpu=False):
    import numpy as np
    import scipy
    import jax
    import jax.numpy as jnp
    import numpyro
    import arviz
    jax.config.update('jax_enable_x64',True)
    devices=jax.devices()
    if not allow_cpu and not any(d.platform=='gpu' for d in devices):raise RuntimeError('A working JAX CUDA device is required. Run this stage through Slurm on gh.')
    out=jax.jit(lambda x:jnp.linalg.eigvalsh(x))(jnp.eye(3,dtype=jnp.float64))
    if out.dtype!=jnp.float64 or not np.isfinite(np.asarray(out)).all():raise RuntimeError('JAX float64/eigensolver preflight failed')
    return dict(jax=jax.__version__,numpyro=numpyro.__version__,arviz=arviz.__version__,numpy=np.__version__,scipy=scipy.__version__,devices=[str(d) for d in devices],float64=True,python=sys.version,allow_cpu=allow_cpu)

def run_stage(batch,target_id,stage,seconds,allow_cpu=False):
    import numpy as np
    from targets import prepare
    from backend import Backend
    from samplers import setup_map,run_gad,run_pmala,numerical_settings
    import reference
    batch=Path(batch).resolve();cfg=read(batch/'campaign.json');folder=batch/'targets'/target_id
    folder.mkdir(parents=True,exist_ok=True);status=folder/(stage+'_status.json');start=time.monotonic();stop=Deadline(max(1,seconds-120))
    def interrupted(sig,frame):raise Stopped('Slurm termination signal; committed checkpoints retained')
    signal.signal(signal.SIGTERM,interrupted)
    write(status,dict(state='running',started=time.time(),pid=os.getpid(),slurm_job_id=os.environ.get('SLURM_JOB_ID')))
    try:
        environment=preflight(allow_cpu);write(folder/(stage+'_environment.json'),environment)
        if stage=='phase_calibrate':
            from phase_prior import calibrate
            result=calibrate(batch,stop)
            if not result['usable']:raise Stopped('Phase-prior initialization pool failed its diagnostics; phase targets withheld')
        else:
            spec=find(cfg,target_id);prepare(spec,batch,stop)
            backend=Backend(folder,cfg['gad']['query_batch'])
            mapbinding=signature(dict(target=backend.fingerprint,map=cfg['map']))
            setup,info=setup_map(backend,cfg['map'],folder/'map',mapbinding,stop)
            if stage=='screen':
                binding=signature(dict(target=backend.fingerprint,stage=stage,map=cfg['map'],reference=cfg['screen_reference'],screen=cfg['screen'],gad=cfg['gad']))
                reference.run(backend,cfg['screen_reference'],setup,folder/'screen_reference',binding,stop,allow_import=True)
                from screen import audit
                audit(backend,cfg,setup,folder,folder/'screen_reference',binding,stop)
            elif stage in ['full','bank']:
                if stage=='bank':
                    cfg=copy.deepcopy(cfg);cfg['gad']['particles'][spec['problem']]*=2
                dest=folder/'bank_double' if stage=='bank' else folder;dest.mkdir(exist_ok=True)
                binding=signature(dict(target=backend.fingerprint,stage=stage,map=cfg['map'],reference=cfg['full_reference'],gad=cfg['gad'],pmala=cfg['pmala'],evaluation=cfg['evaluation']))
                if stage=='full':reference.run(backend,cfg['full_reference'],setup,folder/'reference',binding,stop,allow_import=True)
                elif not (folder/'reference/quality.json').exists():raise ValueError('A bank check requires a completed shared reference')
                n=cfg['gad']['particles'][spec['problem']]
                numerics,control=numerical_settings(setup,cfg['gad']);write(dest/'numerical_control.json',dict(binding=binding,**control))
                # pMALA is cheap enough to finish both prefixes before expensive GAD banks.
                for initial in ['prior','laplace']:
                    run_pmala(backend,cfg,setup,info,dest/('pmala_'+initial),binding,initial,n,batch,stop)
                for initial in ['prior','laplace']:
                    run_gad(backend,cfg,setup,info,dest/('gad_'+initial),binding,initial,n,batch,stop)
                from metrics import evaluate
                evaluate(backend,cfg,dest,folder/'reference',setup,info,binding,stop)
                if stage=='full':
                    from screen import curvature_audit
                    curvature_audit(backend,folder,setup,cfg,stop)
            else:raise ValueError(stage)
        write(status,dict(state='complete',ended=time.time(),runtime_seconds=time.monotonic()-start));return 0
    except Stopped as e:
        write(status,dict(state='capped',reason=str(e),ended=time.time(),runtime_seconds=time.monotonic()-start));say(str(e));return 2
    except Exception as e:
        write(status,dict(state='failed',reason=str(e),traceback=traceback.format_exc(),ended=time.time(),runtime_seconds=time.monotonic()-start));traceback.print_exc();return 1

def task_key(stage,target):return stage+':'+target

def add_task(state,target,stage,minutes):
    key=task_key(stage,target)
    if key not in state['tasks']:state['tasks'][key]=dict(target=target,stage=stage,wall_seconds=int(minutes*60),state='planned')

def active(task):return task['state'] in ['submitted','running']

def accounting(state):
    completed=sum(t.get('elapsed_seconds',0) for t in state['tasks'].values() if not active(t))
    reserved=sum(t['wall_seconds'] for t in state['tasks'].values() if active(t))
    return dict(completed_node_hours=completed/3600,reserved_inflight_node_hours=reserved/3600,total_committed_node_hours=(completed+reserved)/3600,inflight=sum(active(t) for t in state['tasks'].values()))

def submission_command(batch,task,cfg):
    batch=Path(batch);s=cfg['slurm'];label='g1_'+task['stage'][:2]+'_'+task['target'][:16]
    minutes=max(1,int(np_ceil(task['wall_seconds']/60)))
    return ['sbatch','--parsable','--no-requeue','--account='+s['account'],'--partition='+s['partition'],'--nodes=1','--ntasks=1','--cpus-per-task='+str(s['cpus']),'--time='+str(minutes),'--job-name='+label,'--chdir='+str(batch/'code'),'--output='+str(batch/'logs'/(task['stage']+'_'+task['target']+'_%j.log')),'--signal=B:TERM@90',str(batch/'code/slurm/job.sh'),str(batch),task['target'],task['stage'],str(task['wall_seconds'])]

def np_ceil(x):
    import math
    return math.ceil(x)

def refresh(state,batch):
    live=[t for t in state['tasks'].values() if active(t)]
    if not live:return False
    ids=','.join(t['job_id'] for t in live)
    proc=subprocess.run(['sacct','-n','-P','-j',ids,'--format=JobIDRaw,State,ElapsedRaw,AllocNodes'],text=True,capture_output=True)
    if proc.returncode:raise RuntimeError('Cannot read Slurm accounting; scheduler paused without submitting more work: '+proc.stderr)
    by={}
    for line in proc.stdout.splitlines():
        fields=line.split('|')
        if len(fields)>=4 and fields[0].isdigit():by[fields[0]]=fields
    changed=False
    for task in live:
        row=by.get(task['job_id'])
        if not row:continue  # Accounting lag retains the full reservation.
        slurm_state=row[1].split()[0].rstrip('+')
        if slurm_state in TERMINAL:
            task['slurm_state']=slurm_state;task['elapsed_seconds']=int(row[2] or 0)*max(1,int(row[3] or 1));task['state']='finished';changed=True
            status=Path(batch)/'targets'/task['target']/(task['stage']+'_status.json')
            task['result']=read(status)['state'] if status.exists() else 'slurm_'+slurm_state.lower()
        elif slurm_state in ['RUNNING','COMPLETING']:task['state']='running'
    return changed

def conditional_phase(cfg,state,batch):
    if not cfg['conditional_phase_prior']:return False
    ac=[s for s in cfg['targets'] if s['problem']=='allen_cahn' and not s.get('control') and s['prior']=='gaussian']
    files=[batch/'targets'/s['id']/'screen.json' for s in ac]
    if len(files)!=4 or not all(p.exists() for p in files):return False
    records=[read(p) for p in files]
    if not all(r.get('map_usable',False) and r['reference_usable'] and max(r.get('half_timestep_RMS_change_in_noise_units') or [0])<=.1 for r in records):return False
    if any(r['geometry_candidate'] for r in records):return False
    key=task_key('phase_calibrate','phase_prior')
    if key not in state['tasks']:
        add_task(state,'phase_prior','phase_calibrate',15);return True
    task=state['tasks'][key]
    if task['state'] in ['planned','submitted','running']:return True
    meta=batch/'calibration/phase/pool.json'
    if not meta.exists() or not read(meta)['usable']:return False
    if any(s['prior']=='phase' for s in cfg['targets']):return False
    parameters=read(meta)['parameters'];best=max(records,key=lambda r:r['geometry_score'])
    base=[next(s for s in cfg['targets'] if s['id']=='allen_cahn_original'),find(cfg,best['target'])]
    for name,spec in zip(['ac_phase_original','ac_phase_patch'],base):
        spec=copy.deepcopy(spec);spec.update(id=name,prior='phase',phase_parameters=parameters);spec.pop('control',None)
        cfg['targets'].append(spec);add_task(state,name,'screen',cfg['limits']['screen_minutes'])
    write(batch/'campaign.json',cfg);return True

def choose_bank_checks(cfg,batch,state):
    import csv
    from metrics import matched_comparisons
    candidates=[]
    selected=read(batch/'selection.json')['targets']
    for name in selected:
        key=task_key('full',name)
        if state['tasks'].get(key,{}).get('result')!='complete':continue
        folder=batch/'targets'/name
        if not (folder/'metrics.csv').exists():continue
        rows=list(csv.DictReader((folder/'metrics.csv').open()))
        pairs=matched_comparisons(rows,cfg['gad']['rounds'])
        if len(pairs)==2:candidates.append((max(abs(np_log(p['ratio'])) for p in pairs),name))
    for _,name in sorted(candidates,reverse=True)[:cfg['limits']['max_bank_checks']]:add_task(state,name,'bank',cfg['limits']['bank_minutes'])

def np_log(x):
    import math
    return math.log(max(x,1e-15))

def advance(cfg,state,batch):
    if state['phase']=='screen':
        for spec in cfg['targets']:add_task(state,spec['id'],'screen',cfg['limits']['screen_minutes'])
        # Repaired controls precede new targets, and radial NS precedes other new priors.
        if any(t['state'] in ['planned','submitted','running'] for t in state['tasks'].values() if t['stage']=='screen'):return
        if conditional_phase(cfg,state,batch):return
        from screen import select
        selection=select(cfg,batch)
        for name in selection['controls']+selection['targets']:add_task(state,name,'full',cfg['limits']['full_minutes'])
        state['phase']='full'
    if state['phase']=='full':
        if any(t['state'] in ['planned','submitted','running'] for t in state['tasks'].values() if t['stage']=='full'):return
        choose_bank_checks(cfg,batch,state);state['phase']='bank'
    if state['phase']=='bank':
        if not any(t['state'] in ['planned','submitted','running'] for t in state['tasks'].values() if t['stage']=='bank'):state['phase']='complete'

def watch(batch,poll=60,once=False,dry_run=False):
    batch=Path(batch).resolve();cfg=read(batch/'campaign.json')
    if code_identity()!=read(batch/'identity.json')['code_identity']:raise ValueError('Frozen campaign code changed')
    with (batch/'controller.lock').open('a') as handle:
        try:fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('A controller already owns this campaign; no duplicate submissions made')
        while True:
            cfg=read(batch/'campaign.json');state=read(batch/'scheduler.json')
            changed=False if dry_run else refresh(state,batch)
            advance(cfg,state,batch)
            cfg=read(batch/'campaign.json')
            totals=accounting(state);budget=cfg['limits']['node_hours']
            planned=[t for t in state['tasks'].values() if t['state']=='planned']
            planned.sort(key=lambda t:(0 if t['target'].endswith('_original') else 1 if t['target']=='ns_radial_laplace' else 2,list(state['tasks']).index(task_key(t['stage'],t['target']))))
            for task in planned:
                totals=accounting(state)
                if totals['inflight']>=cfg['limits']['max_inflight']:break
                # Reserve the complete Slurm walltime before submission. This bounds all allocated time, including setup/evaluation.
                if totals['total_committed_node_hours']+task['wall_seconds']/3600>budget:
                    continue
                cmd=submission_command(batch,task,cfg)
                if dry_run:
                    say(' '.join(cmd));task['state']='submitted';task['job_id']='DRY_RUN';continue
                proc=subprocess.run(cmd,text=True,capture_output=True)
                if proc.returncode:raise RuntimeError('sbatch rejected submission; no automatic retry: '+proc.stderr)
                job=proc.stdout.strip().split(';')[0]
                if not job.isdigit():raise RuntimeError('Unexpected sbatch response; inspect queue before restarting: '+proc.stdout)
                task.update(state='submitted',job_id=job,submitted=time.time());write(batch/'scheduler.json',state);say(f'Submitted {task["stage"]}/{task["target"]}: {job}');changed=True
            state['accounting']=dict(accounting(state),cap_node_hours=budget,max_inflight=cfg['limits']['max_inflight'])
            if not dry_run:write(batch/'scheduler.json',state)
            say(json.dumps(dict(phase=state['phase'],**state['accounting'])))
            if changed or state['phase']=='complete':
                from report import report
                report(batch)
            if state['phase']=='complete':
                export_results(batch);say('Campaign finished. See report/dashboard.html and GAD_branch1_results.zip.');return
            if once or dry_run:return
            if not any(active(t) for t in state['tasks'].values()):
                remaining=budget-accounting(state)['completed_node_hours']
                if planned and min(t['wall_seconds']/3600 for t in planned)>remaining:
                    state['phase']='resource_cap';write(batch/'scheduler.json',state)
                    from report import report
                    report(batch);export_results(batch);say('Allocated-time cap reached. Unrun targets remain explicitly unresolved.');return
            time.sleep(min(60,max(1,poll)))

def export_results(batch):
    import zipfile
    batch=Path(batch);dest=batch/'GAD_branch1_results.zip'
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(batch.rglob('*')):
            if not p.is_file() or p==dest or 'code' in p.relative_to(batch).parts or p.name.endswith('.lock'):continue
            z.write(p,p.relative_to(batch))
    return dest

def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('init');p.add_argument('--batch',required=True)
    p=sub.add_parser('watch');p.add_argument('--batch',required=True);p.add_argument('--poll',type=int,default=60);p.add_argument('--once',action='store_true');p.add_argument('--dry-run',action='store_true')
    p=sub.add_parser('stage');p.add_argument('--batch',required=True);p.add_argument('--target',required=True);p.add_argument('--stage',choices=['screen','full','bank','phase_calibrate'],required=True);p.add_argument('--seconds',type=int,default=3600);p.add_argument('--allow-cpu',action='store_true')
    for name in ['status','report','export']:p=sub.add_parser(name);p.add_argument('--batch',required=True)
    p=sub.add_parser('preflight');p.add_argument('--allow-cpu',action='store_true')
    sub.add_parser('list');sub.add_parser('self-test')
    args=parser.parse_args()
    if args.command=='init':say(initialize(args.batch))
    elif args.command=='watch':watch(args.batch,args.poll,args.once,args.dry_run)
    elif args.command=='stage':sys.exit(run_stage(Path(args.batch),args.target,args.stage,args.seconds,args.allow_cpu))
    elif args.command=='status':
        state=read(Path(args.batch)/'scheduler.json');say(json.dumps(state,indent=2))
    elif args.command=='report':
        from report import report
        say(report(Path(args.batch)))
    elif args.command=='export':say(export_results(args.batch))
    elif args.command=='preflight':say(json.dumps(preflight(args.allow_cpu),indent=2))
    elif args.command=='list':
        for spec in default_config()['targets']:say(json.dumps(spec))
    elif args.command=='self-test':
        import unittest
        suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'));result=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not result.wasSuccessful())

if __name__=='__main__':main()
