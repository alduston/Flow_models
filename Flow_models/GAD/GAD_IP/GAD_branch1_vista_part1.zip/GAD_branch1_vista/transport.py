"""Unweighted q-LFGI GAD with the original stochastic reverse-OU Heun update.

Negative clean curvature is retained. Only eigenvalues of A=alpha^2 I+gamma
E_q[H_GN] are guarded, along with an explicit maximum gate gain. Target queries
are confined to the reference bank. All flow evaluations reuse that bank.
"""
import math
import time
import numpy as np
import jax
import jax.numpy as jnp

from priors import sample

def score_batch(y,t,x,s,H,gate_min_eval=1e-3,gate_max_gain=2.):
    a=jnp.exp(-t);g=-jnp.expm1(-2*t)
    # Quadratic distance calculation avoids a [query,bank,dimension] tensor.
    d2=jnp.maximum(jnp.sum(y*y,1)[:,None]+a*a*jnp.sum(x*x,1)[None,:]-2*a*(y@x.T),0)
    w=jax.nn.softmax(-.5*d2/g,axis=1)
    mx=w@x;ms=w@s
    h=(w@H.reshape((len(x),-1))).reshape((len(y),y.shape[1],y.shape[1]))
    h=.5*(h+jnp.swapaxes(h,-1,-2))
    ev,V=jnp.linalg.eigh(h)
    natural=a*a+g*ev
    floor=jnp.maximum(gate_min_eval,a*a/gate_max_gain)
    den=jnp.maximum(natural,floor)
    # This is exactly b+G(c-b), expressed without the cancelling 1/g terms.
    precision=jnp.where(natural<floor,(den-a*a)/g,ev)
    r=a*mx-y
    vr=jnp.einsum('bij,bi->bj',V,r);vs=jnp.einsum('bij,bi->bj',V,ms)
    result=jnp.einsum('bij,bj->bi',V,(precision*vr+a*vs)/den)
    ess=1/jnp.sum(w*w,1)
    stats=jnp.stack([jnp.sum(natural<floor),jnp.asarray(natural.size),jnp.min(natural),
                     jnp.max(a*a/den),jnp.sum(ess),jnp.min(ess),jnp.asarray(len(y))])
    return result,stats

def combine_stats(stats):
    return jnp.array([stats[:,0].sum(),stats[:,1].sum(),stats[:,2].min(),stats[:,3].max(),
                      stats[:,4].sum(),stats[:,5].min(),stats[:,6].sum()])

def make_integrator(x,s,H,cfg):
    x,s,H=(jnp.asarray(z,dtype=jnp.float64) for z in [x,s,H])
    batch=cfg['flow_batch'];minimum=cfg['gate_min_eval'];gain=cfg['gate_max_gain']
    def field(y,t):
        n=len(y);pad=(-n)%batch
        padded=jnp.pad(y,((0,pad),(0,0)),mode='edge').reshape((-1,batch,y.shape[1]))
        # Padding is only cached score arithmetic, never a target request.
        def chunk(z):return score_batch(z,t,x,s,H,minimum,gain)
        ys,st=jax.lax.map(chunk,padded)
        return ys.reshape((-1,y.shape[1]))[:n],combine_stats(st)
    def step(carry,times):
        y,key=carry;t,tn=times;h=t-tn
        key,noise_key=jax.random.split(key)
        noise=jax.random.normal(noise_key,y.shape,dtype=jnp.float64)
        sc,st=field(y,t);drift=y+2*sc
        predictor=y+h*drift+jnp.sqrt(2*h)*noise
        sn,stn=field(predictor,tn)
        y=y+.5*h*(drift+predictor+2*sn)+jnp.sqrt(2*h)*noise
        return (y,key),combine_stats(jnp.stack([st,stn]))
    @jax.jit
    def integrate(y,key,times):
        (y,key),stats=jax.lax.scan(step,(y,key),times)
        return y,key,combine_stats(stats)
    return integrate
