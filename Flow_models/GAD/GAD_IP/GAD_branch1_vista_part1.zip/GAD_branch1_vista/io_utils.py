"""Atomic checkpoints and scientific identities; no completed marker without checks."""
import hashlib
import json
import time
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent

def clean(x):
    if isinstance(x, dict): return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (tuple, list)): return [clean(v) for v in x]
    if isinstance(x, Path): return str(x)
    if hasattr(x, 'tolist'): return clean(x.tolist())
    if isinstance(x, float) and not np.isfinite(x): return None
    return x

def read(p): return json.loads(Path(p).read_text())

def write(p, x):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    t = p.with_name(p.name + '.tmp')
    t.write_text(json.dumps(clean(x), indent=2, allow_nan=False) + '\n'); t.replace(p)

def npz(p):
    with np.load(p, allow_pickle=False) as z: return dict(z)

def save_npz(p, **x):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    t = p.with_name(p.name + '.tmp')
    with t.open('wb') as f: np.savez_compressed(f, **x)
    t.replace(p)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''): h.update(b)
    return h.hexdigest()

def signature(x): return hashlib.sha256(json.dumps(clean(x), sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def code_identity():
    return signature({str(p.relative_to(ROOT)): sha(p) for p in sorted(list(ROOT.glob('*.py')) + list((ROOT/'slurm').glob('*'))) if p.is_file()})

def verify_frozen():
    for p, digest in read(ROOT/'frozen_manifest.json').items():
        if sha(ROOT/p) != digest: raise ValueError('Frozen source/input changed: ' + p)

def checked_cloud(x, n=None, d=None):
    x = np.asarray(x, dtype=np.float64)
    if x.ndim != 2 or (n is not None and len(x) != n) or (d is not None and x.shape[1] != d) or not np.isfinite(x).all():
        raise FloatingPointError('Incomplete or nonfinite cloud; no filtering/replacement allowed')
    return x

class Stopped(RuntimeError): pass

class Deadline:
    def __init__(self, seconds): self.end = time.monotonic() + seconds
    def __call__(self):
        if time.monotonic() >= self.end: raise Stopped('Stage time cap reached; checkpoints retained')

def say(x): print(x, flush=True)
