"""Freeze operator, paired noise, and physical data before any sampler is run."""
import fcntl
from pathlib import Path
import numpy as np
import jax.numpy as jnp
from io_utils import ROOT, read,write,npz,save_npz,sha,signature,code_identity,verify_frozen
from models import Physics

def design_for(spec, physics):
    kind=spec['kind']; d=dict(kind=kind)
    if kind=='velocity':
        ys=np.floor(np.arange(12)*32/12).astype(int)
        full=np.array([x*32+y for x in [8,10] for y in ys])
        take=np.arange(24) if spec['locations']==24 else np.r_[np.arange(0,12,2),np.arange(12,24,2)]
        d.update(train_indices=full[take].tolist(),holdout_indices=[x*32+y for x in [24,26] for y in ys[::2]],universe_take=take.tolist())
    elif kind=='patch':
        patches=np.array([[i*32+j for i in range(x,x+4) for j in range(y,y+4)] for x in [0,4,8,12] for y in [2,10,18,26]])
        hold=np.random.default_rng(43).choice(np.arange(16*32,32*32),40,replace=False)
        d.update(patch_indices=patches.tolist(),holdout_indices=hold.tolist(),readout_noise='independent Gaussian on each signed patch average')
    elif kind=='aperture':
        # In the archived Helmholtz mesh, flat row*32+column has x=column/31.
        ys=np.round(np.linspace(0,31,16)).astype(int)
        left=ys*32
        if spec['aperture']=='left': receivers=left
        else:
            xs=np.round(np.linspace(1,31,16)).astype(int)
            receivers=np.r_[left,xs]  # bottom row, excluding duplicate corner
        pairs=np.array([[r,s] for s in [0,3] for r in receivers])
        boundary=np.asarray(physics.constants['boundary_indices_ordered'])
        used={tuple(x) for x in pairs}
        hold=np.array([[r,s] for s in range(4) for r in boundary if (r,s) not in used])
        d.update(train_pairs=pairs.tolist(),holdout_pairs=hold.tolist(),receiver_indices=receivers.tolist(),source_indices=[0,3])
    return d

def velocity_calibration(run, physics, stop):
    path=Path(run)/'calibration/ns_velocity'; path.mkdir(parents=True,exist_ok=True)
    with (path/'lock').open('a') as handle:
        fcntl.flock(handle,fcntl.LOCK_EX)
        file=path/'calibration.json'
        source=code_identity()
        if file.exists():
            out=read(file)
            if out['code_identity']!=source: raise ValueError('Calibration code changed; use a new campaign folder')
            return np.asarray(out['component_rms'])
        draw=np.random.default_rng(20261102).normal(size=(32,physics.dim))
        spec=dict(kind='velocity',locations=24); design=design_for(spec,physics); values=[]
        for x in draw:
            stop(); values.append(np.asarray(physics.observe(jnp.asarray(x),design)).reshape(2,24))
        values=np.stack(values)
        if not np.isfinite(values).all(): raise FloatingPointError('Prior-predictive NS instability')
        rms=np.sqrt(np.mean(values*values,axis=(0,2)))
        if min(rms)<=0: raise ValueError('Zero velocity prior-predictive RMS')
        write(file,dict(code_identity=source,component_rms=rms,draws=32,seed=20261102,definition='sqrt mean(component squared) over 32 Gaussian-prior draws and all 24 candidate sites'))
        save_npz(path/'prior_predictive.npz',coefficients=draw,velocity=values)
        return rms

def prepare(spec, run, stop=lambda:None):
    run=Path(run); folder=run/'targets'/spec['id']; folder.mkdir(parents=True,exist_ok=True)
    meta=folder/'target.json'; data=folder/'target.npz'
    expected=dict(spec=spec,source=code_identity())
    if meta.exists():
        record=read(meta)
        if record['preparation_binding']!=signature(expected) or sha(data)!=record['arrays_sha256']:
            raise ValueError('Prepared target/code changed; create a new run folder')
        return record
    verify_frozen()
    physics=Physics(spec['problem'],spec.get('obs_time',.33))
    physics.validate_original() if spec.get('obs_time',.33)==.33 else Physics(spec['problem']).validate_original()
    design=design_for(spec,physics); a=physics.arrays
    if spec['kind']=='original':
        y=a['y_obs_np']; clean=a['y_clean_np']; hc=a['y_holdout_clean_np']; hy=a['y_holdout_obs_np']
        std=dict(navier_stokes=.005,allen_cahn=.01,helmholtz=.0004)[spec['problem']]
        sigma=np.full(y.shape,std); hs=np.full(hy.shape,std)
    else:
        stop(); clean=np.asarray(physics.observe(jnp.asarray(a['alpha_true_np']),design))
        hc=np.asarray(physics.observe(jnp.asarray(a['alpha_true_np']),design,True))
        if spec['kind']=='velocity':
            rms=velocity_calibration(run,physics,stop)
            sigma=np.repeat(spec['noise_fraction']*rms,spec['locations'])
            hs=np.repeat(spec['noise_fraction']*rms,len(design['holdout_indices']))
            universe=np.random.default_rng(42).normal(size=(2,24))
            noise=universe[:,design['universe_take']].reshape(-1)
        elif spec['kind']=='aperture':
            # Universal source/receiver/component noise gives nested designs paired noise.
            universe=np.random.default_rng(42).normal(size=(2,4,1024))
            pairs=np.asarray(design['train_pairs'])
            noise=universe[:,pairs[:,1],pairs[:,0]].reshape(-1)
            sigma=np.full(clean.shape,spec['noise_std']); hs=np.full(hc.shape,spec['noise_std'])
        else:
            noise=np.random.default_rng(42).normal(size=clean.shape)
            sigma=np.full(clean.shape,spec['noise_std']); hs=np.full(hc.shape,spec['noise_std'])
        y=clean+sigma*noise; hy=hc+hs*np.random.default_rng(43).normal(size=hc.shape)
    if not all(np.isfinite(v).all() for v in [y,clean,hc,hy,sigma,hs]): raise FloatingPointError('Nonfinite frozen target')
    save_npz(data,y=y,y_clean=clean,sigma=sigma,heldout_y=hy,heldout_clean=hc,heldout_sigma=hs)
    record=dict(spec=spec,design=design,dimension=physics.dim,preparation_binding=signature(expected),arrays_sha256=sha(data),original_frozen_manifest=sha(ROOT/'frozen_manifest.json'))
    record['fingerprint']=signature(record)
    write(meta,record)
    return record
