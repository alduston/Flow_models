"""All methods share the exact posterior; only GAD's likelihood curvature uses GN."""
import numpy as np
import jax
import jax.numpy as jnp
from io_utils import npz,read,signature,code_identity
from models import Physics
from priors import energy_jax

class Backend:
    def __init__(self, folder, query_batch=4):
        self.folder=folder; self.meta=read(folder/'target.json'); self.spec=self.meta['spec']; self.data=npz(folder/'target.npz')
        self.physics=Physics(self.spec['problem'],self.spec.get('obs_time',.33)); self.dim=self.physics.dim
        self.design=self.meta['design']; self.query_batch=query_batch
        prior=self.spec['prior']
        if prior=='radial_laplace': self.prior_spec=dict(family=prior,group_size=2,delta=.1)
        elif prior=='phase': self.prior_spec=dict(family='phase',**self.spec['phase_parameters'])
        else: self.prior_spec=dict(family='gaussian',group_size=1)
        B=self.physics.B
        def prior_energy(x):
            if prior!='phase': return energy_jax(x,self.prior_spec)
            p=self.prior_spec; u=(B@x).reshape(32,32)
            dx=(jnp.roll(u,-1,0)-u)*32; dy=(jnp.roll(u,-1,1)-u)*32
            E=jnp.mean(.5*p['ell']*(dx*dx+dy*dy)+(u*u-p['amplitude']**2)**2/(4*p['ell']))
            return .5*jnp.vdot(x,x)+p['strength']*E
        self.prior_energy=prior_energy
        def residual(x): return (self.physics.observe(x,self.design)-jnp.asarray(self.data['y']))/jnp.asarray(self.data['sigma'])
        self.residual=residual
        def energy(x):
            r=residual(x); return prior_energy(x)+.5*jnp.vdot(r,r)
        self.energy=energy
        self._joint=jax.jit(jax.vmap(jax.value_and_grad(energy)))
        self._hessian=jax.jit(jax.hessian(energy))
        self._jac=jax.jit(jax.jacfwd(residual))
        def gn(x):
            J=jax.jacfwd(residual)(x)
            return jax.hessian(prior_energy)(x)+J.T@J
        self._gn=jax.jit(jax.vmap(gn))
        self._qoi=jax.jit(jax.vmap(lambda x:self.physics.qoi(x,self.design)))
        self.fingerprint=signature(dict(target=self.meta['fingerprint'],code=code_identity()))

    def joint(self,x):
        x=np.asarray(x); vs=[]; gs=[]
        for i in range(0,len(x),self.query_batch):
            v,g=self._joint(jnp.asarray(x[i:i+self.query_batch])); vs.append(-np.asarray(v)); gs.append(-np.asarray(g))
        return np.concatenate(vs),np.concatenate(gs)

    def hessian(self,x): return np.asarray(self._hessian(jnp.asarray(x)))
    def jacobian(self,x): return np.asarray(self._jac(jnp.asarray(x)))
    def gn(self,x): return np.asarray(self._gn(jnp.asarray(x)))
    def qoi(self,x,stop=lambda:None):
        out=[]
        for i in range(0,len(x),4): stop(); out.append(np.asarray(self._qoi(jnp.asarray(x[i:i+4]))))
        return np.concatenate(out)
    def fields(self,x):
        out=np.asarray(x)@np.asarray(self.physics.B).T
        if self.spec['problem']=='navier_stokes':
            out*=float(self.physics.physical['scale']); out-=out.mean(axis=1,keepdims=True)
        if self.spec['problem']=='helmholtz': out=.45*np.asarray(self.physics.physical['mask']).ravel()*np.tanh(out)
        return out
