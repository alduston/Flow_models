"""Restartable HTML dashboard, CSVs and separate publication-ready figure files."""
import csv
import html
from pathlib import Path
import numpy as np
from io_utils import read,write,npz,ROOT
from metrics import csv_write,matched_comparisons

def report(run):
    run=Path(run);out=run/'report';out.mkdir(parents=True,exist_ok=True)
    cfg=read(run/'campaign.json');rows=[];screens=[];status=[]
    for spec in cfg['targets']:
        root=run/'targets'/spec['id']
        for stage in ['screen','full','bank']:
            file=root/(stage+'_status.json')
            if file.exists():status.append(dict(target=spec['id'],stage=stage,**read(file)))
        if (root/'screen.json').exists():screens.append(read(root/'screen.json'))
        for folder in [root,root/'bank_double']:
            if (folder/'metrics.csv').exists():
                rr=list(csv.DictReader((folder/'metrics.csv').open()))
                for r in rr:r['bank_variant']='double' if folder.name=='bank_double' else 'base'
                rows.extend(rr)
    csv_write(out/'all_metrics.csv',rows);write(out/'screening.json',screens);write(out/'stage_status.json',status)
    csv_write(out/'screening.csv',[{k:r.get(k) for k in ['target','problem','prior','reference_usable','geometry_candidate','geometry_score','median_stiff_projector_rotation','median_MAP_metric_curvature_change','laplace_to_split_floor_ratio']} for r in screens])
    final=[r for r in rows if int(r['round']) in [0,cfg['gad']['rounds']]];csv_write(out/'final_metrics.csv',final)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    pictures=[];rank=[]
    for spec in cfg['targets']:
        rr=[r for r in rows if r['target']==spec['id'] and r['bank_variant']=='base']
        if not rr:continue
        fig,axes=plt.subplots(2,3,figsize=(12,7));fig.suptitle(spec['id']+' | seed 42 | E+G+H request matching')
        keys=['RefSW2','RefFieldMeanRelL2','RefFieldStdRelL2','RefCovWhitenedRelFro','QoI1_CDF_error','QoI2_CDF_error']
        colors={'GAD':'#007d8a','pMALA':'#b34829'}
        for ax,key in zip(axes.ravel(),keys):
            for method in ['GAD','pMALA']:
                for init in ['prior','laplace']:
                    x=sorted([r for r in rr if r['method']==method and r['initialization']==init],key=lambda r:float(r['work']))
                    if x:ax.plot([float(r['work']) for r in x],[float(r[key]) for r in x],'-o' if init=='laplace' else '--s',color=colors[method],markersize=3,label=method+'/'+init)
            lap=next((r for r in rr if r['method']=='MAP-Laplace'),None)
            if lap:ax.axhline(float(lap[key]),color='#7363a6',linestyle=':',label='MAP-Laplace')
            if key=='RefSW2':ax.axhline(float(rr[0]['sampling_floor_SW2']),color='grey',linestyle=':',label='reference sample scale')
            if key not in ['QoI1_CDF_error','QoI2_CDF_error'] and all(float(r[key])>0 for r in rr):ax.set_yscale('log')
            ax.set_title(key);ax.set_xlabel('Energy + gradient + curvature requests');ax.grid(alpha=.2)
        axes.ravel()[0].legend(fontsize=7);fig.tight_layout()
        image=spec['id']+'_work.png';fig.savefig(out/image,dpi=160);fig.savefig(out/(spec['id']+'_work.pdf'));plt.close(fig);pictures.append(image)
        # Common unclipped scales preserve physical-field uncertainty comparisons.
        qdir=run/'targets'/spec['id']/'evaluation'
        ref_file=qdir/'reference.npz'
        if ref_file.exists():
            ref=npz(ref_file);truth=npz(ROOT/'frozen'/spec['problem']/'physical_spec.npz')['truth']
            columns=[('Truth',dict(field_mean=truth.ravel(),field_std=np.zeros(1024))),('NUTS',ref)]
            draw_curves=[('NUTS',ref['qoi'],'#253047','-')]
            choices=['MAP-Laplace']+[r['label'] for r in rr if r['method'] in ['GAD','pMALA'] and int(r['round'])==cfg['gad']['rounds']]
            for label in choices:
                file=qdir/(label.replace(' ','_')+'.npz')
                if not file.exists():continue
                record=next(r for r in rr if r['label']==label);values=npz(file)
                title='MAP-Laplace' if label=='MAP-Laplace' else record['method']+'/'+record['initialization']
                columns.append((title,values));color='#7363a6' if label=='MAP-Laplace' else colors[record['method']]
                draw_curves.append((title,values['qoi'],color,'--' if record['initialization']=='prior' else '-'))
            diag=next((r for r in rr if r['method']=='Cross-fit Gaussian'),None)
            if diag and (qdir/(diag['label'].replace(' ','_')+'.npz')).exists():
                values=npz(qdir/(diag['label'].replace(' ','_')+'.npz'));draw_curves.append(('Fitted Gaussian (diagnostic)',values['qoi'],'#999999',':'))
            fig,axes=plt.subplots(2,len(columns),figsize=(2.7*len(columns),5.8),squeeze=False)
            means=np.concatenate([x['field_mean'].ravel() for _,x in columns]);max_sd=max(float(x['field_std'].max()) for _,x in columns)
            for i,(title,values) in enumerate(columns):
                axes[0,i].set_title(title,fontsize=9)
                im=axes[0,i].imshow(values['field_mean'].reshape(32,32),origin='lower',vmin=means.min(),vmax=means.max(),cmap='RdBu_r')
                sd=axes[1,i].imshow(values['field_std'].reshape(32,32),origin='lower',vmin=0,vmax=max(max_sd,1e-15),cmap='viridis')
                for ax in axes[:,i]:ax.set_xticks([]);ax.set_yticks([])
            axes[0,0].set_ylabel('Field mean');axes[1,0].set_ylabel('Field SD')
            fig.colorbar(im,ax=axes[0,:].tolist(),fraction=.015,pad=.01);fig.colorbar(sd,ax=axes[1,:].tolist(),fraction=.015,pad=.01)
            fig.suptitle(spec['id']+' | shared unclipped field scales',fontsize=12)
            name=spec['id']+'_fields';fig.savefig(out/(name+'.png'),dpi=160,bbox_inches='tight');fig.savefig(out/(name+'.pdf'),bbox_inches='tight');plt.close(fig);pictures.append(name+'.png')
            fig,axes=plt.subplots(1,2,figsize=(12,4.5))
            titles={'navier_stokes':['Initial enstrophy','Final right-half flow energy'],'allen_cahn':['Initial positive-phase area','Smoothed interface length'],'helmholtz':['Hidden-region mean contrast','Held-out complex response power']}[spec['problem']]
            for k,ax in enumerate(axes):
                for label,q,color,style in draw_curves:
                    x=np.sort(q[:,k]);ax.step(x,np.arange(1,len(x)+1)/len(x),where='post',label=label,color=color,linestyle=style,linewidth=1.4)
                ax.set_title(titles[k]);ax.set_ylabel('Posterior CDF');ax.grid(alpha=.2)
            axes[0].legend(fontsize=7);fig.suptitle(spec['id']+' | final physical observables');fig.tight_layout()
            name=spec['id']+'_qoi';fig.savefig(out/(name+'.png'),dpi=160);fig.savefig(out/(name+'.pdf'));plt.close(fig);pictures.append(name+'.png')
        rank.extend(matched_comparisons(rr,cfg['gad']['rounds']))
    csv_write(out/'candidate_comparisons.csv',rank)
    state=read(run/'scheduler.json') if (run/'scheduler.json').exists() else {}
    esc=html.escape
    body=['<!doctype html><html><head><meta charset="utf-8"><title>GAD branch one</title><style>body{font:15px system-ui;margin:40px auto;max-width:1200px;color:#253047}table{border-collapse:collapse;font-size:12px}td,th{padding:7px;border:1px solid #ddd}th{background:#eef3f5}img{width:100%}pre{white-space:pre-wrap}</style></head><body>',
        '<h1>GAD application redesign: branch one</h1>',
        '<p>One fixed dataset and sampler seed 42. Primary axis: charged E+G+H requests. Prior and MAP-Laplace starts are shown separately. Failed or unresolved references do not establish a method ranking. Field moments use all pMALA production states, including rejections; expensive QoIs use a fixed stratified evaluation cap. Wall time is supplementary.</p>',
        '<p><a href="all_metrics.csv">All metrics CSV</a> · <a href="final_metrics.csv">Final metrics CSV</a> · <a href="screening.csv">Screening CSV</a> · <a href="candidate_comparisons.csv">Provisional candidate comparisons</a></p>',
        '<h2>Resource accounting</h2><pre>'+esc(str(state.get('accounting',{})))+'</pre>',
        '<h2>Stage status</h2><pre>'+esc('\n'.join(f"{s['target']} / {s['stage']}: {s.get('state')} {s.get('reason','')}" for s in status))+'</pre>']
    columns=['target','method','initialization','round','bank_variant','reference_usable','work','RefSW2','RefFieldMeanRelL2','RefFieldStdRelL2','QoI1_CDF_error','QoI2_CDF_error']
    body+=['<h2>Final results and Gaussian controls</h2><table><tr>'+''.join('<th>'+esc(k)+'</th>' for k in columns)+'</tr>']
    for r in final:body.append('<tr>'+''.join('<td>'+esc(str(r.get(k,'')))+'</td>' for k in columns)+'</tr>')
    body+=['</table>']+['<img src="'+esc(p)+'" alt="Accuracy versus work">' for p in pictures]+['</body></html>']
    (out/'dashboard.html').write_text('\n'.join(body));return out
