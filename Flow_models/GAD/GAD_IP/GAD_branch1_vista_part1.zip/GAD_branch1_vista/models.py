"""Pure JAX solvers bound to the exact archived bases/constants, without imports that regenerate data."""
import numpy as np
import jax
import jax.numpy as jnp
from io_utils import ROOT, npz
jax.config.update('jax_enable_x64', True)

class Physics:
    def __init__(self, problem, obs_time=.33, dt_scale=1.):
        self.problem = problem
        folder = ROOT/'frozen'/problem
        self.arrays = npz(folder/'target_arrays.npz')
        self.constants = npz(folder/'target_constants.npz')
        self.physical = npz(folder/'physical_spec.npz')
        self.B = jnp.asarray(self.arrays['basis']); self.dim = self.B.shape[1]
        self.N = 32; self.obs_time = obs_time; self.dt_scale = dt_scale
        c = {k: jnp.asarray(v) for k,v in self.constants.items()}
        if problem == 'navier_stokes':
            f = 2*jnp.pi*jnp.fft.fftfreq(32, d=1/32)
            KX, KY = jnp.meshgrid(f, f, indexing='ij')
            self.KX, self.KY = KX, KY
            dt = .05*dt_scale
            nu = .00075
            cn_num, cn_den = 1-.5*dt*nu*c['K2'], 1+.5*dt*nu*c['K2']
            def step(_, hat):
                hat = hat*c['DEALIAS']
                psi = jnp.where(c['K2']==0, 0., -hat/c['K2_safe'])
                vx = jnp.fft.ifftn(1j*KY*psi).real
                vy = jnp.fft.ifftn(-1j*KX*psi).real
                wx = jnp.fft.ifftn(1j*KX*hat).real
                wy = jnp.fft.ifftn(1j*KY*hat).real
                adv = jnp.fft.fftn(vx*wx+vy*wy)*c['DEALIAS']
                out = ((cn_num*hat-dt*adv+dt*c['forcing_hat'])/cn_den)*c['DEALIAS']
                return jnp.where(c['K2']==0, 0., out)
            def state(x):
                initial = self.field(x)
                hat = jax.lax.fori_loop(0, int(round(10.5/dt)), jax.checkpoint(step), jnp.fft.fftn(initial))
                return jnp.fft.ifftn(hat).real
        elif problem == 'allen_cahn':
            dt = .0005*dt_scale
            f = 2*jnp.pi*jnp.fft.fftfreq(32, d=1/32)
            kx, ky = jnp.meshgrid(f, f, indexing='ij')
            denom = 1/(1+dt*.045**2*(kx*kx+ky*ky))
            def step(_, u):
                return jnp.fft.ifftn(jnp.fft.fftn(u+dt*(u-u**3))*denom).real
            def state(x):
                return jax.lax.fori_loop(0, int(round(obs_time/dt)), jax.checkpoint(step), self.field(x))
        elif problem == 'helmholtz':
            source = c['source_terms_jax']; bg = c['BACKGROUND_FIELDS']
            def state(x):
                contrast = self.field(x).ravel()
                A = c['BACKGROUND_OPERATOR'] - jnp.diag(24.**2*contrast.astype(jnp.complex128))
                return jnp.linalg.solve(A, source)-bg
        else: raise ValueError(problem)
        self.state = jax.jit(state)

    def field(self, x):
        raw = (self.B@x).reshape(32,32)
        if self.problem == 'navier_stokes':
            u = float(self.physical['scale'])*raw
            return u-u.mean()
        if self.problem == 'helmholtz': return .45*jnp.asarray(self.physical['mask'])*jnp.tanh(raw)
        return raw

    def velocity(self, omega):
        c = self.constants
        psi = jnp.where(jnp.asarray(c['K2'])==0, 0., -jnp.fft.fftn(omega)/jnp.asarray(c['K2_safe']))
        return jnp.stack([jnp.fft.ifftn(1j*self.KY*psi).real, jnp.fft.ifftn(-1j*self.KX*psi).real])

    def observe(self, x, design, heldout=False):
        state = self.state(x)
        key = 'holdout' if heldout else 'train'
        kind = design['kind']
        if kind == 'original':
            a = self.arrays
            if self.problem == 'navier_stokes':
                u = jnp.fft.ifftn(jnp.fft.fftn(state)*jnp.asarray(self.constants['OBS_FILTER'])).real
                return u.ravel()[jnp.asarray(a['obs_indices_holdout' if heldout else 'obs_indices_train'])]
            if self.problem == 'allen_cahn':
                return state.ravel()[jnp.asarray(a['obs_indices_holdout' if heldout else 'obs_indices_train'])]
            inds = a['holdout_receiver_flat_indices' if heldout else 'receiver_flat_indices']
            z = state[jnp.asarray(inds), :]
            return jnp.stack([z.real.T,z.imag.T],axis=1).reshape(-1)
        if kind == 'velocity':
            return self.velocity(state).reshape(2,-1)[:,jnp.asarray(design[key+'_indices'])].reshape(-1)
        if kind == 'patch':
            if heldout: return state.ravel()[jnp.asarray(design['holdout_indices'])]
            return state.ravel()[jnp.asarray(design['patch_indices'])].mean(axis=1)
        if kind == 'aperture':
            pairs = jnp.asarray(design[key+'_pairs'])
            z = state[pairs[:,0],pairs[:,1]]
            return jnp.concatenate([z.real,z.imag])
        raise ValueError(kind)

    def qoi(self, x, design):
        field = self.field(x)
        if self.problem == 'allen_cahn':
            dx = (jnp.roll(field,-1,axis=0)-field)*32
            dy = (jnp.roll(field,-1,axis=1)-field)*32
            delta = .1
            area = jnp.mean(field>0)
            length = jnp.mean(jnp.exp(-.5*(field/delta)**2)/(jnp.sqrt(2*jnp.pi)*delta)*jnp.sqrt(dx*dx+dy*dy+1e-12))
            return jnp.array([area,length])
        if self.problem == 'navier_stokes':
            v = self.velocity(self.state(x))
            return jnp.array([.5*jnp.mean(field*field), .5*jnp.mean(jnp.sum(v*v,axis=0)[16:,:])])
        hidden = field[:,16:].mean()
        pred = self.observe(x,design,True)
        return jnp.array([hidden,jnp.mean(pred*pred)*2])

    def validate_original(self):
        p = npz(ROOT/'frozen'/self.problem/'target_probes.npz')
        errors = []
        for x, train, hold in zip(p['alpha'],p['train'],p['holdout']):
            a = np.asarray(self.observe(jnp.asarray(x),{'kind':'original'}))
            b = np.asarray(self.observe(jnp.asarray(x),{'kind':'original'},True))
            np.testing.assert_allclose(a,train,rtol=3e-9,atol=2e-11)
            np.testing.assert_allclose(b,hold,rtol=3e-9,atol=2e-11)
            errors.append(float(max(abs(a-train).max(),abs(b-hold).max())))
        np.testing.assert_allclose(np.asarray(self.field(jnp.asarray(self.arrays['alpha_true_np']))),self.physical['truth'],rtol=1e-10,atol=1e-11)
        return errors
