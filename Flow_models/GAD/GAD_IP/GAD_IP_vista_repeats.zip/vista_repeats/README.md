# GAD inverse-problem repetitions on Vista

This add-on runs exactly ten ordinary Darcy-flow and ten Navier–Stokes
experiments using the defaults in the supplied GAD_IP source. It does not run
ns_multimodal, darcy_compute_frontier, or the offline NUTS reference script.

## Start

Place this `vista_repeats/` directory directly inside the existing `GAD_IP/`
directory, alongside `sampling.py`, `aggregate_tables.py`, `darcy_flow/`, and
`navier_stokes/`. From GAD_IP:

```bash
bash vista_repeats/submit_repeats.sh
squeue -u "$USER"
```

The command submits a 20-task GPU array and a dependent aggregation job. Tasks
0–9 are Darcy seeds 42–51; tasks 10–19 are Navier–Stokes seeds 42–51. No
multimodal experiment is submitted. Each task uses the supplied launcher's
`gh` partition, one node, one task, and two-hour limit. The aggregation job
also uses `gh`, for ten minutes, to reuse the known working environment; it
does not run inference. No Slurm array concurrency cap is imposed.

Your existing `$SCRATCH/venvs/hlsi` environment must contain GPU-enabled JAX,
PyTorch, numpy, pandas, scipy, and matplotlib. The scripts load gcc/13.2.0
and python3/3.11.8, matching the supplied launcher. Override the environment
path with `IP_VENV_DIR=/absolute/path/to/venv` if necessary.

Optional sbatch flags apply to the GPU array:

```bash
bash vista_repeats/submit_repeats.sh -A YOUR_ALLOCATION -t 04:00:00
```

No allocation was hard-coded in the supplied launcher, so none is invented
here. If your site requires an explicit account for *both* jobs, export
`SBATCH_ACCOUNT` before submission. The defaults preserve the existing
two-hour GPU job limit; adequacy for all new seeds must be checked from the
actual run logs.

## What changes, and what remains the current configuration

The original files are left intact. Submission creates a unique directory
`batches/ip_repeats_<timestamp>_<pid>/` and snapshots the two experiment
scripts, sampling.py, the supplied aggregator, and this launcher. In the
snapshot only:

* Both hard-coded `seed = 42` assignments read `IP_RUN_SEED`, default 42.
* Darcy's `from gad_sampling import` uses the supplied `sampling.py`.
* Old command hints use the actual filenames and selected seed.

Each repetition gets a separate script copy, working directory, data files,
results, and status record. This avoids the shared `data/Basis.csv` and
`data/obs_locations.csv` races in concurrent runs of the original scripts.
The launcher chooses darcy_flow/darcy.py explicitly rather than the missing
darcy_flow/darcy_flow.py expected by run_one.slurm.

Inherited `IP_ITER_*`, `IP_MALA_*`, `IP_DARCY_ITER_*`, and `IP_NAVIER_ITER_*`
variables are cleared before each experiment, so these runs use the uploaded
source defaults. Discarded values are recorded in status.json. No scientific
sampler, solver, or evaluation code is otherwise modified.

| Setting | Darcy | Navier–Stokes |
|---|---:|---:|
| Master seeds | 42–51 | 42–51 |
| Grid | 32 x 32, boundary included | 32 x 32, periodic |
| Latent coefficients | 32 | 36 |
| Reference bank and generated cloud per round | 1,000 | 2,000 |
| GAD rounds executed | 1, 2, 3 | 1, 2, 3 |
| GAD rounds in tables | 1 and 3 | 1 and 3 |
| Reverse SDE steps per round | 200 | 200 |
| Reverse diffusion interval | 10 to 10^(-2.5) | 10 to 10^(-2.5) |
| Reverse SDE integrator | stochastic reverse-OU Heun | stochastic reverse-OU Heun |
| Reference/gate coupling | shared bank | shared bank |
| Clean Hessian proxy | Gaussian prior + Gauss–Newton likelihood | same |
| Hessian spectral band | [1e-6, 1e6] | [1e-6, 1e6] |
| Curvature ridge | 1e-6 | 1e-6 |
| Training / held-out sensors | 120 / 30 | 80 / 40 |
| Observation noise SD | 0.001 | 0.005 |
| Truth coefficient SD | 0.5 | 0.6 |
| Prior in inference | N(0, I_32) | N(0, I_36) |
| MALA parallel chains | 32 | 32 |
| MALA initial step size | 1e-4 | 1e-4 |
| MALA warmup transitions/chain | 107 | 217 |
| MALA retained draws/chain before truncation | 32 | 63 |
| MALA thinning | 1 | 1 |
| MALA target acceptance | 0.574 | 0.574 |
| MALA step-size bounds | [1e-12, 1e-1] | [1e-12, 1e-1] |
| GAD round-3 cumulative work proxy | 9,000 | 18,000 |
| MALA work proxy | 8,960 | 17,984 |

MALA is prior-initialized, uses the exact posterior score, adapts step size
only during warmup, and freezes the production kernel. The first 1,000 or
2,000 flattened post-warmup draws are retained; the surplus is truncated by
the existing sampler. These are work-proxy comparisons; do not describe the
budgets as matched wall time or full end-to-end FLOPs.

Darcy uses covariance exp(-distance/0.1) on the grid, 100 computed eigenmodes,
the leading 32 scaled by square-root eigenvalues, unit forcing, homogeneous
Dirichlet pressure boundaries, harmonic face averages, and a differentiable
dense solve for 900 interior pressure unknowns.

Navier–Stokes uses 120 generated periodic real Fourier modes truncated to 36,
anisotropic spectral envelope length scales (0.075, 0.13), initial-vorticity
scale 1.2, viscosity 7.5e-4, timestep 0.05, horizon 10.5 (210 steps), explicit
advection, Crank–Nicolson viscosity and 2/3 dealiasing. The observation Fourier
blur uses cutoffs (8, 4). Exact forcing, sensor-candidate construction, and
basis ordering are retained in the snapshot script. The selected masks and
generated arrays are saved separately for each realization.

The master seed changes sensor choice, truth, training and held-out noise,
and sampler randomness. This is uncertainty across ten *synthetic problem
realizations*, not ten sampler-only restarts for one fixed posterior. GAD
and MALA share the same inverse problem within each seed, so comparisons
are paired. Seed 42 retains the original master seed. Exact bitwise agreement
across library versions or GPU backends is not asserted.

## Aggregation and the manuscript handoff

The batch path and two job IDs are printed at submission. Aggregation runs
after the entire array terminates, including failures. It refuses to produce
final tables unless all 20 tasks record successful completion. Completed
jobs with a missing/nonfinite metric are explicitly flagged by their metric
counts. Earlier results outside this batch are never included.

Each successful batch contains:

* `meta_results/darcy_flow/meta_metrics.csv` and
  `meta_results/navier_stokes/meta_metrics.csv`: the supplied aggregator's
  formatted mean +/- sample SD tables.
* `meta_results/<problem>/headline_table.tex`: tabular snippets matching the
  manuscript's two headline tables, with mean +/- sample SD and no automatic
  boldface selection.
* `meta_results/secondary_table.tex`: the manuscript's secondary diagnostic
  and work table, also with mean +/- sample SD.
* `meta_results/metrics_per_seed.csv` and `metrics_numeric.csv`: complete
  numeric metrics and finite counts.
* `meta_results/paired_contrasts.csv`: GAD3–MALA, GAD1–MALA, and GAD3–GAD1
  paired differences, sample SDs, and descriptive 95% percentile-bootstrap
  intervals for mean differences (10,000 resamples; seed 20261021).
* `meta_results/runinfo_per_seed.csv` and `runinfo_summary.csv`: work,
  runtime, acceptance, split R-hat, step size, and unique fractions. These
  populate secondary diagnostic/work tables; diagnostic NaNs are retained.
* `meta_results/aggregation_audit.json` and `completion_status.csv`: completion
  and nonfinite-data checks.
* `manuscript_update_inputs.zip`: tables, source snapshots, realization
  arrays, per-run parameter/environment records, and logs, for updating the
  supplied manuscript. Large plots and posterior arrays stay in the batch.

For each seed, under `<problem>/run_results/seed_<seed>/`, the full batch
retains exact sensor/truth/observation/basis arrays in `realization.npz`, the
posterior sample banks in `posterior_samples.npz`, `pip_freeze.txt`, and
`status.json`. Nested experiment `run_results/` contains its original CSVs,
parameter log, figures, dashboard, and run ZIP. The top-level manifest
records both uploaded-source and executed-source SHA-256 hashes. Actual
hardware, JAX/PyTorch/CUDA versions, wall time, Slurm metadata, and package
versions are recorded at run time, rather than inferred from the node type.

After completion, return `manuscript_update_inputs.zip` for incorporation into
the manuscript. Keep the full batch if representative figures or posterior
samples are needed. The manuscript has not been edited with unknown future
results. The numeric summary distinguishes reconstruction and predictive
metrics from MMD-to-MALA and the existing KLdiag diagnostic; the latter is
not a measured true KL. Ten seeds give limited precision and the bootstrap
intervals are not adjusted for multiple comparisons.

## Inspect failures or rerun aggregation

```bash
IP_BATCH_DIR=/absolute/path/printed/at/submission
cat "$IP_BATCH_DIR/completion_status.csv"
cat "$IP_BATCH_DIR/logs/aggregate-"*.out
```

On a login node with the same Python environment loaded, aggregation can be
rerun without inference:

```bash
python "$IP_BATCH_DIR/source/manage.py" aggregate --batch "$IP_BATCH_DIR"
```

To retry a failed task, first move that seed's complete working directory
out of `<problem>/run_results/` to a separate `failed_attempts/` directory
inside the batch, preserving it for diagnosis. Then resubmit the relevant
array index using the snapshot run_repeat.slurm and the same IP_BATCH_DIR.
Do not leave two attempts under the problem's run_results/ tree, since the
legacy aggregator recursively includes all metrics files there. Re-run
aggregation after the retry completes. A running job terminated by Slurm
may retain status `running`; it will still be rejected during aggregation.

## Validation performed before delivery

The launcher syntax and Python compilation were checked locally. Snapshot
preparation and aggregation were exercised with a synthetic 20-run fixture,
including rejection of an incomplete batch. No GPU inverse-problem run or
live Vista submission was performed in this workspace.
