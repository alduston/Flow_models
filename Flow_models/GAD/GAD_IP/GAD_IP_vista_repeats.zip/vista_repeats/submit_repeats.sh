#!/bin/bash
# Run from GAD_IP, or invoke this script by its path from anywhere.
set -euo pipefail
IP_TOOLS_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
IP_ROOT="$(cd -- "$IP_TOOLS_DIR/.." && pwd)"
IP_BATCH_DIR="$IP_ROOT/batches/ip_repeats_$(date +%Y%m%d_%H%M%S)_$$"
command -v sbatch >/dev/null
command -v python3 >/dev/null
python3 "$IP_TOOLS_DIR/manage.py" prepare --root "$IP_ROOT" --batch "$IP_BATCH_DIR"
export IP_BATCH_DIR

# Optional sbatch flags (e.g. -A ACCOUNT or -t 04:00:00) apply to the GPU array.
IP_RUN_JOB=$(sbatch --parsable "$@" --array=0-19 \
  --export=ALL,IP_BATCH_DIR="$IP_BATCH_DIR" \
  --output="$IP_BATCH_DIR/logs/run-%A_%a.out" \
  "$IP_BATCH_DIR/source/run_repeat.slurm")
IP_RUN_JOB="${IP_RUN_JOB%%;*}"
printf '%s\n' "$IP_RUN_JOB" > "$IP_BATCH_DIR/run_job_id.txt"
# afterany lets the strict validator report failures instead of silently
# producing a table from fewer than ten repetitions.
IP_AGG_JOB=$(sbatch --parsable --dependency="afterany:$IP_RUN_JOB" \
  --export=ALL,IP_BATCH_DIR="$IP_BATCH_DIR" \
  --output="$IP_BATCH_DIR/logs/aggregate-%j.out" \
  "$IP_BATCH_DIR/source/aggregate_repeats.slurm")
IP_AGG_JOB="${IP_AGG_JOB%%;*}"
printf '%s\n' "$IP_AGG_JOB" > "$IP_BATCH_DIR/aggregate_job_id.txt"
printf 'Batch: %s\nGPU array: %s (20 tasks)\nAggregation: %s\n' \
  "$IP_BATCH_DIR" "$IP_RUN_JOB" "$IP_AGG_JOB"
printf 'Monitor: squeue -u "$USER"\nResults: %s/meta_results/\n' "$IP_BATCH_DIR"
