"""CPU tests of orchestration and statistics. Fixtures are synthetic, not PDE results."""
import argparse
import ast
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from types import SimpleNamespace
import numpy as np
import pandas as pd

BUNDLE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BUNDLE / "source"))
import manage
from darcy_problem_data import fingerprint, validate_reference
from aggregate_frontier import METRICS, aggregate, mean_ci


def fixture(parent):
    """Build an internally consistent fake reference and ten scored runs."""
    parent = Path(parent)
    parent.mkdir(parents=True, exist_ok=True)
    bundle = parent / "bundle"
    shutil.copytree(BUNDLE, bundle, ignore=shutil.ignore_patterns("__pycache__"))
    cfg = json.loads((bundle / "run_settings.json").read_text())
    cfg["problem"].update(grid_size=8, latent_dim=2, n_observations=20, n_holdout=8)
    (bundle / "run_settings.json").write_text(json.dumps(cfg))
    batch = parent / "synthetic_batch"
    manage.prepare(argparse.Namespace(bundle=bundle, batch=batch, reference_dir=None))
    p = SimpleNamespace(**cfg["problem"])
    rng = np.random.default_rng(20261022)
    arrays = {"basis": rng.normal(size=(64, 2)), "alpha_true": rng.normal(size=2),
              "y_obs": rng.normal(size=20), "y_clean": rng.normal(size=20),
              "obs_locations_train": np.arange(20, dtype=np.int32),
              "obs_locations_holdout": np.arange(20,28,dtype=np.int32)}
    arrays["problem_fingerprint"] = np.asarray(fingerprint(p, arrays))
    ref = batch / "reference"
    np.savez_compressed(ref / "problem_data.npz", **arrays)
    chains = rng.normal(size=(4,5000,2))
    np.savez_compressed(ref / "reference_samples.npz", **arrays, certified=True,
                        samples=chains.reshape(-1,2), samples_by_chain=chains)
    thresholds = {"max_rhat":1.01,"min_bulk_ess":1000.,"min_tail_ess":400.,"max_divergences":0,
                  "max_tree_depth_fraction":.01,"min_ebfmi":.3,"min_mean_accept":.8}
    names = ["convergence_diagnostics_finite","kernel_diagnostics_finite","rank_rhat","bulk_ess",
             "tail_ess","divergences","tree_depth","ebfmi","acceptance"]
    diagnostics = dict(certified=True, thresholds=thresholds, checks={name:True for name in names})
    (ref / "nuts_diagnostics.json").write_text(json.dumps(diagnostics))
    refcfg = {"arguments": {**cfg["problem"], **cfg["nuts"]},
              "problem_fingerprint": str(arrays["problem_fingerprint"].item())}
    (ref / "run_config.json").write_text(json.dumps(refcfg))
    audit = validate_reference(ref,p)
    for i, seed in enumerate(cfg["sampler_seeds"]):
        run = batch / "runs" / f"seed_{seed}"
        result = run / "attempt_fixture" / "darcy_mala_gad_compute_frontier_fixture"
        result.mkdir(parents=True)
        config = {**cfg["problem"],**cfg["frontier"],"seed":seed,"selected_methods":["gad_lfgi"],
                  **{key:audit[key] for key in ["reference_sha256","problem_fingerprint","problem_data_sha256"]}}
        (result / "run_config.json").write_text(json.dumps(config))
        rows, index, banks = [], [], {}
        for method, costs, errors in [("mcmc",[0,30,60,90],[4,2,1.3,1]),
                                       ("gad_lfgi",[18,36,54,72],[.4,.09,.06,.07])]:
            for k,(cost,error) in enumerate(zip(costs,errors)):
                row = dict(method=method,total_flops=cost*1e12,gad_round=k if method=="gad_lfgi" else np.nan,
                           base_transition=k*30, sampler_seed=seed)
                for j,(metric,_) in enumerate(METRICS):
                    row[metric] = error * (.92+.025*i) * (.3+.6*j)
                rows.append(row)
                key = f"record_{len(banks):04d}"
                banks[key] = rng.normal(size=(1000,2))
                index.append(dict(sample_key=key,method=method,total_flops=cost*1e12))
        pd.DataFrame(rows).to_csv(result / "functional_compute_frontier.csv",index=False)
        pd.DataFrame(index).to_csv(result / "frontier_sample_index.csv",index=False)
        np.savez_compressed(result / "frontier_samples.npz",**banks)
        files = ["functional_compute_frontier.csv","frontier_samples.npz","frontier_sample_index.csv"]
        manage.write_json(run / "status.json", dict(status="complete",sampler_seed=seed,
            result_directory=str(result.relative_to(run)), artifact_sha256={name:manage.digest(result/name) for name in files}))
    return batch


class WorkflowTests(unittest.TestCase):
    def test_reference_binding_and_rejection(self):
        with tempfile.TemporaryDirectory() as temp:
            batch = fixture(temp)
            args = manage.problem_args(batch)
            self.assertEqual(validate_reference(batch/"reference",args)["reference_particles"],20000)
            path=batch/"reference/problem_data.npz"
            with np.load(path) as z:
                values={k:np.array(z[k]) for k in z.files}
            values["basis"][0,0]+=.001
            np.savez_compressed(path,**values)
            with self.assertRaisesRegex(ValueError,"fingerprint"):
                validate_reference(batch/"reference",args)

    def test_uncertified_reference_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            batch=fixture(temp)
            path=batch/"reference/nuts_diagnostics.json"
            d=json.loads(path.read_text());d["certified"]=False;path.write_text(json.dumps(d))
            with self.assertRaisesRegex(ValueError,"diagnostics"):
                validate_reference(batch/"reference",manage.problem_args(batch))

    def test_bootstrap_and_incomplete_batch(self):
        values=np.arange(1,11,dtype=float)[:,None]
        draws=np.random.default_rng(1).integers(0,10,(5000,10))
        mean,sd,ci=mean_ci(values,draws,.95)
        self.assertAlmostEqual(mean[0],5.5)
        self.assertAlmostEqual(sd[0],np.std(values,ddof=1))
        self.assertLess(ci[0,0],5.5);self.assertGreater(ci[1,0],5.5)
        with tempfile.TemporaryDirectory() as temp:
            batch=fixture(temp)
            (batch/"runs/seed_51/status.json").unlink()
            with self.assertRaisesRegex(ValueError,"Incomplete/invalid"):
                aggregate(batch,qa_label="SYNTHETIC TEST")
            self.assertFalse((batch/"meta_results/gad_v_mala_darcy_uncertainty.pdf").exists())

    def test_prepared_solver_preserved(self):
        original=ast.parse((BUNDLE/"source/darcy_nuts_offline_reference_20260821_v3.py").read_text())
        copied=ast.parse((BUNDLE/"source/_prepared_solver.py").read_text())
        old=next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name=="build_problem_from_prepared_arrays")
        new=next(n for n in copied.body if isinstance(n,ast.FunctionDef))
        body=[n for n in new.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
        self.assertEqual(ast.dump(ast.Module(body=old.body,type_ignores=[])),
                         ast.dump(ast.Module(body=body,type_ignores=[])))

    def test_scheduler_dependencies_and_partial_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            temp=Path(temp);bin_=temp/"bin";bin_.mkdir()
            fakepython=bin_/"python"
            fakepython.write_text(f'#!{sys.executable}\nimport os,sys\nif len(sys.argv)>1 and sys.argv[1].endswith("check_environment.py"):\n print("Dependency presence check stub for scheduler test")\nelse:\n os.execv({sys.executable!r},[{sys.executable!r},*sys.argv[1:]])\n')
            sbatch=bin_/"sbatch"
            sbatch.write_text(f'#!{sys.executable}\nimport os,json,sys\nfrom pathlib import Path\np=Path(os.environ["FAKE_CALLS"])\na=json.loads(p.read_text()) if p.exists() else []\na.append(sys.argv[1:]);p.write_text(json.dumps(a))\nif len(a)==5 and os.getenv("FAIL_AGG")=="1":\n print("Simulated accounting rejection",file=sys.stderr);sys.exit(1)\nprint("Site wrapper: diagnostic preamble")\nprint("Submitted batch job "+str(9000+len(a)))\n')
            squeue=bin_/"squeue";squeue.write_text('#!/bin/bash\n[[ "${FAKE_ACTIVE:-0}" == 0 ]] || echo "9004 RUNNING"\nexit 0\n')
            for p in bin_.iterdir():
                p.chmod(0o755)
            env={**os.environ,"PATH":str(bin_)+os.pathsep+os.environ['PATH'],"DF_SKIP_MODULES":"1",
                 "DF_BATCH_PARENT":str(temp/"batches"),"FAKE_CALLS":str(temp/"calls.json")}
            proc=subprocess.run(['bash',str(BUNDLE/'submit.sh'),'--account','TEST','--max-parallel','3'],env=env,text=True,capture_output=True)
            self.assertEqual(proc.returncode,0,proc.stdout+proc.stderr)
            calls=json.loads((temp/'calls.json').read_text());self.assertEqual(len(calls),5)
            self.assertIn('--dependency=afterok:9001',calls[1])
            self.assertIn('--dependency=afterok:9002',calls[2])
            self.assertIn('--dependency=afterok:9003',calls[3])
            self.assertIn('--dependency=afterany:9004',calls[4])
            self.assertIn('--array=0-9%3',calls[3])
            for call in calls:self.assertEqual(call[:2],['--parsable','-A'])
            batch=next((temp/'batches').iterdir())
            self.assertEqual((batch/'aggregate_job_id.txt').read_text().strip(),'9005')
            env['FAKE_ACTIVE']='1'
            resume=subprocess.run(['bash',str(BUNDLE/'submit.sh'),'--resume-batch',str(batch)],env=env,text=True,capture_output=True)
            self.assertEqual(resume.returncode,2)
            self.assertEqual(len(json.loads((temp/'calls.json').read_text())),5)
            env.update(FAIL_AGG='1',DF_BATCH_PARENT=str(temp/'failed'),FAKE_CALLS=str(temp/'failed_calls.json'))
            failed=subprocess.run(['bash',str(BUNDLE/'submit.sh')],env=env,text=True,capture_output=True)
            self.assertNotEqual(failed.returncode,0)
            batch=next((temp/'failed').iterdir())
            self.assertEqual((batch/'run_job_id.txt').read_text().strip(),'9004')
            self.assertFalse((batch/'aggregate_job_id.txt').exists())


if __name__ == '__main__':
    unittest.main()
