# Darcy matched-compute frontier with uncertainty

This is a Vista run bundle for replacing the supplied six-panel Darcy posterior-functional error figure. It runs ten independent copies of the **matched-compute frontier experiment**, rather than rerunning the separate reconstruction-table experiment in `darcy.py`.

## Submit

Unzip this directory inside your existing `GAD_IP` directory:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP
unzip GAD_darcy_frontier_repeats.zip
bash darcy_frontier_repeats/submit.sh
```

The launcher uses the same Vista modules and `$SCRATCH/venvs/hlsi` environment as the completed Darcy/Navier–Stokes repeats. It checks dependency presence before submission. If NumPyro or ArviZ is missing, run the optional installer and submit again:

```bash
bash darcy_frontier_repeats/install_reference_extras.sh
bash darcy_frontier_repeats/submit.sh
```

The installer constrains every currently installed distribution to its existing version, preserving the working JAX/CUDA/PyTorch stack. If the constraints cannot be satisfied, it stops rather than replacing that stack. The compute jobs also check that both JAX and PyTorch see the GPU. An alternative working venv can be selected with `DF_VENV_DIR=/absolute/venv/path`.

Submission options:

```bash
bash darcy_frontier_repeats/submit.sh --account YOUR_ACCOUNT --max-parallel 2
```

The default is at most two simultaneous frontier repeats. The four reference chains run independently on four GH nodes. `--account` applies to every stage, including aggregation. The launcher prints and saves every job ID immediately; it accepts both parsable Slurm IDs and site-wrapper output. If any submission fails, inspect the saved IDs before resuming, so already-submitted jobs are not duplicated.

## What runs

The default dependency sequence is:

1. Prepare one fixed Darcy problem, truth-blind multistart MAP, and exact-Hessian Laplace whitening.
2. Run four independently adapted, dense-mass NUTS chains, each with 3,000 warmup and 5,000 retained draws, target acceptance 0.95.
3. Finalize and check the reference diagnostics. Failed diagnostics stop the downstream experiment; there is no GAD-refined reference fallback and failed checks are not overridden.
4. Run frontier sampler seeds 42–51 as ten array tasks against that one fixed posterior and reference.
5. Validate all ten results, aggregate them, draw the uncertainty figure, and package the results.

The reference settings and approval checks are those of the supplied NUTS v3 builder: rank-normalized R-hat ≤1.01, bulk ESS ≥1000, tail ESS ≥400, zero divergences, tree-depth saturation ≤1%, E-BFMI ≥0.30, and mean acceptance ≥0.80. Passing them is a diagnostic assessment, not a proof of exact reference sampling. The diagnostic and chain-agreement outputs are retained for review.

Time requests are 2 hours for preparation, 12 hours per NUTS chain, 2 hours for finalization, 4 hours per frontier repeat, and 30 minutes for aggregation. These are scheduler reservations, not measured runtime predictions. Before submission, they can be changed through `DF_REFERENCE_PREP_TIME`, `DF_REFERENCE_CHAIN_TIME`, `DF_REFERENCE_FINAL_TIME`, and `DF_REPEAT_TIME`. For example:

```bash
DF_REPEAT_TIME=02:00:00 bash darcy_frontier_repeats/submit.sh
```

## Existing NUTS reference

The earlier conversation records point to Vista job **928140**, with output directory `run_results/darcy_nuts_reference_928140`. Searches recovered the reference builders and submission scripts but did not locate an uploaded reference sample archive. This bundle therefore regenerates it by default. The attached JPEG alone does not establish whether the earlier plot used NUTS or the frontier script's GAD-refined fallback.

If you locate the old complete reference directory, it can be reused:

```bash
bash darcy_frontier_repeats/submit.sh --reference-dir /absolute/path/to/darcy_nuts_reference_928140
```

The directory must contain `reference_samples.npz`, `problem_data.npz`, `nuts_diagnostics.json`, and `run_config.json`, with compatible problem parameters and the full, diagnostics-approved chain payload. The launcher copies and validates these before scheduling repeats. A bare sample cloud with unverified provenance is insufficient. Reusing a valid reference skips the reference jobs.

## Scientific configuration

The frozen `run_settings.json` is authoritative. The default problem is a 32×32 Darcy grid, 32 KL coefficients, exponential covariance kernel with correlation length 0.1 and unit variance, 120 training and 30 held-out interior pressure observations, noise standard deviation 0.001, and **fixed data seed 42**. The coefficient prior is standard Gaussian; the synthetic truth is drawn with coefficient standard deviation 0.5, as in the original frontier code.

The exact KL basis, observation indices, observations, and synthetic truth are committed once by reference preparation. Every repeat reconstructs the solver around those same arrays and checks the clean forward solution. A fingerprint also binds the reference samples to those arrays and problem settings. This avoids changing the coefficient-space posterior through independent eigendecompositions or data seeds.

Each repeat uses 1,000 parallel MALA chains/particles, prior initialization, ten base checkpoints over transitions 0–70, and 60 dual-averaging transitions targeting acceptance 0.574, from step size 1e-4. The native base checkpoints are 0, 8, 16, 23, 31, 39, 47, 54, 62, and 70. Adaptation is included in the cost. GAD uses the original q-LFGI–Gauss–Newton construction, 100 stochastic reverse-OU Heun steps, T=10, and t_min=10^(-2.5), with 1,000 particles and an unweighted 1,000-particle bank rebuilt after each round. MALA and GAD share the initial prior bank within each repeat.

Only MALA and recursive GAD are run, matching the two methods in the supplied figure. The extra MALA→LFGI and Dirichlet arms are disabled. The existing analytical model charges 17.558 TFLOP per bank and 0.570 TFLOP per transport, or **18.128 TFLOP per GAD round**. Its original horizon is approximately 87.383 TFLOP, retaining four complete GAD rounds at approximately 18.128, 36.256, 54.384, and 72.513 TFLOP. MALA continues through the same horizon. This is the recorded operation-count model, not measured hardware FLOPs; it includes every bank and transport and MALA initialization/adaptation. Compilation, offline reference construction, and scoring are excluded from the plotted axis. The model and measured times are archived per run.

The repeated frontier uses the supplied `darcy_compute_frontier.py`, NUTS v3 builder, and `sampling.py` (copied under its expected import name `gad_sampling.py`). `darcy.py` is retained for provenance and is not launched. Scientific transport and MALA routines are preserved. `frontier_changes.patch` shows the modifications: independent data/sampler seeds, immutable prepared-problem loading, reference validation, and endpoint-bank retention. Original source checksums are in `original_source_hashes.json`.

## Plot and uncertainty

The six errors are the coefficient posterior mean's whitened RMSE, relative coefficient covariance Frobenius error, relative L2 errors in the mean and standard deviation of log permeability, relative L2 error in mean permeability, and relative L2 error in held-out pressure evaluated at the coefficient posterior mean. Every error is compared with the common NUTS reference, not the synthetic truth. The pressure functional is not the posterior predictive mean. Metric normalization, covariance regularization, and the original permeability exponential clipping convention are stated in the generated setup text.

Curves show arithmetic means at native analytical FLOP checkpoints. Shading is a **pointwise 95% percentile-bootstrap confidence interval for the mean**, using 5,000 resamples of the ten complete seeds, with seed 20261022. The same bootstrap run indices are used for every metric, checkpoint, and method. These intervals are conditional on the shared reference and do not include its Monte Carlo error; its separate chain-agreement diagnostics are retained. No runs or particles are removed to improve the plot.

The plot uses a 3×2 layout at a native width of 6.45 inches, readable paper-scale fonts, embedded TrueType fonts in PDF, a 450-dpi PNG, logarithmic error axes, solid circles versus dashed diamonds, and matching confidence bands. This gives each panel more width than the original 2×3 layout. There is no curve smoothing, averaging across different compute budgets, or extrapolation. Matched-compute comparison tables interpolate MALA error only between bracketing native checkpoints at a GAD cost. Any exact zeros that require a display floor are disclosed in the generated caption and metadata; CSV values are never floored.

All ten valid runs are required before a publication figure is produced. The figure caption and appendix setup are generated with the results so uncertainty, reference provenance, units, normalization, and exclusions accompany the figure, in accordance with Gate 8 of the supplied staging guide.

## Outputs and recovery

The launcher prints a directory of the form `GAD_IP/batches/darcy_frontier_<timestamp>_<pid>/`. Monitor with `squeue -u "$USER"`. Its immediate job records are `reference_prepare_job_id.txt`, `reference_chains_job_id.txt`, `reference_finalize_job_id.txt`, `run_job_id.txt`, and `aggregate_job_id.txt` for the stages that were submitted. Logs live in `logs/`.

After completion:

- `meta_results/gad_v_mala_darcy_uncertainty.pdf`: publication figure; copy to `Figures/`.
- `meta_results/gad_v_mala_darcy_uncertainty.png`: high-resolution preview.
- `meta_results/figure_caption.tex`: replacement figure environment using the existing manuscript label.
- `meta_results/matched_compute_setup.tex`: matching reproducibility text and metric definitions.
- `meta_results/frontier_mean_uncertainty.csv`: mean, sample SD, CI, and seed count at each native checkpoint.
- `meta_results/all_seed_frontiers.csv`: all individual measurements.
- `meta_results/paired_matched_compute.csv` and `paired_difference_uncertainty.csv`: within-seed, matched-cost comparisons and their uncertainty.
- `meta_results/completion_audit.json`, `plot_metadata.json`, and `reference_diagnostics.json`: validation and plotting details.
- `runs/seed_*/attempt_*/`: original CSVs, configuration, sample banks, and logs.
- `reference/`: immutable problem, full NUTS chains and samples, and diagnostics.
- **`darcy_frontier_results.zip`**: the complete result bundle to return for manuscript integration.

To resume after an interruption or fix an aggregation submission failure:

```bash
bash darcy_frontier_repeats/submit.sh --resume-batch /absolute/path/to/the/batch
```

Wait until previously submitted jobs have finished or cancel obsolete dependent jobs first; the launcher refuses duplicate submissions while saved job IDs remain active. Completed NUTS chains are reused by the original `--resume` mechanism. Once a valid reference exists, only missing or failed frontier seeds are resubmitted. Completed seeds are checked against the frozen settings and artifact checksums. Failed attempts remain archived. Source/settings changes require a new batch. If NUTS diagnostics fail, inspect `reference/nuts_diagnostics.json`; the workflow does not silently loosen criteria or proceed with an uncertified cloud.

To rerun only aggregation after all ten runs complete:

```bash
sbatch --export=ALL,DF_BATCH_DIR=/absolute/path/to/the/batch \
  --output=/absolute/path/to/the/batch/logs/aggregate-manual-%j.out \
  /absolute/path/to/the/batch/slurm/aggregate.slurm
```

Local verification covered syntax, scheduler submission/dependency handling, fixed-problem/reference rejection checks, strict ten-seed aggregation, bootstrap behavior, and PDF/PNG layout with clearly labeled synthetic fixtures. The production PDE/NUTS jobs require Vista's working GPU environment and have not been executed by this bundle's preparation step. No generated fixture data or simulated result is included in the delivered run bundle. The CPU workflow checks can be rerun from this directory with `python -m unittest discover -s tests -v`; they use temporary files and a fake scheduler and submit no jobs.
