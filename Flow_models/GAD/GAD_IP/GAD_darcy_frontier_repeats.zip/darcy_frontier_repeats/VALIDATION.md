# Validation performed during bundle preparation

- Python source compilation and Bash syntax checks: passed.
- Five CPU workflow tests: passed. They cover reference fingerprint binding, rejection of unapproved NUTS references, bootstrap calculations, refusal of an incomplete ten-seed batch, preservation of the supplied prepared-array Darcy solver, scheduler dependencies, site-wrapper job ID parsing, active-job resubmission prevention, and partial submission failure.
- Full ten-seed aggregation on synthetic fixtures: passed, including mean/CI values, paired error differences, native cost-grid checks, endpoint-bank validation, and result-archive creation.
- Missing-seed selector: correctly returned only task 9 when seed 51's completion record was removed.
- Analytical cost model: unchanged; one GAD round is 18.128125256 TFLOP and the configured horizon is 87.382874128 TFLOP, retaining four complete GAD rounds.
- Generated PDF and PNG: visually checked at paper scale with a prominent synthetic-data watermark. The PDF embeds TrueType fonts. The production figure has no watermark.
- Figure caption and setup text: compiled at the manuscript's 11-point font and margins, with no overfull boxes, layout warnings, or figure-size overflow. The figure and caption fit together on one page.

Production NUTS/PDE sampling has **not** been run locally. This workspace does not have the Vista GPU/JAX/PyTorch environment. The bundle schedules those scientific runs on Vista, records the actual runtime environment, and requires reference approval and all ten completed repeats before producing the publication figure. Generated synthetic fixture data and layout-test figures are excluded from this bundle.
