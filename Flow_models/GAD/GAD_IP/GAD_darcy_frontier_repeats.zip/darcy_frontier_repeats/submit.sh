#!/bin/bash
set -eo pipefail
DF_BUNDLE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DF_REFERENCE_DIR=""
DF_RESUME_BATCH=""
DF_PARALLEL=2
DF_ACCOUNT_ARGS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --reference-dir) DF_REFERENCE_DIR="$2"; shift 2 ;;
    --resume-batch) DF_RESUME_BATCH="$2"; shift 2 ;;
    --max-parallel) DF_PARALLEL="$2"; shift 2 ;;
    --account|-A) DF_ACCOUNT_ARGS=(-A "$2"); shift 2 ;;
    *) printf 'Unknown argument: %s\n' "$1" >&2; exit 2 ;;
  esac
done
[[ "$DF_PARALLEL" =~ ^[1-9][0-9]*$ ]] || { echo '--max-parallel must be positive' >&2; exit 2; }
if [[ -n "$DF_RESUME_BATCH" && -n "$DF_REFERENCE_DIR" ]]; then
  echo 'Use --reference-dir only for a new batch; a resumed batch keeps its reference.' >&2; exit 2
fi
source "$DF_BUNDLE_DIR/slurm/environment.sh"
set -u
command -v sbatch >/dev/null
if [[ -n "$DF_RESUME_BATCH" ]]; then
  DF_BATCH_DIR="$(cd -- "$DF_RESUME_BATCH" && pwd)"
  # Avoid duplicate submissions while any previously submitted stage is alive.
  DF_OLD_IDS=$(python - "$DF_BATCH_DIR" <<'PY'
from pathlib import Path
import sys
print(','.join(sorted({p.read_text().strip() for p in Path(sys.argv[1]).glob('*_job_id.txt') if p.read_text().strip().isdigit()})))
PY
)
  if [[ -n "$DF_OLD_IDS" ]]; then
    if ! DF_QUEUE=$(squeue -h -u "$USER" -o '%i %T'); then
      echo 'Could not check active jobs; resubmission stopped to avoid duplicates.' >&2
      exit 2
    fi
    DF_ACTIVE=$(python - "$DF_OLD_IDS" "$DF_QUEUE" <<'PY'
import re,sys
saved=set(sys.argv[1].split(','))
for line in sys.argv[2].splitlines():
    match=re.match(r'\s*(\d+)',line)
    if match and match.group(1) in saved:
        print(line)
PY
)
    if [[ -n "$DF_ACTIVE" ]]; then
      printf 'This batch still has active jobs:\n%s\nWait for them or cancel obsolete dependent jobs before resuming.\n' "$DF_ACTIVE" >&2
      exit 2
    fi
  fi
else
  DF_BATCH_DIR="${DF_BATCH_PARENT:-$DF_BUNDLE_DIR/../batches}/darcy_frontier_$(date +%Y%m%d_%H%M%S)_$$"
  DF_PREP_ARGS=()
  [[ -z "$DF_REFERENCE_DIR" ]] || DF_PREP_ARGS=(--reference-dir "$DF_REFERENCE_DIR")
  python "$DF_BUNDLE_DIR/source/manage.py" prepare --bundle "$DF_BUNDLE_DIR" \
    --batch "$DF_BATCH_DIR" "${DF_PREP_ARGS[@]}"
  DF_BATCH_DIR="$(cd -- "$DF_BATCH_DIR" && pwd)"
fi
export DF_BATCH_DIR
printf 'Frozen batch: %s\n' "$DF_BATCH_DIR"
trap 'printf "Submission stopped. Inspect %s/logs/submit-*.log and *_job_id.txt. Resume with: bash %q --resume-batch %q\n" "$DF_BATCH_DIR" "$DF_BUNDLE_DIR/submit.sh" "$DF_BATCH_DIR" >&2' ERR

df_submit() {
  local df_stage="$1"
  shift
  local df_log="$DF_BATCH_DIR/logs/submit-${df_stage}-$(date +%s).log"
  if ! sbatch --parsable "${DF_ACCOUNT_ARGS[@]}" "$@" > "$df_log" 2>&1; then
    cat "$df_log" >&2
    return 1
  fi
  cat "$df_log" >&2
  python - "$df_log" "$DF_BATCH_DIR/${df_stage}_job_id.txt" <<'PY'
from pathlib import Path
import re,sys
text=Path(sys.argv[1]).read_text()
ids=re.findall(r'^\s*(?:Submitted batch job\s+)?([0-9]+)(?:;[^\s;]+)?\s*$',text,re.MULTILINE)
if not ids:
    sys.exit('No unambiguous Slurm job ID. Inspect the submission log before resubmitting.')
Path(sys.argv[2]).write_text(ids[-1]+'\n')
print(ids[-1])
PY
}

DF_REFERENCE_READY=0
if [[ -f "$DF_BATCH_DIR/reference/reference_samples.npz" ]]; then
  python "$DF_BATCH_DIR/source/manage.py" validate-reference --batch "$DF_BATCH_DIR"
  DF_REFERENCE_READY=1
fi
DF_RUN_DEP=()
if [[ "$DF_REFERENCE_READY" == 0 ]]; then
  python "$DF_BATCH_DIR/source/check_environment.py" --imports-only --nuts
  DF_PREP_JOB=$(df_submit reference_prepare --time="${DF_REFERENCE_PREP_TIME:-02:00:00}" \
    --export=ALL,DF_BATCH_DIR="$DF_BATCH_DIR",DF_STAGE=nuts-prepare \
    --output="$DF_BATCH_DIR/logs/nuts-prepare-%j.out" "$DF_BATCH_DIR/slurm/reference.slurm")
  DF_CHAIN_JOB=$(df_submit reference_chains --time="${DF_REFERENCE_CHAIN_TIME:-12:00:00}" --array=0-3 \
    --dependency="afterok:$DF_PREP_JOB" --kill-on-invalid-dep=yes \
    --export=ALL,DF_BATCH_DIR="$DF_BATCH_DIR",DF_STAGE=nuts-chain \
    --output="$DF_BATCH_DIR/logs/nuts-chain-%A_%a.out" "$DF_BATCH_DIR/slurm/reference.slurm")
  DF_FINAL_JOB=$(df_submit reference_finalize --time="${DF_REFERENCE_FINAL_TIME:-02:00:00}" \
    --dependency="afterok:$DF_CHAIN_JOB" --kill-on-invalid-dep=yes \
    --export=ALL,DF_BATCH_DIR="$DF_BATCH_DIR",DF_STAGE=nuts-finalize \
    --output="$DF_BATCH_DIR/logs/nuts-finalize-%j.out" "$DF_BATCH_DIR/slurm/reference.slurm")
  DF_RUN_DEP=(--dependency="afterok:$DF_FINAL_JOB" --kill-on-invalid-dep=yes)
  DF_TASKS=0-9
  printf 'NUTS: prepare %s -> chains %s -> diagnostics %s\n' "$DF_PREP_JOB" "$DF_CHAIN_JOB" "$DF_FINAL_JOB"
else
  python "$DF_BATCH_DIR/source/check_environment.py" --imports-only
  DF_TASKS=$(python "$DF_BATCH_DIR/source/manage.py" missing-runs --batch "$DF_BATCH_DIR")
fi
DF_AGG_DEP=()
if [[ -n "$DF_TASKS" ]]; then
  DF_RUN_JOB=$(df_submit run --time="${DF_REPEAT_TIME:-04:00:00}" --array="${DF_TASKS}%${DF_PARALLEL}" \
    "${DF_RUN_DEP[@]}" --export=ALL,DF_BATCH_DIR="$DF_BATCH_DIR" \
    --output="$DF_BATCH_DIR/logs/repeat-%A_%a.out" "$DF_BATCH_DIR/slurm/repeat.slurm")
  DF_AGG_DEP=(--dependency="afterany:$DF_RUN_JOB")
  printf 'Darcy frontier array: %s (tasks %s)\n' "$DF_RUN_JOB" "$DF_TASKS"
fi
DF_AGG_JOB=$(df_submit aggregate "${DF_AGG_DEP[@]}" \
  --export=ALL,DF_BATCH_DIR="$DF_BATCH_DIR" --output="$DF_BATCH_DIR/logs/aggregate-%j.out" \
  "$DF_BATCH_DIR/slurm/aggregate.slurm")
printf 'Aggregation: %s\nMonitor: squeue -u "$USER"\nReturn: %s/darcy_frontier_results.zip\n' "$DF_AGG_JOB" "$DF_BATCH_DIR"
trap - ERR
