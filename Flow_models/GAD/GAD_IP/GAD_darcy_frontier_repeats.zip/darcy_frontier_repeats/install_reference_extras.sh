#!/bin/bash
# Optional: run in the already working hlsi venv if NumPyro/ArviZ are missing.
# Constrain all existing distributions so the installer cannot replace the
# working Vista JAX/CUDA/PyTorch stack merely to satisfy new extras.
set -eo pipefail
DF_EXTRAS_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$DF_EXTRAS_ROOT/slurm/environment.sh"
set -u
DF_CONSTRAINTS=$(mktemp)
trap 'rm -f "$DF_CONSTRAINTS"' EXIT
python - "$DF_CONSTRAINTS" <<'PY'
from importlib.metadata import distributions
from pathlib import Path
import sys
lines=sorted({f"{d.metadata['Name']}=={d.version}" for d in distributions() if d.metadata.get('Name')})
Path(sys.argv[1]).write_text('\n'.join(lines)+'\n')
PY
python -m pip install --constraint "$DF_CONSTRAINTS" numpyro arviz
python -m pip check
python "$DF_EXTRAS_ROOT/source/check_environment.py" --imports-only --nuts
