"""Exact prepared-array solver from the supplied NUTS v3 builder. No KL rebuild."""
from types import SimpleNamespace
import numpy as np

def build_problem_from_prepared_arrays(
    args: argparse.Namespace,
    *,
    basis_np: np.ndarray,
    obs_locations_train: np.ndarray,
    obs_locations_holdout: np.ndarray,
):
    """Rebuild only the Darcy solver around Stage-1-owned immutable arrays.

    ``numpy.linalg.eigh`` is permitted to choose different eigenvector signs
    (and bases inside nearly degenerate eigenspaces) in independent processes.
    Re-running the KL construction on every node can therefore change the
    coefficient-space posterior.  Distributed workers must use the exact basis
    and observation indices committed by the preparation process.
    """
    import jax
    import jax.numpy as jnp
    n_grid = int(args.grid_size)
    basis_np = np.asarray(basis_np, dtype=np.float64)
    obs_train = np.asarray(obs_locations_train)
    obs_holdout = np.asarray(obs_locations_holdout)
    basis = jnp.asarray(basis_np, dtype=jnp.float64)
    obs_train_jax = jnp.asarray(obs_train, dtype=jnp.int32)
    obs_holdout_jax = jnp.asarray(obs_holdout, dtype=jnp.int32)

    h = 1.0 / float(n_grid - 1)
    f_darcy = jnp.ones((n_grid, n_grid), dtype=jnp.float64)
    interior_mask = jnp.zeros((n_grid, n_grid), dtype=bool)
    interior_mask = interior_mask.at[1:-1, 1:-1].set(True)
    int_rows, int_cols = jnp.where(interior_mask)
    n_int = int(int_rows.shape[0])
    int_id = -jnp.ones((n_grid, n_grid), dtype=jnp.int32)
    int_id = int_id.at[int_rows, int_cols].set(jnp.arange(n_int, dtype=jnp.int32))
    int_flat = int_rows * n_grid + int_cols

    def assemble_darcy(k_field):
        h2 = h * h
        k_xp = (
            2.0
            * k_field[:-1, :]
            * k_field[1:, :]
            / (k_field[:-1, :] + k_field[1:, :] + 1e-30)
        )
        k_yp = (
            2.0
            * k_field[:, :-1]
            * k_field[:, 1:]
            / (k_field[:, :-1] + k_field[:, 1:] + 1e-30)
        )
        ir, ic = int_rows, int_cols
        c_e = k_xp[ir, ic] / h2
        c_w = k_xp[ir - 1, ic] / h2
        c_n = k_yp[ir, ic] / h2
        c_s = k_yp[ir, ic - 1] / h2
        diag = c_e + c_w + c_n + c_s
        idx = jnp.arange(n_int)
        nbr_e = int_id[ir + 1, ic]
        nbr_w = int_id[ir - 1, ic]
        nbr_n = int_id[ir, ic + 1]
        nbr_s = int_id[ir, ic - 1]
        matrix = jnp.zeros((n_int, n_int), dtype=jnp.float64)
        matrix = matrix.at[idx, idx].add(diag)
        matrix = matrix.at[idx, nbr_e].add(jnp.where(nbr_e >= 0, -c_e, 0.0))
        matrix = matrix.at[idx, nbr_w].add(jnp.where(nbr_w >= 0, -c_w, 0.0))
        matrix = matrix.at[idx, nbr_n].add(jnp.where(nbr_n >= 0, -c_n, 0.0))
        matrix = matrix.at[idx, nbr_s].add(jnp.where(nbr_s >= 0, -c_s, 0.0))
        rhs = f_darcy[int_rows, int_cols]
        return matrix, rhs

    def solve_at(alpha, locations):
        log_k = jnp.reshape(basis @ alpha, (n_grid, n_grid))
        k_field = jnp.exp(log_k)
        matrix, rhs = assemble_darcy(k_field)
        p_int = jnp.linalg.solve(matrix, rhs)
        p_full = jnp.zeros(n_grid * n_grid, dtype=jnp.float64)
        p_full = p_full.at[int_flat].set(p_int)
        return p_full[locations]

    return SimpleNamespace(
        grid_size=n_grid,
        latent_dim=int(args.latent_dim),
        basis_np=basis_np,
        obs_locations_train=obs_train,
        obs_locations_holdout=obs_holdout,
        solve_forward=jax.jit(lambda alpha: solve_at(alpha, obs_train_jax)),
        solve_forward_holdout=jax.jit(
            lambda alpha: solve_at(alpha, obs_holdout_jax)
        ),
    )
