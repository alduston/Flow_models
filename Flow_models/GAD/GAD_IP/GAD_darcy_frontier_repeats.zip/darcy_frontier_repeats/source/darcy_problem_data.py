"""Validate the shared Darcy posterior and diagnostics-approved NUTS reference."""
from pathlib import Path
import hashlib
import json
import numpy as np

PROBLEM_KEYS = ("data_seed", "grid_size", "latent_dim", "n_observations", "n_holdout", "noise_std")
ARRAY_KEYS = ("basis", "obs_locations_train", "obs_locations_holdout", "alpha_true", "y_obs")


def file_sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fingerprint(args, arrays):
    metadata = {key: getattr(args, key) for key in PROBLEM_KEYS}
    metadata = {key: float(value) if key == "noise_std" else int(value)
                for key, value in metadata.items()}
    canonical = json.dumps(metadata, sort_keys=True, separators=(",", ":"), allow_nan=False)
    digest = hashlib.sha256(canonical.encode("utf-8"))
    for key in ARRAY_KEYS:
        array = np.ascontiguousarray(arrays[key])
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(np.asarray(array.shape, dtype=np.int64).tobytes())
        digest.update(array.tobytes())
    return digest.hexdigest()


def load_arrays(path, args):
    with np.load(path, allow_pickle=False) as archive:
        required = set(ARRAY_KEYS) | {"y_clean", "problem_fingerprint"}
        missing = required - set(archive.files)
        if missing:
            raise ValueError(f"Missing immutable problem arrays: {sorted(missing)}")
        arrays = {key: np.array(archive[key]) for key in required}
    expected = {"basis": (args.grid_size**2, args.latent_dim),
                "alpha_true": (args.latent_dim,), "y_obs": (args.n_observations,),
                "y_clean": (args.n_observations,),
                "obs_locations_train": (args.n_observations,),
                "obs_locations_holdout": (args.n_holdout,)}
    for key, shape in expected.items():
        if arrays[key].shape != shape or not np.isfinite(arrays[key]).all():
            raise ValueError(f"Invalid shape or nonfinite values in {key}")
    locations = np.concatenate([arrays["obs_locations_train"], arrays["obs_locations_holdout"]])
    if (not np.issubdtype(locations.dtype, np.integer) or np.any(locations < 0)
            or np.any(locations >= args.grid_size**2)
            or len(np.unique(locations)) != len(locations)):
        raise ValueError("Invalid, duplicated, or overlapping observation indices")
    found = fingerprint(args, arrays)
    if found != str(arrays["problem_fingerprint"].item()):
        raise ValueError("Problem fingerprint mismatch: settings or immutable arrays changed")
    return arrays, found


def validate_reference(directory, args):
    directory = Path(directory)
    arrays, found = load_arrays(directory / "problem_data.npz", args)
    diagnostics = json.loads((directory / "nuts_diagnostics.json").read_text())
    checks = diagnostics.get("checks", {})
    required = {"convergence_diagnostics_finite", "kernel_diagnostics_finite", "rank_rhat",
                "bulk_ess", "tail_ess", "divergences", "tree_depth", "ebfmi", "acceptance"}
    if (diagnostics.get("certified") is not True or not required <= checks.keys()
            or not all(checks[key] is True for key in required)):
        raise ValueError("NUTS reference did not pass all required diagnostics")
    thresholds = diagnostics["thresholds"]
    maxima = {"max_rhat": 1.01, "max_divergences": 0, "max_tree_depth_fraction": .01}
    minima = {"min_bulk_ess": 1000., "min_tail_ess": 400., "min_ebfmi": .30, "min_mean_accept": .80}
    if any(thresholds[key] > value for key, value in maxima.items()) or any(
            thresholds[key] < value for key, value in minima.items()):
        raise ValueError("Reference diagnostic thresholds were relaxed")
    config = json.loads((directory / "run_config.json").read_text())
    if config.get("problem_fingerprint") != found:
        raise ValueError("NUTS configuration has a different problem fingerprint")
    stored = config["arguments"]
    for key in PROBLEM_KEYS:
        if stored[key] != getattr(args, key):
            raise ValueError(f"Reference configuration mismatch: {key}")
    if stored["num_chains"] < 4 or stored["num_samples"] < 5000 or stored["thinning"] != 1:
        raise ValueError("Reference requires at least four chains, 5000 draws/chain, thinning=1")
    refpath = directory / "reference_samples.npz"
    with np.load(refpath, allow_pickle=False) as reference:
        if not bool(reference["certified"].item()):
            raise ValueError("Reference sample payload is marked uncertified")
        if str(reference["problem_fingerprint"].item()) != found:
            raise ValueError("Reference samples belong to another posterior")
        for key in (*ARRAY_KEYS, "y_clean"):
            if not np.array_equal(reference[key], arrays[key]):
                raise ValueError(f"Reference differs from prepared problem: {key}")
        samples = np.asarray(reference["samples"])
        chains = np.asarray(reference["samples_by_chain"])
        if (chains.shape != (stored["num_chains"], stored["num_samples"], args.latent_dim)
                or samples.shape != (chains.shape[0]*chains.shape[1], args.latent_dim)
                or not np.isfinite(samples).all() or not np.array_equal(samples, chains.reshape(samples.shape))):
            raise ValueError("Invalid pooled reference samples or chain ordering")
    return {"problem_fingerprint": found, "reference_sha256": file_sha256(refpath),
            "problem_data_sha256": file_sha256(directory / "problem_data.npz"),
            "reference_particles": int(samples.shape[0]), "diagnostics": diagnostics}


def load_problem(path, args):
    arrays, found = load_arrays(path, args)
    from _prepared_solver import build_problem_from_prepared_arrays
    import jax.numpy as jnp
    problem = build_problem_from_prepared_arrays(
        args, basis_np=arrays["basis"], obs_locations_train=arrays["obs_locations_train"],
        obs_locations_holdout=arrays["obs_locations_holdout"])
    forward = np.asarray(problem.solve_forward(jnp.asarray(arrays["alpha_true"], dtype=jnp.float64)))
    if not np.allclose(forward, arrays["y_clean"], rtol=1e-9, atol=1e-11):
        raise ValueError("Prepared solver does not reproduce the recorded clean observations")
    return problem, arrays["alpha_true"], arrays["y_clean"], arrays["y_obs"], found
