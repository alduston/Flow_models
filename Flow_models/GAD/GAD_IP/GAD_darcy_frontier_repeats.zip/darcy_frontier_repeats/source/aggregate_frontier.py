"""Strict ten-seed aggregation, paired inference, and print-size Darcy figures."""
import json
from pathlib import Path
import zipfile
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from manage import settings, check_snapshot, check_complete, reference_audit, write_json

METRICS = [
    ("MeanWhitenedRMSE", "Posterior mean\n(whitened RMSE)"),
    ("CovarianceRelFro", "Posterior covariance\n(relative Frobenius error)"),
    ("LogKMeanRelL2", "Mean log-permeability field\n(relative $L^2$ error)"),
    ("LogKStdRelL2", "Log-permeability standard deviation\n(relative $L^2$ error)"),
    ("KMeanRelL2", "Mean permeability field\n(relative $L^2$ error)"),
    ("HoldoutPressureAtMeanRelL2", "Held-out pressure at posterior mean\n(relative $L^2$ error)"),
]
METHODS = ("mcmc", "gad_lfgi")
LABELS = {"mcmc": "MALA", "gad_lfgi": "GAD (q-LFGI-GN)"}


def mean_ci(values, draws, confidence):
    # A row is a full independent run. The same resampled seed rows are used
    # for all budgets, metrics, and both methods, preserving their dependence.
    boot = values[draws].mean(axis=1)
    alpha = (1 - confidence) / 2
    return values.mean(axis=0), values.std(axis=0, ddof=1), np.quantile(boot, [alpha, 1-alpha], axis=0)


def collect(batch):
    manifest = check_snapshot(batch)
    if len(manifest["sampler_seeds"]) != 10:
        raise ValueError("Expected ten seeds")
    audit = reference_audit(batch)
    failures, frames, configs = [], [], []
    for task, seed in enumerate(manifest["sampler_seeds"]):
        try:
            result, config = check_complete(batch, task, audit)
            frame = pd.read_csv(result / "functional_compute_frontier.csv")
            if set(frame["method"]) != set(METHODS):
                raise ValueError("Unexpected or missing methods")
            for method in METHODS:
                part = frame[frame.method == method].sort_values("total_flops")
                x = part.total_flops.to_numpy(float)
                y = part[[key for key, _ in METRICS]].to_numpy(float)
                if (len(x) < 2 or not np.isfinite(x).all() or np.any(x < 0)
                        or np.any(np.diff(x) <= 0) or not np.isfinite(y).all() or np.any(y < 0)):
                    raise ValueError(f"Invalid native compute grid or functional errors: {method}")
            with np.load(result / "frontier_samples.npz", allow_pickle=False) as banks:
                index = pd.read_csv(result / "frontier_sample_index.csv")
                if len(index) != len(frame) or set(index.sample_key) != set(banks.files):
                    raise ValueError("Sample bank index does not cover every scored record")
                for key in banks.files:
                    values = banks[key]
                    if values.shape != (config["n_particles"], config["latent_dim"]) or not np.isfinite(values).all():
                        raise ValueError("Malformed or nonfinite endpoint bank")
            frame["sampler_seed"] = seed
            frames.append(frame)
            configs.append(config)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            failures.append({"sampler_seed": seed, "error": str(exc)})
    write_json(batch / "meta_results/completion_audit.json", {
        "expected_seeds": manifest["sampler_seeds"], "completed": len(frames), "failures": failures})
    if failures:
        raise ValueError(f"Incomplete/invalid batch: {failures}. No publication plot was produced.")
    for method in METHODS:
        grids = [f[f.method == method].sort_values("total_flops").total_flops.to_numpy(float) for f in frames]
        if any(g.shape != grids[0].shape or not np.allclose(g, grids[0], rtol=1e-12, atol=.01) for g in grids[1:]):
            raise ValueError("Analytical FLOP checkpoints differ across seeds; refusing interpolation or extrapolation")
    return frames, configs, audit


def make_figure(summary, out, display_floor, qa_label=None):
    plt.rcParams.update({"font.family": "DejaVu Sans", "mathtext.fontset": "stix",
        "font.size": 8.3, "axes.titlesize": 8.6, "axes.labelsize": 8.3,
        "xtick.labelsize": 7.8, "ytick.labelsize": 7.8, "legend.fontsize": 8.5,
        "pdf.fonttype": 42, "ps.fonttype": 42, "axes.spines.top": False,
        "axes.spines.right": False, "savefig.facecolor": "white"})
    fig, axes = plt.subplots(3, 2, figsize=(6.45, 5.9), sharex=True)
    styles = {"mcmc": ("#242424", "-", "o"), "gad_lfgi": ("#007F88", "--", "D")}
    for ax, (metric, title) in zip(axes.ravel(), METRICS):
        for method in METHODS:
            part = summary[(summary.method == method) & (summary.metric == metric)].sort_values("total_flops")
            x = part.total_flops.to_numpy(float) / 1e12
            color, line, marker = styles[method]
            mean = np.maximum(part["mean"].to_numpy(float), display_floor)
            lo = np.maximum(part.ci_lower.to_numpy(float), display_floor)
            hi = np.maximum(part.ci_upper.to_numpy(float), display_floor)
            ax.fill_between(x, lo, hi, color=color, alpha=.18, linewidth=0)
            ax.plot(x, mean, color=color, linestyle=line, marker=marker, linewidth=1.25,
                    markersize=3.0, markevery=1 if method == "gad_lfgi" else max(1, len(x)//10))
        ax.set_title(title, pad=6)
        ax.set_yscale("log")
        ax.set_xlim(0, float(summary.total_flops.max())/1e12)
        ax.grid(which="major", alpha=.23, linewidth=.5)
        ax.grid(which="minor", axis="y", alpha=.10, linewidth=.4)
        ax.tick_params(which="both", length=2.5)
        ax.set_ylabel("Error ↓")
    for ax in axes[-1]:
        ax.set_xlabel("Total estimated compute (TFLOP)")
    handles = [Line2D([0], [0], color=styles[m][0], linestyle=styles[m][1],
                      marker=styles[m][2], linewidth=1.25, markersize=3.5, label=LABELS[m]) for m in METHODS]
    handles.append(Patch(facecolor="#8F9BA8", alpha=.25, label="Pointwise 95% CI (10 seeds)"))
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.5, .995),
               ncol=3, frameon=False, columnspacing=1.3, handlelength=2.5, fontsize=8)
    if qa_label:
        fig.text(.5, .5, qa_label, ha="center", color="#A00000", fontsize=14,
                 weight="bold", rotation=25, alpha=.28)
    fig.subplots_adjust(left=.105, right=.985, bottom=.095, top=.88, hspace=.58, wspace=.28)
    fig.savefig(out / "gad_v_mala_darcy_uncertainty.pdf", bbox_inches="tight")
    fig.savefig(out / "gad_v_mala_darcy_uncertainty.png", dpi=450, bbox_inches="tight")
    plt.close(fig)


def write_tex(batch, cfg, audit, plot_metadata):
    out = batch / "meta_results"
    n = cfg["frontier"]["n_particles"]
    p = cfg["problem"]
    caption = rf"""\begin{{figure}}[tbp]
\centering
\includegraphics[width=\textwidth]{{Figures/gad_v_mala_darcy_uncertainty.pdf}}
\caption{{\textbf{{Darcy posterior functional error at matched estimated compute.}}
MALA (solid circles) and GAD with q-LFGI--GN (dashed diamonds) use the same fixed
{p['latent_dim']}-dimensional posterior, {p['n_observations']} noisy pressure observations,
and {n:,} equally weighted particles. Curves show arithmetic means over ten
independent sampler seeds; shaded regions are pointwise 95\% percentile-bootstrap
confidence intervals for those means (5,000 resamples of whole, paired runs).
Errors compare with one independent, diagnostics-approved NUTS reference
({audit['reference_particles']:,} retained draws). The panels show whitened coefficient-mean RMSE,
relative covariance Frobenius error, relative $L^2$ errors in the mean and standard
deviation of log permeability, relative $L^2$ error in mean permeability, and
relative $L^2$ error in held-out pressure evaluated at the coefficient posterior mean.
All errors are dimensionless, on logarithmic vertical axes; lower is better.
One TFLOP denotes $10^{{12}}$ operations in the recorded analytical cost model,
including MALA initialization/adaptation and every GAD bank and transport;
offline NUTS construction, compilation, and functional evaluation are excluded.
Methods are aggregated at their native compute checkpoints without extrapolation.
Intervals describe run variability conditional on the shared reference and
do not include its Monte Carlo uncertainty.}}
\label{{fig:darcy-matched-compute}}
\end{{figure}}
"""
    if plot_metadata["zero_display_count"]:
        floor_text = rf" Exactly zero means or interval endpoints are displayed at ${plot_metadata['display_floor']:.2g}$; raw values remain in the CSV."
        caption = caption.replace("Intervals describe", floor_text + "\nIntervals describe")
    (out / "figure_caption.tex").write_text(caption)
    setup = rf"""% Replace/update the existing matched-compute setup; retain its manuscript label.
The Darcy benchmark fixes data seed {p['data_seed']}, a ${p['grid_size']}\times{p['grid_size']}$
grid, {p['latent_dim']} KL coefficients, {p['n_observations']} training and {p['n_holdout']}
held-out interior observation locations, and independent Gaussian noise with
standard deviation ${p['noise_std']:g}$. The prior covariance kernel is
$\exp(-\|x-x'\|/0.1)$ and the coefficient prior is standard Gaussian.
The prepared KL basis and observation arrays are shared exactly across all jobs.
Sampler seeds 42--51 vary independently of the fixed data. Each run initializes
{n:,} parallel MALA chains from the prior and records the configured checkpoints
over transitions 0--70. Dual averaging targets acceptance 0.574 for the first
60 transitions, from $h_0=10^{{-4}}$; the kernel then freezes. Adaptation is included
in compute. GAD starts from the same initial prior cloud, rebuilds its unweighted
bank after each transport, and uses 100 stochastic reverse-OU Heun steps from
$T=10$ to $t_{{\min}}=10^{{-2.5}}$. Only complete GAD rounds within the base-MALA
cost plus one GAD-round cost are retained. MALA continues through that horizon.

One independent offline reference uses four dense-mass NumPyro NUTS chains,
each with 3,000 warmup and 5,000 retained draws, target acceptance 0.95,
truth-blind multistart MAP initialization, and exact-Hessian Laplace whitening.
No GAD output initializes NUTS. Pooling requires rank-normalized
$\widehat R\le1.01$, bulk ESS $\ge1000$, tail ESS $\ge400$, zero divergences,
tree-depth saturation $\le1\%$, E-BFMI $\ge0.30$, and mean acceptance $\ge0.80$,
as checked by the supplied builder. Diagnostic approval is a numerical check,
not a guarantee of exact posterior sampling. Chain-agreement discrepancies
and parameter/derived-functional diagnostics are archived separately.

Let $\widehat\mu_*$ and $\widehat C_*$ denote the pooled-reference coefficient
mean and sample covariance. Mean error is
$\|\widehat C_{{*,\mathrm{{reg}}}}^{{-1/2}}(\widehat\mu-\widehat\mu_*)\|/\sqrt{{d}}$,
where reference-covariance eigenvalues are floored at
$10^{{-10}}+10^{{-8}}\operatorname{{tr}}(\widehat C_*)/d$.
Covariance error is $\|\widehat C-\widehat C_*\|_F/(\|\widehat C_*\|_F+10^{{-12}})$.
Every field relative error is $\|f-f_*\|_2/(\|f_*\|_2+10^{{-12}})$, over all grid
nodes for permeability fields and the held-out observation set for pressure.
Sample covariances and pointwise standard deviations use denominator $N-1$.
Permeability is evaluated as $\exp(\operatorname{{clip}}(\log k,-60,60))$;
unclipped log-field errors are also reported. Held-out pressure is solved at
the coefficient posterior mean and is not the posterior predictive mean.

The FLOP axis uses the supplied dense-solve model, including $d+1$ forward
equivalents per Gauss--Newton bank Hessian and $2S+1$ score evaluations for
$S$ Heun steps. It is an operation-count estimate rather than measured hardware
FLOPs or elapsed time. The full per-component model, measured times, particle
banks, seed settings, software versions, reference fingerprints, all native
checkpoint errors, and paired matched-compute comparisons are archived.
Paired comparisons linearly interpolate MALA error between bracketing native
checkpoints at each GAD cost; they never extrapolate. The plot itself aggregates
native checkpoints directly. Its 95\% intervals resample ten complete paired
runs 5,000 times with bootstrap seed 20261022, and are pointwise intervals for
the mean, conditional on the common NUTS reference.
"""
    (out / "matched_compute_setup.tex").write_text(setup)


def aggregate(batch, qa_label=None):
    batch = Path(batch)
    out = batch / "meta_results"
    out.mkdir(exist_ok=True)
    frames, configs, audit = collect(batch)
    cfg = settings(batch)
    options = cfg["aggregation"]
    rng = np.random.default_rng(options["bootstrap_seed"])
    draws = rng.integers(0, 10, size=(options["bootstrap_replicates"], 10))
    summary_rows, paired_rows = [], []
    for method in METHODS:
        parts = [f[f.method == method].sort_values("total_flops") for f in frames]
        x = parts[0].total_flops.to_numpy(float)
        for metric, _ in METRICS:
            values = np.stack([part[metric].to_numpy(float) for part in parts])
            mean, sd, ci = mean_ci(values, draws, options["confidence"])
            for i in range(len(x)):
                summary_rows.append(dict(method=method, metric=metric, checkpoint=i,
                    total_flops=x[i], mean=mean[i], sample_sd=sd[i], ci_lower=ci[0,i], ci_upper=ci[1,i], n_seeds=10))
    for frame in frames:
        mala = frame[frame.method == "mcmc"].sort_values("total_flops")
        gad = frame[frame.method == "gad_lfgi"].sort_values("total_flops")
        x = mala.total_flops.to_numpy(float)
        for _, row in gad.iterrows():
            if not x.min() <= row.total_flops <= x.max():
                raise ValueError("No MALA bracket at a GAD compute checkpoint")
            for metric, _ in METRICS:
                base = np.interp(row.total_flops, x, mala[metric].to_numpy(float))
                paired_rows.append(dict(sampler_seed=int(row.sampler_seed), gad_round=int(row.gad_round)+1,
                    metric=metric, total_flops=row.total_flops, gad_error=row[metric],
                    matched_mala_error=base, error_difference_gad_minus_mala=row[metric]-base,
                    gad_better=bool(row[metric]<base)))
    summary = pd.DataFrame(summary_rows)
    pd.concat(frames, ignore_index=True).to_csv(out / "all_seed_frontiers.csv", index=False)
    summary.to_csv(out / "frontier_mean_uncertainty.csv", index=False)
    paired = pd.DataFrame(paired_rows)
    paired.to_csv(out / "paired_matched_compute.csv", index=False)
    differences = []
    for (round_, metric), part in paired.groupby(["gad_round", "metric"], sort=False):
        part = part.set_index("sampler_seed").loc[cfg["sampler_seeds"]]
        values = part.error_difference_gad_minus_mala.to_numpy(float)
        mean, sd, ci = mean_ci(values[:,None], draws, options["confidence"])
        differences.append(dict(gad_round=int(round_), metric=metric, mean_difference=float(mean[0]),
            sample_sd=float(sd[0]), ci_lower=float(ci[0,0]), ci_upper=float(ci[1,0]),
            fraction_runs_gad_better=float(part.gad_better.mean())))
    pd.DataFrame(differences).to_csv(out / "paired_difference_uncertainty.csv", index=False)
    all_values = summary[["mean", "ci_lower", "ci_upper"]].to_numpy(float)
    positive = all_values[all_values>0]
    floor = float(positive.min()/10) if positive.size else 1e-16
    metadata = {**options, "n_seeds": 10, "interval_type": "pointwise percentile bootstrap CI for arithmetic mean",
                "conditioning": "one fixed posterior and shared diagnostics-approved NUTS reference",
                "interpolation": "none in figure; linear between bracketing MALA errors for paired comparisons",
                "display_floor": floor, "zero_display_count": int(np.sum(all_values == 0)),
                "reference_sha256": audit["reference_sha256"], "problem_fingerprint": audit["problem_fingerprint"],
                "figure_inches": [6.45,5.9], "png_dpi": 450}
    write_json(out / "plot_metadata.json", metadata)
    write_json(out / "reference_diagnostics.json", audit)
    make_figure(summary, out, floor, qa_label=qa_label)
    write_tex(batch, cfg, audit, metadata)
    archive = batch / "darcy_frontier_results.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=4) as handle:
        for path in sorted(batch.rglob("*")):
            if path.is_file() and path != archive and "__pycache__" not in path.parts:
                handle.write(path, Path(batch.name) / path.relative_to(batch))
    print(f"Complete: {out}\nReturn this archive: {archive}", flush=True)
