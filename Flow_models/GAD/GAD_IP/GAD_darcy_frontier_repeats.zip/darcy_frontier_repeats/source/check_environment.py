"""Check dependencies before submission and GPU visibility inside compute jobs."""
import argparse
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--nuts", action="store_true")
    p.add_argument("--imports-only", action="store_true")
    p.add_argument("--record", type=Path)
    args = p.parse_args()
    packages = ["numpy", "scipy", "pandas", "matplotlib", "jax", "jaxlib", "torch"]
    if args.nuts:
        packages += ["numpyro", "arviz"]
    missing = [name for name in packages if importlib.util.find_spec(name) is None]
    if missing:
        raise SystemExit("Missing packages: " + ", ".join(missing) +
                         ". Use the working hlsi environment; see install_reference_extras.sh if NumPyro/ArviZ are missing.")
    if args.imports_only:
        print("Dependency presence check passed")
        return
    import jax
    import torch
    jax.config.update("jax_enable_x64", True)
    if jax.default_backend() != "gpu" or not any(d.platform == "gpu" for d in jax.devices()):
        raise SystemExit("JAX cannot see a GPU; refusing a silent CPU run. Keep the working Vista CUDA JAX installation.")
    if not torch.cuda.is_available():
        raise SystemExit("PyTorch cannot see a GPU in the selected environment")
    if args.nuts:
        import numpyro
        import arviz
    record = {"python": platform.python_version(), "platform": platform.platform(),
              "packages": {name: importlib.metadata.version(name) for name in packages},
              "jax_backend": jax.default_backend(), "jax_devices": [str(d) for d in jax.devices()],
              "torch_gpu": torch.cuda.get_device_name(0), "torch_cuda": torch.version.cuda,
              "environment": {key: os.getenv(key) for key in ["JAX_PLATFORMS", "JAX_ENABLE_X64",
                  "XLA_PYTHON_CLIENT_PREALLOCATE", "XLA_PYTHON_CLIENT_MEM_FRACTION",
                  "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]}}
    if args.record:
        args.record.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
