"""Freeze, run, validate, and aggregate the repeated Darcy frontier workflow."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from types import SimpleNamespace


def stamp():
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")


def write_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def settings(batch):
    return json.loads((Path(batch) / "run_settings.json").read_text())


def check_snapshot(batch):
    manifest = json.loads((batch / "manifest.json").read_text())
    for name, expected in manifest["frozen_files"].items():
        if digest(batch / name) != expected:
            raise ValueError(f"Frozen batch source changed: {name}; use a new batch")
    return manifest


def problem_args(batch):
    return SimpleNamespace(**settings(batch)["problem"])


def reference_audit(batch):
    from darcy_problem_data import validate_reference
    return validate_reference(batch / "reference", problem_args(batch))


def check_complete(batch, task, audit=None):
    manifest = check_snapshot(batch)
    seed = manifest["sampler_seeds"][task]
    path = batch / "runs" / f"seed_{seed}"
    status = json.loads((path / "status.json").read_text())
    if status.get("status") != "complete" or status.get("sampler_seed") != seed:
        raise ValueError(f"Sampler seed {seed} has not completed")
    result = (path / status["result_directory"]).resolve()
    if not result.is_relative_to(path.resolve()):
        raise ValueError("Result path escaped its run directory")
    audit = audit or reference_audit(batch)
    config = json.loads((result / "run_config.json").read_text())
    expected = settings(batch)
    for key, value in {**expected["problem"], **expected["frontier"], "seed": seed}.items():
        if key == "gate_methods":
            if config["selected_methods"] != ["gad_lfgi"]:
                raise ValueError("Unexpected frontier methods")
        elif config[key] != value:
            raise ValueError(f"Sampler seed {seed} has different {key}")
    for key in ("problem_fingerprint", "reference_sha256", "problem_data_sha256"):
        if config[key] != audit[key]:
            raise ValueError(f"Sampler seed {seed} has different {key}")
    required = ["functional_compute_frontier.csv", "frontier_samples.npz", "frontier_sample_index.csv"]
    for name in required:
        if not (result / name).is_file() or (result / name).stat().st_size == 0:
            raise ValueError(f"Missing run artifact: {name}")
        if status["artifact_sha256"][name] != digest(result / name):
            raise ValueError(f"Modified run artifact: {name}")
    return result, config


def execute(command, logfile):
    print("Command:", " ".join(map(str, command)), flush=True)
    with Path(logfile).open("w") as handle:
        process = subprocess.Popen(list(map(str, command)), stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in process.stdout:
            handle.write(line)
            handle.flush()
            print(line, end="", flush=True)
        code = process.wait()
    if code:
        raise RuntimeError(f"Subprocess exited {code}; see {logfile}")


def flags(values):
    result = []
    for key, value in values.items():
        result.extend(["--" + key.replace("_", "-"), str(value)])
    return result


def prepare(args):
    bundle = args.bundle.resolve()
    batch = args.batch.resolve()
    batch.mkdir(parents=True, exist_ok=False)
    shutil.copytree(bundle / "source", batch / "source", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copytree(bundle / "slurm", batch / "slurm")
    shutil.copy2(bundle / "run_settings.json", batch / "run_settings.json")
    for name in ("logs", "runs", "reference", "meta_results"):
        (batch / name).mkdir()
    cfg = settings(batch)
    seeds = cfg["sampler_seeds"]
    if len(seeds) != 10 or len(set(seeds)) != 10:
        raise ValueError("Publication batch requires exactly ten distinct sampler seeds")
    paths = [batch / "run_settings.json", *(batch / "source").glob("*.py"), *(batch / "slurm").glob("*")]
    frozen = {str(path.relative_to(batch)): digest(path) for path in paths if path.is_file()}
    write_json(batch / "manifest.json", {"format": 1, "created_utc": stamp(), "sampler_seeds": seeds,
               "fixed_data_seed": cfg["problem"]["data_seed"], "frozen_files": frozen,
               "uncertainty": "pointwise 95% paired-seed bootstrap CI for arithmetic mean error, conditional on fixed NUTS reference"})
    if args.reference_dir:
        source = args.reference_dir.resolve()
        for name in ("reference_samples.npz", "problem_data.npz", "nuts_diagnostics.json", "run_config.json"):
            shutil.copy2(source / name, batch / "reference" / name)
        for name in ("nuts_parameter_diagnostics.csv", "reference_functionals.npz"):
            if (source / name).is_file():
                shutil.copy2(source / name, batch / "reference" / name)
        audit = reference_audit(batch)
        write_json(batch / "reference_audit.json", audit)
    print(batch)


def nuts_stage(batch, stage, task):
    check_snapshot(batch)
    cfg = settings(batch)
    command = [sys.executable, "-u", batch / "source/darcy_nuts_offline_reference_20260821_v3.py",
               "--darcy-script", batch / "source/darcy_compute_frontier.py",
               "--output-dir", batch / "reference", "--resume", "--no-progress-bar",
               *flags({**cfg["problem"], **cfg["nuts"]})]
    if stage == "nuts-prepare":
        command += ["--prepare-only"]
    elif stage == "nuts-chain":
        command += ["--chain-index", str(task)]
    else:
        command += ["--finalize-only"]
    execute(command, batch / "logs" / f"{stage}-{task if task is not None else 'all'}.log")
    if stage == "nuts-finalize":
        write_json(batch / "reference_audit.json", reference_audit(batch))


def run(batch, task):
    manifest = check_snapshot(batch)
    cfg = settings(batch)
    if not 0 <= task < len(manifest["sampler_seeds"]):
        raise ValueError("Invalid array index")
    audit = reference_audit(batch)
    seed = manifest["sampler_seeds"][task]
    directory = batch / "runs" / f"seed_{seed}"
    directory.mkdir(exist_ok=True)
    try:
        result, _ = check_complete(batch, task, audit)
        print(f"Seed {seed} already complete and verified: {result}")
        return
    except (OSError, ValueError, KeyError, TypeError):
        pass
    attempt = directory / f"attempt_{stamp()}"
    attempt.mkdir()
    status = {"status": "running", "sampler_seed": seed, "started_utc": stamp(),
              "slurm_job_id": os.getenv("SLURM_JOB_ID"), "slurm_task_id": os.getenv("SLURM_ARRAY_TASK_ID")}
    write_json(directory / "status.json", status)
    command = [sys.executable, "-u", batch / "source/darcy_compute_frontier.py",
               *flags({**cfg["problem"], **cfg["frontier"]}), "--seed", str(seed),
               "--problem-data", batch / "reference/problem_data.npz",
               "--reference-samples", batch / "reference/reference_samples.npz",
               "--output-root", attempt]
    try:
        execute(command, attempt / "run.log")
        results = list(attempt.glob("darcy_mala_gad_compute_frontier_*"))
        if len(results) != 1:
            raise ValueError("Expected exactly one completed result directory")
        result = results[0]
        names = ("functional_compute_frontier.csv", "frontier_samples.npz", "frontier_sample_index.csv")
        status.update(status="complete", finished_utc=stamp(),
                      result_directory=str(result.relative_to(directory)),
                      artifact_sha256={name: digest(result / name) for name in names})
        write_json(directory / "status.json", status)
        check_complete(batch, task, audit)
    except Exception as exc:
        status.update(status="failed", error=str(exc), finished_utc=stamp())
        write_json(directory / "status.json", status)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["prepare", "validate-reference", "missing-runs", "run",
                                          "nuts-prepare", "nuts-chain", "nuts-finalize", "aggregate"])
    parser.add_argument("--bundle", type=Path)
    parser.add_argument("--batch", type=Path, required=True)
    parser.add_argument("--reference-dir", type=Path)
    parser.add_argument("--task", type=int)
    args = parser.parse_args()
    batch = args.batch.resolve()
    if args.action == "prepare":
        prepare(args)
    elif args.action == "validate-reference":
        check_snapshot(batch)
        audit = reference_audit(batch)
        write_json(batch / "reference_audit.json", audit)
        print("Reference passed:", audit["problem_fingerprint"])
    elif args.action == "missing-runs":
        manifest = check_snapshot(batch)
        audit = reference_audit(batch)
        missing = []
        for task in range(len(manifest["sampler_seeds"])):
            try:
                check_complete(batch, task, audit)
            except (OSError, ValueError, KeyError, TypeError):
                missing.append(str(task))
        print(",".join(missing))
    elif args.action.startswith("nuts-"):
        nuts_stage(batch, args.action, args.task)
    elif args.action == "run":
        run(batch, args.task)
    else:
        from aggregate_frontier import aggregate
        aggregate(batch)


if __name__ == "__main__":
    main()
