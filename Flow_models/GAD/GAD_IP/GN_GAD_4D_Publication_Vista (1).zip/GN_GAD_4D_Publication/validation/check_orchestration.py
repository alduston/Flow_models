"""Mock scheduler checks: graph, bounded arrays, freeze and duplicate protection."""
import json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    with tempfile.TemporaryDirectory() as td:
        tmp=Path(td);bin=tmp/'bin';bin.mkdir();state=tmp/'state.json';state.write_text(json.dumps({'calls':[],'live':False,'next':9000}))
        program='''#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
p=Path(os.environ['MOCK_STATE']);d=json.loads(p.read_text());name=Path(sys.argv[0]).name
if name=='sbatch':
 d['next']+=1;d['calls'].append(sys.argv[1:]);p.write_text(json.dumps(d));print(d['next'])
elif name=='squeue':
 if d['live']:print('9001|RUNNING|None')
elif name=='scancel':
 d['cancelled']=sys.argv[1:];p.write_text(json.dumps(d))
'''
        for name in ['sbatch','squeue','scancel']:
            f=bin/name;f.write_text(program);f.chmod(0o755)
        env=dict(os.environ,PATH=str(bin)+os.pathsep+os.environ['PATH'],MOCK_STATE=str(state));batch=tmp/'batch'
        cmd=[sys.executable,str(ROOT/'submit_vista.py'),'--batch',str(batch),'--python',sys.executable]
        p=subprocess.run(cmd+['--dry-run'],env=env,text=True,capture_output=True);assert p.returncode==0,p.stderr
        assert not batch.exists() and json.loads(state.read_text())['calls']==[]
        p=subprocess.run(cmd,env=env,text=True,capture_output=True);assert p.returncode==0,p.stderr
        d=json.loads(state.read_text());assert len(d['calls'])==5
        assert d['calls'][0][-1]==str(Path(sys.executable).absolute())
        assert d['calls'][1][d['calls'][1].index('--array')+1]=='0-3%2'
        assert d['calls'][3][d['calls'][3].index('--array')+1]=='0-4%2'
        for i in range(1,5):assert d['calls'][i][d['calls'][i].index('--dependency')+1]==f'afterok:{9000+i}'
        p=subprocess.run(cmd,env=env,text=True,capture_output=True);assert p.returncode!=0
        d['live']=True;state.write_text(json.dumps(d));p=subprocess.run(cmd+['--resume'],env=env,text=True,capture_output=True);assert p.returncode!=0
        assert len(json.loads(state.read_text())['calls'])==5
        d['live']=False;state.write_text(json.dumps(d));p=subprocess.run(cmd+['--resume'],env=env,text=True,capture_output=True);assert p.returncode==0,p.stderr
        assert len(json.loads(state.read_text())['calls'])==10
        p=subprocess.run(cmd+['--resume','--case','wide'],env=env,text=True,capture_output=True);assert p.returncode!=0
    result={'passed':True,'dry_run_no_side_effects':True,'five_stage_dependencies_checked':True,'max_active_arrays_two':True,'source_frozen_and_verified':True,'live_duplicate_submission_refused':True,'changed_case_resume_refused':True,'mock_only_no_real_jobs_submitted':True}
    (ROOT/'validation/orchestration.json').write_text(json.dumps(result,indent=2)+'\n');print(result)

if __name__=='__main__':main()
