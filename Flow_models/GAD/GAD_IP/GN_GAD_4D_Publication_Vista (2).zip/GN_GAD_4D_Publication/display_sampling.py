"""Fresh outputs of frozen round-1/final fields; no additional bank/target calls."""
import argparse,time
from pathlib import Path
import numpy as np
import jax
import jax.numpy as jnp
from scipy.special import softmax
from common import read,npz,write,save_npz,signature,runtime,verify_file,log
from vendor.lfgi import make_integrator

def frozen_outputs(out,seed):
    from run import load,lock
    m,t=load(out);cfg=m['config'];pc=cfg['publication'];sd=out/f'seed{seed}';setup=npz(sd/'setup/production_setup.npz');M=pc['display_count']
    with lock(sd/'display.lock'):
        for r in pc['display_rounds']:
            bank=npz(sd/f'gad_mixed/round{r}/bank.npz');rec=read(sd/f'gad_mixed/round{r}/sampling.json');directory=sd/f'display/round{r}';directory.mkdir(parents=True,exist_ok=True)
            bind=signature({'campaign':m['binding'],'bank':str(bank['binding']),'round':r,'count':M,'runtime':runtime()})
            if str(bank['binding'])!=rec['binding']:raise ValueError('Wrong saved bank')
            if (directory/'complete.json').exists():verify_file(directory/'complete.json',bind);continue
            gc=dict(cfg['gad']);gc['steps']=rec['steps'];grid=np.geomspace(gc['t_max'],rec['t_min'],gc['steps']+1);integrate=make_integrator(bank['x'],bank['s'],bank['H'],gc)
            file=directory/'state.npz'
            if file.exists():
                state=npz(file)
                if str(state['binding'])!=bind:raise ValueError('Display checkpoint source/runtime mismatch')
                y,key,done,seconds=jnp.asarray(state['y']),jnp.asarray(state['key']),int(state['done']),float(state['seconds'])
            else:
                key,base=jax.random.split(jax.random.PRNGKey(seed+990031+1009*r));y=jax.random.normal(base,(M,t.dim),dtype=jnp.float64);done=0;seconds=0.
            while done<gc['steps']:
                end=min(gc['steps'],done+gc['checkpoint_steps']);start=time.monotonic()
                y,key,_=integrate(y,key,jnp.asarray(np.stack([grid[done:end],grid[done+1:end+1]],axis=1)));y.block_until_ready();seconds+=time.monotonic()-start;done=end
                if not np.isfinite(np.asarray(y)).all():raise FloatingPointError('Nonfinite display output')
                save_npz(file,y=np.asarray(y),key=np.asarray(key),done=np.array(done),seconds=np.array(seconds),binding=np.array(bind));log(f'seed {seed}: frozen round {r} output {done}/{gc["steps"]}')
            save_npz(directory/'samples.npz',samples=np.asarray(y))
            write(directory/'complete.json',{'binding':bind,'campaign_binding':m['binding'],'bank_binding':str(bank['binding']),'round':r,'count':M,'elapsed_seconds':seconds,'extra_target_requests':0,
                'role':'Fresh independent stochastic outputs of the SAME round-r input field, learned from round r-1. No bank rebuild, extra round, target update, or terminal projection.'})
        reference=npz(out/'reference/samples.npz')['samples_by_chain'][2:].reshape(-1,t.dim);rng=np.random.default_rng(72819);Q=min(pc['support_queries'],len(reference));clean=reference[rng.choice(len(reference),Q,replace=False)];noise=rng.normal(size=clean.shape);rows=[]
        for r in range(1,cfg['gad']['rounds']+1):
            x=npz(sd/f'gad_mixed/round{r}/bank.npz')['x']
            for ti in pc['support_times']:
                a=np.exp(-ti);g=-np.expm1(-2*ti);y=a*clean+np.sqrt(g)*noise;dist=np.maximum((y*y).sum(1)[:,None]+a*a*(x*x).sum(1)[None,:]-2*a*y@x.T,0);w=softmax(-dist/(2*g),axis=1);ess=1/(w*w).sum(1)
                rows.append({'seed':seed,'round':r,'ou_time':ti,'median_conditional_ESS':np.median(ess),'q10_conditional_ESS':np.quantile(ess,.1),'fraction_ESS_below_5':np.mean(ess<5)})
        import pandas as pd
        pd.DataFrame(rows).to_csv(sd/'display/support.csv',index=False)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--seed',type=int,default=42);a=ap.parse_args();frozen_outputs(a.out,a.seed)
