"""Work-matched path/QoI figures, metrics and explicit reference qualification."""
from pathlib import Path
import csv
import json
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from common import read,write,npz,save_npz,log
from models import EVENTS

COLORS={'GN-GAD':'#1764a1','pMALA':'#d45a18','GN-MALA':'#45813b','MAP-Laplace':'#666666','moment-Gaussian':'#9954a5','NUTS':'#222222'}
def choose(x,n):
    x=np.asarray(x);return x[np.linspace(0,len(x)-1,min(n,len(x))).astype(int)]
def sw(x,y,directions,trace):
    n=min(len(x),len(y));x=choose(x,n);y=choose(y,n)
    v=np.mean((np.sort(x@directions.T,axis=0)-np.sort(y@directions.T,axis=0))**2)
    return float(np.sqrt(x.shape[1]*v/max(trace,1e-300)))
def mmd(x,y,scale):
    a=cdist(x,x,'sqeuclidean');b=cdist(y,y,'sqeuclidean');c=cdist(x,y,'sqeuclidean');ans=[]
    for width in [.25,.5,1.,2.]:
        h=max(scale*width,1e-12);aa=np.exp(-a/(2*h*h));bb=np.exp(-b/(2*h*h));cc=np.exp(-c/(2*h*h))
        n,m=len(x),len(y);ans.append((aa.sum()-np.trace(aa))/(n*(n-1))+(bb.sum()-np.trace(bb))/(m*(m-1))-2*cc.mean())
    return float(np.mean(ans))

def reference_report(target,directory,quality):
    pd.DataFrame(quality['diagnostics']).to_csv(directory/'diagnostics.csv',index=False)
    pd.DataFrame(quality['events']).to_csv(directory/'events.csv',index=False)
    a=npz(directory/'samples.npz')['samples_by_chain'];q=target.qois(a.reshape(-1,target.dim)).reshape(a.shape[0],a.shape[1],-1)
    fig,axs=plt.subplots(2,2,figsize=(10,7),layout='constrained')
    for j,ax in enumerate(axs.flat):
        for c in range(len(a)):ax.plot(q[c,:,j],lw=.5,alpha=.6,label=f'chain {c}')
        ax.set(xlabel='retained NUTS draw',ylabel=target.qoi_labels[j])
    axs[0,0].legend(fontsize=7);fig.suptitle(('REFERENCE PASSED' if quality['reference_usable'] else 'PROVISIONAL / REFERENCE GATE FAILED')+f' | Rhat {quality["max_rank_rhat"]:.4f} | min ESS {quality["min_bulk_ess"]:.0f}')
    fig.savefig(directory/'reference_traces.pdf');fig.savefig(directory/'reference_traces.png',dpi=130);plt.close(fig)

def evaluation_context(out):
    from run import load
    m,t=load(out);cfg=m['config'];r=npz(out/'reference/samples.npz')['samples_by_chain'];C,N,D=r.shape
    A=r[:C//2].reshape(-1,D);B=r[C//2:].reshape(-1,D);rng=np.random.default_rng(334401)
    dirs=rng.normal(size=(cfg['evaluation']['directions'],D));dirs/=np.linalg.norm(dirs,axis=1)[:,None]
    if len(B)<2:raise ValueError('Insufficient reference draws')
    mean=B.mean(0);cov=np.cov(B.T);trace=np.trace(cov)
    pairs=rng.integers(0,len(A),size=(4000,2));scale=np.median(np.linalg.norm(A[pairs[:,0]]-A[pairs[:,1]],axis=1))
    eig,V=np.linalg.eigh(np.cov(A.T));factor=V*np.sqrt(np.maximum(eig,1e-10))
    # A fixed posterior-informed subspace is an EVALUATION object, not an initialization or metric.
    audit=choose(A,64);H=t.gn(audit)-np.eye(D);ev,V=np.linalg.eigh(H.mean(0));order=np.argsort(ev)[::-1];ev=ev[order];V=V[:,order]
    count=max(1,int((ev>1).sum()));subspace=V[:,:count]
    return m,t,dict(A=A,B=B,reference=r.reshape(-1,D),mean=mean,cov=cov,trace=trace,scale=scale,directions=dirs,moment_factor=factor,
                   subspace=subspace,gn_eigenvalues=ev,likelihood_dimension=int((ev>1).sum()),effective_dimension=float(np.maximum(ev,0).dot(1/(1+np.maximum(ev,0)))))

def distribution_metrics(x,ctx,cfg):
    ec=cfg['evaluation'];cap=min(ec['cloud_cap'],len(x),len(ctx['B']));xc=choose(x,cap);yc=choose(ctx['B'],cap)
    mc=min(ec['mmd_cap'],len(x),len(ctx['B']));m=x.mean(0);C=np.cov(x.T)
    P=ctx['subspace'];xx=xc@P;yy=yc@P;rr=np.random.default_rng(334402).normal(size=(min(512,ec['directions']),P.shape[1]));rr/=np.linalg.norm(rr,axis=1)[:,None]
    return {'SW2_dimension_normalized':sw(xc,yc,ctx['directions'],ctx['trace']),
            'MMD2_multiscale_unbiased':mmd(choose(x,mc),choose(ctx['B'],mc),ctx['scale']),
            'SW2_informed_subspace':sw(xx,yy,rr,np.trace(P.T@ctx['cov']@P)),
            'mean_error_prior_coordinates':float(np.linalg.norm(m-ctx['mean'])),
            'relative_covariance_error':float(np.linalg.norm(C-ctx['cov'])/np.linalg.norm(ctx['cov'])),
            'metric_cloud_states':cap,'all_retained_states':len(x)}

def likelihood_fit(target,x):
    import jax
    import jax.numpy as jnp
    residual=jax.jit(jax.vmap(target.residual));chi=[];inside=[]
    for first in range(0,len(x),1024):
        rr=np.asarray(residual(jnp.asarray(x[first:first+1024])));chi.extend(np.sum(rr*rr,axis=1));inside.extend((abs(rr)<=3).all(1))
    return np.asarray(chi),{'likelihood_mean_chi2':float(np.mean(chi)),'likelihood_median_chi2':float(np.median(chi)),
        'likelihood_p95_chi2':float(np.quantile(chi,.95)),'all_whitened_residuals_within_3SD':float(np.mean(inside))}

METHODS=['GN-GAD','pMALA mixed','pMALA Laplace']
PALETTE={'GN-GAD':'#1764a1','pMALA mixed':'#d47528','pMALA Laplace':'#8a609e','MAP-Laplace':'#777777','Moment Gaussian':'#489b83','Entry mixture':'#aaaaaa','Reference':'#222222'}

def evaluate_seed(out,seed):
    import copy
    from publication_audit import mean_mcse
    m,t,ctx=evaluation_context(out);cfg=m['config'];R=cfg['gad']['rounds'];pc=cfg['publication'];sd=out/f'seed{seed}';dest=sd/'report';dest.mkdir(exist_ok=True)
    ident=read(sd/'identity.json');setup=npz(sd/'setup/production_setup.npz');info=read(sd/'setup/setup.json');ref=ctx['reference'];refq=t.qois(ref);refev=t.events_from_qois(refq).mean(0);_,reffit=likelihood_fit(t,ref)
    refheld=t.heldout(choose(ctx['B'],4096));refscale=np.sqrt(np.mean(refheld.std(0)**2));refpaths=t.paths(choose(ctx['B'],4096));qsd=np.maximum(refq.std(0),1e-12)
    rows=[];erows=[];qrows=[];counts=[];plots={};plotsq={};plotfit={};plotheld={};plots0={}
    def add(name,r,x,record,view,cap,chains=None):
        c=copy.deepcopy(cfg);c['evaluation']['cloud_cap']=cap;c['evaluation']['mmd_cap']=min(cap,c['evaluation']['mmd_cap'])
        q=t.qois(x);evs=t.events_from_qois(q);ev=evs.mean(0);chi,fit=likelihood_fit(t,x);held=t.heldout(choose(x,min(4096,len(x))));paths=t.paths(choose(x,min(4096,len(x))))
        row={'seed':seed,'method':name,'round':r,'view':view,'work':record.get('work',info['work']),'matched_work_cap':record.get('matched_work_cap',record.get('work',info['work'])),
            'elapsed_seconds':record.get('elapsed_seconds'),'reference_usable':ident['reference_usable'],**distribution_metrics(x,ctx,c),**fit,
            'likelihood_mean_chi2_ratio_to_reference':fit['likelihood_mean_chi2']/reffit['likelihood_mean_chi2'],'max_event_probability_error':float(np.max(abs(ev-refev))),
            'heldout_mean_RMSE_over_ref_RMS_SD':np.sqrt(np.mean((held.mean(0)-refheld.mean(0))**2))/refscale,
            'heldout_SD_relative_RMSE':np.sqrt(np.mean((held.std(0)-refheld.std(0))**2))/refscale,'path_mean_RMSE_m':np.sqrt(np.mean((paths.mean(0)-refpaths.mean(0))**2))}
        for key in ['guard_fraction','mean_conditional_ess','acceptance_rate','unused_requests']:
            if key in record:row[key]=record[key]
        for key,value in record.get('oracle_counts',{}).items():row[key+'_requests']=value
        for j,label in enumerate(EVENTS):
            if chains is not None:
                C=chains.shape[0];a=evs[:,j].reshape(-1,C).T;se=mean_mcse(a);kind='MCMC dependence-aware MCSE; not seed variability'
            else:se=np.sqrt(ev[j]*(1-ev[j])/len(x));kind='Conditional output SE; excludes learned-field/setup uncertainty'
            erows.append({'seed':seed,'method':name,'round':r,'view':view,'work':row['work'],'event':label,'probability':ev[j],'reference_probability':refev[j],'signed_error':ev[j]-refev[j],'within_run_MCSE':se,'MCSE_kind':kind})
        for j,label in enumerate(t.qoi_labels):
            n=min(cap,len(q),len(refq));w1=np.mean(abs(np.sort(choose(q[:,j],n))-np.sort(choose(refq[:,j],n))))
            row['W1_over_SD_'+label]=w1/qsd[j]
            qrows.append({'seed':seed,'method':name,'round':r,'view':view,'qoi':label,'mean':q[:,j].mean(),'sd':q[:,j].std(),'reference_mean':refq[:,j].mean(),'reference_sd':qsd[j],'W1':w1,'W1_over_reference_SD':w1/qsd[j]})
        rows.append(row)
        if r==R and view=='fresh_field':
            plots[name]=choose(x,pc['display_count']);plotsq[name]=q;plotfit[name]=chi;plotheld[name]=held
        return row
    for r in range(1,R+1):
        samples={};recs={};chains={}
        samples['GN-GAD']=npz(sd/f'gad_mixed/round{r}/samples.npz')['samples'];recs['GN-GAD']=read(sd/f'gad_mixed/round{r}/sampling.json')
        for law in cfg['pmala_initializations']:
            name='pMALA '+('Laplace' if law=='laplace' else 'mixed');p=npz(sd/f'pmala_{law}/work{r}.npz');samples[name]=p['samples'];chains[name]=p['samples_by_chain'];recs[name]=read(sd/f'pmala_{law}/work{r}.json')
            np.testing.assert_array_equal(p['samples'],p['samples_by_chain'].transpose(1,0,2).reshape(-1,t.dim))
            if recs[name]['matched_work_cap']!=recs['GN-GAD']['work'] or recs[name]['work']>recs[name]['matched_work_cap']:raise ValueError('Unmatched comparator cap')
        cap=min(cfg['evaluation']['cloud_cap'],*(len(v) for v in samples.values()))
        counts.append({'seed':seed,'round':r,'view':'training_output','common_metric_states':cap,'GAD_states':len(samples['GN-GAD']),'pMALA_states':len(samples['pMALA mixed']),'work':recs['GN-GAD']['work']})
        for name,x in samples.items():add(name,r,x,recs[name],'training_output',cap,chains.get(name))
        if r in pc['display_rounds']:
            samples['GN-GAD']=npz(sd/f'display/round{r}/samples.npz')['samples'];cap=min(pc['fixed_output_metric_cap'],*(len(v) for v in samples.values()))
            counts.append({'seed':seed,'round':r,'view':'fresh_field','common_metric_states':cap,'GAD_states':len(samples['GN-GAD']),'pMALA_states':len(samples['pMALA mixed']),'work':recs['GN-GAD']['work']})
            for name,x in samples.items():add(name,r,x,recs[name],'fresh_field',cap,chains.get(name))
    finalcap=next(v['common_metric_states'] for v in counts if v['round']==R and v['view']=='fresh_field')
    z=np.random.default_rng(seed+8193).normal(size=(pc['display_count'],t.dim))
    for name,x in [('MAP-Laplace',setup['center']+z@setup['factor'].T),('Moment Gaussian',ctx['A'].mean(0)+z@ctx['moment_factor'].T)]:
        row=add(name,0,x,info,'baseline',min(cfg['evaluation']['cloud_cap'],len(x)));plots[name]=x;plotsq[name]=t.qois(x);plotfit[name]=likelihood_fit(t,x)[0];plotheld[name]=t.heldout(choose(x,4096))
    entry=npz(sd/'gad_mixed/round1/bank.npz')['x'];add('Entry mixture',0,entry,info,'baseline',min(cfg['evaluation']['cloud_cap'],len(entry)))
    pd.DataFrame(rows).to_csv(dest/'metrics.csv',index=False);pd.DataFrame(erows).to_csv(dest/'events.csv',index=False);pd.DataFrame(qrows).to_csv(dest/'qois.csv',index=False);pd.DataFrame(counts).to_csv(dest/'common_cloud_counts.csv',index=False)
    save_npz(dest/'plot_clouds.npz',**plots);save_npz(dest/'plot_qois.npz',**plotsq);save_npz(dest/'plot_chi2.npz',**plotfit);save_npz(dest/'plot_heldout.npz',**plotheld)
    write(dest/'evaluation.json',{'campaign_binding':m['binding'],'seed':seed,'reference_usable':ident['reference_usable'],'primary_metric_cloud_cap':cfg['evaluation']['cloud_cap'],
        'fresh_metric_cap':finalcap,'display_count':min(pc['display_count'],*[len(v) for v in plots.values()]),'reference_fit':reffit,'all_MALA_production_states_and_rejection_repeats_retained':True,
        'cloud_rule':'Each method uses the same SW2/MMD cloud count at a given seed/round/view. Means/events use all retained output states; MCMC dependence is handled separately.',
        'fresh_output_role':'Saved round-r input bank, no extra target requests; round 4 uses the field learned from round 3, not a fifth round.'})
    return rows


def campaign_report(out):
    import os,shutil
    from matplotlib.ticker import MaxNLocator
    m,t,ctx=evaluation_context(out);cfg=m['config'];seeds=cfg['seeds'];R=cfg['gad']['rounds'];pc=cfg['publication'];rep=out/'report';tables=rep/'tables';figdir=rep/'figures'
    for p in [tables,figdir]:p.mkdir(parents=True,exist_ok=True)
    frames=[];evframes=[];qframes=[];caps=[];clouds={};qclouds={};chis={};helds={}
    for seed in seeds:
        sd=out/f'seed{seed}/report';info=read(sd/'evaluation.json')
        if info['campaign_binding']!=m['binding']:raise ValueError('Wrong evaluation binding')
        frames.append(pd.read_csv(sd/'metrics.csv'));evframes.append(pd.read_csv(sd/'events.csv'));qframes.append(pd.read_csv(sd/'qois.csv'));caps.append(pd.read_csv(sd/'common_cloud_counts.csv'))
        clouds[seed]=npz(sd/'plot_clouds.npz');qclouds[seed]=npz(sd/'plot_qois.npz');chis[seed]=npz(sd/'plot_chi2.npz');helds[seed]=npz(sd/'plot_heldout.npz')
    df=pd.concat(frames,ignore_index=True);ef=pd.concat(evframes,ignore_index=True);qf=pd.concat(qframes,ignore_index=True);cf=pd.concat(caps,ignore_index=True)
    for seed in seeds:
        for r in range(1,R+1):
            rows=df[(df.seed==seed)&(df['round']==r)&(df.view=='training_output')]
            if len(rows)!=3 or rows.metric_cloud_states.nunique()!=1 or rows.matched_work_cap.nunique()!=1:raise ValueError('Incomplete or unequal-cloud comparison grid')
    for name,data in [('per_seed_metrics',df),('per_seed_events',ef),('scientific_qois',qf),('common_cloud_counts',cf)]:data.to_csv(tables/(name+'.csv'),index=False)
    columns=[c for c in df.select_dtypes(include='number').columns if c not in ['seed','round']]
    agg=df.groupby(['method','view','round'])[columns].agg(['mean','std','count']);agg.columns=['_'.join(v) for v in agg.columns];agg.reset_index().to_csv(tables/'mean_sd_metrics.csv',index=False)
    # Reference floors use the exact effective cloud size of each view/round.
    rng=np.random.default_rng(8194);floors=[]
    for (view,r),g in cf.groupby(['view','round']):
        n=int(g.common_metric_states.min());n=min(n,len(ctx['A']),len(ctx['B']))
        for k in range(cfg['evaluation']['floor_repeats']):
            a=ctx['A'][rng.choice(len(ctx['A']),n,replace=False)];b=ctx['B'][rng.choice(len(ctx['B']),n,replace=False)]
            floors.append({'view':view,'round':r,'count':n,'repeat':k,'SW2':sw(a,b,ctx['directions'],ctx['trace'])})
    ff=pd.DataFrame(floors);ff.to_csv(tables/'reference_cloud_floors.csv',index=False)
    pairs=[]
    for view in ['training_output','fresh_field']:
        for seed in seeds:
            z=df[(df.seed==seed)&(df['round']==R)&(df.view==view)];gad=z[z.method=='GN-GAD'].iloc[0]
            for name in METHODS[1:]:
                other=z[z.method==name].iloc[0]
                pairs.append({'seed':seed,'view':view,'comparator':name,'work_cap':gad.matched_work_cap,'SW2_advantage_other_minus_GAD':other.SW2_dimension_normalized-gad.SW2_dimension_normalized,
                    'max_event_error_advantage_other_minus_GAD':other.max_event_probability_error-gad.max_event_probability_error,'GAD_lower_SW2':bool(gad.SW2_dimension_normalized<other.SW2_dimension_normalized)})
    paired=pd.DataFrame(pairs);paired.to_csv(tables/'paired_final_comparisons.csv',index=False)
    final=df[((df['round']==R)&(df.view=='training_output'))|df.method.isin(['MAP-Laplace','Moment Gaussian'])]
    summarycols=['SW2_dimension_normalized','MMD2_multiscale_unbiased','max_event_probability_error','likelihood_mean_chi2_ratio_to_reference','heldout_mean_RMSE_over_ref_RMS_SD']
    table=[]
    for name in METHODS+['MAP-Laplace','Moment Gaussian']:
        z=final[final.method==name];row={'method':name,'seeds':len(z)}
        for col in summarycols:row[col+'_mean']=z[col].mean();row[col+'_sd']=z[col].std(ddof=1) if len(z)>1 else 0.
        table.append(row)
    pd.DataFrame(table).to_csv(tables/'paper_final_table.csv',index=False)
    tex=['% Generated from per-seed primary metrics; values are mean +/- sample SD.','\\begin{tabular}{lrrrr}','\\toprule','Method & SW2 & MMD$^2$ & Max. event error & $\\chi^2$ ratio \\\\','\\midrule']
    for row in table:
        vals=[(f"{row[c+'_mean']:.2e} $\\pm$ {row[c+'_sd']:.1e}" if c=='MMD2_multiscale_unbiased' else f"{row[c+'_mean']:.3f} $\\pm$ {row[c+'_sd']:.3f}") for c in summarycols[:4]];tex.append(row['method']+' & '+' & '.join(vals)+' \\\\')
    tex+=['\\bottomrule','\\end{tabular}'];(tables/'paper_final_table.tex').write_text('\n'.join(tex)+'\n')
    quality=read(out/'reference/quality.json');provisional=not quality['reference_usable'];ref=ctx['reference'];refq=t.qois(ref);refchi=likelihood_fit(t,ref)[0];refheld=t.heldout(choose(ref,4096));representative=pc['display_seed'] if pc['display_seed'] in seeds else seeds[0]
    plt.rcParams.update({'font.size':9,'axes.labelsize':9,'axes.titlesize':10,'legend.fontsize':8,'xtick.labelsize':8,'ytick.labelsize':8,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':300})
    figures=[];figure_index=[]
    def save(fig,name,caption,primary=True):
        if provisional:fig.suptitle('PROVISIONAL REFERENCE / VALIDATION ONLY',fontsize=10,color='darkred')
        fig.savefig(figdir/(name+'.pdf'),dpi=300,bbox_inches='tight');fig.savefig(figdir/(name+'.png'),dpi=300,bbox_inches='tight')
        figures.append(fig);figure_index.append({'file':name+'.pdf','primary_candidate':primary,'caption':caption})
    def curve(ax,col,view='training_output',xlabel='E+G+H requests'):
        for name in METHODS:
            g=df[(df.method==name)&(df.view==view)].groupby('round');x=g.matched_work_cap.mean();y=g[col].mean();sd=g[col].std().fillna(0)
            ax.plot(x,y,'o-',lw=1.5,ms=3.5,label=name,color=PALETTE[name]);ax.fill_between(x,y-sd,y+sd,color=PALETTE[name],alpha=.15)
        ax.set_xlabel(xlabel);ax.ticklabel_format(axis='x',style='sci',scilimits=(3,3));ax.xaxis.set_major_locator(MaxNLocator(4))
    fig,axs=plt.subplots(1,2,figsize=(6.8,2.65),layout='constrained')
    for ax,col,label in zip(axs,['SW2_dimension_normalized','MMD2_multiscale_unbiased'],['Normalized sliced Wasserstein-2','Multiscale MMD$^2$']):
        curve(ax,col);ax.set_ylabel(label)
        ax.axhline(df[df.method=='MAP-Laplace'][col].mean(),ls=':',color=PALETTE['MAP-Laplace'],label='MAP-Laplace')
        if col=='SW2_dimension_normalized':
            floor=ff[ff.view=='training_output'].groupby('round').SW2.mean();xx=cf[cf.view=='training_output'].groupby('round').work.mean();ax.plot(xx,floor,':',color='#999',label='Reference cloud floor')
    axs[0].legend(fontsize=6.5);save(fig,'accuracy_by_work','Primary metric clouds matched across all methods at each budget; mean +/- sample SD over the planned sampler seeds on one dataset. MAP setup and pMALA adaptation/proposals are charged. Reference cloud floors are empirical diagnostics, not confidence bounds.')
    fig,axs=plt.subplots(1,2,figsize=(6.8,2.65),layout='constrained')
    curve(axs[0],'max_event_probability_error');axs[0].set_ylabel('Maximum event probability error');curve(axs[1],'likelihood_mean_chi2_ratio_to_reference');axs[1].set_ylabel('Mean likelihood $\\chi^2$ / reference');axs[1].axhline(1,ls=':',color='#222');axs[0].legend(fontsize=7)
    save(fig,'events_and_physical_fit','Worst event error and physical likelihood fit at the same charged work caps. Shading is sample SD over sampler seeds.')
    def hist_figure(seed,name):
        shown={'Reference':ref,**{key:choose(clouds[seed][key],pc['display_count']) for key in METHODS+['MAP-Laplace','Moment Gaussian']}}
        positions={key:1.5*x[:,[0,2]] for key,x in shown.items()};rb=positions['Reference'];bounds=np.quantile(rb,[.0005,.9995],axis=0);pad=.1*(bounds[1]-bounds[0]);edges=[np.linspace(bounds[0,j]-pad[j],bounds[1,j]+pad[j],65) for j in range(2)]
        count=min(pc['display_count'],*[len(v) for k,v in positions.items() if k!='Reference'])
        for key in positions:
            if key!='Reference':positions[key]=choose(positions[key],count)
        hist={key:np.histogram2d(*x.T,bins=edges)[0]/len(x) for key,x in positions.items()};vmax=float(hist['Reference'].max());fig,axs=plt.subplots(2,3,figsize=(6.8,4.25),sharex=True,sharey=True,layout='constrained')
        for ax,(key,h) in zip(axs.flat,hist.items()):
            im=ax.pcolormesh(*edges,h.T,vmin=0,vmax=vmax,cmap='magma_r',rasterized=True);ax.set(title=key,xlabel='$c_x$ (m)',ylabel='$c_y$ (m)')
        fig.colorbar(im,ax=list(axs.flat),label='Probability per common bin',fraction=.025,extend='max')
        for key,x in positions.items():
            display_audit.append({'seed':seed,'method':key,'display_states':len(x),'outside_window_fraction':1-np.mean((x[:,0]>=edges[0][0])&(x[:,0]<=edges[0][-1])&(x[:,1]>=edges[1][0])&(x[:,1]<=edges[1][-1])),'reference_based_color_max':vmax})
        save(fig,name,f'Midpoint position, prespecified sampler seed {seed}. GAD uses fresh samples from the frozen round-four field. Every non-reference panel has {count} displayed states; NUTS uses all reference draws. Equal count does not imply equal MCMC ESS. Moment Gaussian is an offline crossfit diagnostic. The shared color maximum is fixed by the reference; higher bins saturate and the color bar marks this explicitly.',seed==representative)
    display_audit=[]
    hist_figure(representative,'posterior_midpoint_seed'+str(representative))
    for seed in seeds:
        if seed!=representative:hist_figure(seed,'appendix_midpoint_seed'+str(seed))
    pd.DataFrame(display_audit).to_csv(tables/'histogram_display_audit.csv',index=False)
    qlabels=['Height at 5 s (m)','Time below $y=0$ (s)','Closest approach to (0,2) (m)','Total displacement (m)']
    fig,axs=plt.subplots(2,2,figsize=(6.8,4.3),layout='constrained')
    for j,ax in enumerate(axs.flat):
        bounds=np.quantile(refq[:,j],[.0001,.9999]);grid=np.linspace(bounds[0],bounds[1],300);qr=np.sort(refq[:,j]);ax.plot(grid,np.searchsorted(qr,grid,side='right')/len(qr),color='#222',lw=1.5,label='Reference')
        for name in METHODS+['MAP-Laplace']:
            curves=np.array([np.searchsorted(np.sort(qclouds[s][name][:,j]),grid,side='right')/len(qclouds[s][name]) for s in seeds]);mean=curves.mean(0);sd=curves.std(0,ddof=1) if len(seeds)>1 else mean*0
            ax.plot(grid,mean,color=PALETTE[name],label=name);ax.fill_between(grid,np.maximum(0,mean-sd),np.minimum(1,mean+sd),color=PALETTE[name],alpha=.12)
        ax.set(xlabel=qlabels[j],ylabel='CDF',ylim=(0,1))
    axs[0,0].legend(fontsize=7);save(fig,'scientific_qoi_CDFs','Final scientific QoI CDFs averaged across sampler seeds, with sample SD bands. GAD uses fresh frozen-field outputs; pMALA uses all production history including rejections. Reference uses all chains. Path QoIs are exact for this constant-velocity model.')
    # Path uncertainty: use a fixed seed, and retain every other seed separately in histograms/CSVs.
    shown={'Reference':choose(ref,4096),**{key:choose(clouds[representative][key],4096) for key in METHODS}}
    fig,axs=plt.subplots(1,2,figsize=(6.8,2.8),layout='constrained')
    for name,x in shown.items():
        p=t.paths(x)
        for j,ax in enumerate(axs):
            lo,hi=np.quantile(p[:,:,j],[.05,.95],axis=0);ax.plot(t.times,p[:,:,j].mean(0),color=PALETTE[name],label=name);ax.fill_between(t.times,lo,hi,color=PALETTE[name],alpha=.10);ax.set(xlabel='Time (s)',ylabel=['x (m)','y (m)'][j])
    axs[0].legend(fontsize=6.5);save(fig,'trajectory_uncertainty',f'Pointwise 90% posterior path intervals and means for the prespecified seed {representative}; these are not simultaneous bands or uncertainty over sampler seeds.')
    fig,axs=plt.subplots(1,2,figsize=(6.8,2.7),layout='constrained')
    chi_grid=np.geomspace(max(np.quantile(refchi,.0001),1e-5),max(np.quantile(refchi,.9999),1),300)
    axs[0].plot(chi_grid,np.searchsorted(np.sort(refchi),chi_grid)/len(refchi),color='#222',label='Reference')
    for name in METHODS+['MAP-Laplace','Moment Gaussian']:
        cdf=np.array([np.searchsorted(np.sort(chis[s][name]),chi_grid)/len(chis[s][name]) for s in seeds]);axs[0].plot(chi_grid,cdf.mean(0),color=PALETTE[name],label=name)
    axs[0].set(xscale='log',xlabel='Sum of squared whitened residuals',ylabel='CDF');axs[0].legend(fontsize=6)
    for name in METHODS:
        means=np.array([helds[s][name].mean(0) for s in seeds]);axs[1].plot(t.times,means.mean(0),label=name,color=PALETTE[name]);axs[1].fill_between(t.times,means.mean(0)-means.std(0),means.mean(0)+means.std(0),color=PALETTE[name],alpha=.12)
    axs[1].plot(t.times,refheld.mean(0),color='#222',ls=':',label='Reference');axs[1].set(xlabel='Time (s)',ylabel='Held-out mean TDOA ($\\mu$s)')
    save(fig,'predictive_and_constraint_checks','Likelihood fit exposes Gaussian constraint violations. Held-out predictions use a third microphone absent from the likelihood; shading there is variation of predicted means over sampler seeds.',False)
    fig,axs=plt.subplots(1,2,figsize=(6.8,2.6),layout='constrained');support=[]
    for seed in seeds:
        a=pd.read_csv(out/f'seed{seed}/display/support.csv');support.append(a)
    sf=pd.concat(support,ignore_index=True);sf.to_csv(tables/'conditional_support.csv',index=False)
    for r in range(1,R+1):
        g=sf[sf['round']==r].groupby('ou_time');axs[0].semilogx(g.median_conditional_ESS.mean().index,g.median_conditional_ESS.mean(),'-o',ms=3,label=f'Round {r}')
    axs[0].set(xlabel='OU time',ylabel='Median conditional ESS');axs[0].legend(fontsize=7)
    for name in METHODS:
        z=df[(df.method==name)&(df.view=='training_output')].groupby('round');axs[1].plot(z.elapsed_seconds.mean(),z.SW2_dimension_normalized.mean(),'o-',color=PALETTE[name],label=name)
    axs[1].set(xlabel='Actual cumulative method seconds',ylabel='Normalized SW2');axs[1].legend(fontsize=6.5);save(fig,'appendix_support_and_timing','Offline conditional-support diagnostics and supplementary elapsed cost. Timing curves are not time-matched comparisons; fresh-output time is itemized separately.',False)
    df[(df.view=='fresh_field')].to_csv(tables/'fresh_field_metrics.csv',index=False)
    # Save each scalar panel independently for manuscript layout flexibility.
    for col,label in [('SW2_dimension_normalized','Normalized sliced Wasserstein-2'),('MMD2_multiscale_unbiased','Multiscale MMD$^2$'),('relative_covariance_error','Relative covariance error'),('max_event_probability_error','Maximum event probability error'),('heldout_mean_RMSE_over_ref_RMS_SD','Normalized held-out mean error')]:
        fig,ax=plt.subplots(figsize=(3.3,2.6),layout='constrained');curve(ax,col);ax.set_ylabel(label);ax.legend(fontsize=6.5);save(fig,'panel_'+col,'Standalone primary-metric panel; mean +/- sample SD across fixed-data sampler seeds.',False)
    # Equal output AND metric counts isolate changes in the learned GAD field.
    # This diagnostic is separate from work-matched comparator tables, whose
    # earliest production history is shorter than the requested cloud cap.
    fieldrows=[]
    fixedcap=min(pc['fixed_output_metric_cap'],pc['display_count'],len(ctx['B']))
    for seed in seeds:
        for r in pc['display_rounds']:
            x=npz(out/f'seed{seed}/display/round{r}/samples.npz')['samples'];c={'evaluation':dict(cfg['evaluation'])};c['evaluation']['cloud_cap']=fixedcap;c['evaluation']['mmd_cap']=min(fixedcap,c['evaluation']['mmd_cap'])
            ev=t.events(x).mean(0);refev=t.events(ref).mean(0)
            fieldrows.append({'seed':seed,'round':r,'output_count':len(x),'metric_count':fixedcap,**distribution_metrics(x,ctx,c),'max_event_probability_error':float(np.max(abs(ev-refev)))})
    fielddf=pd.DataFrame(fieldrows);fielddf.to_csv(tables/'fixed_count_field_refinement.csv',index=False)
    fig,axs=plt.subplots(1,2,figsize=(6.8,2.6),layout='constrained')
    for ax,col,label in zip(axs,['SW2_dimension_normalized','max_event_probability_error'],['Normalized sliced Wasserstein-2','Maximum event probability error']):
        g=fielddf.groupby('round')[col];mean=g.mean();sd=g.std().fillna(0);ax.errorbar(mean.index,mean,yerr=sd,marker='o',color=PALETTE['GN-GAD'],capsize=3);ax.set(xlabel='Transport round',ylabel=label);ax.set_xticks(pc['display_rounds'])
    save(fig,'appendix_fixed_count_field_refinement',f'Fresh outputs from the first and final learned fields, using the same {pc["display_count"]} output count and {fixedcap} metric states at both rounds. Error bars are sample SD across sampler seeds. This is a field-refinement diagnostic, separate from work-matched comparator evaluation.',False)
    temporary=rep/'dashboard.inprogress.pdf'
    ordered=sorted(zip(figures,figure_index),key=lambda pair:not pair[1]['primary_candidate'])
    with PdfPages(temporary) as pdf:
        for page,(fig,metadata) in enumerate(ordered,1):
            pdf.savefig(fig);plt.close(fig);metadata['dashboard_page']=page
    if not temporary.read_bytes().rstrip().endswith(b'%%EOF'):raise RuntimeError('Incomplete dashboard PDF')
    os.replace(temporary,rep/'GN_GAD_4D_DASHBOARD.pdf')
    pd.DataFrame(figure_index).to_csv(tables/'figure_index.csv',index=False)
    gates=[];gate=cfg['promotion_gate'];lo,hi=gate['likelihood_mean_chi2_ratio_range']
    for seed in seeds:
        for view in ['training_output','fresh_field']:
            z=df[(df.seed==seed)&(df.method=='GN-GAD')&(df['round']==R)&(df.view==view)].iloc[0]
            checks={'reference':quality['reference_usable'],'joint':z.SW2_dimension_normalized<=gate['max_SW2_dimension_normalized'],'events':z.max_event_probability_error<=gate['max_event_absolute_error'],'physical_fit':lo<=z.likelihood_mean_chi2_ratio_to_reference<=hi}
            gates.append({'seed':seed,'view':view,'checks':checks,'all_passed':all(checks.values())})
    write(rep/'accuracy_gate.json',{'rows':gates,'thresholds':gate,'automatic_promotion':False})
    for file in ['quality.json','geometry_audit.json','diagnostics.csv','events.csv','native_information.csv']:
        if (out/'reference'/file).exists():shutil.copy2(out/'reference'/file,tables/('reference_'+file))
    fresh_times=[]
    for seed in seeds:
        for r in pc['display_rounds']:
            fresh_times.append({'seed':seed,'round':r,**read(out/f'seed{seed}/display/round{r}/complete.json')})
    pd.DataFrame(fresh_times).to_csv(tables/'fresh_output_cost.csv',index=False)
    write(rep/'summary.json',{'campaign_binding':m['binding'],'seeds':seeds,'particles':cfg['gad']['particles'],'rounds':R,'one_shared_four_chain_reference':True,'reference_usable':quality['reference_usable'],
        'data_replications':1,'uncertainty':f'Mean +/- sample SD across {len(seeds)} sampler seeds on ONE frozen dataset. Reference MCSE and conditional output/MCMC uncertainty are separate.',
        'display_seed_prespecified':representative,'display_output_count':pc['display_count'],'primary_cloud_cap':cfg['evaluation']['cloud_cap'],'per_checkpoint_effective_counts':'tables/common_cloud_counts.csv',
        'cost':'E+G+H primary. Setup, pMALA initialization/warmup and all proposals charged. Offline diagnostics and zero-target fresh-output time are separately recorded.',
        'all_requested_seeds_evaluated':True,'all_work_and_cloud_caps_checked':True,'no_automatic_claim_of_advantage':True,'smoke_only':cfg.get('smoke_only',False)})
    (rep/'READ_ME.md').write_text('Main figure candidates are marked in tables/figure_index.csv, with captions. Every curve includes all planned sampler seeds; no best-seed selection. Histograms use the prespecified seed 42, with other seeds supplied separately. Primary E+G+H curves use matched cloud counts at each checkpoint. Full production histories and rejection repeats are retained. See paper_final_table.csv/.tex and paired_final_comparisons.csv. This is one frozen dataset, not dataset replication.\n')
    log('Publication dashboard: '+str(rep/'GN_GAD_4D_DASHBOARD.pdf'));return rep
