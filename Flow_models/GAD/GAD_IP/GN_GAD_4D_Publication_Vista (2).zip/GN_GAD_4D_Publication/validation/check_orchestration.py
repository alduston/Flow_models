"""Mock scheduler checks: graph, bounded arrays, freeze and duplicate protection."""
import getpass,json,os,runpy,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    parse=runpy.run_path(str(ROOT/'submit_vista.py'))['parse_job_id']
    banner='''-----------------------------------------------------------------
          Welcome to the Vista Supercomputer
-----------------------------------------------------------------

No reservation for this job
--> Verifying valid submit host (login1)...OK
--> Checking available allocation (DMS22021)...OK
'''
    for response in ['1116461\n','1116461;vista\n','Submitted batch job 1116461\n',banner+'1116461\n']:
        assert parse(response)=='1116461'
    for response in [banner,banner+'1116461\n1116462\n','warning 1116461; not a result']:
        try:parse(response)
        except RuntimeError:pass
        else:raise AssertionError('Ambiguous/invalid response accepted')
    with tempfile.TemporaryDirectory() as td:
        tmp=Path(td);bin=tmp/'bin';bin.mkdir();state=tmp/'state.json';state.write_text(json.dumps({'calls':[],'live':False,'next':9000}))
        program='''#!/usr/bin/env python3
import json,os,sys
from pathlib import Path
p=Path(os.environ['MOCK_STATE']);d=json.loads(p.read_text());name=Path(sys.argv[0]).name
if name=='sbatch':
 d['next']+=1;d['calls'].append(sys.argv[1:]);p.write_text(json.dumps(d));print('Welcome to the Vista Supercomputer\\nNo reservation for this job\\n--> Checking allocation (DMS22021)...OK');print(str(d['next'])+';vista')
elif name=='squeue':
 if d['live']:print('9001|RUNNING|None')
elif name=='scancel':
 d['cancelled']=sys.argv[1:];p.write_text(json.dumps(d))
elif name=='sacct':
 import getpass
 jid=sys.argv[sys.argv.index('-j')+1];i=int(jid)-9001
 call=d['calls'][i];stage=call[call.index('--job-name')+1]
 print('|'.join([jid,stage,d.get('job_state','COMPLETED'),d.get('owner',getpass.getuser())])+'|')
'''
        for name in ['sbatch','squeue','scancel','sacct']:
            f=bin/name;f.write_text(program);f.chmod(0o755)
        env=dict(os.environ,PATH=str(bin)+os.pathsep+os.environ['PATH'],MOCK_STATE=str(state));batch=tmp/'batch'
        cmd=[sys.executable,str(ROOT/'submit_vista.py'),'--batch',str(batch),'--python',sys.executable]
        p=subprocess.run(cmd+['--dry-run'],env=env,text=True,capture_output=True);assert p.returncode==0,p.stderr
        assert not batch.exists() and json.loads(state.read_text())['calls']==[]
        p=subprocess.run(cmd,env=env,text=True,capture_output=True);assert p.returncode==0,p.stderr
        d=json.loads(state.read_text());assert len(d['calls'])==5
        assert d['calls'][0][-1]==str(Path(sys.executable).absolute())
        assert d['calls'][1][d['calls'][1].index('--array')+1]=='0-3%2'
        assert d['calls'][3][d['calls'][3].index('--array')+1]=='0-4%2'
        for i in range(1,5):assert d['calls'][i][d['calls'][i].index('--dependency')+1]==f'afterok:{9000+i}'
        p=subprocess.run(cmd,env=env,text=True,capture_output=True);assert p.returncode!=0
        d['live']=True;state.write_text(json.dumps(d));p=subprocess.run(cmd+['--resume'],env=env,text=True,capture_output=True);assert p.returncode!=0
        assert len(json.loads(state.read_text())['calls'])==5
        d['live']=False;state.write_text(json.dumps(d));p=subprocess.run(cmd+['--resume'],env=env,text=True,capture_output=True);assert p.returncode==0,p.stderr
        assert len(json.loads(state.read_text())['calls'])==10
        p=subprocess.run(cmd+['--resume','--case','wide'],env=env,text=True,capture_output=True);assert p.returncode!=0
        # Recreate the old bug: only prepare was accepted, and no ID was saved.
        record=json.loads((batch/'submission.json').read_text());record['jobs']={};record.pop('graph',None);record.pop('submission_responses',None)
        (batch/'submission.json').write_text(json.dumps(record))
        d=json.loads(state.read_text());d['calls']=d['calls'][:1];d['next']=9001;d['job_state']='RUNNING';state.write_text(json.dumps(d))
        # Recovery runs from outside the frozen tree, with no local profiles/data.
        recovery=tmp/'recovery.py';recovery.write_bytes((ROOT/'submit_vista.py').read_bytes())
        fix=[sys.executable,str(recovery),'--batch',str(batch),'--continue-batch','--adopt-prepare','9001']
        before=(batch/'submission.json').read_bytes()
        p=subprocess.run(fix+['--dry-run'],env=env,text=True,capture_output=True);assert p.returncode==0,(p.stdout,p.stderr)
        assert before==(batch/'submission.json').read_bytes() and len(json.loads(state.read_text())['calls'])==1
        # A failed or wrong-owner prepare must never enqueue downstream work.
        for field,value in [('job_state','FAILED'),('owner','another-user')]:
            original=d.get(field);d[field]=value;state.write_text(json.dumps(d))
            p=subprocess.run(fix,env=env,text=True,capture_output=True);assert p.returncode!=0
            assert before==(batch/'submission.json').read_bytes() and len(json.loads(state.read_text())['calls'])==1
            if original is None:d.pop(field)
            else:d[field]=original
        state.write_text(json.dumps(d))
        p=subprocess.run(fix,env=env,text=True,capture_output=True);assert p.returncode==0,(p.stdout,p.stderr)
        recovered=json.loads((batch/'submission.json').read_text());d=json.loads(state.read_text())
        assert len(d['calls'])==5 and recovered['jobs']==dict(zip(['prepare','chains','reference-merge','seeds','report'],map(str,range(9001,9006))))
        assert d['calls'][1][d['calls'][1].index('--dependency')+1]=='afterok:9001'
        assert len(recovered['submission_responses'])==4
        # Repeated recovery is a no-op even when the graph remains live.
        p=subprocess.run(fix,env=env,text=True,capture_output=True);assert p.returncode==0,(p.stdout,p.stderr)
        assert len(json.loads(state.read_text())['calls'])==5
        # Frozen modifications are rejected, even for read-only recovery.
        (batch/'code/models.py').write_text('tampered')
        p=subprocess.run(fix+['--dry-run'],env=env,text=True,capture_output=True);assert p.returncode!=0
    result={'passed':True,'dry_run_no_side_effects':True,'five_stage_dependencies_checked':True,'max_active_arrays_two':True,'source_frozen_and_verified':True,'live_duplicate_submission_refused':True,'changed_case_resume_refused':True,'vista_banner_and_cluster_id_parsed':True,'ambiguous_response_refused':True,'unrecorded_prepare_adopted_without_duplicate':True,'recovery_uses_frozen_code_and_settings':True,'failed_or_wrong_owner_prepare_refused':True,'repeat_recovery_no_duplicate':True,'tampered_frozen_code_refused':True,'mock_only_no_real_jobs_submitted':True}
    (ROOT/'validation/orchestration.json').write_text(json.dumps(result,indent=2)+'\n');print(result)

if __name__=='__main__':main()
