"""Mock loader/module regression: explicit venv still needs base libpython."""
import os,shlex,subprocess,tempfile,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td);base=root/'base';venv=root/'venv';(base/'bin').mkdir(parents=True);(base/'lib').mkdir();(venv/'bin').mkdir(parents=True)
        py=base/'bin/python3';py.write_text('''#!/bin/bash
case ":${LD_LIBRARY_PATH:-}:" in
  *":"''' + shlex.quote(str(base/'lib')) + '''":"*) ;;
  *) echo 'mock: libpython3.11.so.1.0 unavailable' >&2; exit 127 ;;
esac
if [[ "${1:-}" == --version ]]; then echo 'Python 3.11.8 (startup test mock)'; fi
''');py.chmod(0o755);(venv/'bin/python').symlink_to(py);(venv/'pyvenv.cfg').write_text('home = '+str(base/'bin')+'\n')
        # The old explicit-Python path fails before any Python code can run.
        env=dict(os.environ);env.pop('LD_LIBRARY_PATH',None);env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None);env.pop('GAD4_SKIP_MODULES',None)
        before=subprocess.run([str(venv/'bin/python'),'--version'],env=env,text=True,capture_output=True);assert before.returncode==127
        # Model the site's module command in this private test shell.
        init=root/'bash_init.sh';init.write_text('module() { export GAD4_TEST_MODULE_LOADED=1; }\n');env['BASH_ENV']=str(init)
        cmd=['bash','-c','set -euo pipefail; source "$1" "$2"; [[ "${GAD4_TEST_MODULE_LOADED:-}" == 1 ]]; "$GAD4_PY" --version','startup',str(ROOT/'slurm/environment.sh'),str(venv/'bin/python')]
        after=subprocess.run(cmd,env=env,text=True,capture_output=True);assert after.returncode==0,after.stderr
        # Base-library repair also works without an initialized module function.
        env.pop('BASH_ENV');after2=subprocess.run(['bash','-c','source "$1" "$2"; "$GAD4_PY" --version','startup',str(ROOT/'slurm/environment.sh'),str(venv/'bin/python')],env=env,text=True,capture_output=True);assert after2.returncode==0,after2.stderr
        # Status must remain useful before campaign initialization and without JAX.
        batch=root/'batch';batch.mkdir();(batch/'prepare-1.log').write_text('libpython startup failure\n')
        status=subprocess.run(['python3',str(ROOT/'status_vista.py'),'--batch',str(batch)],env=env,text=True,capture_output=True);assert status.returncode==0 and 'not initialized' in status.stdout
    result={'passed':True,'old_missing_library_error_reproduced_exit_127':True,'explicit_venv_restores_module_environment':True,'base_libpython_path_restored_before_Python_starts':True,'base_library_fallback_without_module_function':True,'pre_initialization_status_needs_no_JAX_or_venv':True,'mock_only_no_GPU_or_cluster_execution':True}
    (ROOT/'validation/python_startup.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
if __name__=='__main__':main()
