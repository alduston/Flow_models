"""Interrupt/resume equality of actual GAD and both MALA state machines."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tempfile
import numpy as np
import jax
jax.config.update('jax_enable_x64',True)
import jax.numpy as jnp
from common import ROOT,read,npz,write
from samplers import gad,mala

def check():
    cfg=read(ROOT/'profiles/smoke.json');cfg['gad'].update(particles=32,steps=100,checkpoint_steps=25);cfg['pmala'].update(warmup=2,gn_warmup=2)
    class Gaussian:
        dim=4;case='Gaussian restart test'
        energy=staticmethod(lambda x:.5*jnp.vdot(x,x))
        gn_one=staticmethod(lambda x:jnp.eye(4))
        prior_draws=staticmethod(lambda rng,n:rng.normal(size=(n,4)))
        joint=staticmethod(lambda x:(-.5*np.sum(x*x,axis=1),-x))
        gn=staticmethod(lambda x:np.broadcast_to(np.eye(4),(len(x),4,4)).copy())
    target=Gaussian();st={'center':np.zeros(4),'factor':np.eye(4),'steps':np.array(100),'t_min':np.array(1e-6)}
    info={'oracle_counts':{'energy':0,'gradient':0,'hessian':0},'elapsed_seconds':0}
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);a=root/'a';b=root/'b'
        records=gad(target,cfg,st,info,a,'same',42,'mixed')
        gad(target,cfg,st,info,b,'same',42,'mixed',stop_after_chunks=1)
        recovered=gad(target,cfg,st,info,b,'same',42,'mixed')
        for r in [1,2]:
            np.testing.assert_array_equal(npz(a/f'round{r}/samples.npz')['samples'],npz(b/f'round{r}/samples.npz')['samples'])
            assert records[r-1]['oracle_counts']==recovered[r-1]['oracle_counts']
        for kind in ['pmala','gnmala']:
            x=root/f'{kind}_a';y=root/f'{kind}_b'
            mala(target,cfg,st,info,records,x,'same',42,'mixed',kind)
            mala(target,cfg,st,info,records,y,'same',42,'mixed',kind,stop_after_blocks=1)
            mala(target,cfg,st,info,records,y,'same',42,'mixed',kind)
            for r in [1,2]:
                np.testing.assert_array_equal(npz(x/f'work{r}.npz')['samples'],npz(y/f'work{r}.npz')['samples'])
                assert read(x/f'work{r}.json')['oracle_counts']==read(y/f'work{r}.json')['oracle_counts']
    return {'passed':True,'GAD_resumed_samples_bitwise_equal':True,'pMALA_resumed_full_history_bitwise_equal':True,'GN_MALA_resumed_full_history_bitwise_equal':True,'ledgers_equal':True}

if __name__=='__main__':
    result=check();write(ROOT/'validation/restart_test.json',result);print(result)
