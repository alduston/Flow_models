"""Standard-library-only extraction, GPU isolation and logged child processes."""
# Standard-library-only helpers, used in the notebook kernel.
import collections
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import zipfile


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda: f.read(1024*1024), b''):
            h.update(part)
    return h.hexdigest()


def locate_bundle(input_root, explicit=None):
    root = Path(input_root)
    if explicit:
        found = [Path(explicit)]
    else:
        found = sorted(p for p in root.rglob('*.zip') if p.stem.lower().startswith('gn_gad_trajectory4_pilot'))
        if not found:
            found = sorted(p.parent for p in root.rglob('BUNDLE_MANIFEST.json')
                           if (p.parent/'run.py').is_file() and (p.parent/'data/primary.json').is_file())
    if not found:
        raise FileNotFoundError('Attach GN_GAD_trajectory4_pilot.zip as a dataset, or set ARCHIVE to its ZIP/extracted directory.')
    if len(found) > 1:
        raise ValueError('Several bundles found. Set ARCHIVE to one of: '+str([str(p) for p in found]))
    if not found[0].exists():
        raise FileNotFoundError(found[0])
    return found[0]


def verify_source(code, expected_manifest):
    manifest = code/'BUNDLE_MANIFEST.json'
    if digest(manifest) != expected_manifest:
        raise ValueError('This is a different bundle version. Use the 1 November GN_GAD_trajectory4_pilot.zip supplied in this chat.')
    data = json.loads(manifest.read_text())
    for rel, expected in data['files_sha256'].items():
        path = code/rel
        if not path.is_file() or digest(path) != expected:
            raise ValueError('Bundle integrity mismatch: '+str(path))
    return data


def prepare_source(archive, work, expected_zip, expected_manifest):
    code = work/'source'/'GN_GAD_trajectory4_pilot'
    if archive.is_file() and digest(archive) != expected_zip:
        raise ValueError('ZIP SHA256 differs from the current GN_GAD_trajectory4_pilot.zip. Attach the current archive; do not reuse an earlier Vista bundle.')
    if code.exists():
        verify_source(code, expected_manifest)
        return code
    code.parent.mkdir(parents=True, exist_ok=True)
    if archive.is_dir():
        verify_source(archive, expected_manifest)
        shutil.copytree(archive, code)
    else:
        with tempfile.TemporaryDirectory(dir=work) as td:
            stage = Path(td)
            with zipfile.ZipFile(archive) as z:
                for member in z.infolist():
                    dest = (stage/member.filename).resolve()
                    if not dest.is_relative_to(stage.resolve()):
                        raise ValueError('Unsafe ZIP member: '+member.filename)
                    if (member.external_attr >> 16) & 0o170000 == 0o120000:
                        raise ValueError('Symlink in input ZIP: '+member.filename)
                bad = z.testzip()
                if bad:
                    raise ValueError('Corrupt ZIP member: '+bad)
                z.extractall(stage)
            candidates = [p.parent for p in stage.rglob('run.py') if (p.parent/'BUNDLE_MANIFEST.json').exists()]
            if len(candidates) != 1:
                raise ValueError('Could not uniquely identify bundle root: '+str(candidates))
            verify_source(candidates[0], expected_manifest)
            shutil.copytree(candidates[0], code)
    verify_source(code, expected_manifest)
    return code


def gpu_inventory():
    query = subprocess.run(['nvidia-smi', '--query-gpu=index,uuid,name,memory.total', '--format=csv,noheader,nounits'],
                           text=True, capture_output=True, check=True)
    gpus = []
    for row in query.stdout.strip().splitlines():
        index, uuid, name, memory = [v.strip() for v in row.split(',')]
        gpus.append({'index': index, 'uuid': uuid, 'name': name, 'memory_mib': int(memory)})
    if len(gpus) < 1:
        raise RuntimeError('Select a Kaggle GPU accelerator, then rerun (T4 x2 preferred). Found: '+str(gpus))
    return gpus[:2]


def child_env(gpu_uuid, threads=1):
    env = dict(os.environ)
    # Preserve the mounted NVIDIA driver libraries; prefer our private CUDA runtime.
    for key in ['PYTHONPATH', 'PYTHONHOME', 'JAX_PLATFORMS', 'JAX_PLATFORM_NAME',
                'JAX_CUDA_VISIBLE_DEVICES', 'JAX_COMPILATION_CACHE_DIR', 'XLA_FLAGS']:
        env.pop(key, None)
    runtime = Path(os.environ.get('GAD4_PRIVATE_RUNTIME', str(Path('/tmp') / f'gad_trajectory4_jax062_py{sys.version_info.major}{sys.version_info.minor}')))
    private_libs = sorted(Path(runtime).glob('lib/python*/site-packages/nvidia/*/lib'))
    driver_libs = [Path('/usr/local/nvidia/lib64'), Path('/usr/local/nvidia/lib')]
    inherited = [Path(p) for p in os.environ.get('LD_LIBRARY_PATH', '').split(os.pathsep) if p]
    paths = []
    for p in [*private_libs, *driver_libs, *inherited]:
        if p.is_dir() and 'stubs' not in p.parts and str(p) not in paths:
            paths.append(str(p))
    if paths:
        env['LD_LIBRARY_PATH'] = os.pathsep.join(paths)
    else:
        env.pop('LD_LIBRARY_PATH', None)
    env.update(CUDA_VISIBLE_DEVICES=gpu_uuid, JAX_PLATFORMS='cuda', JAX_ENABLE_X64='true',
               XLA_PYTHON_CLIENT_PREALLOCATE='false', JAX_ENABLE_COMPILATION_CACHE='false',
               OMP_NUM_THREADS=str(threads), OPENBLAS_NUM_THREADS=str(threads), MKL_NUM_THREADS=str(threads),
               NUMEXPR_NUM_THREADS=str(threads), MPLBACKEND='Agg', PYTHONUNBUFFERED='1', PYTHONNOUSERSITE='1')
    return env


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True)+'\n')
    os.replace(tmp, path)


def stop_processes(processes):
    for p in processes:
        if p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
    deadline = time.monotonic()+5
    while any(p.poll() is None for p in processes) and time.monotonic() < deadline:
        time.sleep(.1)
    for p in processes:
        if p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    for p in processes:
        p.wait()


def run_logged(cmd, env, log_path, cwd, heartbeat=30):
    log_path = Path(log_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    print('Running:', ' '.join(str(x) for x in cmd), flush=True)
    print('Log:', log_path, flush=True)
    p = None
    with log_path.open('a') as log:
        log.write('\n=== '+time.strftime('%Y-%m-%d %H:%M:%S')+' ===\n'); log.flush()
        started = time.monotonic()
        offset = log_path.stat().st_size
        try:
            p = subprocess.Popen([str(x) for x in cmd], cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            with log_path.open() as reader:
                reader.seek(offset)
                last = time.monotonic()
                while True:
                    new = reader.read()
                    if new:
                        print(new, end='', flush=True)
                    rc = p.poll()
                    if rc is not None:
                        remaining = reader.read()
                        if remaining:
                            print(remaining, end='', flush=True)
                        break
                    if time.monotonic()-last >= heartbeat:
                        print(f'Elapsed {(time.monotonic()-started)/60:.1f} min; stage still running. Full log: {log_path.name}', flush=True)
                        last = time.monotonic()
                    time.sleep(1)
            if rc:
                error = subprocess.CalledProcessError(rc, cmd)
                error.add_note('Last subprocess output ('+str(log_path)+'):\n'+log_path.read_text(errors='replace')[-10000:])
                raise error
        except BaseException:
            if p is not None:
                stop_processes([p])
            raise
    return time.monotonic()-started


def run_parallel(jobs,devices,py,code,work,prefix):
    """Dynamic queue; at most one process group on each physical GPU."""
    pending=collections.deque(jobs);running={};handles=[];last=0;started=time.monotonic()
    logs=Path(work)/'logs';logs.mkdir(parents=True,exist_ok=True)
    def launch(lane,job):
        name,args=job;path=logs/f'{prefix}_{name}.log';handle=path.open('a');handles.append(handle)
        handle.write('\n=== '+time.strftime('%Y-%m-%d %H:%M:%S')+' ===\n');handle.flush()
        p=subprocess.Popen([str(py),'-u',str(Path(code)/'run.py'),*map(str,args)],cwd=code,env=child_env(devices[lane]['uuid']),stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
        running[lane]={'p':p,'name':name,'log':path};print(f'GPU {devices[lane]["index"]}: {name}',flush=True)
    try:
        for lane in range(len(devices)):
            if pending:launch(lane,pending.popleft())
        while running:
            for lane,task in list(running.items()):
                rc=task['p'].poll()
                if rc is None:continue
                if rc:raise RuntimeError(task['name']+' failed:\n'+task['log'].read_text(errors='replace')[-12000:])
                del running[lane]
                if pending:launch(lane,pending.popleft())
            if time.monotonic()-last>=30 and running:
                print(f'{prefix}: {(time.monotonic()-started)/60:.1f} min; {len(pending)} queued',flush=True)
                for lane,task in running.items():
                    lines=task['log'].read_text(errors='replace').splitlines();print('  '+task['name']+': '+(lines[-1] if lines else 'starting'),flush=True)
                last=time.monotonic()
            if running:time.sleep(1)
    except BaseException:
        stop_processes([x['p'] for x in running.values()]);raise
    finally:
        for h in handles:h.close()

