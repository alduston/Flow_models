"""Reference-only affine native coordinates and exact baseline reflection."""
import numpy as np
import jax.numpy as jnp
from common import npz,read,write,save_npz,verify_file

def prepare(target,cfg,setup,directory,bind):
    file=directory/'coordinates.json'
    if file.exists():return verify_file(file,bind)
    save_npz(directory/'coordinates.npz',center=setup['center'],factor=setup['factor'])
    write(file,{'binding':bind,'kind':'affine_native','exact_target':True,
        'note':'Native four coefficients, constant nonsingular affine MAP transform only; no nonlinear chart.'})
    return read(file)

def coordinates(target,cfg,setup,directory,bind):
    info=verify_file(directory/'coordinates.json',bind);a=npz(directory/'coordinates.npz');m,L=jnp.asarray(a['center']),jnp.asarray(a['factor'])
    def decode(z):return m+L@z
    def potential(z):return target.energy(decode(z))
    def encode(x):return np.linalg.solve(np.asarray(L),x-np.asarray(m))
    return decode,potential,encode,info

def reflection(target,center,factor):
    r=np.asarray(target.data['receiver_positions_m']);axis=(r[1]-r[0])/np.linalg.norm(r[1]-r[0]);n=np.array([-axis[1],axis[0]])
    mid=(r[0]+r[1])/2;R=np.eye(2)-2*np.outer(n,n);c=2*n*(n@mid)
    An=np.kron(R,np.eye(2));bn=np.array([c[0]/1.5,0,c[1]/1.5,0])
    A=np.linalg.solve(factor,An@factor);b=np.linalg.solve(factor,An@center+bn-center)
    np.testing.assert_allclose(A@A,np.eye(4),atol=1e-9);np.testing.assert_allclose(A@b+b,0,atol=1e-9)
    assert abs(np.linalg.slogdet(A)[1])<1e-8
    return A,b
