"""Numerical tests of derivatives, noise covariance and exact MH/OU semantics."""
import time
import numpy as np
import jax
import jax.numpy as jnp
from common import ROOT,read,runtime
from models import Target
from vendor.lfgi import score_batch,make_integrator
from prepare import gaussian_control
from samplers import make_pmala_kernels,make_gnmala_kernels

def numerical_tests(target,cfg):
    rng=np.random.default_rng(631);rows=[]
    for case in ['primary','narrow','wide','informative']:
        t=Target(case,target.dim)
        for x in [np.zeros(t.dim),rng.normal(size=t.dim)*.2,rng.normal(size=t.dim)]:
            v=rng.normal(size=t.dim);v/=np.linalg.norm(v);h=2e-6
            lp,s=t.joint(x[None]);ep,_=t.joint((x+h*v)[None]);em,_=t.joint((x-h*v)[None])
            fd=(ep[0]-em[0])/(2*h);ge=abs(fd-s[0]@v)/max(1,abs(fd),abs(s[0]@v))
            jf=np.asarray((t.residual(jnp.asarray(x+h*v))-t.residual(jnp.asarray(x-h*v)))/(2*h))
            jj=np.asarray(t.jacobian(jnp.asarray(x)))@v;je=np.linalg.norm(jf-jj)/max(1,np.linalg.norm(jj))
            ad=np.asarray(jax.jacfwd(t.residual)(jnp.asarray(x)));np.testing.assert_allclose(np.asarray(t.jacobian(jnp.asarray(x))),ad,rtol=3e-12,atol=2e-10)
            H=t.gn(x[None])[0];np.testing.assert_allclose(H,np.eye(t.dim)+ad.T@ad,rtol=2e-12,atol=2e-10)
            assert ge<3e-5 and je<3e-5,(case,ge,je)
            assert np.linalg.eigvalsh(H).min()>1-1e-8
            rows.append({'case':case,'relative_score_direction_error':ge,'relative_residual_Jv_error':je})
        sd=t.data['arrival_sd_us'];nr=len(t.data['receiver_positions_m'])-1
        np.testing.assert_allclose(t.data['noise_covariance_us2'],sd**2*(np.eye(nr)+np.ones((nr,nr))))
    p=Target('primary');wide=Target('wide');full=Target('informative')
    a=(np.array(p.data['y'])-p.data['y_clean'])/p.data['arrival_sd_us'];b=(np.array(wide.data['y'])-wide.data['y_clean'])/wide.data['arrival_sd_us']
    np.testing.assert_allclose(a,b,atol=1e-13);np.testing.assert_allclose(np.array(full.data['y'])[:,:1],p.data['y'])
    from reference_coordinates import reflection
    A,b=reflection(p,np.zeros(4),np.eye(4));xx=rng.normal(size=(20,4));xr=xx@A.T+b
    np.testing.assert_allclose(np.asarray(jax.vmap(p.forward)(jnp.asarray(xx))),np.asarray(jax.vmap(p.forward)(jnp.asarray(xr))),atol=2e-10)
    # Zero velocity recovers the old static two-receiver forward map.
    x=np.array([.65/1.5,0,1.3/1.5,0]);f=np.asarray(p.forward(x))
    np.testing.assert_allclose(f,np.broadcast_to(f[0],f.shape),atol=1e-12)
    exact=p.qois(xx);grid=p.paths(xx,True);dt=10/(grid.shape[1]-1)
    approx=np.trapezoid((grid[:,:,1]<0).astype(float),dx=dt,axis=1)
    assert np.max(abs(exact[:,1]-approx))<=2*dt
    dist=np.linalg.norm(grid-np.array([0.,2.]),axis=-1).min(1)
    assert np.max(abs(exact[:,2]-dist))<.002
    chart_checks=[{'native_reflection_likelihood_invariant':True,'analytic_path_qois_checked':True}]
    gaussian=[]
    for d in [2,4,16]:
        Q,_=np.linalg.qr(rng.normal(size=(d,d)));C=(Q*np.geomspace(1e-4,1,d))@Q.T;H=np.linalg.inv(C);m=rng.normal(size=d)*.2
        x=rng.multivariate_normal(m,C,37);s=-(x-m)@H;hh=np.broadcast_to(H,(len(x),d,d));query=rng.normal(size=(9,d))
        for t in [1e-10,1e-6,.01,.3,3.,10.]:
            actual,_=score_batch(jnp.asarray(query),t,jnp.asarray(x),jnp.asarray(s),jnp.asarray(hh));aa=np.exp(-t);gg=-np.expm1(-2*t)
            expected=-(query-aa*m)@np.linalg.inv(aa*aa*C+gg*np.eye(d));err=np.linalg.norm(np.asarray(actual)-expected)/max(1,np.linalg.norm(expected))
            assert err<3e-9,(d,t,err);gaussian.append({'dimension':d,'time':t,'relative_score_error':err})
        ctl=gaussian_control(m,C,10,1e-8,600);assert ctl['max_relative_variance_error']<.01
    d=4;N=12000
    class Gaussian:
        dim=d
        energy=staticmethod(lambda x:.5*jnp.vdot(x,x))
        gn_one=staticmethod(lambda x:jnp.diag(1+.3*x*x))
    stationarity={}
    for kind,make in [('pmala',lambda:make_pmala_kernels(Gaussian(),np.zeros(d),np.eye(d))),('gnmala',lambda:make_gnmala_kernels(Gaussian()))]:
        initial,_,production=make();x=jnp.asarray(rng.normal(size=(N,d)));vals=initial(x)
        carry=(x,*vals,jax.random.PRNGKey(831),jnp.linspace(.02,.4,N));state,result=production(carry,1);y=np.asarray(state[0])
        me=np.linalg.norm(y.mean(0))/np.sqrt(d);ce=np.linalg.norm(np.cov(y.T)-np.eye(d))/np.sqrt(d)
        assert me<.04 and ce<.07,(kind,me,ce);stationarity[kind]={'normalized_mean_error':me,'relative_covariance_error':ce,'mean_acceptance':float(np.asarray(result[1]).mean())}
    pc=cfg['pmala'];n=cfg['gad']['particles']
    for kind,cost,warm in [('pmala',2,pc['warmup']),('gnmala',3,pc.get('gn_warmup',pc['warmup']))]:
        assert cost*pc['chains']*(warm+1)<3*n,(kind,'warmup consumes first cap')
        assert (3*n)%(cost*pc['chains'])==0,(kind,'batch size prevents exact matching')
    # Measure actual target/bank and cached transport work at the selected bank size.
    xx=rng.normal(size=(n,target.dim));start=time.monotonic();lp,s=target.joint(xx);H=target.gn(xx);bank_sec=time.monotonic()-start
    gc=dict(cfg['gad']);integrate=make_integrator(xx,s,H,gc);M=min(64,n);query=jnp.asarray(rng.normal(size=(M,target.dim)))
    grid=np.geomspace(gc['t_max'],gc['t_min_cap'],gc['steps']+1);times=jnp.asarray(np.stack([grid[:25],grid[1:26]],axis=1))
    start=time.monotonic();y,_,_=integrate(query,jax.random.PRNGKey(22),times);jax.block_until_ready(y);first=time.monotonic()-start
    start=time.monotonic();y,_,_=integrate(query,jax.random.PRNGKey(23),times);jax.block_until_ready(y);cached=time.monotonic()-start
    return {'passed':True,'derivatives':rows,'Gaussian_exact_LFGI':gaussian,'reference_chart_checks':chart_checks,'MH_stationarity':stationarity,'physical_shared_reference_noise_checked':True,
            'cost_probe':{'bank_particles':n,'query_particles':M,'interval_steps':25,'bank_E_G_GN_seconds':bank_sec,'transport_first_call_seconds':first,'transport_cached_seconds':cached,
                          'rough_transport_seconds_per_round':cached*(n/M)*(gc['steps']/25),'estimate_caveat':'Simple query scaling at fixed N; launch/batching/compilation differ. Not a measured full-run ETA.'},
            'runtime':runtime(),'basis_validation':read(ROOT/'data/basis_validation.json')}

if __name__=='__main__':
    import json
    from common import clean
    result=numerical_tests(Target(),read(ROOT/'profiles/smoke.json'))
    print(json.dumps(clean(result),indent=2))
