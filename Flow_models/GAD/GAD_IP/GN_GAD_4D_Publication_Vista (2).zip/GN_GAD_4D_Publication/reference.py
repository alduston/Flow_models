"""One four-chain exact-potential NUTS reference per fixed campaign target."""
import pickle
import time
import warnings
from collections import namedtuple
import numpy as np
import jax
import jax.numpy as jnp
from numpyro.infer import MCMC,NUTS
from common import log,read,write,npz,save_npz,save_pickle,runtime,signature,verify_file
from models import EVENTS

from numpyro.infer.hmc import HMCState
FlipState=namedtuple('FlipState',HMCState._fields+('flip_attempted','flip_accepted'))

class ReferenceNUTS(NUTS):
    """NUTS followed by an exact, lazy, unit-Jacobian involution MH move.

    Used only for the reference to traverse reflected whole-path families.
    Warmup remains ordinary NUTS. The post-warmup proposal is a 50:50
    mixture of identity and a deterministic reflection in chart coordinates.
    Every physical residual and the full proper prior enter its MH ratio.
    """
    def __init__(self,potential_fn,flip_matrix,flip_offset,**kwargs):
        super().__init__(potential_fn=potential_fn,**kwargs)
        self.ref_potential=potential_fn;self.flip_matrix=jnp.asarray(flip_matrix);self.flip_offset=jnp.asarray(flip_offset)
    def init(self,rng_key,num_warmup,*args,**kwargs):
        self.ref_warmup=num_warmup;s=super().init(rng_key,num_warmup,*args,**kwargs)
        return FlipState(*s,jnp.array(False),jnp.array(False))
    def sample(self,state,model_args,model_kwargs):
        s=super().sample(state,model_args,model_kwargs);key,ak,uk=jax.random.split(s.rng_key,3)
        attempt=(s.i>self.ref_warmup)&jax.random.bernoulli(ak,.5)
        z=self.flip_matrix@s.z+self.flip_offset
        pe,g=jax.lax.cond(attempt,lambda zz:jax.value_and_grad(self.ref_potential)(zz),lambda zz:(s.potential_energy,s.z_grad),z)
        accept=attempt&jnp.isfinite(pe)&jnp.all(jnp.isfinite(g))&(jnp.log(jax.random.uniform(uk,dtype=jnp.float64))<jnp.minimum(0.,s.potential_energy-pe))
        s=s._replace(z=jnp.where(accept,z,s.z),potential_energy=jnp.where(accept,pe,s.potential_energy),z_grad=jnp.where(accept,g,s.z_grad),rng_key=key)
        # energy/accept_prob/diverging remain diagnostics of the NUTS substep,
        # before the separate MH move; momentum is refreshed by the next step.
        return FlipState(*s,attempt,accept)

def chain(target,cfg,setup,directory,bind,index):
    rc=cfg['reference'];directory.mkdir(parents=True,exist_ok=True);cd=directory/f'chain{index}';cd.mkdir(exist_ok=True)
    if (cd/'complete.json').exists():return verify_file(cd/'complete.json',bind)
    from reference_coordinates import coordinates
    coordinate_binding=signature({'campaign':bind,'role':'independent reference MAP'})
    decode_one,potential,encode,coordinate_info=coordinates(target,cfg,setup,directory/'setup',coordinate_binding)
    decode=jax.jit(jax.vmap(decode_one))
    options=dict(dense_mass=True,target_accept_prob=rc['target_accept'],max_tree_depth=rc['max_depth'])
    use_flip=rc.get('native_reflection',True) and rc.get('reflection_moves',True)
    if use_flip:
        from reference_coordinates import reflection
        co=npz(directory/'setup/coordinates.npz');A,b=reflection(target,co['center'],co['factor'])
        kernel=ReferenceNUTS(potential,A,b,**options)
    else:kernel=NUTS(potential_fn=potential,**options)
    sb=signature({'binding':bind,'runtime':runtime(),'chain':index});rs=rc['seed']
    rng=np.random.default_rng(rs+3901);candidates=setup['candidates']
    far=int(np.argmax(np.linalg.norm(candidates-candidates[0],axis=1)))
    starts=[candidates[0],candidates[far],*rng.normal(size=(2,target.dim))]
    x=starts[index] if index<4 else rng.normal(size=target.dim)
    z=encode(x)
    def restore(file):
        with file.open('rb') as f:v=pickle.load(f)
        if v['state_binding']!=sb:raise ValueError('NUTS checkpoint target/runtime/source mismatch')
        v['state']=jax.tree_util.tree_map(jnp.asarray,v['state']);return v
    wf=cd/'warmup.pkl'
    if wf.exists():warm=restore(wf)
    else:
        log(f'NUTS chain {index+1}/{rc["chains"]}: warmup {rc["warmup"]}')
        mc=MCMC(kernel,num_warmup=rc['warmup'],num_samples=rc['chunk'],progress_bar=False);start=time.monotonic()
        mc.warmup(jax.random.PRNGKey(rs+100003*(index+1)),init_params=jnp.asarray(z),collect_warmup=True,extra_fields=('num_steps',))
        jax.block_until_ready(mc.post_warmup_state.z)
        warm={'state_binding':sb,'state':jax.device_get(mc.post_warmup_state),'seconds':time.monotonic()-start,
              'leapfrog_steps':int(np.asarray(mc.get_extra_fields()['num_steps']).sum())}
        save_pickle(wf,warm);warm=restore(wf)
    state=warm['state'];parts=[];extras=[];seconds=warm['seconds'];collectors={}
    fields=('potential_energy','energy','accept_prob','num_steps','adapt_state.step_size')+(('flip_attempted','flip_accepted') if use_flip else ())
    for first in range(0,rc['samples'],rc['chunk']):
        n=min(rc['chunk'],rc['samples']-first);file=cd/f'draws_{first:06d}.pkl'
        if file.exists():part=restore(file)
        else:
            log(f'NUTS chain {index+1}/{rc["chains"]}: draws {first}/{rc["samples"]}')
            if n not in collectors:collectors[n]=MCMC(kernel,num_warmup=rc['warmup'],num_samples=n,progress_bar=False)
            mc=collectors[n];mc.post_warmup_state=state;start=time.monotonic()
            mc.run(state.rng_key,init_params=state.z,extra_fields=fields);jax.block_until_ready(mc.last_state.z)
            part={'state_binding':sb,'state':jax.device_get(mc.last_state),'samples':np.asarray(mc.get_samples()),
                  'extras':{k:np.asarray(v) for k,v in mc.get_extra_fields().items()},'first':first,'seconds':time.monotonic()-start}
            save_pickle(file,part)
        if part['first']!=first or part['samples'].shape!=(n,target.dim):raise ValueError('Bad NUTS chunk')
        parts.append(part['samples']);extras.append(part['extras']);state=part['state'];seconds+=part['seconds']
    samples=np.asarray(decode(jnp.asarray(np.concatenate(parts))));ex={k:np.concatenate([a[k] for a in extras]) for k in extras[0]}
    save_npz(cd/'samples.npz',samples=samples,**ex)
    write(cd/'complete.json',{'binding':bind,'index':index,'elapsed_seconds':seconds,'warmup_leapfrog_steps':warm['leapfrog_steps'],
           'production_leapfrog_steps':int(ex['num_steps'].sum()),'initial_physical_coefficients':x,'runtime':runtime(),'reference_coordinates':coordinate_info,
           'reference_reflection_moves':use_flip,'reflection_attempts':int(ex['flip_attempted'].sum()) if use_flip else 0,'reflection_acceptances':int(ex['flip_accepted'].sum()) if use_flip else 0})
    return read(cd/'complete.json')

def merge(target,cfg,directory,bind):
    import arviz as az
    rc=cfg['reference'];parts=[];infos=[]
    for c in range(rc['chains']):
        infos.append(verify_file(directory/f'chain{c}/complete.json',bind));parts.append(npz(directory/f'chain{c}/samples.npz'))
    samples=np.stack([p['samples'] for p in parts]);C,N,D=samples.shape
    extras={k:np.stack([p[k] for p in parts]) for k in parts[0] if k!='samples'}
    q=target.qois(samples.reshape(-1,D)).reshape(C,N,-1);events=target.events_from_qois(q.reshape(-1,q.shape[-1])).reshape(C,N,-1)
    cols=[(target.labels[j],samples[...,j]) for j in range(D)]+[(target.qoi_labels[j],q[...,j]) for j in range(q.shape[-1])]
    rows=[]
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        for name,a in cols:
            rows.append({'observable':name,'rank_rhat':float(az.rhat(a,method='rank')),'bulk_ess':float(az.ess(a,method='bulk')),'tail_ess':float(az.ess(a,method='tail'))})
        erows=[]
        for j,name in enumerate(EVENTS):
            a=events[...,j];p=float(a.mean());constant=bool(np.ptp(a)==0)
            se=float(az.mcse(a,method='mean')) if not constant else None
            group=[float(a[:C//2].mean()),float(a[C//2:].mean())]
            erows.append({'event':name,'probability':p,'mcse':se,'group_probabilities':group,'constant_in_reference':constant,
                          'rank_rhat':float(az.rhat(a,method='rank')) if not constant else None,
                          'bulk_ess':float(az.ess(a,method='bulk')) if not constant else None,
                          'caveat':'Constant event is not a rare-region discovery certificate' if constant else ''})
    rhat=max(v['rank_rhat'] for v in rows);bulk=min(v['bulk_ess'] for v in rows);tail=min(v['tail_ess'] for v in rows)
    energy=extras['energy'];bfmi=np.mean(np.diff(energy,axis=1)**2,axis=1)/np.var(energy,axis=1,ddof=1)
    div=int(extras['diverging'].sum());depth=float(np.mean(extras['num_steps']>=2**rc['max_depth']-1))
    coeff_good=np.isfinite([rhat,bulk,tail,*bfmi]).all() and rhat<=rc['max_rhat'] and bulk>=rc['min_bulk_ess'] and tail>=rc['min_tail_ess'] and div==0 and depth<=rc['max_depth_fraction'] and bfmi.min()>=.3
    event_good=all(v['constant_in_reference'] or (v['mcse']<=rc['max_event_mcse'] and v['rank_rhat']<=rc['max_rhat'] and abs(v['group_probabilities'][0]-v['group_probabilities'][1])<=max(.02,4*v['mcse'])) for v in erows)
    quality={'binding':bind,'reference_usable':bool(coeff_good and event_good and not cfg.get('smoke_only',False)),'smoke_only':cfg.get('smoke_only',False),'diagnostics':rows,'events':erows,
             'max_rank_rhat':rhat,'min_bulk_ess':bulk,'min_tail_ess':tail,'divergences':div,'depth_saturation_fraction':depth,
             'ebfmi_by_chain':bfmi,'mean_acceptance':extras['accept_prob'].mean(),'mean_leapfrog_steps':extras['num_steps'].mean(),
             'chain_records':infos,'thresholds':rc,'initialization':'Two truth-blind MAP candidates and two proper-prior draws, encoded in independently verified exact reference coordinates',
             'reference_kernel':'NUTS plus exact lazy native baseline-reflection MH moves' if 'flip_attempted' in extras else 'NUTS',
             'reflection_attempts':int(extras['flip_attempted'].sum()) if 'flip_attempted' in extras else 0,
             'reflection_acceptances':int(extras['flip_accepted'].sum()) if 'flip_accepted' in extras else 0,
             'caveat':'Diagnostics do not prove global family coverage. No 2D quadrature certificate is inherited. Native affine coordinates and full-target MH reflection; comparators do not use reflection.'}
    save_npz(directory/'samples.npz',samples=samples.reshape(-1,D),samples_by_chain=samples,**extras)
    save_npz(directory/'scientific.npz',qois_by_chain=q,events_by_chain=events)
    write(directory/'quality.json',quality);return read(directory/'quality.json')
