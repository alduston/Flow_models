#!/usr/bin/env bash
set -euo pipefail
module load "${GAD4_PYTHON_MODULE:-python3/3.11.8}"
GAD4_NEW_ENV="${GAD4_VENV_DIR:-${SCRATCH:?Set SCRATCH}/venvs/gad_trajectory4}"
python3 -m venv "$GAD4_NEW_ENV"
source "$GAD4_NEW_ENV/bin/activate"
python -m pip install --upgrade pip
python -m pip install -r "$(dirname "$0")/requirements-cuda12.txt"
echo "Use: export GAD4_VENV_DIR=$GAD4_NEW_ENV before submission."
