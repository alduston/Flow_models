"""Reference-only geometry and curvature audits; never supplied to a sampler."""
import numpy as np
import pandas as pd
import arviz as az
from common import npz,write

def mean_mcse(a):
    a=np.asarray(a)
    return 0. if np.ptp(a)==0 else float(az.mcse(a,method='mean'))

def reference_audit(target,out,quality):
    x=npz(out/'reference/samples.npz')['samples'];ix=np.linspace(0,len(x)-1,min(128,len(x))).astype(int);z=x[ix]
    J=np.asarray([target.jacobian(v) for v in z]);centerJ=J[:,:,[0,2]]/1.5;width=1/np.sqrt(np.linalg.eigvalsh(np.einsum('nmi,nmj->nij',centerJ,centerJ))[:,-1])
    GN=target.gn(z);exact=np.asarray([target.hessian(v) for v in z]);error=np.linalg.norm(exact-GN,axis=(1,2))/np.maximum(np.linalg.norm(exact,axis=(1,2)),1e-12)
    value={'reference_usable':quality['reference_usable'],'median_center_normal_likelihood_width_m':np.median(width),'width_q10_q90_m':np.quantile(width,[.1,.9]),
        'width_definition':'Inverse largest singular value of whitened physical-center Jacobian, with velocity fixed. Local likelihood width, not a marginal interval.',
        'GN_relative_Frobenius_error_q10_median_q90':np.quantile(error,[.1,.5,.9]),'fraction_reference_points_with_indefinite_exact_Hessian':np.mean(np.linalg.eigvalsh(exact).min(1)<0),
        'audit_points':len(z),'native_reference_mean':x.mean(0),'native_reference_sd':x.std(0,ddof=1),'native_correlation':np.corrcoef(x.T),
        'role':'Offline diagnostics only; target calls here are evaluation work, not preprocessing used by either algorithm. GN discrepancy is descriptive, not a safety certificate.'}
    write(out/'reference/geometry_audit.json',value)
    pd.DataFrame({'coordinate':target.labels,'posterior_mean':x.mean(0),'posterior_sd':x.std(0,ddof=1),'prior_sd':1.}).to_csv(out/'reference/native_information.csv',index=False)
    return value
