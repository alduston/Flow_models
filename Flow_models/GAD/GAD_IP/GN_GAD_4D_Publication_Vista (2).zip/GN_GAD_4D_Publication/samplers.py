"""Dimension-general transport and exact MH samplers with charged warmup."""
import time
import pickle
from functools import partial
import numpy as np
import jax
import jax.numpy as jnp
from common import Ledger, log, npz, read, write, save_npz, save_pickle, signature, runtime, verify_file, check_cloud
from initialization import draws
from vendor.lfgi import make_integrator, combine_stats

def gad(target,cfg,setup,info,directory,bind,seed,law,stop_after_chunks=None):
    directory.mkdir(parents=True,exist_ok=True);gc=dict(cfg['gad']);gc['steps']=int(setup['steps']);n=gc['particles'];d=target.dim
    ledger=Ledger(info['oracle_counts']);elapsed=info['elapsed_seconds'];previous=None;records=[];chunks=0
    rtbind=signature({'binding':bind,'runtime':runtime()});grid=np.geomspace(gc['t_max'],float(setup['t_min']),gc['steps']+1)
    for r in range(1,gc['rounds']+1):
        rd=directory/f'round{r}';rd.mkdir(exist_ok=True)
        if (rd/'sampling.json').exists():
            rec=verify_file(rd/'sampling.json',bind);previous=check_cloud(npz(rd/'samples.npz')['samples'],d)
            ledger=Ledger(rec['oracle_counts']);elapsed=rec['elapsed_seconds'];records.append(rec);continue
        if (rd/'bank.npz').exists():
            bank=npz(rd/'bank.npz')
            if str(bank['binding'])!=bind:raise ValueError('Bank identity mismatch')
            ledger=Ledger(dict(zip(['energy','gradient','hessian'],map(int,bank['counts']))));bank_seconds=float(bank['seconds'])
        else:
            started=time.monotonic();x=draws(target,setup,cfg,n,seed+701,law) if r==1 else previous.copy()
            lp,s=target.joint(x);H=target.gn(x);ledger.add(energy=n,gradient=n,hessian=n)
            if not all(np.isfinite(a).all() for a in (lp,s,H)):raise FloatingPointError('Nonfinite target bank')
            bank_seconds=time.monotonic()-started;bank={'x':x,'s':s,'H':H,'binding':np.array(bind),'counts':np.array(list(ledger.counts.values())),'seconds':np.array(bank_seconds)}
            save_npz(rd/'bank.npz',**bank)
        integrate=make_integrator(bank['x'],bank['s'],bank['H'],gc);statefile=rd/'transport.npz'
        if statefile.exists():
            st=npz(statefile)
            if str(st['runtime_binding'])!=rtbind:raise ValueError('GAD runtime/source checkpoint mismatch')
            y,key,done,stats,seconds=jnp.asarray(st['y']),jnp.asarray(st['key']),int(st['done']),st['stats'],float(st['seconds'])
        else:
            key,base=jax.random.split(jax.random.PRNGKey(seed+1009*r));y=jax.random.normal(base,(n,d),dtype=jnp.float64);done=0
            stats=np.array([0.,0.,np.inf,0.,0.,np.inf,0.]);seconds=bank_seconds
        while done<gc['steps']:
            end=min(done+gc['checkpoint_steps'],gc['steps']);started=time.monotonic()
            y,key,ss=integrate(y,key,jnp.asarray(np.stack([grid[done:end],grid[done+1:end+1]],axis=1)))
            yy=check_cloud(np.asarray(y),d);stats=np.asarray(combine_stats(jnp.asarray(np.stack([stats,np.asarray(ss)]))))
            seconds+=time.monotonic()-started;done=end
            save_npz(statefile,y=yy,key=np.asarray(key),done=np.array(done),stats=stats,seconds=np.array(seconds),runtime_binding=np.array(rtbind))
            log(f'{target.case} seed {seed} {law}: GAD round {r}/{gc["rounds"]}, integration {done}/{gc["steps"]}')
            chunks+=1
            if stop_after_chunks is not None and chunks>=stop_after_chunks:return None
        previous=check_cloud(np.asarray(y),d);elapsed+=seconds;save_npz(rd/'samples.npz',samples=previous)
        rec={'binding':bind,'round':r,**ledger.record(),'elapsed_seconds':elapsed,'round_seconds':seconds,
             'guard_fraction':float(stats[0]/max(1,stats[1])),'mean_conditional_ess':float(stats[4]/max(1,stats[6])),
             'min_conditional_ess':float(stats[5]),'t_min':float(setup['t_min']),'steps':gc['steps'],'initial_law':law,
             'note':'Original metric cloud; no terminal projection, importance weights or extra target update.'}
        write(rd/'sampling.json',rec);records.append(rec)
    return records

def make_pmala_kernels(target,center,factor):
    center,factor=jnp.asarray(center),jnp.asarray(factor)
    def loggrad(z):
        e,g=jax.vmap(jax.value_and_grad(target.energy))(center+z@factor.T);return -e,-g@factor
    def step(carry,_):
        z,lp,s,key,h=carry;key,nk,uk=jax.random.split(key,3)
        p=z+h[:,None]*s+jnp.sqrt(2*h[:,None])*jax.random.normal(nk,z.shape,dtype=jnp.float64)
        lq,sq=loggrad(p);f=p-z-h[:,None]*s;rev=z-p-h[:,None]*sq
        raw=lq-lp+(jnp.sum(f*f,1)-jnp.sum(rev*rev,1))/(4*h)
        good=jnp.isfinite(lq)&jnp.all(jnp.isfinite(sq),axis=1)&jnp.isfinite(raw);logr=jnp.where(good,jnp.minimum(0.,raw),-jnp.inf)
        acc=jnp.log(jax.random.uniform(uk,(len(z),),dtype=jnp.float64))<logr
        z=jnp.where(acc[:,None],p,z);lp=jnp.where(acc,lq,lp);s=jnp.where(acc[:,None],sq,s)
        return (z,lp,s,key,h),(center+z@factor.T,jnp.exp(logr),acc)
    @jax.jit
    def initial(z):return loggrad(z)
    @jax.jit
    def warm(carry,i,target_accept):
        state,out=step(carry,None);h=jnp.clip(state[-1]*jnp.exp(.6/(i+1.)**.6*(out[1]-target_accept)),1e-10,1.)
        return (*state[:-1],h),out
    @partial(jax.jit,static_argnums=(1,))
    def production(carry,count):return jax.lax.scan(step,carry,None,length=count)
    return initial,warm,production

def make_gnmala_kernels(target):
    """Simplified manifold MALA. MH includes both state-dependent Gaussian densities."""
    def initial(x):
        e,g=jax.vmap(jax.value_and_grad(target.energy))(x);H=jax.vmap(target.gn_one)(x)
        return -e,-g,H
    def logq(to,fr,score,H,h):
        drift=jnp.linalg.solve(H,score[...,None])[...,0];delta=to-fr-h[:,None]*drift
        return .5*jnp.linalg.slogdet(H)[1]-.5*fr.shape[1]*jnp.log(4*jnp.pi*h)-jnp.einsum('bi,bij,bj->b',delta,H,delta)/(4*h)
    def step(carry,_):
        x,lp,s,H,key,h=carry;key,nk,uk=jax.random.split(key,3)
        L=jnp.linalg.cholesky(H);noise=jax.random.normal(nk,x.shape,dtype=jnp.float64)
        direction=jnp.linalg.solve(jnp.swapaxes(L,-1,-2),noise[...,None])[...,0]
        drift=jnp.linalg.solve(H,s[...,None])[...,0];p=x+h[:,None]*drift+jnp.sqrt(2*h[:,None])*direction
        lq,sq,Hq=initial(p);raw=lq-lp+logq(x,p,sq,Hq,h)-logq(p,x,s,H,h)
        good=jnp.isfinite(lq)&jnp.all(jnp.isfinite(sq),1)&jnp.all(jnp.isfinite(Hq),axis=(1,2))&jnp.isfinite(raw)
        logr=jnp.where(good,jnp.minimum(0.,raw),-jnp.inf);acc=jnp.log(jax.random.uniform(uk,(len(x),),dtype=jnp.float64))<logr
        xx=jnp.where(acc[:,None],p,x);ll=jnp.where(acc,lq,lp);ss=jnp.where(acc[:,None],sq,s);HH=jnp.where(acc[:,None,None],Hq,H)
        return (xx,ll,ss,HH,key,h),(xx,jnp.exp(logr),acc)
    @jax.jit
    def warm(carry,i,target_accept):
        state,out=step(carry,None);h=jnp.clip(state[-1]*jnp.exp(.6/(i+1.)**.6*(out[1]-target_accept)),1e-10,1.)
        return (*state[:-1],h),out
    @partial(jax.jit,static_argnums=(1,))
    def production(carry,count):return jax.lax.scan(step,carry,None,length=count)
    return jax.jit(initial),warm,production

def mala(target,cfg,setup,info,records,directory,bind,seed,law,kind='pmala',stop_after_blocks=None):
    directory.mkdir(parents=True,exist_ok=True);pc=cfg['pmala'];C=pc['chains'];d=target.dim;cost=3 if kind=='gnmala' else 2
    if (directory/'complete.json').exists():return verify_file(directory/'complete.json',bind)
    warmup=pc.get('gn_warmup',pc['warmup']) if kind=='gnmala' else pc['warmup']
    initial,warm,production=make_gnmala_kernels(target) if kind=='gnmala' else make_pmala_kernels(target,setup['center'],setup['factor'])
    rtbind=signature({'binding':bind,'runtime':runtime()});statefile=directory/'state.pkl';blocks=0
    if statefile.exists():
        with statefile.open('rb') as f:st=pickle.load(f)
        if st['runtime_binding']!=rtbind:raise ValueError('MALA runtime/source checkpoint mismatch')
        carry=jax.tree_util.tree_map(jnp.asarray,st['carry']);history=list(st['history']);accepted=st['accepted'];elapsed=st['elapsed'];ledger=Ledger(st['counts']);warm_probs=st['warm_probs']
    else:
        started=time.monotonic();x=draws(target,setup,cfg,C,seed+(50000 if kind=='gnmala' else 40000),law)
        z=x if kind=='gnmala' else np.linalg.solve(setup['factor'],(x-setup['center']).T).T
        vals=initial(jnp.asarray(z));jax.block_until_ready(vals[0])
        h=np.minimum(pc['initial_step'],.25*np.sqrt(2)/np.maximum(np.linalg.norm(np.asarray(vals[1]),axis=1),1e-300))
        carry=(jnp.asarray(z),*vals,jax.random.PRNGKey(seed+(50001 if kind=='gnmala' else 40001)),jnp.asarray(h))
        probs=[]
        for i in range(warmup):carry,out=warm(carry,jnp.asarray(float(i)),jnp.asarray(pc['target_accept']));probs.append(np.asarray(out[1]))
        warm_probs=np.asarray(probs);elapsed=info['elapsed_seconds']+time.monotonic()-started;ledger=Ledger(info['oracle_counts'])
        ledger.add(energy=C*(warmup+1),gradient=C*(warmup+1),hessian=C*(warmup+1) if kind=='gnmala' else 0)
        history=[];accepted=0
    def checkpoint():
        save_pickle(statefile,{'runtime_binding':rtbind,'carry':jax.device_get(carry),'history':np.asarray(history).reshape(-1,C,d),
                    'accepted':accepted,'elapsed':elapsed,'counts':ledger.counts,'warm_probs':warm_probs})
    for rec in records:
        r=rec['round'];cap=rec['work'];out=directory/f'work{r}.json'
        if out.exists():verify_file(out,bind);continue
        if ledger.work>cap:raise ValueError(f'{kind} warmup consumes checkpoint {r} cap; increase particles or reduce charged warmup.')
        while ledger.work+cost*C<=cap:
            n=min(pc['production_block'],(cap-ledger.work)//(cost*C));started=time.monotonic()
            carry,results=production(carry,int(n));states,prob,acc=map(np.asarray,results);check_cloud(states.reshape(-1,d),d)
            history.extend(states);accepted+=int(acc.sum());elapsed+=time.monotonic()-started
            ledger.add(energy=n*C,gradient=n*C,hessian=n*C if kind=='gnmala' else 0);checkpoint();blocks+=1
            if stop_after_blocks is not None and blocks>=stop_after_blocks:return None
        a=np.asarray(history).reshape(-1,C,d)
        save_npz(directory/f'work{r}.npz',samples=a.reshape(-1,d),samples_by_chain=a.transpose(1,0,2))
        write(out,{'binding':bind,'round':r,**ledger.record(),'matched_work_cap':cap,'unused_requests':cap-ledger.work,
              'elapsed_seconds':elapsed,'retained_states':a.shape[0]*C,'acceptance_rate':accepted/max(1,a.shape[0]*C),
              'step_by_chain':np.asarray(carry[-1]),'warmup_transitions_per_chain':warmup,
              'metric':'position-dependent physical GN, MH-corrected' if kind=='gnmala' else 'fixed exact MAP Hessian',
              'output':'ALL production history, including MH rejection repeats; no tail-only window or deduplication'})
        checkpoint();log(f'{target.case} seed {seed} {law}: {kind} checkpoint {r}, work {ledger.work}/{cap}, retained {len(history)*C}')
    write(directory/'complete.json',{'binding':bind,**ledger.record(),'elapsed_seconds':elapsed,'kind':kind})
    return read(directory/'complete.json')
