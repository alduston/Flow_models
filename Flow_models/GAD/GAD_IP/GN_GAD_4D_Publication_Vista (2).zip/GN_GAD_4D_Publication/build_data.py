"""Reproduce the frozen, exactly represented constant-velocity physical data."""
import numpy as np
from common import ROOT, write, save_npz, sha

def truth(t):
    u=(np.asarray(t)-5)/5
    return np.array([.65,1.30])+u[...,None]*np.array([.20,-.125])

def basis(t):
    return np.column_stack([np.full(len(t),1.5),.5*(np.asarray(t)-5)/5])

def build():
    obs=np.linspace(0,10,4);ev=np.linspace(0,10,401);fine=np.linspace(0,10,1601)
    save_npz(ROOT/'data/basis.npz',obs_times=obs,eval_times=ev,fine_times=fine,
             Bobs=basis(obs),Beval=basis(ev),Bfine=basis(fine),Bmid=basis(np.array([5.])),eigenvalues=np.array([22.5,2.5/3]))
    angles=np.deg2rad([200.,10.,100.,290.]);rec=1.2*np.column_stack([np.cos(angles),np.sin(angles)])
    rng=np.random.default_rng(42);errors=np.column_stack([rng.normal(size=(4,2)),rng.normal(size=(4,2))]);pos=truth(obs)
    dist=np.sqrt(np.sum((pos[:,None,:]-rec[None,:,:])**2,axis=-1)+1e-18);clean=(dist[:,1:]-dist[:,:1])*1e6/343
    for case,sd,nrec in [('primary',480.,2),('narrow',240.,2),('wide',720.,2),('informative',480.,4)]:
        y=clean[:,:nrec-1]+sd*(errors[:,1:nrec]-errors[:,:1])
        write(ROOT/f'data/{case}.json',dict(case=case,dim=4,K=2,prior='Independent Gaussian center and half-displacement in each Cartesian axis',
            prior_mean_m=[0.,0.],center_sd_m=1.5,half_displacement_sd_m=.5,velocity_sd_m_s=.1,duration_s=10.,
            receiver_positions_m=rec[:nrec],arrival_sd_us=sd,noise_covariance_us2=sd**2*(np.eye(nrec-1)+np.ones((nrec-1,nrec-1))),
            sound_speed_m_s=343.,range_regularization_m=1e-9,y=y,y_clean=clean[:,:nrec-1],data_seed=42,pulse_times_s=obs,
            truth_definition='s(t) = (0.65,1.30) + ((t-5)/5)*(0.20,-0.125), exactly in inference family',
            basis_sha256=sha(ROOT/'data/basis.npz'),
            width_design='Primary 4-pulse arrival SD480us: pooled constant-position TDOA SD sqrt(2)*480/sqrt(4)=339.411us, matching old single-pulse 2D arrival SD240us; posterior geometry still audited empirically.',
            assumptions=['known pulse association and schedule','independent timestamp noise across pulses','known receiver positions and speed','constant velocity over 10s','synthetic extracted arrival times; no reverberation model']))
    write(ROOT/'data/basis_validation.json',dict(analytic_basis=True,no_discretization_error=True,dimension=4,
        coordinate_order=['center_x/1.5','half_displacement_x/0.5','center_y/1.5','half_displacement_y/0.5'],
        note='Four whitened standard-normal coefficients. Static 2D physical forward map is nested at zero half-displacement.'))
    print('Frozen 4D targets generated.')

if __name__=='__main__':build()
