# Publication run scope

The physical model, observed data, prior, exact score, GN curvature, q-LFGI transport, stochastic Heun integrator and MH kernels are inherited from the user's original 4D audit. The changes are campaign size (five seeds, N=2,000, R=4), restartable zero-target fresh field outputs, fair cloud-count matching and publication reporting. There is no new theory, model selection, noise adjustment or higher-dimensional experiment.

The only new computations are comparison/reporting safeguards and offline diagnostics: fixed-seed multistart MAP preprocessing was already present; one independent shared native-target NUTS reference remains; pMALA stays charged and retains rejection repeats; Gaussian baselines, scientific QoIs, held-out predictions and GN fidelity/support audits are explicitly labeled. Fresh round-four output is generated from the round-four bank (the actual round-three endpoint and its saved target scores/GN matrices), so it is not a fifth transport update.

The 2,000-particle round-one cap cannot support 2,000 retained pMALA states after charging 8×256 warmup transitions. Cloud metrics therefore match 944 states at round one and 2,000 thereafter. At the final cap, each pMALA start has 9,944 retained production states, permitting the declared 8,192-state display cap without oversampling or deduplicating MCMC histories. Sample means and event frequencies use all states; within-run MCSE and between-seed SD remain separate quantities.

The headline metric convention is sqrt(d × mean directional W2² / reference covariance trace). The full four-dimensional metric is accompanied by scientific QoIs and likelihood fit to avoid treating a moment-matched Gaussian as an adequate posterior solely because its projected transport distance is small. One fixed truth/data record supports repeatability over sampler randomness, not robustness over datasets.

Main-figure candidates, individual panels, captions and tables are exported separately. The fixed display seed is 42. All other seed histograms are supplied for inspection. No best-seed display is chosen after ranking the methods.
