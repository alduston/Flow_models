"""Truth-blind MAP preparation and dimension-general numerical endpoint control."""
import time
import numpy as np
import jax.numpy as jnp
from scipy.optimize import minimize
from common import Ledger, check_cloud, log, npz, read, save_npz, verify_file, write

def derivative_check(target, points):
    records = []
    for x in np.asarray(points):
        _, score = target.joint(x[None]); H = np.asarray(target.hessian(jnp.asarray(x)))
        step = 1e-5; fd_g = []; fd_h = []
        for v in np.eye(target.dim):
            ep, sp = target.joint((x+step*v)[None]); em, sm = target.joint((x-step*v)[None])
            fd_g.append(-(ep[0]-em[0])/(2*step)); fd_h.append(-(sp[0]-sm[0])/(2*step))
        ge = np.linalg.norm(-score[0]-fd_g)/max(1., np.linalg.norm(score))
        he = np.linalg.norm(H-np.array(fd_h).T)/max(1., np.linalg.norm(H))
        records.append({'x': x, 'relative_gradient_error': ge, 'relative_hessian_error': he})
    if max(r['relative_gradient_error'] for r in records)>2e-5 or max(r['relative_hessian_error'] for r in records)>1e-4:
        raise AssertionError('Finite-difference derivative validation failed')
    return records

def gaussian_control(center, C, t_max, t_min, steps):
    """Exact mean/covariance recursion of the actual stochastic Heun discretization.

    Includes the correlated predictor/corrector noise and N(0,I) terminal start.
    This is a deterministic integrator check, with no Monte Carlo tolerance.
    """
    ev, V = np.linalg.eigh(C); m = V.T@center
    mean = np.zeros(len(center)); variance = np.ones(len(center))
    grid = np.geomspace(t_max, t_min, steps+1)
    for t, tn in zip(grid[:-1], grid[1:]):
        h = t-tn
        ct = np.exp(-2*t)*ev-np.expm1(-2*t)
        cn = np.exp(-2*tn)*ev-np.expm1(-2*tn)
        b = 1-2/ct; bn = 1-2/cn
        c = 2*np.exp(-t)*m/ct; cn_m = 2*np.exp(-tn)*m/cn
        A = 1+.5*h*(b+bn*(1+h*b)); noise = np.sqrt(2*h)*(1+.5*h*bn)
        offset = .5*h*(c+bn*h*c+cn_m)
        mean = A*mean+offset; variance = A*A*variance+noise*noise
    exact_var = np.exp(-2*t_min)*ev-np.expm1(-2*t_min)
    exact_mean = np.exp(-t_min)*m
    return {'steps': steps, 'max_relative_variance_error': float(np.max(np.abs(variance/exact_var-1))),
            'mean_error_in_posterior_sd': float(np.linalg.norm((mean-exact_mean)/np.sqrt(exact_var))),
            'predicted_variance': variance, 'exact_noisy_variance': exact_var,
            'endpoint_inflation_ratio_map': float(-np.expm1(-2*t_min)/(np.exp(-2*t_min)*ev.min()))}

def setup(target, cfg, directory, bind):
    directory.mkdir(parents=True, exist_ok=True)
    if (directory/'setup.json').exists():
        verify_file(directory/'setup.json', bind)
        return npz(directory/'setup.npz'), read(directory/'setup.json')
    started = time.monotonic(); ledger = Ledger(); rng = np.random.default_rng(cfg['sampler_seed']+700)
    starts = np.vstack([np.zeros((1, target.dim)), rng.normal(0, .7, (cfg['map']['starts']-1, target.dim))])
    candidates = []; records = []
    for i, start in enumerate(starts):
        calls = 0; best = None
        class CallLimit(Exception): pass
        def objective(x):
            nonlocal calls, best
            if calls >= cfg['map']['max_calls']: raise CallLimit()
            calls += 1; ledger.add(energy=1, gradient=1)
            lp, s = target.joint(x[None]); e, g = -float(lp[0]), -s[0]
            if not np.isfinite(e) or not np.isfinite(g).all(): return 1e100, np.zeros(target.dim)
            if best is None or e < best[0]: best = (e, x.copy(), g.copy())
            return e, g
        result = None
        try:
            result = minimize(objective, start, jac=True, method='BFGS', options={'maxiter': cfg['map']['max_calls'], 'gtol': 1e-7})
        except CallLimit: pass
        if best is None: raise FloatingPointError('MAP start yielded no finite point')
        candidates.append(best)
        records.append({'start': i, 'objective_calls': calls, 'energy': best[0], 'center': best[1],
                        'gradient_norm': np.linalg.norm(best[2]), 'optimizer_success': bool(result is not None and result.success)})
    candidates.sort(key=lambda z:z[0]); center = candidates[0][1]
    H = np.asarray(target.hessian(jnp.asarray(center))); ledger.add(hessian=1)
    e, V = np.linalg.eigh(H)
    floor = max(cfg['map']['hessian_floor'], np.max(np.abs(e))/cfg['map']['max_condition'])
    factor = V/np.sqrt(np.maximum(e, floor)); C = factor@factor.T
    # Do not silently use a single basin if a meaningful competing basin is found.
    basins = []; profile_records = []
    for energy, x, grad in candidates[1:]:
        if energy-candidates[0][0] < 10 and np.linalg.norm(np.linalg.solve(factor, x-center)) > 2:
            line = center+(x-center)*np.linspace(0, 1, 25)[:, None]
            lp, _ = target.joint(line); ledger.add(energy=len(line), gradient=len(line))
            barrier = float((-lp).max()-max(energy, candidates[0][0]))
            profile_records.append({'candidate': x, 'barrier_above_endpoints': barrier})
            if barrier>3: basins.append(x)
    t_min = min(cfg['gad']['t_min_cap'], .5*np.log1p(cfg['gad']['endpoint_variance_tolerance']*np.linalg.eigvalsh(C).min()))
    steps = cfg['gad']['steps']; controls = []
    while True:
        ctl = gaussian_control(center, C, cfg['gad']['t_max'], t_min, steps); controls.append(ctl)
        if ctl['max_relative_variance_error'] <= cfg['gad']['integrator_variance_tolerance'] and ctl['mean_error_in_posterior_sd']<.01: break
        steps *= 2
        if steps > cfg['gad']['max_steps']: raise RuntimeError('Gaussian Heun control failed; review endpoint/grid before sampling')
    elapsed = time.monotonic()-started
    data = {'center': center, 'factor': factor, 'covariance': C, 'hessian': H, 't_min': np.array(t_min), 'steps': np.array(steps),
            'candidates': np.stack([v[1] for v in candidates])}
    info = {'binding': bind, **ledger.record(), 'elapsed_seconds': elapsed, 'map_records': records,
            'hessian_eigenvalues_raw': e, 'regularization_floor': floor, 'clipped_eigenvalues': int((e<floor).sum()),
            'gradient_norm': np.linalg.norm(candidates[0][2]), 'distinct_relevant_basins': basins,
            'candidate_profiles': profile_records, 'gaussian_endpoint_controls': controls,
            'numerical_setup_shared': True, 'full_setup_cost_charged_to_each_method': True}
    save_npz(directory/'setup.npz', **data); write(directory/'setup.json', info)
    return data, read(directory/'setup.json')

def production_endpoint(setup,cfg,reference,directory,bind):
    """Tighten a failed endpoint check; reference changes no initialization/metric.

    The MAP-based choice is always tried first. An independent reference may
    request a smaller numerical endpoint, with a factor-two safety margin.
    """
    out=dict(setup);old=float(out['t_min']);lam=float(np.linalg.eigvalsh(np.cov(reference.T)).min())
    tolerance=cfg['gad']['endpoint_variance_tolerance']
    ratio=-np.expm1(-2*old)/(np.exp(-2*old)*lam)
    refined=ratio>tolerance
    if refined:out['t_min']=np.array(min(old,.5*np.log1p(.5*tolerance*lam)))
    steps=int(out['steps']);controls=[]
    while True:
        control=gaussian_control(out['center'],out['covariance'],cfg['gad']['t_max'],float(out['t_min']),steps);controls.append(control)
        if control['max_relative_variance_error']<=cfg['gad']['integrator_variance_tolerance'] and control['mean_error_in_posterior_sd']<.01:break
        steps*=2
        if steps>cfg['gad']['max_steps']:raise RuntimeError('Refined endpoint fails the Gaussian integrator control')
    out['steps']=np.array(steps)
    write(directory/'production_endpoint.json',{'binding':bind,'refined_after_independent_reference_check':refined,
          'MAP_selected_t_min':old,'reference_min_covariance_eigenvalue':lam,'original_reference_inflation_ratio':ratio,
          'production_t_min':float(out['t_min']),'production_steps':steps,'gaussian_controls':controls,
          'role':'numerical accuracy only; reference covariance never initializes or preconditions either competing sampler'})
    save_npz(directory/'production_setup.npz',**out)
    return out
