#!/usr/bin/env python3
"""Read batch state without JAX, NumPy, CUDA, or the dedicated venv."""
import argparse,json,subprocess
from pathlib import Path

def read(path):return json.loads(path.read_text())
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--batch',required=True,type=Path);a=ap.parse_args();batch=a.batch.resolve();out=batch/'results'
    record=batch/'submission.json';jobs=read(record).get('jobs',{}) if record.exists() else {}
    print('Batch:',batch);print('Recorded jobs:',jobs if jobs else 'none')
    if jobs:
        try:
            q=subprocess.run(['sacct','-X','-j',','.join(str(v) for v in jobs.values()),'--format=JobID,JobName%25,State,ExitCode,Elapsed'],text=True,capture_output=True)
            print(q.stdout.strip() or q.stderr.strip())
        except FileNotFoundError:pass
    if not (out/'campaign.json').exists():
        print('Preparation has not initialized campaign.json. Check the prepare log or pending job.')
        for p in sorted(batch.glob('prepare-*.log')):
            print('\n'+str(p));print('\n'.join(p.read_text(errors='replace').splitlines()[-30:]))
        return
    cfg=read(out/'campaign.json')['config'];q=out/'reference/quality.json'
    print('Reference usable:',read(q)['reference_usable'] if q.exists() else 'pending')
    for seed in cfg['seeds']:
        sd=out/f'seed{seed}';counts=sum((sd/f'gad_mixed/round{r}/sampling.json').exists() for r in range(1,cfg['gad']['rounds']+1))
        controls={law:(sd/f'pmala_{law}/complete.json').exists() for law in cfg['pmala_initializations']}
        print('Seed',seed,'GAD rounds',counts,'/',cfg['gad']['rounds'],'pMALA',controls,'evaluation',(sd/'complete.json').exists())
    for p in [out/'GN_GAD_4D_PAPER_RESULTS.zip',out/'report/GN_GAD_4D_DASHBOARD.pdf']:print(p,':',str(p.stat().st_size)+' bytes' if p.exists() else 'pending')
if __name__=='__main__':main()
