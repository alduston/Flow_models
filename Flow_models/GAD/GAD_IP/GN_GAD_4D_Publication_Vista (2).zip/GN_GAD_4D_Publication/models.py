"""Physical TDOA of a temporally coupled path in native KL coordinates."""
import numpy as np
import jax
import jax.numpy as jnp
from common import ROOT, read, npz, sha
jax.config.update('jax_enable_x64',True)

class Target:
    def __init__(self,case='primary',dim=4):
        if case not in ('primary','narrow','wide','informative'):raise ValueError(case)
        if dim!=4:raise ValueError('Pilot is fixed at four unknowns; dimension promotion requires separate review.')
        self.case=case;self.dim=dim;self.K=dim//2;self.data=read(ROOT/f'data/{case}.json')
        if sha(ROOT/'data/basis.npz')!=self.data['basis_sha256']:raise ValueError('Changed basis file')
        self.data={**self.data,'dim':dim,'K':self.K};self.basis=npz(ROOT/'data/basis.npz')
        self.times=self.basis['eval_times'];self.Beval=self.basis['Beval'][:,:self.K]
        self.Bfine=self.basis['Bfine'][:,:self.K];self.Bmid=self.basis['Bmid'][:,:self.K]
        B=jnp.asarray(self.basis['Bobs'][:,:self.K]);r=jnp.asarray(self.data['receiver_positions_m'])
        y=jnp.asarray(self.data['y']);W=jnp.asarray(np.linalg.inv(np.linalg.cholesky(self.data['noise_covariance_us2'])))
        c=1e6/self.data['sound_speed_m_s'];eps=self.data['range_regularization_m']**2;K=self.K
        def position(x):return jnp.stack([B@x[:K],B@x[K:]],axis=-1)
        def forward(x):
            s=position(x);d=jnp.sqrt(jnp.sum((s[:,None,:]-r[None,:,:])**2,axis=-1)+eps)
            return c*(d[:,1:]-d[:,:1])
        def residual(x):return ((forward(x)-y)@W.T).reshape(-1)
        def energy(x):
            rr=residual(x);return .5*jnp.vdot(x,x)+.5*jnp.vdot(rr,rr)
        def jacobian(x):
            s=position(x);diff=s[:,None,:]-r[None,:,:];dist=jnp.sqrt(jnp.sum(diff**2,axis=-1)+eps)
            unit=diff/dist[:,:,None];dp=c*(unit[:,1:,:]-unit[:,:1,:])
            J=jnp.concatenate([dp[:,:,0,None]*B[:,None,:],dp[:,:,1,None]*B[:,None,:]],axis=-1)
            return jnp.einsum('ab,tbd->tad',W,J).reshape(-1,dim)
        def gn(x):
            J=jacobian(x);return jnp.eye(dim,dtype=jnp.float64)+J.T@J
        self.energy=energy;self.forward=jax.jit(forward);self.residual=jax.jit(residual)
        self.jacobian=jax.jit(jacobian);self.gn_one=jax.jit(gn);self.hessian=jax.jit(jax.hessian(energy))
        self._joint=jax.jit(jax.vmap(jax.value_and_grad(energy)));self._gn=jax.jit(jax.vmap(gn))
        self.labels=['center_x_over_1.5','half_displacement_x_over_0.5','center_y_over_1.5','half_displacement_y_over_0.5']
        self.qoi_labels=['height_at_5s_m','residence_below_y0_s','closest_approach_to_0_2_m','total_displacement_m']
    def prior_draws(self,rng,count):return rng.normal(size=(count,self.dim))
    def joint(self,x):
        e,g=self._joint(jnp.asarray(x,dtype=jnp.float64));return -np.asarray(e),-np.asarray(g)
    def gn(self,x):return np.asarray(self._gn(jnp.asarray(x,dtype=jnp.float64)))
    def paths(self,x,fine=False):
        x=np.asarray(x);B=self.Bfine if fine else self.Beval
        return np.stack([x[...,:self.K]@B.T,x[...,self.K:]@B.T],axis=-1)
    def qois(self,x):
        x=np.asarray(x);c=1.5*x[:,[0,2]];d=.5*x[:,[1,3]]
        ad=np.abs(d[:,1]);residence=10*np.clip(.5-c[:,1]/(2*np.maximum(ad,1e-300)),0,1)
        residence=np.where(ad==0,10*(c[:,1]<0),residence)
        v=c-np.array([0.,2.]);u=np.clip(-np.sum(v*d,1)/np.maximum(np.sum(d*d,1),1e-300),-1,1)
        closest=np.linalg.norm(v+u[:,None]*d,axis=1)
        return np.column_stack([c[:,1],residence,closest,2*np.linalg.norm(d,axis=1)])
    def events_from_qois(self,q):
        return np.column_stack([q[:,0]<0,q[:,2]<=1.,(q[:,1]>0)&(q[:,1]<10)]).astype(float)
    def events(self,x):
        return self.events_from_qois(self.qois(x))
    def heldout(self,x):
        s=self.paths(x);r0=np.asarray(self.data['receiver_positions_m'][0]);rh=1.2*np.array([0.,1.])
        return (np.sqrt(((s-rh)**2).sum(-1)+1e-18)-np.sqrt(((s-r0)**2).sum(-1)+1e-18))*1e6/343

EVENTS=['P(height_at_5s<0)','P(enter_disk_center_0_2_radius1)','P(cross_y0_during_10s)']
