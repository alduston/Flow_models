#!/usr/bin/env python3
"""Freeze a source snapshot and submit a bounded dependency graph. stdlib only."""
import argparse
import getpass
import hashlib
import json
import os
import re
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');os.replace(tmp,path)
def inputs():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.json','.npz','.sh','.txt','.md'))

def parse_job_id(answer):
    """Accept an exact Slurm response line amid site submit-plugin banners."""
    ids=set()
    for line in answer.splitlines():
        m=re.fullmatch(r'(?:Submitted batch job\s+)?([0-9]+)(?:;[A-Za-z0-9_.-]+)?',line.strip())
        if m:ids.add(m.group(1))
    if len(ids)!=1:
        raise RuntimeError('No unique job ID in sbatch response. Do not resubmit blindly; inspect submission.json and scheduler. Response:\n'+answer)
    return ids.pop()

def stage_graph(cfg,max_inflight,sampler_time='06:00:00',reference_time='06:00:00'):
    return [('prepare',None,None,'00:30:00'),('chains','prepare',f'0-{cfg["reference"]["chains"]-1}%{max_inflight}',reference_time),
            ('reference-merge','chains',None,'00:30:00'),('seeds','reference-merge',f'0-{len(cfg["seeds"])-1}%{max_inflight}',sampler_time),('report','seeds',None,'01:00:00')]

def stage_command(batch,identity,stage,parent,array,wall,jobs):
    cmd=['sbatch','--parsable','--account',identity['account'],'--partition',identity['partition'],'--nodes','1','--ntasks','1','--cpus-per-task','8','--time',wall,
         '--job-name','g4pub_'+stage,'--output',str(batch/(stage+'-%A_%a.log'))]
    if array:cmd+=['--array',array]
    if parent:cmd+=['--dependency','afterok:'+jobs[parent]]
    return cmd+[str(batch/'code/slurm/job.sh'),str(batch),stage,identity['profile'],identity['case'],identity.get('python') or '']

def submit_stage(batch,record,cmd,stage):
    result=subprocess.run(cmd,text=True,capture_output=True)
    # Preserve the scheduler response BEFORE parsing, including on errors.
    record.setdefault('submission_responses',[]).append({'stage':stage,'stdout':result.stdout,'stderr':result.stderr,'returncode':result.returncode})
    write(batch/'submission.json',record)
    if result.returncode:raise RuntimeError('sbatch failed for '+stage+':\n'+result.stdout+result.stderr)
    jid=parse_job_id(result.stdout)
    record['jobs'][stage]=jid;write(batch/'submission.json',record);print(stage,jid,flush=True)

def verify_existing_job(jid,stage):
    """Accept only this user's successful or live job of the expected stage."""
    if not re.fullmatch(r'[0-9]+',str(jid)):raise SystemExit('Invalid job ID: '+str(jid))
    q=subprocess.run(['sacct','-X','-n','-P','-j',str(jid),'--format=JobIDRaw,JobName%100,State,User%100'],text=True,capture_output=True)
    if q.returncode:raise SystemExit('Could not verify existing job: '+q.stderr)
    rows=[x.strip().split('|') for x in q.stdout.splitlines() if x.strip()]
    rows=[x for x in rows if len(x)>=4 and (x[0]==str(jid) or x[0].startswith(str(jid)+'_'))]
    if not rows:raise SystemExit('No accounting record yet for job '+str(jid)+'. Wait for accounting and repeat this continuation command; no jobs submitted.')
    allowed={'PENDING','RUNNING','CONFIGURING','COMPLETING','SUSPENDED','REQUEUED','REQUEUE_FED','REQUEUE_HOLD','RESIZING','COMPLETED'}
    for job,name,state,user,*_ in rows:
        if name.strip()!='g4pub_'+stage or user.strip()!=getpass.getuser():
            raise SystemExit('Job name/owner mismatch for '+str(jid)+'. No jobs submitted.')
        if state.split()[0].rstrip('+') not in allowed:
            raise SystemExit('Existing '+stage+' job '+str(jid)+' is '+state+'. Continuation stopped; inspect its log before restarting.')
    print('Verified',stage,jid,','.join(sorted({r[2] for r in rows})),flush=True)

def continue_batch(batch,adopt_prepare,dry_run):
    path=batch/'submission.json'
    if not path.is_file():raise SystemExit('Continuation needs an existing submission.json.')
    record=json.loads(path.read_text());identity=record['identity'];code=batch/'code'
    for rel,h in identity['input_hashes'].items():
        if not (code/rel).is_file() or digest(code/rel)!=h:raise SystemExit('Frozen snapshot mismatch: '+rel)
    cfg=json.loads((code/f'profiles/{identity["profile"]}.json').read_text())
    if cfg['seeds']!=identity['seeds']:raise SystemExit('Frozen seed identity mismatch.')
    graph=record.get('graph') or stage_graph(cfg,identity['max_inflight'])
    jobs=record.setdefault('jobs',{})
    if adopt_prepare:
        if jobs.get('prepare') not in (None,adopt_prepare):raise SystemExit('A different prepare job is already recorded.')
        jobs['prepare']=adopt_prepare
    stages=[x[0] for x in graph]
    if set(jobs)-set(stages):raise SystemExit('Unknown stage in submission record.')
    seen_missing=False
    for stage in stages:
        if stage not in jobs:seen_missing=True
        elif seen_missing:raise SystemExit('Recorded stages are not a contiguous dependency graph.')
    if not jobs:raise SystemExit('No recorded prepare job. Supply --adopt-prepare with the accepted job ID.')
    # Verify all recorded jobs before writing adoption or submitting anything.
    for stage,jid in jobs.items():verify_existing_job(jid,stage)
    if not dry_run:
        record['graph']=graph;write(path,record)
    for stage,parent,array,wall in graph:
        if stage in jobs:continue
        cmd=stage_command(batch,identity,stage,parent,array,wall,jobs)
        if dry_run:
            print(shlex.join(cmd));jobs[stage]='<'+stage+'_jobid>'
        else:submit_stage(batch,record,cmd,stage)
    print('DRY RUN: no files written and no jobs submitted.' if dry_run else 'Dependency graph complete. Existing stages were preserved.')

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--batch',required=True,type=Path);ap.add_argument('--python',type=Path,help='Absolute Python executable in an existing compatible GPU environment; its base Python module and shared libraries are restored in every job')
    ap.add_argument('--profile',default='vista',choices=['vista','kaggle','confirm','smoke']);ap.add_argument('--case',default='primary',choices=['primary','narrow','wide','informative'])
    ap.add_argument('--account',default='DMS22021');ap.add_argument('--partition',default='gh');ap.add_argument('--max-inflight',type=int,default=2)
    ap.add_argument('--sampler-time',default='06:00:00');ap.add_argument('--reference-time',default='06:00:00');ap.add_argument('--resume',action='store_true');ap.add_argument('--dry-run',action='store_true')
    ap.add_argument('--continue-batch',action='store_true',help='Submit only missing stages using the existing frozen source and submission settings; keep successful/live jobs')
    ap.add_argument('--adopt-prepare',help='With --continue-batch, record a verified prepare job accepted before the old parser failed')
    a=ap.parse_args();batch=a.batch.resolve()
    if a.continue_batch:
        if a.resume:raise SystemExit('--continue-batch and --resume have different purposes; use only one.')
        if any(x.split('=')[0] not in {'--batch','--continue-batch','--adopt-prepare','--dry-run'} for x in sys.argv[1:] if x.startswith('--')):
            raise SystemExit('--continue-batch reuses recorded settings; pass only --batch, --adopt-prepare and optionally --dry-run.')
        continue_batch(batch,a.adopt_prepare,a.dry_run);return
    if a.adopt_prepare:raise SystemExit('--adopt-prepare requires --continue-batch.')
    if a.python is not None:
        a.python=a.python.absolute()
        if not a.python.is_file():raise SystemExit('--python does not identify an executable file')
    if a.max_inflight<1 or a.max_inflight>4:raise SystemExit('--max-inflight must be between 1 and 4')
    cfg=json.loads((ROOT/f'profiles/{a.profile}.json').read_text());hashes={str(p.relative_to(ROOT)):digest(p) for p in inputs()}
    identity={'schema':1,'profile':a.profile,'case':a.case,'seeds':cfg['seeds'],'input_hashes':hashes,'account':a.account,'partition':a.partition,'max_inflight':a.max_inflight,'python':str(a.python) if a.python else None}
    old=None
    if (batch/'submission.json').exists():
        old=json.loads((batch/'submission.json').read_text())
        if not a.resume:raise SystemExit('Batch exists. Use --resume for unchanged inputs, or a NEW batch path.')
        if old['identity']!=identity:raise SystemExit('Changed source/config/scheduling identity. Use a NEW batch path.')
    elif batch.exists() and any(batch.iterdir()):raise SystemExit('Refusing to freeze into a nonempty unbound batch directory.')
    graph=stage_graph(cfg,a.max_inflight,a.sampler_time,a.reference_time)
    if a.dry_run:
        for stage,parent,array,wall in graph:
            cmd=['sbatch','--account',a.account,'--partition',a.partition,'--nodes','1','--ntasks','1','--cpus-per-task','8','--time',wall]
            if array:cmd+=['--array',array]
            if parent:cmd+=['--dependency',f'afterok:<{parent}_jobid>']
            cmd += [str(batch/'code/slurm/job.sh'),str(batch),stage,a.profile,a.case,str(a.python) if a.python else '']
            print(shlex.join(cmd))
        print('DRY RUN: no files written and no jobs submitted.');return
    if old:
        tracked=[str(v) for v in old.get('jobs',{}).values()]
        if tracked:
            q=subprocess.run(['squeue','-h','-j',','.join(tracked),'-o','%A|%T|%r'],text=True,capture_output=True)
            if q.returncode and 'Invalid job id' not in q.stderr:raise RuntimeError('Could not inspect existing jobs: '+q.stderr)
            lines=[x for x in q.stdout.splitlines() if x.strip()];active=[x for x in lines if 'DependencyNeverSatisfied' not in x]
            if active:raise SystemExit('This exact batch still has live jobs; refusing duplicates:\n'+'\n'.join(active))
            # Only known dependency-blocked jobs from THIS failed graph are obsolete.
            blocked={x.split('|')[0] for x in lines}
            if blocked:subprocess.run(['scancel',*sorted(blocked)],check=True)
    batch.mkdir(parents=True,exist_ok=True);code=batch/'code'
    if not code.exists():
        for p in inputs():
            dst=code/p.relative_to(ROOT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
    for rel,h in hashes.items():
        if digest(code/rel)!=h:raise SystemExit('Frozen snapshot mismatch: '+rel)
    record={'identity':identity,'jobs':{},'graph':graph};write(batch/'submission.json',record)
    for stage,parent,array,wall in graph:
        cmd=stage_command(batch,identity,stage,parent,array,wall,record['jobs'])
        submit_stage(batch,record,cmd,stage)
    print('Batch:',batch);print('Status: python '+str(code/'status_vista.py')+' --batch '+str(batch))

if __name__=='__main__':main()
