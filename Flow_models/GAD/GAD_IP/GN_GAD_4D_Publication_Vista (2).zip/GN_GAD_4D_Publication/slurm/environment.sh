#!/usr/bin/env bash
# Restore the base interpreter environment even when an explicit venv is used.
set -euo pipefail
if [[ "${GAD4_SKIP_MODULES:-0}" != 1 ]]; then
  if type module >/dev/null 2>&1; then
    # The Python module supplies its own GCC/CUDA dependencies. Do not force
    # the old gcc/13 default over the gcc14/cuda12 base used by this venv.
    module load "${GAD4_PYTHON_MODULE:-python3/3.11.8}"
  fi
fi
if [[ -n "${1:-}" ]]; then
  GAD4_PY="$1"
else
  GAD4_PY="${GAD4_VENV_DIR:-${SCRATCH:?Set SCRATCH or GAD4_VENV_DIR}/venvs/gad_trajectory4}/bin/python"
fi
[[ -x "$GAD4_PY" ]] || { echo "Python executable missing: $GAD4_PY" >&2; return 2; }
# A venv does not bundle libpython. Its executable normally links to the module
# installation; support both symlinked and copied venv executables without
# requiring Python to start before its loader path has been repaired.
GAD4_ENV_PREFIX="$(cd "$(dirname "$GAD4_PY")/.." && pwd -P)"
GAD4_REAL_PY="$(readlink -f "$GAD4_PY")"
GAD4_BASE_PREFIX="$(cd "$(dirname "$GAD4_REAL_PY")/.." && pwd -P)"
GAD4_CFG_HOME=""
if [[ -f "$GAD4_ENV_PREFIX/pyvenv.cfg" ]]; then
  GAD4_CFG_HOME="$(awk -F ' = ' '$1 == "home" {print $2; exit}' "$GAD4_ENV_PREFIX/pyvenv.cfg")"
fi
for GAD4_LIBDIR in "$GAD4_ENV_PREFIX/lib" "$GAD4_ENV_PREFIX/lib64" "$GAD4_BASE_PREFIX/lib" "$GAD4_BASE_PREFIX/lib64" "${GAD4_CFG_HOME:-/nonexistent}/../lib" "${GAD4_CFG_HOME:-/nonexistent}/../lib64"; do
  if [[ -d "$GAD4_LIBDIR" ]]; then
    case ":${LD_LIBRARY_PATH:-}:" in
      *":$GAD4_LIBDIR:"*) ;;
      *) export LD_LIBRARY_PATH="$GAD4_LIBDIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ;;
    esac
  fi
done
unset PYTHONPATH PYTHONHOME
export GAD4_PY
export OMP_NUM_THREADS="${GAD4_THREADS:-1}"
export OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS" MKL_NUM_THREADS="$OMP_NUM_THREADS" NUMEXPR_NUM_THREADS="$OMP_NUM_THREADS"
export JAX_ENABLE_X64=true JAX_PLATFORMS=cuda XLA_PYTHON_CLIENT_PREALLOCATE=false MPLBACKEND=Agg PYTHONUNBUFFERED=1
printf 'Python executable: %s\nBase interpreter: %s\n' "$GAD4_PY" "$GAD4_REAL_PY"
"$GAD4_PY" --version
