#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Submission is stdlib-only and does not initialize JAX on a login node.
python3 submit_vista.py --batch "${GAD4_BATCH:-${SCRATCH:?Set SCRATCH or GAD4_BATCH}/gad_4d_5seed_N2000_R4_v1}" --account "${GAD4_ACCOUNT:-DMS22021}" --max-inflight "${GAD4_MAX_INFLIGHT:-2}" "$@"
