"""Reference-free initial laws shared by GAD banks and pMALA chain starts."""
import numpy as np


def draws(target, setup, cfg, count, seed, kind):
    rng = np.random.default_rng(seed)
    if kind == 'prior':
        return target.prior_draws(rng, count)
    if kind == 'laplace':
        return setup['center']+rng.normal(size=(count, target.dim))@setup['factor'].T
    if kind != 'mixed':
        raise ValueError('Unknown initial law: '+kind)
    # Fixed component counts avoid chance omission of the broad component in an
    # eight-chain run. Each method receives the same law, with independent draws.
    broad = int(round(count*cfg['initialization']['mixture_prior_fraction']))
    out = np.concatenate([target.prior_draws(rng, broad),
        setup['center']+rng.normal(size=(count-broad, target.dim))@setup['factor'].T])
    return out[rng.permutation(count)]
