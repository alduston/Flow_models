#!/usr/bin/env python3
"""Immutable campaigns; independent reference; isolated sampler workers."""
import argparse
import contextlib
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile
import numpy as np
from common import ROOT,read,write,npz,signature,source_hashes,log,sha

@contextlib.contextmanager
def lock(path):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a') as f:
        try:fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('This stage is already running: '+str(path))
        yield

def initialize(out,profile,case):
    cfg=read(ROOT/'profiles'/f'{profile}.json');cfg['case']=case
    from models import Target
    target=Target(case,cfg['dim']);identity={'schema':1,'config':cfg,'target':target.data,'source_hashes':source_hashes()}
    identity['binding']=signature(identity)
    out.mkdir(parents=True,exist_ok=True)
    if (out/'campaign.json').exists():
        if read(out/'campaign.json')!=identity:raise ValueError('Changed campaign configuration/target/source. Use a NEW campaign directory.')
    else:write(out/'campaign.json',identity)
    return identity

def load(out):
    m=read(out/'campaign.json')
    if m['source_hashes']!=source_hashes():raise ValueError('Frozen campaign source changed. Use the original source or a NEW campaign.')
    from models import Target
    t=Target(m['config']['case'],m['config']['dim'])
    if t.data!=m['target']:raise ValueError('Changed physical target')
    return m,t

def refsetup(out):
    m,t=load(out);cfg=dict(m['config']);cfg['sampler_seed']=cfg['reference']['seed']
    from prepare import setup
    sb=signature({'campaign':m['binding'],'role':'independent reference MAP'})
    value=setup(t,cfg,out/'reference/setup',sb)
    from reference_coordinates import prepare
    prepare(t,cfg,value[0],out/'reference/setup',sb)
    return value

def reference_chain(out,index):
    m,t=load(out);st=npz(out/'reference/setup/setup.npz')
    from reference import chain
    with lock(out/f'reference/chain{index}.lock'):return chain(t,m['config'],st,out/'reference',m['binding'],index)

def reference_merge(out):
    m,t=load(out)
    from reference import merge
    quality=merge(t,m['config'],out/'reference',m['binding'])
    from reporting import reference_report
    reference_report(t,out/'reference',quality)
    log(f'Reference usable: {quality["reference_usable"]}; Rhat {quality["max_rank_rhat"]:.4f}, min ESS {quality["min_bulk_ess"]:.1f}')
    if not quality['reference_usable'] and not m['config']['allow_provisional_reference']:
        raise RuntimeError('Reference quality gate FAILED. Diagnostics saved. No benchmark seed jobs should run. Extend/reference-review using a new configuration; do not relabel provisional results.')
    from publication_audit import reference_audit
    reference_audit(t,out,quality)
    return quality

def seedsetup(out,seed):
    m,t=load(out);cfg=dict(m['config'])
    if seed not in cfg['seeds']:raise ValueError('Seed not in frozen campaign')
    q=read(out/'reference/quality.json')
    if q['binding']!=m['binding']:raise ValueError('Wrong shared reference')
    if not q['reference_usable'] and not cfg['allow_provisional_reference']:raise RuntimeError('Reference gate failed')
    cfg['sampler_seed']=seed;sb=signature({'campaign':m['binding'],'seed':seed});sd=out/f'seed{seed}'
    from prepare import setup,production_endpoint
    with lock(sd/'setup.lock'):
        st,info=setup(t,cfg,sd/'setup',sb)
        st=production_endpoint(st,cfg,npz(out/'reference/samples.npz')['samples'],sd/'setup',sb)
        write(sd/'identity.json',{'campaign_binding':m['binding'],'binding':sb,'seed':seed,'reference_shared_from':str(out/'reference'),
                               'reference_usable':q['reference_usable'],'provisional':not q['reference_usable']})
    return m,t,cfg,st,info,sb

def worker(out,seed,law,kind):
    m,t=load(out);cfg=dict(m['config']);cfg['sampler_seed']=seed
    if seed not in cfg['seeds'] or law not in (cfg['initializations'] if kind=='gad' else cfg.get('pmala_initializations',cfg['initializations'])):raise ValueError('Undeclared seed/law')
    sd=out/f'seed{seed}';ident=read(sd/'identity.json')
    if ident['campaign_binding']!=m['binding']:raise ValueError('Seed prepared under wrong campaign')
    if ident['provisional'] and not cfg['allow_provisional_reference']:raise RuntimeError('Reference gate failed')
    st=npz(sd/'setup/production_setup.npz');info=read(sd/'setup/setup.json');sb=ident['binding']
    from samplers import gad,mala
    b=signature({'seed_binding':sb,'law':law,'kind':kind})
    with lock(sd/f'{kind}_{law}.lock'):
        if kind=='gad':return gad(t,cfg,st,info,sd/f'gad_{law}',b,seed,law)
        cap_law=law if law in cfg['initializations'] else 'mixed'
        gb=signature({'seed_binding':sb,'law':cap_law,'kind':'gad'})
        records=[]
        for r in range(1,cfg['gad']['rounds']+1):
            rec=read(sd/f'gad_{cap_law}/round{r}/sampling.json')
            if rec['binding']!=gb:raise ValueError('Wrong GAD cap identity')
            records.append(rec)
        if kind=='gnmala' and law!='mixed':raise ValueError('GN-MALA secondary control is mixed-start only')
        return mala(t,cfg,st,info,records,sd/f'{kind}_{law}',b,seed,law,kind)

def sample_law(out,seed,law):
    m,_=load(out);cfg=m['config']
    kinds=(['gad'] if law in cfg['initializations'] else [])+(['pmala'] if law in cfg.get('pmala_initializations',cfg['initializations']) else [])+(['gnmala'] if cfg['run_gnmala'] and law=='mixed' else [])
    for kind in kinds:
        subprocess.run([sys.executable,'-u',str(ROOT/'run.py'),'worker','--out',str(out),'--seed',str(seed),'--law',law,'--kind',kind],check=True,cwd=ROOT)

def sample_seed(out,seed):
    m,*_=seedsetup(out,seed)
    for law in dict.fromkeys(m['config']['initializations']+m['config'].get('pmala_initializations',[])):sample_law(out,seed,law)
    from display_sampling import frozen_outputs
    frozen_outputs(out,seed)
    from reporting import evaluate_seed
    evaluate_seed(out,seed)
    write(out/f'seed{seed}/complete.json',{'campaign_binding':m['binding'],'seed':seed,'all_sampling_display_and_evaluation_complete':True})

def preflight(out):
    m,t=load(out);file=out/'preflight/numerical.json'
    if file.exists() and read(file).get('binding')==m['binding']:return read(file)
    from tests import numerical_tests
    result=numerical_tests(t,m['config']);result['binding']=m['binding'];write(file,result);return result

def export(out,include_checkpoints=False):
    target=out/('GN_GAD_4D_CHECKPOINT.zip' if include_checkpoints else 'GN_GAD_4D_PAPER_RESULTS.zip')
    with zipfile.ZipFile(target.with_suffix('.tmp'),'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            if not p.is_file() or p.suffix in ('.zip','.tmp','.lock') or '.inprogress.' in p.name:continue
            rel=p.relative_to(out)
            eligible=include_checkpoints or rel.parts[0] in ('report','preflight') or p.suffix in ('.json','.csv')
            if eligible:z.write(p,str(rel))
        if (out.parent/'submission.json').exists():
            for file in sorted(out.parent.glob('*.log')):z.write(file,'logs/'+file.name)
    os.replace(target.with_suffix('.tmp'),target)
    with zipfile.ZipFile(target) as z:
        if z.testzip():raise RuntimeError('Export ZIP integrity failure')
    log('Exported '+str(target));return target

def status(out):
    if not (out/'campaign.json').exists():
        value={'preparation':'not initialized; check the prepare job queue/log','campaign_exists':False,'out':str(out)}
        print(json.dumps(value,indent=2));return value
    m=read(out/'campaign.json');rows=[]
    for s in m['config']['seeds']:
        done=[]
        cfg=m['config']
        for kind,laws in [('gad',cfg['initializations']),('pmala',cfg.get('pmala_initializations',cfg['initializations']))]+([('gnmala',['mixed'])] if cfg['run_gnmala'] else []):
            for law in laws:
                file=out/f'seed{s}'/(f'gad_{law}/round{cfg["gad"]["rounds"]}/sampling.json' if kind=='gad' else f'{kind}_{law}/complete.json')
                done.append({'kind':kind,'law':law,'complete':file.exists()})
        rows.append({'seed':s,'tasks':done})
    value={'profile':m['config']['profile'],'case':m['config']['case'],'reference':read(out/'reference/quality.json').get('reference_usable') if (out/'reference/quality.json').exists() else 'pending','seeds':rows}
    print(json.dumps(value,indent=2));return value

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('stage',choices=['init','preflight','reference-prepare','reference-chain','reference-merge','reference','seed-prepare','sample-law','worker','seed','report','evaluate','export','status','run'])
    ap.add_argument('--out',required=True,type=Path);ap.add_argument('--profile',default='vista',choices=['vista','kaggle','confirm','smoke']);ap.add_argument('--case',default='primary',choices=['primary','narrow','wide','informative'])
    ap.add_argument('--seed',type=int,default=42);ap.add_argument('--chain',type=int,default=0);ap.add_argument('--law',choices=['mixed','laplace'],default='mixed');ap.add_argument('--kind',choices=['gad','pmala','gnmala'],default='gad');ap.add_argument('--checkpoints',action='store_true')
    a=ap.parse_args();out=a.out.resolve();stage=a.stage
    if stage in ('init','run'):initialize(out,a.profile,a.case)
    if stage in ('preflight','run'):preflight(out)
    if stage=='reference-prepare':refsetup(out)
    if stage=='reference-chain':reference_chain(out,a.chain)
    if stage in ('reference','run'):
        m,_=load(out);refsetup(out)
        for c in range(m['config']['reference']['chains']):reference_chain(out,c)
    if stage in ('reference-merge','reference','run'):reference_merge(out)
    if stage=='seed-prepare':seedsetup(out,a.seed)
    if stage=='sample-law':sample_law(out,a.seed,a.law)
    if stage=='worker':worker(out,a.seed,a.law,a.kind)
    if stage=='seed':sample_seed(out,a.seed)
    if stage=='evaluate':
        from reporting import evaluate_seed
        evaluate_seed(out,a.seed)
    if stage=='run':
        m,_=load(out)
        for seed in m['config']['seeds']:sample_seed(out,seed)
    if stage in ('report','run'):
        from reporting import campaign_report
        campaign_report(out)
    if stage in ('export','run'):export(out,a.checkpoints)
    if stage=='status':status(out)

if __name__=='__main__':main()
