#!/usr/bin/env python3
"""Standard-library batch freezing, Slurm submission, restart, and stage dispatch."""
import argparse
import datetime
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

from common import ROOT, digest, read_json, run_directory, settings, signature, stage_status, write_json
from scheduler_identity import check_cluster


def validate_config(c):
    if set(c['problems'])-{'afwi','allen_cahn','navier_stokes','helmholtz'}:raise ValueError('Unknown problem')
    seeds=c['sampler_seeds'];n=c['nuts'];e=c['evaluation']
    if not seeds or len(seeds)!=len(set(seeds)) or any(not isinstance(s,int) or s<0 for s in seeds):raise ValueError('Distinct nonnegative sampler seeds required')
    if n['num_chains']<4 or n['num_samples']<4 or n['num_warmup']<1 or n['chunk_size']<1:raise ValueError('Invalid NUTS sizes')
    if n['max_tree_depth']<1 or n['max_tree_depth_warmup']<1:raise ValueError('Invalid NUTS tree depth')
    if not 0<n['target_accept']<1:raise ValueError('Invalid target acceptance')
    if n.get('mass_mode','dense') not in {'fixed','diagonal','dense'}:raise ValueError('Invalid NUTS mass_mode')
    if not 0<c['aggregation']['confidence']<1:raise ValueError('Invalid confidence')
    if c['aggregation']['illustration_seed'] not in seeds:raise ValueError('Illustration seed must be a registered repeat')
    if c['aggregation']['bootstrap_replicates']<100 or e['reference_bootstrap']<20:raise ValueError('Too few bootstrap draws')
    for p in c['problems']:
        from common import sampler_settings
        sampler_settings(c,p)
    if set(c.get('active_problems',c['problems']))-set(c['problems']):raise ValueError('Active problem absent from config')
    if c['slurm'].get('max_outstanding_tasks',32)<1:raise ValueError('Positive task cap required')
    for partition,entry in c['slurm'].get('partition_limits',{}).items():
        if not 1<=entry['max_outstanding_tasks']<=entry['max_submit']:raise ValueError('Invalid partition task cap: '+partition)
    return c


def freeze(config_path,batch,problems=None,reuse_runs=None):
    c=validate_config(read_json(config_path));cluster=check_cluster(c);batch=Path(batch).resolve()
    if ROOT in batch.parents and batch.relative_to(ROOT).parts[0]!='batches':
        raise ValueError('Place batches outside the bundle or under its batches/ directory, so source snapshots cannot include themselves')
    if batch.exists():raise FileExistsError(f'Use --resume-batch for existing {batch}')
    problems=problems or list(c['problems'])
    if any(p not in c['problems'] for p in problems):raise ValueError('Requested problem absent from config')
    batch.mkdir(parents=True)
    shutil.copytree(ROOT,batch/'code',ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','batches','output','*.pyc'))
    write_json(batch/'settings.json',c)
    (batch/'logs').mkdir();(batch/'stages').mkdir()
    hashes={str(p.relative_to(batch/'code')):digest(p) for p in sorted((batch/'code').rglob('*')) if p.is_file()}
    write_json(batch/'source_manifest.json',hashes)
    write_json(batch/'batch.json',dict(problems=problems,settings_sha256=digest(batch/'settings.json'),
                                     scheduler_cluster=cluster,
                                     created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                     source_manifest_sha256=digest(batch/'source_manifest.json'),reuse_runs=str(reuse_runs) if reuse_runs else None))
    if reuse_runs:
        old=Path(reuse_runs).resolve();previous=settings(old)
        for key in ('data_seed','sampler_seeds','sampler','problems'):
            if c[key]!=previous[key]:raise ValueError(f'Cannot reuse runs: changed {key}')
        for p in problems:
            for seed in c['sampler_seeds']:
                source=run_directory(old,p,seed)
                if not (source/'repeat_identity.json').exists():continue
                binding=read_json(source/'repeat_identity.json')
                if binding['samples_sha256']!=digest(source/'samples_all_rounds.npz'):raise ValueError('Reused run checksum failed')
                config=read_json(source/'experiment_config.json')
                if config['sampling_sha256']!=digest(batch/'code/vendor/screening/sampling.py') or config['model_sha256']!=digest(batch/f'code/vendor/screening/models/{p}.py'):
                    raise ValueError('Reused run sampler/model source changed')
                dest=run_directory(batch,p,seed);dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copytree(source,dest,ignore=shutil.ignore_patterns('publication_*','publication_model'))
    return batch


def verify_frozen(batch):
    check_cluster(settings(batch))
    b=read_json(batch/'batch.json')
    if digest(batch/'settings.json')!=b['settings_sha256']:raise ValueError('Frozen settings changed; create a new batch with --reuse-runs')
    if digest(batch/'source_manifest.json')!=b['source_manifest_sha256']:raise ValueError('Source manifest changed')
    for name,sha in read_json(batch/'source_manifest.json').items():
        if digest(batch/'code'/name)!=sha:raise ValueError(f'Frozen source changed: {name}')


def submit(args):
    from planner import run_pass
    if args.resume_batch:
        batch=Path(args.resume_batch).resolve();verify_frozen(batch)
        if read_json(batch/'batch.json').get('workflow_version')!=2:
            raise ValueError('This is a v1 frozen batch. Create a new --batch with --reuse-from OLD_BATCH; the planner will reuse compatible completed or live work without editing the old snapshot.')
    else:
        batch=Path(args.batch or f'batches/gad_ip_followup_{datetime.datetime.now():%Y%m%d_%H%M%S}_{os.getpid()}').resolve()
        c=validate_config(read_json(args.config))
        freeze(args.config,batch,args.problems or c.get('active_problems',list(c['problems'])))
        meta=read_json(batch/'batch.json');meta['workflow_version']=2;write_json(batch/'batch.json',meta)
    c=settings(batch)
    import fcntl
    with (batch/'.submission.lock').open('a') as selection_lock:
        fcntl.flock(selection_lock,fcntl.LOCK_EX)
        selection_path=batch/'selection.json'
        if args.repeats is not None:count=args.repeats
        elif selection_path.exists():count=len(read_json(selection_path)['sampler_seeds'])
        else:count=min(c.get('initial_repeats',len(c['sampler_seeds'])),len(c['sampler_seeds']))
        if not 2<=count<=len(c['sampler_seeds']):raise ValueError('Request 2 through the registered maximum number of repeats')
        if selection_path.exists() and read_json(selection_path)['sampler_seeds']!=c['sampler_seeds'][:count]:
            from planner import Slurm,ACTIVE
            jobs=read_json(batch/'jobs.json') if (batch/'jobs.json').exists() else {}
            reports=[v['id'] for k,v in jobs.items() if k.startswith('aggregate-')]
            if reports:
                states=Slurm(reports,offline=args.offline)
                if any(states.state(j) in ACTIVE or states.state(j)=='UNKNOWN' for j in reports):raise ValueError('Wait for the current aggregate job to finish before changing --repeats; this protects the report selection.')
        if args.max_outstanding_tasks is not None and args.max_outstanding_tasks<1:raise ValueError('Positive task cap required')
        write_json(selection_path,dict(sampler_seeds=c['sampler_seeds'][:count],maximum=len(c['sampler_seeds']),phase='initial' if count<len(c['sampler_seeds']) else 'final'))
        reuse_path=batch/'reuse_sources.json'
        reuse=read_json(reuse_path) if reuse_path.exists() else dict(batches=[str(batch.parent)],screening_runs=[])
        for name,values in [('batches',(args.reuse_from or [])+([args.reuse_runs] if args.reuse_runs else [])),('screening_runs',args.import_runs or [])]:
            for value in values:
                value=str(Path(value).resolve())
                if value not in reuse[name]:reuse[name].append(value)
        write_json(reuse_path,reuse)
    if args.watch and args.dry_run:raise ValueError('--watch cannot be combined with --dry-run')
    if args.offline and not args.dry_run:raise ValueError('--offline is allowed only with --dry-run')
    if not 1<=args.poll_seconds<=60:raise ValueError('--poll-seconds must be 1 through 60')
    attempts=set();passes=0
    while True:
        # The current bundle may orchestrate older frozen scientific code only
        # through adoption. Every newly submitted worker uses this batch's code.
        result=run_pass(batch,args,attempts);passes+=1
        if not args.watch or result['deferred_tasks']==0 or result['failed_tasks']:
            print(f'Batch: {batch}\nResults: {batch}/gad_ip_publication_results.zip',flush=True)
            return 2 if result['failed_tasks'] else 0
        if args.max_passes and passes>=args.max_passes:return 0
        print(f'Submission limits/dependencies deferred {result["deferred_tasks"]} tasks; checking again in {args.poll_seconds}s. Already submitted jobs continue if this driver is stopped.',flush=True)
        time.sleep(args.poll_seconds)


def stage(args):
    from cache import adopt_reference,adopt_run,compatible_sources,import_screening_run,source_batches,summary_key
    from common import selected_config
    batch=Path(args.batch).resolve();verify_frozen(batch);c=settings(batch);p=args.problem;task=args.task;name=args.stage
    path=batch/'stages'/f'{p}-{name}-{task}.json'
    def execute():
        from arviz_compat import load_arviz
        load_arviz()
        if name=='preflight':
            from check_environment import check
            return check(record=batch/'logs/environment-preflight.json',allow_cpu=args.allow_cpu)
        if p not in read_json(batch/'batch.json')['problems'] and name!='aggregate':raise ValueError('Problem not registered')
        reuse=read_json(batch/'reuse_sources.json') if (batch/'reuse_sources.json').exists() else dict(batches=[],screening_runs=[])
        if name!='aggregate':
            adopt_reference(batch,p,compatible_sources(batch,p,reuse['batches'],kind='target'),
                            chain_indices=[],include_reference=False)
            indices=[task] if name=='chain' else ([] if name in {'repeat','evaluate'} else None)
            adopt_reference(batch,p,compatible_sources(batch,p,reuse['batches']),chain_indices=indices,include_reference=name in {'prepare','certify'})
        if name=='prepare':
            from reference import prepare
            return prepare(batch,p)
        if name=='chain':
            from reference import chain
            return chain(batch,p,task)
        if name=='certify':
            from cache import reference_valid,summary_valid
            from reference import certify,summarize
            if not reference_valid(batch,p):certify(batch,p)
            if not summary_valid(batch,p):summarize(batch,p)
            record=read_json(batch/'reference'/p/'summary.json');record['compatibility_key']=summary_key(c,p)
            write_json(batch/'reference'/p/'summary.json',record)
            return dict(reference_ready=True)
        if name in {'repeat','evaluate'}:
            if task not in c['sampler_seeds']:raise ValueError('Invalid sampler seed')
            adopt_run(batch,p,task,source_batches(reuse['batches'],batch))
            import_screening_run(batch,p,task,reuse['screening_runs'])
            if name=='repeat':
                from repeat import run_repeat
                return run_repeat(batch,p,task,allow_cpu=args.allow_cpu)
            from cache import evaluation_valid
            if evaluation_valid(batch,p,task):return dict(cached=True)
            from comparison import evaluate_repeat
            return evaluate_repeat(batch,p,task)
        if name=='aggregate':
            from aggregate_publication import aggregate
            result=aggregate(batch)
            if not result['complete']:raise RuntimeError('Incomplete requested subset; diagnostic results ZIP and failure inventory were written')
            return result
    return stage_status(path,execute)


def main():
    parser=argparse.ArgumentParser(description=__doc__);subs=parser.add_subparsers(dest='command',required=True)
    p=subs.add_parser('submit');p.add_argument('--config',type=Path,default=ROOT/'settings.json')
    p.add_argument('--batch');p.add_argument('--resume-batch');p.add_argument('--reuse-runs',help='Compatibility alias for --reuse-from')
    p.add_argument('--reuse-from',action='append',help='Existing batch or parent of batches; sibling batches are searched automatically')
    p.add_argument('--import-runs',action='append',help='Full canonical screening run tree; actual metadata seeds and realized target arrays are checked')
    p.add_argument('--repeats',type=int,help='Requested first N sampler seeds; default 5 initially, expand to 10 later')
    p.add_argument('--account','-A');p.add_argument('--dry-run',action='store_true');p.add_argument('--offline',action='store_true',help='Dry-run without Slurm queries')
    p.add_argument('--problems',nargs='+');p.add_argument('--partition')
    p.add_argument('--max-outstanding-tasks',type=int,help='Cap ALL current user task slots, including unrelated jobs; default 32')
    p.add_argument('--retry-failed',action='store_true',help='One deliberate retry per failed task per invocation')
    p.add_argument('--watch',action='store_true',help='Refill deferred jobs until all tasks have been submitted; keep this lightweight driver alive')
    p.add_argument('--poll-seconds',type=int,default=30);p.add_argument('--max-passes',type=int,help=argparse.SUPPRESS)
    p.add_argument('--time',action='append',help='Override reservations only, e.g. --time chain=12:00:00')
    p=subs.add_parser('stage');p.add_argument('--batch',type=Path,required=True)
    p.add_argument('--stage',choices=['preflight','prepare','chain','certify','repeat','evaluate','aggregate'],required=True)
    p.add_argument('--problem',default='all');p.add_argument('--task',type=int,default=0);p.add_argument('--allow-cpu',action='store_true')
    p=subs.add_parser('status');p.add_argument('--batch',type=Path,required=True)
    a=parser.parse_args()
    if a.command=='submit':return submit(a)
    if a.command=='stage':stage(a);return 0
    for path in sorted((a.batch/'stages').glob('*.json')):
        value=read_json(path)
        if isinstance(value,dict):print(path.name,value.get('state',''),value.get('error',''))
    if (a.batch/'submission_plan.json').exists():
        plan=read_json(a.batch/'submission_plan.json')
        if isinstance(plan,dict):
            for row in plan['nodes']:print(row['key'],row['state'],row.get('reason',''))
    return 0


if __name__=='__main__':sys.exit(main())
