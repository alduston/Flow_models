"""Incremental, capped Slurm submission. This module performs no GPU work."""
from dataclasses import dataclass,field
import fcntl
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

from common import digest,read_json,settings,signature,write_json
from scheduler_identity import same_scheduler
from cache import (adopt_reference,adopt_run,chain_valid,compatible_sources,evaluation_valid,
                   import_screening_run,prepared_valid,reference_key,reference_valid,run_key,
                   run_valid,source_batches,summary_valid)

ACTIVE={'PENDING','RUNNING','CONFIGURING','COMPLETING','SUSPENDED','RESIZING','REQUEUED','REQUEUE_FED','SIGNALING','STAGE_OUT','RESV_DEL_HOLD','REQUEUE_HOLD'}


class Slurm:
    def __init__(self,ids=(),offline=False):
        self.states={};self.count=0;self.partition_counts={}
        if offline:return
        result=subprocess.run(['squeue','--noheader','--array','--user',os.environ.get('USER',''),'--format=%i|%T|%P'],capture_output=True,text=True)
        if result.returncode:raise RuntimeError('Cannot inspect squeue; refusing to risk duplicate submissions: '+result.stderr)
        for line in result.stdout.splitlines():
            if '|' not in line:continue
            fields=[v.strip() for v in line.split('|')]
            jid,state=fields[:2];self.states[jid]=state.split()[0];self.count+=1
            partitions=fields[2].split(',') if len(fields)>2 and fields[2] else ['_unknown']
            for partition in set(partitions):self.partition_counts[partition]=self.partition_counts.get(partition,0)+1
        missing=sorted({str(i).split('_')[0] for i in ids if str(i).split('_')[0] not in self.states})
        if missing:
            result=subprocess.run(['sacct','-X','-n','-P','-j',','.join(missing),'--format=JobID%80,State%40'],capture_output=True,text=True)
            if result.returncode:raise RuntimeError('Cannot inspect recorded jobs in sacct: '+result.stderr)
            for line in result.stdout.splitlines():
                fields=line.split('|')
                if len(fields)>=2 and fields[0].strip():self.states.setdefault(fields[0].strip(),fields[1].strip().split()[0].rstrip('+'))

    def outstanding_in(self,partition):
        return self.partition_counts.get(partition,0)+self.partition_counts.get('_unknown',0)

    def state(self,jid):
        jid=str(jid)
        if jid in self.states:return self.states[jid]
        children=[v for k,v in self.states.items() if k.startswith(jid+'_')]
        if any(v in ACTIVE for v in children):return 'RUNNING'
        if children and all(v=='COMPLETED' for v in children):return 'COMPLETED'
        if children:return next((v for v in children if v!='COMPLETED'),'COMPLETED')
        return 'UNKNOWN'


@dataclass
class Node:
    key:str
    state:str
    ids:list=field(default_factory=list)

    @property
    def usable(self):return self.state in {'cached','submitted','existing'}


def id_list(batch):
    path=Path(batch)/'jobs.json'
    return [v['id'] for v in read_json(path).values()] if path.exists() else []


def live_donor_job(batch,problem,stage,task,sources,slurm):
    current=settings(batch)
    for source in sources:
        try:
            if not same_scheduler(batch,source):continue
            old=settings(source);jobs=read_json(source/'jobs.json')
            if stage in {'prepare','chain'}:
                if reference_key(current,problem,Path(batch)/'code')!=reference_key(old,problem,source/'code'):continue
                keys=[f'{problem}-prepare'] if stage=='prepare' else [f'{problem}-chain-{task}',f'{problem}-chains']
            else:
                if run_key(current,problem,task,Path(batch)/'code')!=run_key(old,problem,task,source/'code'):continue
                keys=[f'{problem}-repeat-{task}',f'{problem}-repeats']
            for key in keys:
                if key not in jobs:continue
                jid=str(jobs[key]['id'])
                if key.endswith('-chains'):jid+=f'_{task}'
                if key.endswith('-repeats'):
                    # Old bundles had two workers, each running five seeds.
                    if task not in old['sampler_seeds']:continue
                    jid+=f'_{old["sampler_seeds"].index(task)%min(2,len(old["sampler_seeds"]))}'
                if slurm.state(jid) in ACTIVE:return jid,str(source)
        except (OSError,KeyError,ValueError):continue
    return None


def report_signature(batch,problems,seeds):
    inputs=[]
    for p in problems:
        if not summary_valid(batch,p):return None
        for s in seeds:
            if not evaluation_valid(batch,p,s):return None
            from common import run_directory
            inputs.append(digest(run_directory(batch,p,s)/'publication_identity.json'))
    return signature(dict(settings=digest(Path(batch)/'settings.json'),problems=problems,seeds=seeds,inputs=inputs))


class Pass:
    def __init__(self,batch,args,submitted_this_session):
        self.batch=Path(batch);self.args=args;self.c=settings(batch);self.slurm_cfg=dict(self.c['slurm'])
        self.meta=read_json(self.batch/'batch.json');self.selection=read_json(self.batch/'selection.json')
        self.problems=self.meta['problems'];self.seeds=self.selection['sampler_seeds']
        reuse=read_json(self.batch/'reuse_sources.json')
        self.roots=reuse['batches'];self.imports=reuse['screening_runs'];self.sources=source_batches(self.roots,self.batch)
        ids=id_list(self.batch)
        for src in self.sources:
            if same_scheduler(self.batch,src):ids+=id_list(src)
        self.slurm=Slurm(ids,offline=args.offline);self.initial_count=self.slurm.count
        self.jobs=read_json(self.batch/'jobs.json') if (self.batch/'jobs.json').exists() else {}
        self.nodes=[];self.adoptions=[];self.commands=[];self.preflight=None;self.failed=False;self.reservation_blocked=False
        self.submitted_this_session=submitted_this_session
        self.cap=args.max_outstanding_tasks or self.slurm_cfg.get('max_outstanding_tasks',32)
        if args.partition:self.slurm_cfg['partition']=args.partition
        partition=self.slurm_cfg['partition']
        limits=self.slurm_cfg.get('partition_limits',{})
        if partition not in limits:raise ValueError('Unknown LS6 GPU partition: '+partition+'; configure its limits explicitly')
        entry=limits[partition]
        self.partition_cap=min(int(entry['max_submit']),int(entry['max_outstanding_tasks']))
        self.initial_partition_count=self.slurm.outstanding_in(partition)
        self.partition_blocker=None
        if self.slurm_cfg.get('check_partition_availability') and not args.offline:
            partition=self.slurm_cfg['partition']
            result=subprocess.run(['sinfo','--noheader','--partition',partition,'--format=%a'],capture_output=True,text=True)
            if result.returncode:raise RuntimeError('Cannot inspect partition availability: '+result.stderr.strip())
            availability={row.strip().lower() for row in result.stdout.splitlines() if row.strip()}
            if not availability:raise RuntimeError(f'sinfo returned no availability for partition {partition}')
            if availability!={'up'}:
                self.partition_blocker=f'Partition {partition} availability: {", ".join(sorted(availability))}; waiting for it to reopen'
        for item in args.time or []:
            key,value=item.split('=',1)
            if key+'_time' not in self.slurm_cfg or not re.fullmatch(r'\d+:\d{2}:\d{2}',value):raise ValueError('Use --time chain=12:00:00 etc.')
            self.slurm_cfg[key+'_time']=value

    def record(self,key,state,**extra):
        self.nodes.append(dict(key=key,state=state,**extra));return Node(key,state,extra.get('job_ids',[]))

    def cached(self,key,why):return self.record(key,'cached',reason=why)

    def external(self,key,value):
        jid,source=value
        return self.record(key,'existing',job_ids=[jid],reason='compatible work already queued/running',source=source)

    def ensure_preflight(self):
        if self.preflight is not None:return self.preflight
        path=self.batch/'stages/all-preflight-0.json'
        if path.exists() and read_json(path).get('state')=='complete':self.preflight=self.cached('preflight','GPU preflight already completed')
        else:self.preflight=self.queue('preflight','preflight',need_preflight=False)
        return self.preflight

    def queue(self,key,stage,problem='all',task=0,deps=(),afterany=(),need_preflight=True):
        previous=self.jobs.get(key)
        if previous:
            state=self.slurm.state(previous['id'])
            if state in ACTIVE:return self.record(key,'existing',job_ids=[str(previous['id'])],reason='same task already queued/running')
            if state=='UNKNOWN' and not self.args.offline:return self.record(key,'blocked',reason='recorded job has not appeared in squeue/sacct; wait for accounting')
            if key in self.submitted_this_session or not self.args.retry_failed:
                self.failed=True
                return self.record(key,'failed',reason=f'Previous job {previous["id"]}: {state}; required output is absent/invalid. Inspect logs; use --retry-failed for a deliberate retry.')
        dependencies=list(deps)
        if need_preflight:dependencies.append(self.ensure_preflight())
        if any(not x.usable for x in dependencies+list(afterany)):
            return self.record(key,'deferred',reason='required predecessor has not been submitted or has failed')
        if self.partition_blocker:return self.record(key,'deferred',reason=self.partition_blocker)
        if self.reservation_blocked:return self.record(key,'deferred',reason='Scheduler reservation/submit limit reached earlier in this pass')
        if self.slurm.count>=self.cap:return self.record(key,'deferred',reason=f'User has {self.slurm.count} outstanding task slots; cap {self.cap}')
        partition=self.slurm_cfg['partition']
        outstanding=self.slurm.outstanding_in(partition)
        if outstanding>=self.partition_cap:
            return self.record(key,'deferred',reason=f'Partition {partition} has {outstanding} outstanding user task slots; cap {self.partition_cap}')
        ok=sorted({jid for x in dependencies for jid in x.ids});any_ids=sorted({jid for x in afterany for jid in x.ids})
        cmd=['sbatch','--parsable','-p',self.slurm_cfg['partition'],'-N','1','-n','1',
             '--time='+self.slurm_cfg[stage+'_time'],'--job-name=gp-'+key,
             '--output='+str(self.batch/'logs'/(key+'-%j.out'))]
        account=self.args.account or os.getenv('GP_ACCOUNT') or self.slurm_cfg.get('account')
        if account:cmd+=['-A',account]
        clauses=[]
        if ok:clauses.append('afterok:'+':'.join(ok))
        if any_ids:clauses.append('afterany:'+':'.join(any_ids))
        if clauses:cmd+=['--dependency='+','.join(clauses),'--kill-on-invalid-dep=yes']
        cmd+=[str(self.batch/'code/slurm/job.slurm'),str(self.batch),stage,problem,str(task)]
        self.commands.append(dict(key=key,command=cmd))
        if self.args.dry_run:
            import shlex
            print(shlex.join(cmd));jid=str(900000+len(self.commands))
        else:
            result=subprocess.run(cmd,capture_output=True,text=True)
            log=self.batch/'logs'/f'submit-{key}-{time.time_ns()}.log';log.write_text(result.stdout+result.stderr)
            if result.returncode:
                budget=any(t in (result.stdout+result.stderr).lower() for t in ['insufficient balance','job submit limit','maxsubmit','qosmaxsubmit','maximum number of jobs'])
                if budget:
                    self.reservation_blocked=True
                    return self.record(key,'deferred',reason='Scheduler reservation/submit limit; existing submissions retained',log=str(log))
                raise RuntimeError(f'sbatch failed for {key}: see {log}: '+result.stderr.strip())
            ids=re.findall(r'^\s*(?:Submitted batch job\s+)?(\d+)(?:;[^\s;]+)?\s*$',result.stdout,re.MULTILINE)
            if len(ids)!=1:raise RuntimeError(f'Uncertain job ID: inspect {log} before any retry')
            jid=ids[0]
            if previous:
                with (self.batch/'job_history.jsonl').open('a') as f:
                    import json
                    f.write(json.dumps(dict(key=key,previous=previous))+'\n')
            self.jobs[key]=dict(id=jid,command=cmd,submitted_unix=time.time())
            write_json(self.batch/'jobs.json',self.jobs);(self.batch/f'{key}_job_id.txt').write_text(jid+'\n')
            self.submitted_this_session.add(key);print(f'{key}: {jid}',flush=True)
        self.slurm.states[jid]='PENDING';self.slurm.count+=1
        partition=self.slurm_cfg['partition']
        self.slurm.partition_counts[partition]=self.slurm.partition_counts.get(partition,0)+1
        return self.record(key,'submitted',job_ids=[jid])

    def build(self):
        requested=self.args.problems or self.problems
        if any(p not in self.problems for p in requested):raise ValueError('Problem is outside this frozen campaign; create a new batch to add it')
        terminal=[]
        for p in requested:
            sources=compatible_sources(self.batch,p,self.roots)
            local_ref_active=any(k.startswith(p+'-') and ('prepare' in k or 'chain' in k or 'reference' in k) and self.slurm.state(v['id']) in ACTIVE for k,v in self.jobs.items())
            if not local_ref_active:
                self.adoptions+=adopt_reference(self.batch,p,compatible_sources(self.batch,p,self.roots,kind='target'),
                                               chain_indices=[],include_reference=False)
                self.adoptions+=adopt_reference(self.batch,p,sources)
            if prepared_valid(self.batch,p):prep=self.cached(p+'-prepare','matching target and MAP setup are valid')
            else:
                live=live_donor_job(self.batch,p,'prepare',0,sources,self.slurm)
                prep=self.external(p+'-prepare',live) if live else self.queue(p+'-prepare','prepare',p)
            chains=[]
            if reference_valid(self.batch,p):chains=[self.cached(p+'-chains','certified matching NUTS cloud already exists')]
            else:
                for i in range(self.c['nuts']['num_chains']):
                    key=f'{p}-chain-{i}'
                    if chain_valid(self.batch,p,i):node=self.cached(key,'chain sample hash and whitening binding match')
                    else:
                        live=live_donor_job(self.batch,p,'chain',i,sources,self.slurm)
                        node=self.external(key,live) if live else self.queue(key,'chain',p,i,deps=[prep])
                    chains.append(node)
            if summary_valid(self.batch,p):ref=self.cached(p+'-reference','certified cloud and compatible physical/predictive summaries already exist')
            else:ref=self.queue(p+'-reference','certify',p,deps=[prep]+chains)
            for seed in self.seeds:
                key=f'{p}-repeat-{seed}'
                own_live=key in self.jobs and self.slurm.state(self.jobs[key]['id']) in ACTIVE
                if not run_valid(self.batch,p,seed) and not own_live:
                    adopted=adopt_run(self.batch,p,seed,source_batches(self.roots,self.batch))
                    if adopted:self.adoptions.append(adopted)
                    imported=import_screening_run(self.batch,p,seed,self.imports)
                    if imported:self.adoptions.append(imported)
                if run_valid(self.batch,p,seed):run=self.cached(key,'matching data/sampler seed, settings and raw sample checksum are valid')
                else:
                    live=live_donor_job(self.batch,p,'repeat',seed,self.sources,self.slurm)
                    # Raw screening imports need the prepared target before they
                    # can be verified. Wait for that target rather than race a duplicate run.
                    if self.imports and not own_live and not prepared_valid(self.batch,p) and prep.usable:
                        run=self.record(key,'deferred',reason='waiting for prepared target to verify full screening-run imports')
                    else:run=self.external(key,live) if live else self.queue(key,'repeat',p,seed,deps=[prep])
                evalkey=f'{p}-evaluation-{seed}'
                if evaluation_valid(self.batch,p,seed):evaluated=self.cached(evalkey,'reference/evaluation signature and output checksums match')
                else:evaluated=self.queue(evalkey,'evaluate',p,seed,deps=[run,ref])
                terminal.append(evaluated)
        selected_signature=signature(dict(problems=self.problems,seeds=self.seeds))
        key='aggregate-'+selected_signature[:8]
        report=report_signature(self.batch,self.problems,self.seeds)
        previous=self.batch/'meta_results/completion.json'
        if report and previous.exists() and read_json(previous).get('input_signature')==report and read_json(previous).get('complete'):
            self.cached(key,'report input signatures have not changed')
        elif len(requested)!=len(self.problems) and not report:
            self.record(key,'deferred',reason='subset submitted; report waits for the other campaign problems')
        else:
            # A report for failed scientific tasks is still useful, but no
            # dependency may refer to a task that has not been submitted at all.
            self.queue(key,'aggregate',task=0,deps=[],afterany=terminal,need_preflight=False)
        planned=sum(x['state'] in {'deferred','blocked'} for x in self.nodes)
        result=dict(schema=2,batch=str(self.batch),requested_seeds=self.seeds,active_problems=self.problems,
                    nodes=self.nodes,adoptions=self.adoptions,new_submissions=self.commands,
                    initial_user_task_count=self.initial_count,cap=self.cap,partition=self.slurm_cfg["partition"],
                    partition_cap=self.partition_cap,initial_partition_task_count=self.initial_partition_count,deferred_tasks=planned,
                    failed_tasks=sum(x['state']=='failed' for x in self.nodes))
        write_json(self.batch/'submission_plan.json',result)
        with (self.batch/'submission_passes.jsonl').open('a') as f:
            import json
            f.write(json.dumps(dict(unix=time.time(),submitted=len(self.commands),deferred=planned,failed=result['failed_tasks']))+'\n')
        print(f'Plan: {len(self.commands)} new submissions; {sum(x["state"]=="cached" for x in self.nodes)} cached; {planned} deferred; {result["failed_tasks"]} failed. See {self.batch}/submission_plan.json',flush=True)
        return result


def run_pass(batch,args,submitted_this_session):
    path=Path(batch)/'.submission.lock'
    with path.open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        return Pass(batch,args,submitted_this_session).build()
