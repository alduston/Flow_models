# Run on Lonestar6

## 1. Extract and verify the completed installation

Run on an LS6 login node after copying the ZIP into the specified directory. These commands use your existing shared repository prefix; change only that prefix if the repository is elsewhere.

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/sweeps/lonestar6
unzip -qo GAD_IP_publication_lonestar6_fixed_mass_bundle.zip
cd gad_ip_publication
source slurm/environment.sh
python check_environment.py --imports-only
```

The existing `/work/10812/ald4435/ls6/venvs/flow_ls6_py39` is activated; `/work2/...` resolving as its actual prefix is normal. Your diagnostics sibling symlink to `${SCRATCH}/venvs/flow_ls6_py39_gad_diagnostics` is retained and the default lookup is unchanged. No installation is needed for this code update. For a genuinely new environment, the original `bash install_reference_extras.sh` remains available with marker `gad-ls6-reference-extras-1`. GPU execution is checked by an allocated compute-node preflight.

## 2. Start the detached campaign

Use the new fixed-mass LS6 batch below, never `--resume-batch` pointing at a Vista/Frontera batch. Five sampler repeats start initially. The two explicit donors below point to the existing GAD_IP batches and the retired Frontera campaign; the raw-run root points to GAD_IP. Missing donor directories are harmless. Completed compatible files are copied and validated, while donor files and other-cluster live jobs are left alone.

```bash
GP_BATCH=../batches/gad_ip_ls6_fixed_mass_20261027
GP_DRIVER_LOG=../gad_ip_ls6_fixed_mass_20261027_submit.log

nohup bash submit.sh \
  --batch "$GP_BATCH" \
  --reuse-from ../../../batches \
  --reuse-from ../../frontera/batches \
  --import-runs ../../.. \
  --repeats 5 --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown

tail -n 30 "$GP_DRIVER_LOG"
bash check_status.sh --batch "$GP_BATCH" --check-packages
```

Normal plans with zero failed tasks and deferred work mean the watcher is polling. It survives laptop/SSH disconnects. `PENDING` due to Priority/Resources is ordinary queue waiting; `Dependency` waits for predecessors. Package/API checks passing does not establish CUDA support or NUTS convergence: the allocated preflight and reference certification establish those separately. An ArviZ FutureWarning by itself is not an error.

## 3. Resume after reconnecting

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/sweeps/lonestar6/gad_ip_publication
source slurm/environment.sh
GP_BATCH=../batches/gad_ip_ls6_fixed_mass_20261027
GP_DRIVER_LOG=../gad_ip_ls6_fixed_mass_20261027_submit.log

bash check_status.sh --batch "$GP_BATCH"
```

If the previous watcher stopped, use:

```bash
nohup bash submit.sh --resume-batch "$GP_BATCH" --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown
```

Run one watcher per batch. It may exit normally once all tasks are cached/submitted, while Slurm jobs remain pending/running. The process check only sees the watcher on the recorded login host. If jobs failed or were deliberately cancelled, inspect their logs and add `--retry-failed` to the resume invocation for one deliberate retry per task.

## 4. H100 or other GPU queues

A100 is the default because it supports up to eight running jobs per user, versus one on H100. This is a throughput choice, not a predicted wait time. To choose H100 for the initial launch, add `--partition gpu-h100` to `submit.sh` and use that same flag on every resume; the planner automatically applies its four-submission cap. The same frozen LS6 batch may be resumed on another LS6 GPU queue after stopping its old watcher: existing live jobs keep their queues and new submissions use the selected queue. The global cap and per-partition counts cover both. The original configuration file remains frozen; the operational queue selection is logged in each submission plan.

`gpu-a100-small` is supported with a cap of ten; its virtual-node resources differ from full A100 nodes, so assess the allocated preflight and memory behavior before using it broadly. `gpu-a100-dev` has a cap of two and a two-hour wall limit: it is unsuitable for the default 12-hour NUTS jobs unless a shorter explicit chain time is chosen. The scheduler enforces the wall limit; the bundle does not truncate reference lengths.

## 5. Expand to ten repeats

After the five-repeat aggregate finishes and the old watcher exits:

```bash
nohup bash submit.sh --resume-batch "$GP_BATCH" --repeats 10 --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown
```

This retains valid seeds 42–46 and adds missing seeds 47–51. Supply the operational `--partition` flag again if using a nondefault queue. Wait for an active aggregate before changing selection.

Final output: `../batches/gad_ip_ls6_fixed_mass_20261027/gad_ip_publication_results.zip`. A complete campaign requires `meta_results/completion.json` to report `complete: true`; a diagnostic ZIP can exist before all scientific checks pass.
