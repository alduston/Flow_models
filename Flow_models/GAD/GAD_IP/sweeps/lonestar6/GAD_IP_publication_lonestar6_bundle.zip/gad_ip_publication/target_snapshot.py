"""Bind every worker to the authenticated prepared target, not regenerated data."""
from contextlib import contextmanager
import fcntl
import os
from pathlib import Path
import time

VERSION='target-snapshot-1'
EXTRA_FILES=('target_constants.npz','target_probes.npz','target_constants.json')
CONSTANTS={
    'allen_cahn':('IMEX_DENOM',),
    'navier_stokes':('K2','K2_safe','DEALIAS','forcing_hat','OBS_FILTER','CN_NUM','CN_DEN'),
    'helmholtz':('support_mask','support_mask_jax','source_terms','source_terms_jax',
                 'boundary_indices_ordered','boundary_indices_jax','NEG_LAPLACIAN','IDENTITY_WAVE',
                 'BACKGROUND_OPERATOR','BACKGROUND_FIELDS'),
    'afwi':('model_support_mask','model_support_mask_jax','source_patterns','source_patterns_jax',
            'source_time_series','source_time_series_jax','damping_field','damping_field_jax',
            'record_step_indices_np','record_step_indices_jax','holdout_step_indices_np','holdout_step_indices_jax'),
}
BASE=('alpha_true_np','y_obs_np','y_clean_np','y_holdout_obs_np','y_holdout_clean_np')


@contextmanager
def snapshot_lock(directory,write=False):
    path=Path(directory)/'.target_snapshot.lock'
    if not write and not path.exists():
        yield;return
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a' if write else 'r') as handle:
        fcntl.flock(handle,fcntl.LOCK_EX if write else fcntl.LOCK_SH)
        yield


def _extra(directory,target,load=False):
    from common import read_json,digest,load_npz,fingerprint
    directory=Path(directory);paths=[directory/n for n in EXTRA_FILES]
    if not any(p.exists() for p in paths):return None
    if not all(p.is_file() for p in paths):raise ValueError('Incomplete target-constant snapshot')
    info=read_json(paths[2])
    if info['version']!=VERSION or info['fingerprint']!=target['fingerprint'] or info['metadata']!=target['metadata']:
        raise ValueError('Target constants belong to a different prepared target')
    if digest(paths[0])!=info['constants_sha256'] or digest(paths[1])!=info['probes_sha256']:
        raise ValueError('Saved target-constant/probe checksum failed')
    physical_path=directory/'physical_spec.npz'
    if physical_path.exists() and fingerprint(info['metadata'],load_npz(physical_path))!=info['physical_fingerprint']:
        raise ValueError('Physical-field snapshot fingerprint failed')
    if not load:return info
    values=load_npz(paths[0]);probes=load_npz(paths[1])
    allowed=set(CONSTANTS[target['metadata']['problem']])
    if set(values)!=set(info['kinds']) or not set(values).issubset(allowed):
        raise ValueError('Unexpected target-constant names')
    if any(kind not in {'numpy','jax'} for kind in info['kinds'].values()):
        raise ValueError('Unexpected target-constant storage type')
    return info,values,probes


def validate_prepared(batch,problem,require_setup=True):
    """CPU-only validation, usable from the submission planner."""
    import numpy as np
    from common import read_json,load_npz,settings,fingerprint,digest
    directory=Path(batch)/'reference'/problem
    with snapshot_lock(directory):
        target=read_json(directory/'target.json');arrays=load_npz(directory/'target_arrays.npz')
        if fingerprint(target['metadata'],arrays)!=target['fingerprint']:raise ValueError('Saved target-array fingerprint failed')
        if target['metadata']['data_seed']!=settings(batch)['data_seed']:raise ValueError('Prepared data seed changed')
        model_file=Path(batch)/'code/vendor/screening/models'/f'{problem}.py'
        if target['metadata']['model_sha256']!=digest(model_file):raise ValueError('Prepared model source changed')
        if any(not np.isfinite(a).all() for a in arrays.values()):raise ValueError('Non-finite prepared target')
        if require_setup:
            setup=read_json(directory/'setup.json')
            if setup.get('fingerprint',target['fingerprint'])!=target['fingerprint']:
                raise ValueError('MAP setup target fingerprint changed')
            if setup['setup_sha256']!=digest(directory/'setup.npz'):raise ValueError('MAP setup checksum failed')
        _extra(directory,target)
    return target,arrays


def _probes(model):
    import numpy as np
    import jax.numpy as jnp
    alpha=np.stack([model.alpha_true_np,np.zeros(model.ACTIVE_DIM),
                    np.random.default_rng(514).normal(0,.2,model.ACTIVE_DIM)])
    return dict(alpha=alpha,train=np.stack([np.asarray(model.solve_forward(jnp.asarray(a))) for a in alpha]),
                holdout=np.stack([np.asarray(model.solve_forward_holdout(jnp.asarray(a))) for a in alpha]))


def _write(directory,problem,model,metadata,identity,origin):
    import numpy as np
    from common import save_npz,write_json,digest,physical_spec,fingerprint
    directory=Path(directory);values={};kinds={}
    for name in CONSTANTS[problem]:
        if not hasattr(model,name):raise ValueError('Required model constant absent: '+name)
        value=getattr(model,name);array=np.asarray(value)
        if not np.isfinite(array).all():raise ValueError('Non-finite model constant: '+name)
        values[name]=array;kinds[name]='numpy' if isinstance(value,np.ndarray) else 'jax'
    probes=_probes(model)
    if any(not np.isfinite(v).all() for v in probes.values()):raise ValueError('Non-finite target validation probe')
    save_npz(directory/EXTRA_FILES[0],**values);save_npz(directory/EXTRA_FILES[1],**probes)
    write_json(directory/EXTRA_FILES[2],dict(version=VERSION,fingerprint=identity,metadata=metadata,kinds=kinds,
               constants_sha256=digest(directory/EXTRA_FILES[0]),probes_sha256=digest(directory/EXTRA_FILES[1]),
               physical_fingerprint=fingerprint(metadata,physical_spec(problem,model)),
               origin=origin,probe_rule='truth, zero, fixed prior-scale probe; validation only, never MAP initialization'))


def capture_preparation(directory,problem,model,metadata,identity):
    """Called on the actual model instance before the original MAP routine runs."""
    with snapshot_lock(directory,write=True):
        _write(directory,problem,model,metadata,identity,'original_preparation_model')


def _bind(model,problem,arrays,physical,extra):
    import numpy as np
    import jax.numpy as jnp
    model.Basis=jnp.asarray(arrays['basis'],dtype=jnp.float64)
    model.basis_truncated=np.array(arrays['basis'],copy=True)
    for name in ['Basis_Modes','full_basis']:
        if hasattr(model,name):
            value=np.array(getattr(model,name),copy=True);value[:,:model.ACTIVE_DIM]=arrays['basis'];setattr(model,name,value)
    for key in BASE:setattr(model,key,np.array(arrays[key],copy=True))
    model.y_clean=jnp.asarray(model.y_clean_np)
    if hasattr(model,'y_clean_holdout_np'):model.y_clean_holdout_np=model.y_holdout_clean_np.copy()
    if hasattr(model,'y_clean_holdout'):model.y_clean_holdout=jnp.asarray(model.y_holdout_clean_np)
    for name in ['obs_indices_train','obs_indices_holdout','receiver_flat_indices','holdout_receiver_flat_indices',
                 'source_centers','receiver_coords']:
        if name in arrays:setattr(model,name,np.array(arrays[name],copy=True))
    if problem=='allen_cahn':
        model.obs_indices=model.obs_indices_train
        model.obs_locations_train=jnp.asarray(model.obs_indices_train);model.obs_locations=model.obs_locations_train
        model.obs_locations_holdout=jnp.asarray(model.obs_indices_holdout)
    elif problem=='navier_stokes':
        model.obs_indices=model.obs_indices_train;model.obs_locations=jnp.asarray(model.obs_indices_train)
        model.holdout_locations=jnp.asarray(model.obs_indices_holdout)
    elif problem=='afwi':
        model.receiver_indices_jax=jnp.asarray(model.receiver_flat_indices)
        model.obs_indices_holdout_jax=jnp.asarray(model.obs_indices_holdout)
        model.model_support_mask=np.array(physical['mask'],copy=True);model.model_support_mask_jax=jnp.asarray(model.model_support_mask)
    elif problem=='helmholtz':
        model.receiver_indices_jax=jnp.asarray(model.receiver_flat_indices)
        model.holdout_receiver_indices_jax=jnp.asarray(model.holdout_receiver_flat_indices)
        model.support_mask=np.array(physical['mask'],copy=True);model.support_mask_jax=jnp.asarray(model.support_mask)
    if extra is not None:
        info,values,_=extra
        for name,value in values.items():setattr(model,name,value.copy() if info['kinds'][name]=='numpy' else jnp.asarray(value))
    model.true_field=np.array(physical['truth'],copy=True)


def _bind_prepared_target(batch,problem,model):
    import numpy as np
    import jax
    import jax.numpy as jnp
    from common import model_data,read_json,load_npz,settings,fingerprint,write_json
    if problem not in CONSTANTS:raise ValueError('No prepared-target adapter for '+problem)
    batch=Path(batch);directory=batch/'reference'/problem
    # Validate the completed preparation before touching any model globals.
    target,arrays=validate_prepared(batch,problem)
    with snapshot_lock(directory,write=True):
        # Recheck under the write lock to avoid concurrent legacy upgrades.
        if fingerprint(target['metadata'],load_npz(directory/'target_arrays.npz'))!=target['fingerprint']:
            raise ValueError('Target changed while acquiring snapshot lock')
        metadata,actual,before=model_data(problem,model,settings(batch)['data_seed'])
        if metadata!=target['metadata'] or int(getattr(model,'seed',-1))!=metadata['data_seed']:
            raise ValueError('Loaded model source/data seed/noise/grid/dimension differs from the prepared target')
        if set(actual)!=set(arrays) or any(actual[k].shape!=arrays[k].shape for k in arrays):
            raise ValueError('Loaded target array names/shapes differ from preparation')
        differences=[dict(array=k,saved_dtype=str(arrays[k].dtype),generated_dtype=str(actual[k].dtype),
                          max_abs_difference=float(np.max(np.abs(actual[k].astype(float)-arrays[k].astype(float)))))
                     for k in arrays if arrays[k].dtype!=actual[k].dtype or not np.array_equal(arrays[k],actual[k])]
        physical=load_npz(directory/'physical_spec.npz')
        if not np.array_equal(physical['basis'],arrays['basis']):raise ValueError('Physical and target bases differ')
        extra=_extra(directory,target,load=True)
        if extra is None:
            # Legacy snapshots did not save wave-source tensors. Their fixed
            # source geometry must still match before those tensors are used.
            for name in ['source_centers','receiver_coords']:
                if name in arrays and not np.array_equal(actual[name],arrays[name]):
                    raise ValueError('Legacy snapshot source geometry differs: '+name+'; a fresh preparation is required')
        _bind(model,problem,arrays,physical,extra)
        jax.clear_caches()  # Import-time jit traces may contain regenerated constants.
        meta2,restored,identity=model_data(problem,model,metadata['data_seed'])
        if meta2!=target['metadata'] or identity!=target['fingerprint']:
            raise ValueError('Restored target failed exact fingerprint verification')
        atol=max(2e-13,float(model.NOISE_STD)*1e-9)
        alpha=jnp.asarray(model.alpha_true_np)
        np.testing.assert_allclose(np.asarray(model.solve_forward(alpha)),arrays['y_clean_np'],rtol=2e-10,atol=atol)
        np.testing.assert_allclose(np.asarray(model.solve_forward_holdout(alpha)),arrays['y_holdout_clean_np'],rtol=2e-10,atol=atol)
        np.testing.assert_allclose(np.asarray(model.field_from_latent(model.alpha_true_np)),physical['truth'],rtol=2e-11,atol=2e-12)
        if extra is not None:
            probes=extra[2]
            for i,a in enumerate(probes['alpha']):
                np.testing.assert_allclose(np.asarray(model.solve_forward(jnp.asarray(a))),probes['train'][i],rtol=2e-10,atol=atol)
                np.testing.assert_allclose(np.asarray(model.solve_forward_holdout(jnp.asarray(a))),probes['holdout'][i],rtol=2e-10,atol=atol)
        setup=load_npz(directory/'setup.npz')
        if 'map_energy' in setup:
            position=jnp.asarray(setup['map_position']);residual=(model.solve_forward(position)-model.y_obs_np)/model.NOISE_STD
            energy=float(.5*jnp.vdot(position,position)+.5*jnp.vdot(residual,residual))
            np.testing.assert_allclose(energy,float(setup['map_energy']),rtol=2e-9,atol=2e-9)
        if extra is None:_write(directory,problem,model,metadata,identity,'legacy_target_verified_against_clean_data_and_saved_MAP')
        if before!=identity:print(f'[{problem}] Restored prepared target: '+str(differences),flush=True)
        write_json(batch/'logs'/f'target-snapshot-{problem}-{os.getpid()}-{time.time_ns()}.json',
                   dict(version=VERSION,prepared_fingerprint=identity,regenerated_fingerprint=before,
                        differences=differences,constants_origin='legacy' if extra is None else extra[0]['origin']))
        return identity


def bind_prepared_target(batch,problem,model):
    previous=getattr(model,'_gad_restoring_target',False)
    model._gad_restoring_target=True
    try:return _bind_prepared_target(batch,problem,model)
    finally:model._gad_restoring_target=previous
