# LS6 port validation — 27 October 2026

The starting archive is the final combined Frontera bundle, SHA256 `9f16251dede83e69aca440e7b15e0b6b0e2e3bf205d33142286cc2a248012308`. It includes the all-four-problem target-snapshot fix and the final Python-3.9/NumPy-2 isolation, pip-bootstrap and pinned diagnostics-wheel fixes. Parent documentation is retained under `provenance/parent_frontera` as historical evidence.

## Scope

LS6 modules/venv, cluster identity aliases, queue defaults, per-partition counting/caps, monitoring and user instructions are adapted to the supplied live LS6 transcript. Existing canonical model/sampler files, reference potential/MAP/NUTS/diagnostics code, comparison metrics, aggregation/plotting code and scientific settings are checked byte-for-byte against the parent archive. The package installer changes only the printed LS6 marker/comment; dependency behavior is retained. No GPU frameworks are upgraded or replaced automatically.

## Current checks

33 targeted checks passed: 18 incremental scheduler/reuse/queue-cap/cluster-alias tests; three installer tests; six frozen-repair tests; two status-before-first-submission/failed-plan tests; and four environment/annotation/protocol-identity checks. Actual Python 3.9 is used for installer/repair/status and annotation/environment checks; package/scheduler calls are mocked where no cluster exists. Python/shell syntax, documentation commands/links, source hashes, offline planning, ZIP CRC and the bundle manifest are checked. Numerical kernels did not change, so the earlier all-four-model and reduced Allen–Cahn end-to-end checks in the parent validation remain historical evidence; no fresh production mixing claim is made.

No jobs are submitted to LS6 during authoring. The provided package metadata does not establish CUDA functionality: allocated preflight checks both JAX and PyTorch GPU operations before scientific jobs. The published queue rates and supplied live limits inform configuration; actual runtime, queue waits and NUTS convergence remain production outcomes.
