"""The monitor must work when every task is deferred and jobs.json is absent."""
import contextlib
import io
from pathlib import Path
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import write_json
from workflow import freeze
from status_publication import inspect


class LS6StatusTests(unittest.TestCase):
    def test_fully_deferred_batch_without_job_ids(self):
        with tempfile.TemporaryDirectory() as temporary:
            batch=freeze(ROOT/'settings.json',Path(temporary)/'batch',['allen_cahn'])
            write_json(batch/'submission_plan.json',dict(partition='gpu-a100',partition_cap=28,cap=32,
                       failed_tasks=0,deferred_tasks=1,nodes=[dict(key='preflight',state='deferred',reason='Partition unavailable')]))
            out=io.StringIO()
            with contextlib.redirect_stdout(out):code=inspect(batch,scheduler=False)
            self.assertEqual(code,0)
            self.assertIn('PASS:',out.getvalue());self.assertIn('No accepted job IDs yet',out.getvalue())
            self.assertIn('Partition unavailable',out.getvalue())
            self.assertFalse((batch/'jobs.json').exists())

    def test_failed_plan_is_reported(self):
        with tempfile.TemporaryDirectory() as temporary:
            batch=freeze(ROOT/'settings.json',Path(temporary)/'batch',['allen_cahn'])
            write_json(batch/'submission_plan.json',dict(failed_tasks=1,nodes=[dict(key='chain-0',state='failed',reason='QA failure')]))
            out=io.StringIO()
            with contextlib.redirect_stdout(out):code=inspect(batch,scheduler=False)
            self.assertEqual(code,1);self.assertIn('chain-0 failed QA failure',out.getvalue())


if __name__=='__main__':unittest.main()
