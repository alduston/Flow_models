import sys,shutil,tempfile
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
import common
from target_snapshot import capture_preparation,EXTRA_FILES,CONSTANTS
from workflow import freeze
import jax,jax.numpy as jnp
with tempfile.TemporaryDirectory(prefix='gad-target-snapshot-qa-') as qa_root:
    for problem in ['allen_cahn','navier_stokes','helmholtz','afwi']:
     print('\nREAL MODEL:',problem,flush=True)
     parent=Path(qa_root)/problem;parent.mkdir(parents=True)
     config=common.read_json(root/'settings.json');config['active_problems']=[problem]
     configfile=parent/'config.json';common.write_json(configfile,config)
     batch=freeze(configfile,parent/'batch',[problem]);directory=batch/'reference'/problem
     model=common.load_model(problem,42,parent/'model')
     meta,arrays,identity=common.model_data(problem,model,42);physical=common.physical_spec(problem,model)
     common.write_json(directory/'target.json',dict(metadata=meta,fingerprint=identity));common.save_npz(directory/'target_arrays.npz',**arrays)
     common.save_npz(directory/'physical_spec.npz',**physical)
     zero=jnp.zeros(model.ACTIVE_DIM);res=(model.solve_forward(zero)-model.y_obs_np)/model.NOISE_STD
     energy=float(.5*jnp.vdot(zero,zero)+.5*jnp.vdot(res,res))
     common.save_npz(directory/'setup.npz',map_position=np.asarray(zero),map_energy=np.asarray(energy))
     common.write_json(directory/'setup.json',dict(fingerprint=identity,setup_sha256=common.digest(directory/'setup.npz')))
     capture_preparation(directory,problem,model,meta,identity)
     baseline_setup=common.digest(directory/'setup.npz');baseline_arrays=common.digest(directory/'target_arrays.npz')
     probe=np.random.default_rng(54).normal(0,.2,model.ACTIVE_DIM)
     expected=np.asarray(model.solve_forward(jnp.asarray(probe)))
     expected_holdout=np.asarray(model.solve_forward_holdout(jnp.asarray(probe)))
     # Perturb the numerical coordinates, observations, sampling indices and an
     # actual PDE/source constant. Compile the wrong forward map before repair.
     model.Basis=-model.Basis;model.y_obs_np=model.y_obs_np+1
     if hasattr(model,'obs_indices_train'):model.obs_indices_train=model.obs_indices_train[::-1].copy()
     if problem=='allen_cahn':model.IMEX_DENOM=model.IMEX_DENOM*.99
     if problem=='navier_stokes':model.forcing_hat=model.forcing_hat*1.01
     if problem=='helmholtz':model.source_terms_jax=model.source_terms_jax*1.1
     if problem=='afwi':model.source_patterns_jax=model.source_patterns_jax*1.1
     jax.clear_caches();wrong=np.asarray(model.solve_forward(jnp.asarray(probe)))
     assert not np.allclose(wrong,expected,rtol=1e-8,atol=1e-14)
     assert common.check_target(batch,problem,model)==identity
     np.testing.assert_allclose(np.asarray(model.solve_forward(jnp.asarray(probe))),expected,rtol=2e-10,atol=2e-13)
     np.testing.assert_allclose(np.asarray(model.solve_forward_holdout(jnp.asarray(probe))),expected_holdout,rtol=2e-10,atol=2e-13)
     gradient=np.asarray(jax.grad(lambda a:.5*jnp.vdot(a,a)+.5*jnp.sum(((model.solve_forward(a)-model.y_obs_np)/model.NOISE_STD)**2))(jnp.asarray(probe)))
     assert np.isfinite(gradient).all()
     assert common.digest(directory/'setup.npz')==baseline_setup and common.digest(directory/'target_arrays.npz')==baseline_arrays
     print('PASS: exact target, wrong JIT/PDE constants, forward/holdout and finite gradient; MAP/data unchanged',flush=True)
     model.seed=43
     try:common.check_target(batch,problem,model)
     except ValueError:pass
     else:raise AssertionError('wrong seed accepted')
     model.seed=42
     const=directory/'target_constants.npz';bytes_=const.read_bytes();const.write_bytes(bytes_+b'corrupt')
     try:common.check_target(batch,problem,model)
     except ValueError:pass
     else:raise AssertionError('corrupt constants accepted')
     const.write_bytes(bytes_)
     # Upgrade an older prepared target without altering its data or MAP.
     for name in EXTRA_FILES:(directory/name).unlink()
     if hasattr(model,'source_centers'):
      old=model.source_centers.copy();model.source_centers=old+.01
      try:common.check_target(batch,problem,model)
      except ValueError as exc:assert 'geometry' in str(exc)
      else:raise AssertionError('unverifiable legacy wave source accepted')
      model.source_centers=old
     model.Basis=-model.Basis;model.y_obs_np=model.y_obs_np+1
     assert common.check_target(batch,problem,model)==identity
     assert common.read_json(directory/'target_constants.json')['origin'].startswith('legacy')
     assert common.digest(directory/'setup.npz')==baseline_setup and common.digest(directory/'target_arrays.npz')==baseline_arrays
     print('PASS: rejects wrong seed/corrupt constants; compatible legacy snapshot upgraded safely',flush=True)
     print('DONE',problem,flush=True)
