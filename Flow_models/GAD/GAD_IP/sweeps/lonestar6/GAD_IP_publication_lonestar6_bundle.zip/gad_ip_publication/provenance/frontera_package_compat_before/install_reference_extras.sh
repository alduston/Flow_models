#!/bin/bash
# Preserve the known-working CUDA stacks; never install CPU JAX or replace PyTorch.
set -eo pipefail
GP_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$GP_ROOT/slurm/environment.sh"
GP_CONSTRAINTS="$(mktemp)"
trap 'rm -f "$GP_CONSTRAINTS"' EXIT
python - "$GP_CONSTRAINTS" <<'PY'
import importlib.metadata,sys
from pathlib import Path
names=['jax','jaxlib','torch','numpy','scipy','pandas','matplotlib','jax-cuda12-plugin','jax-cuda12-pjrt','jax-cuda13-plugin','jax-cuda13-pjrt']
rows=[]
for name in names:
    try: rows.append(name+'=='+importlib.metadata.version(name))
    except importlib.metadata.PackageNotFoundError: pass
Path(sys.argv[1]).write_text('\n'.join(rows)+'\n')
PY
GP_ISOLATE_DIAGNOSTICS="$(python -c 'import sys,numpy; print(int(sys.version_info < (3,10) and int(numpy.__version__.split(".")[0]) >= 2))')"
if [[ "$GP_ISOLATE_DIAGNOSTICS" == 1 ]]; then
  # ArviZ 0.17 requires NumPy <2; leave the working GPU environment untouched.
  python -m pip install -c "$GP_CONSTRAINTS" numpyro pypdf
  GP_DIAGNOSTICS_PYTHON="$(python -c 'from arviz_compat import diagnostics_python; print(diagnostics_python())')"
  GP_DIAGNOSTICS_VENV="$(dirname -- "$(dirname -- "$GP_DIAGNOSTICS_PYTHON")")"
  if [[ ! -x "$GP_DIAGNOSTICS_PYTHON" ]]; then
    python -m venv "$GP_DIAGNOSTICS_VENV"
  fi
  "$GP_DIAGNOSTICS_PYTHON" -m pip install 'numpy==1.26.4' 'scipy==1.13.1' 'arviz==0.17.1'
  export GP_DIAGNOSTICS_PYTHON
else
  GP_ARVIZ_SPEC="$(python -c 'import sys; print("arviz==0.17.1" if sys.version_info < (3,10) else "arviz>=0.18,<1")')"
  python -m pip install -c "$GP_CONSTRAINTS" numpyro "$GP_ARVIZ_SPEC" pypdf
fi
python "$GP_ROOT/check_environment.py" --imports-only
