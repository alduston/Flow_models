# Prepared-target snapshot and Frontera package repair

The latest Frontera revision also carries the final package fixes in [FRONTERA_PACKAGE_COMPAT.md](FRONTERA_PACKAGE_COMPAT.md). Run the installer once after extraction, then re-run the frozen-batch repair even if a previous target-only repair succeeded.

## What changed

The original adapter regenerated the KL/Fourier basis, synthetic observations and geometry in each process and required their fingerprint to exactly match preparation. The Colab Allen-Cahn run stopped at this check. Its traceback did not identify which array drifted. The same reconstruction/verification path is used by Navier-Stokes, Helmholtz and acoustic FWI, so both cluster bundles now fix all four cases.

Every NUTS chain, sampler repeat, reference summary and evaluation binds its model to the authenticated prepared arrays. New preparations additionally save `target_constants.npz`, `target_probes.npz` and `target_constants.json` on the actual model instance used for the MAP. The constants include the applicable time-stepping/forcing tensors, wave-source tensors, masks, background fields and operators. Import-time JAX traces are cleared so they cannot retain regenerated constants.

The exact target fingerprint, model source hash, data seed, dimensions, noise level, MAP checksum and MAP/target binding remain checked. Forward/held-out probes, physical-field consistency and the saved MAP energy are also verified. NUTS lengths/thresholds, particles, rounds and canonical checkpoint MALA are unchanged. Validation probes do not feed MAP initialization or the sampler RNG streams.

## Existing frozen batches require a one-time repair

Extract the updated ZIP over the existing main bundle directory. A new batch will automatically receive the fix. An existing batch continues to use its frozen `code/` until repaired: replacing the top-level ZIP alone does not fix already queued workers.

Stop the batch's submission watcher while it is polling, using its recorded PID/host as described in `SUBMISSION_WATCHER.md`. Let any currently running batch jobs finish. Then, from the newly extracted bundle directory and working environment:

```bash
python repair_target_snapshots.py --batch /absolute/path/to/existing_batch
```

The repair tool:

- Verifies the original frozen settings/source manifest and recognizes only the expected loader functions.
- Refuses to edit source while any recorded job in this batch is running/configuring/completing. Other batches' jobs are ignored.
- Holds eligible pending jobs during the edit, then releases only the holds it placed. Existing user/admin holds are preserved; job IDs are retained.
- Updates `code/common.py`, `code/cache.py`, `code/target_snapshot.py` and recognized Frontera compatibility files (`arviz_compat.py`, `diagnostics_worker.py`, `check_environment.py`, `install_reference_extras.sh`) together with their source-manifest binding. Unknown local compatibility customizations are rejected. Cluster settings, source model/sampler files, saved target/MAP, reference samples and repeat outputs stay in place.
- Backs up the old code and manifests under `repairs/TIMESTAMP/`, logs the change, and rolls back if the source commit fails. Applying the same repair twice is a no-op.

After a successful repair, restart the detached watcher:

```bash
nohup bash submit.sh --resume-batch /absolute/path/to/existing_batch \
  --retry-failed --watch \
  >> /absolute/path/to/submission.log 2>&1 < /dev/null &
echo "$!" > /absolute/path/to/submission.log.pid
hostname > /absolute/path/to/submission.log.host
disown
```

Use `--retry-failed` when the old target mismatch already failed jobs or cancelled their dependents. Completed valid work is retained. The flag permits one deliberate retry per failed task per invocation; it is not a loop that overrides scientific failures. A NUTS convergence failure still needs investigation and, if necessary, a new longer-reference configuration.

## Exact Frontera paths

After extracting the updated Frontera ZIP under `sweeps/frontera`:

```bash
cd /work2/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/sweeps/frontera/gad_ip_publication
source slurm/environment.sh
bash install_reference_extras.sh
GP_BATCH=../batches/gad_ip_frontera_20261027_v3
GP_DRIVER_LOG=../gad_ip_frontera_20261027_v3_submit.log
python repair_target_snapshots.py --batch "$GP_BATCH"
```

Use your actual batch name if it differs, then resume it with the detached watcher. The installer checks or repairs the diagnostics environment; it keeps the main GPU stack constrained.

## Vista/Colab batches

Use the Vista bundle and its repair script for Vista/Colab. This Frontera repair additionally expects the Frontera compatibility modules in frozen code. The offline option is reserved for stopped local test runners.

## Reusing older prepared targets

Existing `target.json`, `target_arrays.npz`, `physical_spec.npz` and `setup.npz` are retained byte-for-byte. On first use, the loader restores those arrays, verifies clean training/hold-out predictions, the physical truth field and saved MAP energy, then records the extra constants/probes as a legacy snapshot upgrade. For wave problems, source geometry that cannot be verified from an old snapshot is rejected explicitly rather than guessed.

Snapshot sidecars travel with prepared outputs during compatible batch reuse. Corrupt/partial sidecars are rejected. Different data/model/noise/grid settings still require a new scientific setup. Sampler seeds remain independent while all methods use the same prepared target.

## Validation commands

```bash
python -m unittest discover -s tests -v
python -m unittest discover -s vendor/screening/tests -v
# Optional real-model CPU checks for all four problems:
JAX_PLATFORMS=cpu JAX_ENABLE_X64=true python tests/check_target_snapshots.py
```

These are implementation/loader checks. Production NUTS mixing and GPU performance must still be assessed from the actual runs. The original Colab mismatch was not reproduced on the local CPU; the fix removes regeneration from the target definition rather than assuming a particular source of drift.
