# Validation — Frontera edition, 27 October 2026

No production Frontera or Vista jobs were submitted from this session. Frontera CUDA behavior, GPU memory use, elapsed time and long-reference mixing still require the compute-node preflight and actual jobs. Existing Vista jobs remain independent.

## Final Frontera package repair, 27 October 2026

The actual shared conversation and its standalone repair-2 payload were compared with the delivered ZIP. The later NumPy runtime/distribution detection helper and the final pip/wheel commands were absent. They are now merged; `FRONTERA_PACKAGE_COMPAT.md` records the exact working versions and migration instructions. The installer prints `numpy2-isolation-repair-3`.

Nine targeted tests pass on actual Python 3.9.25: three installer/isolation tests (with subcases for fresh/existing diagnostics venvs and divergent NumPy versions), plus six audited batch-repair tests. These verify that only diagnostics pip is bootstrapped before binary-only pinned installs, main pip retains stack constraints, errors propagate, and already-target-repaired batches receive the compatibility update while saved settings/MAPs and source integrity remain protected. All 15 incremental scheduler/reuse tests also passed under Python 3.12.14 (24 distinct targeted checks in total); the nine compatibility/repair tests passed on both Python 3.9 and 3.12. Pip and Slurm are simulated; no new GPU or full NUTS run is claimed in this package-only revision. Numerical model/sampler/reference files, SU defaults and existing scientific identities are unchanged.

## Prepared-target snapshot repair, 27 October 2026

- All four actual source models passed CPU checks with deliberately changed basis/observations/sensors and a wrong cached PDE/source constant. Rebinding restored the exact prepared fingerprint and forward/hold-out behavior, retained finite gradients, and preserved the saved target/MAP byte-for-byte. Wrong seeds, corrupt constant snapshots and unverifiable legacy wave-source geometry were rejected.
- New preparations capture source/PDE constants and truth/zero/prior-scale validation probes on the actual MAP model instance; older prepared targets can be upgraded after clean-data, physical-field and MAP-energy verification. Generic Darcy routines and strict production NUTS settings are unchanged.
- Four additional repair-tool tests cover pending-job holds/release, preserving existing manual holds, source-manifest update/idempotence, refusing running batches, rejecting altered frozen code, and rollback after commit failure. These use mocked scheduler calls; no remote jobs were modified.
- Frontera's NumPy-2/isolated-ArviZ support, Python-3.9 protocol backport, environment configuration, scheduler-cluster isolation and drained-queue handling are preserved from the attached Frontera ZIP. Both new loader/repair modules compile under the actual local Python 3.9 interpreter.
- Current verification: 38 publication/repair tests ran: 36 passed and two optional isolated-ArviZ tests skipped because no separate diagnostics interpreter was configured for this run. All 32 original screening tests passed on the shared unchanged screening source. The four migration tests also passed on the actual Python 3.9.25 interpreter; function recognition is normalized across Python 3.9/3.12 AST differences.
- A fresh reduced Allen-Cahn CPU pipeline completed preparation, two independent sampler seeds, four short NUTS chains, certification/reference summaries, both evaluations, all 14 figure families and the final verified results ZIP. The new preparation sidecars came from the actual MAP model. This used original model dimensions, 64 particles, two rounds, 30 warmup/80 draws and relaxed QA diagnostics only; production settings and reference thresholds were unchanged.
- The Colab GPU mismatch itself was not reproduced on CPU. The patch eliminates target regeneration from the worker target definition and records per-array differences instead of assuming which array drifted.


## Changes in this edition

- RTX partition; one node and one task; account DMS22021; gcc/9.1.0, python3/3.9.2 and the supplied persistent Python 3.9 venv. Defaults remain 12 hours per NUTS chain, one hour per standard job and 20 minutes for preflight. The watcher caps all local-cluster task slots at 32, below the supplied RTX MaxSubmit of 36.
- The planner queries partition availability and defers new submissions while RTX is drained/down/inactive, preserving cached results and local live IDs. Existing queue/allocation rejection recovery and watch refilling remain supported.
- Frozen batches record the scheduler cluster. Known cluster mismatches fail before submitting; donor live IDs are considered only on the same cluster. Completed scientific files remain eligible for existing compatibility checks across clusters.
- Python 3.9 protocol compatibility adds only `from __future__ import annotations`. The compatibility digest removes that exact line for protocol identity; all other bytes continue binding run compatibility. Original source hashes are retained and verified, including the normalized protocol; all numerical sampler/model files and the generic Darcy NUTS routines remain unchanged.
- Reference extras select ArviZ 0.17.1 on Python 3.9 because >=0.18 requires newer Python. Worker startup restores the legacy scipy.signal.gaussian import alias from scipy.signal.windows only for old ArviZ when needed, without replacing SciPy. The installed JAX/CUDA/PyTorch/NumPy/SciPy stack remains constrained during extras installation.
- Documentation uses the new sweeps/frontera extraction root, separate batches/logs, correctly resolved previous-output paths, detached nohup start/resume, PID/login-host tracking, monitoring, stop/retry and expansion to ten repeats.

## Earlier Frontera environment validation

**66 tests passed on actual CPython 3.9.25 with NumPy 2.0.2 in the sampler environment:** 34 publication/Frontera tests and 32 original screening tests. This includes real JAX/NumPyro CPU continuation with an interrupted chain matching uninterrupted draws exactly, actual ArviZ rank-Rhat/bulk-ESS/tail-ESS/MCSE APIs under SciPy 1.13, numerical comparison/uncertainty checks, and fake-scheduler recovery/reuse tests.

The original local Python 3.9 CPU environment uses NumPy 1.26.4, SciPy 1.13.1, pandas 2.2.3, Matplotlib 3.9.4, JAX/jaxlib 0.4.30, NumPyro 0.15.3, ArviZ 0.17.1 and pypdf 6.21.3. These are validation versions, not instructions to replace the user's working GPU stack. PyTorch/CUDA execution was not retested locally in this edition; the allocated production preflight checks both GPU frameworks.

New tests cover RTX/default allocation wiring, drain-to-up recovery, cross-cluster live-ID rejection with completed-output reuse, known wrong-cluster rejection before creating/submitting a batch, environment module selection, missing-venv errors, Python 3.9 syntax/runtime protocol import, exact legacy kernel digest preservation, and actual ArviZ diagnostics under SciPy 1.13.

The retained publication tests cover capped/recoverable submission, live-job deduplication, checksum/signature reuse, changed-only Helmholtz work, reference reuse after particle changes, missing-seed and five-to-ten expansion behavior, canonical raw-run import, paired uncertainty, distribution metrics, reference withdrawal after failed diagnostics, and actual NumPyro chunk restart equivalence.

Shell examples and scripts, documentation links, ZIP integrity and file manifest are checked before delivery. Historical figure renders, reduced numerical end-to-end evidence and prior Vista implementation checks are retained in provenance/VALIDATION_VISTA_LEGACY.md. Those are earlier evidence rather than newly executed Frontera production results.

## NumPy 2.0.2 installation repair

The user environment revealed an installer conflict not covered by the original NumPy-1 local test: Python 3.9 requires old ArviZ, while ArviZ 0.17.1 declares NumPy <2. The corrected installer retains the main GPU environment and uses a separate CPU ArviZ venv when Python <3.10 and NumPy >=2. It never bypasses dependency metadata or forces ArviZ into the incompatible main environment.

The diagnostic adapter supports the exact API subset used by this bundle (posterior from_dict, rank R-hat, bulk/tail ESS, mean MCSE). It invokes the actual ArviZ library in the isolated interpreter through numeric NPZ files, computes all four diagnostics once per posterior object and caches the arrays. Native diagnostic results and adapter results are checked for exact array equality; scalar, vector and matrix variables and the unchanged generic reference diagnostic routines are exercised. Scientific reference thresholds are unchanged.

The new local sampler-side test environment is Python 3.9.25, NumPy 2.0.2, SciPy 1.13.1, JAX/jaxlib 0.4.30 and NumPyro 0.15.3, with no ArviZ installed there. Its diagnostic interpreter uses the original NumPy-1/ArviZ environment. All checks pass with this split; after correcting a new test to initialize the adapter before importing the unchanged reference module, its complete test file was rerun successfully. The user's precise GPU-package versions and GPU execution remain checked by allocated preflight.
