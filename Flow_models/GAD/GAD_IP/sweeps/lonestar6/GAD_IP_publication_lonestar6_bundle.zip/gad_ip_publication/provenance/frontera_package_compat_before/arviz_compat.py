"""Use native ArviZ or its isolated diagnostic environment on Python 3.9/NumPy 2."""
import importlib.metadata
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types


def diagnostics_python():
    return Path(os.environ.get('GP_DIAGNOSTICS_PYTHON') or
                (str(Path(sys.prefix))+'_gad_diagnostics/bin/python'))


class _Posterior:
    def __init__(self,posterior,python):
        import numpy as np
        self.arrays={k:np.asarray(v) for k,v in posterior.items()}
        self.python=python
        self.results=None

    def metric(self,name,method):
        allowed={'rhat':{'rank'},'ess':{'bulk','tail'},'mcse':{'mean'}}
        if method not in allowed.get(name,set()):raise ValueError('Unsupported diagnostic method')
        if self.results is None:
            import numpy as np
            with tempfile.TemporaryDirectory(prefix='gad-arviz-') as temporary:
                source=Path(temporary)/'posterior.npz';dest=Path(temporary)/'diagnostics.npz'
                np.savez(source,**self.arrays)
                result=subprocess.run([str(self.python),'-I',str(Path(__file__).with_name('diagnostics_worker.py')),
                                       str(source),str(dest)],capture_output=True,text=True)
                if result.returncode:
                    raise RuntimeError('Isolated ArviZ diagnostics failed: '+result.stderr.strip())
                with np.load(dest,allow_pickle=False) as data:
                    self.results={k:data[k].copy() for k in data.files}
        prefix=name+'_'+method+'__'
        return {k:types.SimpleNamespace(values=self.results[prefix+k]) for k in self.arrays}


def _isolated_arviz():
    python=diagnostics_python()
    if not python.is_file():
        raise RuntimeError('Python 3.9 with NumPy 2 needs the isolated ArviZ environment. '
                           'Run bash install_reference_extras.sh; expected '+str(python))
    module=types.ModuleType('arviz')
    module.__version__='0.17.1 (isolated NumPy 1.26.4)'
    module.from_dict=lambda *,posterior:_Posterior(posterior,python)
    module.rhat=lambda data,method='rank':data.metric('rhat',method)
    module.ess=lambda data,method='bulk':data.metric('ess',method)
    module.mcse=lambda data,method='mean':data.metric('mcse',method)
    module.__gad_isolated__=True
    return module


def load_arviz():
    import numpy as np
    if sys.version_info<(3,10) and int(np.__version__.split('.')[0])>=2:
        current=sys.modules.get('arviz')
        if not getattr(current,'__gad_isolated__',False):sys.modules['arviz']=_isolated_arviz()
        return sys.modules['arviz']
    version=importlib.metadata.version('arviz')
    if tuple(int(v) for v in version.split('.')[:2]) < (0,18):
        # ArviZ 0.17 imports the old SciPy alias, removed in SciPy 1.13.
        # It is the very same Gaussian window function in its current module.
        import scipy.signal
        if not hasattr(scipy.signal,'gaussian'):
            scipy.signal.gaussian=scipy.signal.windows.gaussian
    import arviz
    return arviz
