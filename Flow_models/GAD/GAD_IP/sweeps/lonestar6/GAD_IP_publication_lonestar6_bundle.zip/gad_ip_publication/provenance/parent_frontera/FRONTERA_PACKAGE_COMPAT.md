# Frontera package compatibility: final working repair

This revision incorporates the last fixes from the [shared Frontera thread](https://chatgpt.com/share/6ae0f036-72c8-83e9-a2d0-5cbf322fd8d1), including the manual commands after `numpy2-isolation-repair-2`. The previous combined target-snapshot ZIP retained the initial diagnostics isolation but missed the later NumPy detection helper and pip/wheel bootstrap. The installer now prints `numpy2-isolation-repair-3`.

## Incorporated fixes

- Preserve the existing GPU environment, including NumPy 2.0.2, JAX/jaxlib, PyTorch, SciPy and CUDA packages. The main-environment extras installation remains constrained to installed stack versions.
- On Python 3.9, check both loaded NumPy and installed distribution metadata before deciding whether ArviZ needs isolation. This carries forward `needs_isolated_arviz()` from the standalone repair-2 script.
- Use the separate `<GPU-venv>_gad_diagnostics` CPU environment for ArviZ. Upgrade its pip to **25.3 before resolving dependencies**, even when that environment already exists.
- Install only binary wheels for the working set: NumPy 1.26.4, SciPy 1.13.1, pandas 2.2.3, Matplotlib 3.9.4, xarray 2024.7.0, xarray-einstats 0.7.0 and ArviZ 0.17.1. This avoids the old pip selecting a pandas source build that failed under the cluster compiler.
- Retain the SciPy Gaussian-window compatibility alias, actual ArviZ rank-Rhat/ESS/MCSE checks, Python-3.9 annotations fix, cluster-local job identities and drained-partition deferral.

All problem definitions, sampler settings, NUTS lengths/thresholds, timing defaults and completed scientific outputs are retained.

## Apply to the existing Frontera campaign

Stop the batch's submission watcher on its recorded login host. Let running batch jobs finish before changing frozen code. The repair holds eligible pending jobs and preserves job IDs, completed work and saved MAPs. Then:

```bash
(
set -e
cd /work2/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/sweeps/frontera
unzip -qo GAD_IP_publication_frontera_bundle.zip
cd gad_ip_publication
source slurm/environment.sh

# Idempotent: repairs a missing/partial diagnostics installation and checks APIs.
bash install_reference_extras.sh

GP_BATCH=../batches/gad_ip_frontera_20261027_v3
GP_DRIVER_LOG=../gad_ip_frontera_20261027_v3_submit.log

if [[ -f "$GP_BATCH/batch.json" ]]; then
    python repair_target_snapshots.py --batch "$GP_BATCH"
    GP_ARGS=(--resume-batch "$GP_BATCH" --retry-failed --watch)
else
    GP_ARGS=(--batch "$GP_BATCH" --reuse-from ../../../batches
             --import-runs ../../.. --repeats 5 --watch)
fi

nohup bash submit.sh "${GP_ARGS[@]}" \
    >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown
tail -n 30 "$GP_DRIVER_LOG"
)
```

Run the installer successfully before launching the watcher. Use your actual batch name if different. Re-run the updated `repair_target_snapshots.py` even if the earlier target-only repair succeeded: it now also updates recognized Frontera compatibility files in frozen `code/`, records the source manifest and backs up every changed file. It refuses running batches and unknown local compatibility customizations. No separate old NumPy repair script is required.

The Vista bundle needs no change for this Python-3.9-specific package correction. Use Vista's own repair script for Vista/Colab batches.

## Verification

The targeted regression checks run on actual Python 3.9.25. They exercise mismatched loaded/distribution NumPy versions, installer ordering and exact wheel pins for fresh/existing diagnostics environments, upgrade failure propagation, and migration of frozen batches already repaired for target snapshots. Scheduler and pip calls are simulated in these targeted tests; no cluster jobs or user environments are changed during authoring. Earlier numerical tests remain recorded in `VALIDATION.md` because numerical kernels are unchanged.
