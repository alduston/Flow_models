"""Artifact compatibility and conservative reuse across publication batches."""
import copy
import csv
import ast
import os
from dataclasses import asdict
from pathlib import Path
import shutil
import time
from zipfile import BadZipFile

from common import (ROOT, SCREEN, digest, fingerprint, load_npz, problem_config, read_json,
                    run_directory, sampler_settings, save_npz, screen_imports, settings,
                    signature, verified_reference, write_json)

KERNEL_FILES=['sampling.py','protocol.py','mala_checkpoints.py','evaluate.py','state_metrics.py']
PREPARED=['target.json','target_arrays.npz','physical_spec.npz','model_derivative_check.json','setup.npz','setup.json']
REF_OUTPUTS=['reference_samples.npz','reference_samples_uncertified.npz','nuts_diagnostics.json',
             'nuts_parameter_diagnostics.csv','chain_diagnostics.npz']
SUMMARY_OUTPUTS=['reference_summary.npz','geometry.npz','sampling_floors.npz','summary.json']


def target_key(config,problem,code=ROOT):
    return signature(dict(data_seed=config['data_seed'],model_sha256=digest(Path(code)/'vendor/screening/models'/f'{problem}.py'),
                          potential_sha256=digest(Path(code)/'reference.py')))


def run_key(config,problem,seed,code=ROOT):
    return signature(dict(target=target_key(config,problem,code),seed=seed,
                          settings=asdict(sampler_settings(config,problem)),
                          kernel={name:kernel_digest(Path(code)/'vendor/screening'/name) for name in KERNEL_FILES}))


def kernel_digest(path):
    # The sole protocol backport postpones evaluation of `int | None` on
    # Python 3.9. Normalize only that exact import; all other bytes still bind
    # compatibility, retaining historical sampler results after this backport.
    path=Path(path)
    if path.name=='protocol.py':
        import hashlib
        data=path.read_bytes().replace(b'from __future__ import annotations\n',b'',1)
        return hashlib.sha256(data).hexdigest()
    return digest(path)


def reference_key(config,problem,code=ROOT):
    return signature(dict(target=target_key(config,problem,code),nuts=config['nuts'],
                          core=digest(Path(code)/'reference_core.py')))


def summary_key(config,problem,code=ROOT):
    return signature(dict(algorithm=evaluation_algorithm_key(code),evaluation=config['evaluation'],particles=config['problems'][problem]['particles'],
                          heldout_batch=config['sampler']['heldout_batch']))


def evaluation_key(batch,problem,seed):
    batch=Path(batch);c=settings(batch);d=batch/'reference'/problem
    r=read_json(d/'summary.json');q=read_json(d/'nuts_diagnostics.json')
    return signature(dict(schema=2,algorithm=evaluation_algorithm_key(batch/'code'),run=run_key(c,problem,seed,batch/'code'),reference=q['reference_sha256'],
                          summary=r['summary_sha256'],geometry=r['geometry_sha256'],evaluation=c['evaluation'],
                          cap=c['sampler']['eval_particles'],batch_size=c['sampler']['heldout_batch']))


def evaluation_algorithm_key(code):
    tree=ast.parse((Path(code)/'comparison.py').read_text())
    for node in tree.body:
        if isinstance(node,ast.FunctionDef) and node.name=='evaluate_repeat':
            node.body=[s for s in node.body if not (
                isinstance(s,ast.ImportFrom) and s.module=='cache' or
                isinstance(s,ast.Expr) and isinstance(s.value,ast.Call) and isinstance(s.value.func,ast.Name) and s.value.func.id=='write_json'
                and s.value.args and 'publication_identity.json' in ast.unparse(s.value.args[0]))]
    return signature(ast.dump(tree))


def prepared_valid(batch,problem):
    try:
        batch=Path(batch);out=batch/'reference'/problem;config=settings(batch)
        info=read_json(out/'setup.json');target=read_json(out/'target.json')
        if info['setup_sha256']!=digest(out/'setup.npz'):return False
        if target['metadata']['data_seed']!=config['data_seed']:return False
        if target['metadata']['model_sha256']!=digest(batch/'code/vendor/screening/models'/f'{problem}.py'):return False
        if fingerprint(target['metadata'],load_npz(out/'target_arrays.npz'))!=target['fingerprint']:return False
        from target_snapshot import validate_prepared  # target-snapshot-1
        validate_prepared(batch,problem)
        return all((out/name).is_file() for name in PREPARED)
    except (OSError,ValueError,KeyError,TypeError,BadZipFile,EOFError):return False


def chain_valid(batch,problem,index):
    try:
        batch=Path(batch);out=batch/'reference'/problem;c=settings(batch);setup=read_json(out/'setup.json')
        target=read_json(out/'target.json');path=out/'chains'/f'chain_{index}.npz';record=read_json(path.with_suffix('.json'))
        if record['identity']!=signature(dict(target=target['fingerprint'],setup=setup['setup_sha256'])):return False
        if digest(path)!=record['sha256']:return False
        import numpy as np
        values=load_npz(path)
        return values['samples'].shape==(c['nuts']['num_samples'],target['metadata']['dimension']) and np.isfinite(values['samples']).all()
    except (OSError,ValueError,KeyError,TypeError,BadZipFile,EOFError):return False


def reference_valid(batch,problem):
    try:verified_reference(batch,problem);return True
    except (OSError,ValueError,KeyError,TypeError,BadZipFile,EOFError):return False


def summary_valid(batch,problem):
    try:
        if not reference_valid(batch,problem):return False
        out=Path(batch)/'reference'/problem;r=read_json(out/'summary.json');q=read_json(out/'nuts_diagnostics.json')
        if r['reference_sha256']!=q['reference_sha256']:return False
        if r.get('compatibility_key')!=summary_key(settings(batch),problem,Path(batch)/'code'):return False
        return all(digest(out/name)==r[key] for name,key in [('reference_summary.npz','summary_sha256'),('geometry.npz','geometry_sha256'),('sampling_floors.npz','floor_sha256')])
    except (OSError,ValueError,KeyError,TypeError,BadZipFile,EOFError):return False


def run_valid(batch,problem,seed):
    try:
        batch=Path(batch);d=run_directory(batch,problem,seed);c=settings(batch)
        r=read_json(d/'repeat_identity.json');e=read_json(d/'experiment_config.json')
        if read_json(d/'status.json')['state']!='complete':return False
        if e.get('settings')!=asdict(sampler_settings(c,problem)):return False
        if e.get('sampler_seed',e.get('seed'))!=seed or e.get('data_seed',e.get('seed'))!=c['data_seed']:return False
        if e['sampling_sha256']!=digest(batch/'code/vendor/screening/sampling.py'):return False
        if e['model_sha256']!=digest(batch/'code/vendor/screening/models'/f'{problem}.py'):return False
        if r['samples_sha256']!=digest(d/'samples_all_rounds.npz'):return False
        if (batch/'reference'/problem/'target.json').exists() and r['fingerprint']!=read_json(batch/'reference'/problem/'target.json')['fingerprint']:return False
        screen_imports();from protocol import output_labels
        labels=set(output_labels(sampler_settings(c,problem)));rows=read_json(d/'metrics.json')
        if set(rows)!=labels:return False
        return all(rows[label].get('finite_fraction')==1 and rows[label].get('heldout_predictive_finite_fraction')==1 for label in labels)
    except (OSError,ValueError,KeyError,TypeError,BadZipFile,EOFError):return False


def evaluation_valid(batch,problem,seed):
    try:
        if not run_valid(batch,problem,seed) or not summary_valid(batch,problem):return False
        d=run_directory(batch,problem,seed);r=read_json(d/'publication_identity.json')
        if r.get('evaluation_key')!=evaluation_key(batch,problem,seed):return False
        return all(digest(d/name)==r[key] for name,key in [('publication_metrics.json','metrics_sha256'),('publication_fields.npz','fields_sha256'),('publication_predictives.npz','predictive_sha256')])
    except (OSError,ValueError,KeyError,TypeError,BadZipFile,EOFError):return False


def copy_file(source,destination):
    destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
    temp=destination.with_name(destination.name+f'.import-{time.time_ns()}')
    shutil.copy2(source,temp);temp.replace(destination)


def source_batches(paths,batch):
    found=[];batch=Path(batch).resolve()
    for raw in paths:
        p=Path(raw).resolve()
        candidates=[p] if (p/'batch.json').exists() else [x.parent for x in p.glob('*/batch.json')]
        for x in sorted(candidates):
            if x!=batch and (x/'settings.json').exists() and (x/'code/reference.py').exists() and x not in found:found.append(x)
    return found


def compatible_sources(batch,problem,paths,kind='reference'):
    c=settings(batch);key=reference_key if kind=='reference' else target_key
    expected=key(c,problem,Path(batch)/'code')
    result=[]
    for src in source_batches(paths,batch):
        try:
            old=settings(src)
            if problem in old['problems'] and key(old,problem,src/'code')==expected:result.append(src)
        except (OSError,ValueError,KeyError):continue
    return result


def adopt_reference(batch,problem,sources,chain_indices=None,include_reference=True):
    """Copy only validated immutable outputs; never modify or symlink a donor."""
    batch=Path(batch);out=batch/'reference'/problem;adopted=[]
    for src in sources:
        previous=src/'reference'/problem
        if not prepared_valid(batch,problem) and prepared_valid(src,problem):
            for name in PREPARED:copy_file(previous/name,out/name)
            from target_snapshot import EXTRA_FILES
            for name in EXTRA_FILES:
                if (previous/name).exists():copy_file(previous/name,out/name)
                elif (out/name).exists():
                    archive=batch/'failed_attempts'/'target_constants'/problem/str(time.time_ns())
                    archive.mkdir(parents=True,exist_ok=True);shutil.move(str(out/name),str(archive/name))
            adopted.append(dict(kind='prepared',source=str(src)))
        if not prepared_valid(batch,problem):continue
        # Different MAP setups can target the same posterior but their whitened
        # chain checkpoints cannot be combined. Adopt only one setup geometry.
        if not prepared_valid(src,problem) or read_json(previous/'setup.json')['setup_sha256']!=read_json(out/'setup.json')['setup_sha256']:continue
        for i in (range(settings(batch)['nuts']['num_chains']) if chain_indices is None else chain_indices):
            if not chain_valid(batch,problem,i) and chain_valid(src,problem,i):
                for ext in ['.npz','.json']:copy_file(previous/'chains'/f'chain_{i}{ext}',out/'chains'/f'chain_{i}{ext}')
                adopted.append(dict(kind=f'chain-{i}',source=str(src)))
            checkpoint=previous/'checkpoints'/f'chain_{i}';destination=out/'checkpoints'/f'chain_{i}'
            if checkpoint.exists() and not destination.exists() and not chain_valid(batch,problem,i):
                shutil.copytree(checkpoint,destination);adopted.append(dict(kind=f'checkpoint-{i}',source=str(src)))
        if include_reference and not reference_valid(batch,problem) and reference_valid(src,problem):
            for name in REF_OUTPUTS:
                if (previous/name).exists():copy_file(previous/name,out/name)
            adopted.append(dict(kind='certified-reference',source=str(src)))
        if include_reference and not summary_valid(batch,problem) and reference_valid(batch,problem) and summary_key(settings(src),problem,src/'code')==summary_key(settings(batch),problem,Path(batch)/'code'):
            try:
                r=read_json(previous/'summary.json');q=read_json(out/'nuts_diagnostics.json')
                if r['reference_sha256']!=q['reference_sha256']:continue
                if not all(digest(previous/name)==r[key] for name,key in [('reference_summary.npz','summary_sha256'),('geometry.npz','geometry_sha256'),('sampling_floors.npz','floor_sha256')]):continue
                for name in SUMMARY_OUTPUTS:copy_file(previous/name,out/name)
                record=read_json(out/'summary.json');record['compatibility_key']=summary_key(settings(batch),problem,Path(batch)/'code');write_json(out/'summary.json',record)
                adopted.append(dict(kind='reference-summary',source=str(src)))
            except (OSError,ValueError,KeyError):continue
    return adopted


def adopt_run(batch,problem,seed,sources):
    if run_valid(batch,problem,seed):return None
    batch=Path(batch);c=settings(batch);expected=run_key(c,problem,seed,batch/'code')
    for src in sources:
        try:
            if run_key(settings(src),problem,seed,src/'code')!=expected or not run_valid(src,problem,seed):continue
            donor=run_directory(src,problem,seed);dest=run_directory(batch,problem,seed)
            target=batch/'reference'/problem/'target.json'
            if target.exists() and read_json(donor/'repeat_identity.json')['fingerprint']!=read_json(target)['fingerprint']:continue
            temp=dest.with_name(dest.name+f'.import-{time.time_ns()}');temp.parent.mkdir(parents=True,exist_ok=True)
            shutil.copytree(donor,temp,ignore=shutil.ignore_patterns('publication_model','data','__pycache__'))
            if dest.exists():
                archived=batch/'failed_attempts'/problem/f'{dest.name}_{time.time_ns()}'
                archived.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(dest),str(archived))
            temp.replace(dest)
            write_json(dest/'import_provenance.json',dict(source=str(donor),run_key=expected))
            # v1 evaluations predate the explicit evaluation signature. Adopt
            # them only if their complete numerical AST, reference summary,
            # geometry and all saved output hashes match this campaign.
            try:
                identity=read_json(dest/'publication_identity.json')
                old_summary=read_json(src/'reference'/problem/'summary.json')
                new_summary=read_json(batch/'reference'/problem/'summary.json')
                same=evaluation_algorithm_key(src/'code')==evaluation_algorithm_key(batch/'code')
                same=same and old_summary['reference_sha256']==new_summary['reference_sha256']
                same=same and all(old_summary[k]==new_summary[k] for k in ['summary_sha256','geometry_sha256'])
                same=same and settings(src)['evaluation']==c['evaluation']
                same=same and identity['reference_sha256']==new_summary['reference_sha256']
                same=same and all(digest(dest/name)==identity[k] for name,k in [('publication_metrics.json','metrics_sha256'),('publication_fields.npz','fields_sha256'),('publication_predictives.npz','predictive_sha256')])
                if same:
                    identity['evaluation_key']=evaluation_key(batch,problem,seed);write_json(dest/'publication_identity.json',identity)
            except (OSError,KeyError,ValueError):pass
            return dict(kind='sampler-run',problem=problem,seed=seed,source=str(donor))
        except (OSError,ValueError,KeyError):continue
    return None


def screening_candidates(directories,batch):
    """Find raw outputs while skipping model data, snapshots and old attempts."""
    batch=Path(batch).resolve()
    skip={'code','vendor','data','failed_attempts','previous_reports','__pycache__','.git','.venv','venvs'}
    for raw in directories:
        for root,dirs,files in os.walk(Path(raw).resolve()):
            parent=Path(root)
            if parent==batch or batch in parent.parents:
                dirs[:]=[];continue
            dirs[:]=[d for d in dirs if d not in skip and not d.startswith('.')]
            if 'experiment_config.json' in files:
                yield parent/'experiment_config.json'
                dirs[:]=[]


def import_screening_run(batch,problem,seed,directories):
    """Import full raw canonical screening output, never a dashboard/CSV alone.

    Exact settings are required except a longer checkpoint trajectory may be
    truncated after verifying identical GAD configurations and MALA prefixes.
    Actual metadata seeds take precedence over the directory's name.
    """
    import numpy as np
    batch=Path(batch);c=settings(batch);dest=run_directory(batch,problem,seed)
    if run_valid(batch,problem,seed) or not prepared_valid(batch,problem):return None
    target=read_json(batch/'reference'/problem/'target.json');data=load_npz(batch/'reference'/problem/'target_arrays.npz')
    screen_imports();from protocol import Settings,make_protocol,output_labels,comparison_labels
    wanted=sampler_settings(c,problem);labels=set(output_labels(wanted))
    for path in screening_candidates(directories,batch):
        try:
            donor=path.parent;e=read_json(path)
            if (donor/'status.json').exists() and read_json(donor/'status.json').get('state')!='complete':continue
            if (donor/'repeat_identity.json').exists() and read_json(donor/'repeat_identity.json').get('samples_sha256')!=digest(donor/'samples_all_rounds.npz'):continue
            if e.get('problem')!=problem or e.get('sampler_seed',e.get('seed'))!=seed or e.get('data_seed',e.get('seed'))!=c['data_seed']:continue
            if e['sampling_sha256']!=digest(SCREEN/'sampling.py') or e['model_sha256']!=digest(SCREEN/'models'/f'{problem}.py') or e.get('mala_checkpoint_sha256')!=digest(SCREEN/'mala_checkpoints.py'):continue
            values=copy.deepcopy(e['settings']);rounds=values.pop('rounds');desired=asdict(wanted);desired.pop('rounds')
            if values!=desired or rounds<wanted.rounds or e['settings']['mala_mode']!='checkpoints':continue
            older=Settings(**e['settings']);new_protocol,new_budget=make_protocol(wanted);old_protocol,old_budget=make_protocol(older)
            if any(old_protocol[k]!=new_protocol[k] for k in new_protocol if k.startswith('GAD-')):continue
            if old_budget['mala_checkpoints'][:wanted.rounds]!=new_budget['mala_checkpoints']:continue
            realized=load_npz(donor/'realization.npz')
            pairs={'alpha_true':'alpha_true_np','y_obs':'y_obs_np','y_clean':'y_clean_np','y_holdout_obs':'y_holdout_obs_np','basis':'basis'}
            if not all(np.array_equal(realized[a],data[b]) for a,b in pairs.items()):continue
            clouds=load_npz(donor/'samples_all_rounds.npz');metrics=read_json(donor/'metrics.json')
            if not labels.issubset(clouds) or not labels.issubset(metrics):continue
            if any(clouds[k].shape!=(wanted.particles,target['metadata']['dimension']) or not np.isfinite(clouds[k]).all() or metrics[k].get('finite_fraction')!=1 or metrics[k].get('heldout_predictive_finite_fraction')!=1 for k in labels):continue
            if any(metrics[k].get('mala_acceptance_rate',0)<=0 for k in labels if k.startswith('MALA')):continue
            temp=dest.with_name(dest.name+f'.import-{time.time_ns()}');temp.parent.mkdir(parents=True,exist_ok=True)
            shutil.copytree(donor,temp,ignore=shutil.ignore_patterns('publication_*','publication_model','data','__pycache__','mala_checkpoints','*.png','*.pdf','*.svg','*.html'))
            for filename in ['samples_all_rounds.npz','gad_samples.npz','state_summaries.npz','field_summaries.npz']:
                if (temp/filename).exists():
                    arrays=load_npz(temp/filename);save_npz(temp/filename,**{k:v for k,v in arrays.items() if k in labels or k=='truth'})
            for filename in ['run_info.json','gad_run_info.json','ess_logs.json','evaluation_details.json']:
                if (temp/filename).exists():write_json(temp/filename,{k:v for k,v in read_json(temp/filename).items() if k in labels})
            chosen={k:metrics[k] for k in sorted(labels)};write_json(temp/'metrics.json',chosen)
            keys=['method']+sorted({k for row in chosen.values() for k in row})
            with (temp/'metrics.csv').open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(dict(method=k,**v) for k,v in chosen.items())
            comparisons=temp/'round_comparisons.csv'
            if comparisons.exists():
                with comparisons.open(newline='') as f:
                    reader=csv.DictReader(f);columns=reader.fieldnames;kept=[row for row in reader if int(row['last_round'])<=wanted.rounds]
                with comparisons.open('w',newline='') as f:
                    writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader();writer.writerows(kept)
            e.update(settings=asdict(wanted),data_seed=c['data_seed'],sampler_seed=seed,seed=seed,target_fingerprint=target['fingerprint'],protocol=new_protocol,budget=new_budget,expected_outputs=sorted(labels),comparison_methods=comparison_labels(labels),evaluated_rounds=list(range(1,wanted.rounds+1)))
            write_json(temp/'experiment_config.json',e);write_json(temp/'status.json',dict(state='complete',problem=problem,seed=seed,imported=True))
            write_json(temp/'repeat_identity.json',dict(fingerprint=target['fingerprint'],samples_sha256=digest(temp/'samples_all_rounds.npz'),data_seed=c['data_seed'],sampler_seed=seed))
            write_json(temp/'import_provenance.json',dict(source=str(donor.resolve()),original_rounds=rounds,retained_rounds=wanted.rounds,verification='exact realized target arrays; source hashes; transport configs; MALA work-prefix equality'))
            if dest.exists():
                archived=batch/'failed_attempts'/problem/f'{dest.name}_{time.time_ns()}';archived.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(dest),str(archived))
            temp.replace(dest)
            return dict(kind='screening-run',problem=problem,seed=seed,source=str(donor.resolve()),retained_rounds=wanted.rounds)
        except (OSError,ValueError,KeyError,TypeError,BadZipFile,EOFError):continue
    return None
