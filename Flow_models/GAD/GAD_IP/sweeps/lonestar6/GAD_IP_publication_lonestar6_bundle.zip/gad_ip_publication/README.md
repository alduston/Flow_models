# GAD publication bundle — Lonestar6

Start with [RUN_ON_LONESTAR6.md](RUN_ON_LONESTAR6.md). This is a new LS6 campaign built from the final Frontera package/target repair. Existing Vista and Frontera batches provide compatible completed outputs; their live job IDs are not reused across clusters.

Extract the ZIP under `GAD/GAD_IP/sweeps/lonestar6/`. The archive contains `gad_ip_publication/`; batches and watcher logs sit beside that folder. The examples use the existing shared repository under `/work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP`; adjust that repository prefix if needed.

## Defaults

| Setting | Default |
| --- | --- |
| Cluster/account | `ls6`, `DMS22021` |
| Queue | `gpu-a100` |
| Modules | `gcc/11.2.0`, `python3/3.9.7` |
| Existing GPU venv | `/work/10812/ald4435/ls6/venvs/flow_ls6_py39` |
| NUTS chain time | 12 hours |
| Other scientific/report jobs | 1 hour |
| Preflight | 20 minutes |
| Initial independent repeats | 5, seeds 42–46; expand to 10, seeds 42–51 |
| Data seed | 42, fixed across all sampler repeats |

Navier–Stokes and Allen–Cahn use 1,000 particles and five rounds; Helmholtz uses 2,000 and five rounds. Acoustic FWI remains an explicit reserve at 300 particles/four rounds. Canonical GAD/checkpoint MALA, strict four-chain NUTS (3,000 warmup/5,000 retained each), reference checks and publication PDF/SVG/600-dpi PNGs are preserved. [METHODS_AND_OUTPUTS.md](METHODS_AND_OUTPUTS.md) describes all metrics and outputs.

## LS6 submission caps

The live limits you supplied are recorded in `settings.json`. The watcher counts all your local queued/running tasks and enforces both a global cap of 32 and a selected-partition cap:

| Queue | Watcher cap | Supplied MaxSubmit | Supplied MaxJobsPU | Published SU/node-hour |
| --- | ---: | ---: | ---: | ---: |
| `gpu-a100` | 28 | 32 | 8 | 3 |
| `gpu-a100-small` | 10 | 12 | 3 | 1.5 |
| `gpu-a100-dev` | 2 | 3 | 1 | 3 |
| `gpu-h100` | 4 | 4 | 1 | 6 |

Partition counts include your unrelated jobs and jobs requesting multiple partitions. Unknown queue labels are counted conservatively. Slurm enforces running/node limits. `--max-outstanding-tasks` changes the global cap but cannot bypass a configured partition cap. Partition unavailability, prerequisites, balance rejection and task limits cause deferral; accepted IDs are retained. There is no reliable queue-start estimate from pending-job counts alone.

One node/task and one visible GPU per process are retained from the working scripts. No `--gres`, memory request, node pinning or `--export` is added; your live LS6 partition configuration reports null GRES. GPU execution is verified by the allocated preflight before scientific dependencies run.

## Environment

`install_reference_extras.sh` prints `gad-ls6-reference-extras-1`. It keeps installed JAX/jaxlib, PyTorch, NumPy, SciPy and plotting packages constrained while adding reference extras. Python 3.9/NumPy 2 uses a separate CPU ArviZ environment at `<GPU-venv>_gad_diagnostics`; its pip is bootstrapped to 25.3 and the final working binary-wheel set is pinned. No packages are installed inside Slurm jobs. CUDA plugin packages being absent from metadata does not establish GPU support; the compute-node preflight will test the actual installed frameworks. A failed GPU preflight requires inspecting its log, rather than silently using CPU or replacing the GPU stack.

## Monitoring and reuse

Use `bash check_status.sh --check-packages` after launch and `bash check_status.sh` for subsequent checks. It verifies frozen source bindings, summarizes deferral reasons and handles an absent `jobs.json` before the first successful submission. [SUBMISSION_WATCHER.md](SUBMISSION_WATCHER.md) covers resume, stop/retry and expansion. [TARGET_SNAPSHOT_FIX.md](TARGET_SNAPSHOT_FIX.md) describes fixed-target handling. [VALIDATION.md](VALIDATION.md) records actual checks.

A fresh five-repeat campaign has 50 tasks and reserves 181.33 node-hours before reuse: approximately 544 SUs on full A100 nodes, or 1,088 on H100, excluding other project commitments. These are full wall-limit reservations, not runtime predictions. No SU total is guaranteed by the submitted limits. References/chains, repeats and evaluations are reused individually after signatures/checksums pass; scientific changes require a new batch. Identical seeds across clusters remain duplicate experiments, not additional independent repeats.

Official references: [LS6 guide](https://docs.tacc.utexas.edu/hpc/lonestar6/), [Slurm sinfo](https://slurm.schedmd.com/sinfo.html). Live `qlimits` takes precedence over published queue tables. The supplied output reports both main GPU partitions UP; the A100 apparent idle node is also reported reserved, so immediate scheduling is not assumed.
