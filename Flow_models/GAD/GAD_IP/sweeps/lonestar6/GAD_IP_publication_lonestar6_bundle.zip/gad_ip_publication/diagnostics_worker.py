"""Actual ArviZ calculations in the separate NumPy-1 environment; no GPU imports."""
import sys
import numpy as np
import scipy.signal

if not hasattr(scipy.signal,'gaussian'):
    scipy.signal.gaussian=scipy.signal.windows.gaussian
import arviz as az


def main():
    with np.load(sys.argv[1],allow_pickle=False) as data:
        posterior={k:data[k] for k in data.files}
    inference=az.from_dict(posterior=posterior)
    arrays={}
    for name,method in [('rhat','rank'),('ess','bulk'),('ess','tail'),('mcse','mean')]:
        result=getattr(az,name)(inference,method=method)
        for key in posterior:arrays[name+'_'+method+'__'+key]=np.asarray(result[key].values)
    np.savez(sys.argv[2],**arrays)


if __name__=='__main__':main()
