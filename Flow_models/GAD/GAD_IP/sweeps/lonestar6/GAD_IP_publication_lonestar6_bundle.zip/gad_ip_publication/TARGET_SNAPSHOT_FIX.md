# Prepared-target handling in the LS6 bundle

Every NUTS chain, repeat, reference summary and evaluation binds to the authenticated prepared basis, observations and geometry. New preparations also save PDE/source constants and validation probes. JAX caches are cleared after rebinding. Strict fingerprints, source/seed/noise/grid checks, saved MAP checks and validation probes are retained for acoustic FWI, Allen–Cahn, Navier–Stokes and Helmholtz. This is the tested target fix from the parent bundle; no model/sampler kernel is changed in the LS6 port.

Create a new LS6 batch using [RUN_ON_LONESTAR6.md](RUN_ON_LONESTAR6.md). Completed Vista/Frontera work is eligible for signature/checksum reuse. Other-cluster job IDs cannot become dependencies. Legacy prepared targets may be upgraded with constant sidecars only after their forward/holdout, physical-field and MAP-energy checks pass.

The included `repair_target_snapshots.py` is retained for known older LS6 snapshots. It verifies frozen sources, backs up changes, holds eligible pending jobs and refuses running batches or unknown compatibility customizations. It updates only recognized target-loader/package files and source-manifest bindings, preserving saved scientific outputs. Run from the complete extracted LS6 bundle, not with a lone script:

```bash
python repair_target_snapshots.py --batch /absolute/path/to/existing_ls6_batch
```

Fresh LS6 batches already contain these fixes. Do not use this command to convert Vista/Frontera batches to LS6; use a new batch with `--reuse-from`. Keep the parent cluster source snapshots intact.
