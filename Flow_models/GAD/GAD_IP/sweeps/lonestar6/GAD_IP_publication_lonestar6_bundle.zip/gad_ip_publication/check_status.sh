#!/bin/bash
# Read-only monitoring; no installation, submission or repair.
set -uo pipefail
GP_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$GP_ROOT/slurm/environment.sh" || exit
exec python "$GP_ROOT/status_publication.py" "$@"
