#!/bin/bash
# Idempotent Oct-28 repair: install only missing pinned CUDA support wheels.
set -eo pipefail
GP_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$GP_ROOT/slurm/environment.sh"
cd "$GP_ROOT"
python "$GP_ROOT/ls6_cuda.py" --repair
