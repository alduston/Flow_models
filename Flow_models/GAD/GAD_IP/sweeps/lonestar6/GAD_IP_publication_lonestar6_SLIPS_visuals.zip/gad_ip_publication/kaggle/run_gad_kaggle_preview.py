#!/usr/bin/env python3
"""A bounded, resumable notebook preview of the supplied fixed-mass GAD bundle.

Commands: setup [--install], run, report. The source bundle is copied, never edited.
Preview NUTS samples are explicitly uncertified and cannot be adopted as references
by the publication workflow. No Slurm or cluster environment scripts are executed.
"""
from __future__ import annotations

import argparse
import contextlib
import copy
import hashlib
import importlib.metadata as metadata
import json
import math
import os
from pathlib import Path
import pickle
import queue
import shutil
import signal
import subprocess
import sys
import threading
import time
import traceback
import zipfile

VERSION = 'kaggle-slips-preview-2'
PROBLEMS = ['allen_cahn', 'navier_stokes', 'helmholtz']
WORKING = Path('/kaggle/working') if Path('/kaggle').exists() else Path.cwd()
DEFAULT_BATCH = WORKING / 'gad_slips_preview_r4_n1500'
NOTE = 'PREVIEW ONLY: one sampler repeat; shortened NUTS is not a certified reference.'


def say(message):
    print(message, flush=True)


def read(path):
    return json.loads(Path(path).read_text())


def clean(value):
    if isinstance(value, dict): return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)): return [clean(v) for v in value]
    if isinstance(value, Path): return str(value)
    if hasattr(value, 'tolist'): return clean(value.tolist())
    if isinstance(value, float) and not math.isfinite(value): return None
    return value


def write(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(clean(value), indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''): h.update(block)
    return h.hexdigest()


def binding(value):
    return hashlib.sha256(json.dumps(clean(value), sort_keys=True).encode()).hexdigest()


def safe_extract(archive, destination):
    destination = Path(destination).resolve(); destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            target = (destination / item.filename).resolve()
            if not target.is_relative_to(destination): raise ValueError('Unsafe ZIP path: ' + item.filename)
            if (item.external_attr >> 16) & 0o170000 == 0o120000: raise ValueError('ZIP symlinks are unsupported')
        z.extractall(destination)


def locate_bundle(inputs, explicit=None):
    if explicit:
        p = Path(explicit).resolve()
        if (p / 'reference.py').is_file():
            if not (p / 'slips_comparison.py').is_file():raise ValueError('Use the updated SLIPS bundle')
            return p
        roots = [p]
    else:
        roots = [Path(inputs).resolve()]
    candidates = []
    for root in roots:
        if root.is_file() and root.suffix.lower() == '.zip': archives = [root]
        else:
            for f in root.rglob('reference.py'):
                if (f.parent / 'settings.json').is_file() and (f.parent / 'vendor/screening/run_problem.py').is_file() and (f.parent / 'slips_comparison.py').is_file():
                    candidates.append(f.parent)
            archives = list(root.rglob('*.zip'))
        if candidates: continue
        for archive in archives:
            try:
                with zipfile.ZipFile(archive) as z:
                    matches = [n for n in z.namelist() if n.endswith('gad_ip_publication/reference.py')
                               and str(Path(n).parent / 'slips_comparison.py') in z.namelist()]
                if not matches: continue
                dest = WORKING / 'gad_preview_sources' / sha(archive)[:12]
                safe_extract(archive, dest)
                candidates.append(dest / Path(matches[0]).parent)
            except zipfile.BadZipFile: continue
    candidates = sorted(set(p.resolve() for p in candidates))
    if len(candidates) != 1:
        raise RuntimeError('Expected one GAD bundle. Found: ' + str(candidates) +
                           '. Pass --bundle /exact/path/to/gad_ip_publication or its ZIP.')
    return candidates[0]


def environment(allow_cpu=False, gpu=None):
    env = os.environ.copy()
    env.update(PYTHONUNBUFFERED='1', MPLBACKEND='Agg', JAX_ENABLE_X64='true',
               XLA_PYTHON_CLIENT_PREALLOCATE='false', XLA_PYTHON_CLIENT_MEM_FRACTION='0.40',
               OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2')
    env['JAX_PLATFORMS'] = 'cpu' if allow_cpu else 'cuda'
    if gpu is not None: env['CUDA_VISIBLE_DEVICES'] = str(gpu)
    return env


def versions():
    result = {'python': sys.version.split()[0]}
    for name in ['jax', 'jaxlib', 'numpy', 'scipy', 'pandas', 'matplotlib', 'torch', 'numpyro', 'arviz', 'pypdf']:
        try: result[name] = metadata.version(name)
        except metadata.PackageNotFoundError: result[name] = None
    return result


def setup_environment(args):
    current = versions(); say(json.dumps(current, indent=2))
    # Constrain the working numerical/CUDA stack while pip resolves only extras.
    protected = {}
    for d in metadata.distributions():
        name = d.metadata.get('Name', '')
        if name.lower() in {'jax', 'jaxlib', 'numpy', 'scipy', 'pandas', 'matplotlib', 'torch'} or name.lower().startswith(('jax-cuda', 'nvidia-')):
            # distributions() can enumerate duplicate/stale metadata entries.
            # Resolve by the same import-path priority as the version report.
            protected[name] = metadata.version(name)
    constraints = WORKING / 'gad_preview_environment_constraints.txt'
    constraints.parent.mkdir(parents=True, exist_ok=True)
    constraints.write_text(''.join(f'{n}=={v}\n' for n, v in sorted(protected.items())))
    if args.install:
        requirements = ['numpyro==0.22.0', 'arviz==0.23.4', 'pypdf>=5,<7']
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check',
                        '--upgrade-strategy', 'only-if-needed', '-c', str(constraints), *requirements], check=True)
        for name, version in protected.items():
            if metadata.version(name) != version: raise RuntimeError('Protected package changed: ' + name)
    result = WORKING / 'gad_preview_environment.json'
    command = [sys.executable, '-u', str(Path(__file__).resolve()), '_preflight', '--record', str(result)]
    if args.allow_cpu: command.append('--allow-cpu')
    subprocess.run(command, env=environment(args.allow_cpu, 0), check=True)
    say('Environment passed. Existing JAX, CUDA packages and PyTorch retained.')


def preflight(args):
    import numpy as np
    import scipy, pandas, matplotlib, torch, jax, arviz as az, pypdf, numpyro
    import jax.numpy as jnp
    from numpyro.infer import NUTS
    jax.config.update('jax_enable_x64', True)
    if not args.allow_cpu:
        if not any(d.platform == 'gpu' for d in jax.devices()): raise RuntimeError('JAX GPU is unavailable')
        if not torch.cuda.is_available(): raise RuntimeError('PyTorch GPU is unavailable')
    a = jax.jit(lambda x: x @ x)(jnp.eye(4, dtype=jnp.float64)); a.block_until_ready()
    if a.dtype != jnp.float64: raise RuntimeError('float64 check failed')
    b = torch.eye(4, dtype=torch.float64, device='cuda' if torch.cuda.is_available() else 'cpu')
    (b @ b).sum().item()
    kernel = NUTS(potential_fn=lambda z: .5 * jnp.vdot(z, z), adapt_mass_matrix=False,
                  target_accept_prob=.95, max_tree_depth=(4, 5), find_heuristic_step_size=True)
    state = kernel.init(jax.random.PRNGKey(7), num_warmup=20, init_params=jnp.zeros(3), model_args=(), model_kwargs={})
    step = jax.jit(lambda s: kernel.sample(s, (), {}))
    for _ in range(25): state = step(state)
    jax.block_until_ready(state.z)
    if not np.isfinite(np.asarray(state.z)).all(): raise RuntimeError('NumPyro transition failed')
    probe = az.from_dict(posterior={'x': np.random.default_rng(4).normal(size=(2, 100, 3))})
    for fn, method in [(az.rhat, 'rank'), (az.ess, 'bulk'), (az.ess, 'tail'), (az.mcse, 'mean')]:
        if not np.isfinite(fn(probe, method=method)['x'].values).all(): raise RuntimeError('ArviZ 0.x API failed')
    result = dict(versions=versions(), devices=[str(d) for d in jax.devices()],
                  cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'), float64=True)
    write(args.record, result); say(json.dumps(result, indent=2))


def preview_config(source, args):
    c = copy.deepcopy(read(source / 'settings.json'))
    c['sampler_seeds'] = [42]; c['initial_repeats'] = 1; c['active_problems'] = args.problems
    for p in PROBLEMS:
        c['problems'][p].update(particles=args.helmholtz_particles if p == 'helmholtz' else args.particles, rounds=args.rounds)
    c['sampler'].update(rounds=args.rounds, steps=200, eval_particles=64, heldout_batch=2)
    c['nuts'].update(num_chains=2, num_warmup=args.warmup, num_samples=args.draws,
                     chunk_size=25, mass_mode='fixed', max_tree_depth_warmup=7,
                     max_tree_depth=8, map_starts=2)
    c['evaluation'].update(distribution_cap=200, sliced_directions=32, floor_replicates=20,
                           reference_predictive_draws=64, reference_block_length=25, reference_bootstrap=50)
    c['aggregation'].update(bootstrap_replicates=100, png_dpi=160)
    c['preview'] = dict(version=VERSION, certified=False, repeat_uncertainty_available=False,
                        note=NOTE, production_nuts_thresholds=read(source / 'settings.json')['nuts'])
    return c


def create_batch(source, args):
    batch = args.batch.resolve(); config = preview_config(source, args)
    original = {str(p.relative_to(source)): sha(p) for p in source.rglob('*')
                if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    identity = binding(dict(config=config, source=original, runner=sha(__file__), runtime=versions()))
    if batch.exists():
        if not (batch / 'preview.json').exists() or read(batch / 'preview.json')['binding'] != identity:
            raise ValueError('Existing preview settings/source/runtime differ. Use a fresh --batch path.')
        for name, expected in read(batch / 'source_manifest.json').items():
            if sha(batch / 'code' / name) != expected: raise ValueError('Frozen source changed: ' + name)
        return batch
    if batch == source or source in batch.parents or batch in source.parents:
        raise ValueError('Use a preview batch outside the input bundle')
    batch.mkdir(parents=True)
    shutil.copytree(source, batch / 'code', ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.pytest_cache', 'batches', 'output'))
    shutil.copy2(__file__, batch / 'preview_runner.py')
    write(batch / 'settings.json', config)
    write(batch / 'source_manifest.json', {str(p.relative_to(batch / 'code')): sha(p) for p in (batch / 'code').rglob('*') if p.is_file()})
    write(batch / 'batch.json', dict(problems=args.problems, preview_only=True, qa_label=NOTE))
    write(batch / 'selection.json', dict(sampler_seeds=[42], maximum=1, phase='preview'))
    write(batch / 'preview.json', dict(binding=identity, created_unix=time.time(), note=NOTE,
                                      source=str(source), configuration=config, runtime=versions()))
    (batch / 'logs').mkdir(); (batch / 'stages').mkdir()
    return batch


@contextlib.contextmanager
def heartbeat(label, seconds=15):
    started = time.monotonic(); stop = threading.Event()
    def pulse():
        while not stop.wait(seconds): say(f'[heartbeat] {label}; waiting {time.monotonic()-started:.0f}s')
    thread = threading.Thread(target=pulse, daemon=True); thread.start()
    try: yield
    finally: stop.set(); thread.join()


def nuts_transitions(energy, initial, config, directory, index, identity, *, limit=None):
    """NumPyro's unchanged transition; host timing and atomic local checkpoints."""
    import jax
    import jax.numpy as jnp
    import numpy as np
    from numpyro.infer import NUTS
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    key = binding(dict(identity=identity, config=config, index=index, runtime=versions()))
    checkpoint = directory / 'preview_checkpoint.pkl'
    kernel = NUTS(potential_fn=energy, dense_mass=False, adapt_mass_matrix=False,
                  target_accept_prob=config['target_accept'],
                  max_tree_depth=(config['max_tree_depth_warmup'], config['max_tree_depth']),
                  find_heuristic_step_size=True, regularize_mass_matrix=True)
    with heartbeat(f'chain {index}: initialization/compilation'):
        state = kernel.init(jax.random.PRNGKey(config['sampler_seed'] + 100003*(index+1)),
                            num_warmup=config['num_warmup'], init_params=jnp.asarray(initial), model_args=(), model_kwargs={})
        jax.block_until_ready(state.z)
    done = 0; warm = 0; times = []; positions = []
    extra = {k: [] for k in ['potential_energy', 'energy', 'accept_prob', 'num_steps', 'diverging', 'adapt_state.step_size']}
    elapsed = 0.
    if checkpoint.exists():
        with checkpoint.open('rb') as f: saved = pickle.load(f)
        if saved['binding'] != key: raise ValueError('Preview checkpoint identity/runtime changed')
        state = jax.tree_util.tree_map(jnp.asarray, saved['state'])
        warm, done, positions, extra, elapsed = (saved[k] for k in ['warm', 'done', 'positions', 'extra', 'elapsed'])
        say(f'chain {index}: resume warmup={warm}, retained={done}')
    step = jax.jit(lambda s: kernel.sample(s, (), {}))
    transitions = 0
    def persist():
        saved = dict(binding=key, state=jax.device_get(state), warm=warm, done=done,
                     positions=positions, extra=extra, elapsed=elapsed)
        tmp = checkpoint.with_suffix('.pkl.tmp')
        with tmp.open('wb') as f: pickle.dump(saved, f, protocol=pickle.HIGHEST_PROTOCOL)
        tmp.replace(checkpoint)
        write(directory / 'progress.json', dict(warmup_done=warm, warmup_requested=config['num_warmup'],
              draws_done=done, draws_requested=config['num_samples'], elapsed_seconds=elapsed, certified=False))
        if done:
            draws_path = directory / 'preview_draws.npz'
            temp_draws = draws_path.with_suffix('.npz.tmp')
            with temp_draws.open('wb') as f:
                np.savez_compressed(f, z_samples=np.asarray(positions), **{k: np.asarray(v) for k, v in extra.items()})
            temp_draws.replace(draws_path)
    try:
        while warm < config['num_warmup'] or done < config['num_samples']:
            warming = warm < config['num_warmup']; number = warm+1 if warming else done+1
            started = time.monotonic()
            with heartbeat(f'chain {index}: {"warmup" if warming else "sample"} {number}'):
                state = step(state); jax.block_until_ready(state.z)
            seconds = time.monotonic()-started; elapsed += seconds; times.append(seconds); transitions += 1
            host = jax.device_get(state)
            if warming: warm += 1
            else:
                done += 1; positions.append(np.asarray(host.z))
                for k in extra:
                    extra[k].append(np.asarray(host.adapt_state.step_size if k == 'adapt_state.step_size' else getattr(host, k)))
            if number % 10 == 0 or number == 1 or (warming and warm == config['num_warmup']) or done == config['num_samples']:
                phase = f'warmup {warm}/{config["num_warmup"]}' if warming else f'sample {done}/{config["num_samples"]}'
                say(f'chain {index} {phase}: last={seconds:.3f}s, leapfrogs={int(host.num_steps)}, '
                    f'accept={float(host.accept_prob):.3f}, divergent={bool(host.diverging)}, step={float(host.adapt_state.step_size):.4g}')
            if number % 10 == 0 or (warming and warm == config['num_warmup']) or done == config['num_samples']: persist()
            if limit and transitions >= limit: break
    finally: persist()
    return directory / 'preview_draws.npz'


def chain_worker(batch, problem, index):
    import jax
    from common import check_target, load_model, load_npz, read_json
    from reference import potential
    from reference_core import make_whitened_potential
    cfg = read(batch / 'settings.json'); out = batch / 'reference' / problem
    setup = load_npz(out / 'setup.npz'); info = read_json(out / 'setup.json')
    if sha(out / 'setup.npz') != info['setup_sha256']: raise ValueError('Changed MAP setup')
    model = load_model(problem, cfg['data_seed'], out / f'model_preview_chain{index}')
    target = check_target(batch, problem, model)
    say(f'{problem} chain {index}: {jax.devices()}; exact MAP-whitened potential, fixed mass, depths 7/8')
    nuts_transitions(make_whitened_potential(potential(model), setup), setup['initial_z'][index],
                     cfg['nuts'], out / 'preview_chains' / f'chain_{index}', index,
                     dict(target=target, setup=sha(out / 'setup.npz')))


def preview_reference(batch, problem):
    """Explicit opt-in accessor for this process only; production checks still reject it."""
    from common import load_npz
    if not read(Path(batch) / 'batch.json').get('preview_only'): raise ValueError('Preview batch required')
    out = Path(batch) / 'reference' / problem
    ref = load_npz(out / 'preview_samples.npz'); q = read(out / 'nuts_diagnostics.json')
    if bool(ref['certified']) or q['certified']: raise ValueError('Preview must remain uncertified')
    if sha(out / 'preview_samples.npz') != q['preview_samples_sha256']: raise ValueError('Changed preview samples')
    if str(ref['fingerprint']) != read(out / 'target.json')['fingerprint']: raise ValueError('Preview target mismatch')
    # Existing summary/evaluation functions use this key only as a byte identity.
    return ref, dict(q, reference_sha256=q['preview_samples_sha256'])


def evaluate_worker(batch, problem):
    import numpy as np
    import reference, comparison
    from common import load_npz, save_npz
    from reference_core import arviz_diagnostics, kernel_diagnostics
    out = batch / 'reference' / problem; cfg = read(batch / 'settings.json'); target = read(out / 'target.json')
    parts = []
    for i in range(2):
        p = out / 'preview_chains' / f'chain_{i}' / 'preview_draws.npz'
        if not p.exists(): raise RuntimeError(f'Chain {i} has no retained preview draws; inspect its log')
        parts.append(load_npz(p))
    count = min(len(p['z_samples']) for p in parts)
    if count < 50: raise RuntimeError(f'Only {count} draws per chain; resume NUTS before reference comparisons')
    setup = load_npz(out / 'setup.npz')
    z = np.stack([p.pop('z_samples')[:count] for p in parts])
    chains = setup['map_position'] + z @ setup['laplace_factor'].T
    if not np.isfinite(chains).all(): raise ValueError('Nonfinite NUTS samples')
    extras = {k: np.stack([p[k][:count] for p in parts]) for k in parts[0]}
    derived = reference._derived(chains, extras['potential_energy'], load_npz(out / 'physical_spec.npz'))
    convergence, rows = arviz_diagnostics(chains, derived)
    kernel = kernel_diagnostics(extras, max_tree_depth=cfg['nuts']['max_tree_depth'])
    save_npz(out / 'preview_samples.npz', samples=chains.reshape(-1, chains.shape[-1]), samples_by_chain=chains,
             certified=np.asarray(False), fingerprint=np.asarray(target['fingerprint']))
    save_npz(out / 'chain_diagnostics.npz', **dict(extras, **derived))
    original = cfg['preview']['production_nuts_thresholds']
    checks = dict(rank_rhat=convergence['max_rank_rhat'] <= original['max_rhat'],
                  bulk_ess=convergence['min_bulk_ess'] >= original['min_bulk_ess'],
                  tail_ess=convergence['min_tail_ess'] >= original['min_tail_ess'],
                  divergences=kernel['total_divergences'] == 0,
                  tree_depth=kernel['max_tree_depth_saturation_fraction'] <= original['max_tree_depth_fraction'],
                  ebfmi=kernel['min_ebfmi'] >= original['min_ebfmi'],
                  acceptance=kernel['min_mean_accept_prob'] >= original['min_mean_accept'])
    write(out / 'nuts_diagnostics.json', dict(certified=False, preview_only=True, note=NOTE,
          convergence=convergence, kernel=kernel, checks_against_production_thresholds=checks,
          thresholds=cfg['nuts'], retained_draws_per_chain=count, requested_draws_per_chain=cfg['nuts']['num_samples'],
          reference_sha256=None, preview_samples_sha256=sha(out / 'preview_samples.npz')))
    from aggregate_publication import write_csv
    write_csv(out / 'nuts_parameter_diagnostics.csv', rows)
    reference.verified_reference = preview_reference
    comparison.verified_reference = preview_reference
    # Keep a disjoint sampling-floor subcloud even if a chain reached its time limit.
    # A time-limited preview may have fewer draws than requested. Keep floor
    # subclouds disjoint and record their actual size; never fabricate draws.
    summary_cfg = copy.deepcopy(cfg)
    summary_cfg['evaluation']['distribution_cap'] = min(cfg['evaluation']['distribution_cap'], count)
    reference.settings = lambda unused: copy.deepcopy(summary_cfg)
    say(f'{problem}: provisional diagnostics {convergence}; {kernel}')
    reference.summarize(batch, problem)
    comparison.evaluate_repeat(batch, problem, 42)


def render_problem(batch, problem):
    import numpy as np
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    import plotting
    from common import load_npz, problem_config, run_directory
    from aggregate_publication import summarize_rows, write_csv, finite
    cfg = problem_config(read(batch / 'settings.json'), problem)
    directory = run_directory(batch, problem, 42)
    rows = [dict(v, problem=problem, method=k, algorithm=k.split('-')[0], round=int(k.split('-')[1]),
                 sampler_seed=42, data_seed=42, preview_only=True) for k, v in read(directory / 'publication_metrics.json').items()]
    summary = summarize_rows(rows, cfg, problem)
    for row in summary: row.update(sd=None, ci_low=None, ci_high=None)
    out = batch / 'meta_results' / problem; out.mkdir(parents=True, exist_ok=True)
    write_csv(out / 'all_metrics.csv', rows)
    write_csv(out / 'summary.csv', summary)
    display = [dict(row, ci_low=row['mean'], ci_high=row['mean']) for row in summary]
    original_finish = plotting.finish
    original_load = plotting.load_npz
    def preview_load(path):
        p = Path(path)
        return original_load(p.with_name('preview_samples.npz') if p.name == 'reference_samples.npz' else p)
    def finish(fig, name, destination, dashboard, dpi, captions, caption):
        fig.text(.5, .005, 'PREVIEW | n=1 | shortened, uncertified NUTS', ha='center', fontsize=7, color='#A33B21')
        if name in {'reconstruction_vs_round', 'posterior_error_vs_work', 'secondary_diagnostics', 'runtime_and_conditional_ess'}:
            caption = ('Single seed 42. Repeat SD and confidence intervals are unavailable; no uncertainty band is estimated. '
                       'NUTS comparisons and the sampling-floor scale are provisional. '
                       'The actual subcloud size is recorded in sampling_floors.npz and may be smaller than the candidate cloud. ')
        caption = NOTE + ' ' + caption + ' SLIPS uses a terminal conditional cloud; draws sharing a localization path are dependent. See slips_diagnostics and the saved path IDs.'
        return original_finish(fig, name, destination, dashboard, dpi, captions, caption)
    plotting.load_npz = preview_load; plotting.finish = finish
    def no_repeat_sd(batch, problem, seeds, rounds, out, dashboard, dpi, captions):
        fig, ax = plt.subplots(figsize=(7.1, 2.3)); ax.axis('off')
        ax.text(.5, .55, 'Repeat-to-repeat variation needs multiple independent repeats.', ha='center', transform=ax.transAxes)
        ax.text(.5, .35, 'This preview has one repeat. Posterior SD maps remain available.', ha='center', transform=ax.transAxes)
        finish(fig, 'sampler_repeat_variation', out, dashboard, dpi, captions, 'Across-repeat variation is unavailable at n=1.')
    plotting.spread_maps = no_repeat_sd
    quality = read(batch / 'reference' / problem / 'nuts_diagnostics.json')
    with PdfPages(out / 'PREVIEW_dashboard.pdf') as pdf:
        fig = plt.figure(figsize=(8.27, 11.69)); fig.text(.08, .92, f'GAD preview: {problem}', size=18)
        text = [NOTE, '', f'Particles: {cfg["problems"][problem]["particles"]}; GAD rounds: {cfg["sampler"]["rounds"]}; sampler seed: 42',
                f'NUTS: 2 chains; {cfg["nuts"]["num_warmup"]} warmup; {quality["retained_draws_per_chain"]} retained draws each',
                'Exact posterior for the frozen preview realization; float64; MAP whitening; fixed mass.',
                'Depth limits: 7 warmup / 8 production (127 / 255 leapfrog steps).', '',
                'Short-chain diagnostics:', json.dumps(quality['convergence'], indent=2),
                f'Divergences: {quality["kernel"]["total_divergences"]}',
                f'Max tree-depth saturation fraction: {quality["kernel"]["max_tree_depth_saturation_fraction"]:.3g}',
                '', f'GAD/MALA/SLIPS rounds: 1 through {cfg["sampler"]["rounds"]}; MALA uses cumulative checkpoints; SLIPS restarts at each matched derivative-work budget.',
                'No across-repeat SD or confidence interval can be estimated from this preview.',
                'All NUTS-based distances, intervals and maps are provisional.']
        fig.text(.08, .85, '\n'.join(text), va='top', size=9, linespacing=1.6); pdf.savefig(fig); plt.close(fig)
        number = plotting.problem_figures(batch, problem, cfg, display, out / 'figures', pdf)
    write(out / 'preview_report.json', dict(figure_count=number, preview_only=True, certified=False))
    return number


def worker(args):
    batch = args.batch.resolve(); sys.path.insert(0, str(batch / 'code'))
    if not read(batch / 'batch.json').get('preview_only'): raise ValueError('Preview batch required')
    if args.stage == 'prepare':
        from reference import prepare
        prepare(batch, args.problem)
    elif args.stage == 'repeat':
        from repeat import run_repeat
        run_repeat(batch, args.problem, 42, allow_cpu=args.allow_cpu)
    elif args.stage == 'slips':
        from slips_comparison import execute
        execute(batch, args.problem, 42, allow_cpu=args.allow_cpu)
    elif args.stage == 'chain': chain_worker(batch, args.problem, args.chain)
    elif args.stage == 'evaluate': evaluate_worker(batch, args.problem)
    elif args.stage == 'plot': render_problem(batch, args.problem)


def stage_group(batch, jobs, minutes, global_deadline, allow_cpu):
    """Subprocess workers isolate model globals and assign each NUTS chain a GPU."""
    running = []; messages = queue.Queue()
    def pump(pipe, label, logfile):
        with logfile.open('w') as f:
            for line in iter(pipe.readline, ''):
                f.write(line); f.flush(); messages.put((label, line.rstrip()))
        pipe.close()
    def stop(proc):
        if proc.poll() is not None: return
        os.killpg(proc.pid, signal.SIGTERM)
        try: proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL); proc.wait()
    try:
        for problem, stage, index, gpu in jobs:
            label = f'{problem}-{stage}-{index}'; statepath = batch / 'stages' / (label + '.json')
            if statepath.exists() and read(statepath).get('state') == 'complete':
                say(label + ': already complete'); continue
            if time.monotonic() >= global_deadline: continue
            cmd = [sys.executable, '-u', str(batch / 'preview_runner.py'), '_worker', '--batch', str(batch),
                   '--problem', problem, '--stage', stage, '--chain', str(index)]
            if allow_cpu: cmd.append('--allow-cpu')
            env = environment(allow_cpu or stage == 'plot', gpu)
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                    bufsize=1, env=env, start_new_session=True)
            started = time.monotonic()
            log = batch / 'logs' / (label + '.log')
            thread = threading.Thread(target=pump, args=(proc.stdout, label, log), daemon=True); thread.start()
            write(statepath, dict(state='running', started_unix=time.time(), log=str(log)))
            running.append(dict(proc=proc, label=label, statepath=statepath, started=started,
                                deadline=min(started+minutes*60, global_deadline), thread=thread))
        last_pulse = time.monotonic()
        while any(j['proc'].poll() is None for j in running):
            try:
                label, line = messages.get(timeout=.25); say(f'[{label}] {line}')
            except queue.Empty: pass
            now = time.monotonic()
            for j in running:
                if j['proc'].poll() is None and now >= j['deadline']:
                    j['timed_out'] = True; say(f'{j["label"]}: reached wall-time limit; saved checkpoints/results retained.'); stop(j['proc'])
            if now-last_pulse >= 30:
                say('[driver heartbeat] ' + '; '.join(f'{j["label"]}: {(now-j["started"])/60:.1f} min' for j in running if j['proc'].poll() is None))
                last_pulse = now
        for j in running:
            j['thread'].join(timeout=5)
            rc = j['proc'].returncode
            write(j['statepath'], dict(state='complete' if rc == 0 else 'timed_out' if j.get('timed_out') else 'failed',
                  returncode=rc, elapsed_seconds=time.monotonic()-j['started'], note=NOTE))
    finally:
        for j in running:
            stop(j['proc'])
            if read(j['statepath']).get('state') == 'running':
                write(j['statepath'], dict(state='interrupted', returncode=j['proc'].returncode,
                      elapsed_seconds=time.monotonic()-j['started'], note=NOTE))
        while not messages.empty():
            label, line = messages.get_nowait(); say(f'[{label}] {line}')
    return all((batch / 'stages' / f'{p}-{s}-{i}.json').exists()
               and read(batch / 'stages' / f'{p}-{s}-{i}.json').get('state') == 'complete'
               for p, s, i, gpu in jobs)


def package_report(batch):
    """Also works after a timeout, interruption, or failed problem."""
    from pypdf import PdfReader, PdfWriter
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    batch = Path(batch).resolve(); out = batch / 'meta_results'; out.mkdir(exist_ok=True)
    stages = {p.stem: read(p) for p in (batch / 'stages').glob('*.json')}
    ready = [p for p in read(batch / 'batch.json')['problems']
             if (out / p / 'PREVIEW_dashboard.pdf').exists() and (out / p / 'preview_report.json').exists()]
    cover = out / 'preview_cover.pdf'
    fig = plt.figure(figsize=(8.27, 11.69)); fig.text(.08, .93, 'GAD reduced-run preview', size=20)
    text = [NOTE, '', 'Finished problem reports: ' + (', '.join(ready) or 'none yet'), '', 'Stage inventory:']
    text += [f'{key}: {value["state"]}' for key, value in stages.items()]
    text += ['', 'Check logs/ and stages/ for failed or time-limited work.',
             'Rerun the identical run command to continue local NUTS checkpoints.',
             'Use a fresh batch if settings, code or numerical package versions change.',
             'Raw outputs and any unfinished work remain available in the results ZIP.']
    fig.text(.08, .87, '\n'.join(text), va='top', size=9, linespacing=1.5)
    fig.savefig(cover); plt.close(fig)
    writer = PdfWriter(); writer.append(str(cover))
    for p in ready: writer.append(str(out / p / 'PREVIEW_dashboard.pdf'))
    target = batch.parent / 'gad_preview_dashboard.pdf'
    with target.with_suffix('.pdf.tmp').open('wb') as f: writer.write(f)
    target.with_suffix('.pdf.tmp').replace(target); writer.close()
    write(out / 'preview_completion.json', dict(preview_only=True, certified=False, ready_problems=ready, stages=stages))
    archive = batch.parent / 'gad_preview_results.zip'; temporary = archive.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=4) as z:
        z.write(target, target.name)
        for p in sorted(batch.rglob('*')):
            relative = p.relative_to(batch)
            if not p.is_file() or p.suffix in {'.pkl', '.pyc', '.tmp'}: continue
            if any(part in {'__pycache__', 'data', '.pytest_cache', 'failed_attempts'} or part.startswith('model_') for part in relative.parts): continue
            z.write(p, Path('gad_preview') / relative)
    temporary.replace(archive)
    say(f'Dashboard: {target}\nResults ZIP: {archive}\nCompleted preview reports: {ready}')
    return ready


def run(args):
    if args.rounds < 1: raise ValueError('Positive GAD/MALA round count required')
    if args.warmup < 50 or args.draws < max(100, min(args.particles, 200), min(args.helmholtz_particles, 200)):
        raise ValueError('Use >=50 warmup and >=200 draws with the default particles; enough for preview floor subsets')
    if min(args.particles, args.helmholtz_particles) < 64: raise ValueError('At least 64 particles required')
    if min(args.hours, args.chain_minutes, args.stage_minutes) <= 0: raise ValueError('Positive time limits required')
    source = locate_bundle(args.inputs, args.bundle)
    if not (source / 'slips_comparison.py').is_file() or not read(source / 'settings.json').get('slips',{}).get('enabled'):
        raise ValueError('Attach the updated SLIPS bundle, not the earlier GAD/MALA ZIP')
    manifest = read(source / 'BUNDLE_MANIFEST.json')
    for name, record in manifest.items():
        expected = record['sha256'] if isinstance(record, dict) else record
        if sha(source / name) != expected: raise ValueError('Input manifest mismatch: ' + name)
    say('Input bundle: ' + str(source))
    batch = create_batch(source, args)
    say(NOTE); say('Preview batch: ' + str(batch))
    deadline = time.monotonic()+args.hours*3600
    with (batch / '.preview.lock').open('a') as lock:
        import fcntl
        try: fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError('A preview driver is already running for this batch')
        if args.reuse_reference_from:
            reuse_reference(batch, args.reuse_reference_from)
        try:
            for problem in args.problems:
                if time.monotonic() >= deadline: break
                say(f'\n=== {problem}: one repeat, {args.rounds} GAD/MALA/SLIPS rounds, two short NUTS chains ===')
                from_path = str(batch / 'code')
                if from_path not in sys.path: sys.path.insert(0, from_path)
                from slips_comparison import valid as slips_valid
                if not slips_valid(batch,problem,42):
                    (batch / 'stages' / f'{problem}-slips-0.json').unlink(missing_ok=True)
                upstream = [f'{problem}-{stage}-{i}' for stage, i in [('prepare', 0), ('repeat', 0), ('slips', 0), ('chain', 0), ('chain', 1)]]
                changed = any(not (batch / 'stages' / (key+'.json')).exists()
                              or read(batch / 'stages' / (key+'.json')).get('state') != 'complete' for key in upstream)
                if changed:
                    for stage in ['evaluate', 'plot']:
                        (batch / 'stages' / f'{problem}-{stage}-0.json').unlink(missing_ok=True)
                    (batch / 'meta_results' / problem / 'preview_report.json').unlink(missing_ok=True)
                if not stage_group(batch, [(problem, 'prepare', 0, 0)], args.stage_minutes, deadline, args.allow_cpu):
                    package_report(batch); continue
                # Sampler outputs become available before the NUTS preview.
                stage_group(batch, [(problem, 'repeat', 0, 0)], args.stage_minutes, deadline, args.allow_cpu)
                stage_group(batch, [(problem, 'slips', 0, 0)], args.stage_minutes, deadline, args.allow_cpu)
                stage_group(batch, [(problem, 'chain', 0, 0), (problem, 'chain', 1, 1)], args.chain_minutes, deadline, args.allow_cpu)
                if time.monotonic() < deadline:
                    ok = stage_group(batch, [(problem, 'evaluate', 0, 0)], args.stage_minutes, deadline, args.allow_cpu)
                    if ok: stage_group(batch, [(problem, 'plot', 0, 0)], args.stage_minutes, deadline, True)
                package_report(batch)
        finally: ready = package_report(batch)
    complete_stages = all(read(p).get('state') == 'complete' for p in (batch / 'stages').glob('*.json'))
    return 0 if len(ready) == len(args.problems) and complete_stages else 2


def reuse_reference(batch, donor):
    """Reuse only target/MAP/NUTS state from a stopped compatible local preview."""
    donor = Path(donor).resolve()
    if not (donor / 'preview.json').exists(): return
    old = read(donor / 'settings.json'); new = read(batch / 'settings.json')
    if old['data_seed'] != new['data_seed'] or old['nuts'] != new['nuts'] or read(donor / 'preview.json')['runtime'] != versions():
        say('Previous preview reference settings/runtime differ; preparing fresh references.'); return
    # Sampling/plot/SLIPS edits do not invalidate the unchanged exact-potential
    # NUTS transition. Compare only its source dependencies and actual bytes.
    import ast
    def functions(path, names):
        tree = ast.parse(path.read_text())
        return {node.name: ast.dump(node) for node in tree.body
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in names}
    transition_names = {'nuts_transitions', 'chain_worker', 'binding', 'versions', 'environment'}
    old_runner = donor / 'preview_runner.py'
    if not old_runner.exists() or functions(old_runner, transition_names) != functions(Path(__file__), transition_names):
        say('Previous preview NUTS implementation differs; preparing fresh references.'); return
    old_manifest = read(donor / 'source_manifest.json'); new_manifest = read(batch / 'source_manifest.json')
    dependencies = ['common.py', 'target_snapshot.py', 'reference.py', 'reference_core.py',
                    'vendor/screening/run_problem.py', 'vendor/screening/sampling.py']
    dependencies += ['vendor/screening/models/' + p + '.py' for p in read(batch / 'batch.json')['problems']]
    for name in dependencies:
        expected = new_manifest.get(name)
        if expected is None or old_manifest.get(name) != expected or sha(donor / 'code' / name) != expected:
            say('Previous preview reference dependency differs: ' + name + '; preparing fresh references.'); return
    sys.path.insert(0, str(batch / 'code'))
    from cache import prepared_valid
    from common import load_npz
    for problem in read(batch / 'batch.json')['problems']:
        source = donor / 'reference' / problem; destination = batch / 'reference' / problem
        if destination.exists() or not prepared_valid(donor, problem): continue
        def omit_model_directories(directory, names):
            return [name for name in names if name == 'data' or name.endswith('.tmp')
                    or name.startswith('model_') and (Path(directory) / name).is_dir()]
        shutil.copytree(source, destination, ignore=omit_model_directories)
        if not prepared_valid(batch, problem): raise ValueError('Copied preview target failed integrity validation')
        write(batch / 'stages' / f'{problem}-prepare-0.json', dict(state='complete', reused_from=str(donor), note=NOTE))
        for index in range(new['nuts']['num_chains']):
            progress = destination / 'preview_chains' / f'chain_{index}' / 'progress.json'
            if not progress.exists(): continue
            state = read(progress)
            draws_file = progress.parent / 'preview_draws.npz'
            if (state['warmup_done'] == new['nuts']['num_warmup'] and state['draws_done'] == new['nuts']['num_samples']
                    and draws_file.exists() and len(load_npz(draws_file)['z_samples']) == new['nuts']['num_samples']):
                write(batch / 'stages' / f'{problem}-chain-{index}.json', dict(state='complete', reused_from=str(donor), note=NOTE))
        say(f'{problem}: reused prepared target/MAP and available NUTS checkpoints from {donor}')


def stop_batch(batch, *, _proc_root=None):
    """Stop only this user's preview processes for the exact requested batch."""
    batch = Path(batch).resolve()
    proc_root = Path('/proc') if _proc_root is None else Path(_proc_root)
    if _proc_root is None and int((proc_root / 'self').resolve().name) != os.getpid():
        raise RuntimeError('Process namespace differs from /proc; stop the old preview through Kaggle session controls.')
    scripts = {Path(__file__).resolve(), batch / 'preview_runner.py'}
    found = []
    for entry in proc_root.iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid(): continue
        try:
            if entry.stat().st_uid != os.getuid(): continue
            argv = [x.decode() for x in (entry / 'cmdline').read_bytes().split(b'\0') if x]
            if len(argv) < 3: continue
            # Python can have -u before the script path.
            script_indices = [i for i, value in enumerate(argv) if value.endswith('.py') and Path(value).resolve() in scripts]
            if not script_indices: continue
            tail = argv[script_indices[0]+1:]
            if not tail or tail[0] not in {'run', '_worker'}: continue
            if '--batch' in tail:
                requested = Path(tail[tail.index('--batch')+1]).resolve()
            elif tail[0] == 'run':
                # Legacy one-round driver omitted --batch only at its old default.
                requested = WORKING / 'gad_preview'
            else: continue
            if requested == batch: found.append(int(entry.name))
        except (OSError, ValueError, UnicodeError, IndexError): continue
    for pid in found:
        try: os.kill(pid, signal.SIGTERM)
        except ProcessLookupError: pass
    deadline = time.monotonic()+5
    while time.monotonic() < deadline and any((proc_root / str(pid)).exists() for pid in found):
        time.sleep(.1)
    for pid in found:
        if not (proc_root / str(pid)).exists(): continue
        try: os.kill(pid, signal.SIGKILL)
        except ProcessLookupError: pass
    say(f'Stopped preview processes for {batch}: {found}. Saved files retained.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest='command', required=True)
    p = subs.add_parser('setup'); p.add_argument('--install', action='store_true'); p.add_argument('--allow-cpu', action='store_true')
    p = subs.add_parser('run')
    p.add_argument('--inputs', default='/kaggle/input/datasets/aloislduston')
    p.add_argument('--bundle', help='Exact extracted bundle folder or ZIP; otherwise search --inputs recursively')
    p.add_argument('--batch', type=Path, default=DEFAULT_BATCH)
    p.add_argument('--problems', nargs='+', choices=PROBLEMS, default=PROBLEMS)
    p.add_argument('--particles', type=int, default=200); p.add_argument('--helmholtz-particles', type=int, default=1500)
    p.add_argument('--rounds', type=int, default=4)
    p.add_argument('--reuse-reference-from', type=Path, help='Stopped local preview: reuse compatible target/MAP/NUTS work')
    p.add_argument('--warmup', type=int, default=1500); p.add_argument('--draws', type=int, default=500)
    p.add_argument('--chain-minutes', type=float, default=30); p.add_argument('--stage-minutes', type=float, default=20)
    p.add_argument('--hours', type=float, default=4); p.add_argument('--allow-cpu', action='store_true')
    p = subs.add_parser('report'); p.add_argument('--batch', type=Path, default=DEFAULT_BATCH)
    p = subs.add_parser('stop'); p.add_argument('--batch', type=Path, required=True)
    p = subs.add_parser('_preflight'); p.add_argument('--record', type=Path, required=True); p.add_argument('--allow-cpu', action='store_true')
    p = subs.add_parser('_worker'); p.add_argument('--batch', type=Path, required=True); p.add_argument('--problem', required=True)
    p.add_argument('--stage', choices=['prepare', 'repeat', 'slips', 'chain', 'evaluate', 'plot'], required=True)
    p.add_argument('--chain', type=int, default=0); p.add_argument('--allow-cpu', action='store_true')
    args = parser.parse_args()
    if args.command == 'setup': setup_environment(args)
    elif args.command == 'run': return run(args)
    elif args.command == 'report': package_report(args.batch)
    elif args.command == 'stop': stop_batch(args.batch)
    elif args.command == '_preflight': preflight(args)
    elif args.command == '_worker': worker(args)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
