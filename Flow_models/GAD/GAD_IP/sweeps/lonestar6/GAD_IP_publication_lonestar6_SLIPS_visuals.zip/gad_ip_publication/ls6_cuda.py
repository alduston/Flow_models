"""Narrow CUDA repair for the supplied LS6 JAX 0.4.30 stack.

These checks do not initialize a GPU. The allocated preflight must still
compile float64 kernels in both JAX and PyTorch.
"""
import argparse
import importlib.metadata
from pathlib import Path
import subprocess
import sys

PINS={'jax-cuda12-plugin':'0.4.30', 'jax-cuda12-pjrt':'0.4.30',
      'nvidia-cuda-nvcc-cu12':'12.8.93'}


def installed_packages():
    return {d.metadata['Name'].lower().replace('_','-'):d.version
            for d in importlib.metadata.distributions() if d.metadata['Name']}


def missing_requirements(installed):
    for name in ('jax','jaxlib'):
        if installed.get(name)!='0.4.30':
            raise RuntimeError('The LS6 repair expects '+name+'==0.4.30; found '+
                               str(installed.get(name))+'. No core packages were changed.')
    missing=[]
    for name,version in PINS.items():
        actual=installed.get(name)
        if actual is None:missing.append(name+'=='+version)
        elif actual!=version:
            raise RuntimeError('Expected '+name+'=='+version+'; found '+actual+
                               '. Refusing to replace an existing CUDA package automatically.')
    return missing


def check_packages():
    installed=installed_packages();missing=missing_requirements(installed)
    if missing:
        raise RuntimeError('LS6 CUDA support is incomplete: '+', '.join(missing)+
                           '. Run bash repair_ls6_cuda.sh on the login node, then run the allocated preflight.')
    return {name:installed[name] for name in ('jax','jaxlib',*PINS)}


def check_binding():
    versions=check_packages()
    from jax._src import lib
    if lib.cuda_versions is None:
        raise RuntimeError('JAX cannot import its CUDA version extension (lib.cuda_versions is None). '
                           'Inspect the plugin import error; do not submit the campaign yet.')
    return versions


def repair():
    before=installed_packages();missing=missing_requirements(before)
    if missing:
        subprocess.run([sys.executable,'-m','pip','install','--only-binary=:all:',
                        '--no-deps',*missing],check=True)
    else:print('Pinned LS6 CUDA repair packages already present; no installation needed.',flush=True)
    after=installed_packages()
    protected={name:version for name,version in before.items()
               if name in {'jax','jaxlib','torch','numpy','scipy','pandas','matplotlib','numpyro'}
               or name.startswith(('jax-cuda','nvidia-'))}
    if any(after.get(name)!=version for name,version in protected.items()):
        raise RuntimeError('An existing numerical/CUDA package changed during repair.')
    subprocess.run([sys.executable,str(Path(__file__).resolve()),'--check-binding'],check=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repair',action='store_true')
    parser.add_argument('--check-binding',action='store_true')
    args=parser.parse_args()
    if args.repair:repair()
    else:print(check_binding() if args.check_binding else check_packages(),flush=True)
