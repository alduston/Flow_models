# Lonestar6 SLIPS/visuals validation — 2026-10-28

This is implementation QA, not production posterior accuracy or a successful LS6 GPU run.

## Current checks

- **72 tests passed, no skips.** The combined suite covers the LS6 scheduler/caps/cluster guards, fixed-mass NUTS continuation, cross-cluster completed-file reuse, exclusion of foreign runtime checkpoints, target snapshot binding/repair, Python 3.9 annotation compatibility, isolated ArviZ, SLIPS callback ledgers/calibration/restarts, combined evaluations and presentation preferences.
- The exact JAX/jaxlib **0.4.30** and NumPyro **0.19.0** combination was exercised on CPU. Fixed-mass chunked continuation matched an uninterrupted chain. The main QA interpreter was Python 3.12.14, with NumPy 2.3.5, SciPy 1.17.0, PyTorch 2.5.1+cpu and ArviZ 0.23.4. This does not constitute execution under LS6 Python 3.9/CUDA.
- The isolated diagnostic bridge was exercised against a separate NumPy 1.26.4 / SciPy 1.13.1 / ArviZ 0.17.1 environment, including native equality for rank R-hat, bulk/tail ESS and mean MCSE. The existing scratch-symlink lookup passed. All non-provenance Python files parse with Python 3.9 grammar; shell syntax checks passed.
- Actual tiny SLIPS PDE smoke runs passed for Allen–Cahn `[64,32]`, Navier–Stokes `[64,36]` and Helmholtz `[64,32]`. Each produced 64 finite samples at **192** charged derivative-proxy units, within its 192-unit cap. Prepared-target binding, exact nonlinear posterior bridge, canonical metric evaluation, completed-cloud caching and recovery after an interrupted metric write passed. No NUTS reference or scientific convergence claim comes from these QA fixtures.
- Instrumented SLIPS callbacks matched every ledger across 64, 200, 1,000, 1,500 and 2,000 output particles and rounds 1–5. Rejected proposals were charged; fixed-seed replay matched exactly. Synthetic combined-reference evaluation included all GAD/MALA/SLIPS outputs, fields, posterior SD, predictive summaries and CSVs.
- Synthetic comparison figures passed the display assertions. Reconstruction and PCA histogram PNGs were visually inspected: plain MALA/SLIPS labels, matched-budget captions, equal histogram counts, deterministic saved selection and separate Allen–Cahn diagnostic traces. Synthetic figures are not distributed as scientific results.
- A full offline graph contains **65 tasks**: 1 preflight, 3 preparations, 12 NUTS chains, 3 certifications, 15 canonical repeats, **15 SLIPS jobs**, 15 evaluations and 1 report. Each SLIPS job waits for its canonical run and preparation; each evaluation waits for SLIPS and the reference. All commands retain `gpu-a100`/`DMS22021`; full reservations sum to **196.33 node-hours** before reuse. Only this QA graph raised the partition cap to inspect every command at once. Production retains the A100 cap of 28 and the global cap of 32.
- Six focused repair/relaunch tests verify missing-only pinned binary-wheel installation with `--no-deps`, preservation of the installed stack, rejection of incompatible installed versions, detection of the original missing CUDA binding, and stop-watcher → cancel-all → drain → repair/check → submit → detached-watch ordering. Slurm/cancellation/package mutations were mocked; no user jobs were touched here.
- Byte comparison confirms **seven Vista modules/assets are identical**, including both SLIPS modules, plotting, comparison, aggregation and the optional Kaggle notebook/runner. **39 LS6 scientific files are identical**, including every original model/sampler, fixed-mass reference, reference core and target helper. Settings differ from the supplied LS6 bundle only by adding `slips` and `slurm.slips_time`. Parent ZIP hashes and these file identities are in `provenance/ls6_slips_port.json`.
- The final ZIP has a regenerated SHA-256/size manifest, valid CRCs and no Python caches or synthetic result artifacts. Current top-level documentation links and shell examples were checked. The retained legacy target repair also recognizes the supplied LS6 installer and carries the new CUDA helper companions.

## Reproduce

From the extracted bundle with the normal numerical QA dependencies installed:

```bash
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 JAX_PLATFORMS=cpu JAX_ENABLE_X64=true \
  python -m unittest discover -s tests -p 'test_*.py' -v
```

Set `GP_DIAGNOSTICS_PYTHON` to the existing isolated diagnostic Python to include the two isolated-ArviZ integration checks; otherwise those checks explicitly skip.

```bash
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 JAX_PLATFORMS=cpu JAX_ENABLE_X64=true \
  python tests/smoke_slips_pde.py --problem allen_cahn --output /tmp/gad_ls6_slips_ac
```

Repeat with `navier_stokes` and `helmholtz` and distinct fresh output directories. These utilities deliberately use tiny QA-only prepared geometry and do not run/certify NUTS.

## Remaining production checks

No LS6 access/GPU allocation was available during authoring. The fresh allocated preflight must test CUDA initialization, float64 compilation in both JAX/PyTorch and NumPyro continuation. The targeted installer reproduces the recovered Oct-28 repair but does not establish GPU execution on its own. NUTS mixing, convergence certification, wall-time sufficiency and finite-budget SLIPS accuracy remain production outcomes. The terminal-conditional SLIPS variant and its within-path dependence are unchanged from Vista; see `SLIPS_COMPARISON.md`.

The public shared-chat URL could not be fetched. The supplied Vista archive was used as the authoritative implementation/display source, and the specific CUDA fix was recovered from the recent conversation context. Earlier Vista implementation QA is retained in `SLIPS_VALIDATION.md` as historical evidence.
