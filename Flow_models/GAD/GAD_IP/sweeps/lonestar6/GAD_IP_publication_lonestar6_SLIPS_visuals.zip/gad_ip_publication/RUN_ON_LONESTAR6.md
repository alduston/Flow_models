# Run the SLIPS/visuals update on Lonestar6

## Replace the current campaign

Copy `GAD_IP_publication_lonestar6_SLIPS_visuals.zip` into the existing `sweeps/lonestar6/` directory. Run on **login1.ls6**, the host recorded in the supplied status transcript. The command below deliberately cancels **every active Slurm job owned by you on LS6**, including `gp-preflight-repair` (3538967 in that transcript). It retains all batch directories and completed result files.

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/sweeps/lonestar6
unzip -qo GAD_IP_publication_lonestar6_SLIPS_visuals.zip
cd gad_ip_publication
bash restart_slips_lonestar6.sh --cancel-all-user-jobs
```

The launcher checks the old batch and login host, freezes a distinct new batch, stops local LS6 publication submission watchers, cancels all your Slurm jobs and waits for them to leave the queue. It then applies the missing-wheel CUDA repair, checks imports and starts the new campaign. The first submission pass runs in the foreground; a detached watcher fills deferred tasks after that. Do not disconnect until the launcher prints `Detached watcher PID`.

Defaults:

- Old batch: `../batches/gad_ip_ls6_fixed_mass_20261027`.
- New batch: `../batches/gad_ip_ls6_slips_visuals_20261028`.
- New watcher log: `../gad_ip_ls6_slips_visuals_20261028_submit.log`.
- Five sampler seeds (42–46), three active problems, five GAD rounds.
- `gpu-a100`, account `DMS22021`, global task cap 32, A100 cap 28, 12-hour NUTS reservations and one-hour SLIPS reservations.

A healthy run shows the new `gp-preflight` job first. Scientific jobs depend on this allocated CUDA/float64/NUTS preflight. Pending Priority/Resources is normal queue waiting. A full fresh campaign contains 65 tasks; only eligible tasks are submitted initially. Reuse and the 28-slot A100 cap can reduce the initial submission count.

The original completed targets, MAPs, canonical GAD/MALA runs and compatible fixed-mass NUTS outputs are adopted individually after identity checks. No old frozen source or scientific outputs are deleted. Cancelled jobs from the old batch do not block the new batch. The launcher also checks `GAD_IP/batches`, `sweeps/frontera/batches` and raw screening runs under `GAD_IP`. Partial NUTS checkpoints are reused only within the same cluster and still must match numerical runtime versions.

A second invocation verifies the existing destination source/settings, cancels current jobs again and resumes it with one deliberate retry per missing task. To change source/settings, supply a distinct `--new-batch ../batches/NAME`. The launcher refuses to stop a watcher recorded on another login host; stop it there before retrying. If the CUDA check fails, no new scientific jobs are submitted; retain the printed error.

## The preflight repair

The Oct-28 failure had `lib.cuda_versions is None` under JAX/jaxlib 0.4.30. The supplied repair adds only missing pinned packages:

```text
jax-cuda12-plugin==0.4.30
jax-cuda12-pjrt==0.4.30
nvidia-cuda-nvcc-cu12==12.8.93
```

Installation uses `--only-binary=:all: --no-deps`. Already installed matching packages are left in place; an incompatible installed version causes an explicit error. JAX, jaxlib, PyTorch, NumPy, SciPy and NumPyro are preserved. The existing Python 3.9.7 GPU venv and the diagnostics sibling symlink into `$SCRATCH/venvs/flow_ls6_py39_gad_diagnostics` are retained. Do **not** rerun the full reference installer for this update. The restart launcher already invokes the targeted repair.

For a standalone repair/check only, without cancellation/submission:

```bash
bash repair_ls6_cuda.sh
source slurm/environment.sh
python check_environment.py --imports-only
```

Login checks verify the CUDA extension import; actual GPU compilation is still tested on an allocated node.

## Monitor and reconnect

```bash
source slurm/environment.sh
bash check_status.sh --check-packages
tail -n 40 ../gad_ip_ls6_slips_visuals_20261028_submit.log
squeue -u "$USER"
```

Use the same new batch after a disconnect. If its watcher has exited and tasks remain deferred, resume it (do not run another watcher concurrently):

```bash
GP_BATCH=../batches/gad_ip_ls6_slips_visuals_20261028
GP_DRIVER_LOG=../gad_ip_ls6_slips_visuals_20261028_submit.log
nohup bash submit.sh --resume-batch "$GP_BATCH" --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown
```

Failed or deliberately cancelled jobs with invalid/missing output require inspecting logs and adding `--retry-failed` to that resume command. Each watcher retries a task at most once per invocation. The watcher may exit after all tasks are submitted while Slurm work is still pending/running.

After the five-repeat report has finished, use the same detached resume command with `--repeats 10` to add seeds 47–51. Queue overrides such as `--partition gpu-h100` and reservation overrides such as `--time slips=02:00:00` must be supplied again on every resume. Existing LS6 H100/small/development caps are preserved; the development partition is unsuitable for default 12-hour NUTS reservations.

Final output: `../batches/gad_ip_ls6_slips_visuals_20261028/gad_ip_publication_results.zip`. A diagnostic ZIP alone does not establish scientific completion: `meta_results/completion.json` must report `complete: true`, including strict NUTS certification and all three-method comparisons.
