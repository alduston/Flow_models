# SLIPS and visual revision

The comparison now includes SLIPS at every GAD budget. See [SLIPS_COMPARISON.md](SLIPS_COMPARISON.md) for its algorithm, ledger and terminal-conditional dependence limits, and [PLOT_PREFERENCES.md](PLOT_PREFERENCES.md) for presentation changes. The GAD/MALA and NUTS settings below are retained. All comparison families now include SLIPS; displayed baseline panels use the final cumulative GAD budget.

# Scientific configuration and publication outputs

## Experiment plan

| Problem | Particles / bank | GAD rounds | Initial repeats | Optional final repeats |
| --- | ---: | ---: | ---: | ---: |
| Navier-Stokes | 1,000 | 5 | 5 | 10 |
| Allen-Cahn | 1,000 | 5 | 5 | 10 |
| Helmholtz | 2,000 | 5 | 5 | 10 |
| Acoustic FWI, reserve only | 300 | 4 | Explicit opt-in | 10 registered |

Use `--problems afwi` in a new batch to opt into the reserve. No more same-seed exploratory extensions, heat runs or independent-MALA audits are scheduled.

Data seed stays **42**; requested independent sampler seeds initially are **42–46**, expandable to **42–51**. These repeats estimate sampler variability on one posterior, not robustness across new truths, noise or sensor layouts. The model-loader adapter separates data randomness from the original `seed+10000` transport and `seed+20000` MALA streams. Metadata and target fingerprints are checked rather than trusting directory suffixes.

Every active problem uses 200 transport steps, canonical OU interval `[10^-2.5, 10]`, a shared reference/gate bank equal to particles, original curvature settings and the supplied checkpoint MALA: guarded adaptation, 32 chains, thinning 1, requested dt `1e-4`, work multiplier 1. No baseline tuning is folded into the primary comparison.

| Particles | GAD cumulative work | MALA cumulative work | Shared warmup | Transitions / chain | Draws / chain |
| ---: | --- | --- | ---: | --- | ---: |
| 1000 | 3000, 6000, 9000, 12000, 15000 | 2944, 5952, 8960, 11968, 14976 | 13 | 45, 92, 139, 186, 233 | 32 |
| 2000 | 6000, 12000, 18000, 24000, 30000 | 5952, 11968, 17984, 24000, 29952 | 29 | 92, 186, 280, 374, 467 | 63 |

These are the original derivative-count proxies (three per GN bank particle, two per MALA transition/chain plus initialization). They include warmup and are not FLOPs or elapsed time. A compute-matched short MALA trajectory is not relabelled a converged reference.

## NUTS reference design and failure handling

The reference uses the **same discretized posterior** as the comparison run, not a finer PDE grid or a different sensor/noise model. “High fidelity” here means a longer, independently sampled posterior reference. Fingerprints bind the model source, realized basis, truth, observations, holdouts, observation geometry, noise scale and data seed. A mismatch fails rather than allowing a comparison between different posteriors.

The exact potential is `0.5 * ||alpha||^2 + 0.5 * ||F(alpha)-y||^2 / noise_std^2`. MAP starts use zero and independent prior draws, never generating truth or GAD/MALA output. The supplied Darcy routines perform four-start MAP optimization, select distinct candidate basins, regularize the exact MAP Hessian and construct a fixed invertible affine whitening map. The chains retain fixed identity mass after full MAP-Hessian whitening, adapt the step size, and use independent overdispersed starts, target acceptance 0.95, warmup tree depth 10 and production depth 12. Whitening changes coordinates, not the target potential; its constant Jacobian has no effect on the chain.

Per problem, the reference has 3,000 warmup and 5,000 retained draws per chain, four chains, and no thinning. Production saves atomic chunks of 250 draws together with full adaptation state and RNG state. Completed chunks resume without restarting or duplicating production draws; an interrupted incomplete warmup restarts warmup. Pickle checkpoints are trusted, locally generated state files and must not be replaced with files from untrusted sources. Resuming with different numerical package versions is refused.

Certification follows the Darcy thresholds on every latent coefficient plus potential energy, coefficient norm, four field-quadrant means and field RMS:

- Rank-normalized R-hat <= 1.01; bulk ESS >= 1000; tail ESS >= 400.
- Zero divergences; tree-depth saturation <= 1% in every chain.
- E-BFMI >= 0.30 and mean acceptance >= 0.80 in every chain.
- Finite draws and all required diagnostics.

Diagnostics are necessary evidence of mixing, not a proof that all possible modes were explored. Multi-start initialization and the trace/functional diagnostics make failures visible; a diagnostic pass is not mathematical ground truth. Unsuccessful checks write `reference_samples_uncertified.npz` and detailed diagnostics, but do **not** write a usable canonical reference or publication comparisons. There is no automatic override or silent reference substitution.

The NUTS mean has coefficient MCSE and approximate field-mean/SD Monte Carlo intervals from a within-chain block bootstrap (block length 100, 500 bootstrap replicates). Posterior spread and reference MC uncertainty are displayed separately. Inspect block-length sensitivity and the diagnostic table before making final reference-accuracy claims. The plotted repeat confidence intervals condition on the shared reference; they do not propagate its MC error into every distance metric.

## Results and publication outputs

The submission command prints the absolute batch path. After completion, download:

```text
BATCH/gad_ip_publication_results.zip
```

The ZIP includes the complete source snapshot and configuration, all original method clouds and all-round canonical metrics, reference chains and summaries, new reference metrics, diagnostic evidence and publication outputs. Repeated generated model-data directories, obsolete attempts and trusted restart pickles stay in the LS6 batch and are excluded from the review ZIP.

Main review files under `meta_results/`:

- `dashboard.pdf`: all publication figures, prefaced by the experiment and uncertainty conventions.
- `all_metrics.csv`: every method/round/seed, with both original and additional metrics.
- `summary.csv`: mean, median, sample SD, bootstrap 95% interval and explicit `n/expected_n` for every scalar metric.
- `paired_comparisons.csv`: GAD minus same-round MALA and GAD minus GAD-1, paired bootstrap intervals, ratios/reductions for positive errors, and win counts.
- `run_manifest.csv`, `reference_quality.csv`, `missing_or_failed.csv`, `completion.json`.
- `tables/*.tex`: editable mean +/- SD numeric tables for primary, posterior and secondary metrics.
- `metric_definitions.json`: exact definitions and estimator conventions.

Every problem gets the same figure family, with editable SVG, embedded-font PDF and **600 dpi PNG**, consistent serif typography, common method colors, matched axes and documented color scales:

- Primary field/state/forward errors versus round with repeat-mean confidence intervals.
- Six posterior-reference functionals versus cumulative canonical work: whitened mean/covariance errors, physical-field mean/SD errors, 95% interval endpoint error, and sliced Wasserstein error.
- Secondary exact-score, predictive and baseline diagnostics.
- Manuscript-style rows of posterior mean, absolute error and pointwise posterior SD, with truth/NUTS/GAD-1/GAD-final/MALA-final columns and shared unsaturated row scales.
- Mean estimates and their spatial SD across independent sampler repeats.
- Physical-state reconstructions with the original full-state metric definition preserved.
- Three reference-PCA projection pairs, all requested GAD rounds, NUTS and final MALA, with common coordinates and disclosed mass outside the displayed window.
- Held-out predictive intervals, sensor/source geometry, NUTS traces and reference MC uncertainty maps.
- Sampler runtime and conditional reference ESS diagnostics.

The map/PCA/predictive illustrations use **preselected sampler seed 42**, not the best seed. Aggregate curves use all requested seeds (five initially; ten after expansion); no round is selected separately by seed. Physical-field posterior means average the transformed fields, important for nonlinear velocity/contrast maps; the original `RMSE_field` remains the field evaluated at the mean coefficient. Both are reported under distinct names. Posterior SD uses `ddof=1`, explicitly differing from the archived manuscript illustration's `ddof=0`.

The original `postprocess_seed.py` is retained unchanged in `vendor/screening/` and works on these run directories:

```bash
python "$GP_BATCH/code/vendor/screening/postprocess_seed.py" \
  --root "$GP_BATCH/runs" --seed 42 --output "$GP_BATCH/seed42_legacy_review"
```

Original KL diagnostics have an unknown normalizer and are not true KL estimates. The canonical predictive NLL's absolute jitter floor is preserved for reproducibility. An additional `ScaledHeldoutPredNLL` uses noise-relative jitter, and clean held-out relative error is reported separately to expose small-amplitude/low-signal FWI effects. Unbiased reference `RefMMD2` can be negative; it is never truncated or relabeled a nonnegative distance. The SW2 subcloud band compares a candidate-size subcloud with all remaining disjoint NUTS draws. It is a finite-sample comparison scale, not a rigorous lower bound or an autocorrelation correction. All finite tails remain in the metrics.

Incomplete branches yield `INCOMPLETE_dashboard.pdf` and a nonzero aggregate job exit, while retaining numeric evidence and the review ZIP. A complete publication-ready claim requires every requested repeat and each reference to pass the checks; unavailable values are never silently treated as zero or as a ten-run average.

