"""Budgeted SLIPS, classical observation Y_t=t X+W_t, float64 NumPy driver.

The PDE callback supplies exact (log pi, grad log pi). Conditional Gaussian
terms are analytic. See SLIPS_COMPARISON.md for the terminal-conditional cloud
extension and its dependence limitations. No posterior reference is used.
"""
import math
import time
import numpy as np

DEFAULTS = dict(enabled=True, outer_steps=16, init_steps=4, init_step_factor=.05,
                t_start=.001, t_end=1000., max_paths=32, dt=1e-4,
                terminal_burnin=2, target_accept=.574)


def configuration(values=None):
    c = dict(DEFAULTS, **(values or {}))
    if set(c)-set(DEFAULTS): raise ValueError('Unknown SLIPS configuration field')
    for key in ['outer_steps', 'init_steps', 'max_paths', 'terminal_burnin']:
        if not isinstance(c[key], int) or c[key] < (1 if key in ['outer_steps','max_paths'] else 0):
            raise ValueError('Invalid SLIPS ' + key)
    if not 0 < c['t_start'] < c['t_end']: raise ValueError('Invalid SLIPS time range')
    if not 0 < c['init_step_factor'] < 1: raise ValueError('Invalid SLIPS initialization step')
    if not np.isfinite(c['dt']) or c['dt'] <= 0: raise ValueError('Invalid SLIPS MALA step')
    if not 0 < c['target_accept'] < 1: raise ValueError('Invalid SLIPS acceptance target')
    return c


def allocate(n_samples, target_proxy, values=None):
    """Quantize a fresh, independent budget run; never silently exceed its cap.

    One callback row = one exact value + one exact gradient = two proxy units,
    as in the existing MALA baseline. The initial cache is also charged.
    """
    c = configuration(values); stages = c['init_steps'] + c['outer_steps']
    plans = []
    for paths in range(1, min(c['max_paths'], n_samples)+1):
        draws = math.ceil(n_samples/paths)
        minimum = 2*paths*(1+stages+c['terminal_burnin']+draws)
        if minimum <= target_proxy: plans.append((paths, draws))
    if not plans: raise ValueError('SLIPS budget cannot fund initialization, localization and output cloud')
    paths, draws = plans[-1]
    extra = math.floor(target_proxy/(2*paths))-(1+stages+c['terminal_burnin']+draws)
    # Spend remaining whole parallel transitions evenly on denoiser estimates.
    inner = [1+extra//stages+int(i < extra%stages) for i in range(stages)]
    actual = 2*paths*(1+sum(inner)+c['terminal_burnin']+draws)
    return dict(paths=paths, draws_per_path=draws, inner_steps=inner,
                target_proxy=float(target_proxy), actual_proxy=actual,
                output_samples=n_samples, discarded_padding=paths*draws-n_samples,
                budget_slack=float(target_proxy)-actual)


def conditional(logp, score, x, y, t):
    residual = x-y/t
    return logp-.5*t*np.sum(residual**2, axis=1), score-t*residual


def run(initial, posterior, plan, values=None, *, seed=42, progress=None):
    """Run one budget, returning P terminal conditional draws and an audit ledger.

    Cached exact target values/scores remain valid when (y,t) changes. Only
    conditional analytic terms are recomputed. Rejected proposals still cost.
    """
    c = configuration(values); started = time.perf_counter()
    x = np.asarray(initial, dtype=np.float64).copy()
    paths, dim = x.shape
    if paths != plan['paths']: raise ValueError('SLIPS initial shape/plan mismatch')
    rng = np.random.default_rng(seed)
    ledger = dict(initialization=0, initialization_inner=0, localization_inner=0,
                  terminal_burnin=0, terminal_sampling=0)
    accepted_by_phase = {}; transitions_by_phase = {}; schedule = []

    def evaluate(z, phase):
        lp, sc = (np.asarray(v, dtype=np.float64) for v in posterior(z))
        if lp.shape != (paths,) or sc.shape != x.shape: raise ValueError('SLIPS posterior callback shape')
        ledger[phase] += paths
        return lp, sc

    lp, sc = evaluate(x, 'initialization')
    if not np.isfinite(lp).all() or not np.isfinite(sc).all(): raise ValueError('Nonfinite SLIPS initial posterior')
    t = c['t_start']; y = math.sqrt(t)*rng.normal(size=x.shape)
    base_dt = c['dt']

    def inner(y, t, steps, phase, adapt=True, retain=False):
        nonlocal x, lp, sc, base_dt
        cp, cs = conditional(lp, sc, x, y, t)
        # Guarded isotropic steps, no MAP/NUTS/GAD geometry. Freeze for output.
        dt = min(base_dt/(1+base_dt*t), .25*math.sqrt(dim)/max(float(np.linalg.norm(cs,axis=1).max()),1e-300))
        dt = max(dt, 1e-16); means = np.zeros_like(x); saved = []
        for i in range(steps):
            proposal = x+dt*cs+math.sqrt(2*dt)*rng.normal(size=x.shape)
            pp, ps = evaluate(proposal, phase)
            qp, qs = conditional(pp, ps, proposal, y, t)
            loga = qp-cp+(np.sum((proposal-x-dt*cs)**2,axis=1)-np.sum((x-proposal-dt*qs)**2,axis=1))/(4*dt)
            finite = np.isfinite(qp)&np.isfinite(qs).all(1)&np.isfinite(loga)
            clipped = np.where(finite,np.minimum(loga,0.),-np.inf)
            probability = np.exp(clipped)
            accept = np.log(rng.random(paths)) < clipped
            accepted_by_phase[phase] = accepted_by_phase.get(phase,0)+int(accept.sum())
            transitions_by_phase[phase] = transitions_by_phase.get(phase,0)+paths
            next_dt = dt
            if adapt:
                lengths = np.linalg.norm(proposal-x,axis=1)
                ratios = np.linalg.norm(qs-cs,axis=1)/np.maximum(lengths,1e-300)
                ratios = ratios[np.isfinite(ratios)&(ratios>0)]
                cap = .5/float(ratios.max()) if len(ratios) else dt*2
                p = float(probability.mean())
                next_dt = min(dt*(.1 if p<.05 else math.exp(min(1.,math.sqrt(5/(i+1)))*(p-c['target_accept']))),cap,c['dt']/(1+c['dt']*t))
            x = np.where(accept[:,None],proposal,x)
            lp = np.where(accept,pp,lp); sc = np.where(accept[:,None],ps,sc)
            cp = np.where(accept,qp,cp); cs = np.where(accept[:,None],qs,cs)
            means += x
            if retain: saved.append(x.copy())
            dt = max(next_dt,1e-16)
        if adapt:
            # Express the tested conditional step as a base step for the next t.
            base_dt = min(c['dt'],dt/max(1-dt*t,1e-12))
        schedule.append(dict(phase=phase,t=float(t),steps=steps,dt_final=dt))
        return np.stack(saved) if retain else means/max(steps,1)

    cursor = 0
    for _ in range(c['init_steps']):
        mean = inner(y,t,plan['inner_steps'][cursor],'initialization_inner'); cursor += 1
        # ULA for p_t, score = E[X|Y]-Y/t; reduced step avoids large init bias.
        lam = c['init_step_factor']*t
        y += lam*(mean-y/t)+math.sqrt(2*lam)*rng.normal(size=x.shape)
    times = np.geomspace(c['t_start'],c['t_end'],c['outer_steps']+1)
    for k, (t, next_t) in enumerate(zip(times[:-1],times[1:])):
        mean = inner(y,t,plan['inner_steps'][cursor],'localization_inner'); cursor += 1
        y += (next_t-t)*mean+math.sqrt(next_t-t)*rng.normal(size=x.shape)
        if progress: progress(k+1,c['outer_steps'])
    t = times[-1]
    if c['terminal_burnin']: inner(y,t,c['terminal_burnin'],'terminal_burnin')
    # Pooled conditional draws are explicit, with a frozen MALA kernel.
    draws = inner(y,t,plan['draws_per_path'],'terminal_sampling',adapt=False,retain=True)
    samples = draws.reshape(-1,dim)[:plan['output_samples']].copy()
    evaluations = sum(ledger.values()); actual = 2*evaluations
    if actual != plan['actual_proxy'] or actual > plan['target_proxy']: raise RuntimeError('SLIPS work ledger/plan mismatch')
    runtime = time.perf_counter()-started
    info = dict(method='slips',node='slips',n_samples=len(samples),
                pde_likelihood_evals=evaluations,pde_score_evals=evaluations,pde_gn_hessian_evals=0,
                pde_solve_count=actual,local_pde_solve_count=actual,
                target_slips_proxy=plan['target_proxy'],actual_slips_proxy=actual,
                slips_to_gad_proxy_ratio=actual/plan['target_proxy'],slips_budget_exceeded=False,
                slips_paths=paths,slips_draws_per_path=plan['draws_per_path'],
                slips_unique_fraction=len(np.unique(samples,axis=0))/len(samples),
                slips_acceptance_rate=accepted_by_phase.get('terminal_sampling',0)/max(1,transitions_by_phase.get('terminal_sampling',0)),
                slips_seed=seed,slips_output='terminal conditional draws; dependent within localization path',
                slips_budget_design='fresh independent run per GAD cumulative budget; other budget runs are separate experiments',
                runtime_seconds=runtime,local_runtime_seconds=runtime,
                work_ledger=ledger,acceptances=accepted_by_phase,proposals=transitions_by_phase,
                plan=plan,transition_schedule=schedule,configuration=c)
    state = dict(samples_by_draw_path=draws,terminal_y=y,terminal_t=np.asarray(t),
                 path_id=np.tile(np.arange(paths),plan['draws_per_path'])[:len(samples)],
                 rng_state_json=np.asarray(__import__('json').dumps(rng.bit_generator.state)))
    return samples, info, state
