"""Regression checks for the exact Python-3.9 installer failures in the shared thread."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import arviz_compat

FAKE_PYTHON='''#!/usr/bin/env python3
import json,os,pathlib,sys
args=sys.argv[1:]
diag=pathlib.Path(os.environ['GP_QA_DIAG'])
is_diag=pathlib.Path(sys.argv[0])==diag
with open(os.environ['GP_QA_CALLS'],'a') as f:f.write(json.dumps(dict(diag=is_diag,args=args))+'\\n')
if args[0]=='-':
    sys.stdin.read()
    pathlib.Path(args[1]).write_text('jax==0.4.30\\nnumpy==2.0.2\\n')
elif args[0]=='-c':
    if 'needs_isolated_arviz' in args[1]:print(1)
    elif 'diagnostics_python' in args[1]:print(diag)
    else:raise SystemExit('Unexpected Python command')
elif args[:2]==['-m','venv']:
    diag.parent.mkdir(parents=True,exist_ok=True)
    diag.write_text(pathlib.Path(sys.argv[0]).read_text());diag.chmod(0o755)
elif args[:2]==['-m','pip']:
    if is_diag and '--upgrade' in args and os.environ.get('GP_QA_FAIL_UPGRADE')=='1':raise SystemExit(3)
    if not is_diag:
        constraint=pathlib.Path(args[args.index('-c')+1]).read_text()
        assert 'jax==0.4.30' in constraint and 'numpy==2.0.2' in constraint
elif pathlib.Path(args[0]).name=='check_environment.py':
    assert os.environ.get('GP_DIAGNOSTICS_PYTHON')==str(diag)
elif pathlib.Path(args[0]).name=='ls6_cuda.py':
    assert args[1:]==['--repair']
else:raise SystemExit('Unexpected call: '+repr(args))
'''


class PackageCompatibilityTests(unittest.TestCase):
    def test_isolation_checks_loaded_numpy_and_distribution_metadata(self):
        for loaded,installed,expected in [('1.26.4','2.0.2',True),('2.0.2','1.26.4',True),
                                          ('2.0.2','2.0.2',True),('1.26.4','1.26.4',False)]:
            with self.subTest(loaded=loaded,installed=installed):
                fake=types.ModuleType('numpy');fake.__version__=loaded
                with patch.dict(sys.modules,numpy=fake),patch.object(arviz_compat.sys,'version_info',(3,9,25)),\
                     patch.object(arviz_compat.importlib.metadata,'version',return_value=installed):
                    self.assertEqual(arviz_compat.needs_isolated_arviz(),expected)
        with patch.object(arviz_compat.sys,'version_info',(3,12,14)):
            fake=types.ModuleType('numpy');fake.__version__='2.0.2'
            with patch.dict(sys.modules,numpy=fake):self.assertFalse(arviz_compat.needs_isolated_arviz())

    def installer(self,directory,existing=False,fail=False):
        root=Path(directory);bundle=root/'bundle';(bundle/'slurm').mkdir(parents=True)
        for name in ['install_reference_extras.sh','slurm/environment.sh','repair_ls6_cuda.sh']:shutil.copy2(ROOT/name,bundle/name)
        bin_dir=root/'bin';bin_dir.mkdir();main=bin_dir/'python';main.write_text(FAKE_PYTHON);main.chmod(0o755)
        diag=root/'diagnostics/bin/python'
        if existing:diag.parent.mkdir(parents=True);diag.write_text(FAKE_PYTHON);diag.chmod(0o755)
        calls=root/'calls.jsonl'
        env=dict(os.environ,PATH=str(bin_dir)+os.pathsep+os.environ['PATH'],GP_SKIP_MODULES='1',
                 GP_QA_DIAG=str(diag),GP_QA_CALLS=str(calls),GP_QA_FAIL_UPGRADE=str(int(fail)))
        result=subprocess.run(['bash',str(bundle/'install_reference_extras.sh')],env=env,capture_output=True,text=True)
        return result,[json.loads(line) for line in calls.read_text().splitlines()]

    def test_installer_bootstraps_pip_then_uses_pinned_wheels_for_new_and_existing_venvs(self):
        for existing in [False,True]:
            with self.subTest(existing=existing),tempfile.TemporaryDirectory() as directory:
                result,calls=self.installer(directory,existing=existing)
                self.assertEqual(result.returncode,0,result.stderr)
                self.assertIn('gad-ls6-reference-extras-1',result.stdout)
                main_pip=[r['args'] for r in calls if not r['diag'] and r['args'][:2]==['-m','pip']]
                self.assertEqual(len(main_pip),1)
                self.assertFalse(any('arviz' in arg for arg in main_pip[0]))
                diag=[r['args'] for r in calls if r['diag']]
                self.assertEqual(diag[0],['-m','pip','install','--upgrade','pip==25.3'])
                self.assertIn('--only-binary=:all:',diag[1])
                for pin in ['numpy==1.26.4','scipy==1.13.1','pandas==2.2.3','matplotlib==3.9.4',
                            'xarray==2024.7.0','xarray-einstats==0.7.0','arviz==0.17.1']:
                    self.assertIn(pin,diag[1])
                self.assertEqual(sum(r['args'][:2]==['-m','venv'] for r in calls),int(not existing))
                self.assertEqual(Path(calls[-1]['args'][0]).name,'check_environment.py')

    def test_installer_stops_if_diagnostics_pip_upgrade_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            result,calls=self.installer(directory,fail=True)
            self.assertEqual(result.returncode,3)
            self.assertFalse(any('--only-binary=:all:' in r['args'] for r in calls))
            self.assertFalse(any(Path(r['args'][0]).name=='check_environment.py' for r in calls))


if __name__=='__main__':unittest.main()
