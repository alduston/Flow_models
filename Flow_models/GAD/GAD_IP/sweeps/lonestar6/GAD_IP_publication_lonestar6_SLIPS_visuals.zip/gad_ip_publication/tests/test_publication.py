import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import (digest, fields_from_latents, read_json, run_directory, save_npz, settings,
                    signature, verified_reference, write_json)
from comparison import mmd2,predictive_metrics_scaled,sliced_w2
from aggregate_publication import bootstrap,collect,paired_rows
from workflow import freeze,verify_frozen
from fixtures import synthetic_batch


class NumericalTests(unittest.TestCase):
    def test_unequal_empirical_wasserstein_exact_integral(self):
        # F_X^-1 is 0 then 2; F_Y^-1 is constantly 1, hence W2=1.
        self.assertAlmostEqual(sliced_w2(np.array([[0.],[2.]]),np.array([[1.],[1.],[1.]]),np.ones((1,1))),1.)
        self.assertAlmostEqual(sliced_w2(np.array([[0.]]),np.array([[3.],[4.]]),np.ones((1,1))),np.sqrt(12.5))

    def test_unbiased_mmd_retains_negative_values(self):
        a=np.array([[0.],[1.],[2.]])
        self.assertLess(mmd2(a,a),0)

    def test_noise_relative_predictive_score_scale_behavior(self):
        rng=np.random.default_rng(55);pred=rng.normal(0,.1,(100,3));obs=np.array([.1,0,-.1]);clean=np.array([.2,.3,.4])
        a=predictive_metrics_scaled(pred,obs,clean,.01);b=predictive_metrics_scaled(pred*1e-5,obs*1e-5,clean*1e-5,.01*1e-5)
        self.assertAlmostEqual(b['ScaledHeldoutPredNLL']-a['ScaledHeldoutPredNLL'],np.log(1e-5),places=9)
        self.assertAlmostEqual(a['HeldoutCleanRelL2'],b['HeldoutCleanRelL2'],places=10)

    def test_nonlinear_field_mean_is_not_field_at_mean(self):
        spec=dict(problem=np.asarray('afwi'),grid=np.asarray(1),basis=np.ones((1,1)),mask=np.ones((1,1)),scale=np.asarray(.8),background=np.asarray(1.))
        a=np.array([[-1.],[1.]])
        self.assertGreater(float(fields_from_latents(a,spec).mean()),fields_from_latents(a.mean(0)[None],spec)[0].item())

    def test_paired_seed_bootstrap_preserves_constant_differences(self):
        config=read_json(ROOT/'settings.json');rows=[]
        for s in config['sampler_seeds']:
            rows += [dict(problem='afwi',sampler_seed=s,method='GAD-1',RMSE_field=float(s)),
                     dict(problem='afwi',sampler_seed=s,method='MALA-1',RMSE_field=float(s)+3)]
        item=next(r for r in paired_rows(rows,config,'afwi') if r['metric']=='RMSE_field' and r['baseline']=='MALA-1')
        self.assertEqual(item['mean_difference'],-3);self.assertEqual(item['ci_low'],-3);self.assertEqual(item['ci_high'],-3)
        self.assertEqual(item['gad_wins'],10)


class ProvenanceTests(unittest.TestCase):
    def test_original_source_hashes_and_generic_routines_preserved(self):
        from cache import kernel_digest
        for name,sha in read_json(ROOT/'provenance/source_hashes.json').items():
            actual=kernel_digest(ROOT/name) if name=='vendor/screening/protocol.py' else digest(ROOT/name)
            self.assertEqual(actual,sha,name)
        original=ast.parse((ROOT/'provenance/darcy_nuts_original.py').read_text());current=ast.parse((ROOT/'reference_core.py').read_text())
        for new in current.body:
            if isinstance(new,ast.FunctionDef):
                old=next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name==new.name)
                self.assertEqual(ast.dump(old),ast.dump(new),new.name)

    def test_frozen_config_mutation_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            batch=freeze(ROOT/'settings.json',Path(d)/'batch')
            verify_frozen(batch)
            config=settings(batch);config['data_seed']=43;write_json(batch/'settings.json',config)
            with self.assertRaisesRegex(ValueError,'Frozen settings'):verify_frozen(batch)


class IdentityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.batch=synthetic_batch(cls.temp.name)

    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()

    def test_complete_collection_then_missing_seed_not_publication_ready(self):
        config=settings(self.batch);rows,manifest,quality,missing,ready=collect(self.batch,config,['afwi'])
        self.assertEqual(len(rows),80);self.assertEqual(ready,['afwi']);self.assertFalse(missing)
        path=run_directory(self.batch,'afwi',51)/'publication_identity.json';original=path.read_bytes();path.unlink()
        try:
            rows,manifest,quality,missing,ready=collect(self.batch,config,['afwi'])
            self.assertEqual(ready,[]);self.assertEqual(sum(r['complete'] for r in manifest),9)
        finally:path.write_bytes(original)

    def test_changed_reference_and_uncertified_cloud_rejected(self):
        directory=self.batch/'reference/afwi';path=directory/'nuts_diagnostics.json';original=path.read_bytes()
        quality=read_json(path);quality['certified']=False;write_json(path,quality)
        try:
            with self.assertRaisesRegex(ValueError,'checks failed'):verified_reference(self.batch,'afwi')
        finally:path.write_bytes(original)
        samples=directory/'reference_samples.npz';original=samples.read_bytes()
        try:
            with samples.open('ab') as f:f.write(b'changed')
            with self.assertRaisesRegex(ValueError,'bytes changed'):verified_reference(self.batch,'afwi')
        finally:samples.write_bytes(original)


class ChainRestartTests(unittest.TestCase):
    def test_actual_numpyro_resume_matches_uninterrupted_and_rejects_changed_settings(self):
        import jax
        import jax.numpy as jnp
        from reference import run_chunked_chain
        jax.config.update('jax_enable_x64',True)
        config=dict(num_warmup=25,num_samples=24,chunk_size=8,target_accept=.9,max_tree_depth_warmup=4,max_tree_depth=5,sampler_seed=551)
        energy=lambda z:.5*jnp.sum(z*z)
        with tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
            self.assertIsNone(run_chunked_chain(energy,np.zeros(2),a,config,0,'qa',stop_after_chunks=1))
            resumed=run_chunked_chain(energy,np.zeros(2),a,config,0,'qa')
            direct=run_chunked_chain(energy,np.zeros(2),b,config,0,'qa')
            np.testing.assert_array_equal(resumed['z_samples'],direct['z_samples'])
            changed=dict(config,target_accept=.95)
            with self.assertRaisesRegex(ValueError,'Incompatible checkpoint'):
                run_chunked_chain(energy,np.zeros(2),a,changed,0,'qa')


class ReferenceWorkflowTests(unittest.TestCase):
    def test_failed_certification_withdraws_canonical_reference(self):
        from arviz_compat import load_arviz
        load_arviz()
        from reference import certify
        with tempfile.TemporaryDirectory() as d:
            batch=synthetic_batch(d);out=batch/'reference/afwi'
            samples=np.load(out/'reference_samples.npz')['samples_by_chain']
            save_npz(out/'setup.npz',position=np.zeros(6))
            setup_sha=digest(out/'setup.npz');write_json(out/'setup.json',dict(setup_sha256=setup_sha))
            identity=signature(dict(target=read_json(out/'target.json')['fingerprint'],setup=setup_sha));rng=np.random.default_rng(5)
            for i in range(4):
                path=out/'chains'/f'chain_{i}.npz';size=len(samples[i])
                save_npz(path,samples=samples[i],z_samples=samples[i],diverging=np.zeros(size,dtype=bool),
                         potential_energy=(samples[i]**2).sum(1)/2,energy=rng.chisquare(6,size),
                         accept_prob=np.ones(size)*.95,num_steps=np.ones(size,dtype=int)*7,
                         **{'adapt_state.step_size':np.ones(size)*.2})
                write_json(path.with_suffix('.json'),dict(identity=identity,sha256=digest(path),elapsed_seconds=1,
                                                        mass_mode=settings(batch)['nuts'].get('mass_mode','dense')))
            with self.assertRaisesRegex(RuntimeError,'NUTS checks failed'):certify(batch,'afwi')
            self.assertFalse((out/'reference_samples.npz').exists())
            self.assertTrue((out/'reference_samples_uncertified.npz').exists())
            self.assertFalse(read_json(out/'nuts_diagnostics.json')['certified'])

    def test_extended_reference_fork_reuses_only_canonical_runs(self):
        with tempfile.TemporaryDirectory() as d:
            old=synthetic_batch(d);config=settings(old);config['nuts']['num_samples']=200
            path=Path(d)/'extended.json';write_json(path,config)
            new=freeze(path,Path(d)/'new',reuse_runs=old)
            run=run_directory(new,'afwi',42)
            self.assertTrue((run/'samples_all_rounds.npz').exists())
            self.assertFalse((run/'publication_metrics.json').exists())
            self.assertEqual(digest(run/'samples_all_rounds.npz'),digest(run_directory(old,'afwi',42)/'samples_all_rounds.npz'))
            config['data_seed']=43;write_json(path,config)
            with self.assertRaisesRegex(ValueError,'changed data_seed'):freeze(path,Path(d)/'invalid',reuse_runs=old)


if __name__=='__main__':unittest.main()
