"""Exercise CUDA repair preservation and the destructive restart order with fakes."""
from pathlib import Path
import shutil
import socket
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import read_json,write_json
import ls6_cuda
import restart_slips_lonestar6 as launcher
from workflow import freeze


class CUDARepairTests(unittest.TestCase):
    def stack(self):
        return dict(jax='0.4.30',jaxlib='0.4.30',torch='2.8.0',numpy='2.0.2',
                    scipy='1.13.1',numpyro='0.19.0',**ls6_cuda.PINS)

    def test_installed_repair_never_reinstalls_the_stack(self):
        stack=self.stack()
        with patch.object(ls6_cuda,'installed_packages',return_value=stack),patch.object(ls6_cuda.subprocess,'run') as run:
            ls6_cuda.repair()
        self.assertEqual(run.call_count,1)
        self.assertEqual(run.call_args.args[0][-1],'--check-binding')

    def test_only_missing_pinned_wheels_are_installed_without_dependencies(self):
        after=self.stack();before={k:v for k,v in after.items() if k!='jax-cuda12-plugin'}
        with patch.object(ls6_cuda,'installed_packages',side_effect=[before,after]),patch.object(ls6_cuda.subprocess,'run') as run:
            ls6_cuda.repair()
        cmd=run.call_args_list[0].args[0]
        self.assertIn('--no-deps',cmd);self.assertIn('--only-binary=:all:',cmd)
        self.assertEqual([x for x in cmd if '==' in x],['jax-cuda12-plugin==0.4.30'])

    def test_incompatible_stack_is_rejected_before_install(self):
        for changes in [dict(jax='0.5.0'),{'jax-cuda12-plugin':'0.5.0'}]:
            with patch.object(ls6_cuda,'installed_packages',return_value=dict(self.stack(),**changes)),patch.object(ls6_cuda.subprocess,'run') as run:
                with self.assertRaises(RuntimeError):ls6_cuda.repair()
                run.assert_not_called()

    def test_preflight_detects_original_missing_packages_and_bad_binding(self):
        with patch.object(ls6_cuda,'installed_packages',return_value=dict(jax='0.4.30',jaxlib='0.4.30')):
            with self.assertRaisesRegex(RuntimeError,'repair_ls6_cuda.sh'):ls6_cuda.check_packages()
        with patch.object(ls6_cuda,'check_packages',return_value=self.stack()),patch('jax._src.lib.cuda_versions',None):
            with self.assertRaisesRegex(RuntimeError,'cuda_versions is None'):ls6_cuda.check_binding()


class RestartTests(unittest.TestCase):
    def test_stops_watcher_cancels_all_drains_repairs_then_launches_with_reuse(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);bundle=base/'sweeps/lonestar6/gad_ip_publication'
            shutil.copytree(ROOT,bundle,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
            old=freeze(ROOT/'settings.json',base/'old',['allen_cahn'])
            new=base/'new';log=bundle.parent/'old_submit.log'
            Path(str(log)+'.host').write_text(socket.gethostname())
            marker=old/'saved-result.npz';marker.write_bytes(b'preserve completed outputs')
            events=[]
            def run(cmd,**kw):events.append(cmd);return SimpleNamespace(returncode=0)
            def cancel(pid,sig):events.append(['stop-watcher',pid])
            def active(user):
                self.assertEqual(user,'qa-user');events.append(['squeue']);return ['3538967'] if len(events)<3 else []
            with patch.object(launcher,'ROOT',bundle),patch.object(launcher,'watcher_pids',return_value=[(123456,old)]),\
                 patch.object(launcher.os,'kill',side_effect=cancel),patch.object(launcher.getpass,'getuser',return_value='qa-user'),\
                 patch.object(launcher,'active_jobs',side_effect=active),patch.object(launcher.subprocess,'run',side_effect=run),\
                 patch.object(launcher.subprocess,'Popen',return_value=SimpleNamespace(pid=987654)) as popen:
                launcher.restart(old,new,log,cancel_all=True)
            self.assertEqual(events[0],['stop-watcher',123456])
            self.assertEqual(events[2],['scancel','--user','qa-user'])
            self.assertEqual(events[3],['squeue'])
            self.assertEqual(events[4][-1],'--repair')
            self.assertEqual(events[5][-1],'--imports-only')
            launch=events[6]
            self.assertIn('--resume-batch',launch);self.assertIn(str(new),launch)
            self.assertIn(str(old),launch);self.assertIn('--retry-failed',launch)
            self.assertEqual(marker.read_bytes(),b'preserve completed outputs')
            self.assertTrue(read_json(new/'settings.json')['slips']['enabled'])
            self.assertEqual(read_json(new/'batch.json')['workflow_version'],2)
            self.assertEqual(popen.call_args.kwargs['start_new_session'],True)
            self.assertEqual(popen.call_args.args[0][-1],'--watch')
            self.assertEqual((bundle.parent/'new_submit.log.pid').read_text().strip(),'987654')

    def test_explicit_all_user_job_flag_is_required(self):
        with patch.object(launcher.subprocess,'run') as run:
            with self.assertRaisesRegex(ValueError,'cancel-all-user-jobs'):
                launcher.restart('/old','/new','/old.log')
            run.assert_not_called()


if __name__=='__main__':unittest.main()
