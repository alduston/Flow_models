"""Fixed MAP metric, old-output reuse and scratch diagnostics compatibility."""
import copy
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from cache import adopt_reference,chain_valid,reference_valid,reference_key,run_key,target_key
from common import digest,read_json,run_directory,settings,write_json
from fixtures import synthetic_batch
from workflow import freeze
import test_incremental as incremental


class FixedMassTests(unittest.TestCase):
    setUp=incremental.IncrementalTests.setUp
    tearDown=incremental.IncrementalTests.tearDown
    cli=incremental.IncrementalTests.cli
    commands=incremental.IncrementalTests.commands

    def legacy(self):
        old=synthetic_batch(self.base)
        c=settings(old);c['nuts'].pop('mass_mode',None);write_json(old/'settings.json',c)
        shutil.copy2(ROOT/'provenance/fixed_mass_before/reference.py',old/'code/reference.py')
        out=old/'reference/afwi'
        for p in (out/'chains').glob('*.json'):
            r=read_json(p);r.pop('mass_mode',None);write_json(p,r)
        r=read_json(out/'nuts_diagnostics.json');r['thresholds']=c['nuts'];write_json(out/'nuts_diagnostics.json',r)
        return old

    def test_changed_metric_reuses_prepared_target_and_runs_across_clusters_without_live_ids(self):
        old=self.legacy();c=settings(old)
        c['slurm'].update(cluster='vista',partition='gh');write_json(old/'settings.json',c)
        meta=read_json(old/'batch.json');meta['scheduler_cluster']='vista';write_json(old/'batch.json',meta)
        shutil.rmtree(run_directory(old,'afwi',43))
        write_json(old/'jobs.json',{'afwi-repeat-43':dict(id='99977'),'afwi-chain-0':dict(id='99978')})
        write_json(self.states,{'99977':'PENDING','99978':'PENDING'})
        new=copy.deepcopy(c);new['nuts']['mass_mode']='fixed'
        new['slurm']=settings(ROOT)['slurm'];cfg=self.base/'fixed.json';write_json(cfg,new)
        batch=self.base/'ls6';self.env['TACC_SYSTEM']='ls6'
        self.cli('--batch',batch,'--config',cfg,'--reuse-from',old)
        nodes={n['key']:n for n in read_json(batch/'submission_plan.json')['nodes']}
        self.assertEqual(nodes['afwi-prepare']['state'],'cached')
        self.assertEqual(nodes['afwi-repeat-42']['state'],'cached')
        self.assertEqual(nodes['afwi-repeat-43']['state'],'submitted')
        self.assertNotIn('99977',nodes['afwi-repeat-43']['job_ids'])
        for i in range(4):self.assertEqual(nodes['afwi-chain-'+str(i)]['state'],'submitted')
        self.assertFalse((batch/'reference/afwi/checkpoints').exists())
        self.assertFalse((batch/'reference/afwi/chains').exists())
        self.assertFalse((batch/'reference/afwi/reference_samples.npz').exists())
        for name in ['target_arrays.npz','setup.npz']:
            self.assertEqual(digest(batch/'reference/afwi'/name),digest(old/'reference/afwi'/name))
        self.assertEqual(digest(run_directory(batch,'afwi',42)/'samples_all_rounds.npz'),
                         digest(run_directory(old,'afwi',42)/'samples_all_rounds.npz'))

    def test_driver_tuning_preserves_sampler_identity_and_changed_potential_invalidates(self):
        old=self.legacy();c=settings(old);new=copy.deepcopy(c);new['nuts']['mass_mode']='fixed'
        self.assertEqual(run_key(c,'afwi',42,old/'code'),run_key(new,'afwi',42,ROOT))
        self.assertNotEqual(reference_key(c,'afwi',old/'code'),reference_key(new,'afwi',ROOT))
        p=old/'code/reference.py';p.write_text(p.read_text().replace('return .5*jnp.vdot','return .6*jnp.vdot'))
        self.assertNotEqual(target_key(c,'afwi',old/'code'),target_key(new,'afwi',ROOT))

    def test_mass_configuration_rejects_old_dense_completed_reference(self):
        old=self.legacy();self.assertTrue(chain_valid(old,'afwi',0));self.assertTrue(reference_valid(old,'afwi'))
        c=settings(old);c['nuts']['mass_mode']='fixed';write_json(old/'settings.json',c)
        self.assertFalse(chain_valid(old,'afwi',0));self.assertFalse(reference_valid(old,'afwi'))

    def test_incomplete_runtime_checkpoints_stay_on_their_cluster(self):
        old=synthetic_batch(self.base);c=settings(old)
        c['slurm'].update(cluster='vista',partition='gh');write_json(old/'settings.json',c)
        meta=read_json(old/'batch.json');meta['scheduler_cluster']='vista';write_json(old/'batch.json',meta)
        out=old/'reference/afwi';(out/'chains/chain_0.npz').unlink();(out/'chains/chain_0.json').unlink()
        checkpoint=out/'checkpoints/chain_0';checkpoint.mkdir(parents=True)
        (checkpoint/'warmup.pkl').write_bytes(b'foreign-runtime-state')
        new=copy.deepcopy(c);new['slurm']=settings(ROOT)['slurm'];cfg=self.base/'fixed.json';write_json(cfg,new)
        batch=freeze(cfg,self.base/'ls6',['afwi'])
        adopt_reference(batch,'afwi',[old],chain_indices=[0],include_reference=False)
        self.assertTrue((batch/'reference/afwi/setup.npz').exists())
        self.assertFalse((batch/'reference/afwi/checkpoints/chain_0').exists())


class FixedKernelAndEnvironmentTests(unittest.TestCase):
    def test_fixed_chunk_resume_is_identical_and_rejects_changed_mass_mode(self):
        import jax
        import jax.numpy as jnp
        import numpy as np
        from reference import run_chunked_chain
        jax.config.update('jax_enable_x64',True)
        c=dict(mass_mode='fixed',num_warmup=25,num_samples=16,chunk_size=8,target_accept=.95,
               max_tree_depth_warmup=4,max_tree_depth=5,sampler_seed=551)
        energy=lambda z:.5*jnp.sum(z*z)
        with tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
            self.assertIsNone(run_chunked_chain(energy,np.zeros(2),a,c,0,'qa',stop_after_chunks=1))
            resumed=run_chunked_chain(energy,np.zeros(2),a,c,0,'qa')
            direct=run_chunked_chain(energy,np.zeros(2),b,c,0,'qa')
            np.testing.assert_array_equal(resumed['z_samples'],direct['z_samples'])
            with self.assertRaisesRegex(ValueError,'Incompatible checkpoint'):
                run_chunked_chain(energy,np.zeros(2),a,dict(c,mass_mode='dense'),0,'qa')

    def test_default_diagnostics_lookup_follows_existing_scratch_symlink(self):
        from arviz_compat import diagnostics_python
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);gpu=root/'work/flow_ls6_py39';gpu.mkdir(parents=True)
            scratch=root/'scratch/venvs/flow_ls6_py39_gad_diagnostics';(scratch/'bin').mkdir(parents=True)
            (scratch/'bin/python').symlink_to(sys.executable)
            expected=Path(str(gpu)+'_gad_diagnostics');expected.symlink_to(scratch,target_is_directory=True)
            env=dict(os.environ);env.pop('GP_DIAGNOSTICS_PYTHON',None)
            with patch.dict(os.environ,env,clear=True),patch.object(sys,'prefix',str(gpu)):
                self.assertTrue(diagnostics_python().is_file())
                self.assertEqual(diagnostics_python().resolve(),Path(sys.executable).resolve())


if __name__=='__main__':unittest.main()
