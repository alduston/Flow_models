"""Kaggle runner/embedded-source parity and conservative prior-reference reuse."""
import base64,gzip,importlib.util,json,re,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from common import digest,read_json,write_json
from fixtures import synthetic_batch
from workflow import freeze
spec=importlib.util.spec_from_file_location('slips_preview_runner',ROOT/'kaggle/run_gad_kaggle_preview.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)


class PreviewTests(unittest.TestCase):
    def test_notebook_embeds_exact_runner_and_requested_settings(self):
        notebook=read_json(ROOT/'kaggle/GAD_IP_Kaggle_SLIPS_preview.ipynb')
        boot=''.join(notebook['cells'][2]['source'])
        encoded=re.search('"""(.*?)"""',boot,re.S).group(1)
        self.assertEqual(gzip.decompress(base64.b64decode(encoded)),Path(runner.__file__).read_bytes())
        command=''.join(notebook['cells'][8]['source'])
        self.assertIn('"--helmholtz-particles", "1500"',command)
        self.assertIn('"--rounds", "4", "--particles", "200"',command)
        for cell in notebook['cells']:
            if cell['cell_type']=='code':compile(''.join(cell['source']),'<notebook>','exec')

    def test_unchanged_nuts_reuses_across_plot_and_slips_source_changes(self):
        with tempfile.TemporaryDirectory() as tmp:
            old=synthetic_batch(tmp,rounds=1)
            write_json(old/'preview.json',dict(runtime=runner.versions()))
            (old/'preview_runner.py').write_text(Path(runner.__file__).read_text().replace("kaggle-slips-preview-2","kaggle-preview-1"))
            # The former exact-full-manifest check rejected this benign edit.
            plot=old/'code/plotting.py';plot.write_text(plot.read_text()+'\n# Older plotting revision\n')
            hashes={str(p.relative_to(old/'code')):digest(p) for p in (old/'code').rglob('*') if p.is_file()}
            write_json(old/'source_manifest.json',hashes)
            cfg=read_json(old/'settings.json');cfg['slips']['enabled']=True
            config=Path(tmp)/'new.json';write_json(config,cfg)
            batch=freeze(config,Path(tmp)/'new',['afwi'])
            runner.reuse_reference(batch,old)
            self.assertEqual(digest(batch/'reference/afwi/setup.npz'),digest(old/'reference/afwi/setup.npz'))
            self.assertTrue((batch/'stages/afwi-prepare-0.json').exists())
            self.assertFalse((batch/'runs').exists())
            # Actual numerical reference dependency changes must still refuse.
            core=old/'code/reference_core.py';core.write_text(core.read_text()+'\n# Changed reference source\n')
            hashes['reference_core.py']=digest(core);write_json(old/'source_manifest.json',hashes)
            another=freeze(config,Path(tmp)/'another',['afwi'])
            runner.reuse_reference(another,old)
            self.assertFalse((another/'reference/afwi/setup.npz').exists())

if __name__=='__main__':unittest.main()
