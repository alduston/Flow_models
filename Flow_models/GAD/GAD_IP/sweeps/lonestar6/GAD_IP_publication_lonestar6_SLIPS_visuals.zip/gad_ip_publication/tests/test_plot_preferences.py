"""Publication display preferences; no sampler or metric changes."""
import sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from common import digest,load_npz,read_json,run_directory
from fixtures import synthetic_batch
import plotting

class PlotPreferences(unittest.TestCase):
    def test_histograms_use_same_deterministic_count_without_modifying_samples(self):
        with tempfile.TemporaryDirectory() as tmp:
            batch=synthetic_batch(tmp,rounds=2);d=run_directory(batch,'afwi',42)
            paths=[d/'samples_all_rounds.npz',batch/'reference/afwi/reference_samples.npz']
            before=[digest(path) for path in paths]
            out=Path(tmp)/'figures';captions={};seen=[]
            original=np.histogram2d
            def record(x,y,*args,**kwargs):
                seen.append(len(x));return original(x,y,*args,**kwargs)
            def inspect(fig,name,*args):
                titles=[ax.get_title() for ax in fig.axes]
                self.assertIn('MALA',titles);self.assertNotIn('MALA-2',titles)
                plotting.plt.close(fig)
            with patch.object(np,'histogram2d',record),patch.object(plotting,'finish',inspect):
                plotting.pca_maps(batch,'afwi',42,2,out,None,65,captions)
            self.assertTrue(seen);self.assertEqual(set(seen),{80})
            self.assertEqual(before,[digest(path) for path in paths])
            selection=read_json(out/'posterior_histogram_selection.json')
            self.assertEqual(selection['particles_per_method'],80)
            self.assertEqual(selection['available_particles']['NUTS'],400)
            indices=load_npz(out/'posterior_histogram_indices.npz')
            self.assertEqual(len(np.unique(indices['NUTS'])),80)
            with patch.object(plotting,'finish',inspect):
                plotting.pca_maps(batch,'afwi',42,2,out,None,65,{})
            again=load_npz(out/'posterior_histogram_indices.npz')
            for label in indices:np.testing.assert_array_equal(indices[label],again[label])

    def test_allen_cahn_traces_saved_separately_from_dashboard_and_paper_figures(self):
        with tempfile.TemporaryDirectory() as tmp:
            batch=synthetic_batch(tmp,problem='allen_cahn',rounds=1)
            out=Path(tmp)/'paper_figures';dashboard=object();captions={};calls=[]
            def finish(fig,name,destination,pdf,dpi,registry,caption):
                calls.append((name,Path(destination),pdf));registry[name]=caption
                Path(destination).mkdir(parents=True,exist_ok=True)
                plotting.plt.close(fig)
            with patch.object(plotting,'finish',finish):
                plotting.reference_plots(batch,'allen_cahn',out,dashboard,65,captions)
            trace=next(row for row in calls if row[0]=='nuts_traces')
            self.assertEqual(trace[1],batch/'reference/allen_cahn/diagnostic_figures')
            self.assertIsNone(trace[2]);self.assertNotIn('nuts_traces',captions)
            self.assertIn('nuts_monte_carlo_uncertainty',captions)
            self.assertTrue((batch/'reference/allen_cahn/diagnostic_figures/captions.json').exists())
            self.assertTrue((batch/'reference/allen_cahn/chain_diagnostics.npz').exists())
            self.assertTrue((batch/'reference/allen_cahn/nuts_diagnostics.json').exists())

if __name__=='__main__':unittest.main()
