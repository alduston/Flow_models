"""Small CPU bridge smoke on the actual frozen PDE; no NUTS/reference claim."""
import argparse
import json
from pathlib import Path
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import (load_model,model_data,physical_spec,read_json,save_npz,write_json,digest,load_npz,run_directory)
from workflow import freeze
from target_snapshot import capture_preparation
from slips_comparison import execute,valid


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--problem',required=True,choices=['allen_cahn','navier_stokes','helmholtz']);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();args.output.mkdir(parents=True)
    c=read_json(ROOT/'settings.json');c['active_problems']=[args.problem];c['sampler_seeds']=[42];c['aggregation']['illustration_seed']=42
    c['problems'][args.problem].update(particles=64,rounds=1);c['sampler'].update(rounds=1,eval_particles=64)
    write_json(args.output/'config.json',c)
    # freeze's publication minimum applies to NUTS, not number of sampler seeds.
    batch=freeze(args.output/'config.json',args.output/'batch',[args.problem])
    out=batch/'reference'/args.problem
    model=load_model(args.problem,42,args.output/'model')
    metadata,arrays,fingerprint=model_data(args.problem,model,42)
    write_json(out/'target.json',dict(metadata=metadata,fingerprint=fingerprint));save_npz(out/'target_arrays.npz',**arrays)
    save_npz(out/'physical_spec.npz',**physical_spec(args.problem,model))
    import jax.numpy as jnp
    zero=jnp.zeros(model.ACTIVE_DIM);residual=(model.solve_forward(zero)-model.y_obs_np)/model.NOISE_STD
    energy=float(.5*jnp.vdot(zero,zero)+.5*jnp.vdot(residual,residual))
    save_npz(out/'setup.npz',map_position=np.asarray(zero),map_energy=np.asarray(energy))
    write_json(out/'setup.json',dict(fingerprint=fingerprint,setup_sha256=digest(out/'setup.npz'),qa_only=True))
    capture_preparation(out,args.problem,model,metadata,fingerprint)
    execute(batch,args.problem,42,allow_cpu=True)
    assert valid(batch,args.problem,42)
    directory=run_directory(batch,args.problem,42)/'slips'
    record=read_json(directory/'identity.json');cloud=load_npz(directory/'samples_all_rounds.npz')['SLIPS-1']
    checksums={name:digest(directory/name) for name in record['files']}
    execute(batch,args.problem,42,allow_cpu=True)
    assert checksums=={name:digest(directory/name) for name in record['files']}
    # Emulate a timeout after sampling but before finishing metric writes.
    (directory/'identity.json').unlink();write_json(directory/'status.json',dict(state='running'))
    execute(batch,args.problem,42,allow_cpu=True)
    assert valid(batch,args.problem,42)
    assert checksums['SLIPS-1.npz']==digest(directory/'SLIPS-1.npz')
    print(json.dumps(dict(problem=args.problem,shape=list(cloud.shape),work=read_json(directory/'run_info.json')['SLIPS-1']['pde_solve_count'],target=192,
                         finite=bool(np.isfinite(cloud).all()),restart_reuses_cloud=True,qa_only=True)))

if __name__=='__main__':main()
