# GAD / MALA / SLIPS publication bundle — Lonestar6

This ports the supplied Vista `SLIPS_visuals` revision onto the supplied LS6 fixed-mass bundle. Start with [RUN_ON_LONESTAR6.md](RUN_ON_LONESTAR6.md) for the all-job cancellation and detached relaunch command. The archive retains the `gad_ip_publication/` directory layout; completed campaign directories remain beside it.

## Scientific and display changes

The SLIPS implementation, comparison/evaluation modules and plotting module are copied byte for byte from the supplied Vista archive. SLIPS is a separate stage per problem/seed, with exact charged derivative-work ledgers and conservative identity-based reuse. Evaluation waits for all three methods and the NUTS reference. See [SLIPS_COMPARISON.md](SLIPS_COMPARISON.md) for the documented terminal-conditional variant, its dependent samples, initialization and proxy accounting; it is not a claim of independently repeated canonical SLIPS or tuned optimal performance.

[PLOT_PREFERENCES.md](PLOT_PREFERENCES.md) records plain MALA/SLIPS panel titles, captions matched to the cumulative GAD budget, equal particle counts in every displayed PCA histogram, saved selection indices and separate Allen–Cahn trace diagnostics. Full metric populations and raw samples are retained. The companion Kaggle notebook/runner is unchanged from Vista; it is optional and is not an LS6 launch path.

| Setting | LS6 default retained |
| --- | --- |
| Active problems | Navier–Stokes, Allen–Cahn, Helmholtz |
| Particles/bank | 1,000 / 1,000 / 2,000 respectively |
| GAD rounds / initial sampler repeats | 5 / 5 (seeds 42–46) |
| Data seed | 42, shared across sampler repeats |
| NUTS | Four chains, 3,000 warmup + 5,000 retained per chain |
| NUTS metric | Fixed identity after MAP-Hessian whitening; adapted step size |
| Chain / SLIPS reservations | 12 hours / 1 hour |
| Modules | gcc/11.2.0, python3/3.9.7 |
| GPU venv | /work/10812/ald4435/ls6/venvs/flow_ls6_py39 |
| Cluster / account / partition | ls6 / DMS22021 / gpu-a100 |

AFWI remains an explicit reserve at 300 particles/four rounds. Exact targets, PDEs, GAD/MALA kernels, fixed-mass NUTS and strict certification thresholds are unchanged. Scientific sources and parent-archive identities are recorded in `provenance/ls6_slips_port.json`. [METHODS_AND_OUTPUTS.md](METHODS_AND_OUTPUTS.md) and [FIXED_MASS_UPDATE.md](FIXED_MASS_UPDATE.md) supply reference details.

## CUDA repair and existing installation

The Oct-28 `gp-preflight` failure lacked the JAX CUDA plugin/PJRT/compiler support. The restart command applies [repair_ls6_cuda.sh](repair_ls6_cuda.sh), adding only missing `jax-cuda12-plugin==0.4.30`, `jax-cuda12-pjrt==0.4.30` and `nvidia-cuda-nvcc-cu12==12.8.93` binary wheels with `--no-deps`. Matching installed packages are skipped. Incompatible installed versions stop the launcher. No numerical framework is upgraded or reinstalled.

Your existing Python 3.9/NumPy 2 environment and isolated ArviZ 0.17.1/NumPy 1.26.4 diagnostics symlink remain in use. There is no need to rerun `install_reference_extras.sh`. That full installer remains available for a new installation and now invokes the same CUDA repair. Package installation occurs only on the login node. The allocated preflight must still establish GPU functionality before scientific work.

## Scheduler and reuse

The unchanged global outstanding-task cap is 32. Configured partition caps are A100 28, A100-small 10, A100-dev 2 and H100 4; counts include unrelated user jobs and expanded arrays. Configured account, partition availability checks and cluster identity guards are retained. One node/task and one visible GPU are preserved from the working LS6 scripts.

Completed compatible output files can cross clusters; live Slurm IDs and unfinished runtime checkpoints cannot. GAD/MALA reuse retains the exact Python 3.9 annotation normalization. All three-method evaluations/report figures are rebuilt where the new baseline changes their identity. Cancelled old tasks do not contaminate new batch state.

A fully fresh three-problem/five-seed graph has **65 tasks** and **196.33 reserved node-hours** before reuse: the previous graph plus 15 one-hour SLIPS jobs. Reservations are not runtime measurements. [SUBMISSION_WATCHER.md](SUBMISSION_WATCHER.md) covers deferred submission, reconnects and explicit retries; [VALIDATION.md](VALIDATION.md) records tests and limitations. Final completion requires certified NUTS references and all requested sampler/SLIPS evaluations.
