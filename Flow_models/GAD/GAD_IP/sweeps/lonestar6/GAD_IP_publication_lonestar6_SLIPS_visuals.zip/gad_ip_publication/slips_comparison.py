"""Independent SLIPS stage: preserve canonical GAD/MALA outputs and reuse."""
from pathlib import Path
import shutil
import time
import numpy as np
from common import (ROOT, check_target, digest, load_model, load_npz, read_json,
                    run_directory, sampler_settings, save_npz, screen_imports,
                    settings, signature, write_json)
from slips_core import configuration, allocate, run


def enabled(config):
    return bool(config.get('slips', {}).get('enabled', False))


def labels(config, problem):
    algorithms = ['GAD','MALA']+(['SLIPS'] if enabled(config) else [])
    rounds = config['problems'][problem].get('rounds',config['sampler']['rounds'])
    return {f'{a}-{r}' for a in algorithms for r in range(1,rounds+1)}


def key(config, problem, seed, code=ROOT):
    from cache import target_key
    c = configuration(config.get('slips'))
    return signature(dict(target=target_key(config,problem,code),seed=seed,
        settings=vars(sampler_settings(config,problem)),slips=c,
        source={name:digest(Path(code)/name) for name in ['slips_core.py','slips_comparison.py']},
        bridge=digest(Path(code)/'vendor/screening/sampling.py'),
        evaluator=digest(Path(code)/'vendor/screening/evaluate.py'),
        state_metrics=digest(Path(code)/'vendor/screening/state_metrics.py')))


def valid(batch, problem, seed):
    from zipfile import BadZipFile
    try:
        config = settings(batch)
        if not enabled(config): return True
        out = run_directory(batch,problem,seed)/'slips'
        record = read_json(out/'identity.json')
        if record['key'] != key(config,problem,seed,Path(batch)/'code'): return False
        if record['fingerprint'] != read_json(Path(batch)/'reference'/problem/'target.json')['fingerprint']: return False
        if read_json(out/'status.json')['state'] != 'complete': return False
        if not all(digest(out/name)==value for name,value in record['files'].items()): return False
        n = config['problems'][problem]['particles']
        expected = {s for s in labels(config,problem) if s.startswith('SLIPS-')}
        raw = load_npz(out/'samples_all_rounds.npz'); info = read_json(out/'run_info.json')
        if set(raw)!=expected or set(info)!=expected: return False
        return all(a.shape==(n,record['dimension']) and np.isfinite(a).all()
                   and info[label]['actual_slips_proxy'] <= info[label]['target_slips_proxy']
                   for label,a in raw.items())
    except (OSError,ValueError,KeyError,TypeError,BadZipFile,EOFError): return False


def adopt(batch, problem, seed, sources):
    if not enabled(settings(batch)) or valid(batch,problem,seed): return None
    expected = key(settings(batch),problem,seed,Path(batch)/'code')
    for source in sources:
        try:
            if not enabled(settings(source)) or key(settings(source),problem,seed,source/'code')!=expected: continue
            if not valid(source,problem,seed): continue
            donor = run_directory(source,problem,seed)/'slips'
            target = Path(batch)/'reference'/problem/'target.json'
            if not target.exists() or read_json(donor/'identity.json')['fingerprint']!=read_json(target)['fingerprint']: continue
            dest = run_directory(batch,problem,seed)/'slips'
            if dest.exists(): archive(batch,problem,seed,dest)
            shutil.copytree(donor,dest)
            return dict(kind='slips',problem=problem,seed=seed,source=str(source))
        except (OSError,ValueError,KeyError): continue


def archive(batch,problem,seed,path):
    dest = Path(batch)/'failed_attempts'/problem/f'slips_seed{seed}_{time.time_ns()}'
    dest.parent.mkdir(parents=True,exist_ok=True); shutil.move(str(path),str(dest))


def merged_npz(directory, filename):
    result = load_npz(Path(directory)/filename)
    extra = Path(directory)/'slips'/filename
    if extra.exists():
        values = load_npz(extra)
        for label,value in values.items():
            if label=='truth': continue
            if label in result: raise ValueError('Duplicate comparison method: '+label)
            result[label]=value
    return result


def merged_metrics(directory, config):
    result = read_json(Path(directory)/'metrics.json')
    extra=Path(directory)/'slips/metrics.json'
    if enabled(config) and extra.exists(): result.update(read_json(extra))
    return result


def execute(batch, problem, seed, *, allow_cpu=False):
    import os
    batch = Path(batch).resolve(); cfg = settings(batch)
    if not enabled(cfg): return dict(disabled=True)
    if seed not in cfg['sampler_seeds']: raise ValueError('Unregistered SLIPS seed')
    if valid(batch,problem,seed): return dict(cached=True)
    out = run_directory(batch,problem,seed)/'slips'
    # Completed per-budget clouds survive interruptions; bind them to exact code,
    # target and settings, and verify their hashes before using them again.
    target = read_json(batch/'reference'/problem/'target.json')['fingerprint']
    identity = dict(key=key(cfg,problem,seed,batch/'code'),fingerprint=target)
    if out.exists() and (not (out/'binding.json').exists() or read_json(out/'binding.json')!=identity):
        archive(batch,problem,seed,out)
    out.mkdir(parents=True,exist_ok=True); write_json(out/'binding.json',identity)
    write_json(out/'status.json',dict(state='running'))
    os.environ.setdefault('JAX_ENABLE_X64','true')
    os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE','false')
    if not allow_cpu: os.environ.setdefault('JAX_PLATFORMS','cuda')
    screen_imports()
    import torch
    import jax
    import sampling
    from evaluate import evaluate
    if not allow_cpu and (not torch.cuda.is_available() or not any(d.platform=='gpu' for d in jax.devices())):
        raise RuntimeError('SLIPS requires CUDA in both frameworks; --allow-cpu is explicit')
    s = sampler_settings(cfg,problem); c = configuration(cfg['slips'])
    model = load_model(problem,cfg['data_seed'],out/'model_data')
    check_target(batch,problem,model)
    sampling.configure_sampling(active_dim=model.ACTIVE_DIM,default_n_gen=s.particles,
        hess_min=s.hess_min,hess_max=s.hess_max,curvature_ridge=s.curvature_ridge)
    model.prior_model = sampling.GaussianPrior(dim=model.ACTIVE_DIM)
    model.lik_model,_ = sampling.make_physics_likelihood(model.solve_forward,model.y_obs_np,model.NOISE_STD,
        use_gauss_newton_hessian=True,log_batch_size=s.log_batch,grad_batch_size=s.grad_batch,hess_batch_size=s.hess_batch)
    def posterior(x):
        with torch.no_grad():
            tensor = torch.as_tensor(x,device=sampling.device,dtype=torch.float64)
            ll,gradient = model.lik_model.log_likelihood_and_grad(tensor)
            lp = ll+model.prior_model.log_prob(tensor)
            score = gradient+model.prior_model.score0(tensor)
        return lp.cpu().numpy(),score.cpu().numpy()
    samples = {}; infos = {}; file_hashes = {}
    for r in range(1,s.rounds+1):
        label = f'SLIPS-{r}'; path = out/(label+'.npz'); record = out/(label+'.json')
        plan = allocate(s.particles,3*s.bank*r,c)
        if record.exists() and path.exists() and read_json(record).get('samples_sha256')==digest(path):
            payload = load_npz(path); info = read_json(record)
        else:
            stream = seed+30000+100*r
            initial = np.random.default_rng(stream).normal(size=(plan['paths'],model.ACTIVE_DIM))
            print(f'[{problem} seed{seed} {label}] plan={plan}',flush=True)
            cloud,info,state = run(initial,posterior,plan,c,seed=stream,
                progress=lambda k,n: print(f'  {label}: localization {k}/{n}',flush=True) if k in (1,n) else None)
            save_npz(path,samples=cloud,**state)
            info['samples_sha256']=digest(path);write_json(record,info)
            payload = dict(samples=cloud)
        samples[label]=payload['samples'];infos[label]=info
        file_hashes[path.name]=digest(path);file_hashes[record.name]=digest(record)
    save_npz(out/'samples_all_rounds.npz',**samples);write_json(out/'run_info.json',infos)
    # Canonical metric definitions, prediction batching and subset selection.
    rows,_,_ = evaluate(model,samples,s,seed,out,problem)
    for label,row in rows.items():
        # The old evaluator assumes every non-GAD cloud is the MALA cloud;
        # its self-distance is not a valid SLIPS-to-MALA diagnostic. Independent
        # reference MMD is computed for every method by comparison.py instead.
        row.pop('MMD_to_MALA_diagnostic',None)
        row.pop('MMD_reference_method',None)
        row.update({k:v for k,v in infos[label].items()
                    if k!='method' and isinstance(v,(int,float,str,bool))})
    write_json(out/'metrics.json',rows)
    if any(row.get('finite_fraction')!=1 or row.get('heldout_predictive_finite_fraction')!=1
           or not all(np.isfinite(row.get(k,np.nan)) for k in ['RMSE_field','RMSE_state','FwdRelErr','KSD','HeldoutPredNLL'])
           for row in rows.values()): raise RuntimeError('SLIPS metrics incomplete; inspect slips outputs')
    for name in ['samples_all_rounds.npz','run_info.json','metrics.json','field_summaries.npz','state_summaries.npz']:
        file_hashes[name]=digest(out/name)
    write_json(out/'experiment_config.json',dict(configuration=c,plans={label:info['plan'] for label,info in infos.items()},
        total_separate_budget_work=sum(info['actual_slips_proxy'] for info in infos.values()),
        work_convention='two proxy units per exact posterior value/gradient pair, initial cache and all rejected proposals included',
        comparison_design='independent restarted SLIPS experiment at each cumulative GAD work budget',
        output_design='P terminal conditional draws from the recorded localization paths; samples within a path are dependent'))
    write_json(out/'status.json',dict(state='complete'))
    identity.update(dimension=int(model.ACTIVE_DIM),files=file_hashes)
    write_json(out/'identity.json',identity)
    return identity
