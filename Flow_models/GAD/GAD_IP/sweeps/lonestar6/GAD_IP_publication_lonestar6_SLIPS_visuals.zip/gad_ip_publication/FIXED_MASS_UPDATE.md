> Historical fixed-mass notes. For the current SLIPS/visuals launch and Oct-28 CUDA repair, follow [RUN_ON_LONESTAR6.md](RUN_ON_LONESTAR6.md). Its targeted missing-wheel repair supersedes the earlier extraction-only installation instructions below.

# Fixed-mass NUTS on Lonestar6

New batches set `nuts.mass_mode="fixed"`. Identity mass is held fixed in the coordinates obtained from the regularized exact MAP Hessian; the full Hessian preconditioner remains in the original latent coordinates. Step-size adaptation and NUTS acceptance correction remain enabled. The target is still the full nonlinear PDE posterior.

No transition counts, priors, observations, PDEs, GAD/MALA settings, certification thresholds, queue limits or wall reservations are changed. Each problem retains four chains with 3,000 warmup and 5,000 retained draws per chain, target acceptance 0.95, depths 10/12 and atomic production chunks of 250 draws. This default applies to all selected problems; the supplied Allen–Cahn Colab benchmark is the available GPU performance evidence, not a guarantee of LS6 performance or convergence of other problems.

The Allen–Cahn benchmark completed 300 warmup transitions plus 20 production transitions at a mean of 0.6796 seconds per production transition, 14.2 leapfrog steps and zero production divergences. This supports proceeding with the existing full pipeline. Only the full reference certification makes the cloud eligible for publication comparisons.

## Fresh start using your completed install

There are no submitted LS6 jobs to cancel. Use the new batch name in [RUN_ON_LONESTAR6.md](RUN_ON_LONESTAR6.md): `batches/gad_ip_ls6_fixed_mass_20261027`. Do not resume an old dense-mass frozen batch after extracting the update.

Your existing GPU venv, modules, isolated ArviZ bridge and diagnostics installer are unchanged. The sibling path `<GPU-venv>_gad_diagnostics` still follows your symlink to `${SCRATCH}/venvs/flow_ls6_py39_gad_diagnostics`. Keep that symlink and the installed environments. The current update needs only extraction and `python check_environment.py --imports-only`; rerunning the installer is unnecessary.

## Reuse and restart

Completed compatible targets/MAPs and GAD/MALA runs can be copied from Vista, Frontera or LS6. A NUTS metric or logging change no longer invalidates an unchanged target or sampler run: compatibility binds the potential function AST, model source, realized target, seeds and canonical sampler hashes. A changed potential still invalidates reuse. Python 3.9's exact protocol annotation backport remains normalized as before.

References and completed chains additionally bind the mass setting. Old dense-adaptation reference outputs cannot be silently reused as fixed-mode outputs. A legacy config without `mass_mode` retains dense behavior; explicit `dense` and `diagonal` remain supported options for future deliberate configurations.

Cross-cluster live Slurm IDs remain excluded. Incomplete runtime pickle checkpoints also stay on their originating cluster; they bind numerical package versions and are not portable between the Python 3.9 LS6 environment and other runtimes. Compatible completed sample files remain reusable across clusters. Within the same scheduler/runtime, atomic chunks resume exactly and changed configuration bindings are refused.

Stdout now records the mass mode, completed warmup elapsed time, and each completed production chunk's elapsed time, seconds per draw and mean leapfrog count. An incomplete warmup still has no partial checkpoint. Monitor the detached submission driver through [SUBMISSION_WATCHER.md](SUBMISSION_WATCHER.md); scientific worker logs live under the new batch's `logs/` directory.
