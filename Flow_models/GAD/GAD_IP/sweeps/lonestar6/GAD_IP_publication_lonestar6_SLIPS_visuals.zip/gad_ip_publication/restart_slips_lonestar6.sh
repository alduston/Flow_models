#!/bin/bash
# Stop old LS6 publication watchers, cancel user jobs, repair CUDA, launch SLIPS.
set -eo pipefail
GP_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$GP_ROOT/slurm/environment.sh"
cd "$GP_ROOT"
exec python "$GP_ROOT/restart_slips_lonestar6.py" "$@"
