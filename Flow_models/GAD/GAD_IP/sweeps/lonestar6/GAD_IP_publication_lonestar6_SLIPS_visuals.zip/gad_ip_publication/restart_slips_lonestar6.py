"""Explicit all-user-job restart for this LS6 publication campaign.

Run on the old watcher's login host. Scientific output directories are retained.
The flag --cancel-all-user-jobs is required because scancel covers every active
Slurm job owned by this user, including the standalone preflight repair job.
"""
import argparse
import datetime
import fcntl
import getpass
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

from common import ROOT,digest,read_json,write_json
from scheduler_identity import batch_cluster,check_cluster
from workflow import freeze,verify_frozen


def watcher_pids():
    """Identify this user's local LS6 workflow submitters by argv and batch metadata."""
    found=[]
    for process in Path('/proc').glob('[0-9]*'):
        try:
            if process.stat().st_uid!=os.getuid():continue
            args=[v.decode() for v in (process/'cmdline').read_bytes().split(b'\0') if v]
            if not any(Path(v).name=='workflow.py' for v in args) or 'submit' not in args:continue
            cwd=(process/'cwd').resolve()
            for flag in ('--batch','--resume-batch'):
                if flag in args:
                    batch=Path(args[args.index(flag)+1]);batch=(cwd/batch).resolve()
                    if (batch/'batch.json').is_file() and batch_cluster(batch)=='ls6':
                        found.append((int(process.name),batch))
                    break
        except (OSError,ValueError,IndexError,UnicodeError):continue
    return found


def active_jobs(user):
    query=subprocess.run(['squeue','--noheader','--array','--user',user,'--format=%i'],
                         text=True,capture_output=True,check=True)
    return query.stdout.split()


def restart(old,new,old_log,*,cancel_all=False):
    if not cancel_all:raise ValueError('Add --cancel-all-user-jobs to perform the requested all-job restart.')
    old=Path(old).resolve();new=Path(new).resolve();old_log=Path(old_log).resolve()
    check_cluster(read_json(ROOT/'settings.json'))
    if old==new:raise ValueError('Choose a distinct new batch; retain the old frozen outputs.')
    if not (old/'batch.json').is_file() or batch_cluster(old)!='ls6':
        raise ValueError('Expected the existing LS6 batch at '+str(old))
    host_file=Path(str(old_log)+'.host')
    if not host_file.is_file():raise RuntimeError('Missing old watcher host record: '+str(host_file))
    host=host_file.read_text().strip()
    if host.split('.')[0]!=socket.gethostname().split('.')[0]:
        raise RuntimeError('Run on '+host+' so its old watcher can be stopped before cancellation.')
    # Verify any previous launch before changing old jobs. A distinct snapshot
    # prevents the old failed preflight record from blocking the new campaign.
    if new.exists():
        verify_frozen(new)
        if read_json(new/'settings.json')!=read_json(ROOT/'settings.json'):
            raise ValueError('Destination uses different settings; choose another new batch.')
        manifest=read_json(new/'source_manifest.json')
        current={str(p.relative_to(ROOT)):digest(p) for p in ROOT.rglob('*')
                 if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
        if manifest!=current:raise ValueError('Destination uses different source; choose another new batch.')
    else:
        config=read_json(ROOT/'settings.json')
        freeze(ROOT/'settings.json',new,config['active_problems'])
        meta=read_json(new/'batch.json');meta['workflow_version']=2;write_json(new/'batch.json',meta)
        write_json(new/'selection.json',dict(sampler_seeds=config['sampler_seeds'][:5],maximum=len(config['sampler_seeds']),phase='initial'))
    # Refuse known live submitters on another login host; local /proc cannot
    # stop them. Stale records with dead PIDs on this host are harmless.
    for record in ROOT.parent.glob('*_submit.log.host'):
        recorded=record.read_text().strip()
        if recorded.split('.')[0]==socket.gethostname().split('.')[0]:continue
        pid_path=Path(str(record)[:-5]+'.pid')
        if pid_path.exists():
            raise RuntimeError('Check/stop the watcher recorded on '+recorded+' ('+str(record)+') before the all-job restart.')
    watchers=watcher_pids()
    for pid,batch in watchers:
        print('Stopping old LS6 watcher '+str(pid)+' for '+str(batch),flush=True)
        try:os.kill(pid,signal.SIGTERM)
        except ProcessLookupError:pass
    # Wait for their submission-pass locks so no in-flight sbatch can escape
    # cancellation. Locks are held until squeue confirms all old jobs drained.
    locks=[]
    try:
        for batch in sorted({old,new,*(b for _,b in watchers)}):
            lock=(batch/'.submission.lock').open('a');locks.append(lock)
            fcntl.flock(lock,fcntl.LOCK_EX)
        user=getpass.getuser();ids=active_jobs(user)
        stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        write_json(new/'logs'/('restart-'+stamp+'.json'),dict(user=user,old_batch=str(old),
                   new_batch=str(new),watchers=[dict(pid=p,batch=str(b)) for p,b in watchers],
                   all_user_jobs_before_cancel=ids))
        print('Cancelling ALL '+str(len(ids))+' active Slurm jobs for '+user+'; retaining result files.',flush=True)
        subprocess.run(['scancel','--user',user],check=True)
        deadline=time.monotonic()+300
        while active_jobs(user):
            if time.monotonic()>deadline:raise RuntimeError('Old jobs are still stopping; rerun this launcher after squeue drains.')
            time.sleep(2)
    finally:
        for lock in reversed(locks):lock.close()
    # No scientific jobs remain active while the shared environment is repaired.
    subprocess.run([sys.executable,str(ROOT/'ls6_cuda.py'),'--repair'],check=True)
    subprocess.run([sys.executable,str(ROOT/'check_environment.py'),'--imports-only'],check=True)
    ip_root=ROOT.parent.parent.parent
    args=[sys.executable,str(ROOT/'workflow.py'),'submit','--resume-batch',str(new),
          '--reuse-from',str(old),'--reuse-from',str(ip_root/'batches'),
          '--reuse-from',str(ROOT.parent.parent/'frontera/batches'),
          '--import-runs',str(ip_root),'--repeats','5','--retry-failed']
    # First pass is synchronous: the user sees the real preflight job ID and
    # immediate errors before the detached watcher takes over the deferred work.
    subprocess.run(args,check=True)
    log=ROOT.parent/(new.name+'_submit.log')
    with log.open('a') as stream:
        driver=subprocess.Popen(args+['--watch'],stdin=subprocess.DEVNULL,stdout=stream,
                                stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
    Path(str(log)+'.pid').write_text(str(driver.pid)+'\n')
    Path(str(log)+'.host').write_text(socket.gethostname()+'\n')
    print('Detached watcher PID: '+str(driver.pid)+'\nBatch: '+str(new)+'\nLog: '+str(log),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--old-batch',type=Path,default=ROOT.parent/'batches/gad_ip_ls6_fixed_mass_20261027')
    parser.add_argument('--new-batch',type=Path,default=ROOT.parent/'batches/gad_ip_ls6_slips_visuals_20261028')
    parser.add_argument('--old-watcher-log',type=Path)
    parser.add_argument('--cancel-all-user-jobs',action='store_true')
    args=parser.parse_args()
    log=args.old_watcher_log or ROOT.parent/(args.old_batch.name+'_submit.log')
    restart(args.old_batch,args.new_batch,log,cancel_all=args.cancel_all_user_jobs)
