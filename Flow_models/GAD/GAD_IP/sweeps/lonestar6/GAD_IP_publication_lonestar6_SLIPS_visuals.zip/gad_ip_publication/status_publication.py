"""Inspect a publication batch even before its first accepted Slurm submission."""
import argparse
from collections import Counter,deque
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def read(path,default=None):
    return json.loads(path.read_text()) if path.exists() else default


def inspect(batch,log=None,scheduler=True,packages=False):
    batch=Path(batch).resolve();failed=False
    if not (batch/'batch.json').is_file():raise FileNotFoundError('Batch not initialized: '+str(batch))
    sys.path.insert(0,str(batch/'code'))
    from workflow import verify_frozen
    try:
        verify_frozen(batch)
        for name in ['common.py','cache.py','target_snapshot.py','arviz_compat.py','diagnostics_worker.py','check_environment.py','ls6_cuda.py','repair_ls6_cuda.sh','install_reference_extras.sh','slurm/environment.sh','scheduler_identity.py','planner.py','slips_core.py','slips_comparison.py','plotting.py','comparison.py']:
            if (batch/'code'/name).read_bytes()!=(ROOT/name).read_bytes():raise ValueError('Frozen code differs from this bundle: '+name)
        print('PASS: frozen source integrity, SLIPS/visuals, target snapshots and LS6 CUDA/package/scheduler fixes.',flush=True)
    except (OSError,ValueError,KeyError) as exc:
        failed=True;print('FAIL:',str(exc),flush=True)
    plan=read(batch/'submission_plan.json',{})
    if plan:
        print('Latest plan:',{k:plan.get(k) for k in ['failed_tasks','deferred_tasks','cap','partition','partition_cap']},flush=True)
        reasons=Counter(n.get('reason','') for n in plan.get('nodes',[]) if n['state']=='deferred')
        for reason,count in reasons.items():print('Deferred:',count,reason,flush=True)
        for node in plan.get('nodes',[]):
            if node['state'] in {'failed','blocked'}:print(node['key'],node['state'],node.get('reason',''),flush=True)
        failed=failed or bool(plan.get('failed_tasks'))
    else:print('No submission plan yet.',flush=True)
    jobs=read(batch/'jobs.json',{})
    if not jobs:print('No accepted job IDs yet; a fully deferred batch has no jobs.json.',flush=True)
    if packages and not failed:
        result=subprocess.run([sys.executable,str(batch/'code/check_environment.py'),'--imports-only'])
        failed=failed or bool(result.returncode)
    if scheduler:
        partition=plan.get('partition') or read(batch/'settings.json')['slurm']['partition']
        commands=[['sinfo','-p',partition,'-o','%22P %8a %22F'],['squeue','-u',os.environ.get('USER',''),'-o','%.18i %.20P %.34j %.12T %.12M %R']]
        if jobs:commands.append(['sacct','-X','-j',','.join(sorted({str(v['id']) for v in jobs.values()})),'--format=JobID,JobName%36,State,ExitCode'])
        for cmd in commands:
            result=subprocess.run(cmd);failed=failed or bool(result.returncode)
    log=Path(log).resolve() if log else batch.parent.parent/(batch.name+'_submit.log')
    if log.exists():
        print('Latest watcher log:',str(log),flush=True)
        with log.open(errors='replace') as f:print(''.join(deque(f,maxlen=20)),end='',flush=True)
    host_path=Path(str(log)+'.host')
    if host_path.exists():
        host=host_path.read_text().strip();print('Recorded watcher host:',host,'Current host:',socket.gethostname(),flush=True)
        if scheduler and host.split('.')[0]==socket.gethostname().split('.')[0]:
            pattern='workflow[.]py submit .*'+re.escape(batch.name)+'([[:space:]]|$)'
            result=subprocess.run(['pgrep','-afu',os.environ.get('USER',''),pattern])
            if result.returncode==1:print('No local watcher. It may have exited normally after all work was submitted.',flush=True)
    return 1 if failed else 0


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--batch',type=Path,default=ROOT.parent/'batches/gad_ip_ls6_slips_visuals_20261028')
    p.add_argument('--log',type=Path)
    p.add_argument('--check-packages',action='store_true')
    p.add_argument('--no-scheduler',action='store_true',help='Local QA only: skip Slurm and process queries')
    a=p.parse_args();return inspect(a.batch,a.log,not a.no_scheduler,a.check_packages)


if __name__=='__main__':sys.exit(main())
