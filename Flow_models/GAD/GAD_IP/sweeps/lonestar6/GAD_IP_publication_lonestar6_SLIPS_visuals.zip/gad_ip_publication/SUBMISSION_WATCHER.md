# Detached LS6 submission standard

[RUN_ON_LONESTAR6.md](RUN_ON_LONESTAR6.md) contains the complete start, resume and expansion commands. Use a detached `nohup bash submit.sh ... --watch >> LOG 2>&1 < /dev/null &`, then record `$!` and `hostname`, and `disown`. Launch only one watcher per batch. It checks every 30 seconds, preserves accepted job IDs, reuses verified outputs and refills deferred tasks after dependencies/limits clear. `--watch` and `--dry-run` are mutually exclusive.

## Inspect and stop the watcher

Run these from the extracted directory on the recorded login host:

```bash
GP_BATCH=../batches/gad_ip_ls6_slips_visuals_20261028
GP_DRIVER_LOG=../gad_ip_ls6_slips_visuals_20261028_submit.log
bash check_status.sh --batch "$GP_BATCH"
cat "$GP_DRIVER_LOG.host"
ps -p "$(cat "$GP_DRIVER_LOG.pid")" -o pid,etime,args
```

Verify the displayed command belongs to this batch; PID files can be stale. While the watcher is polling, stop only that verified process:

```bash
kill -TERM "$(cat "$GP_DRIVER_LOG.pid")"
```

Accepted Slurm jobs continue. Resume the same batch using `--resume-batch`; do not start a new batch merely because SSH disconnected. A login-node restart can terminate the watcher despite nohup. The watcher exits normally after submission is complete; that does not imply scientific jobs have finished.

## Limits and failures

The global cap is 32 local user tasks. Selected queue caps are A100 28, H100 4, A100-small 10 and A100-dev 2, counting unrelated local jobs and expanded arrays. `--max-outstanding-tasks N` may lower the global cap. Partition unavailability and allocation/submit rejections defer work. Caps reduce simultaneous reservations; they cannot create additional allocation.

Failed/cancelled jobs with missing outputs require inspection and `--retry-failed`. A reference that fails strict convergence checks needs a scientifically appropriate new configuration, not repeated certification of identical draws. `--time chain=...` changes reservations for future submissions and must be repeated after restart. `--partition gpu-h100` is operational and also must be repeated on resume.

Before the first accepted submission, `jobs.json` may not exist. The supplied status command handles that state and prints deferral reasons. Older failure logs can remain after a successful retry; use the latest submission plan and current recorded job IDs.
