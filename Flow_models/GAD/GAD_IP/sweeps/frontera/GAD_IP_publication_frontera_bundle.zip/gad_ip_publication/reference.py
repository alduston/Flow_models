"""Independent, exact-potential NUTS with resumable production chunks."""
import argparse
import os
import pickle
import time
from pathlib import Path
from types import SimpleNamespace

from common import (check_target, digest, field_summary, fields_from_latents, load_model,
                    load_npz, model_data, physical_spec, read_json, save_npz, screen_imports,
                    settings, signature, verified_reference, write_json)

EXTRA = ('potential_energy', 'energy', 'accept_prob', 'num_steps', 'adapt_state.step_size')


def potential(model):
    import jax.numpy as jnp
    y = jnp.asarray(model.y_obs_np); sigma = float(model.NOISE_STD)
    def energy(alpha):
        residual = (model.solve_forward(alpha)-y)/sigma
        return .5*jnp.vdot(alpha, alpha)+.5*jnp.vdot(residual, residual)
    return energy


def prepare(batch, problem):
    import numpy as np
    from reference_core import find_map_and_laplace, make_chain_initial_positions, make_whitened_potential, stabilize_chain_initial_positions
    screen_imports()
    from run_problem import check_model
    batch = Path(batch); cfg = settings(batch); out = batch/'reference'/problem
    if (out/'setup.json').exists():
        info = read_json(out/'setup.json')
        if digest(out/'setup.npz') == info['setup_sha256']: return info
        raise ValueError('Existing prepared NUTS setup changed')
    model = load_model(problem, cfg['data_seed'], out/'model_data')
    metadata, arrays, identity = model_data(problem, model, cfg['data_seed'])
    write_json(out/'target.json', dict(metadata=metadata, fingerprint=identity))
    save_npz(out/'target_arrays.npz', **arrays)
    spec = physical_spec(problem, model)
    # Test the fast host-side physical map against the unmodified model.
    probes = np.stack([model.alpha_true_np, np.zeros(model.ACTIVE_DIM),
                       np.random.default_rng(105).normal(0,.2,model.ACTIVE_DIM)])
    for alpha, field in zip(probes, fields_from_latents(probes, spec)):
        np.testing.assert_allclose(field, model.field_from_latent(alpha), rtol=2e-12, atol=2e-12)
    save_npz(out/'physical_spec.npz', **spec)
    # Generating truth is used only for validation/plots, never for MAP or chain initialization.
    write_json(out/'model_derivative_check.json', check_model(model))
    args = SimpleNamespace(**cfg['nuts'], latent_dim=model.ACTIVE_DIM)
    energy = potential(model)
    setup = find_map_and_laplace(args, energy)
    initial = make_chain_initial_positions(args, setup)
    initial = stabilize_chain_initial_positions(initial, make_whitened_potential(energy, setup))
    records = setup.pop('map_records')
    save_npz(out/'setup.npz', **setup, initial_z=initial)
    info = dict(fingerprint=identity, setup_sha256=digest(out/'setup.npz'), map_records=records,
                initialization='truth-blind zero/prior multi-start MAP; distinct basin centers + whitened jitter',
                whitening='regularized exact MAP Hessian; fixed invertible affine change of variables',
                potential='0.5*alpha.T*alpha + 0.5*||forward(alpha)-observations||^2/noise_std^2')
    write_json(out/'setup.json', info)
    return info


def _atomic_pickle(path, payload):
    temporary = path.with_name(path.name+f'.{os.getpid()}.tmp')
    with temporary.open('wb') as f: pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)
    temporary.replace(path)


def run_chunked_chain(energy_z, initial, directory, config, chain_index, identity, *, stop_after_chunks=None):
    """Checkpoints contain state + RNG + draws atomically, so restart cannot duplicate draws.

    Pickles are local, self-generated state checkpoints. Do not load checkpoints from untrusted bundles.
    A warmup interrupted before its completion restarts warmup; completed production chunks survive.
    """
    import jax
    import jax.numpy as jnp
    import numpy as np
    import numpyro
    from numpyro.infer import MCMC, NUTS
    directory = Path(directory); directory.mkdir(parents=True, exist_ok=True)
    runtime = dict(jax=jax.__version__, numpyro=numpyro.__version__, numpy=np.__version__)
    binding = signature(dict(identity=identity, config=config, chain=chain_index, runtime=runtime))
    kernel = NUTS(potential_fn=energy_z, dense_mass=True, target_accept_prob=config['target_accept'],
                  max_tree_depth=(config['max_tree_depth_warmup'], config['max_tree_depth']),
                  find_heuristic_step_size=True, regularize_mass_matrix=True)
    def restore(path):
        with path.open('rb') as f: value = pickle.load(f)
        if value['binding'] != binding: raise ValueError(f'Incompatible checkpoint: {path}')
        value['state'] = jax.tree_util.tree_map(jnp.asarray, value['state'])
        return value
    warm = directory/'warmup.pkl'
    if warm.exists():
        checkpoint = restore(warm)
    else:
        t0 = time.perf_counter()
        mcmc = MCMC(kernel, num_warmup=config['num_warmup'], num_samples=config['chunk_size'],
                    num_chains=1, progress_bar=False)
        key = jax.random.PRNGKey(config['sampler_seed']+100003*(chain_index+1))
        print(f'chain {chain_index}: warmup {config["num_warmup"]}', flush=True)
        mcmc.warmup(key, init_params=jnp.asarray(initial))
        jax.block_until_ready(mcmc.post_warmup_state.z)
        checkpoint = dict(binding=binding, state=jax.device_get(mcmc.post_warmup_state),
                          elapsed_seconds=time.perf_counter()-t0)
        _atomic_pickle(warm, checkpoint)
        checkpoint = restore(warm)
    state = checkpoint['state']; elapsed = checkpoint['elapsed_seconds']; parts = []; extras = []
    done = 0; chunk = 0; newly_completed = 0
    while done < config['num_samples']:
        size = min(config['chunk_size'], config['num_samples']-done)
        path = directory/f'chunk_{chunk:05d}.pkl'
        if path.exists():
            checkpoint = restore(path)
            if checkpoint['start'] != done or checkpoint['draws'].shape != (size, len(initial)):
                raise ValueError('Malformed or noncontiguous NUTS checkpoint')
        else:
            mcmc = MCMC(kernel, num_warmup=config['num_warmup'], num_samples=size,
                        num_chains=1, progress_bar=False)
            mcmc.post_warmup_state = state
            t0 = time.perf_counter()
            # A fresh NumPyro kernel still needs a prototype initial state to
            # compile its transition, even when post_warmup_state is restored.
            mcmc.run(state.rng_key, init_params=state.z, extra_fields=EXTRA)
            jax.block_until_ready(mcmc.last_state.z)
            checkpoint = dict(binding=binding, state=jax.device_get(mcmc.last_state), start=done,
                              draws=np.asarray(mcmc.get_samples()),
                              extras={k: np.asarray(v) for k,v in mcmc.get_extra_fields().items()},
                              elapsed_seconds=time.perf_counter()-t0)
            if not np.isfinite(checkpoint['draws']).all(): raise FloatingPointError('Non-finite NUTS draws')
            _atomic_pickle(path, checkpoint); newly_completed += 1
        state = checkpoint['state']; parts.append(checkpoint['draws']); extras.append(checkpoint['extras'])
        elapsed += checkpoint['elapsed_seconds']; done += size; chunk += 1
        print(f'chain {chain_index}: retained {done}/{config["num_samples"]}', flush=True)
        if stop_after_chunks is not None and newly_completed >= stop_after_chunks and done < config['num_samples']:
            return None
    names = set(EXTRA)|{'diverging'}
    if any(set(e) != names for e in extras): raise ValueError('NUTS extra fields missing')
    return dict(z_samples=np.concatenate(parts), elapsed_seconds=elapsed,
                extras={k: np.concatenate([e[k] for e in extras]) for k in names}, binding=binding, runtime=runtime)


def chain(batch, problem, index):
    import numpy as np
    from reference_core import make_whitened_potential
    batch = Path(batch); cfg = settings(batch); out = batch/'reference'/problem
    if not 0 <= index < cfg['nuts']['num_chains']: raise ValueError('Invalid chain index')
    model = load_model(problem, cfg['data_seed'], out/f'model_chain{index}')
    identity = check_target(batch, problem, model)
    info = read_json(out/'setup.json')
    if info['setup_sha256'] != digest(out/'setup.npz'): raise ValueError('Whitening setup hash mismatch')
    setup = load_npz(out/'setup.npz'); expected = signature(dict(target=identity, setup=info['setup_sha256']))
    path = out/'chains'/f'chain_{index}.npz'; status_path = path.with_suffix('.json')
    if path.exists() and status_path.exists():
        record = read_json(status_path)
        if record['identity'] == expected and record['sha256'] == digest(path): return record
        raise ValueError('Completed reference chain identity changed')
    result = run_chunked_chain(make_whitened_potential(potential(model), setup), setup['initial_z'][index],
                               out/'checkpoints'/f'chain_{index}', cfg['nuts'], index, expected)
    alpha = setup['map_position'] + result['z_samples'] @ setup['laplace_factor'].T
    save_npz(path, samples=alpha, z_samples=result['z_samples'], **result['extras'])
    record = dict(identity=expected, fingerprint=identity, sha256=digest(path), runtime=result['runtime'],
                  elapsed_seconds=result['elapsed_seconds'], chain=index)
    write_json(status_path, record)
    return record


def _derived(chains, energies, spec):
    import numpy as np
    c,n,d = chains.shape; grid = int(spec['grid'])
    result = dict(potential_energy=energies, coefficient_norm=np.linalg.norm(chains, axis=-1))
    outputs = np.empty((c,n,5))
    half = grid//2
    for ci in range(c):
        for start in range(0,n,256):
            f = fields_from_latents(chains[ci,start:start+256], spec)
            v = np.stack([f[:,:half,:half].mean((1,2)),f[:,:half,half:].mean((1,2)),
                          f[:,half:,:half].mean((1,2)),f[:,half:,half:].mean((1,2)),
                          np.sqrt((f*f).mean((1,2)))], axis=-1)
            outputs[ci,start:start+len(f)] = v
    result['field_quadrant_means_and_rms'] = outputs
    return result


def certify(batch, problem):
    import numpy as np
    import csv
    from reference_core import arviz_diagnostics, kernel_diagnostics
    batch = Path(batch); cfg = settings(batch); c = cfg['nuts']; out = batch/'reference'/problem
    prepared = read_json(out/'setup.json'); target = read_json(out/'target.json')
    if prepared['setup_sha256'] != digest(out/'setup.npz'): raise ValueError('Changed reference setup')
    expected = signature(dict(target=target['fingerprint'],setup=prepared['setup_sha256']))
    draws=[]; extras=[]; records=[]
    for i in range(c['num_chains']):
        p=out/'chains'/f'chain_{i}.npz'; r=read_json(p.with_suffix('.json'))
        if r['identity'] != expected or r['sha256'] != digest(p): raise ValueError('Chain binding failed')
        a=load_npz(p); draws.append(a.pop('samples')); a.pop('z_samples'); extras.append(a); records.append(r)
    chains=np.stack(draws)
    if chains.shape != (c['num_chains'],c['num_samples'],target['metadata']['dimension']) or not np.isfinite(chains).all():
        raise ValueError('Malformed reference chains')
    extra={key:np.stack([x[key] for x in extras]) for key in set(EXTRA)|{'diverging'}}
    if any(v.shape != chains.shape[:2] for v in extra.values()): raise ValueError('Malformed diagnostics arrays')
    spec=load_npz(out/'physical_spec.npz')
    derived=_derived(chains,extra['potential_energy'],spec)
    convergence,rows=arviz_diagnostics(chains,derived)
    kernel=kernel_diagnostics(extra,max_tree_depth=c['max_tree_depth'])
    checks=dict(convergence_finite=convergence['finite'],kernel_finite=kernel['finite'],
                rank_rhat=convergence['max_rank_rhat']<=c['max_rhat'],bulk_ess=convergence['min_bulk_ess']>=c['min_bulk_ess'],
                tail_ess=convergence['min_tail_ess']>=c['min_tail_ess'],divergences=kernel['total_divergences']<=c['max_divergences'],
                tree_depth=kernel['max_tree_depth_saturation_fraction']<=c['max_tree_depth_fraction'],
                ebfmi=kernel['min_ebfmi']>=c['min_ebfmi'],acceptance=kernel['min_mean_accept_prob']>=c['min_mean_accept'])
    passed=all(checks.values())
    payload=dict(samples=chains.reshape(-1,chains.shape[-1]),samples_by_chain=chains,certified=np.asarray(passed),
                 fingerprint=np.asarray(target['fingerprint']))
    save_npz(out/'reference_samples_uncertified.npz',**payload)
    canonical=out/'reference_samples.npz'
    if passed: save_npz(canonical,**payload)
    elif canonical.exists(): canonical.unlink()
    quality=dict(certified=passed,checks=checks,thresholds=c,convergence=convergence,kernel=kernel,
                 fingerprint=target['fingerprint'],chain_records=records,
                 reference_sha256=digest(canonical) if passed else None,
                 interpretation='Diagnostic checks are necessary evidence of mixing, not a proof of global exploration.')
    write_json(out/'nuts_diagnostics.json',quality)
    with (out/'nuts_parameter_diagnostics.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    save_npz(out/'chain_diagnostics.npz',**dict(extra,**derived))
    if not passed: raise RuntimeError(f'{problem}: NUTS checks failed: '+', '.join(k for k,v in checks.items() if not v))
    return quality


def summarize(batch, problem):
    """Physical/predictive reference summaries and block-bootstrap MC error."""
    import numpy as np
    import jax
    import jax.numpy as jnp
    import arviz as az
    from comparison import reference_geometry, reference_floors, predictive_metrics_scaled
    batch=Path(batch); cfg=settings(batch); out=batch/'reference'/problem
    ref,quality=verified_reference(batch,problem)
    model=load_model(problem,cfg['data_seed'],out/'model_summary'); check_target(batch,problem,model)
    spec=load_npz(out/'physical_spec.npz'); samples=ref['samples']; chains=ref['samples_by_chain']
    summary=field_summary(samples,spec)
    # Nonoverlapping within-chain blocks preserve short-range dependence.
    length=min(cfg['evaluation']['reference_block_length'],chains.shape[1])
    count=chains.shape[1]//length
    if count<2: raise ValueError('Need >=2 complete blocks per reference chain')
    first=[]; second=[]
    for draws in chains:
        mean=[]; moment=[]
        for i in range(count):
            f=fields_from_latents(draws[i*length:(i+1)*length],spec)
            mean.append(f.mean(0));moment.append((f*f).mean(0))
        first.append(np.stack(mean));second.append(np.stack(moment))
    first=np.stack(first);second=np.stack(second)
    rng=np.random.default_rng(cfg['evaluation']['seed']); bootmeans=[]; bootstd=[]
    for _ in range(cfg['evaluation']['reference_bootstrap']):
        index=rng.integers(0,count,(len(chains),count));ci=np.arange(len(chains))[:,None]
        m=first[ci,index].mean((0,1));v=second[ci,index].mean((0,1))-m*m
        bootmeans.append(m);bootstd.append(np.sqrt(np.maximum(v,0)))
    summary.update(mean_mc_ci_low=np.quantile(bootmeans,.025,axis=0),mean_mc_ci_high=np.quantile(bootmeans,.975,axis=0),
                   std_mc_ci_low=np.quantile(bootstd,.025,axis=0),std_mc_ci_high=np.quantile(bootstd,.975,axis=0),
                   alpha_mean=samples.mean(0),alpha_cov=np.cov(samples,rowvar=False),
                   alpha_mean_mcse=np.asarray(az.mcse(az.from_dict(posterior={'alpha':chains}),method='mean')['alpha'].values))
    screen_imports()
    from state_metrics import state_evaluator
    summary['state_at_mean']=state_evaluator(model,problem)(samples.mean(0))
    summary['state_truth']=state_evaluator(model,problem)(model.alpha_true_np)
    summary['truth']=spec['truth']
    # Same posterior-predictive cap as the canonical screening evaluation.
    limit=min(cfg['evaluation']['reference_predictive_draws'],len(samples))
    indices=rng.choice(len(samples),limit,replace=False)
    forward=jax.jit(jax.vmap(model.solve_forward_holdout));pred=[]
    batchsize=cfg['sampler']['heldout_batch']
    for i in range(0,limit,batchsize):
        pred.append(np.asarray(forward(jnp.asarray(samples[indices[i:i+batchsize]]))))
    predictions=np.concatenate(pred)
    summary.update(predictive_mean=predictions.mean(0),predictive_std=predictions.std(0,ddof=1),
                   predictive_var=predictions.var(0,ddof=1),predictive_draws=predictions,
                   y_holdout_obs=model.y_holdout_obs_np,y_holdout_clean=model.y_holdout_clean_np,noise_std=np.asarray(model.NOISE_STD))
    metrics=predictive_metrics_scaled(predictions,model.y_holdout_obs_np,model.y_holdout_clean_np,float(model.NOISE_STD))
    save_npz(out/'reference_summary.npz',**summary)
    geometry=reference_geometry(samples,cfg['evaluation'])
    save_npz(out/'geometry.npz',**geometry)
    floor=reference_floors(samples,geometry,min(cfg['problems'][problem]['particles'],cfg['evaluation']['distribution_cap']),cfg['evaluation'])
    save_npz(out/'sampling_floors.npz',**floor)
    write_json(out/'summary.json',dict(fingerprint=str(ref['fingerprint']),metrics=metrics,
                                     reference_sha256=quality['reference_sha256'],summary_sha256=digest(out/'reference_summary.npz'),
                                     geometry_sha256=digest(out/'geometry.npz'),floor_sha256=digest(out/'sampling_floors.npz'),
                                     reference_block_length=length,complete_blocks_per_chain=count,
                                     monte_carlo_uncertainty='95% within-chain block bootstrap intervals; block length sensitivity should be checked for final reference claims'))
    return metrics


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['prepare','chain','certify','summarize'])
    p.add_argument('--batch',type=Path,required=True);p.add_argument('--problem',required=True);p.add_argument('--chain',type=int,default=0)
    a=p.parse_args()
    if a.stage=='chain':chain(a.batch,a.problem,a.chain)
    else:globals()[a.stage](a.batch,a.problem)


if __name__=='__main__': main()
