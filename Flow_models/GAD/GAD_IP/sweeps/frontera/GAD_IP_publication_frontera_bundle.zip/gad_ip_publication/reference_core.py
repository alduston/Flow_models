"""Generic routines copied verbatim from the supplied Darcy NUTS driver.
The original file and SHA256/AST provenance are retained in provenance/.
"""
import argparse
import math
import time
from typing import Dict, List, Mapping, Sequence, Tuple
import numpy as np
import jax
import jax.numpy as jnp
import arviz as az
from scipy.optimize import minimize

def find_map_and_laplace(
    args: argparse.Namespace,
    potential_alpha,
) -> Dict[str, object]:
    d = int(args.latent_dim)
    value_grad_jax = jax.jit(jax.value_and_grad(potential_alpha))
    # Force compilation once at the correct dimension.
    warm_value, warm_grad = value_grad_jax(jnp.zeros(d, dtype=jnp.float64))
    _ = (jax.device_get(warm_value), jax.device_get(warm_grad))

    def objective(x_np: np.ndarray):
        value, gradient = value_grad_jax(jnp.asarray(x_np, dtype=jnp.float64))
        scalar = float(np.asarray(jax.device_get(value)))
        grad = np.asarray(jax.device_get(gradient), dtype=np.float64)
        if not math.isfinite(scalar) or not np.isfinite(grad).all():
            raise FloatingPointError("Non-finite value/gradient during MAP optimization.")
        return scalar, grad

    rng = np.random.default_rng(args.sampler_seed + 17_301)
    starts = [np.zeros(d, dtype=np.float64)]
    starts.extend(
        rng.normal(0.0, args.map_start_scale, size=d).astype(np.float64)
        for _ in range(args.map_starts - 1)
    )
    solutions = []
    print(f"\n=== Truth-blind multi-start MAP ({len(starts)} starts) ===")
    for index, start in enumerate(starts):
        started = time.perf_counter()
        try:
            initial_energy, _ = objective(start)
        except (FloatingPointError, ValueError) as exc:
            elapsed = time.perf_counter() - started
            print(
                f"MAP start {index + 1}/{len(starts)} is non-finite and was skipped: {exc}"
            )
            solutions.append(
                {
                    "start_index": index,
                    "initial_energy": float("inf"),
                    "energy": float("inf"),
                    "gradient_norm": float("inf"),
                    "success": False,
                    "status": -1,
                    "message": str(exc),
                    "iterations": -1,
                    "function_evaluations": -1,
                    "elapsed_seconds": elapsed,
                    "position": start,
                }
            )
            continue
        try:
            result = minimize(
                objective,
                start,
                method="L-BFGS-B",
                jac=True,
                options={
                    "maxiter": int(args.map_maxiter),
                    "gtol": float(args.map_gtol),
                    "ftol": float(args.map_ftol),
                    "maxls": 50,
                },
            )
        except (FloatingPointError, ValueError) as exc:
            elapsed = time.perf_counter() - started
            print(
                f"MAP start {index + 1}/{len(starts)} failed after {elapsed:.1f}s: {exc}"
            )
            solutions.append(
                {
                    "start_index": index,
                    "initial_energy": initial_energy,
                    "energy": float("inf"),
                    "gradient_norm": float("inf"),
                    "success": False,
                    "status": -1,
                    "message": str(exc),
                    "iterations": -1,
                    "function_evaluations": -1,
                    "elapsed_seconds": elapsed,
                    "position": start,
                }
            )
            continue
        elapsed = time.perf_counter() - started
        x = np.asarray(result.x, dtype=np.float64)
        try:
            energy, gradient = objective(x)
        except (FloatingPointError, ValueError) as exc:
            print(
                f"MAP start {index + 1}/{len(starts)} ended at a non-finite "
                f"position and was skipped: {exc}"
            )
            solutions.append(
                {
                    "start_index": index,
                    "initial_energy": initial_energy,
                    "energy": float("inf"),
                    "gradient_norm": float("inf"),
                    "success": False,
                    "status": int(getattr(result, "status", -1)),
                    "message": str(exc),
                    "iterations": int(getattr(result, "nit", -1)),
                    "function_evaluations": int(getattr(result, "nfev", -1)),
                    "elapsed_seconds": elapsed,
                    "position": start,
                }
            )
            continue
        record = {
            "start_index": index,
            "initial_energy": initial_energy,
            "energy": energy,
            "gradient_norm": float(np.linalg.norm(gradient)),
            "success": bool(result.success),
            "status": int(result.status),
            "message": str(result.message),
            "iterations": int(getattr(result, "nit", -1)),
            "function_evaluations": int(getattr(result, "nfev", -1)),
            "elapsed_seconds": elapsed,
            "position": x,
        }
        solutions.append(record)
        print(
            f"MAP start {index + 1}/{len(starts)}: U={energy:.6e}, "
            f"|grad|={record['gradient_norm']:.3e}, success={record['success']}, "
            f"nit={record['iterations']}, wall={elapsed:.1f}s"
        )

    finite = [item for item in solutions if math.isfinite(float(item["energy"]))]
    if not finite:
        raise RuntimeError("Every MAP optimization produced a non-finite result.")
    finite.sort(key=lambda item: float(item["energy"]))
    best = finite[0]
    map_position = np.asarray(best["position"], dtype=np.float64)
    best_energy = float(best["energy"])

    usable = []
    for item in finite:
        if float(item["energy"]) - best_energy > args.map_energy_window:
            continue
        candidate = np.asarray(item["position"], dtype=np.float64)
        if all(
            np.linalg.norm(candidate - np.asarray(other["position"]))
            > args.map_distinct_distance
            for other in usable
        ):
            usable.append(item)
    if not usable:
        usable = [best]
    print(
        f"Selected MAP U={best_energy:.6e}; retained {len(usable)} distinct "
        "candidate basin(s) for overdispersed chain starts."
    )

    print("Computing exact posterior Hessian at the selected MAP...")
    hessian_jax = jax.jit(jax.hessian(potential_alpha))(
        jnp.asarray(map_position, dtype=jnp.float64)
    )
    hessian = np.asarray(jax.device_get(hessian_jax), dtype=np.float64)
    hessian = 0.5 * (hessian + hessian.T)
    if not np.isfinite(hessian).all():
        raise FloatingPointError("Exact MAP Hessian contains non-finite entries.")
    raw_eigvals, eigvecs = np.linalg.eigh(hessian)
    spectral_max = max(float(np.max(np.abs(raw_eigvals))), args.hessian_eigenvalue_floor)
    effective_floor = max(
        float(args.hessian_eigenvalue_floor),
        spectral_max / float(args.hessian_max_condition),
    )
    clipped_eigvals = np.maximum(raw_eigvals, effective_floor)
    laplace_factor = (
        eigvecs
        @ np.diag(float(args.laplace_scale) / np.sqrt(clipped_eigvals))
    )
    if not np.isfinite(laplace_factor).all():
        raise FloatingPointError("Laplace whitening factor is non-finite.")
    print(
        "MAP Hessian spectrum: "
        f"raw=[{raw_eigvals.min():.3e}, {raw_eigvals.max():.3e}], "
        f"regularized floor={effective_floor:.3e}, "
        f"condition={clipped_eigvals.max() / clipped_eigvals.min():.3e}"
    )
    return {
        "map_position": map_position,
        "map_energy": best_energy,
        "map_gradient_norm": float(best["gradient_norm"]),
        "candidate_positions": np.stack(
            [np.asarray(item["position"], dtype=np.float64) for item in usable]
        ),
        "candidate_energies": np.asarray(
            [float(item["energy"]) for item in usable], dtype=np.float64
        ),
        "hessian": hessian,
        "hessian_eigenvalues_raw": raw_eigvals,
        "hessian_eigenvalues_regularized": clipped_eigvals,
        "laplace_factor": laplace_factor,
        "map_records": [
            {key: value for key, value in item.items() if key != "position"}
            for item in solutions
        ],
    }


def make_whitened_potential(potential_alpha, setup: Mapping[str, object]):
    map_position = jnp.asarray(setup["map_position"], dtype=jnp.float64)
    laplace_factor = jnp.asarray(setup["laplace_factor"], dtype=jnp.float64)

    def potential_z(z):
        alpha = map_position + laplace_factor @ jnp.asarray(z, dtype=jnp.float64)
        return potential_alpha(alpha)

    return potential_z


def make_chain_initial_positions(
    args: argparse.Namespace,
    setup: Mapping[str, object],
) -> np.ndarray:
    map_position = np.asarray(setup["map_position"], dtype=np.float64)
    factor = np.asarray(setup["laplace_factor"], dtype=np.float64)
    candidates = np.asarray(setup["candidate_positions"], dtype=np.float64)
    rng = np.random.default_rng(args.sampler_seed + 29_011)
    positions = []
    for chain_index in range(args.num_chains):
        center = candidates[chain_index % len(candidates)]
        center_z = np.linalg.solve(factor, center - map_position)
        jitter = rng.normal(0.0, args.init_overdispersion, size=args.latent_dim)
        positions.append(center_z + jitter)
    return np.stack(positions).astype(np.float64)


def stabilize_chain_initial_positions(
    positions: np.ndarray,
    potential_z,
    *,
    max_shrinks: int = 12,
) -> np.ndarray:
    """Shrink only pathological starts toward the MAP until U and grad are finite."""
    value_grad = jax.jit(jax.value_and_grad(potential_z))
    stabilized = np.asarray(positions, dtype=np.float64).copy()
    for chain_index in range(stabilized.shape[0]):
        candidate = stabilized[chain_index]
        for shrink_index in range(max_shrinks + 1):
            value, gradient = value_grad(jnp.asarray(candidate, dtype=jnp.float64))
            value_np = float(np.asarray(jax.device_get(value)))
            gradient_np = np.asarray(jax.device_get(gradient), dtype=np.float64)
            if math.isfinite(value_np) and np.isfinite(gradient_np).all():
                stabilized[chain_index] = candidate
                if shrink_index:
                    print(
                        f"Shrank chain {chain_index} initialization toward the MAP "
                        f"{shrink_index} time(s) to obtain finite geometry."
                    )
                break
            candidate = 0.5 * candidate
        else:
            raise FloatingPointError(
                f"Could not obtain a finite initialization for chain {chain_index}."
            )
    return stabilized


def arviz_diagnostics(
    samples_by_chain: np.ndarray,
    derived: Mapping[str, np.ndarray],
) -> Tuple[Dict[str, object], List[Dict[str, object]]]:
    posterior = {"alpha": np.asarray(samples_by_chain, dtype=np.float64)}
    posterior.update({key: np.asarray(value) for key, value in derived.items()})
    inference_data = az.from_dict(posterior=posterior)
    rhat_data = az.rhat(inference_data, method="rank")
    bulk_data = az.ess(inference_data, method="bulk")
    tail_data = az.ess(inference_data, method="tail")
    mcse_data = az.mcse(inference_data, method="mean")

    rows: List[Dict[str, object]] = []
    for variable in posterior:
        rhat = np.asarray(rhat_data[variable].values, dtype=np.float64)
        bulk = np.asarray(bulk_data[variable].values, dtype=np.float64)
        tail = np.asarray(tail_data[variable].values, dtype=np.float64)
        mcse = np.asarray(mcse_data[variable].values, dtype=np.float64)
        shape = rhat.shape
        for flat_index in range(max(1, rhat.size)):
            coordinate = None if shape == () else np.unravel_index(flat_index, shape)
            rows.append(
                {
                    "variable": variable,
                    "coordinate": "" if coordinate is None else ",".join(map(str, coordinate)),
                    "rank_rhat": float(rhat.reshape(-1)[flat_index]),
                    "bulk_ess": float(bulk.reshape(-1)[flat_index]),
                    "tail_ess": float(tail.reshape(-1)[flat_index]),
                    "mcse_mean": float(mcse.reshape(-1)[flat_index]),
                }
            )
    all_rhat = np.asarray([row["rank_rhat"] for row in rows], dtype=np.float64)
    all_bulk = np.asarray([row["bulk_ess"] for row in rows], dtype=np.float64)
    all_tail = np.asarray([row["tail_ess"] for row in rows], dtype=np.float64)
    finite_mask = np.isfinite(all_rhat) & np.isfinite(all_bulk) & np.isfinite(all_tail)
    if finite_mask.any():
        max_rhat = float(np.max(all_rhat[finite_mask]))
        min_bulk = float(np.min(all_bulk[finite_mask]))
        min_tail = float(np.min(all_tail[finite_mask]))
    else:
        max_rhat = float("nan")
        min_bulk = float("nan")
        min_tail = float("nan")
    return (
        {
            "finite": bool(finite_mask.all()),
            "nonfinite_entries": int((~finite_mask).sum()),
            "max_rank_rhat": max_rhat,
            "min_bulk_ess": min_bulk,
            "min_tail_ess": min_tail,
        },
        rows,
    )


def kernel_diagnostics(
    extras_by_name: Mapping[str, np.ndarray],
    *,
    max_tree_depth: int,
) -> Dict[str, object]:
    diverging = np.asarray(extras_by_name["diverging"], dtype=bool)
    accept = np.asarray(extras_by_name["accept_prob"], dtype=np.float64)
    num_steps = np.asarray(extras_by_name["num_steps"], dtype=np.int64)
    energy = np.asarray(extras_by_name["energy"], dtype=np.float64)
    step_size = np.asarray(
        extras_by_name["adapt_state.step_size"], dtype=np.float64
    )
    arrays_finite = bool(
        np.isfinite(accept).all()
        and np.isfinite(energy).all()
        and np.isfinite(step_size).all()
    )
    max_steps = 2 ** int(max_tree_depth) - 1
    per_chain = []
    for chain_index in range(diverging.shape[0]):
        chain_energy = energy[chain_index]
        energy_variance = float(np.var(chain_energy, ddof=1))
        ebfmi = (
            float(np.mean(np.diff(chain_energy) ** 2)) / energy_variance
            if energy_variance > 0.0
            else 0.0
        )
        per_chain.append(
            {
                "chain": chain_index,
                "divergences": int(diverging[chain_index].sum()),
                "mean_accept_prob": float(np.mean(accept[chain_index])),
                "tree_depth_saturation_fraction": float(
                    np.mean(num_steps[chain_index] >= max_steps)
                ),
                "mean_num_steps": float(np.mean(num_steps[chain_index])),
                "max_num_steps": int(np.max(num_steps[chain_index])),
                "ebfmi": ebfmi,
                "adapted_step_size": float(np.median(step_size[chain_index])),
            }
        )
    summary = {
        "finite": arrays_finite
        and all(math.isfinite(float(item["ebfmi"])) for item in per_chain),
        "total_divergences": int(diverging.sum()),
        "max_tree_depth_saturation_fraction": float(
            max(item["tree_depth_saturation_fraction"] for item in per_chain)
        ),
        "min_ebfmi": float(min(item["ebfmi"] for item in per_chain)),
        "min_mean_accept_prob": float(
            min(item["mean_accept_prob"] for item in per_chain)
        ),
        "per_chain": per_chain,
    }
    return summary


