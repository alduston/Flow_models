# Reusable operating standard: detached submission watcher

> For the prepared-target code update, first follow [TARGET_SNAPSHOT_FIX.md](TARGET_SNAPSHOT_FIX.md): stop polling, repair the frozen batch after running jobs finish, then resume. Extracting a new ZIP alone does not change a frozen batch.

Use this pattern for this bundle and future workflows that implement incremental `submit.sh --resume-batch ... --watch`. The watch option supplies planning/retry behavior; `nohup` supplies connection independence. It is not a generic retry wrapper for arbitrary job scripts.

## One-time setup for each terminal

Run from the extracted bundle directory on a Frontera login node, using the same working Python environment as the campaign:

```bash
source slurm/environment.sh
GP_BATCH=../batches/gad_ip_frontera_20261027_v3
GP_DRIVER_LOG=../gad_ip_frontera_20261027_v3_submit.log
```

Change both names for a different campaign. Keep logs outside the frozen source snapshot. Use one watcher per batch and record its login host alongside its PID.

## Initial submission

For a batch directory that does not exist yet:

```bash
nohup bash submit.sh \
  --batch "$GP_BATCH" \
  --reuse-from ../../../batches \
  --import-runs ../../.. --repeats 5 --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown

tail -n 20 "$GP_DRIVER_LOG"
```

A printed background PID means the shell launched a process. Confirm a healthy plan or successful submission completion in the log. A traceback means inspect and correct the error before resuming. The log appends across restarts rather than losing earlier evidence.

## Resume after interruption

Check the log and the recorded host/process first. If the watcher stopped, resume the existing batch:

```bash
nohup bash submit.sh \
  --resume-batch "$GP_BATCH" --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown
```

Selection, reuse paths and submitted IDs are persisted in the batch. The same resume recipe works after SSH disconnect, a stopped foreground watcher, laptop closure, or login-node interruption. Valid completed outputs and compatible live jobs on this cluster are skipped. Cross-cluster completed files can pass reuse checks, but live Vista job IDs cannot become Frontera dependencies. Never resume a Vista batch on Frontera; create a separate Frontera batch. A source/scientific configuration change needs a new batch; an operational restart does not.

## Inspect and stop the driver

```bash
tail -n 30 "$GP_DRIVER_LOG"
cat "$GP_DRIVER_LOG.host"
hostname
ps -p "$(cat "$GP_DRIVER_LOG.pid")" -o pid,etime,args
squeue -u "$USER"
python workflow.py status --batch "$GP_BATCH"
```

Run the process check on the recorded login host and confirm its command points to the intended batch. PID numbers can later be reused, so a saved PID alone is insufficient evidence of a live watcher. For a launch made without a PID file, use the PID printed by the launching shell on that same host.

To stop only the verified watcher, wait until its log says it is checking again in 30 seconds, then:

```bash
kill -TERM "$(cat "$GP_DRIVER_LOG.pid")"
```

This pauses future submissions. Already accepted Slurm jobs remain queued/running. To stop computation too, cancel the specific Slurm job IDs separately. A foreground watcher can be stopped with Ctrl+C while it is polling, then resumed with the detached recipe.

## Interpret the log

| Log evidence | Meaning / action |
| --- | --- |
| `checking again in 30s`, `0 failed` | Watcher is alive and waiting; deferred-node reasons distinguish queue/allocation limits from missing prerequisite outputs. |
| `0 new submissions` | No new task was eligible in this pass; this alone is not an error. |
| `cached` | A required stage/output passed the relevant reuse checks. One cached node does not mean the whole problem finished. |
| Scheduler insufficient balance / submit limit | Accepted IDs are retained, further attempts pause for that pass, and watch mode checks again. More total allocation may still be required. |
| Failed task or traceback | Inspect submission/job logs. The watcher does not keep blindly retrying a scientific failure. |
| Final `Batch:` and `Results:` lines, no deferred/failed work in the plan | Submission is complete; compute jobs may still run. The watcher can exit normally. |

`submission_plan.json`, `jobs.json` and the job/stage logs retain the detailed evidence. The watcher is a login-node process rather than a Slurm job, so it does not appear in `squeue`.

## Operational adjustments

After stopping the previous watcher, restart the resume recipe with any needed operational flags on its `submit.sh` command:

- `--max-outstanding-tasks 24`: lower the cap across all the user's queued/running task slots.
- `--poll-seconds 60`: check once a minute instead of every 30 seconds.
- `--time chain=12:00:00 --time repeat=01:00:00`: set reservations for newly submitted tasks. Existing submissions keep their limits. Supply intended overrides again on a later driver restart.
- `--repeats 10`: expand the selection after the previous aggregate job completes. Previously completed compatible work is retained.
- `--retry-failed`: request a deliberate retry after investigating the failed task. At most one retry per task is allowed per watcher invocation; no automatic scientific retry loop is introduced.

The Frontera default cap is 32 local-cluster task slots, below the supplied RTX MaxSubmit of 36. The supplied sinfo snapshot shows rtx availability drain; the planner defers new submissions until sinfo reports up. This is healthy waiting and is recorded in submission_plan.json.

The cap and shorter reservations reduce simultaneous allocation encumbrance. They do not lower the workload's required compute or replenish SUs. Leave the watcher running while ordinary limits/prerequisites clear; if the remaining workload exceeds the total allocation, change the allocation or requested workload.

## Preview without submitting

Preview uses a foreground command because it is one finite planning pass:

```bash
bash submit.sh --batch ../batches/gad_ip_frontera_preview \
  --reuse-from ../../../batches \
  --import-runs ../../.. --repeats 5 --dry-run
```

Inspect the preview's `submission_plan.json`. To run that exact frozen plan, use the detached resume recipe with `GP_BATCH=../batches/gad_ip_frontera_preview`. Do not combine `--watch` with `--dry-run`. Away from Frontera, add `--offline --dry-run`; that preview cannot inspect live jobs.

See [RUN_ON_FRONTERA.md](RUN_ON_FRONTERA.md) for the current GAD campaign's exact paths, expected initial deferrals and collection commands.
