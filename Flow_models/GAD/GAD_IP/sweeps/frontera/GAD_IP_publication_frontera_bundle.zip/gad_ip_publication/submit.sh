#!/bin/bash
set -eo pipefail
GP_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec "${GP_PYTHON:-python3}" "$GP_ROOT/workflow.py" submit "$@"
