"""Frontera environment and compatibility checks without a remote cluster."""
import ast
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from cache import kernel_digest


class FronteraTests(unittest.TestCase):
    def test_legacy_arviz_with_current_scipy(self):
        from arviz_compat import load_arviz
        import numpy as np
        az=load_arviz()
        data=az.from_dict(posterior={'probe':np.random.default_rng(4).normal(size=(4,200,2))})
        for function,method in ((az.rhat,'rank'),(az.ess,'bulk'),(az.ess,'tail'),(az.mcse,'mean')):
            self.assertTrue(np.isfinite(function(data,method=method)['probe'].values).all())

    def test_python39_syntax_and_postponed_protocol_annotations(self):
        for path in ROOT.rglob('*.py'):
            if 'provenance' in path.relative_to(ROOT).parts:continue
            ast.parse(path.read_text(),filename=str(path),feature_version=(3,9))
        sys.path.insert(0,str(ROOT/'vendor/screening'))
        from protocol import Settings
        self.assertEqual(Settings.__annotations__['bank'],'int | None')
        self.assertEqual(Settings(particles=1000).bank,1000)

    def test_annotation_backport_preserves_legacy_kernel_identity(self):
        path=ROOT/'vendor/screening/protocol.py'
        legacy=path.read_bytes().replace(b'from __future__ import annotations\n',b'',1)
        self.assertEqual(kernel_digest(path),hashlib.sha256(legacy).hexdigest())
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'protocol.py';p.write_bytes(legacy)
            self.assertEqual(kernel_digest(path),kernel_digest(p))
            p.write_bytes(legacy+b'\n# another change\n')
            self.assertNotEqual(kernel_digest(path),kernel_digest(p))

    def test_environment_modules_activation_and_gpu_visibility(self):
        with tempfile.TemporaryDirectory() as directory:
            venv=Path(directory)/'venv';(venv/'bin').mkdir(parents=True)
            (venv/'bin/activate').write_text('export QA_ACTIVATED=yes\n')
            env=dict(os.environ,GP_VENV_DIR=str(venv),GP_SKIP_MODULES='0',GP_CUDA_VISIBLE_DEVICES='2')
            for key in ('GP_GCC_MODULE','GP_PYTHON_MODULE'):env.pop(key,None)
            script='module() { echo "module $*"; }; source "$1"; printf "activated=%s gpu=%s\\n" "$QA_ACTIVATED" "$CUDA_VISIBLE_DEVICES"'
            result=subprocess.run(['bash','-c',script,'qa',str(ROOT/'slurm/environment.sh')],env=env,text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('module load gcc/9.1.0',result.stdout)
            self.assertIn('module load python3/3.9.2',result.stdout)
            self.assertIn('activated=yes gpu=2',result.stdout)

    def test_missing_venv_fails_clearly(self):
        env=dict(os.environ,GP_VENV_DIR='/nonexistent/gad_frontera_qa_venv',GP_SKIP_MODULES='0')
        result=subprocess.run(['bash','-c','module() { :; }; source "$1"','qa',str(ROOT/'slurm/environment.sh')],env=env,text=True,capture_output=True)
        self.assertEqual(result.returncode,2)
        self.assertIn('Expected venv',result.stderr)
