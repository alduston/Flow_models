"""Frontera environment and compatibility checks without a remote cluster."""
import ast
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from cache import kernel_digest


class FronteraTests(unittest.TestCase):
    def test_isolated_arviz_full_reference_routines(self):
        import numpy as np
        from arviz_compat import _isolated_arviz,diagnostics_python
        if not diagnostics_python().is_file():self.skipTest('Set GP_DIAGNOSTICS_PYTHON to a NumPy-1/ArviZ environment')
        az=_isolated_arviz()
        samples=np.random.default_rng(443).normal(size=(4,240,3))
        derived={'scalar':samples.mean(-1),'matrix':samples[:,:,:2].reshape(4,240,1,2)}
        data=az.from_dict(posterior={'alpha':samples,**derived})
        for name,method in [('rhat','rank'),('ess','bulk'),('ess','tail'),('mcse','mean')]:
            result=getattr(az,name)(data,method=method)
            self.assertEqual(result['matrix'].values.shape,(1,2))
            self.assertEqual(result['scalar'].values.shape,())
            self.assertTrue(np.isfinite(result['alpha'].values).all())
        saved=data.results
        az.ess(data,method='bulk');self.assertIs(data.results,saved)
        from arviz_compat import load_arviz
        load_arviz()
        from reference_core import arviz_diagnostics
        with patch.dict(arviz_diagnostics.__globals__,az=az):
            diagnostic,rows=arviz_diagnostics(samples,derived)
        self.assertTrue(diagnostic['finite'])
        self.assertEqual(len(rows),6)
        self.assertLess(diagnostic['max_rank_rhat'],1.05)

    def test_isolated_diagnostic_results_match_native_library(self):
        import numpy as np
        from arviz_compat import _isolated_arviz,diagnostics_python
        if not diagnostics_python().is_file():self.skipTest('Set GP_DIAGNOSTICS_PYTHON to a NumPy-1/ArviZ environment')
        samples=np.random.default_rng(5).normal(size=(4,150,2))
        az=_isolated_arviz();data=az.from_dict(posterior={'alpha':samples})
        with tempfile.TemporaryDirectory() as directory:
            inp=Path(directory)/'input.npz';out=Path(directory)/'native.npz';np.savez(inp,alpha=samples)
            code='''import sys,numpy as np,scipy.signal
if not hasattr(scipy.signal,"gaussian"):scipy.signal.gaussian=scipy.signal.windows.gaussian
import arviz as az
x=az.from_dict(posterior={"alpha":np.load(sys.argv[1])["alpha"]})
np.savez(sys.argv[2],rank=az.rhat(x,method="rank")["alpha"].values,bulk=az.ess(x,method="bulk")["alpha"].values,tail=az.ess(x,method="tail")["alpha"].values,mean=az.mcse(x,method="mean")["alpha"].values)
'''
            subprocess.run([str(diagnostics_python()),'-I','-c',code,str(inp),str(out)],check=True,capture_output=True)
            with np.load(out) as expected:
                for name,method in [('rhat','rank'),('ess','bulk'),('ess','tail'),('mcse','mean')]:
                    np.testing.assert_array_equal(getattr(az,name)(data,method=method)['alpha'].values,expected[method])

    def test_legacy_arviz_with_current_scipy(self):
        from arviz_compat import load_arviz
        import numpy as np
        az=load_arviz()
        data=az.from_dict(posterior={'probe':np.random.default_rng(4).normal(size=(4,200,2))})
        for function,method in ((az.rhat,'rank'),(az.ess,'bulk'),(az.ess,'tail'),(az.mcse,'mean')):
            self.assertTrue(np.isfinite(function(data,method=method)['probe'].values).all())

    def test_python39_syntax_and_postponed_protocol_annotations(self):
        for path in ROOT.rglob('*.py'):
            if 'provenance' in path.relative_to(ROOT).parts:continue
            ast.parse(path.read_text(),filename=str(path),feature_version=(3,9))
        sys.path.insert(0,str(ROOT/'vendor/screening'))
        from protocol import Settings
        self.assertEqual(Settings.__annotations__['bank'],'int | None')
        self.assertEqual(Settings(particles=1000).bank,1000)

    def test_annotation_backport_preserves_legacy_kernel_identity(self):
        path=ROOT/'vendor/screening/protocol.py'
        legacy=path.read_bytes().replace(b'from __future__ import annotations\n',b'',1)
        self.assertEqual(kernel_digest(path),hashlib.sha256(legacy).hexdigest())
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'protocol.py';p.write_bytes(legacy)
            self.assertEqual(kernel_digest(path),kernel_digest(p))
            p.write_bytes(legacy+b'\n# another change\n')
            self.assertNotEqual(kernel_digest(path),kernel_digest(p))

    def test_environment_modules_activation_and_gpu_visibility(self):
        with tempfile.TemporaryDirectory() as directory:
            venv=Path(directory)/'venv';(venv/'bin').mkdir(parents=True)
            (venv/'bin/activate').write_text('export QA_ACTIVATED=yes\n')
            env=dict(os.environ,GP_VENV_DIR=str(venv),GP_SKIP_MODULES='0',GP_CUDA_VISIBLE_DEVICES='2')
            for key in ('GP_GCC_MODULE','GP_PYTHON_MODULE'):env.pop(key,None)
            script='module() { echo "module $*"; }; source "$1"; printf "activated=%s gpu=%s\\n" "$QA_ACTIVATED" "$CUDA_VISIBLE_DEVICES"'
            result=subprocess.run(['bash','-c',script,'qa',str(ROOT/'slurm/environment.sh')],env=env,text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('module load gcc/9.1.0',result.stdout)
            self.assertIn('module load python3/3.9.2',result.stdout)
            self.assertIn('activated=yes gpu=2',result.stdout)

    def test_missing_venv_fails_clearly(self):
        env=dict(os.environ,GP_VENV_DIR='/nonexistent/gad_frontera_qa_venv',GP_SKIP_MODULES='0')
        result=subprocess.run(['bash','-c','module() { :; }; source "$1"','qa',str(ROOT/'slurm/environment.sh')],env=env,text=True,capture_output=True)
        self.assertEqual(result.returncode,2)
        self.assertIn('Expected venv',result.stderr)
