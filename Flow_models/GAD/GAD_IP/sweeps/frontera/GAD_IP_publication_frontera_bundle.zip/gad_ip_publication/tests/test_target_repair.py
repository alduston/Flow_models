"""Exercise audited frozen-source repair without contacting Slurm."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch
import subprocess
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import repair_target_snapshots as repair
from common import read_json,write_json,digest
from workflow import freeze,verify_frozen


class FrozenTargetRepairTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.batch=freeze(ROOT/'settings.json',Path(self.temp.name)/'batch',['allen_cahn'])
        old=ROOT/'provenance/target_snapshot_before'
        for name in ['common.py','cache.py']:shutil.copy2(old/name,self.batch/'code'/name)
        for name in repair.COMPATIBILITY_BASELINES:
            shutil.copy2(ROOT/'provenance/frontera_package_compat_before'/name,self.batch/'code'/name)
        (self.batch/'code/target_snapshot.py').unlink()
        manifest=read_json(self.batch/'source_manifest.json');manifest.pop('target_snapshot.py')
        for name in ['common.py','cache.py']+list(repair.COMPATIBILITY_BASELINES):manifest[name]=digest(self.batch/'code'/name)
        write_json(self.batch/'source_manifest.json',manifest)
        meta=read_json(self.batch/'batch.json');meta['source_manifest_sha256']=digest(self.batch/'source_manifest.json');write_json(self.batch/'batch.json',meta)
        write_json(self.batch/'jobs.json',{'prepare':dict(id='100'),'chains':dict(id='101')})
        self.protected=self.batch/'reference/allen_cahn/setup.npz';self.protected.parent.mkdir(parents=True);self.protected.write_bytes(b'QA map marker')
        self.settings=(self.batch/'settings.json').read_bytes()
        self.calls=[]

    def tearDown(self):self.temp.cleanup()

    def fake(self,cmd,**kwargs):
        self.calls.append(cmd)
        text='100|PENDING|Dependency\n101|PENDING|JobHeldUser\n999|RUNNING|None\n' if cmd[0]=='squeue' else ''
        return subprocess.CompletedProcess(cmd,0,stdout=text,stderr='')

    def test_holds_pending_jobs_preserves_manual_holds_and_updates_manifest(self):
        with patch.object(repair.subprocess,'run',side_effect=self.fake):repair.repair(self.batch)
        self.assertIn(['scontrol','hold','100'],self.calls);self.assertIn(['scontrol','release','100'],self.calls)
        self.assertNotIn(['scontrol','release','101'],self.calls)
        self.assertEqual((self.batch/'settings.json').read_bytes(),self.settings)
        self.assertEqual(self.protected.read_bytes(),b'QA map marker')
        verify_frozen(self.batch)
        self.assertTrue((self.batch/'code/target_snapshot.py').exists())
        self.assertEqual((self.batch/'code/arviz_compat.py').read_bytes(),(ROOT/'arviz_compat.py').read_bytes())
        self.assertEqual(read_json(self.batch/'batch.json')['frontera_environment_fix'],repair.ENVIRONMENT_FIX)
        self.assertTrue(list((self.batch/'repairs').glob('*/repair.json')))
        # Applying the same version twice creates no second backup/submissions.
        with patch.object(repair.subprocess,'run',side_effect=AssertionError('unexpected Slurm call')):repair.repair(self.batch)
        self.assertEqual(len(list((self.batch/'repairs').glob('*/repair.json'))),1)

    def test_refuses_running_batch_before_modifying_code(self):
        before=digest(self.batch/'code/common.py')
        result=subprocess.CompletedProcess([],0,stdout='100|RUNNING|None\n101|PENDING|Dependency\n',stderr='')
        with patch.object(repair.subprocess,'run',return_value=result):
            with self.assertRaisesRegex(RuntimeError,'active jobs'):repair.repair(self.batch)
        self.assertEqual(digest(self.batch/'code/common.py'),before)
        self.assertFalse((self.batch/'repairs').exists())

    def test_rejects_modified_frozen_source(self):
        with (self.batch/'code/common.py').open('a') as f:f.write('\n# changed\n')
        with self.assertRaisesRegex(ValueError,'Frozen source was modified'):repair.repair(self.batch,offline=True)

    def test_updates_environment_even_if_target_snapshot_was_already_repaired(self):
        common=self.batch/'code/common.py';common.write_text(repair.patch_common(common.read_text()))
        cache=self.batch/'code/cache.py';cache.write_text(repair.patch_cache(cache.read_text()))
        shutil.copy2(ROOT/'target_snapshot.py',self.batch/'code/target_snapshot.py')
        manifest=read_json(self.batch/'source_manifest.json')
        for name in ['common.py','cache.py','target_snapshot.py']:manifest[name]=digest(self.batch/'code'/name)
        write_json(self.batch/'source_manifest.json',manifest)
        meta=read_json(self.batch/'batch.json');meta['source_manifest_sha256']=digest(self.batch/'source_manifest.json');write_json(self.batch/'batch.json',meta)
        repair.repair(self.batch,offline=True)
        record=read_json(next((self.batch/'repairs').glob('*/repair.json')))
        self.assertEqual(set(record['changed_source_files']),{'arviz_compat.py','install_reference_extras.sh'})
        verify_frozen(self.batch)

    def test_preserves_unknown_local_environment_customizations(self):
        path=self.batch/'code/arviz_compat.py';path.write_text(path.read_text()+'\n# local customization\n')
        manifest=read_json(self.batch/'source_manifest.json');manifest['arviz_compat.py']=digest(path)
        write_json(self.batch/'source_manifest.json',manifest)
        meta=read_json(self.batch/'batch.json');meta['source_manifest_sha256']=digest(self.batch/'source_manifest.json');write_json(self.batch/'batch.json',meta)
        with self.assertRaisesRegex(ValueError,'Unrecognized arviz_compat.py'):
            repair.repair(self.batch,offline=True)
        self.assertFalse((self.batch/'repairs').exists())

    def test_rollback_restores_source_and_metadata_after_failed_commit(self):
        original_write=repair.write;before=digest(self.batch/'code/common.py');manifest=digest(self.batch/'source_manifest.json')
        def fail(path,text):
            if Path(path)==self.batch/'source_manifest.json':raise OSError('QA commit failure')
            return original_write(path,text)
        with patch.object(repair,'write',side_effect=fail):
            with self.assertRaisesRegex(OSError,'QA commit failure'):repair.repair(self.batch,offline=True)
        self.assertEqual(digest(self.batch/'code/common.py'),before)
        self.assertEqual(digest(self.batch/'source_manifest.json'),manifest)
        self.assertFalse((self.batch/'code/target_snapshot.py').exists())
        verify_frozen(self.batch)


if __name__=='__main__':unittest.main()
