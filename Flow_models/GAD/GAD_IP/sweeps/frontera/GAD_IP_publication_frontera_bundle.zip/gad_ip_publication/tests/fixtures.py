"""Small synthetic fixtures for QA only. Never included as scientific results."""
import sys
import shutil
from dataclasses import asdict
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import (ROOT, digest, field_summary, fields_from_latents, read_json, run_directory,
                    save_npz, write_json,fingerprint,sampler_settings,signature)
from comparison import cloud_metrics, reference_geometry, reference_floors


def synthetic_batch(directory,problem='afwi',rounds=4):
    batch=Path(directory)/'synthetic';batch.mkdir()
    config=read_json(ROOT/'settings.json');config['problems']={problem:{'particles':80}}
    config['sampler']['rounds']=rounds;config['active_problems']=[problem]
    config['nuts']['num_samples']=100;config['evaluation'].update(distribution_cap=64,sliced_directions=8,floor_replicates=4)
    config['aggregation'].update(bootstrap_replicates=200,png_dpi=85)
    shutil.copytree(ROOT,batch/'code',ignore=shutil.ignore_patterns('__pycache__','.pytest_cache','batches','output'))
    write_json(batch/'settings.json',config);write_json(batch/'batch.json',dict(problems=[problem],qa_label='SYNTHETIC QA ONLY',workflow_version=2))
    write_json(batch/'selection.json',dict(sampler_seeds=config['sampler_seeds'],maximum=10))
    write_json(batch/'reuse_sources.json',dict(batches=[],screening_runs=[]))
    (batch/'stages').mkdir();(batch/'logs').mkdir()
    rng=np.random.default_rng(620);chains=rng.normal(0,.2,size=(4,100,6));reference=chains.reshape(-1,6);dim=6;n=8
    basis=rng.normal(0,.2,(n*n,dim));spec=dict(problem=np.asarray(problem),grid=np.asarray(n),basis=basis,mask=np.ones((n,n)),scale=np.asarray(.32),background=np.asarray(1.))
    truthalpha=np.zeros(dim);truth=fields_from_latents(truthalpha[None],spec)[0];spec['truth']=truth
    out=batch/'reference'/problem;out.mkdir(parents=True)
    save_npz(out/'physical_spec.npz',**spec)
    arrays=dict(alpha_true_np=truthalpha,y_obs_np=np.zeros(20),y_clean_np=np.zeros(20),y_holdout_obs_np=np.zeros(12),y_holdout_clean_np=np.zeros(12),
                basis=basis,receiver_flat_indices=np.array([8,9,10]),source_centers=np.array([[.2,.2],[.8,.2]]))
    save_npz(out/'target_arrays.npz',**arrays);target_arrays=arrays
    metadata=dict(dimension=dim,data_seed=config['data_seed'],model_sha256=digest(ROOT/f'vendor/screening/models/{problem}.py'))
    identity=fingerprint(metadata,arrays)
    write_json(out/'target.json',dict(fingerprint=identity,metadata=metadata))
    save_npz(out/'setup.npz',map_position=np.zeros(dim),laplace_factor=np.eye(dim),candidate_positions=np.zeros((1,dim)),initial_z=np.zeros((4,dim)))
    setup_sha=digest(out/'setup.npz');write_json(out/'setup.json',dict(setup_sha256=setup_sha,fingerprint=identity))
    write_json(out/'model_derivative_check.json',dict(finite=True))
    for i in range(4):
        path=out/'chains'/f'chain_{i}.npz';size=len(chains[i])
        save_npz(path,samples=chains[i],z_samples=chains[i],potential_energy=(chains[i]**2).sum(1)/2,energy=rng.chisquare(6,size),
                 accept_prob=np.ones(size)*.95,num_steps=np.ones(size,dtype=int)*7,diverging=np.zeros(size,dtype=bool),
                 **{'adapt_state.step_size':np.ones(size)*.2})
        write_json(path.with_suffix('.json'),dict(identity=signature(dict(target=identity,setup=setup_sha)),sha256=digest(path),elapsed_seconds=1))
    save_npz(out/'reference_samples.npz',samples=reference,samples_by_chain=chains,certified=np.asarray(True),fingerprint=np.asarray(identity))
    geometry=reference_geometry(reference,config['evaluation']);save_npz(out/'geometry.npz',**geometry)
    floor=reference_floors(reference,geometry,64,config['evaluation']);save_npz(out/'sampling_floors.npz',**floor)
    fs=field_summary(reference,spec);state=np.stack([np.sin(np.linspace(0,6,n*n).reshape(n,n))*1e-4]*2)
    summary=dict(fs,truth=truth,mean_mc_ci_low=fs['mean']-.001,mean_mc_ci_high=fs['mean']+.001,
                 state_at_mean=state,state_truth=state*1.1,predictive_mean=np.zeros(12),predictive_std=np.ones(12)*.01,
                 y_holdout_obs=rng.normal(0,.01,12),y_holdout_clean=np.zeros(12),noise_std=np.asarray(.01))
    save_npz(out/'reference_summary.npz',**summary)
    from cache import summary_key,evaluation_key
    write_json(out/'summary.json',dict(compatibility_key=summary_key(config,problem),reference_sha256=digest(out/'reference_samples.npz'),
               summary_sha256=digest(out/'reference_summary.npz'),geometry_sha256=digest(out/'geometry.npz'),
               floor_sha256=digest(out/'sampling_floors.npz')))
    write_json(out/'nuts_diagnostics.json',dict(certified=True,reference_sha256=digest(out/'reference_samples.npz'),
               convergence=dict(finite=True,max_rank_rhat=1.001,min_bulk_ess=300,min_tail_ess=200),
               kernel=dict(finite=True,total_divergences=0,min_ebfmi=1.2,min_mean_accept_prob=.95,per_chain=[])))
    save_npz(out/'chain_diagnostics.npz',potential_energy=(chains*chains).sum(-1)/2)
    for seed in config['sampler_seeds']:
        directory=run_directory(batch,problem,seed);directory.mkdir(parents=True)
        rows={};arrays={};predictives={};raw={};states={'truth':state*1.1};logs={}
        for algorithm in ['GAD','MALA']:
            for r in range(1,rounds+1):
                label=f'{algorithm}-{r}';offset=(.12/r if algorithm=='GAD' else .1/r**.3)
                a=rng.normal(offset,.2,(80,dim));raw[label]=a;f=field_summary(a,spec)
                for key,value in f.items():arrays[label+'__'+key]=value
                states[label]=state*(1+.3/r);predictives[label+'__mean']=rng.normal(0,.002/r,12);predictives[label+'__std']=np.ones(12)*.01
                row=cloud_metrics(a,reference,geometry,config['evaluation'],random_seed=10)
                row.update(RefFieldMeanRelL2=float(np.linalg.norm(f['mean']-fs['mean'])/np.linalg.norm(fs['mean'])),
                           RefFieldStdRelL2=float(np.linalg.norm(f['std']-fs['std'])/np.linalg.norm(fs['std'])),
                           RefFieldCI95RMSE=float(np.sqrt(np.mean((f['q025']-fs['q025'])**2))),
                           RMSE_field=offset,RMSE_state=offset*.1,FwdRelErr=offset*.5,PosteriorMeanFieldRMSE=offset*.9,
                           ScaledHeldoutPredNLL=-2+rng.normal(0,.1),HeldoutPredNLL=-1.8,HeldoutCleanRelL2=offset,
                           ScaledHeldoutCoverage95=.92,KSD=offset*1000,KLdiag=offset*5,
                           finite_fraction=1.,heldout_predictive_finite_fraction=1.,
                           runtime_seconds=r*(2 if algorithm=='GAD' else 1),pde_solve_count=r*240)
                if algorithm=='MALA':row['mala_acceptance_rate']=.8
                rows[label]=row
                if algorithm=='GAD':logs[label]=dict(t=np.geomspace(10,.003,10),mean_ess=np.linspace(80,40-r*3,10))
        save_npz(directory/'samples_all_rounds.npz',**raw);save_npz(directory/'state_summaries.npz',**states)
        save_npz(directory/'publication_fields.npz',**arrays);save_npz(directory/'publication_predictives.npz',**predictives)
        write_json(directory/'metrics.json',rows);write_json(directory/'publication_metrics.json',rows)
        write_json(directory/'experiment_config.json',dict(problem=problem,seed=seed,sampler_seed=seed,data_seed=42,settings=asdict(sampler_settings(config,problem)),sampling_sha256=digest(ROOT/'vendor/screening/sampling.py'),
                   mala_checkpoint_sha256=digest(ROOT/'vendor/screening/mala_checkpoints.py'),model_sha256=digest(ROOT/f'vendor/screening/models/{problem}.py')))
        save_npz(directory/'realization.npz',alpha_true=target_arrays['alpha_true_np'],y_obs=target_arrays['y_obs_np'],y_clean=target_arrays['y_clean_np'],y_holdout_obs=target_arrays['y_holdout_obs_np'],basis=basis)
        write_json(directory/'ess_logs.json',logs);write_json(directory/'status.json',dict(state='complete'))
        write_json(directory/'repeat_identity.json',dict(data_seed=42,sampler_seed=seed,fingerprint=identity,samples_sha256=digest(directory/'samples_all_rounds.npz')))
        write_json(directory/'publication_identity.json',dict(evaluation_key=evaluation_key(batch,problem,seed),fingerprint=identity,reference_sha256=digest(out/'reference_samples.npz'),
                   metrics_sha256=digest(directory/'publication_metrics.json'),fields_sha256=digest(directory/'publication_fields.npz'),
                   predictive_sha256=digest(directory/'publication_predictives.npz')))
    return batch
