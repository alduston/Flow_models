"""CPU-only collection, paired repeat uncertainty, publication plots, and results ZIP."""
import argparse
import csv
from pathlib import Path
import shutil
import time
import zipfile
import numpy as np

from common import (NAMES, digest, load_npz, read_json, run_directory, settings,
                    verified_reference, write_json, selected_config,problem_config)

PRIMARY=['RMSE_field','RMSE_state','FwdRelErr','PosteriorMeanFieldRMSE']
REFERENCE=['RefMeanWhitenedRMSE','RefCovWhitenedRelFro','RefFieldMeanRelL2','RefFieldStdRelL2','RefFieldCI95RMSE','RefSW2']
REQUIRED=PRIMARY[:3]+REFERENCE+['ScaledHeldoutPredNLL','HeldoutCleanRelL2']


def write_csv(path,rows,leading=()):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    columns=list(leading)+sorted(set().union(*(r.keys() for r in rows))-set(leading)) if rows else list(leading)
    with path.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader();writer.writerows(rows)


def finite(x):return isinstance(x,(int,float,np.number)) and np.isfinite(x)


def bootstrap(values,indices,confidence=.95):
    values=np.asarray(values,dtype=float)
    if len(values)!=indices.shape[1]:raise ValueError('Bootstrap units must be independent sampler seeds')
    estimates=values[indices].mean(1);alpha=(1-confidence)/2
    return float(values.mean()),float(values.std(ddof=1)) if len(values)>1 else None,*map(float,np.quantile(estimates,[alpha,1-alpha]))


def summarize_rows(rows,config,problem):
    seeds=config['sampler_seeds'];n=len(seeds);out=[]
    random=np.random.default_rng(config['aggregation']['seed'])
    indices=random.integers(0,n,(config['aggregation']['bootstrap_replicates'],n))
    methods=sorted({r['method'] for r in rows},key=lambda s:(s.split('-')[0],int(s.split('-')[1])))
    for method in methods:
        selected={r['sampler_seed']:r for r in rows if r['method']==method}
        keys=sorted({k for r in selected.values() for k,v in r.items() if finite(v)})
        for metric in keys:
            if metric in ['round','seed','sampler_seed','data_seed']:continue
            values=[selected[s][metric] for s in seeds if s in selected and finite(selected[s].get(metric))]
            record=dict(problem=problem,method=method,algorithm=method.split('-')[0],round=int(method.split('-')[1]),
                        metric=metric,n=len(values),expected_n=n,median=float(np.median(values)) if values else None)
            if len(values)==n:
                mean,sd,low,high=bootstrap(values,indices,config['aggregation']['confidence'])
                record.update(mean=mean,sd=sd,ci_low=low,ci_high=high)
            else:record.update(mean=float(np.mean(values)) if values else None,sd=None,ci_low=None,ci_high=None)
            work=[selected[s].get('pde_solve_count') for s in seeds if s in selected]
            record['work_mean']=float(np.mean(work)) if work and all(finite(x) for x in work) else None
            out.append(record)
    return out


def paired_rows(rows,config,problem):
    seeds=config['sampler_seeds'];n=len(seeds);results=[]
    index={(r['sampler_seed'],r['method']):r for r in rows}
    random=np.random.default_rng(config['aggregation']['seed']);draws=random.integers(0,n,(config['aggregation']['bootstrap_replicates'],n))
    for r in range(1,config['sampler']['rounds']+1):
        for baseline in [f'MALA-{r}','GAD-1']:
            if baseline==f'GAD-{r}':continue
            for metric in PRIMARY+REFERENCE+['HeldoutPredNLL','ScaledHeldoutPredNLL','HeldoutCleanRelL2']:
                a=[index.get((s,f'GAD-{r}'),{}).get(metric) for s in seeds]
                b=[index.get((s,baseline),{}).get(metric) for s in seeds]
                present=[finite(x) and finite(y) for x,y in zip(a,b)]
                item=dict(problem=problem,method=f'GAD-{r}',baseline=baseline,metric=metric,n=sum(present),expected_n=n)
                if all(present):
                    a=np.asarray(a);b=np.asarray(b);delta=a-b
                    mean,sd,low,high=bootstrap(delta,draws,config['aggregation']['confidence'])
                    item.update(mean_difference=mean,sd_difference=sd,ci_low=low,ci_high=high,
                                gad_wins=int((delta<0).sum()),gad_ties=int((delta==0).sum()))
                    if np.all(b>0) and np.all(a>=0):
                        ratio=100*(1-a[draws].mean(1)/b[draws].mean(1));alpha=(1-config['aggregation']['confidence'])/2
                        item.update(percent_reduction_of_means=float(100*(1-a.mean()/b.mean())),
                                    reduction_ci_low=float(np.quantile(ratio,alpha)),reduction_ci_high=float(np.quantile(ratio,1-alpha)))
                results.append(item)
    return results


def collect(batch,config,problems):
    rows=[];manifest=[];quality_rows=[];missing=[];ready=[]
    for problem in problems:
        expected_labels={f'{a}-{r}' for a in ['GAD','MALA'] for r in range(1,problem_config(config,problem)['sampler']['rounds']+1)}
        reference_ok=False
        try:
            from cache import summary_valid
            if not summary_valid(batch,problem):raise ValueError('Reference summary settings or algorithm changed')
            ref,quality=verified_reference(batch,problem)
            record=read_json(batch/'reference'/problem/'summary.json')
            if record['reference_sha256']!=quality['reference_sha256']:raise ValueError('Stale reference summaries')
            for filename,key in [('reference_summary.npz','summary_sha256'),('geometry.npz','geometry_sha256'),('sampling_floors.npz','floor_sha256')]:
                if digest(batch/'reference'/problem/filename)!=record[key]:raise ValueError('Changed reference summaries')
            reference_ok=True
            row=dict(problem=problem,certified=True)
            row.update({('convergence_finite' if k=='finite' else k):v for k,v in quality['convergence'].items()})
            row.update({('kernel_finite' if k=='finite' else k):v for k,v in quality['kernel'].items() if k!='per_chain'})
            row['total_chain_wall_seconds']=sum(r.get('elapsed_seconds',0) for r in quality.get('chain_records',[]))
            quality_rows.append(row)
        except Exception as exc:
            missing.append(dict(problem=problem,stage='reference',error=f'{type(exc).__name__}: {exc}'))
            quality_rows.append(dict(problem=problem,certified=False,error=str(exc)))
        valid=0
        for seed in config['sampler_seeds']:
            directory=run_directory(batch,problem,seed);item=dict(problem=problem,sampler_seed=seed,data_seed=config['data_seed'],run_dir=str(directory),complete=False)
            try:
                status=read_json(directory/'status.json');item['canonical_state']=status['state'];item['warnings']=str(status.get('warnings',[]))
                selected=read_json(directory/'metrics.json');source='canonical_only'
                if (directory/'publication_metrics.json').exists():selected=read_json(directory/'publication_metrics.json');source='publication'
                for label,metrics in selected.items():
                    row=dict(metrics,problem=problem,method=label,algorithm=label.split('-')[0],round=int(label.split('-')[1]),
                             sampler_seed=seed,data_seed=config['data_seed'],metrics_source=source)
                    rows.append(row)
                if not reference_ok:raise ValueError('Independent reference unavailable or uncertified')
                from cache import evaluation_valid
                if not evaluation_valid(batch,problem,seed):raise ValueError('Run/evaluation settings or input/output checksums changed')
                if status['state']!='complete':raise ValueError('Canonical metrics incomplete')
                identity=read_json(directory/'publication_identity.json')
                repeat=read_json(directory/'repeat_identity.json')
                if repeat['samples_sha256']!=digest(directory/'samples_all_rounds.npz'):raise ValueError('Changed raw repeat samples')
                if identity['fingerprint']!=str(ref['fingerprint']) or repeat['fingerprint']!=str(ref['fingerprint']):raise ValueError('Target fingerprint mismatch')
                if identity['reference_sha256']!=quality['reference_sha256']:raise ValueError('Reference changed since evaluation')
                for filename,key in [('publication_metrics.json','metrics_sha256'),('publication_fields.npz','fields_sha256'),('publication_predictives.npz','predictive_sha256')]:
                    if digest(directory/filename)!=identity[key]:raise ValueError(f'Changed {filename}')
                if set(selected)!=expected_labels:raise ValueError('Missing or extra methods/rounds')
                if any(not finite(selected[label].get(metric)) for label in expected_labels for metric in REQUIRED):raise ValueError('Missing primary/reference metric')
                valid+=1;item['complete']=True
            except Exception as exc:
                item['error']=f'{type(exc).__name__}: {exc}';missing.append(dict(problem=problem,sampler_seed=seed,stage='repeat/evaluation',error=item['error']))
            manifest.append(item)
        if valid==len(config['sampler_seeds']) and reference_ok:ready.append(problem)
    return rows,manifest,quality_rows,missing,ready


def latex_tables(out,summary,config,problems):
    def number(metric,problem,label):
        values=[r for r in summary if r['metric']==metric and r['problem']==problem and r['method']==label]
        if not values or values[0]['n']!=len(config['sampler_seeds']):return '--'
        r=values[0];return f'${r["mean"]:.3g} \\pm {r["sd"]:.2g}$'
    out.mkdir(parents=True,exist_ok=True)
    for name,metrics in [('primary',PRIMARY[:3]),('posterior',REFERENCE),('diagnostics',['KSD','HeldoutPredNLL','ScaledHeldoutPredNLL','HeldoutCleanRelL2','runtime_seconds'])]:
        text=['% Generated means +/- sample SD over independent sampler seeds on fixed data.',
              '\\begin{tabular}{ll'+'r'*len(metrics)+'}','\\hline',
              'Problem & Method & '+' & '.join(m.replace('_','\\_') for m in metrics)+' \\\\','\\hline']
        for p in problems:
            for algorithm in ['GAD','MALA']:
                for r in range(1,problem_config(config,p)['sampler']['rounds']+1):
                    label=f'{algorithm}-{r}'
                    text.append(NAMES[p]+' & '+label+' & '+' & '.join(number(m,p,label) for m in metrics)+' \\\\')
            text.append('\\hline')
        text+=['\\end{tabular}','']
        (out/(name+'.tex')).write_text('\n'.join(text))


def package_results(batch):
    path=batch/'gad_ip_publication_results.zip';temporary=path.with_suffix('.zip.tmp')
    excluded={'__pycache__','.pytest_cache','checkpoints','failed_attempts','publication_model','data'}
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for top in ['meta_results','reference','runs','stages','logs','code']:
            directory=batch/top
            if not directory.exists():continue
            for p in sorted(directory.rglob('*')):
                if not p.is_file() or any(part in excluded or part.startswith('model_') for part in p.relative_to(directory).parts):continue
                if p.suffix=='.pkl':continue
                archive.write(p,p.relative_to(batch))
        for name in ['settings.json','batch.json','selection.json','reuse_sources.json','source_manifest.json','jobs.json','submission_plan.json','job_history.jsonl']:
            if (batch/name).exists():archive.write(batch/name,name)
    temporary.replace(path)
    return path


def aggregate(batch):
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    from plotting import problem_figures,style
    batch=Path(batch).resolve();config=selected_config(batch);problems=read_json(batch/'batch.json')['problems'];out=batch/'meta_results'
    # Archive old reports before regenerating, so a failed rerun cannot leave a stale publication claim.
    if out.exists():
        archive=batch/'previous_reports'/str(time.time_ns());archive.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(out),str(archive))
    out.mkdir();rows,manifest,quality,missing,ready=collect(batch,config,problems)
    summary=[];paired=[]
    for p in problems:
        selected=[r for r in rows if r['problem']==p]
        summary+=summarize_rows(selected,problem_config(config,p),p);paired+=paired_rows(selected,problem_config(config,p),p)
    write_csv(out/'all_metrics.csv',rows,['problem','sampler_seed','data_seed','method','round','algorithm'])
    write_csv(out/'summary.csv',summary,['problem','method','round','metric','n','expected_n','mean','median','sd','ci_low','ci_high'])
    write_csv(out/'paired_comparisons.csv',paired,['problem','method','baseline','metric','n','expected_n'])
    write_csv(out/'run_manifest.csv',manifest,['problem','sampler_seed','data_seed','complete','canonical_state','run_dir'])
    write_csv(out/'reference_quality.csv',quality,['problem','certified'])
    write_csv(out/'missing_or_failed.csv',missing,['problem','sampler_seed','stage','error'])
    latex_tables(out/'tables',summary,config,problems)
    complete=not missing;style();plot_errors=[];figure_count=0
    with PdfPages(out/'dashboard.pdf') as dashboard:
        fig=plt.figure(figsize=(8.27,11.69));fig.text(.08,.92,'GAD inverse-problem validation',size=19)
        qa_label=read_json(batch/'batch.json').get('qa_label')
        if qa_label:fig.text(.08,.95,qa_label,size=11,color='#A33B21')
        fig.text(.08,.875,'COMPLETE' if complete else 'INCOMPLETE - inspect missing_or_failed.csv',size=13,color='black' if complete else '#A33B21')
        text=[f'Fixed synthetic data seed: {config["data_seed"]}',f'Independent sampler seeds: {config["sampler_seeds"]}',
              'GAD rounds: '+', '.join(f'{p}={problem_config(config,p)["sampler"]["rounds"]}' for p in problems),
              f'Requested {len(config["sampler_seeds"])} of {len(settings(batch)["sampler_seeds"])} registered sampler seeds; canonical MALA',
              f'NUTS per problem: {config["nuts"]["num_chains"]} chains x {config["nuts"]["num_samples"]} retained draws',
              '', 'Uncertainty conventions:', 'Tables: mean +/- sample SD over sampler repeats.',
              'Curves: bootstrap 95% confidence intervals for the repeat mean.',
              'Summary CSV: fixed-round means, medians and sample SDs.',
              'Reconstruction SD maps: posterior spread within a run.',
              'NUTS MC error: block bootstrap and chain-based ESS/MCSE diagnostics.',
              '', 'Scientific scope:', 'One fixed inverse problem per model; these are not repeated data realizations.',
              'A diagnostic pass supports a NUTS reference; it is not a proof of global mixing.',
              'Work proxy preserves the supplied derivative-count convention, not FLOPs/time.',
              'Canonical metric definitions are retained, including the original NLL jitter.',
              'Scaled-jitter predictive NLL is an additional explicitly named metric.',
              '', 'Ready for figures: '+(', '.join(NAMES[p] for p in ready) or 'none')]
        fig.text(.08,.82,'\n'.join(text),size=10,va='top',linespacing=1.6);dashboard.savefig(fig);plt.close(fig)
        for p in ready:
            try:figure_count+=problem_figures(batch,p,problem_config(config,p),[r for r in summary if r['problem']==p],out/'figures'/p,dashboard)
            except Exception as exc:
                import traceback
                error=dict(problem=p,error=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc());plot_errors.append(error)
                write_json(out/f'plot_error_{p}.json',error)
    # Check every standalone PDF again after all renderers and the dashboard close.
    from pypdf import PdfReader
    for pdf in (out/'figures').rglob('*.pdf') if (out/'figures').exists() else []:
        try:
            if len(PdfReader(pdf).pages)!=1:raise ValueError('Expected one figure page')
        except Exception as exc:plot_errors.append(dict(file=str(pdf),error=str(exc)))
    if plot_errors:complete=False
    if not complete:
        # Keep partial review graphics clearly separated from a publication-ready report.
        (out/'dashboard.pdf').replace(out/'INCOMPLETE_dashboard.pdf')
    from planner import report_signature
    result=dict(complete=complete,ready_problems=ready,expected_problems=problems,
                input_signature=report_signature(batch,problems,config['sampler_seeds']),
                requested_repeats_per_problem=len(config['sampler_seeds']),registered_repeats_per_problem=len(settings(batch)['sampler_seeds']),
                valid_repeats=sum(r['complete'] for r in manifest),expected_repeats=len(problems)*len(config['sampler_seeds']),
                figure_count=figure_count,missing=missing,plot_errors=plot_errors)
    write_json(out/'completion.json',result)
    write_json(out/'metric_definitions.json',dict(
        canonical='Unmodified vendor/screening/evaluate.py and state_metrics.py; all finite particles, no IQR deletion.',
        reference_mean='RMSE of posterior mean difference in reference-whitened latent coordinates.',
        reference_cov='Relative Frobenius covariance error in reference-whitened coordinates; all output particles.',
        reference_field_mean='Relative L2 error of mean transformed physical fields against NUTS.',
        reference_field_sd='Relative L2 error of pointwise sample SD of transformed fields against NUTS.',
        reference_intervals='RMSE of pointwise 2.5% and 97.5% physical-field endpoints against NUTS.',
        reference_sw2='Exact empirical one-dimensional W2 averaged over 128 fixed directions after NUTS whitening; candidate cap 1000; full NUTS reference.',
        reference_mmd2='Unbiased squared RBF MMD with bandwidth sqrt(d) after NUTS whitening; capped subsets; finite-sample estimate can be negative.',
        scaled_nll='Gaussian full-covariance predictive NLL with jitter=max(noise_variance*1e-8, max_marginal_variance*1e-12); additive supplemental score.',
        uncertainty='Paired bootstrap unit is one independent sampler seed; no particle-wise bootstrap is used for repeat confidence intervals.',
        reference_floor='Candidate-size pooled-NUTS subcloud versus all remaining disjoint reference draws; finite-sample SW2 scale only, not an ESS-corrected lower bound.',
        physical_sd='ddof=1 sample SD. Original manuscript illustration used ddof=0; this bundle records the new convention explicitly.'))
    (out/'README.md').write_text(
        '# GAD publication results\n\n'+('All required outputs completed.' if complete else '**INCOMPLETE.** Inspect completion.json and missing_or_failed.csv before using these results.')+
        '\n\n`all_metrics.csv` retains every round, method and seed. `summary.csv` provides n, mean, SD and bootstrap intervals. '
        '`paired_comparisons.csv` contains GAD minus matched MALA and GAD minus GAD-1 differences, with paired bootstrap intervals and win counts. '
        '`reference_quality.csv` and reference/*/nuts_diagnostics.json report diagnostic checks.\n\n'
        'Figure captions and exact uncertainty definitions accompany every problem under figures/. PDF/SVG are publication formats; PNGs use the configured 600 dpi. '
        'Illustrations use the preselected seed, never the best-performing seed. No ten-realization/generalization claim is supported by these fixed-data repeats.\n\n'
        'The results ZIP includes raw method clouds, reference chains, identities, summaries, code and logs. Resumable trusted pickle checkpoints, repeated generated model_data directories, and older failed attempts remain in the Vista batch directory and are omitted from the ZIP.\n')
    package_results(batch)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--batch',type=Path,required=True)
    result=aggregate(parser.parse_args().batch)
    raise SystemExit(0 if result['complete'] else 2)
