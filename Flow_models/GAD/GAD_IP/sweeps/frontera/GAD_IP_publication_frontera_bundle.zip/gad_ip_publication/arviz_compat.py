"""Load the Python-3.9 ArviZ API without downgrading the working SciPy stack."""
import importlib.metadata


def load_arviz():
    version=importlib.metadata.version('arviz')
    if tuple(int(v) for v in version.split('.')[:2]) < (0,18):
        # ArviZ 0.17 imports the old SciPy alias, removed in SciPy 1.13.
        # It is the very same Gaussian window function in its current module.
        import scipy.signal
        if not hasattr(scipy.signal,'gaussian'):
            scipy.signal.gaussian=scipy.signal.windows.gaussian
    import arviz
    return arviz
