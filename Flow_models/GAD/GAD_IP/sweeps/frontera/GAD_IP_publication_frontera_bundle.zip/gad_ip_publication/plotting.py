"""Consistent manuscript-scale PDF/SVG/600-dpi PNG publication figures."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from common import NAMES, load_npz, read_json, run_directory, write_json

COLORS={'GAD':'#0072B2','MALA':'#D55E00','NUTS':'#343B40'}
LABELS={
    'RMSE_field':'Field RMSE (at mean coefficient)', 'RMSE_state':'Physical state RMSE', 'FwdRelErr':'Forward relative error',
    'RefMeanWhitenedRMSE':'Whitened mean error', 'RefCovWhitenedRelFro':'Whitened covariance error',
    'RefFieldMeanRelL2':'Posterior field mean error', 'RefFieldStdRelL2':'Posterior field SD error',
    'RefFieldCI95RMSE':'95% interval endpoint RMSE', 'RefSW2':'Whitened sliced Wasserstein',
    'ScaledHeldoutPredNLL':'Held-out predictive NLL (scaled jitter)', 'HeldoutCleanRelL2':'Clean held-out relative error',
    'KSD':r'Exact-score KSD$^2$', 'KLdiag':'Unnormalized KL diagnostic',
    'ScaledHeldoutCoverage95':'Held-out marginal coverage', 'mala_acceptance_rate':'MALA production acceptance'}


def style():
    plt.rcParams.update({'font.family':'serif','font.serif':['STIXGeneral','DejaVu Serif'],
                         'mathtext.fontset':'stix','font.size':8,'axes.titlesize':9,'axes.labelsize':8,
                         'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'lines.linewidth':1.3,
                         'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,
                         'savefig.facecolor':'white','pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})


def finish(fig,name,out,dashboard,dpi,captions,caption):
    import io
    from pypdf import PdfReader
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    # Buffer PDF bytes explicitly and replace atomically. Verify the actual
    # standalone artifact, not just the successfully rendered dashboard page.
    buffer=io.BytesIO();fig.savefig(buffer,format='pdf',dpi=dpi,bbox_inches='tight')
    payload=buffer.getvalue()
    if len(PdfReader(io.BytesIO(payload)).pages)!=1:raise ValueError('Malformed standalone PDF')
    pdf=out/(name+'.pdf');temporary=pdf.with_suffix('.pdf.tmp');temporary.write_bytes(payload);temporary.replace(pdf)
    fig.savefig(out/(name+'.svg'),dpi=dpi,bbox_inches='tight')
    fig.savefig(out/(name+'.png'),dpi=dpi,bbox_inches='tight')
    if dashboard:dashboard.savefig(fig,bbox_inches='tight',dpi=dpi)
    captions[name]=caption
    plt.close(fig)


def metric_curves(summary,metrics,problem,out,dashboard,dpi,captions,*,work=False,floor=None):
    ncols=3;nrows=int(np.ceil(len(metrics)/3))
    fig,axes=plt.subplots(nrows,ncols,figsize=(7.1,2.15*nrows),squeeze=False,layout='constrained')
    for ax,metric in zip(axes.flat,metrics):
        available=False
        for algorithm,marker in [('GAD','o'),('MALA','s')]:
            subset=[r for r in summary if r['metric']==metric and r['algorithm']==algorithm and r['n']==r['expected_n']]
            subset.sort(key=lambda x:x['round'])
            if not subset:continue
            x=np.asarray([r['work_mean'] if work else r['round'] for r in subset]);y=np.asarray([r['mean'] for r in subset])
            low=np.asarray([r['ci_low'] for r in subset]);high=np.asarray([r['ci_high'] for r in subset])
            ax.plot(x,y,marker=marker,ms=3.4,color=COLORS[algorithm],ls='-' if algorithm=='GAD' else '--',label=algorithm)
            ax.fill_between(x,low,high,color=COLORS[algorithm],alpha=.16,linewidth=0);available=True
        if metric=='RefSW2' and floor is not None:
            ax.axhspan(*np.quantile(floor['sw2'],[.05,.95]),color='gray',alpha=.13)
            ax.axhline(np.median(floor['sw2']),color='gray',lw=.8,ls=':',label='NUTS subcloud scale')
        if metric=='ScaledHeldoutCoverage95':ax.axhline(.95,color='gray',ls=':',lw=.8)
        ax.set_title(LABELS.get(metric,metric));ax.grid(alpha=.16,linewidth=.5)
        ax.set_xlabel('PDE / derivative work proxy' if work else 'Round / matched MALA budget')
        if not work:ax.set_xticks(sorted(set(r['round'] for r in summary)))
        if available:
            # Keep signed quantities and coverage on a linear scale. Positive error curves use log only when helpful.
            values=[r['mean'] for r in summary if r['metric']==metric and r['n']==r['expected_n']]
            if values and min(values)>0 and max(values)/min(values)>15 and metric not in ['ScaledHeldoutCoverage95','mala_acceptance_rate']:
                ax.set_yscale('log')
        else:ax.text(.5,.5,'Not available',ha='center',va='center',transform=ax.transAxes)
    for ax in list(axes.flat)[len(metrics):]:ax.set_visible(False)
    handles,labels=[],[]
    for ax in axes.flat:
        hh,ll=ax.get_legend_handles_labels()
        for h,l in zip(hh,ll):
            if l not in labels:handles.append(h);labels.append(l)
    if handles:fig.legend(handles,labels,loc='outside lower center',ncol=3,frameon=False)
    fig.suptitle(NAMES[problem],fontsize=10)
    name='posterior_error_vs_work' if work else ('reconstruction_vs_round' if metrics[0]=='RMSE_field' else 'secondary_diagnostics')
    count=summary[0]['expected_n'] if summary else 0
    caption=f'Mean over {count} independent sampler seeds on the fixed inverse problem. Shading: paired-seed bootstrap 95% confidence intervals for each mean, conditional on the shared NUTS reference; these are not posterior credible intervals and do not propagate reference MC error. '
    if work:caption+='Work uses the canonical screening derivative-count proxy, including MALA warmup and initialization; it is not FLOPs or elapsed time. Gray SW2 band compares a size-matched candidate subcloud with all remaining NUTS draws (5th-95th percentiles), not a posterior error bound. '
    if name=='secondary_diagnostics':caption+='KSD and unnormalized KL are supplementary diagnostics; scaled-jitter predictive NLL is an additional metric and does not replace the canonical score. '
    finish(fig,name,out,dashboard,dpi,captions,caption)


def field_maps(batch,problem,seed,rounds,out,dashboard,dpi,captions):
    directory=run_directory(batch,problem,seed);ref=load_npz(Path(batch)/'reference'/problem/'reference_summary.npz')
    fields=load_npz(directory/'publication_fields.npz');truth=ref['truth'];labels=['NUTS','GAD-1',f'GAD-{rounds}',f'MALA-{rounds}']
    means=[ref['mean']]+[fields[k+'__mean'] for k in labels[1:]]
    stds=[ref['std']]+[fields[k+'__std'] for k in labels[1:]]
    fig,axes=plt.subplots(3,5,figsize=(7.1,4.65),layout='constrained')
    allfields=[truth]+means;lo=min(a.min() for a in allfields);hi=max(a.max() for a in allfields)
    diverging=problem in ['navier_stokes','allen_cahn','helmholtz']
    if diverging:hi=max(abs(lo),abs(hi));lo=-hi
    errmax=max(float(np.max(np.abs(a-truth))) for a in means);stdmax=max(float(x.max()) for x in stds)
    for col,(name,mean) in enumerate(zip(['Truth']+labels,allfields)):
        im=axes[0,col].imshow(mean,origin='lower',cmap='RdBu_r' if diverging else 'viridis',vmin=lo,vmax=hi,interpolation='nearest')
        axes[0,col].set_title(name)
    for col,(mean,sd) in enumerate(zip(means,stds),1):
        error=np.abs(mean-truth)
        em=axes[1,col].imshow(error,origin='lower',cmap='magma',vmin=0,vmax=max(errmax,1e-15),interpolation='nearest')
        sm=axes[2,col].imshow(sd,origin='lower',cmap='viridis',vmin=0,vmax=max(stdmax,1e-15),interpolation='nearest')
    for row in [1,2]:
        axes[row,0].set_frame_on(False);axes[row,0].set_aspect('equal')
    for ax in axes.flat:ax.set_xticks([]);ax.set_yticks([])
    for i,label in enumerate(['Posterior mean','Absolute error','Posterior SD']):axes[i,0].set_ylabel(label)
    for row,image in enumerate([im,em,sm]):fig.colorbar(image,ax=axes[row,:],shrink=.77,pad=.015)
    fig.suptitle(f'{NAMES[problem]}: fixed illustration seed {seed}',fontsize=10)
    finish(fig,'field_reconstruction',out,dashboard,dpi,captions,
           f'Preselected illustration seed {seed}; columns are truth, independent NUTS, GAD-1, GAD-{rounds} and matched MALA-{rounds}. '
           'Rows show the Monte Carlo mean physical field, its absolute error against generating truth, and pointwise posterior sample SD (ddof=1). '
           'Nonlinear physical maps are averaged after transformation. Each row shares a common color scale across all methods, with no saturation. This SD is within-posterior spread, not across-run uncertainty.')


def spread_maps(batch,problem,seeds,rounds,out,dashboard,dpi,captions):
    labels=['GAD-1',f'GAD-{rounds}',f'MALA-{rounds}'];data=[]
    for label in labels:
        data.append(np.stack([load_npz(run_directory(batch,problem,s)/'publication_fields.npz')[label+'__mean'] for s in seeds]))
    mean=[a.mean(0) for a in data];sd=[a.std(0,ddof=1) for a in data]
    fig,axes=plt.subplots(2,3,figsize=(7.1,4.4),layout='constrained')
    lo=min(a.min() for a in mean);hi=max(a.max() for a in mean);maximum=max(a.max() for a in sd)
    for col,label in enumerate(labels):
        im=axes[0,col].imshow(mean[col],origin='lower',cmap='RdBu_r',vmin=lo,vmax=hi,interpolation='nearest')
        sm=axes[1,col].imshow(sd[col],origin='lower',cmap='viridis',vmin=0,vmax=max(maximum,1e-15),interpolation='nearest')
        axes[0,col].set_title(label)
    axes[0,0].set_ylabel('Mean of posterior means');axes[1,0].set_ylabel('SD across sampler repeats')
    for ax in axes.flat:ax.set_xticks([]);ax.set_yticks([])
    fig.colorbar(im,ax=axes[0,:],shrink=.8,pad=.015);fig.colorbar(sm,ax=axes[1,:],shrink=.8,pad=.015)
    fig.suptitle(f'{NAMES[problem]}: variation over {len(seeds)} sampler repeats',fontsize=10)
    finish(fig,'sampler_repeat_variation',out,dashboard,dpi,captions,
           f'Top: mean of {len(seeds)} independently estimated posterior field means. Bottom: sample SD of those means. '
           'The bottom row measures Monte Carlo repeatability on one fixed data set; it does not represent posterior spread or variability across new data sets.')


def state_maps(batch,problem,seed,rounds,out,dashboard,dpi,captions):
    ref=load_npz(Path(batch)/'reference'/problem/'reference_summary.npz');states=load_npz(run_directory(batch,problem,seed)/'state_summaries.npz')
    def panel(a):
        if a.ndim>2:a=a[0]
        return np.real(a)
    truth=panel(ref['state_truth']);labels=['Truth','NUTS','GAD-1',f'GAD-{rounds}',f'MALA-{rounds}']
    values=[truth,panel(ref['state_at_mean'])]+[panel(states[k]) for k in labels[2:]]
    fig,axes=plt.subplots(2,5,figsize=(7.1,3.35),layout='constrained')
    maximum=max(abs(a).max() for a in values);emax=max(abs(a-truth).max() for a in values[1:])
    for col,(value,label) in enumerate(zip(values,labels)):
        im=axes[0,col].imshow(value,origin='lower',cmap='RdBu_r',vmin=-maximum,vmax=maximum,interpolation='nearest');axes[0,col].set_title(label)
        if col:em=axes[1,col].imshow(abs(value-truth),origin='lower',cmap='magma',vmin=0,vmax=max(emax,1e-15),interpolation='nearest')
    axes[1,0].set_frame_on(False);axes[1,0].set_aspect('equal')
    axes[0,0].set_ylabel('State at mean coefficient');axes[1,0].set_ylabel('Absolute error')
    for ax in axes.flat:ax.set_xticks([]);ax.set_yticks([])
    fig.colorbar(im,ax=axes[0,:],shrink=.7,pad=.015);fig.colorbar(em,ax=axes[1,:],shrink=.7,pad=.015)
    suffix='; source 1, real component' if problem=='helmholtz' else ('; source 1' if problem=='afwi' else '')
    fig.suptitle(f'{NAMES[problem]}: physical state{suffix}',fontsize=10)
    finish(fig,'physical_state',out,dashboard,dpi,captions,
           'PDE state evaluated at each method\'s mean latent coefficient. For FWI only source 1 is displayed; for Helmholtz the real part of source 1 scattered pressure is displayed. '
           'Saved canonical RMSE_state uses the full physical state, all sources/components, and complex modulus-squared error where relevant. Visualization does not change that definition.')


def pca_maps(batch,problem,seed,rounds,out,dashboard,dpi,captions):
    refdir=Path(batch)/'reference'/problem;ref=load_npz(refdir/'reference_samples.npz');geo=load_npz(refdir/'geometry.npz')
    raw=load_npz(run_directory(batch,problem,seed)/'samples_all_rounds.npz')
    labels=['NUTS']+[f'GAD-{i}' for i in range(1,rounds+1)]+[f'MALA-{rounds}']
    for pair in range(min(3,geo['pca'].shape[1]//2)):
        basis=geo['pca'][:,2*pair:2*pair+2];scale=np.sqrt(np.maximum(geo['pca_variance'][2*pair:2*pair+2],1e-30))
        clouds=[(ref['samples'] if k=='NUTS' else raw[k])-geo['mean'] for k in labels]
        clouds=[(a@basis)/scale for a in clouds]
        nrows=int(np.ceil(len(labels)/3))
        fig,axes=plt.subplots(nrows,3,figsize=(7.1,2.25*nrows),squeeze=False,layout='constrained');hist=[]
        for a in clouds:
            h,edgesx,edgesy=np.histogram2d(a[:,0],a[:,1],bins=45,range=[[-4,4],[-4,4]])
            hist.append(h.T/(len(a)*(8/45)**2))
        maximum=max(h.max() for h in hist);positive=np.concatenate([h[h>0] for h in hist])
        norm=LogNorm(vmin=max(float(positive.min()),maximum/5000),vmax=maximum)
        for ax,label,a,h in zip(axes.flat,labels,clouds,hist):
            im=ax.imshow(np.ma.masked_equal(h,0),origin='lower',extent=(-4,4,-4,4),norm=norm,cmap='viridis',interpolation='nearest')
            outside=np.mean((np.abs(a)>4).any(1))
            ax.set_title(label);ax.text(.03,.97,f'Outside: {outside:.1%}',va='top',fontsize=6,transform=ax.transAxes,
                                      bbox=dict(facecolor='white',edgecolor='none',alpha=.85,pad=1.5))
            ax.set_xlabel(f'Reference PC{2*pair+1} / SD');ax.set_ylabel(f'Reference PC{2*pair+2} / SD')
        for ax in list(axes.flat)[len(labels):]:ax.set_visible(False)
        fig.colorbar(im,ax=axes.ravel().tolist(),label='Projected density',shrink=.8,pad=.015)
        fig.suptitle(f'{NAMES[problem]}: posterior projections, seed {seed}',fontsize=10)
        finish(fig,f'posterior_pca_{pair+1}',out,dashboard,dpi,captions,
               'Common PCA coordinates from NUTS only, standardized by reference PC SD. Common bins, density normalization and log color scale. '
               'Visible window is +/-4 reference SD; each panel reports the fraction outside the window. No finite particles are deleted from saved metrics. Histograms are illustrative seed 42, not pooled repeats.')


def predictive_plot(batch,problem,seed,rounds,out,dashboard,dpi,captions):
    ref=load_npz(Path(batch)/'reference'/problem/'reference_summary.npz');pred=load_npz(run_directory(batch,problem,seed)/'publication_predictives.npz')
    labels=['NUTS','GAD-1',f'GAD-{rounds}',f'MALA-{rounds}'];indices=np.unique(np.linspace(0,len(ref['y_holdout_obs'])-1,min(64,len(ref['y_holdout_obs'])),dtype=int))
    fig,axes=plt.subplots(2,2,figsize=(7.1,4.25),layout='constrained')
    for ax,label in zip(axes.flat,labels):
        mean=ref['predictive_mean'] if label=='NUTS' else pred[label+'__mean']
        sd=ref['predictive_std'] if label=='NUTS' else pred[label+'__std']
        radius=1.95996398454*np.sqrt(sd**2+float(ref['noise_std'])**2)
        color=COLORS['NUTS' if label=='NUTS' else label.split('-')[0]]
        ax.fill_between(indices,(mean-radius)[indices],(mean+radius)[indices],color=color,alpha=.2,label='95% Gaussian predictive interval')
        ax.plot(indices,mean[indices],lw=.9,color=color,label='Predictive mean')
        ax.plot(indices,ref['y_holdout_clean'][indices],'.',color='black',ms=2.1,label='Clean truth')
        ax.plot(indices,ref['y_holdout_obs'][indices],'x',color='gray',ms=2.6,mew=.6,label='Noisy observation')
        ax.set_title(label);ax.set_xlabel('Held-out measurement index');ax.ticklabel_format(axis='y',style='sci',scilimits=(-2,3))
    handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='outside lower center',ncol=2,frameon=False)
    fig.suptitle(f'{NAMES[problem]}: held-out predictions, seed {seed}',fontsize=10)
    finish(fig,'heldout_predictive_intervals',out,dashboard,dpi,captions,
           'Fixed, evenly spaced held-out indices (all indices remain in numeric scores). Bands are Gaussian marginal predictive intervals using posterior prediction variance plus known observation noise variance. '
           'These bands are not confidence intervals across sampler repeats. Clean-data prediction errors are reported alongside noisy predictive scores.')


def reference_plots(batch,problem,out,dashboard,dpi,captions):
    directory=Path(batch)/'reference'/problem;raw=load_npz(directory/'reference_samples.npz')['samples_by_chain'];extras=load_npz(directory/'chain_diagnostics.npz')
    geo=load_npz(directory/'geometry.npz');projected=(raw-geo['mean'])@geo['pca'][:,:2]
    fig,axes=plt.subplots(3,1,figsize=(7.1,4.5),layout='constrained')
    for ci in range(len(raw)):
        for col in range(2):axes[col].plot(projected[ci,:,col],lw=.4,alpha=.7,label=f'Chain {ci+1}')
        axes[2].plot(extras['potential_energy'][ci],lw=.4,alpha=.7)
    for ax,label in zip(axes,['Reference PC1','Reference PC2','Potential energy']):ax.set_ylabel(label)
    axes[-1].set_xlabel('Retained draw');axes[0].legend(ncol=4,loc='upper right',frameon=False)
    fig.suptitle(f'{NAMES[problem]}: NUTS trace diagnostics',fontsize=10)
    finish(fig,'nuts_traces',out,dashboard,dpi,captions,
           'All retained NUTS draws after warmup, colored by chain. Rank-normalized R-hat, bulk/tail ESS, MCSE, divergences, tree saturation, E-BFMI and acceptance are saved separately. Passing these checks does not prove global exploration.')
    # Reference Monte Carlo uncertainty is distinct from posterior SD.
    s=load_npz(directory/'reference_summary.npz');width=(s['mean_mc_ci_high']-s['mean_mc_ci_low'])/2
    fig,axes=plt.subplots(1,3,figsize=(7.1,2.45),layout='constrained')
    for ax,a,title in zip(axes,[s['std'],width,width/np.maximum(s['std'],1e-15)],['Posterior field SD','95% MC half-width for mean','MC half-width / posterior SD']):
        im=ax.imshow(a,origin='lower',cmap='viridis',interpolation='nearest');ax.set_title(title);ax.set_xticks([]);ax.set_yticks([])
        fig.colorbar(im,ax=ax,shrink=.8,pad=.02)
    fig.suptitle(NAMES[problem]+': reference uncertainty',fontsize=10)
    finish(fig,'nuts_monte_carlo_uncertainty',out,dashboard,dpi,captions,
           'Reference posterior field SD, 95% block-bootstrap Monte Carlo half-width for its mean, and their ratio. Blocks are resampled within each chain. '
           'These approximate MC intervals depend on the recorded block length; inspect diagnostics and block-length sensitivity before final reference claims.')


def geometry_plot(batch,problem,out,dashboard,dpi,captions):
    directory=Path(batch)/'reference'/problem;arrays=load_npz(directory/'target_arrays.npz');spec=load_npz(directory/'physical_spec.npz')
    truth=spec['truth'];n=len(truth)
    fig,ax=plt.subplots(figsize=(3.5,3.2),layout='constrained')
    im=ax.imshow(truth,origin='lower',extent=(-.5,n-.5,-.5,n-.5),cmap='RdBu_r' if problem!='afwi' else 'viridis',interpolation='nearest')
    train=arrays.get('obs_indices_train',arrays.get('receiver_flat_indices'))
    hold=arrays.get('obs_indices_holdout',arrays.get('holdout_receiver_flat_indices'))
    if problem=='afwi':hold=None  # These indices are time/source/receiver measurements, not grid locations.
    for ii,label,color,marker in [(train,'Training sensors','#00A676','o'),(hold,'Held-out sensors','#B34CBE','s')]:
        if ii is None:continue
        ii=np.asarray(ii,dtype=int).ravel();ax.scatter(ii%n,ii//n,s=8,marker=marker,facecolors='none',edgecolors=color,lw=.55,label=label)
    if 'source_centers' in arrays:
        points=arrays['source_centers'];ax.scatter(points[:,0]*(n-1),points[:,1]*(n-1),s=27,marker='*',color='#E69F00',label='Sources')
    ax.set_xticks([0,n-1]);ax.set_yticks([0,n-1]);ax.set_xlabel('Grid column index');ax.set_ylabel('Grid row index')
    ax.set_title(NAMES[problem]+': generating field and geometry');fig.colorbar(im,ax=ax,shrink=.8,pad=.02)
    if ax.collections:ax.legend(loc='lower right',fontsize=6,framealpha=.9)
    finish(fig,'truth_and_observation_geometry',out,dashboard,dpi,captions,
           'Generating unknown field and observation geometry in the solver array orientation. For initial-condition inversions, sensors observe the later state rather than the displayed initial field. '
           'FWI held-out indices select other time samples, so they are not plotted as separate spatial sensors. No observation or PDE setup is modified.')


def runtime_and_ess(batch,problem,config,summary,out,dashboard,dpi,captions):
    fig,axes=plt.subplots(1,2,figsize=(7.1,2.65),layout='constrained')
    for algorithm,marker in [('GAD','o'),('MALA','s')]:
        sub=sorted([r for r in summary if r['metric']=='runtime_seconds' and r['algorithm']==algorithm],key=lambda r:r['round'])
        x=np.asarray([r['work_mean'] for r in sub]);y=np.asarray([r['mean'] for r in sub]);low=np.asarray([r['ci_low'] for r in sub]);high=np.asarray([r['ci_high'] for r in sub])
        axes[0].plot(x,y,marker=marker,ms=3,color=COLORS[algorithm],label=algorithm)
        axes[0].fill_between(x,low,high,color=COLORS[algorithm],alpha=.16,linewidth=0)
    axes[0].set_xlabel('PDE / derivative work proxy');axes[0].set_ylabel('Cumulative sampler time (s)');axes[0].legend(frameon=False)
    random=np.random.default_rng(config['aggregation']['seed']);n=len(config['sampler_seeds'])
    draws=random.integers(0,n,(config['aggregation']['bootstrap_replicates'],n))
    for r in range(1,config['sampler']['rounds']+1):
        traces=[read_json(run_directory(batch,problem,s)/'ess_logs.json')[f'GAD-{r}'] for s in config['sampler_seeds']]
        times=np.asarray(traces[0]['t']);values=np.asarray([t['mean_ess'] for t in traces])/config['problems'][problem]['particles']
        if any(not np.allclose(times,t['t']) for t in traces):raise ValueError('ESS time grids disagree')
        ci=np.quantile(values[draws].mean(1),[.025,.975],axis=0)
        color=plt.get_cmap('viridis')((r-.5)/config['sampler']['rounds'])
        axes[1].plot(times,values.mean(0),label=f'GAD-{r}',color=color,lw=1)
        axes[1].fill_between(times,ci[0],ci[1],color=color,alpha=.12,linewidth=0)
    axes[1].set_xscale('log');axes[1].set_xlabel('OU time');axes[1].set_ylabel('Mean conditional ESS / bank size');axes[1].legend(frameon=False,ncol=2)
    for ax in axes:ax.grid(alpha=.15,lw=.5)
    fig.suptitle(NAMES[problem]+': runtime and reference-weight ESS',fontsize=10)
    finish(fig,'runtime_and_conditional_ess',out,dashboard,dpi,captions,
           'Left: original cumulative sampler timings and their repeat-mean bootstrap confidence intervals, versus the derivative-count proxy. No wallclock speedup is inferred from work matching. '
           'Right: original conditional-reference ESS traces normalized by bank size, averaged over sampler seeds with bootstrap 95% intervals. Conditional ESS is not MCMC chain ESS.')


def problem_figures(batch,problem,config,summary,out,dashboard):
    style();out=Path(out);captions={};dpi=config['aggregation']['png_dpi'];seed=config['aggregation']['illustration_seed'];rounds=config['sampler']['rounds']
    metric_curves(summary,['RMSE_field','RMSE_state','FwdRelErr'],problem,out,dashboard,dpi,captions)
    floor=load_npz(Path(batch)/'reference'/problem/'sampling_floors.npz')
    metric_curves(summary,['RefMeanWhitenedRMSE','RefCovWhitenedRelFro','RefFieldMeanRelL2','RefFieldStdRelL2','RefFieldCI95RMSE','RefSW2'],
                  problem,out,dashboard,dpi,captions,work=True,floor=floor)
    metric_curves(summary,['KSD','KLdiag','ScaledHeldoutPredNLL','HeldoutCleanRelL2','ScaledHeldoutCoverage95','mala_acceptance_rate'],
                  problem,out,dashboard,dpi,captions)
    field_maps(batch,problem,seed,rounds,out,dashboard,dpi,captions)
    spread_maps(batch,problem,config['sampler_seeds'],rounds,out,dashboard,dpi,captions)
    state_maps(batch,problem,seed,rounds,out,dashboard,dpi,captions)
    pca_maps(batch,problem,seed,rounds,out,dashboard,dpi,captions)
    predictive_plot(batch,problem,seed,rounds,out,dashboard,dpi,captions)
    reference_plots(batch,problem,out,dashboard,dpi,captions)
    geometry_plot(batch,problem,out,dashboard,dpi,captions)
    runtime_and_ess(batch,problem,config,summary,out,dashboard,dpi,captions)
    write_json(out/'captions.json',captions)
    (out/'CAPTIONS.md').write_text('\n\n'.join(f'### {name}\n\n{text}' for name,text in captions.items())+'\n')
    return len(captions)
