# Validation — Frontera edition, 27 October 2026

No production Frontera or Vista jobs were submitted from this session. Frontera CUDA behavior, GPU memory use, elapsed time and long-reference mixing still require the compute-node preflight and actual jobs. Existing Vista jobs remain independent.

## Changes in this edition

- RTX partition; one node and one task; account DMS22021; gcc/9.1.0, python3/3.9.2 and the supplied persistent Python 3.9 venv. Defaults remain 12 hours per NUTS chain, one hour per standard job and 20 minutes for preflight. The watcher caps all local-cluster task slots at 32, below the supplied RTX MaxSubmit of 36.
- The planner queries partition availability and defers new submissions while RTX is drained/down/inactive, preserving cached results and local live IDs. Existing queue/allocation rejection recovery and watch refilling remain supported.
- Frozen batches record the scheduler cluster. Known cluster mismatches fail before submitting; donor live IDs are considered only on the same cluster. Completed scientific files remain eligible for existing compatibility checks across clusters.
- Python 3.9 protocol compatibility adds only `from __future__ import annotations`. The compatibility digest removes that exact line for protocol identity; all other bytes continue binding run compatibility. Original source hashes are retained and verified, including the normalized protocol; all numerical sampler/model files and the generic Darcy NUTS routines remain unchanged.
- Reference extras select ArviZ 0.17.1 on Python 3.9 because >=0.18 requires newer Python. Worker startup restores the legacy scipy.signal.gaussian import alias from scipy.signal.windows only for old ArviZ when needed, without replacing SciPy. The installed JAX/CUDA/PyTorch/NumPy/SciPy stack remains constrained during extras installation.
- Documentation uses the new sweeps/frontera extraction root, separate batches/logs, correctly resolved previous-output paths, detached nohup start/resume, PID/login-host tracking, monitoring, stop/retry and expansion to ten repeats.

## Current local validation

**66 tests passed on actual CPython 3.9.25 with NumPy 2.0.2 in the sampler environment:** 34 publication/Frontera tests and 32 original screening tests. This includes real JAX/NumPyro CPU continuation with an interrupted chain matching uninterrupted draws exactly, actual ArviZ rank-Rhat/bulk-ESS/tail-ESS/MCSE APIs under SciPy 1.13, numerical comparison/uncertainty checks, and fake-scheduler recovery/reuse tests.

The original local Python 3.9 CPU environment uses NumPy 1.26.4, SciPy 1.13.1, pandas 2.2.3, Matplotlib 3.9.4, JAX/jaxlib 0.4.30, NumPyro 0.15.3, ArviZ 0.17.1 and pypdf 6.21.3. These are validation versions, not instructions to replace the user's working GPU stack. PyTorch/CUDA execution was not retested locally in this edition; the allocated production preflight checks both GPU frameworks.

New tests cover RTX/default allocation wiring, drain-to-up recovery, cross-cluster live-ID rejection with completed-output reuse, known wrong-cluster rejection before creating/submitting a batch, environment module selection, missing-venv errors, Python 3.9 syntax/runtime protocol import, exact legacy kernel digest preservation, and actual ArviZ diagnostics under SciPy 1.13.

The retained publication tests cover capped/recoverable submission, live-job deduplication, checksum/signature reuse, changed-only Helmholtz work, reference reuse after particle changes, missing-seed and five-to-ten expansion behavior, canonical raw-run import, paired uncertainty, distribution metrics, reference withdrawal after failed diagnostics, and actual NumPyro chunk restart equivalence.

Shell examples and scripts, documentation links, ZIP integrity and file manifest are checked before delivery. Historical figure renders, reduced numerical end-to-end evidence and prior Vista implementation checks are retained in provenance/VALIDATION_VISTA_LEGACY.md. Those are earlier evidence rather than newly executed Frontera production results.

## NumPy 2.0.2 installation repair

The user environment revealed an installer conflict not covered by the original NumPy-1 local test: Python 3.9 requires old ArviZ, while ArviZ 0.17.1 declares NumPy <2. The corrected installer retains the main GPU environment and uses a separate CPU ArviZ venv when Python <3.10 and NumPy >=2. It never bypasses dependency metadata or forces ArviZ into the incompatible main environment.

The diagnostic adapter supports the exact API subset used by this bundle (posterior from_dict, rank R-hat, bulk/tail ESS, mean MCSE). It invokes the actual ArviZ library in the isolated interpreter through numeric NPZ files, computes all four diagnostics once per posterior object and caches the arrays. Native diagnostic results and adapter results are checked for exact array equality; scalar, vector and matrix variables and the unchanged generic reference diagnostic routines are exercised. Scientific reference thresholds are unchanged.

The new local sampler-side test environment is Python 3.9.25, NumPy 2.0.2, SciPy 1.13.1, JAX/jaxlib 0.4.30 and NumPyro 0.15.3, with no ArviZ installed there. Its diagnostic interpreter uses the original NumPy-1/ArviZ environment. All checks pass with this split; after correcting a new test to initialize the adapter before importing the unchanged reference module, its complete test file was rerun successfully. The user's precise GPU-package versions and GPU execution remain checked by allocated preflight.
