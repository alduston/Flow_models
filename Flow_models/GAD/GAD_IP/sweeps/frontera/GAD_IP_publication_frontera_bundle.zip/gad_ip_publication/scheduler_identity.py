"""Keep local Slurm IDs separate from reusable scientific files."""
import os
from pathlib import Path

from common import read_json


def configured_cluster(config):
    cluster = config.get('slurm', {}).get('cluster')
    if cluster:
        return cluster.lower()
    # Recognize historical bundles, which predate explicit cluster metadata.
    return {'gh': 'vista', 'rtx': 'frontera', 'rtx-dev': 'frontera'}.get(
        config.get('slurm', {}).get('partition'))


def batch_cluster(batch):
    batch = Path(batch)
    meta = read_json(batch / 'batch.json')
    return meta.get('scheduler_cluster') or configured_cluster(read_json(batch / 'settings.json'))


def same_scheduler(first, second):
    a, b = batch_cluster(first), batch_cluster(second)
    return a is not None and a == b


def check_cluster(config):
    expected = configured_cluster(config)
    actual = (os.environ.get('TACC_SYSTEM') or os.environ.get('SLURM_CLUSTER_NAME') or '').lower()
    if expected and actual and expected != actual:
        raise ValueError(f'This configuration belongs to {expected}, but this host reports {actual}. '
                         'Create a new batch for this cluster and use --reuse-from for completed files; '
                         'Slurm job IDs and live dependencies cannot cross clusters.')
    return expected
