#!/bin/bash
# Frontera defaults match the user's working RTX/Python 3.9 job.
gp_load_environment() {
  if [[ "${GP_SKIP_MODULES:-0}" != 1 ]]; then
    module purge || return
    module load "${GP_GCC_MODULE:-gcc/9.1.0}" || return
    module load "${GP_PYTHON_MODULE:-python3/3.9.2}" || return
    local gp_venv="${GP_VENV_DIR:-/work2/10812/ald4435/frontera/venvs/flow_frontera_py39}"
    if [[ ! -f "$gp_venv/bin/activate" ]]; then
      echo "[error] Expected venv at $gp_venv; set GP_VENV_DIR to override." >&2
      return 2
    fi
    source "$gp_venv/bin/activate" || return
  fi
  export OMP_NUM_THREADS="${GP_THREADS:-8}"
  export MKL_NUM_THREADS="$OMP_NUM_THREADS" OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS" NUMEXPR_NUM_THREADS="$OMP_NUM_THREADS"
  export MPLBACKEND=Agg JAX_ENABLE_X64=true
  export XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION="${GP_JAX_MEM_FRACTION:-0.20}"
  export CUDA_VISIBLE_DEVICES="${GP_CUDA_VISIBLE_DEVICES:-${CUDA_VISIBLE_DEVICES:-0}}"
}
gp_load_environment
