# Run the publication campaign on Frontera

> **Existing campaign:** see [TARGET_SNAPSHOT_FIX.md](TARGET_SNAPSHOT_FIX.md) before resuming. The target-loading fix also needs to be applied to the batch's frozen `code/`. A healthy watcher can be stopped while polling, the batch repaired once no batch jobs are running, and the same batch resumed. Completed work and saved MAPs are retained. This replaces the earlier documentation-only update advice for this code repair.


## 1. Extract and activate

Copy `GAD_IP_publication_frontera_bundle.zip` to the directory below, then run on a Frontera login node:

```bash
cd /work2/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/sweeps/frontera
unzip -qo GAD_IP_publication_frontera_bundle.zip
cd gad_ip_publication
source slurm/environment.sh
python -V
```

The environment loads `gcc/9.1.0`, `python3/3.9.2`, and the existing `/work2/10812/ald4435/frontera/venvs/flow_frontera_py39` venv. It does not create a new production environment or install GPU frameworks. If reference extras have not already been installed in this Frontera venv:

```bash
bash install_reference_extras.sh
```

The installer preserves installed JAX/jaxlib, PyTorch, NumPy, SciPy and plotting versions using constraints. For the supplied Python 3.9 / NumPy 2.0.2 environment, it installs NumPyro/pypdf in that environment and creates `/work2/10812/ald4435/frontera/venvs/flow_frontera_py39_gad_diagnostics` for CPU ArviZ calculations with NumPy 1.26.4, SciPy 1.13.1 and ArviZ 0.17.1. The sampler retains NumPy 2.0.2. Workers find the side environment automatically; NPZ arrays pass between the environments without pickle. Export `GP_DIAGNOSTICS_PYTHON` before installation and submission only when overriding the default diagnostic interpreter. It selects ArviZ 0.17.1 on Python 3.9 (ArviZ >=0.18,<1 on newer Python), using the separate diagnostics environment when NumPy 2 requires it, and checks actual APIs. Worker startup supplies the legacy scipy.signal.gaussian alias from scipy.signal.windows if ArviZ 0.17 needs it; SciPy is not downgraded. A dependency conflict stops installation rather than replacing the GPU stack. The allocated preflight job checks CUDA, float64, actual ArviZ APIs and NumPyro continuation before scientific jobs run. No numerical PDE work runs on the login node.

## 2. Start a detached watcher

Use a new batch name for this separate Frontera campaign. The following relative paths are calculated from `sweeps/frontera/gad_ip_publication`:

```bash
GP_BATCH=../batches/gad_ip_frontera_20261027_v3
GP_DRIVER_LOG=../gad_ip_frontera_20261027_v3_submit.log

nohup bash submit.sh \
  --batch "$GP_BATCH" \
  --reuse-from ../../../batches \
  --import-runs ../../.. \
  --repeats 5 --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown

tail -n 30 "$GP_DRIVER_LOG"
```

`../../../batches` points to the former `GAD_IP/batches` directory; `../../..` points to the former `GAD_IP` working directory. Neither points into the new extraction directory by accident. Existing source snapshots, failed attempts and model-data caches are skipped during raw-run discovery. If no matching old outputs exist, a fresh campaign is scheduled. Omit these two flags to skip old-directory discovery entirely, or add explicit repeatable `--reuse-from` / `--import-runs` paths.

Normal `Plan:` / `checking again` messages with zero failures mean the driver is alive. It may also finish immediately if everything has already been cached/submitted. Check the log after launch before disconnecting. The watcher survives SSH/laptop disconnects but not a login-node reboot or administrative process termination. Keep one watcher per batch.

The supplied queue snapshot has `rtx` availability `drain`. While that persists, this watcher records deferred tasks and sends no new `sbatch` calls. It polls and submits when `sinfo` reports `up`. This is separate from a node's idle/drained state and from queue priority. Watch current availability with:

```bash
sinfo -p rtx -o '%P %a %l %D %T'
qlimits
```

The settings use `rtx`, one node / one task, allocation `DMS22021`, 32 outstanding local-cluster tasks, 12-hour NUTS chains and one-hour standard jobs (20-minute preflight). The supplied RTX limits are 36 submissions, 24 running jobs, 48 nodes/user, 48-hour maximum. Slurm enforces running/node limits; the driver conservatively counts all your outstanding Frontera tasks, including unrelated work, against its 32-task cap. Partition availability, submission limits, allocation rejections and prerequisites cause deferral, with accepted IDs preserved.

## 3. Monitor or resume after reconnecting

```bash
cd /work2/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/sweeps/frontera/gad_ip_publication
source slurm/environment.sh
GP_BATCH=../batches/gad_ip_frontera_20261027_v3
GP_DRIVER_LOG=../gad_ip_frontera_20261027_v3_submit.log

tail -n 30 "$GP_DRIVER_LOG"
squeue -u "$USER"
python workflow.py status --batch "$GP_BATCH"
cat "$GP_DRIVER_LOG.host"
```

If the driver stopped, use `--resume-batch`, not `--batch`:

```bash
nohup bash submit.sh --resume-batch "$GP_BATCH" --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown
```

Check the saved host and verify the process command on that host before starting another watcher. A saved PID alone can become stale. To inspect it on the recorded host:

```bash
ps -p "$(cat "$GP_DRIVER_LOG.pid")" -o pid,etime,args
```

To stop only a verified watcher while it is polling:

```bash
kill -TERM "$(cat "$GP_DRIVER_LOG.pid")"
```

Queued/running Slurm jobs continue. Resume later to fill deferred work. A failed/cancelled task requires inspection and a deliberate `--retry-failed` on the resume command. NUTS production chunks resume when compatible; sampler repeats rerun if incomplete. The watcher exits once all tasks are cached/submitted; compute jobs can still be running.

## 4. Scientific settings and reuse

| Problem | Particles / bank | Rounds | Initial sampler seeds |
| --- | ---: | ---: | --- |
| Navier-Stokes | 1,000 | 5 | 42–46 |
| Allen-Cahn | 1,000 | 5 | 42–46 |
| Helmholtz | 2,000 | 5 | 42–46 |

Data seed remains 42. FWI is optional, 300 particles / four rounds. Checkpoint MALA and strict four-chain NUTS reference settings remain canonical (3,000 warmup and 5,000 retained draws per chain). Publication PDF/SVG/600-dpi PNGs, paired uncertainty and tables remain enabled. The full five-repeat campaign has 50 tasks and reserves 181.33 node-hours before reuse, approximately 544 SUs at the documented RTX rate of 3 SUs/node-hour. Actual use and mixing must be assessed from production results.

Completed references and runs are reused only after signature/checksum checks. Scientific changes require a new batch with `--reuse-from OLD_BATCH`. Changing only Helmholtz does not invalidate compatible NS/Allen-Cahn work. Different particle counts do not invalidate a compatible NUTS cloud, but may require fresh summaries/evaluations.

Vista and Frontera campaigns are independent. Leave the existing Vista watcher/jobs alone if running both. Do not resume the Vista batch on Frontera: job IDs are cluster-local, and this bundle rejects a known cluster mismatch. Copied completed files can be reused; live jobs from another cluster cannot become dependencies. No cross-cluster synchronization or automatic cancellation is attempted. If combining results later, identical problem/data/sampler seeds are duplicate experiments, not additional independent repeats.

After the five-repeat aggregate finishes and the old watcher has exited, expand on Frontera:

```bash
nohup bash submit.sh --resume-batch "$GP_BATCH" --repeats 10 --watch \
  >> "$GP_DRIVER_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_DRIVER_LOG.pid"
hostname > "$GP_DRIVER_LOG.host"
disown
```

This retains completed seeds 42–46 and adds missing seeds 47–51. Do not change the selection while its aggregate is active.

## 5. Results and operational overrides

The final archive is:

```text
/work2/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/sweeps/frontera/batches/gad_ip_frontera_20261027_v3/gad_ip_publication_results.zip
```

Inspect `meta_results/completion.json` and `submission_plan.json`; an archive containing diagnostic/incomplete output does not establish a complete publication campaign.

For a finite preview, choose a new batch path:

```bash
bash submit.sh --batch ../batches/gad_ip_frontera_preview \
  --reuse-from ../../../batches --import-runs ../../.. \
  --repeats 5 --dry-run
```

Resume that exact preview batch to execute it. Add `--offline` for a preview away from Slurm. Do not combine `--dry-run` with `--watch`.

Operational overrides affect only future submissions; repeat them after restarting the watcher. Examples: `--account OTHER_PROJECT`, `--max-outstanding-tasks 24`, `--time chain=24:00:00`, `--time repeat=02:00:00`. Keep the 12-hour/one-hour defaults initially; RTX performance may differ from Vista, and failed/timeout logs determine any extensions. The sampler uses one GPU per job; it does not pool the four cards' memory. Environment overrides must be exported before starting the watcher so submitted jobs inherit them.

Sources: supplied working job, `qlimits`, `taccinfo`, `sacctmgr` and `sinfo` transcript; [TACC Frontera environment/GPU guide](https://docs.tacc.utexas.edu/hpc/frontera/); [TACC running/accounting guide](https://docs.tacc.utexas.edu/hpc/frontera/running/). The supplied live `qlimits` takes precedence over older published queue limits.
