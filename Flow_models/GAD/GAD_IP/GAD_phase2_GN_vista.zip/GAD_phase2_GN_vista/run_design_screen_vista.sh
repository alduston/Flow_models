#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source slurm/environment.sh
python submit_vista.py --batch "${G2_BATCH:-../batches/gad_phase2_GN_array_design_screen_v2}" \
  --case "${G2_CASE:-exploratory}" --stage screen --account "${G2_ACCOUNT:-DMS22021}" "$@"
