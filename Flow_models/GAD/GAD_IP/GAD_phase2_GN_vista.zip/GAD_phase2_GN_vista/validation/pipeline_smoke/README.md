# tdoa_array_wide

Status: SMOKE VALIDATION. Geometry screen: candidate.

Reference passed: True; quadrature converged: True; reference/grid agreement: True.

See tables/metrics.csv, qoi_metrics.csv, work_and_sampler_diagnostics.csv and curvature_audit.csv. All pMALA moments and QoIs use its full post-warmup history. Cloud metrics stratify that history and retain rejection repeats. The Gaussian diagnostic is fit to one chain group and evaluated on the other.

This is one fixed dataset and seed, with no claim of repeat-to-repeat uncertainty. A curved physical-parameter plot alone does not establish a curved target in the coordinates sampled. Negative or unresolved screens are retained.
