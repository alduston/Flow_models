#!/usr/bin/env python3
"""Fake Slurm checks: freezing, live-job refusal, restart and dry-run purity."""
import json,os,pathlib,subprocess,sys,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]

def main():
    with tempfile.TemporaryDirectory() as td:
        tmp=pathlib.Path(td);bin_=tmp/'bin';bin_.mkdir();state=tmp/'live';state.write_text('')
        (bin_/'sbatch').write_text('#!/usr/bin/env python3\nprint("7654321")\n')
        (bin_/'squeue').write_text('#!/usr/bin/env python3\nimport os,pathlib\nprint(pathlib.Path(os.environ["FAKE_SLURM_STATE"]).read_text())\n')
        for p in bin_.iterdir():p.chmod(0o755)
        env=dict(os.environ,PATH=str(bin_)+os.pathsep+os.environ['PATH'],FAKE_SLURM_STATE=str(state))
        batch=tmp/'batch';base=[sys.executable,str(ROOT/'submit_vista.py'),'--batch',str(batch),'--case','tdoa_array_wide','--profile','highbank']
        r=subprocess.run(base+['--dry-run'],env=env,capture_output=True,text=True,check=True)
        assert not batch.exists()
        subprocess.run(base,env=env,capture_output=True,text=True,check=True)
        record=json.loads((batch/'batch.json').read_text());assert record['job_id']=='7654321' and record['profile']=='highbank'
        assert (batch/'code/data/tdoa_array_wide.json').is_file() and (batch/'code/profiles/highbank.json').is_file()
        state.write_text('RUNNING');live=subprocess.run(base+['--resume'],env=env,capture_output=True,text=True)
        assert live.returncode and 'still live' in live.stderr
        state.write_text('');subprocess.run(base+['--resume'],env=env,capture_output=True,text=True,check=True)
        changed=subprocess.run(base+['--resume','--seed','43'],env=env,capture_output=True,text=True)
        assert changed.returncode and 'changed' in changed.stderr
        for p in (ROOT/'slurm').glob('*.sh'):subprocess.run(['bash','-n',str(p)],check=True)
        for p in ROOT.glob('*.sh'):subprocess.run(['bash','-n',str(p)],check=True)
    print(json.dumps({'passed':True,'dry_run_is_pure':True,'source_and_profile_freeze':True,'live_job_refusal':True,'restart':True,'changed_seed_refusal':True,'bash_syntax':True}))
if __name__=='__main__':main()
