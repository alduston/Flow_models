# Local validation and evidence limits - 1 November 2026

The final source was checked on CPU with Python 3.12.14, JAX/JAXlib 0.4.35, NumPyro 0.15.3, ArviZ 0.22.0 and NumPy 2.5.4. No Vista job was submitted. The bundle uses the existing Vista GPU environment and runs its preflight again on allocation.

## What passed

- Finite-difference score/full-Hessian checks for all thirteen target files; independent physical forward/noise-covariance formula checks.
- Gaussian q-LFGI identities over OU times 1e-10 through 10, deterministic Heun mean/covariance propagation, reference-chart inverse/Jacobian checks, and MH Gaussian stationarity/rejection preservation.
- Independent OU-score quadrature against an analytic Gaussian; paired standardized observation errors; proper shared prior/Laplace initial laws; the actual JAX pMALA transition with different fixed per-chain steps.
- Quadrature-only geometry checks for every eleven-case design-panel target. These are labeled prescreens and are not production NUTS acceptance.
- Complete five-round, two-initial-law pipeline for the selected `tdoa_array_wide` target, including independent four-chain NUTS, quadrature cross-check, both fresh-process comparator pairs, all eleven dashboard pages, exported tables and score audits. This uses 128 particles and shortened reference settings from `isolated_smoke_config.json`, with debugging overrides available. Its NUTS diagnostics passed those shortened thresholds, with zero divergences; it does not establish the production reference thresholds or production accuracy.
- GAD reconstruction from a completed transport checkpoint produces identical samples and unchanged oracle counts. Restoring pMALA reproduces the full history, including repeats, with unchanged oracle counts.
- Fake-Slurm submission checks: pure dry run, source/profile freezing, refusal of a live duplicate, completed-job resubmission, changed-seed rejection, shell syntax. No real Slurm command was executed in these checks.
- The dashboard was rendered and visually inspected. Common-bin logarithmic joint plots, probability allocation and first/later-bank score panels are included in `pipeline_smoke/` as labeled examples.

The separate `highbank_step.json` records the full 8,192-point bank/output one-step numerical/memory check. It is not a full high-bank run.

## Local design exploration

The first stage tested 512 particles, five rounds and seed 42 on `tdoa_wide` and `tdoa_gentle`, against converged 2D quadrature. Simply increasing arrival noise to 60 microseconds retained the desired rotation but still left large GN-GAD weighting errors. These failures were retained.

A second exploratory stage then changed the search prior to the known array center and/or used coarser, 240 microsecond timing uncertainty. Each second-stage target was frozen before its own check; the matched four-microphone control was added after the array-centered candidate looked promising. This was an exploratory response to the first failures, not a confirmatory preregistered success. No target uses reference samples or covariance for initialization.

The final candidate was rerun with the final **per-chain pMALA adaptation**, 512 particles, five rounds, seed 42 and the same quadrature check. Normalized SW2 is approximately:

| Initial law | GN-GAD | Matched-work pMALA |
|---|---:|---:|
| Prior/Laplace mixture | 0.0976 | 0.3127 |
| MAP-Laplace | 0.1044 | 0.4515 |

MAP-Laplace alone gives 0.3360. The stronger pMALA start at this budget is therefore the mixture. This is an optimistic post hoc comparison across the two charged configurations, not a free combined algorithm. GAD's lower-arm probability is 0.4316 versus quadrature 0.4575; its three-sigma measurement-fit probability is 0.9980 versus 0.9976. The timing continuation reached its local hard transition limit, so these runs do **not** establish a matched-time advantage.

`exploratory_design_history.csv` includes every completed 512-particle design result. Its `pmala_version` distinguishes the earlier shared-step exploratory comparator from the final per-chain implementation. Use only the `final_candidate` rows for numbers describing the delivered comparator. `final_candidate_coverage.csv` contains the corresponding region/constraint/conditional-QoI checks.

This is one selected synthetic dataset and sampler seed. The default Vista job is a new 2,048-particle/five-round confirmation with strict references; repeat seeds and the optional 8,192-particle profile remain unrun. This is a 2D mechanism result, not a completed higher-dimensional scientific application or a general GN safety criterion.

## Reproduce

From the bundle root:

```bash
python run.py preflight --cpu --out /tmp/gad_GN_preflight
python local_design_check.py --cases tdoa_array_wide tdoa_array_control \
  --out /tmp/gad_GN_design
python local_sampling_check.py --cases tdoa_array_wide --particles 512 \
  --out /tmp/gad_GN_exploratory
python run.py run --case tdoa_array_wide --cpu \
  --config validation/isolated_smoke_config.json \
  --out /tmp/gad_GN_isolated_smoke --run-screen-failures --allow-provisional
python validation/check_orchestration.py
```

Use new output directories after modifying source or configuration. The source/target binding intentionally refuses stale checkpoints. Full raw reference/trajectory checkpoints are omitted from this compact executable distribution; the scripts regenerate them.
