# GN-GAD inverse-problem design update - 1 November 2026

This updates the supplied phase-two Vista bundle using the GN-GAD design follow-up and the linked 31 October study. It keeps the physical localization, logistic-growth and binding models. The changes target **resolvable local width, retained global bending, and shared initial coverage**. The default candidate was chosen through a documented local design exploration; it still needs production confirmation. No new convergence theory is introduced.

Start with `tdoa_array_wide`: 240 microsecond arrival noise, a search-region prior centered on the sensor array, the original sensor geometry, 2,048 particles and five rounds. Both GAD and MAP-Hessian pMALA run from (i) a 50:50 prior/MAP-Laplace mixture and (ii) MAP-Laplace. The original thin target remains a stress control. Logistic and binding remain calibration cases, with their existing priors and native sampling coordinates.

These are two-dimensional mechanism tests. The package does not implement a new kinetic network, seismic solver or obstacle-shape PDE. `EXPERIMENT_DESIGN.md` explains the connection to those subsequent application choices. A positive geometry screen is not a demonstrated GN-GAD advantage.

## Launch one comparison on Vista

Extract into a **new directory** beside your existing campaign, then:

```bash
unzip -q GAD_phase2_GN_vista.zip
cd GAD_phase2_GN_vista
bash run_first_vista.sh
```

This submits one GH node, one job, six hours, account DMS22021, sampler seed 42. Default batch: `../batches/gad_phase2_GN_array_wide_seed42_v2`. It uses your established `hlsi` environment. No arrays or watcher are started. Old campaigns are untouched.

To inspect the submission first:

```bash
python submit_vista.py --batch ../batches/gad_phase2_GN_array_wide_seed42_v2 \
  --case tdoa_array_wide --dry-run
```

To screen every fixed acquisition design, without running either competing sampler:

```bash
bash run_design_screen_vista.sh
```

That is a separate one-node job. It runs the four second-stage cases below sequentially, with independent NUTS, quadrature, Gaussian controls and reports. It produces `design_summary.csv`. Do not run the screen and comparison simultaneously if conserving SUs; the default comparison already checks its own reference and geometry.

## Fixed target panel

| Case | Arrival-time SD (microseconds) | Sensor radius (m) | Role |
|---|---:|---:|---|
| `tdoa` | 15 | 1.2 | Original thin stress case; unchanged observations |
| `tdoa_soft` | 30 | 1.2 | Twofold transverse-noise sensitivity |
| `tdoa_wide` | 60 | 1.2 | Wider-ridge candidate; retained first-stage test |
| `tdoa_gentle` | 60 | 1.8 | Longer-baseline candidate; separately regenerated target |
| `tdoa_control_wide` | 60 | 1.2 | Four-microphone, more identifiable control |
| `logistic_clustered` | published population SD 0.4 | - | Existing conditional biological calibration; may screen negative |
| `logistic_dispersed` | published population SD 0.4 | - | Existing informative time-design control |

The first seven cases form `--case panel`. The following **exploratory second-stage** panel was added after the 60 microsecond checks still showed GAD weighting errors:

| Case | Arrival-time SD (microseconds) | Search-prior mean (m) | Role |
|---|---:|---|---|
| `tdoa_array_centered` | 60 | (0,0) | Isolate the array-centered search prior |
| `tdoa_array_wide` | 240 | (0,0) | Wider, covered bend; default confirmation candidate |
| `tdoa_coarse` | 240 | (0,1) | Timing change with original search prior |
| `tdoa_array_control` | 240 | (0,0) | Matched four-microphone informative control |

The radius remains 1.2 m and spatial prior SD remains 1.5 m. A 240 microsecond arrival uncertainty corresponds to 0.0823 m of acoustic path-length uncertainty; it is a deliberately coarse synthetic acquisition regime. This second panel is a design exploration, not a prespecified successful confirmation. The search prior is centered using the array's known center, not a reference posterior or true source.

`--case exploratory` selects these four and is the default design-screen launcher; `--case all` selects all eleven. To screen only the original seven-case panel, use `G2_CASE=panel G2_BATCH=../batches/gad_phase2_GN_original_panel_v2 bash run_design_screen_vista.sh`. The legacy `tdoa_control` and `binding` are also available individually. Noise variations reuse the same standardized synthetic arrival errors. The covariance is always the physical shared-reference covariance, sigma_TOA^2 (I + 11^T); GAD uses its Cholesky-whitened forward Jacobian. No favorable residual refactorization is introduced. The timing SD range is a declared synthetic acquisition sensitivity, not a newly calibrated instrument dataset.

## Other cases, seeds and bank resolution

```bash
python submit_vista.py --batch ../batches/gad_phase2_GN_gentle_seed42_v2 \
  --case tdoa_gentle --account DMS22021

python submit_vista.py --batch ../batches/gad_phase2_GN_array_wide_seed43_v2 \
  --case tdoa_array_wide --seed 43 --account DMS22021

python submit_vista.py --batch ../batches/gad_phase2_GN_array_wide_8k_seed42_v2 \
  --case tdoa_array_wide --profile highbank --account DMS22021
```

The high-bank profile preserves the linked chat's planned **8,192 particles x five rounds** resolution check. The standard 2,048-particle profile is the bounded first campaign. Each runs both initial laws; the profile changes bank/output resolution, not the target. `--initialization mixed`, `laplace`, or `prior` can isolate an initial-law experiment in a new campaign. The default is `both` (mixed and Laplace). No reference samples enter either initial law, metric or bank.

Freeze one surviving target before adding seeds 43 and 44. Report every fixed design you screened. Compare within an initial law and its actual charged budget; selecting the best start after evaluation is an optimistic envelope, not a free new sampler.

## Reference, costs and stopping

- Production reference remains four exact-potential NUTS chains, 5,000 warmup and 20,000 draws per chain, with the previous strict R-hat/ESS/divergence/E-BFMI gates and independent refined quadrature.
- All single-pair TDOA variants use the exact Jacobian-corrected range-difference chart for the reference only. Competing samplers remain in Cartesian prior coordinates. This available native chart limits the application claim.
- The stable endpoint selection and deterministic Gaussian Heun control are retained. An accepted reference may tighten the numerical endpoint, without supplying an initial covariance or metric.
- The exact full MAP Hessian still preconditions pMALA. Truth-blind MAP search, warmup, initial requests and rejected transitions are charged; each chain adapts and then freezes its own step size so a broad-start chain does not force every chain to use one step; its full production history is retained.
- Each method/initial-law pair runs in a **fresh process** for production timing, including its derivative/integrator compilation. Shared MAP preprocessing is fully charged to each. Reference and offline diagnostic costs are separate. Local debug runs can intentionally share a process and are labeled accordingly.
- Work matching remains cumulative E+G+H **request counts**, not equivalent FLOPs. GN counts as an H request. Actual isolated method seconds, underfilled time caps and hard limits are also saved. A CPU request-count lead is not a Vista time lead.
- An unresolved reference, endpoint, or competing MAP basin prevents production sampling. A geometry-negative case yields a diagnostic report; controls remain visible. Exact-Hessian GAD success and small exact/GN matrix error are **not** eligibility conditions.

## New figures and metrics

The dashboard and individual PDF/PNG panels now include:

1. Existing posterior geometry, predictive mean/SD, scientific QoI CDFs/tails, accuracy versus work/time, reference traces, geometry and solve guards.
2. Two six-panel joint histograms, one per initial law: reference, Laplace, first/final GN-GAD, matched-work and matched-time pMALA. Common bins, limits and logarithmic density scales expose geometry and concentration. Out-of-display mass is printed and exported; metrics use all states.
3. Lower-arm probability, constraint-fit probability and errors in fixed physical height bins. Conditional QoI means are exported for every region and input bank. Fitting the measurements does not establish correct mass allocation.
4. First- and last-bank GN score errors at identical noisy entry-law and posterior queries, against independent OU-score quadrature. Fine/coarse grid agreement is checked. Exact-Hessian bank fields, conditional solve-scaled residuals and ESS are offline diagnostics, not extra competitors or a GN pass/fail gate.

Important tables: `metrics.csv` (also normalized SW2), `qoi_metrics.csv`, `predictive_metrics.csv`, `coverage_constraint_and_conditional_QoI.csv`, `OU_score_summary.csv`, `OU_score_queries.csv`, `work_and_sampler_diagnostics.csv`, `pmala_chain_diagnostics.csv`, `histogram_display_coverage.csv`, and reference sampling floors. The moment Gaussian remains split-reference cross-fitted and clearly labeled as an oracle diagnostic. Single-run particle/block MC errors do not estimate between-seed uncertainty; the capped block length can understate uncertainty in poorly mixing chains, so inspect the ESS and R-hat tables.

The OU score audit retains unpruned log-density weights, since negligible unconditional mass can matter when conditioning on an entry query. It uses a truncated 2D integration domain; grid agreement is a numerical check, not proof of tail coverage. The exact field may be evaluated on a labeled subset when a production bank exceeds 2,048 points. Neither diagnostic supplies scores to transport.

## Restart and collect

After the recorded job has left the queue:

```bash
python submit_vista.py --batch ../batches/gad_phase2_GN_array_wide_seed42_v2 \
  --case tdoa_array_wide --account DMS22021 --resume
```

Repeat the original stage/profile/seed/initialization options for a nondefault campaign. Source/configuration changes require a new batch. Completed NUTS chunks, GAD transport checkpoints and full pMALA state/history are resumable with matching runtime versions. A live recorded job blocks duplicate submission.

The compact export is:

```text
../batches/gad_phase2_GN_array_wide_seed42_v2/tdoa_array_wide/tdoa_array_wide_figures_metrics.zip
```

Raw samples/checkpoints remain outside that compact export. The batch also gets `design_summary.csv` and JSON.

## CPU checks

Use a separate CPU environment; do not install CPU JAX over your Vista GPU environment.

```bash
python -m pip install -r requirements-cpu.txt
python run.py preflight --cpu --out /tmp/gad_GN_preflight
python local_design_check.py --out /tmp/gad_GN_geometry
python local_sampling_check.py --out /tmp/gad_GN_512 --particles 512
python run.py run --case tdoa_array_wide --out /tmp/gad_GN_smoke --cpu \
  --smoke --run-screen-failures --allow-provisional
```

The last command deliberately relaxes reference requirements and uses 128 particles. It validates the pipeline; it is not a scientific result. `validation/VALIDATION.md` states exactly what was run locally. No Vista experiment has been launched by preparing this package.
