# Design update and boundaries

## Change in the working hypothesis

The 31 October GN-GAD study supports seeking a long, connected physical trade-off with appreciable accumulated bending **and enough width for the bank and score field to resolve the turns**. Extremely thin constraints are not automatically better examples. Good posterior-point GN agreement can miss a difficult entry stage; conversely, exact-Hessian GAD failure does not disqualify an accurate GN-GAD run. The operative question is GN-GAD accuracy and cost on the physical model.

This package implements the changes that the attached analytic phase-two source supports directly. It does not silently replace that source with the old NS/Allen-Cahn/Helmholtz targets, or invent a new forward model to reproduce a toy banana. The unchanged biological controls remain available, and geometry-negative results remain visible.

## Localization setup

The baseline is the previous two-microphone acoustic range-difference model, with reference angle 200 degrees and receiver angle 10 degrees. The source has proper spatial prior N((0,1),1.5^2 I), expressed in affine Cartesian prior coordinates. Known sound speed is 343 m/s. The truth (0.65,1.3) m is used only to generate data and for plots. Ranges retain the same negligible 1e-9 m regularization.

Baseline radius 1.2 m and arrival noise SD 15 microseconds are unchanged in `tdoa`. The first-stage fixed variants are SD 30 and 60 microseconds at radius 1.2 m, plus radius 1.8 m at SD 60. Increasing timing uncertainty widens the normal direction. Changing the baseline changes the physical range-difference contours and is labeled as a new target; it does not purport to isolate bending while holding every other geometric quantity constant. Standardized arrival errors are paired across variants, and the entire likelihood covariance is regenerated consistently. A four-microphone control at the same 60 microseconds uses receiver angles 10, 85 and 130 degrees relative to the shared reference.

These are synthetic acquisition sensitivities; no instrument-specific empirical noise calibration is claimed. Their mechanism is a physically underdetermined range difference, not a target-dependent residual representation. Preserve all variants in reporting. The initial 512-particle checks retained global curvature but did not establish GN-GAD accuracy at 60 microseconds. A second exploratory panel therefore compares the original versus array-centered search prior, at 60 and 240 microseconds. Its four cases were fixed before their own check: array-centered/60, array-centered/240, offset/240, and a matched array-centered/240 four-microphone control. These are explicitly exploratory choices informed by the first panel, rather than retroactively prespecified confirmatory results.

The array-centered prior is N((0,0),1.5^2 I), using the known sensor-circle center. It improves initial coverage of the bend without a posterior-derived initializer. The 240 microsecond timing SD gives 0.0823 m one-way path uncertainty and a more resolvable normal width. The physical truth and standardized observation errors remain fixed. `tdoa_array_wide` is the first Vista confirmation candidate because its exploratory five-round GN-GAD distribution improved over the other tested settings; that selection is documented and must not be reported as an unbiased sweep-level performance claim.

Scientific observables are unchanged: source height and distance to search center (0,2) m, including the radius-one and positive-height probabilities. Predictions at a fixed grid of held-out microphone angles propagate the unresolved position uncertainty. New fixed height regions (-infinity,-2], (-2,0], (0,1], (1,2], (2,4], (4,infinity) and the lower/upper-arm partition measure how mass is assigned along the curve. Conditional observable means test whether a visually recovered arm has the right predictive consequences.

## Biological cases

The logistic model remains K/[1+(K/x0-1) exp(-rt)], x0=0.1, with the published physical uniform priors K in (0.1,200), r in (0,10), population noise SD 0.4, clustered times (6,7,8) and dispersed times (2,7,23). The exact logit transformation Jacobian and prior Hessian are retained. No Gaussian prior is substituted to manufacture a more attractive geometry. Binding retains its previous proper log-affinity prior and data; its tested bend largely straightened in those coordinates.

Neither biological case is automatically a positive example. Their role is to detect coordinate-dependent or weak-curvature explanations before increasing application dimensionality. The local prescreen's modest logistic normal rotation is itself useful evidence against simply promoting the published physical-parameter plot.

## Coverage and comparators

The primary initial-law sensitivity compares a stratified 50:50 mixture of proper-prior and MAP-Laplace draws against pure MAP-Laplace. Both samplers receive each law, independently. GAD receives 2,048 particles (8,192 in the optional resolution profile); pMALA receives eight chains, half in each mixture component. A standalone prior start is also available. Neither method is seeded with reference states, fitted-reference covariance, true source, or a precomputed ridge chart.

A Gaussian mixture initializer is not a fitted posterior mixture and uses no importance weights. Changing the initial bank alone cannot repair incorrect along-curve weights. Report probability, constraint fit and held-out predictions together. Discovered relevant competing MAP basins stop the single-metric campaign; any future mode-spread extension must be charged and shared. This package makes no disconnected-mode advantage claim.

pMALA retains full exact MAP-Hessian preconditioning, independently adapted/frozen per-chain step sizes, charged warmup and cumulative production with rejection repeats. Work caps are each GAD law's own cumulative request counts. A pMALA checkpoint from a different law or a different GAD budget is not automatically matched to the displayed GAD result. Production timings use fresh comparator processes to avoid cache reuse across initial laws. The moment Gaussian is cross-fitted across reference chain groups and remains an oracle representation check.

## GN diagnostics on entry and later banks

The code retains the exact physical residual r=Gamma^(-1/2)(F-y), with exact prior curvature plus J^T J. Pointwise raw Hessian differences remain descriptive. The new audit additionally averages exact and GN bank Hessians with the **same conditional kernel weights used by GAD**, then scales their discrepancy by the guarded conditional solve. This diagnoses a different object from a pointwise residual norm.

At OU times 0.01, 0.03, 0.1 and 0.3, 24 fixed noisy queries from each initial law and 24 from the posterior are used to compare first/later bank fields to independent 2D OU quadrature. Tangent and normal score errors, conditional ESS, exact-bank field error, fine/coarse grid discrepancy and subset size are exported. Reference-only quadrature retains log densities in tails; it does not supply transport scores. Incomplete grid resolution invalidates the score diagnostic at that time; it does not establish a GN failure or success.

The exact-Hessian bank field is an offline control. No exact-Hessian sampling success, Hessian error threshold or large conditional ESS is an automatic eligibility requirement. Eligibility to spend production work rests on a usable reference and the existing physical geometry/endpoint screen. Promotion afterward rests on actual GN-GAD distribution and observable accuracy at measured cost.

## How this informs the next application

Retain the follow-up's richer biological and fixed-layer seismic tracks, and the strategic smooth acoustic-shape PDE track. A useful next candidate should have compensating physical parameters that preserve measured dynamics/dispersion/scattering but alter a predeclared held-out prediction. Work in reasonable native positive/log-rate or smooth-shape coordinates, retain proper scientific priors, and audit GN on initial as well as posterior banks. Screen a small acquisition/noise range and an informative control before large repeats.

A positive 2D localization result would validate an entry/width/coverage mechanism. It would not establish a 4-8 parameter biological or 6-10 parameter seismic application. Those require implementing and validating their own forward/Jacobian batching and reference first. Non-Gaussian priors are optional scientific choices, not prerequisites for GN-GAD relevance. No additional convergence theory is proposed before advisor review.

## Source continuity

- Starting executable: attached `GAD_phase2_vista (1).zip` (the 2,048-particle/four-round snapshot).
- Design authority: attached `GN_GAD_inverse_problem_design_followup(1).pdf`, 31 October, especially width, operational GN usefulness, entry audits, shared coverage and total-cost rules.
- Shared discussion: https://chatgpt.com/share/6ae76f4f-5270-83e9-a916-82caeb034e1a (retrieved 1 November). It also describes a later planned 8,192-particle/five-round TDOA campaign; the optional high-bank profile preserves that resolution check.
- Scientific family motivation: attached application-redesign and new-family reports. Existing source citations for TDOA, logistic growth and binding are retained in each frozen data file and in provenance.
- New campaign identity, target-specific observations, checkpoints and reports are required. Earlier CPU results are not represented as results for a changed target.
