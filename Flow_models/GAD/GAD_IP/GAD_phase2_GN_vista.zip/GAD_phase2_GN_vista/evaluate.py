"""Full-history moments/QoIs; capped-cloud SW2/MMD; source-independent plots."""
import csv
import time
from pathlib import Path
import numpy as np
from scipy.spatial.distance import cdist
from scipy.stats import wasserstein_distance
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from common import check_cloud, log, npz, read, verify_file, write
from audit import curvature_rows
from diagnostics import allocation, bank_score_audit

COLORS = {'NUTS': '#263238', 'Laplace': '#a6761d', 'GAD-1': '#a7c7e7', 'GAD-2': '#6297c7', 'GAD-3': '#326ba8', 'GAD-4': '#10498a',
          'pMALA-work1': '#f8c0a4', 'pMALA-work2': '#ef9668', 'pMALA-work3': '#d96836', 'pMALA-work4': '#ae3e11',
          'pMALA-time4': '#a41c50', 'Moment Gaussian A to B': '#6e687f', 'Moment Gaussian B to A': '#9b92a7'}

def csvfile(path, rows):
    if not rows: return
    keys = list(dict.fromkeys(k for r in rows for k in r))
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='') as f:
        writer = csv.DictWriter(f, keys); writer.writeheader(); writer.writerows(rows)

def capped(x, count):
    # Evenly stratified over ALL production time and chains, retaining repeats.
    x = np.asarray(x).reshape(-1, 2)
    return x[np.linspace(0, len(x)-1, min(count, len(x)), dtype=int)]

def sw2(x, y, directions=256):
    n = min(len(x), len(y)); x = capped(x, n); y = capped(y, n)
    angle = np.arange(directions)*np.pi/directions; v = np.stack([np.cos(angle), np.sin(angle)])
    return float(np.sqrt(np.mean((np.sort(x@v, axis=0)-np.sort(y@v, axis=0))**2)))

def mmd(x, y):
    """Unbiased multiscale MMD^2 at fixed prior-coordinate bandwidths."""
    xx, yy, xy = cdist(x, x, 'sqeuclidean'), cdist(y, y, 'sqeuclidean'), cdist(x, y, 'sqeuclidean')
    values = []
    for h in [.1, .2, .5, 1., 2.]:
        Kx, Ky, Kxy = np.exp(-xx/(2*h*h)), np.exp(-yy/(2*h*h)), np.exp(-xy/(2*h*h))
        values.append((Kx.sum()-len(x))/(len(x)*(len(x)-1))+(Ky.sum()-len(y))/(len(y)*(len(y)-1))-2*Kxy.mean())
    return float(np.mean(values))

def metrics(x, ref, cfg):
    xc, rc = capped(x, cfg['cloud_cap']), capped(ref, cfg['cloud_cap'])
    C = np.cov(x.T); Cr = np.cov(ref.T)
    return {'SW2_prior_coordinates': sw2(xc, rc, cfg['directions']),
            'SW2_normalized':sw2(xc,rc,cfg['directions'])/np.sqrt(np.trace(Cr)), 'multiscale_MMD2_unbiased': mmd(xc, rc),
            'mean_error_prior_coordinates': float(np.linalg.norm(x.mean(0)-ref.mean(0))),
            'relative_covariance_error': float(np.linalg.norm(C-Cr)/np.linalg.norm(Cr)),
            'relative_sd_error': float(np.linalg.norm(np.sqrt(np.diag(C))-np.sqrt(np.diag(Cr)))/np.linalg.norm(np.sqrt(np.diag(Cr)))),
            'sd_amplitude_ratio': float(np.linalg.norm(np.sqrt(np.diag(C)))/np.linalg.norm(np.sqrt(np.diag(Cr)))),
            'all_retained_states_for_moments': len(x), 'cloud_states_for_SW2_MMD': len(xc)}

def block_mcse(q_by_chain, threshold, repeats, seed):
    rng = np.random.default_rng(seed); q = np.asarray(q_by_chain)
    if q.ndim == 1: q = q[None]
    C, N = q.shape
    # Contiguous blocks preserve short-range dependence, not arbitrary thinning.
    block = max(1, min(128, N//8)); nblocks = N//block
    if nblocks<2: return np.nan, np.nan
    blocks = q[:, :nblocks*block].reshape(C*nblocks, block)
    means = blocks.mean(1); tails = (blocks>threshold).mean(1)
    ix = rng.integers(0, len(blocks), (repeats, len(blocks)))
    return float(means[ix].mean(1).std(ddof=1)), float(tails[ix].mean(1).std(ddof=1))

def prediction_stats(target,samples,at):
    """Stable streaming moments of ALL states; capped draws only for quantile bands."""
    mean=np.zeros(len(at));M2=np.zeros(len(at));count=0
    for first in range(0,len(samples),4096):
        values=target.predictions(samples[first:first+4096],at);n=len(values);blockmean=values.mean(0)
        delta=blockmean-mean;total=count+n
        M2+=np.sum((values-blockmean)**2,axis=0)+delta*delta*count*n/total
        mean+=delta*n/total;count=total
    band=target.predictions(capped(samples,4096),at);quantiles=np.quantile(band,[.05,.95],axis=0)
    return {'mean':mean,'sd':np.sqrt(M2/count),'q05':quantiles[0],'q95':quantiles[1],
            'moment_states':count,'quantile_states':len(band)}

def reference_grid_check(ref, quad, target):
    ev, V = np.linalg.eigh(quad['covariance']); W = (V/np.sqrt(ev))@V.T
    mean_err = np.linalg.norm(W@(ref.mean(0)-quad['mean']))
    cov_err = np.linalg.norm(W@np.cov(ref.T)@W-np.eye(2), 2)
    q1, q2 = target.qois(ref), target.qois(quad['samples']); thresholds = np.asarray(target.data['qoi_tail_thresholds'])
    tail = np.max(np.abs((q1>thresholds).mean(0)-(q2>thresholds).mean(0)))
    return {'mean_error_in_quadrature_sd': float(mean_err), 'covariance_error_in_quadrature_metric': float(cov_err),
            'max_QoI_tail_probability_difference': float(tail), 'agreement': bool(mean_err<.15 and cov_err<.15 and tail<.03),
            'thresholds': {'mean_error_in_sd': .15, 'covariance_error': .15, 'tail_probability': .03}}

def evaluate(target, cfg, setup, setup_info, directory, bind):
    report_start=time.monotonic()
    out = directory/'report'; figs = out/'figures'; tables = out/'tables'; figs.mkdir(parents=True, exist_ok=True)
    refinfo = verify_file(directory/'reference/quality.json', bind); refdata = npz(directory/'reference/samples.npz')
    ref = refdata['samples']; chains = refdata['samples_by_chain']; screen = verify_file(directory/'screen.json', bind)
    quad = npz(directory/'setup/quadrature.npz'); qinfo = verify_file(directory/'setup/quadrature.json', bind)
    gridcheck = reference_grid_check(ref, quad, target)
    write(out/'reference_quadrature_check.json', {'binding': bind, **gridcheck, 'quadrature_converged': qinfo['converged']})
    n = cfg['evaluation']['cloud_cap']; rng = np.random.default_rng(777)
    methods = {}; metadata = {}; chainmap = {}
    lap = setup['center']+rng.normal(size=(cfg['gad']['particles'], 2))@setup['factor'].T
    methods['Laplace'] = lap; metadata['Laplace'] = {'work': setup_info['work'], 'elapsed_seconds': setup_info['elapsed_seconds'], 'round': 0}
    chainmap['Laplace'] = lap[None]
    for initial_law in cfg['initializations']:
        for r in range(1, cfg['gad']['rounds']+1):
            p = directory/f'gad_{initial_law}/round{r}'
            if (p/'sampling.json').exists():
                name = f'GAD-{initial_law}-{r}'; metadata[name] = verify_file(p/'sampling.json', bind)
                methods[name] = npz(p/'samples.npz')['samples']; chainmap[name] = methods[name][None]
            for kind in ['work', 'time']:
                p = directory/f'pmala_{initial_law}/{kind}{r}'
                if p.with_suffix('.json').exists():
                    m = verify_file(p.with_suffix('.json'), bind)
                    if m['state'] != 'complete': continue
                    name = f'pMALA-{initial_law}-{kind}{r}'; data = npz(p.with_suffix('.npz'))
                    methods[name] = data['samples']; metadata[name] = m; metadata[name]['round'] = r
                    chainmap[name] = data['samples_by_chain']
    # Cross-fit the moment-Gaussian diagnostic on disjoint reference chains.
    split = max(1, len(chains)//2); A = chains[:split].reshape(-1, 2); B = chains[split:].reshape(-1, 2)
    if len(B)==0: raise ValueError('At least two NUTS chains are required for cross-fitting')
    cross = {}
    for fit, test, label in [(A, B, 'Moment Gaussian A to B'), (B, A, 'Moment Gaussian B to A')]:
        methods[label] = rng.multivariate_normal(fit.mean(0), np.cov(fit.T), size=cfg['gad']['particles'])
        metadata[label] = {'work': None, 'elapsed_seconds': None, 'round': 0, 'diagnostic_oracle': True}; cross[label] = test; chainmap[label] = methods[label][None]
    rows = []; qrows = []; chainrows=[]; qref = target.qois(ref)
    for name, samples in methods.items():
        check_cloud(samples); reference = cross.get(name, ref)
        met = metadata[name]; log(f'{target.case}: evaluate {name}, {len(samples)} states')
        row = {'initial_law':met.get('initial_law'),'method': name, 'round': met.get('round'), 'work': met['work'], 'elapsed_seconds': met['elapsed_seconds'], **metrics(samples, reference, cfg['evaluation'])}
        rows.append(row); q = target.qois(samples); qr = target.qois(reference)
        by_chain = chainmap[name]; qc = target.qois(by_chain.reshape(-1, 2)).reshape(by_chain.shape[0], by_chain.shape[1], 2)
        if name.startswith('pMALA-'):
            import arviz as az
            for label,values in [(f'prior coordinate {j}',by_chain[...,j]) for j in range(2)]+[(target.qoi_labels[j],qc[...,j]) for j in range(2)]:
                chainrows.append({'method':name,'observable':label,'rank_rhat':float(az.rhat(values,method='rank')),
                                  'bulk_ess':float(az.ess(values,method='bulk')),'tail_ess':float(az.ess(values,method='tail',prob=(.05,.95))),
                                  'production_states':int(values.size),'mean_squared_jump_prior_coordinates':float(np.mean(np.sum(np.diff(by_chain,axis=1)**2,axis=2))) if by_chain.shape[1]>1 else np.nan})
        for j, label in enumerate(target.qoi_labels):
            threshold = target.data['qoi_tail_thresholds'][j]
            mean_se, tail_se = block_mcse(qc[..., j], threshold, cfg['evaluation']['bootstrap_repeats'], 909+j)
            quantiles = np.quantile(q[:, j], [.05, .5, .95]); rq = np.quantile(qr[:, j], [.05, .5, .95])
            qrows.append({'method': name, 'qoi': label, 'mean': q[:, j].mean(), 'reference_mean': qr[:, j].mean(),
                          'W1': wasserstein_distance(q[:, j], qr[:, j]), 'q05': quantiles[0], 'median': quantiles[1], 'q95': quantiles[2],
                          'reference_q05': rq[0], 'reference_median': rq[1], 'reference_q95': rq[2],
                          'tail_threshold': threshold, 'upper_tail_probability': np.mean(q[:, j]>threshold),
                          'reference_upper_tail_probability': np.mean(qr[:, j]>threshold), 'conditional_or_block_mean_mcse': mean_se,
                          'conditional_or_block_tail_mcse': tail_se, 'mcse_scope': 'single-run particle/block MC error; no between-seed uncertainty'})
    floors = []
    for i in range(cfg['evaluation']['floor_repeats']):
        aa = np.roll(A, i*137, axis=0); bb = np.roll(B, i*173, axis=0)
        floors.append(metrics(capped(aa, n), capped(bb, n), cfg['evaluation']))
    csvfile(tables/'metrics.csv', rows); csvfile(tables/'qoi_metrics.csv', qrows); csvfile(tables/'reference_floor.csv', floors)
    csvfile(tables/'nuts_diagnostics.csv', refinfo['diagnostics'])
    csvfile(tables/'pmala_chain_diagnostics.csv',chainrows)
    refqchains = target.qois(chains.reshape(-1, 2)).reshape(*chains.shape[:2], 2)
    csvfile(tables/'reference_qoi_mcse.csv', [{'qoi':target.qoi_labels[j], 'mean_mcse':block_mcse(refqchains[..., j], target.data['qoi_tail_thresholds'][j], 128, 999)[0],
                                              'tail_mcse':block_mcse(refqchains[..., j], target.data['qoi_tail_thresholds'][j], 128, 999)[1]} for j in range(2)])
    auditrows = list(screen['curvature_rows'])
    auditbanks=[]; allocation_rows=allocation(target,ref,ref,cfg,'NUTS')
    for name,cloud in methods.items(): allocation_rows.extend(allocation(target,cloud,cross.get(name,ref),cfg,name))
    for initial_law in cfg['initializations']:
        for r in range(1,cfg['gad']['rounds']+1):
            p=directory/f'gad_{initial_law}/round{r}/bank.npz'
            if not p.exists():continue
            bank=npz(p);allocation_rows.extend(allocation(target,bank['x'],ref,cfg,f'bank-{initial_law}-{r}'))
            if r in [1,cfg['gad']['rounds']]:
                pts=bank['x'][np.linspace(0,len(bank['x'])-1,4,dtype=int)]
                auditrows.extend(curvature_rows(target,pts,f'{initial_law}_bank{r}',float(setup['t_min'])))
                auditbanks.append((initial_law,r,bank))
    csvfile(tables/'coverage_constraint_and_conditional_QoI.csv',allocation_rows)
    score_rows,score_summary,score_cost=bank_score_audit(target,auditbanks,ref,quad,cfg)
    csvfile(tables/'OU_score_queries.csv',score_rows);csvfile(tables/'OU_score_summary.csv',score_summary)
    write(out/'offline_diagnostic_cost.json',score_cost)
    csvfile(tables/'curvature_audit.csv', auditrows)
    ledger = []
    for name, met in metadata.items():
        if met.get('diagnostic_oracle'): continue
        ledger.append({'method':name,'work':met['work'],'elapsed_seconds':met['elapsed_seconds'], **met.get('oracle_counts', {}),
                       'initial_law':met.get('initial_law'),'guard_fraction':met.get('guard_fraction'), 'mean_conditional_ess':met.get('mean_conditional_ess'), 'min_conditional_ess':met.get('min_conditional_ess'),
                       'acceptance_rate':met.get('acceptance_rate'), 'time_undershoot_seconds':met.get('time_undershoot_seconds')})
    csvfile(tables/'work_and_sampler_diagnostics.csv', ledger)
    summary = {'binding':bind,'case':target.case,'reference_usable':refinfo['reference_usable'], 'quadrature_converged':qinfo['converged'],
               'reference_quadrature_agreement':gridcheck['agreement'], 'screen':screen, 'smoke_only':cfg.get('smoke_only',False),
               'interpretation':'One dataset and sampler seed; MC/block uncertainties are not repeat-to-repeat uncertainty. Failed/negative screens remain visible.',
               'SW2_reference_floor_mean':np.mean([f['SW2_prior_coordinates'] for f in floors]),'mmd_bandwidths_prior_coordinates':[.1,.2,.5,1.,2.],
               'MMD_estimator':'unbiased MMD squared; small negative values are sampling noise',
               'distribution_clouds':'whole-history stratification, including rejections; pMALA draws are dependent',
               'moments_and_QoIs':'ALL post-warmup production states per checkpoint; streaming full-history predictive moments; bands alone capped at 4096 states',
               'initial_laws':cfg['initializations'],
               'GN_operational_rule':'Accuracy of GN-GAD on the physical target; exact-Hessian bank field is an offline diagnostic, never an eligibility gate',
               'gaussian_controls':'MAP-Laplace and split-reference moment Gaussian; latter is an oracle diagnostic, not a free sampler'}
    write(out/'summary.json', summary)
    plt.rcParams.update({'font.size':9, 'axes.spines.top':False, 'axes.spines.right':False, 'figure.dpi':120})
    status = 'SMOKE VALIDATION' if cfg.get('smoke_only') else ('REFERENCE PASSED' if refinfo['reference_usable'] and gridcheck['agreement'] and qinfo['converged'] else 'PROVISIONAL REFERENCE')
    figures = []
    def finish(fig, filename):
        fig.suptitle(f'{target.case} | {status}', fontsize=12, fontweight='bold')
        fig.tight_layout(rect=(0, 0, 1, .94)); fig.savefig(figs/(filename+'.png'), dpi=170); fig.savefig(figs/(filename+'.pdf'))
        figures.append(fig)
    R=cfg['gad']['rounds'];primary=cfg['initializations'][0]
    for i,law in enumerate(cfg['initializations']):
        for r in range(1,R+1):
            COLORS[f'GAD-{law}-{r}']=plt.cm.Blues(.35+.55*r/R) if i==0 else plt.cm.Purples(.35+.55*r/R)
            COLORS[f'pMALA-{law}-work{r}']=plt.cm.Oranges(.35+.55*r/R) if i==0 else plt.cm.Reds(.35+.55*r/R)
            COLORS[f'pMALA-{law}-time{r}']=plt.cm.Greens(.35+.55*r/R)
    finalists = ['Laplace', f'GAD-{primary}-{R}', f'pMALA-{primary}-work{R}', f'pMALA-{primary}-time{R}', 'Moment Gaussian A to B']
    finalists = [k for k in finalists if k in methods]
    # 1. Posterior geometry, always in both physically meaningful and sampled coordinates.
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.6))
    for ax, physical in zip(axes, [False, True]):
        r = capped(ref, 4000); rr = target.parameters(r) if physical else r
        ax.scatter(rr[:, 0], rr[:, 1], s=2, alpha=.18, c=COLORS['NUTS'], label='NUTS')
        for name in finalists:
            s = capped(methods[name], 700); s = target.parameters(s) if physical else s
            ax.scatter(s[:, 0], s[:, 1], s=3, alpha=.22, color=COLORS.get(name,'#888888'), label=name)
        if physical:
            ax.set_xlabel(target.labels[0]); ax.set_ylabel(target.labels[1]); ax.set_title('Physical parameters (linear axes)')
        else:
            ax.set_xlabel(target.coordinate_label+' 1'); ax.set_ylabel(target.coordinate_label+' 2'); ax.set_title('Coordinates actually sampled')
    axes[1].legend(fontsize=7, markerscale=2); finish(fig,'posterior_geometry')
    # 2. Predictive curves: common scales, no clipped observations or negative noisy occupancy.
    tdoa = target.case.startswith('tdoa')
    at = np.linspace(-np.pi,np.pi,150) if tdoa else (np.geomspace(1e-6, 1., 150) if target.case=='binding' else np.linspace(.1, 30., 150))
    prediction={'NUTS':prediction_stats(target,ref,at)}
    for name in finalists:prediction[name]=prediction_stats(target,methods[name],at)
    prows=[];pmetrics=[]
    for name,pp in prediction.items():
        for j,value in enumerate(at):prows.append({'method':name,'prediction_coordinate':value,'mean':pp['mean'][j],'sd':pp['sd'][j],
                                                   'q05':pp['q05'][j],'q95':pp['q95'][j],'states_for_moments':pp['moment_states'],'states_for_bands':pp['quantile_states']})
        if name!='NUTS':
            rm=prediction['NUTS']['mean'];rs=prediction['NUTS']['sd'];ss=pp['sd']
            pmetrics.append({'method':name,'predictive_mean_RMSE_vs_reference':float(np.sqrt(np.mean((pp['mean']-rm)**2))),
                             'relative_predictive_SD_error':float(np.linalg.norm(ss-rs)/np.linalg.norm(rs)),
                             'predictive_SD_amplitude_ratio':float(np.linalg.norm(ss)/np.linalg.norm(rs)),
                             'normalized_predictive_SD_pattern_error':float(np.linalg.norm(ss/max(1e-300,np.linalg.norm(ss))-rs/np.linalg.norm(rs)))})
    csvfile(tables/'predictive_curves.csv',prows);csvfile(tables/'predictive_metrics.csv',pmetrics)
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.6)); pr = prediction['NUTS']
    for ax in axes:
        ax.plot(at, pr['mean'], color=COLORS['NUTS'], label='NUTS mean'); lo, hi = pr['q05'],pr['q95']
        ax.fill_between(at,lo,hi,color='#263238',alpha=.12,label='NUTS 90% band')
        ax.errorbar(target.data['design'],target.data['y'],yerr=target.data['noise_sd'],fmt='o',ms=3,color='black',label='data +/- SD')
        if target.case=='binding': ax.set_xscale('log')
        ax.set_xlabel('receiver angle (rad)' if tdoa else ('ligand concentration (uM)' if target.case=='binding' else 'time'))
        ax.set_ylabel('TDOA (microseconds)' if tdoa else ('occupancy' if target.case=='binding' else 'population'))
    for name in finalists:
        pp = prediction[name]
        axes[0].plot(at,pp['mean'],c=COLORS.get(name,'#888888'),label=name)
    axes[1].clear(); axes[1].plot(at,pr['sd'],c=COLORS['NUTS'],label='NUTS')
    for name in finalists: axes[1].plot(at,prediction[name]['sd'],c=COLORS.get(name,'#888888'),label=name)
    if target.case=='binding': axes[1].set_xscale('log')
    axes[1].set(xlabel='receiver angle (rad)' if tdoa else ('concentration (uM)' if target.case=='binding' else 'time'),ylabel='predictive SD',title='Uncertainty amplitude and shape')
    axes[0].set_title('Posterior prediction'); axes[0].legend(fontsize=6); axes[1].legend(fontsize=6); finish(fig,'predictive_curves')
    # 3. Fixed scientific observables: CDF and survival, all samples used.
    fig, axes = plt.subplots(2, 2, figsize=(10.5, 7.2))
    for j in range(2):
        for name, q in [('NUTS',qref)]+[(k,target.qois(methods[k])) for k in finalists]:
            values = np.sort(q[:,j]); cdf = (np.arange(len(values))+.5)/len(values)
            axes[j,0].plot(values,cdf,label=name,c=COLORS.get(name,'#888888'))
            axes[j,1].plot(values,1-cdf,label=name,c=COLORS.get(name,'#888888'))
        for ax in axes[j]: ax.set_xlabel(target.qoi_labels[j]); ax.axvline(target.data['qoi_tail_thresholds'][j],ls=':',c='#aaaaaa')
        axes[j,0].set_ylabel('CDF'); axes[j,1].set_ylabel('upper-tail probability'); axes[j,1].set_yscale('log'); axes[j,1].set_ylim(1e-3,1)
    axes[0,0].legend(fontsize=7); finish(fig,'qoi_cdfs_and_tails')
    # 4. Quantitative convergence in the historical work proxy and measured elapsed time.
    fig, axes = plt.subplots(2, 2, figsize=(10.5, 7.2))
    for col, cost in enumerate(['work','elapsed_seconds']):
        compared=[]
        for i,law in enumerate(cfg['initializations']):
            compared.extend([(f'GAD-{law}-','#10498a' if i==0 else '#7160a0'),(f'pMALA-{law}-'+('work' if cost=='work' else 'time'),'#ae3e11' if i==0 else '#bf545e')])
        for prefix, color in compared:
            selected = [r for r in rows if r['method'].startswith(prefix) and r[cost] is not None]
            for row, metric in enumerate(['SW2_prior_coordinates','relative_covariance_error']):
                axes[row,col].plot([r[cost] for r in selected],[r[metric] for r in selected],'o-',c=color,label=prefix.rstrip('-'))
                axes[row,col].set_ylabel(metric.replace('_',' ')); axes[row,col].set_xlabel('E + G + H requests' if cost=='work' else 'total method seconds')
        laplace_row=next(r for r in rows if r['method']=='Laplace')
        for row,metric in enumerate(['SW2_prior_coordinates','relative_covariance_error']):
            axes[row,col].axhline(laplace_row[metric],ls='--',c=COLORS['Laplace'],label='MAP-Laplace')
        axes[0,col].axhline(summary['SW2_reference_floor_mean'],ls=':',c='#888888',label='ref/ref floor'); axes[0,col].legend(fontsize=7)
    finish(fig,'accuracy_vs_cost')
    # 5. Reference diagnostics and chain agreement in meaningful observables.
    fig, axes = plt.subplots(2, 2, figsize=(10.5, 6.8)); cq = refqchains
    for c in range(len(chains)):
        step = max(1,chains.shape[1]//1500)
        for j in range(2):
            axes[j,0].plot(np.arange(chains.shape[1])[::step],cq[c,::step,j],lw=.45,alpha=.7,label=f'chain {c}')
            axes[j,1].hist(cq[c,:,j],bins=45,density=True,histtype='step',label=f'chain {c}')
    for j in range(2): axes[j,0].set(xlabel='retained NUTS draw',ylabel=target.qoi_labels[j]); axes[j,1].set(xlabel=target.qoi_labels[j],ylabel='density')
    axes[0,0].set_title(f'Rhat max {refinfo["max_rank_rhat"]:.3f}, bulk ESS min {refinfo["min_bulk_ess"]:.0f}'); axes[0,1].legend(fontsize=7)
    finish(fig,'reference_traces_and_histograms')
    # 6. Geometry: rotating informed normal, local coherence, independent grid contours.
    geo = npz(directory/'geometry.npz'); fig, axes = plt.subplots(1,3,figsize=(11,4.2))
    axes[0].contour(quad['axis0'],quad['axis1'],quad['relative_density'].T,levels=[.01,.05,.2,.6],colors='#666666')
    axes[0].quiver(geo['points'][:,0],geo['points'][:,1],geo['stiff'][:,0],geo['stiff'][:,1],angles='xy',scale_units='xy',scale=5,color='#10498a')
    axes[0].set(xlabel='prior coordinate 1',ylabel='prior coordinate 2',title='Likelihood stiff direction')
    axes[1].hist(geo['rotation'],bins=15,color='#10498a',alpha=.8);axes[1].set(xlabel='angle from MAP normal (degrees)',ylabel='audit points',title='Global rotation')
    axes[2].scatter(geo['nearest_distance'],geo['local_angle'],c='#10498a',s=15);axes[2].set(xlabel='distance to nearest reference draw',ylabel='normal rotation (degrees)',title='Local coherence')
    finish(fig,'geometry_audit')
    # 7. Bank overlap/guard and exact versus GN residuals.
    fig,axes=plt.subplots(1,3,figsize=(11,4.2)); gr=[metadata[k] for k in methods if k.startswith('GAD-')]
    
    for law in cfg['initializations']:
        rr=[r for r in gr if r['initial_law']==law]
        axes[0].plot([r['round'] for r in rr],[r['mean_conditional_ess'] for r in rr],'o-',label=law)
    axes[0].legend(fontsize=6); axes[0].set(xlabel='GAD round',ylabel='mean conditional ESS',title='Bank overlap')
    
    for law in cfg['initializations']:
        rr=[r for r in gr if r['initial_law']==law]
        axes[1].plot([r['round'] for r in rr],[r['guard_fraction'] for r in rr],'o-',label=law)
    axes[1].set(xlabel='GAD round',ylabel='guarded eigenvalue fraction',title='Actual solve guard')
    for region in sorted(set(r['region'] for r in auditrows)):
        color='#263238' if region=='reference' else ('#a7c7e7' if region.endswith('bank1') else '#10498a')
        rr=[r for r in auditrows if r['region']==region];axes[2].scatter([r['time'] for r in rr],[r['pointwise_solve_scaled_residual_norm'] for r in rr],s=12,c=color,label=region)
    axes[2].set_xscale('log');axes[2].set_yscale('symlog',linthresh=.001)
    axes[2].set_ylim(bottom=0.)
    axes[2].set(xlabel='OU time',ylabel='pointwise solve-scaled residual norm',title='Exact Hessian - GN');axes[2].legend(fontsize=6)
    finish(fig,'overlap_guard_curvature')
    from diagnostic_plots import extra_figures
    extra_figures(target,cfg,ref,methods,allocation_rows,score_summary,finish,csvfile,tables)
    with PdfPages(out/'dashboard.pdf') as pdf:
        for fig in figures: pdf.savefig(fig)
    for fig in figures: plt.close(fig)
    text = f'''# {target.case}\n\nStatus: {status}. Geometry screen: {screen['status']}.\n\nReference passed: {refinfo['reference_usable']}; quadrature converged: {qinfo['converged']}; reference/grid agreement: {gridcheck['agreement']}.\n\nSee tables/metrics.csv, qoi_metrics.csv, work_and_sampler_diagnostics.csv and curvature_audit.csv. All pMALA moments and QoIs use its full post-warmup history. Cloud metrics stratify that history and retain rejection repeats. The Gaussian diagnostic is fit to one chain group and evaluated on the other.\n\nThis is one fixed dataset and seed, with no claim of repeat-to-repeat uncertainty. A curved physical-parameter plot alone does not establish a curved target in the coordinates sampled. Negative or unresolved screens are retained.\n'''
    (out/'README.md').write_text(text)
    write(out/'offline_diagnostic_cost.json',{**score_cost,'report_elapsed_seconds':time.monotonic()-report_start,
        'count_scope':'Only offline audit Hessian requests are enumerated; reference, grid, forward/QoI evaluation and plotting are outside sampler budgets. Report elapsed time includes evaluation and figures.'})
    return summary
