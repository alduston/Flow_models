#!/usr/bin/env python3
"""One comparator in a fresh process, so method compilation caches are not shared."""
import os
os.environ.setdefault('JAX_ENABLE_X64','true');os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE','false')
import argparse
from pathlib import Path
from common import binding,npz,read,verify_file
from models import Target
from samplers import gad,pmala

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--kind',choices=['gad','pmala'],required=True);ap.add_argument('--initial-law',choices=['mixed','laplace','prior'],required=True)
    args=ap.parse_args();identity=read(args.out/'target.json');cfg=identity['config'];target=Target(identity['data']['case'])
    bind=binding(cfg,target.data);verify_file(args.out/'target.json',bind)
    setup=npz(args.out/'setup/production_setup.npz');si=verify_file(args.out/'setup/setup.json',bind)
    law=args.initial_law
    if args.kind=='gad':gad(target,cfg,setup,si,args.out/('gad_'+law),bind,law)
    else:
        records=[verify_file(args.out/f'gad_{law}/round{r}/sampling.json',bind) for r in range(1,cfg['gad']['rounds']+1)]
        pmala(target,cfg,setup,si,records,args.out/('pmala_'+law),bind,law)
if __name__=='__main__':main()
