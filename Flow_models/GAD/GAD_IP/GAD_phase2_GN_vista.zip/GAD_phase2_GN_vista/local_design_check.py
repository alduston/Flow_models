#!/usr/bin/env python3
"""Cheap quadrature-only geometry check. Independent NUTS still required in production."""
import os
os.environ.setdefault('JAX_PLATFORMS','cpu')
import argparse
from pathlib import Path
import numpy as np
from common import ROOT,binding,read,write
from models import Target
from prepare import setup,quadrature
from audit import screen

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--cases',nargs='+',default=['tdoa','tdoa_soft','tdoa_wide','tdoa_gentle','tdoa_control_wide','logistic_clustered','logistic_dispersed'])
    args=ap.parse_args();cfg=read(ROOT/'config.json');records=[]
    for case in args.cases:
        t=Target(case);bind=binding(cfg,t.data);out=args.out/case
        st,si=setup(t,cfg,out/'setup',bind);q,qi=quadrature(t,cfg,out/'setup',bind)
        sc=screen(t,cfg,st,si,{'samples':q['samples']},{'reference_usable':qi['converged']},out,bind)
        rec=dict(case=case,quadrature_converged=qi['converged'],geometry_candidate=sc['geometry_candidate'],
            rotation_p90_degrees=sc['rotation_p90_degrees'],normal_width_proxy_median=sc['normal_width_proxy_median'],
            warning='Quadrature-only prescreen; not an accepted production NUTS reference and not a sampler ranking')
        records.append(rec);print(rec,flush=True)
    write(args.out/'quadrature_prescreen.json',records)
if __name__=='__main__':main()
