"""Prespecified reference-based geometry screen and exact/GN curvature audit."""
import numpy as np
import jax.numpy as jnp
from scipy.spatial import cKDTree
from common import save_npz, write

def angles(v, other):
    return np.degrees(np.arccos(np.clip(np.abs(np.sum(v*other, axis=-1)), 0, 1)))

def curvature_rows(target, points, region, t_min):
    out = []; matrices = target.gn(points)
    for x, Hgn in zip(points, matrices):
        exact = np.asarray(target.hessian(jnp.asarray(x))); residual = exact-Hgn
        for t in [t_min, .001, .01, .1]:
            a2 = np.exp(-2*t); gamma = -np.expm1(-2*t)
            e, V = np.linalg.eigh(Hgn); denom = np.maximum(a2+gamma*e, .001)
            scale = (V/np.sqrt(denom))@V.T
            error = np.linalg.norm(gamma*scale@residual@scale, 2)
            out.append({'region': region, 'x0': float(x[0]), 'x1': float(x[1]), 'time': t,
                        'pointwise_solve_scaled_residual_norm': float(error),
                        'relative_Hessian_GN_error': float(np.linalg.norm(residual)/max(1e-12, np.linalg.norm(exact))),
                        'exact_min_eigenvalue': float(np.linalg.eigvalsh(exact).min())})
    return out

def screen(target, cfg, setup, setup_info, reference, quality, directory, bind):
    x = reference['samples']; idx = np.linspace(0, len(x)-1, cfg['screen']['points'], dtype=int); pts = x[idx]
    likelihood = target.likelihood_gn(pts)
    e, V = np.linalg.eigh(likelihood); stiff = V[:, :, -1]
    _, vmap = np.linalg.eigh(target.likelihood_gn(setup['center'][None])[0]); vm = vmap[:, -1]
    ratio = e[:, -1]/np.maximum(e[:, 0], 1e-12); rotation = angles(stiff, vm)
    unique = np.unique(x,axis=0)
    neighbors = cKDTree(unique).query(pts, k=2)[1][:, 1]
    _, Vnear = np.linalg.eigh(target.likelihood_gn(unique[neighbors]))
    local = angles(stiff, Vnear[:, :, -1]); distance = np.linalg.norm(pts-unique[neighbors], axis=1)
    gap = ratio>=cfg['screen']['min_projector_gap_ratio']
    useful_gap = bool(np.mean(gap)>=.8)
    anisotropy = bool(np.median(ratio)>=cfg['screen']['min_median_likelihood_eigenvalue_ratio'])
    rotation_ok = bool(np.percentile(rotation[gap], 90)>=cfg['screen']['min_rotation_p90_degrees']) if useful_gap else False
    hrows = curvature_rows(target, pts[:4], 'reference', float(setup['t_min']))
    cov_ref = np.cov(x.T); ratio_endpoint = -np.expm1(-2*float(setup['t_min']))/(np.exp(-2*float(setup['t_min']))*np.linalg.eigvalsh(cov_ref).min())
    not_multimode = not setup_info['distinct_relevant_basins']
    eligible = quality['reference_usable'] and useful_gap and anisotropy and rotation_ok and not_multimode
    result = {'binding': bind, 'reference_usable': quality['reference_usable'], 'geometry_candidate': bool(eligible),
              'median_likelihood_eigenvalue_ratio': float(np.median(ratio)),
              'normal_width_proxy_median':float(np.median(1/np.sqrt(1+e[:,-1]))),
              'likelihood_max_eigenvalue_median':float(np.median(e[:,-1])), 'rank1_projector_gap_usable': useful_gap,
              'rotation_p90_degrees': float(np.percentile(rotation[gap], 90)) if useful_gap else None,
              'nearest_reference_angle_median_degrees': float(np.median(local)),
              'nearest_reference_distance_median': float(np.median(distance)), 'endpoint_inflation_ratio_reference': ratio_endpoint,
              'endpoint_within_tolerance_reference': bool(ratio_endpoint<=cfg['gad']['endpoint_variance_tolerance']),
              'known_negative_control': target.data['control'], 'thresholds': cfg['screen'],
              'status': 'candidate' if eligible else ('negative_control' if target.data['control'] else 'screen_negative_or_unresolved'),
              'interpretation': 'A geometry screen, not evidence of a GAD advantage. Flat/straightened cases stay visible. GN audit is pointwise, not a conditional-bank-average identity.',
              'curvature_rows': hrows}
    write(directory/'screen.json', result)
    save_npz(directory/'geometry.npz', points=pts, eigenvalues=e, stiff=stiff, rotation=rotation,
             local_angle=local, nearest_distance=distance, projector_gap_usable=gap)
    return result
