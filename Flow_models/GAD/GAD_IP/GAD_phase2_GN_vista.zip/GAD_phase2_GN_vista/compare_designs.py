#!/usr/bin/env python3
"""Collect completed and failed design screens without choosing a sampler winner."""
import argparse
from pathlib import Path
from common import read,write
from evaluate import csvfile

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--batch',type=Path,required=True);args=ap.parse_args()
    rows=[]
    for p in sorted(args.batch.glob('*/target.json')):
        root=p.parent;identity=read(p);d=identity['data'];sc=read(root/'screen.json') if (root/'screen.json').exists() else {}
        ref=read(root/'reference/quality.json') if (root/'reference/quality.json').exists() else {}
        status=read(root/'sampling_status.json') if (root/'sampling_status.json').exists() else {}
        rows.append(dict(case=d['case'],arrival_noise_sd_us=d.get('arrival_time_noise_sd_microseconds'),sensor_radius_m=d.get('sensor_radius_m'),
            reference_usable=ref.get('reference_usable'),geometry_candidate=sc.get('geometry_candidate'),
            normal_width_proxy=sc.get('normal_width_proxy_median'),global_rotation_p90_deg=sc.get('rotation_p90_degrees'),
            median_likelihood_eigenvalue_ratio=sc.get('median_likelihood_eigenvalue_ratio'),sampling_state=status.get('state','not_run'),
            caution='Geometry and derivative budget comparisons do not establish a Vista wall-time advantage'))
    csvfile(args.batch/'design_summary.csv',rows)
    write(args.batch/'design_summary.json',{'cases':rows,'decision':'Retain every prespecified design; no ranking-driven parameter selection or automatic promotion.'})
if __name__=='__main__':main()
