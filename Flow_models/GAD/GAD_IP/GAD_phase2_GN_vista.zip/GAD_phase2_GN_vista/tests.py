"""Numerical checks for the scientific failure modes, not output-shape snapshots."""
import numpy as np
import jax.numpy as jnp
from models import Target, CASES
from prepare import derivative_check, gaussian_control
from vendor.lfgi import score_batch
from vendor.mala import mala_step

def numerical_tests():
    records = {}
    for case in CASES:
        target = Target(case)
        records[case] = derivative_check(target,[np.zeros(2), np.array([.15,-.12])])
        # Independent formula validates physical parameter order and forward convention.
        x = np.array([.2,-.1]); p = target.parameters(x[None])[0]; at = np.array(target.data['design'])
        if case.startswith('tdoa'):
            radius=target.data['sensor_radius_m']; phi=target.data['reference_angle_radians']
            reference=radius*np.array([np.cos(phi),np.sin(phi)]); receivers=radius*np.column_stack([np.cos(at),np.sin(at)])
            expected=(np.sqrt(np.sum((p-receivers)**2,axis=1)+1e-18)-np.sqrt(np.sum((p-reference)**2)+1e-18))*1e6/target.data['sound_speed_m_per_s']
            cov=np.array(target.data['noise_covariance']);np.testing.assert_allclose(cov,target.data['arrival_time_noise_sd_microseconds']**2*(np.eye(len(at))+np.ones((len(at),len(at)))))
        elif case=='binding':
            a,b=p; expected=(a*at+2*a*b*at*at)/(2*(1+a*at+a*b*at*at))
        else:
            K,r=p; expected=K/(1+(K/target.data['initial_population']-1)*np.exp(-r*at))
        np.testing.assert_allclose(np.asarray(target.forward(jnp.asarray(x))),expected,rtol=2e-13,atol=1e-13)
    rng=np.random.default_rng(1); m=np.array([.5,-.8]); C=np.array([[.025,.014],[.014,.04]]); H=np.linalg.inv(C)
    bank=rng.multivariate_normal(m,C,37); score=-(bank-m)@H; hs=np.tile(H,(len(bank),1,1)); query=rng.normal(size=(13,2))
    gaussian_errors=[]
    for t in [1e-10,1e-6,.001,.1,1.,10.]:
        actual,_=score_batch(jnp.asarray(query),t,jnp.asarray(bank),jnp.asarray(score),jnp.asarray(hs))
        a=np.exp(-t);g=-np.expm1(-2*t); expected=-(query-a*m)@np.linalg.inv(a*a*C+g*np.eye(2))
        err=np.linalg.norm(np.asarray(actual)-expected)/max(1.,np.linalg.norm(expected));gaussian_errors.append(err)
        assert err<2e-10,(t,err)
    ctl=gaussian_control(m,C,10.,1e-7,300);assert ctl['max_relative_variance_error']<.01
    from reference_coordinates import tdoa_chart
    import jax
    chart,logjac,inverse=tdoa_chart(Target('tdoa'))
    for q in [np.array([.2,.4]),np.array([-.4,-.6]),np.array([.7,0.])]:
        x=np.asarray(chart(jnp.asarray(q)));np.testing.assert_allclose(inverse(x),q,atol=1e-11)
        np.testing.assert_allclose(float(logjac(q)),float(jnp.linalg.slogdet(jax.jacfwd(chart)(jnp.asarray(q)))[1]),atol=1e-11)
    # Detailed-balance algebra in whitened Gaussian coordinates; finite MH target.
    def cb(x):return -.5*np.sum(x*x,1),-x
    x=rng.normal(size=(20000,2));lp,s=cb(x);y,_,_,info=mala_step(x,lp,s,cb,.2,rng)
    assert np.linalg.norm(y.mean(0))<.04 and np.linalg.norm(np.cov(y.T)-np.eye(2))<.06
    # Rejections must be preserved; no unique()/trailing-window output transformation.
    _,_,_,bad=mala_step(x,lp,s,lambda z:(np.full(len(z),-np.inf),np.zeros_like(z)),.2,rng)
    assert bad['accepted']==0
    # Actual JAX pMALA transition: different frozen steps preserve one target.
    from samplers import make_pmala_kernels
    class Gaussian:
        energy=staticmethod(lambda x:.5*jnp.vdot(x,x))
    initial,_,production=make_pmala_kernels(Gaussian(),np.zeros(2),np.eye(2))
    zz=jnp.asarray(rng.normal(size=(20000,2)));ll,ss=initial(zz)
    state=(zz,ll,ss,jax.random.PRNGKey(173),jnp.linspace(.01,.5,len(zz)))
    state,_=production(state,1);actual=np.asarray(state[0])
    assert np.linalg.norm(actual.mean(0))<.04 and np.linalg.norm(np.cov(actual.T)-np.eye(2))<.06
    # Independent OU quadrature must reproduce the analytic Gaussian score.
    from diagnostics import ou_score
    axis=np.linspace(-7,7,241);aa,bb=np.meshgrid(axis,axis,indexing='ij');nodes=np.column_stack([aa.ravel(),bb.ravel()])
    Cq=np.array([[.4,.1],[.1,.7]]);mq=np.array([.2,-.1]);Pq=np.linalg.inv(Cq)
    logs=-.5*np.sum(((nodes-mq)@Pq)*(nodes-mq),axis=1)
    queries=np.array([[.1,.3],[-.6,.2],[.4,-.8]])
    for t in [.01,.1,.3]:
        actual=ou_score(queries,t,nodes,logs);alpha=np.exp(-t);gamma=-np.expm1(-2*t)
        expected=-(queries-alpha*mq)@np.linalg.inv(alpha*alpha*Cq+gamma*np.eye(2))
        np.testing.assert_allclose(actual,expected,rtol=2e-7,atol=2e-8)
    # Dataset changes alter physical noise, not standardized arrival errors.
    base=Target('tdoa').data
    standardized=(np.asarray(base['y'])-base['y_clean'])/base['arrival_time_noise_sd_microseconds']
    for case in ['tdoa_soft','tdoa_wide','tdoa_gentle','tdoa_array_centered','tdoa_array_wide','tdoa_coarse']:
        d=Target(case).data
        np.testing.assert_allclose((np.asarray(d['y'])-d['y_clean'])/d['arrival_time_noise_sd_microseconds'],standardized,atol=2e-13)
    # Initial laws are reference-free, proper, and independent across methods.
    from initialization import draws
    cfg={'initialization':{'mixture_prior_fraction':.5}}
    st={'center':np.array([1.,-1.]),'factor':np.diag([.1,.2])}
    mixed=draws(Target('tdoa_wide'),st,cfg,20000,123,'mixed')
    np.testing.assert_allclose(mixed.mean(0),st['center']/2,atol=.025)
    uniform=Target('logistic_clustered');prior=draws(uniform,st,cfg,20000,128,'prior');params=uniform.parameters(prior)
    bounds=np.asarray(uniform.data['prior_bounds'])
    np.testing.assert_allclose(params.mean(0),bounds.mean(1),rtol=.02)
    assert not np.array_equal(draws(Target('tdoa_wide'),st,cfg,8,1,'mixed'),draws(Target('tdoa_wide'),st,cfg,8,2,'mixed'))
    return {'passed':True,'derivative_checks':records,'Gaussian_LFGI_relative_errors':gaussian_errors,'Heun_control':ctl,'MALA_stationarity_check':info,'OU_score_quadrature':True,'paired_data_noise':True,'shared_initial_laws':True,'per_chain_JAX_MALA_stationarity':True}

if __name__=='__main__':
    from common import clean
    import json
    print(json.dumps(clean(numerical_tests()),indent=2))
