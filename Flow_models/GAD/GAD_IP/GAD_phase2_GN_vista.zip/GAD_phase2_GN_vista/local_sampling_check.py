#!/usr/bin/env python3
"""Exploratory CPU checks against quadrature; never substitutes for production NUTS."""
import os
os.environ.setdefault('JAX_PLATFORMS','cpu');os.environ.setdefault('JAX_ENABLE_X64','true')
import argparse
from pathlib import Path
import numpy as np
from common import ROOT,binding,read,write,npz
from models import Target
from prepare import setup,quadrature,production_endpoint
from samplers import gad,pmala
from evaluate import metrics,csvfile
from diagnostics import allocation

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--cases',nargs='+',default=['tdoa_wide','tdoa_gentle']);ap.add_argument('--particles',type=int,default=512)
    args=ap.parse_args();cfg=read(ROOT/'config.json');cfg['smoke_only']=True;cfg['gad']['particles']=args.particles
    cfg['evaluation'].update(cloud_cap=args.particles,directions=128);cfg['pmala'].update(max_transitions=8192,max_seconds=60)
    rows=[];coverage=[]
    for case in args.cases:
        t=Target(case);bind=binding(cfg,t.data);out=args.out/case
        st,si=setup(t,cfg,out/'setup',bind);q,qi=quadrature(t,cfg,out/'setup',bind)
        if not qi['converged']:raise RuntimeError('Local quadrature did not converge')
        st=production_endpoint(st,cfg,q['samples'],out/'setup',bind)
        write(out/'LOCAL_ONLY.json',{'binding':bind,'config':cfg,'reference':'converged 2D quadrature only; production still requires independent NUTS','smoke_only':True})
        lap=st['center']+np.random.default_rng(777).normal(size=(args.particles,2))@st['factor'].T
        rows.append(dict(case=case,method='Laplace',**metrics(lap,q['samples'],cfg['evaluation'])))
        for law in cfg['initializations']:
            gr=gad(t,cfg,st,si,out/('gad_'+law),bind,law);pmala(t,cfg,st,si,gr,out/('pmala_'+law),bind,law)
            for r in [1,cfg['gad']['rounds']]:
                paths=[(f'GAD-{law}-{r}',out/f'gad_{law}/round{r}/samples.npz'),(f'pMALA-{law}-work{r}',out/f'pmala_{law}/work{r}.npz')]
                for name,path in paths:
                    if not path.exists():continue
                    x=npz(path)['samples'];rows.append(dict(case=case,method=name,**metrics(x,q['samples'],cfg['evaluation'])))
                    coverage.extend(dict(case=case,**v) for v in allocation(t,x,q['samples'],cfg,name))
        csvfile(args.out/'exploratory_metrics.csv',rows);csvfile(args.out/'exploratory_coverage.csv',coverage)
if __name__=='__main__':main()
