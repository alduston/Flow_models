"""Offline probability-allocation and OU score audits. No data flow to samplers."""
import time
import numpy as np
import jax
import jax.numpy as jnp
from scipy.special import logsumexp
from vendor.lfgi import score_batch
from common import log


def allocation(target, samples, reference, cfg, method):
    """Full-history constraint fit, fixed physical regions, conditional predictions."""
    out = []; d = target.data
    residual = target.residuals(samples); rr = target.residuals(reference)
    stat = np.sum(residual**2,axis=1); rs = np.sum(rr**2,axis=1)
    limit = cfg['diagnostics']['constraint_sigma']**2*len(d['design'])
    out.append(dict(method=method,diagnostic='measurement_fit',region='all',probability=float(np.mean(stat<=limit)),
        reference_probability=float(np.mean(rs<=limit)),mean=float(stat.mean()),reference_mean=float(rs.mean()),
        quantity='noise-whitened residual squared; fit alone does not establish correct weighting'))
    if not target.case.startswith('tdoa'): return out
    p = target.parameters(samples); pr = target.parameters(reference)
    q = target.qois(samples); qr = target.qois(reference)
    edges = [-np.inf,*cfg['diagnostics']['coverage_height_edges_m'],np.inf]
    regions = [(f'{lo:g}<height<={hi:g}', (p[:,1]>lo)&(p[:,1]<=hi), (pr[:,1]>lo)&(pr[:,1]<=hi)) for lo,hi in zip(edges[:-1],edges[1:])]
    regions += [('lower_arm_height<=0',p[:,1]<=0,pr[:,1]<=0),('upper_arm_height>0',p[:,1]>0,pr[:,1]>0)]
    for label, ix, ir in regions:
        prob, rp = ix.mean(),ir.mean()
        out.append(dict(method=method,diagnostic='region_mass',region=label,probability=float(prob),reference_probability=float(rp),
            absolute_probability_error=float(abs(prob-rp)),retained_states=int(ix.sum()),reference_states=int(ir.sum())))
        for j,name in enumerate(target.qoi_labels):
            out.append(dict(method=method,diagnostic='conditional_QoI',region=label,quantity=name,probability=float(prob),reference_probability=float(rp),
                mean=float(q[ix,j].mean()) if ix.any() else None,reference_mean=float(qr[ir,j].mean()) if ir.any() else None))
    return out


def ou_score(queries, t, points, logweights):
    """Independent quadrature of the OU-smoothed target score; stable at tiny density."""
    a=np.exp(-t);g=-np.expm1(-2*t);out=[]
    for y in queries:
        logw=logweights-np.sum((y-a*points)**2,axis=1)/(2*g)
        w=np.exp(logw-logsumexp(logw));mean=w@points
        out.append((a*mean-y)/g)
    return np.asarray(out)


def bank_score_audit(target, banks, reference, quad, cfg):
    started=time.monotonic(); rows=[];summary=[];H_requests=0
    if not banks: return rows,summary,{'elapsed_seconds':0.,'diagnostic_hessian_requests':0}
    dc=cfg['diagnostics'];nq=dc['score_queries'];rng=np.random.default_rng(92013)
    score_cache={}
    firstbanks={law:b['x'] for law,r,b in banks if r==1}
    for name,round_,bank in banks:
        log(f'{target.case}: offline OU score audit {name}, bank {round_}')
        x,s,H=bank['x'],bank['s'],bank['H'];cap=dc['max_audit_bank']
        # If capped, this is explicitly a subset diagnostic, never the production field.
        ix=np.linspace(0,len(x)-1,min(cap,len(x)),dtype=int);x,s,H=x[ix],s[ix],H[ix]
        exact=np.asarray(jax.jit(jax.vmap(target.hessian))(jnp.asarray(x))) if dc['exact_bank_control'] else None
        H_requests+=len(x) if exact is not None else 0
        first=firstbanks[name]
        seedpoints={'entry_law':first[np.linspace(0,len(first)-1,nq,dtype=int)],
                    'posterior':reference[np.linspace(0,len(reference)-1,nq,dtype=int)]}
        for t in dc['score_times']:
            a=np.exp(-t);g=-np.expm1(-2*t)
            for querylaw,points in seedpoints.items():
                # Seeded identically for every bank: compare fields at identical queries.
                noise=np.random.default_rng(40011+int(t*1e6)+(0 if querylaw=='entry_law' else 1)).normal(size=points.shape)
                y=a*points+np.sqrt(g)*noise
                cachekey=(name if querylaw=='entry_law' else 'shared_posterior',querylaw,t)
                if cachekey not in score_cache:
                    score_cache[cachekey]=(ou_score(y,t,quad['score_points'],quad['score_logweights']),
                        ou_score(y,t,quad['coarse_score_points'],quad['coarse_score_logweights']))
                true,coarse=score_cache[cachekey]
                denom=max(1e-14,np.linalg.norm(true));griderr=float(np.linalg.norm(coarse-true)/denom)
                predicted,stats=score_batch(jnp.asarray(y),t,jnp.asarray(x),jnp.asarray(s),jnp.asarray(H),cfg['gad']['gate_min_eval'],cfg['gad']['gate_max_gain'])
                pred=np.asarray(predicted);ex_pred=None
                if exact is not None:
                    ex_pred=np.asarray(score_batch(jnp.asarray(y),t,jnp.asarray(x),jnp.asarray(s),jnp.asarray(exact),cfg['gad']['gate_min_eval'],cfg['gad']['gate_max_gain'])[0])
                for j,z in enumerate(y):
                    lw=-np.sum((z-a*x)**2,axis=1)/(2*g);w=np.exp(lw-logsumexp(lw))
                    h=np.einsum('n,nij->ij',w,H);ev,V=np.linalg.eigh(h)
                    den=np.maximum(a*a+g*ev,max(cfg['gad']['gate_min_eval'],a*a/cfg['gad']['gate_max_gain']))
                    cond_error=None
                    if exact is not None:
                        residual=np.einsum('n,nij->ij',w,exact-H);scale=(V/np.sqrt(den))@V.T
                        cond_error=float(np.linalg.norm(g*scale@residual@scale,2))
                    err=pred[j]-true[j]
                    rows.append(dict(initial_law=name,round=round_,query_law=querylaw,time=t,query=j,
                        score_error_norm=float(np.linalg.norm(err)),true_score_norm=float(np.linalg.norm(true[j])),
                        normal_score_error=float(abs(err@V[:,-1])),tangent_score_error=float(abs(err@V[:,0])),
                        conditional_ess=float(1/np.sum(w*w)),conditional_solve_scaled_residual_norm=cond_error,
                        exact_bank_score_error_norm=float(np.linalg.norm(ex_pred[j]-true[j])) if ex_pred is not None else None,
                        grid_relative_error=griderr,grid_resolved=griderr<=dc['max_score_grid_relative_error'],
                        audit_bank_size=len(x),production_bank_size=len(bank['x'])))
                summary.append(dict(initial_law=name,round=round_,query_law=querylaw,time=t,
                    GN_relative_score_RMSE=float(np.linalg.norm(pred-true)/denom),
                    exact_bank_relative_score_RMSE=float(np.linalg.norm(ex_pred-true)/denom) if ex_pred is not None else None,
                    grid_relative_error=griderr,grid_resolved=griderr<=dc['max_score_grid_relative_error'],
                    mean_conditional_ess=float(np.asarray(stats)[4]/np.asarray(stats)[6]),
                    role='offline diagnostic; exact-Hessian success is not a gate for GN-GAD'))
    return rows,summary,dict(elapsed_seconds=time.monotonic()-started,diagnostic_hessian_requests=H_requests,
        role='excluded from comparator budgets; fields only, no exact-Hessian sampling run; no reference initialization')
