#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source slurm/environment.sh
python submit_vista.py \
  --batch "${G2_BATCH:-../batches/gad_phase2_GN_array_wide_seed42_v2}" \
  --case "${G2_CASE:-tdoa_array_wide}" --account "${G2_ACCOUNT:-DMS22021}" "$@"
