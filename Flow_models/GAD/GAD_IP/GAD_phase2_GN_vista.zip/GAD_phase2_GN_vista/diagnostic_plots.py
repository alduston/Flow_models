"""Publication-friendly common-bin joint plots and GN entry diagnostics."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm


def extra_figures(target,cfg,ref,methods,allocation_rows,score_summary,finish,csvfile,tables):
    R=cfg['gad']['rounds'];bounds=np.quantile(ref,[.0005,.9995],axis=0)
    pad=.08*np.maximum(bounds[1]-bounds[0],.01);limits=[(bounds[0,j]-pad[j],bounds[1,j]+pad[j]) for j in range(2)]
    bins=[np.linspace(lo,hi,65) for lo,hi in limits];outside=[]
    for law in cfg['initializations']:
        names=['NUTS','Laplace',f'GAD-{law}-1',f'GAD-{law}-{R}',f'pMALA-{law}-work{R}',f'pMALA-{law}-time{R}']
        clouds={'NUTS':ref,**methods};hist=[]
        for name in names:
            if name not in clouds:hist.append(None);continue
            x=clouds[name];h,_,_=np.histogram2d(x[:,0],x[:,1],bins=bins)
            h=h/len(x)/np.diff(bins[0])[0]/np.diff(bins[1])[0];hist.append(h)
            inside=(x[:,0]>=bins[0][0])&(x[:,0]<=bins[0][-1])&(x[:,1]>=bins[1][0])&(x[:,1]<=bins[1][-1])
            outside.append(dict(initial_law=law,method=name,probability_outside_display=float(1-inside.mean()),display_coordinates=target.coordinate_label,
                x_min=bins[0][0],x_max=bins[0][-1],y_min=bins[1][0],y_max=bins[1][-1]))
        vmax=max((np.max(h) for h in hist if h is not None),default=1.)
        fig,axes=plt.subplots(2,3,figsize=(11,7))
        for ax,name,h in zip(axes.flat,names,hist):
            if h is None:ax.text(.5,.5,'No sampler output',ha='center',transform=ax.transAxes)
            else:
                ax.pcolormesh(bins[0],bins[1],h.T,cmap='magma_r',norm=LogNorm(vmin=max(vmax/300,1e-6),vmax=vmax),rasterized=True)
                outside_row=next(r for r in outside if r['initial_law']==law and r['method']==name)
                ax.text(.02,.97,f"outside: {100*outside_row['probability_outside_display']:.1f}%",va='top',fontsize=7,transform=ax.transAxes)
            ax.set(xlim=limits[0],ylim=limits[1],xlabel=target.coordinate_label+' 1',ylabel=target.coordinate_label+' 2',title=name)
        finish(fig,'joint_histograms_'+law)
    csvfile(tables/'histogram_display_coverage.csv',outside)
    if target.case.startswith('tdoa'):
        fig,axes=plt.subplots(1,3,figsize=(11,4.4))
        refarm=next(r['reference_probability'] for r in allocation_rows if r['diagnostic']=='region_mass' and r['region']=='lower_arm_height<=0')
        for law in cfg['initializations']:
            for prefix,style in [(f'GAD-{law}-','-'),(f'pMALA-{law}-work','--')]:
                rr=[r for r in allocation_rows if r['method'].startswith(prefix) and r['diagnostic']=='region_mass' and r['region']=='lower_arm_height<=0']
                axes[0].plot([int(r['method'].removeprefix(prefix)) for r in rr],[r['probability'] for r in rr],'o'+style,label=prefix.rstrip('-'))
                fit=[r for r in allocation_rows if r['method'].startswith(prefix) and r['diagnostic']=='measurement_fit']
                axes[1].plot([int(r['method'].removeprefix(prefix)) for r in fit],[r['probability'] for r in fit],'o'+style,label=prefix.rstrip('-'))
            final=f'GAD-{law}-{R}'
            rr=[r for r in allocation_rows if r['method']==final and r['diagnostic']=='region_mass' and r['region'] not in ['lower_arm_height<=0','upper_arm_height>0']]
            axes[2].plot(range(len(rr)),[r['probability']-r['reference_probability'] for r in rr],'o-',label=law)
        axes[0].axhline(refarm,c='black',ls=':',label='reference')
        rf=next(r['probability'] for r in allocation_rows if r['method']=='NUTS' and r['diagnostic']=='measurement_fit')
        axes[1].axhline(rf,c='black',ls=':');axes[2].axhline(0,c='black',ls=':')
        axes[0].set(xlabel='round / matched work checkpoint',ylabel='P(source height <= 0)',title='Arm weighting')
        axes[1].set(xlabel='round / matched work checkpoint',ylabel='P(residual RMS <= 3 sigma)',title='Measurement fit')
        axes[2].set(xlabel='fixed physical height bin',ylabel='probability - reference',title='Final GN-GAD allocation error')
        axes[0].legend(fontsize=6);axes[2].legend(fontsize=7);finish(fig,'coverage_and_constraint_fit')
    if score_summary:
        fig,axes=plt.subplots(1,2,figsize=(10.5,4.6))
        for ax,qlaw in zip(axes,['entry_law','posterior']):
            for law in cfg['initializations']:
                for round_ in [1,R]:
                    rr=[r for r in score_summary if r['initial_law']==law and r['round']==round_ and r['query_law']==qlaw]
                    if not rr:continue
                    ax.plot([r['time'] for r in rr],[r['GN_relative_score_RMSE'] for r in rr],'o-',label=f'{law}, bank {round_}')
                    invalid=[r for r in rr if not r['grid_resolved']]
                    ax.scatter([r['time'] for r in invalid],[r['GN_relative_score_RMSE'] for r in invalid],marker='x',c='red',s=70)
            ax.set(xscale='log',yscale='log',xlabel='OU time',ylabel='relative score RMS error',title=qlaw+' queries')
            ax.legend(fontsize=6)
        finish(fig,'GN_score_entry_and_late_bank')
