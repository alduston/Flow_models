#!/usr/bin/env python3
"""Freeze a new source/config snapshot and submit ONE Vista GH job.

--case all runs the two families plus logistic control sequentially in that job.
No watcher, arrays, deletion of old jobs, or dependency on earlier campaign ZIPs.
"""
import argparse
import json
from pathlib import Path
import shlex
import shutil
import subprocess
from common import ROOT, read, sha, write

def inputs():
    paths=[]
    for p in ROOT.rglob('*'):
        if p.is_file() and not any(x in p.relative_to(ROOT).parts for x in ['__pycache__','validation','runs']):
            if p.suffix in ['.py','.json','.sh','.md','.txt']: paths.append(p)
    return sorted(paths)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--batch',type=Path,required=True)
    ap.add_argument('--case',choices=['tdoa','tdoa_soft','tdoa_wide','tdoa_gentle','tdoa_control','tdoa_control_wide','logistic_clustered','logistic_dispersed','tdoa_array_centered','tdoa_array_wide','tdoa_coarse','tdoa_array_control','binding','panel','exploratory','all'],default='tdoa_array_wide')
    ap.add_argument('--account',default='DMS22021');ap.add_argument('--time',default='06:00:00')
    ap.add_argument('--profile',choices=['standard','highbank'],default='standard')
    ap.add_argument('--stage',choices=['screen','compare'],default='compare')
    ap.add_argument('--seed',type=int,default=42)
    ap.add_argument('--initialization',choices=['both','mixed','laplace','prior'],default='both')
    ap.add_argument('--resume',action='store_true');ap.add_argument('--dry-run',action='store_true')
    args=ap.parse_args();batch=args.batch.resolve()
    selected=['tdoa','tdoa_soft','tdoa_wide','tdoa_gentle','tdoa_control_wide','logistic_clustered','logistic_dispersed'] if args.case in ['panel','all'] else [args.case]
    if args.case=='exploratory':selected=['tdoa_array_centered','tdoa_array_wide','tdoa_coarse','tdoa_array_control']
    if args.case=='all':selected+=['tdoa_array_centered','tdoa_array_wide','tdoa_coarse','tdoa_array_control']
    hashes={str(p.relative_to(ROOT)):sha(p) for p in inputs()}
    if batch.exists() and (batch/'batch.json').exists():
        old=read(batch/'batch.json')
        if not args.resume: raise SystemExit('Batch exists; add --resume for this exact source/config, or choose a new batch.')
        if old['input_hashes']!=hashes or old['cases']!=selected or old.get('stage')!=args.stage or old.get('seed')!=args.seed or old.get('initialization')!=args.initialization or old.get('profile')!=args.profile: raise SystemExit('Batch/source/config/cases changed. Use a NEW batch directory.')
        # Refuse duplicate live submissions; never cancel any unrelated job.
        if old.get('job_id'):
            q=subprocess.run(['squeue','-h','-j',old['job_id'],'-o','%T'],capture_output=True,text=True,check=True)
            if q.stdout.strip(): raise SystemExit('Existing batch job is still live: '+q.stdout.strip())
    cmd=['sbatch','--parsable','--account',args.account,'--partition','gh','--nodes','1','--ntasks','1','--cpus-per-task','8',
         '--time',args.time,'--job-name','g2_'+args.case,'--output',str(batch/'slurm-%j.log'),str(batch/'code/slurm/job.sh'),str(batch),args.stage,str(args.seed),args.initialization,args.profile,*selected]
    if args.dry_run:
        print('One GH node; cases run sequentially. No files changed; no job submitted.')
        print(shlex.join(cmd));return
    batch.mkdir(parents=True,exist_ok=True);code=batch/'code'
    if not code.exists():
        for p in inputs():
            dest=code/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    for rel,expected in hashes.items():
        if sha(code/rel)!=expected: raise SystemExit('Frozen source checksum mismatch: '+rel)
    record={'schema':1,'cases':selected,'input_hashes':hashes,'account':args.account,'time':args.time,'job_id':None,'stage':args.stage,'seed':args.seed,'initialization':args.initialization,'profile':args.profile}
    write(batch/'batch.json',record)
    answer=subprocess.check_output(cmd,text=True).strip();job_id=answer.split(';')[0]
    record['job_id']=job_id;write(batch/'batch.json',record)
    print('Submitted',job_id,'; batch',batch)
    print('Monitor: tail -n 30 '+shlex.quote(str(batch/('slurm-'+job_id+'.log'))))

if __name__=='__main__':main()
