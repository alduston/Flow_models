#!/usr/bin/env bash
# Scheduler resources are supplied explicitly by submit_vista.py.
set -euo pipefail
G2_BATCH="${1:?batch directory}"
shift
G2_STAGE="${1:?stage}"; G2_SEED="${2:?seed}"; G2_INIT="${3:?initialization}"; G2_PROFILE="${4:?profile}"
shift 4
G2_FLAGS=()
G2_CONFIG=config.json
if [[ "$G2_PROFILE" == highbank ]]; then G2_CONFIG=profiles/highbank.json; fi
if [[ "$G2_STAGE" == screen ]]; then G2_FLAGS+=(--screen-only); fi
cd "$G2_BATCH/code"
source slurm/environment.sh
python -u run.py preflight --out "$G2_BATCH/preflight"
for G2_CASE in "$@"; do
  python -u run.py run --case "$G2_CASE" --out "$G2_BATCH/$G2_CASE" --config "$G2_CONFIG" --seed "$G2_SEED" --initialization "$G2_INIT" "${G2_FLAGS[@]}"
  python -u run.py export --case "$G2_CASE" --out "$G2_BATCH/$G2_CASE"
done

python -u compare_designs.py --batch "$G2_BATCH"
