# SLIPS revision validation

Validation date: 2026-10-28. These are implementation checks, not posterior accuracy results.

- The full pre-existing and new suite passed: 43 tests. A subsequent added combined-evaluation regression and the other seven SLIPS tests also passed, giving 44 distinct passing tests. The final conservative-reuse edits were checked with all 12 incremental workflow tests.
- Actual CPU smoke runs completed on all three unchanged PDE models through `slips_comparison.execute`: Allen–Cahn `[64,32]`, Navier–Stokes `[64,36]`, Helmholtz `[64,32]`. Each returned 64 finite samples at exactly 192 derivative-proxy units. Exact prepared-target binding, canonical state/reconstruction/KSD/KL/predictive evaluation, completed-stage caching and resumption after an interrupted evaluation passed. These deliberately tiny clouds are not accuracy benchmarks or NUTS references.
- Instrumented posterior callbacks matched every phase ledger and allocated work exactly, over 64, 200, 1,000, 1,500 and 2,000 particles and budgets corresponding to rounds 1–5. All actual counts stayed at or below the GAD cap. Deliberately rejected stiff-target proposals were still charged.
- Conditional gradients matched finite differences. A larger-work analytic Gaussian calibration reproduced the known mean and covariance within the predeclared Monte Carlo tolerance. Fixed-seed replay returned byte-identical sample arrays and RNG state.
- A synthetic multi-repeat fixture exercised all figure families, SLIPS curves/panels, paired GAD–SLIPS comparisons, MMD, and the SLIPS diagnostics panel. Reconstruction, predictive and work-curve PNGs were also visually inspected. These synthetic figures are not distributed as scientific results.
- The combined-reference evaluator wrote all six GAD/MALA/SLIPS methods at two budgets, including fields, posterior SD, predictive summaries and CSV output.
- A full three-problem/five-seed offline Slurm plan contained 15 separate SLIPS jobs. Each waits for its canonical run and preparation; each evaluation depends on SLIPS. The existing live-donor/capped-submission/retry/target-repair/fixed-mass tests passed.
- Preview reference reuse passed across plotting/SLIPS edits and rejected changed numerical reference source. The previous full-source-manifest restriction was narrowed to actual NUTS dependencies and transition ASTs. Model directories are excluded without accidentally dropping `model_derivative_check.json`.
- The notebook passes nbformat validation; every code cell compiles. Its embedded gzip runner is identical to the bundled standalone runner. Its command retains four rounds and 200 NS/Allen–Cahn particles, sets Helmholtz to 1,500, and retains the original NUTS preview/time-limit settings.
- The original sampler, PDE model, MALA checkpoint, NUTS reference and target-snapshot sources are unchanged. The existing source-provenance tests passed.

Local validation used CPU JAX 0.12.0.1, NumPyro 0.22.0, PyTorch 2.5.1+cpu, ArviZ 0.23.4 and NumPy 2.3.5 in an isolated QA environment. CUDA, Kaggle T4 ×2 and Vista execution were not available here. No cluster jobs were submitted. The notebook retains its GPU/environment preflight and the shortened-NUTS certification safeguards.

The default SLIPS output is the documented terminal-conditional cloud variant. Its phase ledger is exact for the stated proxy, but that proxy is not a FLOP model; the method still has finite-inner-chain and outer-grid bias, and within-path sample dependence. See `SLIPS_COMPARISON.md` before interpreting posterior uncertainty plots or reporting this baseline.

Reproduce the automated checks:

```bash
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 JAX_ENABLE_X64=true \
  python -m unittest discover -s tests -p 'test_*.py'
```

With the normal numerical dependencies installed, run each tiny PDE bridge smoke in a fresh directory:

```bash
JAX_PLATFORMS=cpu JAX_ENABLE_X64=true OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 \
  python tests/smoke_slips_pde.py --problem allen_cahn --output /tmp/gad_slips_qa_ac
```

Repeat with `navier_stokes` and `helmholtz` and distinct output paths. The smoke utility explicitly uses QA-only prepared geometry and does not run or certify NUTS.
