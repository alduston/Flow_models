# GAD / MALA / SLIPS inverse-problem comparison

This revision adds SLIPS to the full Vista workflow and to the four-round Kaggle preview. The active problems remain Navier–Stokes, Allen–Cahn and Helmholtz. **The Kaggle Helmholtz preview now uses 1,500 particles and a 1,500-particle GAD bank** (up from 300). The full cluster sweep retains its existing larger 2,000-particle Helmholtz setting, five rounds, 1,000 particles on NS/Allen–Cahn and five initial sampler seeds. The preview retains four rounds and 200 particles on NS/Allen–Cahn. Target/PDE definitions, original GAD/MALA algorithms and NUTS certification criteria are unchanged.

## Compute matching

The existing derivative-count convention is the primary cost measure, **not runtime**:

| Operation | Proxy units |
| --- | ---: |
| GAD GN reference-bank particle, per round | 3 |
| Exact posterior value and gradient for one SLIPS/MALA state | 2 |
| Gaussian localization log density and gradient added analytically | 0 additional PDE units |
| Target Hessian or GN matrix used by SLIPS | None |

For GAD round `r`, the SLIPS cap is `3 * bank * r`. SLIPS counts its initial exact target cache and **every proposed state**, including rejections, initialization denoising, localization denoising, terminal burn-in, terminal sampling and any discarded output padding. A cached value/gradient at the unchanged current state is reused when only the analytic localization conditional changes. All calls use the same exact nonlinear posterior bridge as MALA. No GAD cloud, generating truth, MAP, NUTS draw or NUTS covariance initializes SLIPS.

This is the original proxy, not an assertion that a GN evaluation and an adjoint gradient have identical FLOPs. Common target-validation/setup work and downstream metric/predictive evaluation are outside the sampler budgets, as in the original comparison. Timings remain supplementary diagnostics. `run_info.json` records separate likelihood, gradient and GN counts; its phase ledger is in exact particle-wise value/gradient callback rows. The run fails if the measured count differs from its plan or exceeds the cap.

Each `SLIPS-r` is a **fresh independently seeded run** at the cumulative GAD-r budget. This avoids giving a higher-budget run any uncharged initialization from a previous experiment. The sum of all separate budget experiments is recorded in `slips/experiment_config.json`; it is not presented as one cumulative trajectory. MALA retains its original cumulative checkpoints. For five budgets, the total SLIPS sweep costs about three times its final-budget run, before rounding.

## SLIPS algorithm and finite-cloud design

`slips_core.py` implements classical stochastic localization, `Y_t = t X + W_t`, with a geometric SNR/time grid and exact Gaussian conditional terms:

```
q_t(x | y) proportional to pi(x) exp(-t ||x-y/t||^2 / 2)
grad log q_t(x | y) = grad log pi(x) + y - t x
Y_next = Y + (t_next-t) * E_q[X] + sqrt(t_next-t) * normal
```

The denoiser is estimated by warm-started inner MALA. Initialization uses four Langevin-within-MALA refinements of the observation law, with step `0.05*t_start`. Defaults: 16 outer intervals, `t_start=0.001`, `t_end=1000`, requested isotropic MALA step `1e-4`, and at most 32 localization paths. Score/secant guards and acceptance adaptation stabilize the inner steps; terminal production freezes its step. This is an independent NumPy driver through the existing JAX/PyTorch exact-PDE bridge, with no new sampling dependency.

**The default output is a terminal-conditional SLIPS variant.** A full independent localization trajectory per output particle cannot fit these small derivative budgets. Instead, it runs as many localization paths as the cap permits (up to 32), then produces the requested `P` samples by MALA from their terminal `q_T(.|Y_T)`, pooling paths and truncating only the recorded padding. In the ideal limit of exact observation-law and conditional sampling, the mixture identity `integral q_T(dx|y) p_T(dy) = pi(dx)` gives the target, without the finite-noise variance loss of returning a denoiser mean. Finite inner sampling and outer integration introduce approximation error.

**P outputs do not mean P independent localization paths.** Conditional draws sharing a path are dependent, and terminal conditional mixing does not repair a missed mode in the localization path distribution. With small preview budgets this limitation can dominate the SD/covariance maps. Saved `path_id`, `samples_by_draw_path`, the terminal observation, unique fraction, acceptance and path-count panels make this visible. This design differs from the official implementation's terminal denoiser-mean output; it must be described as the terminal-conditional SLIPS variant in a paper, not silently identified with independently repeated canonical SLIPS. This is a preliminary fixed-setting implementation, not a tuned claim about optimal SLIPS performance.

At the 1,500-particle Kaggle Helmholtz setting, the actual work is:

| Budget / GAD round | GAD cap | SLIPS actual | Localization paths | Output draws |
| --- | ---: | ---: | ---: | ---: |
| 1 | 4,500 | 4,480 | 32 | 1,500 |
| 2 | 9,000 | 8,960 | 32 | 1,500 |
| 3 | 13,500 | 13,440 | 32 | 1,500 |
| 4 | 18,000 | 17,984 | 32 | 1,500 |
| 5, optional extension | 22,500 | 22,464 | 32 | 1,500 |

The full 2,000-particle cluster Helmholtz run has caps 6,000 through 30,000; the fifth SLIPS budget uses 29,952 units. For the 200-particle preview the early budgets support fewer paths; `allocate()` records the actual counts for every run. No automatic work overrun is allowed.

Source basis: [SLIPS paper](https://arxiv.org/abs/2402.10758), [official repository](https://github.com/h2o64/slips), inspected commit `b21288b577f4046d52b2264fc638f681dee69ac1`. The conditional law, Langevin initialization and classical MC-observable outer update were checked against `sto_loc.py`, `mcmc.py` and `integrators.py`. Their source identities are recorded in `provenance/slips_source_identity.json`. Upstream source is not copied into this distribution.

## Full Vista submission and reuse

Extract this ZIP and create a **new batch**, because existing cluster campaigns have frozen source snapshots. Nothing in this bundle cancels or edits the already-submitted campaigns. For example, from the new bundle directory:

```bash
source slurm/environment.sh
GP_SLIPS_BATCH=../batches/gad_ip_slips_20261028
GP_SLIPS_LOG=../gad_ip_slips_20261028_submit.log
nohup bash submit.sh --batch "$GP_SLIPS_BATCH" \
  --reuse-from ../batches/gad_ip_fixed_mass_20261027 \
  --repeats 5 --watch >> "$GP_SLIPS_LOG" 2>&1 < /dev/null &
echo "$!" > "$GP_SLIPS_LOG.pid"
hostname > "$GP_SLIPS_LOG.host"
disown
```

The planner can reuse compatible prepared targets, MAPs and NUTS chains/references, plus canonical GAD/MALA repeats at unchanged particle/settings/source identities. Compatible live donor GAD/MALA jobs are still recognized. The cluster particle counts remain unchanged, so all compatible canonical repeats can be reused. The Kaggle Helmholtz increase from 300 to 1,500 requires new preview GAD/MALA clouds; it does not change the target or NUTS chain. Particle-dependent preview floor summaries and all new comparisons are rebuilt. Completed compatible SLIPS stages can be reused independently.

There is one new **SLIPS job per problem/seed**, dependent on preparation and its canonical GAD/MALA run (to prevent output-directory retries/adoption from racing). It can run alongside NUTS. Evaluation waits for all baselines and the reference. Existing task caps, watcher behavior, retry rules and submission commands remain. `--time slips=01:00:00` overrides new SLIPS reservations. A fresh three-problem/five-seed campaign now has **65 tasks** and **196.33 reserved node-hours** before reuse (15 added SLIPS jobs at one hour each). These are reservations, not measured use.

Run `python workflow.py submit --batch /tmp/gad_slips_dry_run --dry-run --offline --max-outstanding-tasks 100` for a local submission plan; it does not contact Slurm. Scientific sampling still runs on allocated compute nodes.

SLIPS files live under `runs/<problem>/<problem>_seed<seed>/slips/`, leaving the canonical GAD/MALA files intact. Finished per-budget clouds and their hashes survive interruptions. An interrupted current budget restarts that budget; completed budgets are reused. A completed sample sweep whose metrics were interrupted reruns evaluation without resampling. Changed code, settings, target or output bytes invalidate the SLIPS identity. No partial SLIPS output is accepted as a complete publication comparison.

## Kaggle

Open `GAD_IP_Kaggle_SLIPS_preview.ipynb` and attach this updated ZIP. Its embedded runner is also supplied in `kaggle/run_gad_kaggle_preview.py`. The new batch is `/kaggle/working/gad_slips_preview_r4_n1500`. It can reuse compatible target/MAP/short-NUTS state from a stopped older preview, while maintaining the original uncertified-preview safeguards. Time limits bound the notebook job; **they do not set any baseline compute budget**. Increase time-limit flags if the larger Helmholtz run needs longer.

Every existing comparison family includes SLIPS: reconstruction/errors/posterior SD, physical state, PCA histograms, predictive intervals, metric-vs-round/work curves, runtime and multi-repeat variation. SLIPS-specific diagnostics show terminal acceptance, actual/cap work and path count. GAD's conditional bank ESS remains a GAD-only diagnostic; SLIPS acceptance is not mislabeled as ESS. NUTS-only diagnostic figures remain reference diagnostics. Cluster paired comparisons and tables include SLIPS. The raw clouds, phase ledgers, per-path arrays, source and plots enter the normal results package.

## Validation

See `SLIPS_VALIDATION.md` for the checks actually run. The local numerical and synthetic-figure tests are QA, not posterior benchmark results. No cluster job is submitted and no Kaggle result is claimed by this update.
