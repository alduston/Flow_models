"""SLIPS numerical, work-accounting and pipeline integration regression checks."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from slips_core import allocate,conditional,run
from common import (digest,field_summary,load_npz,read_json,run_directory,save_npz,
                    settings,write_json)
from slips_comparison import key,labels,merged_npz,valid


class WorkTests(unittest.TestCase):
    def test_all_requested_budgets_include_every_callback_row(self):
        for n in [64,200,1000,1500,2000]:
            for r in range(1,6):
                plan=allocate(n,3*n*r)
                counter=[0]
                def posterior(x):
                    counter[0]+=len(x)
                    return -.5*(x*x).sum(1),-x
                x,info,state=run(np.ones((plan['paths'],3)),posterior,plan,seed=42)
                self.assertEqual(x.shape,(n,3));self.assertTrue(np.isfinite(x).all())
                self.assertEqual(2*counter[0],info['pde_solve_count'])
                self.assertEqual(counter[0],sum(info['work_ledger'].values()))
                self.assertLessEqual(info['pde_solve_count'],3*n*r)
                self.assertEqual(len(state['path_id']),n)
                self.assertGreater(info['work_ledger']['initialization'],0)
                self.assertGreater(info['work_ledger']['terminal_sampling'],0)

    def test_rejected_proposals_are_charged_and_replay_is_exact(self):
        plan=allocate(200,2400)
        def stiff(x):return -.5e16*(x*x).sum(1),-1e16*x
        initial=np.ones((plan['paths'],2))
        a,ia,sa=run(initial,stiff,plan,seed=12)
        b,ib,sb=run(initial,stiff,plan,seed=12)
        np.testing.assert_array_equal(a,b)
        self.assertEqual(ia['work_ledger'],ib['work_ledger'])
        self.assertLess(sum(ia['acceptances'].values()),sum(ia['proposals'].values()))
        self.assertEqual(ia['pde_solve_count'],plan['actual_proxy'])
        self.assertEqual(str(sa['rng_state_json']),str(sb['rng_state_json']))

    def test_conditional_score_matches_finite_differences(self):
        rng=np.random.default_rng(2);x=rng.normal(size=(7,3));y=rng.normal(size=x.shape)
        precision=np.array([2.,3.,5.]);t=4.;eps=1e-6
        def logp(z):return -.5*np.sum(z*z*precision,axis=1)
        value,score=conditional(logp(x),-x*precision,x,y,t)
        for j in range(3):
            d=np.zeros_like(x);d[:,j]=eps
            plus=conditional(logp(x+d),-(x+d)*precision,x+d,y,t)[0]
            minus=conditional(logp(x-d),-(x-d)*precision,x-d,y,t)[0]
            np.testing.assert_allclose((plus-minus)/(2*eps),score[:,j],rtol=1e-7,atol=1e-7)

    def test_gaussian_posterior_moments_with_adequate_work(self):
        # This is a numerical calibration, not a claim about the small PDE budgets.
        cfg=dict(max_paths=2048,outer_steps=100,init_steps=10,dt=.05,t_end=10.)
        plan=allocate(2048,3_000_000,cfg)
        def posterior(x):return -.5*np.sum(x*x*2,axis=1),-2*x
        x,info,state=run(np.random.default_rng(4).normal(size=(plan['paths'],2)),posterior,plan,cfg,seed=44)
        self.assertLess(float(abs(x.mean(0)).max()),.09)
        np.testing.assert_allclose(np.var(x,axis=0),.5,atol=.09)


class PipelineTests(unittest.TestCase):
    def test_combined_reference_evaluation_writes_all_methods_and_csv(self):
        from fixtures import synthetic_batch
        from types import SimpleNamespace
        import jax.numpy as jnp
        import comparison
        import slips_comparison
        with tempfile.TemporaryDirectory() as tmp:
            batch=synthetic_batch(tmp,rounds=2);cfg=settings(batch)
            cfg['slips']['enabled']=True;write_json(batch/'settings.json',cfg)
            d=run_directory(batch,'afwi',42);out=d/'slips';out.mkdir()
            raw=load_npz(d/'samples_all_rounds.npz');rows=read_json(d/'metrics.json')
            save_npz(out/'samples_all_rounds.npz',**{f'SLIPS-{r}':raw[f'MALA-{r}'] for r in [1,2]})
            write_json(out/'metrics.json',{f'SLIPS-{r}':rows[f'MALA-{r}'] for r in [1,2]})
            model=SimpleNamespace(solve_forward_holdout=lambda a:jnp.tile(a,2),
                y_holdout_obs_np=np.zeros(12),y_holdout_clean_np=np.ones(12)*.01,NOISE_STD=.01)
            old_load,old_check,old_valid=comparison.load_model,comparison.check_target,slips_comparison.valid
            comparison.load_model=lambda *args:model
            comparison.check_target=lambda *args:None
            slips_comparison.valid=lambda *args:True
            try:result=comparison.evaluate_repeat(batch,'afwi',42)
            finally:
                comparison.load_model,comparison.check_target,slips_comparison.valid=old_load,old_check,old_valid
            self.assertEqual(result['methods'],6)
            self.assertEqual(set(read_json(d/'publication_metrics.json')),labels(cfg,'afwi'))
            self.assertIn('SLIPS-2__std',load_npz(d/'publication_fields.npz'))
            self.assertIn('SLIPS-2__mean',load_npz(d/'publication_predictives.npz'))
            self.assertIn('SLIPS-2',(d/'publication_metrics.csv').read_text())

    def test_changed_slips_code_or_settings_do_not_change_base_run_key(self):
        from cache import run_key
        c=read_json(ROOT/'settings.json');new=copy.deepcopy(c);new['slips']['outer_steps']+=1
        self.assertEqual(run_key(c,'allen_cahn',42),run_key(new,'allen_cahn',42))
        self.assertNotEqual(key(c,'allen_cahn',42),key(new,'allen_cahn',42))
        self.assertIn('SLIPS-5',labels(c,'allen_cahn'))

    def test_slips_stage_is_separate_and_evaluation_waits_for_it(self):
        from workflow import freeze
        with tempfile.TemporaryDirectory() as tmp:
            batch=Path(tmp)/'batch'
            result=subprocess.run([sys.executable,str(ROOT/'workflow.py'),'submit','--batch',str(batch),
                '--dry-run','--offline','--max-outstanding-tasks','100'],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            plan=read_json(batch/'submission_plan.json')
            nodes={x['key']:x for x in plan['nodes']}
            self.assertEqual(len([k for k in nodes if '-slips-' in k]),15)
            commands={r['key']:r['command'] for r in plan['new_submissions']}
            for p in ['navier_stokes','allen_cahn','helmholtz']:
                for seed in range(42,47):
                    slips_id=nodes[f'{p}-slips-{seed}']['job_ids'][0]
                    slips_dep=next(x for x in commands[f'{p}-slips-{seed}'] if x.startswith('--dependency='))
                    self.assertIn(nodes[f'{p}-repeat-{seed}']['job_ids'][0],slips_dep)
                    dep=next(x for x in commands[f'{p}-evaluation-{seed}'] if x.startswith('--dependency='))
                    self.assertIn(slips_id,dep)

    def test_combined_summaries_and_every_comparison_figure_include_slips(self):
        from fixtures import synthetic_batch
        from aggregate_publication import summarize_rows,paired_rows
        import plotting
        with tempfile.TemporaryDirectory() as tmp:
            batch=synthetic_batch(tmp,rounds=2);cfg=settings(batch);cfg['slips']['enabled']=True
            cfg['sampler_seeds']=[42,43];cfg['aggregation']['png_dpi']=65
            write_json(batch/'settings.json',cfg)
            for seed in cfg['sampler_seeds']:
                d=run_directory(batch,'afwi',seed);out=d/'slips';out.mkdir()
                raw=load_npz(d/'samples_all_rounds.npz');state=load_npz(d/'state_summaries.npz')
                save_npz(out/'samples_all_rounds.npz',**{f'SLIPS-{r}':raw[f'MALA-{r}']+.002 for r in [1,2]})
                save_npz(out/'state_summaries.npz',**{f'SLIPS-{r}':state[f'MALA-{r}'] for r in [1,2]})
                fields=load_npz(d/'publication_fields.npz');pred=load_npz(d/'publication_predictives.npz');rows=read_json(d/'publication_metrics.json')
                for r in [1,2]:
                    for suffix in ['mean','std','q025','q975']:fields[f'SLIPS-{r}__{suffix}']=fields[f'MALA-{r}__{suffix}']
                    for suffix in ['mean','std']:pred[f'SLIPS-{r}__{suffix}']=pred[f'MALA-{r}__{suffix}']
                    rows[f'SLIPS-{r}']=dict(rows[f'MALA-{r}'],slips_paths=4,slips_to_gad_proxy_ratio=.98,slips_acceptance_rate=.8)
                save_npz(d/'publication_fields.npz',**fields);save_npz(d/'publication_predictives.npz',**pred)
                write_json(d/'publication_metrics.json',rows)
            rows=[]
            for seed in cfg['sampler_seeds']:
                rows += [dict(v,method=k,sampler_seed=seed) for k,v in read_json(run_directory(batch,'afwi',seed)/'publication_metrics.json').items()]
            summary=summarize_rows(rows,cfg,'afwi')
            self.assertTrue(any(r['baseline']=='SLIPS-2' and r['n']==2 for r in paired_rows(rows,cfg,'afwi')))
            names=[];original=plotting.finish
            def inspect(fig,name,out,dashboard,dpi,captions,caption):
                import matplotlib.pyplot as plt
                if name in ['field_reconstruction','physical_state','posterior_pca_1','heldout_predictive_intervals','sampler_repeat_variation']:
                    self.assertTrue(any(ax.get_title()=='SLIPS' for ax in fig.axes),name)
                    self.assertTrue(any(ax.get_title()=='MALA' for ax in fig.axes),name)
                    self.assertFalse(any(ax.get_title() in ['SLIPS-2','MALA-2'] for ax in fig.axes),name)
                    self.assertIn('all 2 GAD rounds',caption)
                if name in ['reconstruction_vs_round','posterior_error_vs_work','runtime_and_conditional_ess']:
                    self.assertTrue(any(line.get_label()=='SLIPS' for ax in fig.axes for line in ax.lines),name)
                names.append(name)
                original(fig,name,out,dashboard,dpi,captions,caption)
            plotting.finish=inspect
            try:
                count=plotting.problem_figures(batch,'afwi',cfg,summary,Path(tmp)/'figures',None)
                self.assertGreaterEqual(count,13)
                self.assertIn('slips_diagnostics',names)
            finally:plotting.finish=original

if __name__=='__main__':unittest.main()
