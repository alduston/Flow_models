> **SLIPS revision:** for new three-method campaigns use [SLIPS_COMPARISON.md](SLIPS_COMPARISON.md). This earlier campaign guide is retained for already-frozen batches; its historical particle counts/reservation totals may differ.

# Vista: replace NUTS work and retain the sampler sweep

New batches set `nuts.mass_mode` to `fixed`: identity mass in the existing MAP-Hessian-whitened coordinates, with step-size adaptation enabled. The exact nonlinear PDE posterior, four independent starts, 3,000 warmup / 5,000 retained draws, target acceptance 0.95, tree depths 10/12, certification thresholds, sampler settings and reservations are unchanged. This default applies to all selected problems. Allen–Cahn has the supplied Colab GPU performance evidence; other problems still require their own completed reference diagnostics.

Existing batch: `batches/gad_ip_followup_20261026_v2`.
Replacement batch: `batches/gad_ip_fixed_mass_20261027`.
The old batch's frozen source and settings are not edited.

## Surgical restart

Run on **login2.vista**, where the existing watcher was recorded. Copy `GAD_IP_publication_vista_fixed_mass_bundle.zip` into GAD_IP, then run:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP
unzip -qo GAD_IP_publication_vista_fixed_mass_bundle.zip
cd gad_ip_publication
bash restart_fixed_mass_vista.sh
```

The launcher loads the existing environment, stops the old watcher, queries live jobs from that batch's `jobs.json`, and cancels only NUTS chains, certification/summary, reference-based evaluations and aggregate reports. Pending or running GAD/MALA repeats and preparation/preflight jobs are retained. No job IDs are hard-coded. A host check prevents silently missing the watcher on another login host. Completed scientific output is not deleted.

It performs the first submission pass in the foreground and then starts a detached `nohup ... --watch` driver for the replacement batch. Wait for the printed detached watcher PID before closing the terminal. The replacement inherits the old selected repeat count (currently five per problem). If already initialized, it resumes its own existing selection. The 32-task cap counts retained old repeats and unrelated jobs too.

The planner copies authenticated prepared targets/MAPs and valid completed sampler runs. Compatible old live sampler jobs are reused as dependencies; their outputs are copied when complete. New evaluations wait for the new reference. The potential's AST and the original model/sampler hashes determine target/run compatibility, so a NUTS tuning or timing-log change no longer causes GAD/MALA recomputation. A changed potential still invalidates reuse.

Dense-adaptation reference chains/clouds and their checkpoints are not imported into this fixed-mass batch. Completed chain records and certified references also check the mass configuration. New checkpoint bindings include the mass setting through the frozen NUTS config. Cancelled old reference files remain available in the old batch for audit.

The cancellation helper can be previewed without stopping the watcher:

```bash
python cancel_reference_jobs.py \
  --batch ../batches/gad_ip_followup_20261026_v2 \
  --watcher-log ../gad_ip_followup_20261026_v2_submit.log
```

Add `--apply` only when performing the cancellation. The launcher supplies it as part of the authorized restart. The helper records its action in the old batch's logs. It does not stop watchers on other login hosts; run on the recorded host.

## Monitoring and later resume

```bash
tail -f /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/gad_ip_fixed_mass_20261027_submit.log
```

The first foreground pass also prints its plan. The detached watcher may immediately print a final `Batch:` / `Results:` and exit if all work is already submitted; queued compute jobs continue. Otherwise normal deferred-task messages mean it is polling for available slots or prerequisites. It does not replenish allocation balances. Stop viewing a log with Ctrl+C; this does not stop the watcher.

```bash
GP_BATCH=/work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP/batches/gad_ip_fixed_mass_20261027
python "$GP_BATCH/code/workflow.py" status --batch "$GP_BATCH"
squeue -u "$USER" -o "%.18i %.10P %.36j %.12T %.12M %R"
```

The launcher is safe to run again on the recorded host: it resumes the replacement batch, retains its live job IDs and replaces its local watcher. For custom paths, use `bash restart_fixed_mass_vista.sh OLD_BATCH NEW_BATCH`; set `GP_OLD_WATCHER_LOG` / `GP_NEW_DRIVER_LOG` when their log paths differ from the defaults. Keep the old batch until retained jobs finish and all needed sampler outputs have been adopted.

NUTS stdout now prints completed warmup elapsed time and each production chunk's elapsed time, seconds per draw and mean leapfrog steps. An incomplete warmup still has no partial checkpoint; production chunks remain resumable. No additional packages are required in the supplied working Vista environment.

To expand from the retained five-repeat selection to ten, use the existing detached resume recipe with `--resume-batch ../batches/gad_ip_fixed_mass_20261027 --repeats 10 --watch` once the initial aggregate job finishes; retain the host/PID/log tracking described in SUBMISSION_WATCHER.md.
