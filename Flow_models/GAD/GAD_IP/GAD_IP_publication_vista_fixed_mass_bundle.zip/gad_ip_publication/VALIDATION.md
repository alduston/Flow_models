# Validation — follow-up revision, 26 October 2026

No production Vista jobs were submitted from this authoring session. Tests validate implementation and reuse behavior; they do not establish long-reference mixing or Vista runtime.

## Fixed-mass reference update, 27 October 2026

- Default `nuts.mass_mode="fixed"` uses identity mass in the existing MAP-Hessian-whitened coordinates and retains step-size adaptation, exact posterior gradients, the original 3,000/5,000 transition counts and all certification thresholds. Modes `dense` and `diagonal` remain explicit options; a legacy config without the new field retains dense behavior.
- The supplied Allen–Cahn Colab benchmark completed 300 warmup transitions and 20 production transitions at 0.6796 seconds per production transition, mean 14.2 leapfrog steps, zero production divergences. This is performance evidence only; it is not long-chain convergence validation or a Vista runtime measurement. Other problems are not newly GPU-benchmarked here.
- New fixed-mode Gaussian NumPyro tests verify that interrupted chunked execution matches uninterrupted draws exactly and that changing mass configuration rejects the checkpoint. Completed chain records and certified references enforce the mass mode; old dense outputs cannot silently become fixed-mode references.
- Mocked Slurm tests exercise selective cancellation, idempotence, retaining old pending repeats, importing prepared target/MAP bytes and completed sampler outputs, and rebuilding references/evaluations without new sampler submissions. The launcher's first foreground submission and detached watcher are tested together. No real cluster job is cancelled or submitted during these tests.
- Target compatibility now hashes the potential function AST alongside the model source and data seed, separating unchanged posterior/sampler artifacts from NUTS driver tuning. Tests verify that a changed potential still invalidates reuse.
- Current suite: 34 publication, restart and migration tests pass on CPU with NumPyro 0.22.0 / ArviZ 0.23.4. The original model/sampling files, reference_core.py and Vista environment/scheduler reservation files remain byte-for-byte unchanged. Updated shell scripts and fenced shell examples pass Bash syntax checks.

## Prepared-target snapshot repair, 27 October 2026

- All four actual source models passed CPU checks with deliberately changed basis/observations/sensors and a wrong cached PDE/source constant. Rebinding restored the exact prepared fingerprint and forward/hold-out behavior, retained finite gradients, and preserved the saved target/MAP byte-for-byte. Wrong seeds, corrupt constant snapshots and unverifiable legacy wave-source geometry were rejected.
- New preparations capture source/PDE constants and truth/zero/prior-scale validation probes on the actual MAP model instance; older prepared targets can be upgraded after clean-data, physical-field and MAP-energy verification. Generic Darcy routines and strict production NUTS settings are unchanged.
- Four additional repair-tool tests cover pending-job holds/release, preserving existing manual holds, source-manifest update/idempotence, refusing running batches, rejecting altered frozen code, and rollback after commit failure. These use mocked scheduler calls; no remote jobs were modified.
- Frontera's NumPy-2/isolated-ArviZ support, Python-3.9 protocol backport, environment configuration, scheduler-cluster isolation and drained-queue handling are preserved from the attached Frontera ZIP. Both new loader/repair modules compile under the actual local Python 3.9 interpreter.
- Current verification: 28 publication/repair tests passed; all 32 original screening tests passed (60 total). The four migration tests also passed on the actual Python 3.9.25 interpreter; function recognition is normalized across Python 3.9/3.12 AST differences.
- A fresh reduced Allen-Cahn CPU pipeline completed preparation, two independent sampler seeds, four short NUTS chains, certification/reference summaries, both evaluations, all 14 figure families and the final verified results ZIP. The new preparation sidecars came from the actual MAP model. This used original model dimensions, 64 particles, two rounds, 30 warmup/80 draws and relaxed QA diagnostics only; production settings and reference thresholds were unchanged.
- The Colab GPU mismatch itself was not reproduced on CPU. The patch eliminates target regeneration from the worker target definition and records per-array differences instead of assuming which array drifted.


## Earlier persistent submission documentation update

The README, Vista guide and new reusable `SUBMISSION_WATCHER.md` make the detached `nohup ... --watch` workflow standard for initial submission, resume and later repeat expansion. Instructions include disconnected stdin, appended stdout/stderr logs, Bash disowning, host/PID recording, interpreting expected deferrals, stopping only the driver and explicit failed-job recovery. The user's Vista log confirmed healthy detached polling after initial submission (19 submitted, 31 deferred, then one cached and zero failures).

That earlier revision changed documentation only. Existing scientific settings, scheduler code, worker code and tests are byte-for-byte unchanged from the preceding delivered bundle. Shell examples were syntax-checked, internal documentation links verified, and the regenerated ZIP/manifest checked. Numerical tests were not rerun for this documentation-only change; the preceding 56-test results below remain the recorded implementation evidence. The current target-loader code repair instead requires the one-time frozen-batch migration described in TARGET_SNAPSHOT_FIX.md.

## Updated defaults and preserved code

- Active cases: Navier-Stokes and Allen-Cahn, 1,000 particles/bank and five rounds; Helmholtz, 2,000 and five rounds. FWI stays an explicit reserve. Initial selection is five independent sampler seeds on fixed data seed 42; ten seeds are registered for later expansion.
- Default limits: 12 hours per NUTS chain; one hour for preparation, a single sampler repeat, certification/summary, a single evaluation and aggregation; 20-minute preflight. The fresh initial plan contains 50 one-node tasks requesting 181.33 node-hours across the campaign, with no more than 32 outstanding user task slots by default.
- All 44 supplied screening files and supplied postprocess_seed.py remain byte-for-byte unchanged. The generic Darcy NUTS routines still match the supplied ASTs. Original strict reference thresholds and 3,000 warmup / 5,000 retained draws per chain are unchanged.
- Per-problem rounds flow through run settings, expected labels, tables, metrics and plots. Summary CSV includes fixed-round medians as well as means, SDs and confidence intervals.

## Earlier workflow tests

**24 publication-workflow tests + 32 original screening tests pass (56 total).**

New incremental tests use fake sbatch/squeue/sacct executables and cover:

- Default 12-hour/one-hour reservations, all-user task counting (including unrelated work), dependency wiring, wrapper chatter, paths containing spaces, cap/deferred behavior and watch refilling.
- Identical resume while jobs are live creates no duplicates; accepted IDs survive a mid-submission allocation rejection and subsequent recovery.
- A complete compatible source requires only a new report; once that report is complete, an identical resume submits nothing.
- A single missing seed submits just that repeat, its evaluation, preflight if required and the report; preparation/NUTS/other seeds remain cached.
- A three-problem campaign with only Helmholtz particles changed submits scientific work only for Helmholtz, retaining NS/Allen-Cahn runs and all compatible NUTS references.
- Five-to-ten expansion adds only seeds 47–51; legacy active four-chain arrays become dependencies rather than duplicate chain submissions.
- Failed jobs require explicit retry, retain attempt history and cannot be retried indefinitely by watch mode.
- Full raw screening import follows actual seed metadata over directory names, verifies realized data, rejects a different target, and truncates a longer trajectory only after matching canonical transport and MALA prefixes. Independent-MALA repairs are not adopted.

Existing numerical/identity tests also pass, including exact empirical Wasserstein, signed MMD, scale-aware predictive scores, nonlinear field transforms, paired bootstrap, mutation rejection, reference failure withdrawing canonical output, and actual NumPyro chunk restart matching uninterrupted draws exactly.

## Five-round report check

A clearly labelled synthetic QA fixture exercised five requested repeats, five GAD/MALA rounds, all 14 figure families, all three PCA pairs, numeric tables, the result ZIP and a 15-page dashboard. The PCA grid now expands to display NUTS, GAD-1 through GAD-5 and MALA-5; all seven labels were checked in each PDF. The seven-panel layout was rendered and visually inspected. Synthetic QA outputs are not included as scientific results.

The following earlier checks remain relevant because the numerical model/sampler/NUTS kernels were preserved; they are not claims of new full production runs.

## Earlier numerical checks (unchanged numerical kernels)

The original seed-42 models for **acoustic FWI, Allen-Cahn, Navier-Stokes and Helmholtz** were imported at their original grid sizes/dimensions. Their forward maps, exact gradients, forward Jacobians and GN posterior curvature were checked. Independent finite-difference directional derivative relative errors were below the screening tolerance `5e-3`; the three separately logged FWI/NS/Helmholtz errors were approximately `8.7e-10`, `5.4e-9` and `6.8e-9`.

The fast host-side physical-field transforms used for posterior moment/interval summaries matched the original model transforms. The preparation stage also checks this at the truth, zero and an independent prior-scale probe before production jobs are released.

## Earlier reduced end-to-end CPU smoke run

A reduced **Allen-Cahn** validation used the original 32-dimensional, 32 x 32 problem, fixed data seed 42, 64 particles, 200 transport steps, two GAD rounds and two independent sampler seeds (42 and 43). Both canonical comparisons completed, used identical target fingerprints and produced their own GAD and checkpoint-MALA clouds.

Four independent short NUTS chains used 30 warmup steps and 80 retained draws each, with intentionally relaxed diagnostic thresholds solely to exercise the workflow. Preparation, exact-potential NUTS, chunk export, ArviZ diagnostics, physical/predictive reference summaries, both repeat evaluations, paired aggregation and the final results ZIP completed. The short-chain maximum rank R-hat was about 1.14: **this is a plumbing check, not a production-quality reference**. The delivered defaults retain the strict Darcy thresholds and 3,000/5,000 warmup/retained lengths.

An intentionally coarse three-step transport smoke test produced incomplete predictive metrics; the runner correctly marked it incomplete instead of silently reporting success. The actual reduced end-to-end test used the full canonical 200 steps. No coarse transport settings or relaxed NUTS thresholds are in the delivered defaults.

## Earlier figure and artifact checks

- All 14 figure types, all three PCA pairs, CSV outputs, LaTeX table fragments and a 15-page dashboard were exercised with a ten-repeat synthetic fixture. Fixture results are not scientific outputs and are not included in the deliverable.
- The real reduced Allen-Cahn run also produced all 14 figure types and a complete results archive.
- Standalone PDFs are created from verified in-memory PDF bytes and atomically replaced. Every standalone PDF is reopened after rendering; invalid PDFs make aggregation incomplete. The completed dashboard and results ZIP were checked.
- Field/state grids, posterior-error/work curves, predictive bands, PCA histograms, repeat-variation maps, reference traces, uncertainty maps and geometry layouts were visually inspected. Final field/error/SD row labels and common color scales were checked on the real Allen-Cahn render.
- A production-resolution figure was generated at 600 dpi: its PNG was 4,329 x 2,821 pixels and its PDF was readable. PDF/SVG retain editable text and vector line work; physical grids retain their original solver resolution and are not represented as a finer numerical solution.

## Local QA environment

Python 3.12.14 on x86_64 CPU; NumPy 2.3.5, SciPy 1.17.0, pandas 2.2.3, Matplotlib 3.10.8, JAX/jaxlib 0.12.0.1, PyTorch 2.14.1+cpu, NumPyro 0.22.0, ArviZ 0.23.4, pypdf 6.10.0. These are tested local versions, not instructions to replace the working Vista environment.

The current ArviZ major-version API incompatibility and NumPyro fresh-kernel continuation requirement were reproduced during QA and handled. Production preflight checks actual API calls and CUDA operations in the selected Vista environment. Long-chain convergence, GPU runtime/memory use and all requested production outcomes must be assessed from the actual submitted jobs.
