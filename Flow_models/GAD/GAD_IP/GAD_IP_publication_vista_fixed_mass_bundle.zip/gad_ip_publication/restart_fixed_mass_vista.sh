#!/bin/bash
# Replace only the reference-dependent work; retain the old frozen sampler jobs.
set -euo pipefail
GP_BUNDLE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
GP_IP_ROOT="$(dirname -- "$GP_BUNDLE_DIR")"
GP_OLD_BATCH="${1:-$GP_IP_ROOT/batches/gad_ip_followup_20261026_v2}"
GP_NEW_BATCH="${2:-$GP_IP_ROOT/batches/gad_ip_fixed_mass_20261027}"
GP_OLD_LOG="${GP_OLD_WATCHER_LOG:-$GP_IP_ROOT/$(basename -- "$GP_OLD_BATCH")_submit.log}"
GP_NEW_LOG="${GP_NEW_DRIVER_LOG:-$GP_IP_ROOT/$(basename -- "$GP_NEW_BATCH")_submit.log}"
cd "$GP_BUNDLE_DIR"
source slurm/environment.sh

# Check the destination before touching any old submissions; stop a prior local
# watcher for the destination too, making this launcher safe to run again.
python - "$GP_OLD_BATCH" "$GP_NEW_BATCH" "$GP_NEW_LOG" <<'PY'
import json,os,signal,socket,sys
from pathlib import Path
from cancel_reference_jobs import watcher_pids
from workflow import verify_frozen
old,new,log=map(lambda x:Path(x).resolve(),sys.argv[1:])
if old==new:raise ValueError('Use a distinct new batch; the old frozen code stays intact.')
if not (old/'batch.json').is_file():raise FileNotFoundError('Missing old batch: '+str(old))
if new.exists():
    verify_frozen(new)
    if json.loads((new/'settings.json').read_text())['nuts'].get('mass_mode')!='fixed':
        raise ValueError('Destination is not a fixed-mass batch; choose another destination.')
    host=Path(str(log)+'.host')
    if host.exists() and host.read_text().strip().split('.')[0]!=socket.gethostname().split('.')[0]:
        raise RuntimeError('Stop the destination watcher on '+host.read_text().strip()+' first.')
    for pid in watcher_pids(new):
        try:os.kill(pid,signal.SIGTERM)
        except ProcessLookupError:pass
PY

python cancel_reference_jobs.py --batch "$GP_OLD_BATCH" --watcher-log "$GP_OLD_LOG" --apply

if [[ -f "$GP_NEW_BATCH/batch.json" ]]; then
    GP_ARGS=(--resume-batch "$GP_NEW_BATCH" --reuse-from "$GP_OLD_BATCH" --retry-failed)
else
    GP_REPEATS="$(python - "$GP_OLD_BATCH" <<'PY'
import json,sys
from pathlib import Path
b=Path(sys.argv[1]);p=b/'selection.json';c=json.loads((b/'settings.json').read_text())
print(len(json.loads(p.read_text())['sampler_seeds']) if p.exists() else min(c.get('initial_repeats',5),len(c['sampler_seeds'])))
PY
)"
    GP_ARGS=(--batch "$GP_NEW_BATCH" --reuse-from "$GP_OLD_BATCH" --import-runs "$GP_IP_ROOT" --repeats "$GP_REPEATS")
fi

# First pass returns after the eligible jobs are submitted. The persistent
# driver then fills the remaining tasks as slots and reservations become free.
bash submit.sh "${GP_ARGS[@]}"
nohup bash submit.sh --resume-batch "$GP_NEW_BATCH" --reuse-from "$GP_OLD_BATCH" --retry-failed --watch \
    >> "$GP_NEW_LOG" 2>&1 < /dev/null &
GP_DRIVER_PID=$!
echo "$GP_DRIVER_PID" > "$GP_NEW_LOG.pid"
hostname > "$GP_NEW_LOG.host"
disown
echo "Detached watcher PID: $GP_DRIVER_PID"
echo "Batch: $GP_NEW_BATCH"
echo "Monitor: tail -f $GP_NEW_LOG"
