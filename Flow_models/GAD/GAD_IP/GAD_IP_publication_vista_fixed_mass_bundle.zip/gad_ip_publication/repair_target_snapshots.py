#!/usr/bin/env python3
"""Audited target-loader repair for existing frozen publication batches.

Stops if a batch job is running; holds eligible pending jobs during the atomic
file replacements. Existing MAP, reference, samples and settings are preserved.
"""
import argparse
import ast
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

VERSION='target-snapshot-1'
OLD_FUNCTION_HASHES={'load_model': '9bb1fd1b036ec5a966a9f9ade6d03bbb9e99227eba0ea88e8969c0589068f411', 'model_data': 'ecb96d0fbe114e893872e3f15ec312f094da550416aa1d3c443dac54b28bf664', 'check_target': 'b9b1edf9ab7a7dc1244b9e86f41c356cbabb356ff623ce3f38a956d91c5d66c7'}
FUNCTIONS={'load_model': "def load_model(problem, data_seed, directory):\n    screen_imports()\n    from run_problem import load_model as original\n    with in_directory(directory):\n        model=original(problem,data_seed)\n    if Path(directory).name=='model_data':\n        model._gad_preparation_snapshot=Path(directory).resolve().parent\n    return model\n", 'model_data': "def model_data(problem, model, data_seed):\n    import numpy as np\n    arrays = {key: np.asarray(getattr(model, key), dtype=np.float64) for key in\n              ('alpha_true_np', 'y_obs_np', 'y_clean_np', 'y_holdout_obs_np', 'y_holdout_clean_np')}\n    arrays['basis'] = np.asarray(model.Basis, dtype=np.float64)\n    for key in ('obs_indices_train', 'obs_indices_holdout', 'receiver_flat_indices',\n                'holdout_receiver_flat_indices', 'source_centers', 'receiver_coords'):\n        if hasattr(model, key): arrays[key] = np.asarray(getattr(model, key))\n    meta = dict(problem=problem, data_seed=data_seed, noise_std=float(model.NOISE_STD),\n                dimension=int(model.ACTIVE_DIM), grid=int(model.N), model_sha256=digest(SCREEN/'models'/f'{problem}.py'))\n    identity=fingerprint(meta,arrays)\n    if (getattr(model,'_gad_preparation_snapshot',None) is not None\n            and not getattr(model,'_gad_snapshot_captured',False)\n            and not getattr(model,'_gad_restoring_target',False)):\n        from target_snapshot import capture_preparation\n        capture_preparation(model._gad_preparation_snapshot,problem,model,meta,identity)\n        model._gad_snapshot_captured=True\n    return meta,arrays,identity\n", 'check_target': 'def check_target(batch, problem, model):\n    from target_snapshot import bind_prepared_target\n    return bind_prepared_target(batch,problem,model)\n'}


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def write(path,text):
    path=Path(path);temp=path.with_name(path.name+f'.{os.getpid()}.repair-tmp')
    temp.write_text(text);temp.replace(path)


def function_hash(node):
    # Serialize fields explicitly: ast.dump formatting and empty-field defaults
    # vary across supported Python versions. Empty type_params is new in 3.12.
    def stable(value):
        if isinstance(value,ast.AST):
            return [type(value).__name__,{name:stable(item) for name,item in ast.iter_fields(value)
                                         if name!='type_params'}]
        if isinstance(value,list):return [stable(item) for item in value]
        return value
    return hashlib.sha256(json.dumps(stable(node),sort_keys=True,separators=(',',':')).encode()).hexdigest()

def patch_common(source):
    nodes={n.name:n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
    edits=[];lines=source.splitlines(keepends=True)
    for name,replacement in FUNCTIONS.items():
        node=nodes[name];old=function_hash(node)
        new=ast.parse(replacement).body[0]
        new_hash=function_hash(new)
        if old not in {OLD_FUNCTION_HASHES[name],new_hash}:
            raise ValueError('Unrecognized '+name+' implementation; refusing to overwrite local changes')
        edits.append((node.lineno-1,node.end_lineno,replacement))
    for start,end,replacement in sorted(edits,reverse=True):lines[start:end]=[replacement]
    return ''.join(lines)


def patch_cache(source):
    if '# target-snapshot-1' in source:return source
    first="        return all((out/name).is_file() for name in PREPARED)"
    if source.count(first)!=1:raise ValueError('Unrecognized prepared-target cache check')
    source=source.replace(first,"        from target_snapshot import validate_prepared  # target-snapshot-1\n        validate_prepared(batch,problem)\n"+first)
    second="            for name in PREPARED:copy_file(previous/name,out/name)"
    if source.count(second)!=1:raise ValueError('Unrecognized prepared-target adoption path')
    extra="""
            from target_snapshot import EXTRA_FILES
            for name in EXTRA_FILES:
                if (previous/name).exists():copy_file(previous/name,out/name)
                elif (out/name).exists():
                    archive=batch/'failed_attempts'/'target_constants'/problem/str(time.time_ns())
                    archive.mkdir(parents=True,exist_ok=True);shutil.move(str(out/name),str(archive/name))
"""
    return source.replace(second,second+extra.rstrip())


def verify(batch):
    meta=read(batch/'batch.json');manifest=read(batch/'source_manifest.json')
    if digest(batch/'settings.json')!=meta['settings_sha256']:raise ValueError('Frozen settings were modified')
    if digest(batch/'source_manifest.json')!=meta['source_manifest_sha256']:raise ValueError('Source manifest was modified')
    for name,sha in manifest.items():
        if digest(batch/'code'/name)!=sha:raise ValueError('Frozen source was modified: '+name)
    return meta,manifest


def local_jobs(batch,offline):
    config=read(batch/'settings.json')
    expected=config.get('slurm',{}).get('cluster') or {'gh':'vista','rtx':'frontera','rtx-dev':'frontera'}.get(config['slurm']['partition'])
    actual=(os.environ.get('TACC_SYSTEM') or os.environ.get('SLURM_CLUSTER_NAME') or '').lower()
    if actual and expected and actual!=expected:raise ValueError('Repair this batch on '+expected+', not '+actual)
    if offline:return []
    result=subprocess.run(['squeue','--noheader','--array','--user',os.environ.get('USER',''),'--format=%i|%T|%r'],capture_output=True,text=True,check=True)
    own={str(v['id']).split('_')[0] for v in read(batch/'jobs.json').values()} if (batch/'jobs.json').exists() else set()
    rows=[]
    for line in result.stdout.splitlines():
        parts=[s.strip() for s in line.split('|',2)]
        if len(parts)==3 and parts[0].split('_')[0] in own:rows.append(parts)
    busy=[jid+':'+state for jid,state,reason in rows if state!='PENDING']
    if busy:raise RuntimeError('Batch has active jobs; wait for them to finish before patching frozen source: '+', '.join(busy))
    return rows


def repair(batch,offline=False):
    batch=Path(batch).resolve();held=[]
    with (batch/'.submission.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        meta,manifest=verify(batch)
        helper=Path(__file__).with_name('target_snapshot.py')
        if not helper.is_file():raise FileNotFoundError('Keep repair_target_snapshots.py beside target_snapshot.py in the extracted bundle')
        replacements={'common.py':patch_common((batch/'code/common.py').read_text()),
                      'cache.py':patch_cache((batch/'code/cache.py').read_text()),
                      'target_snapshot.py':helper.read_text()}
        for name,source in replacements.items():ast.parse(source,filename=name)
        changed={n:s for n,s in replacements.items() if not (batch/'code'/n).exists() or (batch/'code'/n).read_text()!=s}
        if not changed:
            print('Already repaired: '+str(batch));return
        rows=local_jobs(batch,offline)
        try:
            for jid,state,reason in rows:
                if reason.startswith('JobHeld'):continue
                subprocess.run(['scontrol','hold',jid],check=True,capture_output=True,text=True);held.append(jid)
            if not offline:local_jobs(batch,False)
            stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'_'+str(os.getpid())
            backup=batch/'repairs'/stamp;backup.mkdir(parents=True)
            protected={str(p.relative_to(batch)):digest(p) for pattern in ['reference/*/target*','reference/*/setup.*']
                       for p in batch.glob(pattern) if p.is_file()}
            for name in ['batch.json','source_manifest.json']:shutil.copy2(batch/name,backup/name)
            for name in changed:
                old=batch/'code'/name
                if old.exists():shutil.copy2(old,backup/name)
            try:
                for name,source in changed.items():write(batch/'code'/name,source)
                for name in changed:manifest[name]=digest(batch/'code'/name)
                write(batch/'source_manifest.json',json.dumps(manifest,indent=2)+'\n')
                meta['source_manifest_sha256']=digest(batch/'source_manifest.json')
                meta['target_snapshot_fix']=VERSION
                write(batch/'batch.json',json.dumps(meta,indent=2)+'\n')
                verify(batch)
                if any(digest(batch/name)!=sha for name,sha in protected.items()):raise RuntimeError('Protected target/MAP files changed')
            except BaseException:
                for name in changed:
                    previous=backup/name;dest=batch/'code'/name
                    if previous.exists():shutil.copy2(previous,dest)
                    else:dest.unlink(missing_ok=True)
                for name in ['batch.json','source_manifest.json']:shutil.copy2(backup/name,batch/name)
                raise
            record=dict(version=VERSION,changed_source_files=list(changed),backup=str(backup),
                        protected_files=protected,settings_sha256=meta['settings_sha256'],held_pending_jobs=held)
            write(backup/'repair.json',json.dumps(record,indent=2)+'\n')
            write(batch/'logs'/('target-snapshot-repair-'+stamp+'.json'),json.dumps(record,indent=2)+'\n')
            print('Repaired '+str(batch)+'; saved target, MAP, samples and settings retained. Backup: '+str(backup))
        finally:
            for jid in held:
                result=subprocess.run(['scontrol','release',jid],capture_output=True,text=True)
                if result.returncode:print('Could not release '+jid+': '+result.stderr.strip(),file=sys.stderr)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--batch',type=Path,required=True)
    parser.add_argument('--offline',action='store_true',help='No Slurm queries/holds; only for a stopped local/Colab runner')
    args=parser.parse_args();repair(args.batch,args.offline)


if __name__=='__main__':main()
