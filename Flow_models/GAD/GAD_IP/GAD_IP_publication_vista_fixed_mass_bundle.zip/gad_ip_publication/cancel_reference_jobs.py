#!/usr/bin/env python3
"""Stop one batch's local watcher and cancel only its reference-dependent jobs.

GAD/MALA repeats, preparation jobs and all scientific files remain in place.
Default is read-only; --apply performs the displayed actions. Run on the login
host recorded in the watcher's .host file. Uses only the Python standard library.
"""
import argparse
import datetime
import fcntl
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import socket
import subprocess


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def reference_job(key, job):
    command=job.get('command',[])
    if len(command)>=3 and command[-3] in {'chain','certify','evaluate','aggregate'}:
        return True
    return bool(key.startswith('aggregate-') or re.search(r'-(?:chains|chain-\d+|reference|evaluation-\d+)$',key))


def watcher_pids(batch):
    result=[]
    for directory in Path('/proc').glob('[0-9]*'):
        try:
            if directory.stat().st_uid!=os.getuid():continue
            args=[s.decode() for s in (directory/'cmdline').read_bytes().split(b'\0') if s]
            if not any(Path(s).name=='workflow.py' for s in args) or 'submit' not in args:continue
            cwd=(directory/'cwd').resolve()
            for flag in ('--batch','--resume-batch'):
                if flag in args:
                    value=Path(args[args.index(flag)+1])
                    if (value if value.is_absolute() else cwd/value).resolve()==batch:
                        result.append(int(directory.name));break
        except (OSError,ValueError,IndexError,UnicodeDecodeError):continue
    return result


def cancel(batch,watcher_log,apply=False):
    batch=Path(batch).resolve();watcher_log=Path(watcher_log).resolve()
    cluster=(os.environ.get('TACC_SYSTEM') or '').lower()
    if cluster and cluster!='vista':raise RuntimeError('Run this command on Vista.')
    host_file=Path(str(watcher_log)+'.host')
    if not host_file.is_file():
        raise RuntimeError('Missing watcher host record: '+str(host_file)+'. Locate the old watcher before cancelling its jobs.')
    recorded=host_file.read_text().strip();actual=socket.gethostname()
    if recorded.split('.')[0]!=actual.split('.')[0]:
        raise RuntimeError('Run on '+recorded+' to stop the old watcher. Current host: '+actual)
    pids=watcher_pids(batch)
    print('Watcher host: '+recorded+'; matching watcher PIDs: '+str(pids),flush=True)
    if apply:
        for pid in pids:
            try:os.kill(pid,signal.SIGTERM)
            except ProcessLookupError:pass
    # A stopped watcher cannot race changes to jobs.json. In read-only mode
    # this lock only makes the preview consistent with a single submission pass.
    with (batch/'.submission.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        meta=read(batch/'batch.json')
        if digest(batch/'settings.json')!=meta['settings_sha256']:raise ValueError('Frozen settings changed')
        if digest(batch/'source_manifest.json')!=meta['source_manifest_sha256']:raise ValueError('Frozen source manifest changed')
        for name,sha in read(batch/'source_manifest.json').items():
            if digest(batch/'code'/name)!=sha:raise ValueError('Frozen source changed: '+name)
        jobs=read(batch/'jobs.json') if (batch/'jobs.json').exists() else {}
        wanted={str(v['id']):k for k,v in jobs.items() if reference_job(k,v)}
        if any(not re.fullmatch(r'\d+(?:_\d+)?',jid) for jid in wanted):raise ValueError('Unexpected Slurm job ID')
        query=subprocess.run(['squeue','--noheader','--array','--user',os.environ.get('USER') or getpass.getuser(),
                              '--format=%i|%T'],capture_output=True,text=True,check=True)
        active={}
        for line in query.stdout.splitlines():
            if '|' not in line:continue
            jid,state=[x.strip() for x in line.split('|',1)]
            if jid in wanted:active[jid]=state
            elif jid.split('_')[0] in wanted:active[jid.split('_')[0]]=state
        print('Cancel '+str(len(active))+' active reference/dependent jobs:',flush=True)
        for jid in sorted(active):print('  '+jid+' '+wanted[jid]+' '+active[jid],flush=True)
        kept={k:str(v['id']) for k,v in jobs.items() if not reference_job(k,v)}
        print('Retain preparation, preflight and GAD/MALA repeat jobs: '+str(kept),flush=True)
        if not apply:
            print('Read-only preview. Add --apply to stop the watcher and cancel the listed jobs.');return
        stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'_'+str(os.getpid())
        record=dict(batch=str(batch),watcher_host=recorded,stopped_watcher_pids=pids,
                    cancel_job_ids=sorted(active),retained_jobs=kept)
        path=batch/'logs'/('fixed-mass-cancel-'+stamp+'.json');path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps(record,indent=2)+'\n')
        if active:subprocess.run(['scancel',*sorted(active)],check=True)
        print('Reference cancellation requested. Saved all targets, MAPs and sampler results. Audit: '+str(path),flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--batch',type=Path,required=True)
    p.add_argument('--watcher-log',type=Path,required=True)
    p.add_argument('--apply',action='store_true')
    a=p.parse_args();cancel(a.batch,a.watcher_log,a.apply)


if __name__=='__main__':main()
