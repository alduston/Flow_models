"""Fixed-mass restart: preserve live repeats, reject dense references, resume safely."""
import copy
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unittest

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from common import digest,read_json,run_directory,settings,write_json
from cache import chain_valid,reference_valid,reference_key,run_key,target_key
from fixtures import synthetic_batch
import test_incremental as incremental
from workflow import freeze


class FixedMassMigrationTests(unittest.TestCase):
    setUp=incremental.IncrementalTests.setUp
    tearDown=incremental.IncrementalTests.tearDown
    cli=incremental.IncrementalTests.cli
    commands=incremental.IncrementalTests.commands

    def legacy(self):
        old=synthetic_batch(self.base)
        c=settings(old);c['nuts'].pop('mass_mode',None);write_json(old/'settings.json',c)
        shutil.copy2(ROOT/'provenance/fixed_mass_before/reference.py',old/'code/reference.py')
        out=old/'reference/afwi'
        for path in (out/'chains').glob('*.json'):
            r=read_json(path);r.pop('mass_mode',None);write_json(path,r)
        r=read_json(out/'nuts_diagnostics.json');r['thresholds']=c['nuts'];write_json(out/'nuts_diagnostics.json',r)
        manifest={str(p.relative_to(old/'code')):digest(p) for p in (old/'code').rglob('*') if p.is_file()}
        write_json(old/'source_manifest.json',manifest)
        meta=read_json(old/'batch.json');meta.update(settings_sha256=digest(old/'settings.json'),
                                                  source_manifest_sha256=digest(old/'source_manifest.json'))
        write_json(old/'batch.json',meta)
        return old

    def test_fixed_fork_reuses_preparation_completed_and_live_repeats_only(self):
        old=self.legacy();old_settings=digest(old/'settings.json')
        shutil.rmtree(run_directory(old,'afwi',43))
        write_json(old/'jobs.json',{'afwi-repeat-43':dict(id='8888'),'afwi-chain-0':dict(id='8889')})
        write_json(self.states,{'8888':'PENDING','8889':'CANCELLED'})
        c=settings(old);c['nuts']['mass_mode']='fixed';cfg=self.base/'fixed.json';write_json(cfg,c)
        batch=self.base/'new'
        self.cli('--batch',batch,'--config',cfg,'--reuse-from',old,'--max-outstanding-tasks','100')
        nodes={r['key']:r for r in read_json(batch/'submission_plan.json')['nodes']}
        self.assertEqual(nodes['afwi-prepare']['state'],'cached')
        self.assertEqual(nodes['afwi-repeat-42']['state'],'cached')
        self.assertEqual(nodes['afwi-repeat-43']['job_ids'],['8888'])
        self.assertEqual(nodes['afwi-repeat-43']['state'],'existing')
        for i in range(4):self.assertEqual(nodes['afwi-chain-'+str(i)]['state'],'submitted')
        self.assertFalse((batch/'reference/afwi/chains').exists())
        self.assertFalse((batch/'reference/afwi/checkpoints').exists())
        self.assertFalse((batch/'reference/afwi/reference_samples.npz').exists())
        self.assertEqual(digest(batch/'reference/afwi/setup.npz'),digest(old/'reference/afwi/setup.npz'))
        self.assertEqual(digest(batch/'reference/afwi/target_arrays.npz'),digest(old/'reference/afwi/target_arrays.npz'))
        self.assertEqual(digest(run_directory(batch,'afwi',42)/'samples_all_rounds.npz'),
                         digest(run_directory(old,'afwi',42)/'samples_all_rounds.npz'))
        self.assertEqual(digest(old/'settings.json'),old_settings)
        self.assertFalse(any(cmd[-3]=='repeat' for cmd in self.commands()))
        before=len(self.commands());self.cli('--resume-batch',batch,'--max-outstanding-tasks','100')
        self.assertEqual(len(self.commands()),before)

    def test_sampler_keys_ignore_nuts_logging_but_detect_changed_potential(self):
        old=self.legacy();c=settings(old);fixed=copy.deepcopy(c);fixed['nuts']['mass_mode']='fixed'
        self.assertEqual(target_key(c,'afwi',old/'code'),target_key(fixed,'afwi',ROOT))
        self.assertEqual(run_key(c,'afwi',42,old/'code'),run_key(fixed,'afwi',42,ROOT))
        self.assertNotEqual(reference_key(c,'afwi',old/'code'),reference_key(fixed,'afwi',ROOT))
        path=old/'code/reference.py';path.write_text(path.read_text().replace('return .5*jnp.vdot','return .6*jnp.vdot'))
        self.assertNotEqual(target_key(c,'afwi',old/'code'),target_key(fixed,'afwi',ROOT))

    def test_old_dense_reference_rejected_in_fixed_settings(self):
        old=self.legacy();self.assertTrue(chain_valid(old,'afwi',0));self.assertTrue(reference_valid(old,'afwi'))
        c=settings(old);c['nuts']['mass_mode']='fixed';write_json(old/'settings.json',c)
        self.assertFalse(chain_valid(old,'afwi',0));self.assertFalse(reference_valid(old,'afwi'))

    def test_cancellation_keeps_sampler_jobs_and_is_idempotent(self):
        old=self.legacy();jobs={'afwi-chain-0':dict(id='2001'),'afwi-reference':dict(id='2002'),
                             'afwi-evaluation-42':dict(id='2003'),'aggregate-abc':dict(id='2004'),
                             'afwi-repeat-43':dict(id='2005'),'afwi-prepare':dict(id='2006')}
        write_json(old/'jobs.json',jobs);write_json(self.states,{str(i):'PENDING' for i in range(2001,2007)})
        calls=self.base/'cancelled.json'
        executable=self.base/'bin/scancel'
        executable.write_text('#!'+sys.executable+'\n'+'''import json,os,sys
from pathlib import Path
p=Path(os.environ['QA_CANCELS']);p.write_text(json.dumps(sys.argv[1:]))
s=Path(os.environ['QA_STATES']);states=json.loads(s.read_text())
for jid in sys.argv[1:]:states[jid]='CANCELLED'
s.write_text(json.dumps(states))
''');executable.chmod(0o755)
        log=self.base/'watcher.log';Path(str(log)+'.host').write_text(socket.gethostname())
        env={**self.env,'QA_CANCELS':str(calls),'TACC_SYSTEM':'vista'}
        cmd=[sys.executable,str(ROOT/'cancel_reference_jobs.py'),'--batch',str(old),'--watcher-log',str(log)]
        preview=subprocess.run(cmd,env=env,capture_output=True,text=True)
        self.assertEqual(preview.returncode,0,preview.stderr);self.assertFalse(calls.exists())
        applied=subprocess.run(cmd+['--apply'],env=env,capture_output=True,text=True)
        self.assertEqual(applied.returncode,0,applied.stderr)
        self.assertEqual(read_json(calls),['2001','2002','2003','2004'])
        self.assertEqual(read_json(self.states)['2005'],'PENDING');self.assertEqual(read_json(self.states)['2006'],'PENDING')
        again=subprocess.run(cmd+['--apply'],env=env,capture_output=True,text=True)
        self.assertEqual(again.returncode,0,again.stderr)
        self.assertIn('Cancel 0 active',again.stdout)

    def test_launcher_submits_then_detaches_with_old_repeat_retained(self):
        old=self.legacy();shutil.rmtree(run_directory(old,'afwi',43))
        write_json(old/'jobs.json',{'afwi-chain-0':dict(id='2001'),'afwi-repeat-43':dict(id='2005')})
        write_json(self.states,{'2001':'PENDING','2005':'PENDING'})
        executable=self.base/'bin/scancel'
        executable.write_text('#!'+sys.executable+'\n'+'''import json,os,sys
from pathlib import Path
s=Path(os.environ['QA_STATES']);states=json.loads(s.read_text())
for jid in sys.argv[1:]:states[jid]='CANCELLED'
s.write_text(json.dumps(states))
''');executable.chmod(0o755)
        code=self.base/'bundle';shutil.copytree(ROOT,code,ignore=shutil.ignore_patterns('__pycache__'))
        c=settings(old);c['nuts']['mass_mode']='fixed';write_json(code/'settings.json',c)
        log=self.base/'old.log';Path(str(log)+'.host').write_text(socket.gethostname())
        new=self.base/'fixed';new_log=self.base/'fixed_submit.log'
        env={**self.env,'GP_SKIP_MODULES':'1','GP_OLD_WATCHER_LOG':str(log),
             'GP_NEW_DRIVER_LOG':str(new_log),'TACC_SYSTEM':'vista'}
        result=subprocess.run(['bash',str(code/'restart_fixed_mass_vista.sh'),str(old),str(new)],
                              env=env,capture_output=True,text=True,timeout=60)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)
        self.assertIn('Detached watcher PID:',result.stdout)
        self.assertTrue(Path(str(new_log)+'.pid').exists());self.assertTrue(Path(str(new_log)+'.host').exists())
        self.assertEqual(read_json(self.states)['2005'],'PENDING')
        nodes={r['key']:r for r in read_json(new/'submission_plan.json')['nodes']}
        self.assertEqual(nodes['afwi-repeat-43']['job_ids'],['2005'])
        # This one-problem fixture fits in one pass. Its detached watcher has
        # no deferred nodes and exits without leaving a persistent QA process.
        for _ in range(200):
            if new_log.exists() and 'Results:' in new_log.read_text():break
            time.sleep(.05)
        self.assertIn('Results:',new_log.read_text())


class FixedChainTests(unittest.TestCase):
    def test_fixed_chunk_resume_and_metric_binding(self):
        import jax
        import jax.numpy as jnp
        import numpy as np
        from reference import run_chunked_chain
        jax.config.update('jax_enable_x64',True)
        cfg=dict(mass_mode='fixed',num_warmup=25,num_samples=16,chunk_size=8,target_accept=.95,
                 max_tree_depth_warmup=4,max_tree_depth=5,sampler_seed=551)
        energy=lambda z:.5*jnp.sum(z*z)
        with tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
            self.assertIsNone(run_chunked_chain(energy,np.zeros(2),a,cfg,0,'qa',stop_after_chunks=1))
            resumed=run_chunked_chain(energy,np.zeros(2),a,cfg,0,'qa')
            direct=run_chunked_chain(energy,np.zeros(2),b,cfg,0,'qa')
            np.testing.assert_array_equal(resumed['z_samples'],direct['z_samples'])
            with self.assertRaisesRegex(ValueError,'Incompatible checkpoint'):
                run_chunked_chain(energy,np.zeros(2),a,dict(cfg,mass_mode='dense'),0,'qa')


if __name__=='__main__':unittest.main()
