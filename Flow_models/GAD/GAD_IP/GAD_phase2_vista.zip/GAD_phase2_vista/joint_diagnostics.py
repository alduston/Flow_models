"""Joint geometry, measured-constraint fit and prespecified y<0 coverage.

Aggregate SW2/MMD remain in the report. These diagnostics distinguish fitting
the curved constraint from assigning the correct probability along it.
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

def turn_profile(target):
    """Truth-blind scalar profile through the turn; diagnostic only.

    Minimizes exact posterior energy over source x at each fixed source y.
    This probes a ridge-energy barrier; it is not a free-energy estimate or
    proof about transport dynamics, and never supplies a sampler initializer.
    """
    from scipy.optimize import minimize_scalar
    mu=np.asarray(target.mu);scale=np.asarray(target.scale);rows=[]
    for y in np.linspace(-4.,6.,121):
        grid=np.linspace(mu[0]-7.5*scale[0],mu[0]+7.5*scale[0],257)
        points=np.column_stack([grid,np.full(len(grid),y)])
        alpha=(points-mu)/scale;lp,_=target.joint(alpha)
        candidates=[]
        for j in np.argsort(-lp)[:4]:
            lo=grid[max(0,j-1)];hi=grid[min(len(grid)-1,j+1)]
            def f(x):return -float(target.joint(((np.array([x,y])-mu)/scale)[None])[0][0])
            opt=minimize_scalar(f,bounds=(lo,hi),method='bounded',options={'xatol':1e-9})
            candidates.append((opt.fun,opt.x))
        energy,x=min(candidates);a=(np.array([x,y])-mu)/scale;prior=.5*np.sum(a*a)
        rows.append({'source_y_m':float(y),'profile_source_x_m':float(x),'exact_profile_energy':float(energy),
                     'prior_energy':float(prior),'likelihood_energy':float(energy-prior)})
    minimum=min(r['exact_profile_energy'] for r in rows)
    for row in rows:row['energy_above_profile_minimum']=row['exact_profile_energy']-minimum
    fig,axes=plt.subplots(1,2,figsize=(11,4.5))
    axes[0].plot([r['profile_source_x_m'] for r in rows],[r['source_y_m'] for r in rows],c='#10498a')
    axes[0].axhline(0,c='#888',ls=':');axes[0].set(xlabel='source x (m)',ylabel='fixed source y (m)',title='Profiled ridge through the turn')
    for key,label in [('energy_above_profile_minimum','posterior, shifted minimum'),('prior_energy','prior'),('likelihood_energy','likelihood')]:
        axes[1].plot([r['source_y_m'] for r in rows],[r[key] for r in rows],label=label)
    axes[1].axvline(0,c='#888',ls=':');axes[1].set(xlabel='source y (m)',ylabel='negative log energy',title='Exact posterior energy along profiled ridge');axes[1].legend(fontsize=8)
    return rows,fig

def geometry_metrics(target,methods,ref,cfg):
    from evaluate import sw2,capped
    result=[];rp=target.parameters(ref);negative=rp[:,1]<0
    cov=np.asarray(target.data.get('noise_covariance',np.diag(np.asarray(target.data['noise_sd'])**2)))
    W=np.linalg.inv(np.linalg.cholesky(cov));obs=np.asarray(target.data['y'])
    for name,x in methods.items():
        physical=target.parameters(x);neg=physical[:,1]<0;within=0;energy=0.;maxres=[];fitparts=[]
        for first in range(0,len(x),8192):
            residual=(np.asarray(target.forward_batch(x[first:first+8192]))-obs)@W.T
            fitparts.append(np.all(np.abs(residual)<=3,axis=1));within+=fitparts[-1].sum();energy+=np.sum(residual**2)/2
            maxres.append(np.max(np.abs(residual),axis=1))
        residuals=np.concatenate(maxres)
        row={'method':name,'states':len(x),'fraction_all_whitened_residual_components_within_3':within/len(x),
             'mean_negative_log_likelihood_up_to_constant':energy/len(x),'whitened_residual_abs_median':np.median(residuals),
             'whitened_residual_abs_q95':np.quantile(residuals,.95)}
        if target.case.startswith('tdoa'):
            row.update(probability_y_below_zero=neg.mean(),reference_probability_y_below_zero=negative.mean(),
                       absolute_y_below_zero_probability_error=abs(neg.mean()-negative.mean()),
                       negative_region_states=int(neg.sum()),positive_region_states=int((~neg).sum()),
                       fraction_negative_and_within_3=float(np.mean(neg & np.concatenate(fitparts))),
                       negative_region_constraint_fit_fraction=float(np.mean(np.concatenate(fitparts)[neg])) if neg.any() else None)
            for mask,r_mask,label in [(neg,negative,'negative'),(~neg,~negative,'positive')]:
                n=min(cfg['cloud_cap'],int(mask.sum()),int(r_mask.sum()))
                row[f'{label}_region_conditional_SW2']=sw2(capped(x[mask],n),capped(ref[r_mask],n),cfg['directions']) if n>=32 else None
                row[f'{label}_region_comparison_state']='available' if n>=32 else 'insufficient_or_missing_coverage'
        result.append(row)
    return result

def joint_panel(target,methods,reference,quadrature,last):
    names=['NUTS',f'GAD-{last}',f'pMALA-work{last}',f'pMALA-time{last}','Laplace','Independent quadrature']
    sets=[reference,methods.get(names[1]),methods.get(names[2]),methods.get(names[3]),methods['Laplace'],quadrature]
    points=[None if x is None else target.parameters(x) for x in sets]
    lo=np.min([x.min(0) for x in points if x is not None],axis=0);hi=np.max([x.max(0) for x in points if x is not None],axis=0)
    pad=.025*np.maximum(hi-lo,1e-9);lo-=pad;hi+=pad
    xe=np.linspace(lo[0],hi[0],151);ye=np.linspace(lo[1],hi[1],181)
    hist=[None if x is None else np.histogram2d(x[:,0],x[:,1],bins=[xe,ye])[0]/len(x) for x in points]
    norm=LogNorm(vmin=1e-5,vmax=max(1e-4,max(h.max() for h in hist if h is not None)))
    fig,axes=plt.subplots(2,3,figsize=(15,10),sharex=True,sharey=True)
    for ax,name,x,h in zip(axes.flat,names,points,hist):
        ax.set_title(name);ax.set_facecolor('#f3f4f6');ax.set(xlim=(lo[0],hi[0]),ylim=(lo[1],hi[1]))
        ax.axhline(0,c='#888888',ls=':',lw=.65)
        if x is None:ax.text(.5,.5,'No completed sample checkpoint',transform=ax.transAxes,ha='center');continue
        im=ax.pcolormesh(xe,ye,np.ma.masked_equal(h.T,0),norm=norm,cmap='magma',rasterized=True)
        ax.text(.03,.97,f'N = {len(x):,}\nP(y < 0) = {np.mean(x[:,1]<0):.1%}',transform=ax.transAxes,ha='left',va='top',fontsize=9,bbox=dict(facecolor='white',alpha=.85,edgecolor='none'))
    for ax in axes[-1]:ax.set_xlabel('source x (m)')
    for ax in axes[:,0]:ax.set_ylabel('source y (m)')
    # Explicit colorbar prevents tight_layout from squeezing the six axes.
    from matplotlib.cm import ScalarMappable
    fig.colorbar(ScalarMappable(norm=norm,cmap='magma'),ax=axes.ravel().tolist(),fraction=.025,pad=.025,label='probability per common bin (log scale)')
    return fig
