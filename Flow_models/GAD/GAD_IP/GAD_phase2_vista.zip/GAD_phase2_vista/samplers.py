"""Four-round transport-only GAD and charged, dispersed-start MAP-pMALA."""
import time
import numpy as np
import jax
import jax.numpy as jnp
from common import Ledger, check_cloud, log, npz, read, runtime, save_npz, signature, verify_file, write
from vendor.lfgi import combine_stats, make_integrator

def gad(target, cfg, setup, setup_info, directory, bind):
    gc = dict(cfg['gad']); gc['steps'] = int(setup['steps']); n = gc['particles']
    directory.mkdir(parents=True, exist_ok=True)
    ledger = Ledger(setup_info['oracle_counts']); elapsed = setup_info['elapsed_seconds']; previous = None; records = []
    times = np.geomspace(gc['t_max'], float(setup['t_min']), gc['steps']+1)
    rtbind = signature({'binding': bind, 'runtime': runtime()})
    for r in range(1, gc['rounds']+1):
        rd = directory/f'round{r}'; rd.mkdir(exist_ok=True)
        if (rd/'sampling.json').exists():
            rec = verify_file(rd/'sampling.json', bind); previous = check_cloud(npz(rd/'samples.npz')['samples'])
            ledger = Ledger(rec['oracle_counts']); elapsed = rec['elapsed_seconds']; records.append(rec); continue
        log(f'{target.case}: GAD round {r}/{gc["rounds"]}, bank {n}')
        if (rd/'bank.json').exists():
            bi = verify_file(rd/'bank.json', bind); bank = npz(rd/'bank.npz'); bank_seconds = bi['bank_seconds']; ledger = Ledger(bi['oracle_counts'])
        else:
            start = time.monotonic()
            x = setup['center']+np.random.default_rng(cfg['sampler_seed']+701).normal(size=(n, 2))@setup['factor'].T if r==1 else previous.copy()
            lp, s = target.joint(x); H = target.gn(x); ledger.add(energy=n, gradient=n, hessian=n)
            if not np.isfinite(lp).all() or not np.isfinite(s).all() or not np.isfinite(H).all(): raise FloatingPointError('Nonfinite GAD bank')
            bank = {'x': x, 's': s, 'H': H}; bank_seconds = time.monotonic()-start
            save_npz(rd/'bank.npz', **bank)
            write(rd/'bank.json', {'binding': bind, 'bank_seconds': bank_seconds, **ledger.record(), 'curvature': 'exact prior Hessian + likelihood J^T Gamma^-1 J'})
        integrate = make_integrator(bank['x'], bank['s'], bank['H'], gc)
        statefile = rd/'transport.npz'
        if statefile.exists():
            state = npz(statefile)
            if str(state['runtime_binding']) != rtbind: raise ValueError('GAD checkpoint runtime mismatch')
            y, key, done, stats, round_seconds = jnp.asarray(state['y']), jnp.asarray(state['key']), int(state['done']), state['stats'], float(state['round_seconds'])
        else:
            key = jax.random.PRNGKey(cfg['sampler_seed']+1009*r); key, base = jax.random.split(key)
            y = jax.random.normal(base, (n, 2), dtype=jnp.float64); done = 0
            stats = np.array([0., 0., np.inf, 0., 0., np.inf, 0.]); round_seconds = bank_seconds
        while done<gc['steps']:
            end = min(done+gc['checkpoint_steps'], gc['steps']); start = time.monotonic()
            interval = np.stack([times[done:end], times[done+1:end+1]], axis=1)
            y, key, st = integrate(y, key, jnp.asarray(interval)); yy = check_cloud(np.asarray(y))
            stats = np.asarray(combine_stats(jnp.asarray(np.stack([stats, np.asarray(st)]))))
            round_seconds += time.monotonic()-start; done = end
            start_io = time.monotonic()
            save_npz(statefile, y=yy, key=np.asarray(key), done=np.array(done), stats=stats,
                     round_seconds=np.array(round_seconds), runtime_binding=np.asarray(rtbind))
            round_seconds += time.monotonic()-start_io
            log(f'{target.case}: GAD round {r}, integration {done}/{gc["steps"]}')
        previous = check_cloud(np.asarray(y)); elapsed += round_seconds
        save_npz(rd/'samples.npz', samples=previous)
        rec = {'binding': bind, 'method': f'GAD-{r}', 'round': r, **ledger.record(), 'elapsed_seconds': elapsed,
               'round_seconds': round_seconds, 't_min': float(setup['t_min']), 'steps': gc['steps'],
               'guard_fraction': float(stats[0]/max(1, stats[1])), 'min_gate_denominator': float(stats[2]),
               'max_gate_gain': float(stats[3]), 'mean_conditional_ess': float(stats[4]/max(1, stats[6])),
               'min_conditional_ess': float(stats[5]), 'initialization': 'MAP-Laplace' if r==1 else f'GAD-{r-1}',
               'output': 'unweighted transport samples; no terminal projection or importance weights',
               'proxy': 'E+G+H requests; bank GN counts as H; not a FLOP equivalence; elapsed time includes compilation and shared setup'}
        write(rd/'sampling.json', rec); records.append(read(rd/'sampling.json'))
    return records

def make_pmala_kernels(target, center, factor):
    center, factor = jnp.asarray(center), jnp.asarray(factor)
    def loggrad(z):
        e, g = jax.vmap(jax.value_and_grad(target.energy))(center+z@factor.T)
        return -e, -g@factor
    def step(carry, _):
        z, lp, s, key, h = carry
        key, nk, uk = jax.random.split(key, 3)
        prop = z+h*s+jnp.sqrt(2*h)*jax.random.normal(nk, z.shape, dtype=jnp.float64)
        lq, sq = loggrad(prop)
        f = prop-z-h*s; rev = z-prop-h*sq
        ratio = lq-lp+(jnp.sum(f*f, axis=1)-jnp.sum(rev*rev, axis=1))/(4*h)
        good = jnp.isfinite(lq) & jnp.all(jnp.isfinite(sq), axis=1) & jnp.isfinite(ratio)
        logr = jnp.where(good, jnp.minimum(ratio, 0.), -jnp.inf)
        acc = jnp.log(jax.random.uniform(uk, (len(z),), dtype=jnp.float64))<logr
        zz = jnp.where(acc[:, None], prop, z); pp = jnp.where(acc, lq, lp); ss = jnp.where(acc[:, None], sq, s)
        return (zz, pp, ss, key, h), (center+zz@factor.T, jnp.mean(jnp.exp(logr)), jnp.sum(acc))
    @jax.jit
    def initial(z): return loggrad(z)
    @jax.jit
    def warm(carry, i, target_accept):
        state, out = step(carry, None)
        multiplier = jnp.where(out[1]<.05,.1,jnp.exp(.6/(i+1.)**.6*(out[1]-target_accept)))
        h = jnp.clip(state[-1]*multiplier, 1e-10, 1.)
        return (*state[:-1], h), (out[1], h)
    # Fixed static production lengths are compiled once per length encountered.
    from functools import partial
    @partial(jax.jit, static_argnums=(1,))
    def production(carry, count): return jax.lax.scan(step, carry, None, length=count)
    return initial, warm, production

def pmala(target, cfg, setup, setup_info, gad_records, directory, bind):
    directory.mkdir(parents=True, exist_ok=True); pc = cfg['pmala']; chains = pc['chains']
    complete = directory/'complete.json'
    if complete.exists(): return verify_file(complete, bind)
    initial, warm_step, production = make_pmala_kernels(target, setup['center'], setup['factor'])
    statefile = directory/'state.npz'; metafile = directory/'state.json'
    rtbind = signature({'binding': bind, 'runtime': runtime()})
    if statefile.exists() and metafile.exists():
        st = npz(statefile); meta = verify_file(metafile, bind)
        if meta['runtime_binding'] != rtbind: raise ValueError('pMALA runtime mismatch')
        carry = tuple(jnp.asarray(st[k]) for k in ['z', 'lp', 'score', 'key', 'h'])
        history = list(st['history']); block_times = list(st['block_times']); block_ends = list(st['block_ends'])
        block_accepted = list(st['block_accepted']); elapsed = meta['elapsed_seconds']; warm_probs = st['warm_acceptance']; ledger = Ledger(meta['oracle_counts'])
    else:
        start = time.monotonic()
        z = np.random.default_rng(cfg['sampler_seed']+40000).normal(size=(chains, 2))
        lp, s = initial(jnp.asarray(z)); jax.block_until_ready(s)
        if not np.isfinite(np.asarray(lp)).all() or not np.isfinite(np.asarray(s)).all(): raise FloatingPointError('Invalid dispersed pMALA start')
        initial_h = min(pc['initial_step'], .25*np.sqrt(2.)/max(1e-300,np.linalg.norm(np.asarray(s),axis=1).max()))
        carry = (jnp.asarray(z), lp, s, jax.random.PRNGKey(cfg['sampler_seed']+40001), jnp.asarray(initial_h))
        probs = []
        # Adaptation has a fixed, charged length. Frozen step thereafter.
        for i in range(pc['warmup']):
            carry, out = warm_step(carry, jnp.asarray(float(i)), jnp.asarray(pc['target_accept']))
            probs.append(float(np.asarray(out[0])))
        elapsed = setup_info['elapsed_seconds']+time.monotonic()-start
        ledger = Ledger(setup_info['oracle_counts']); ledger.add(energy=chains*(1+pc['warmup']), gradient=chains*(1+pc['warmup']))
        history = []; block_times = []; block_ends = []; block_accepted = []; warm_probs = np.array(probs)
    # All production states, including MH rejection repeats, survive each checkpoint.
    def checkpoint():
        nonlocal elapsed
        start = time.monotonic()
        z, lp, s, key, h = (np.asarray(a) for a in carry)
        save_npz(statefile, z=z, lp=lp, score=s, key=key, h=h, history=np.asarray(history).reshape(-1, chains, 2),
                 block_times=np.asarray(block_times), block_ends=np.asarray(block_ends), block_accepted=np.asarray(block_accepted), warm_acceptance=warm_probs)
        elapsed += time.monotonic()-start
        write(metafile, {'binding': bind, 'runtime_binding': rtbind, **ledger.record(), 'elapsed_seconds': elapsed})
    def advance(count):
        nonlocal carry, elapsed
        start = time.monotonic(); carry, out = production(carry, count)
        states, probs, acc = (np.asarray(a) for a in out); check_cloud(states.reshape(-1, 2))
        history.extend(states); elapsed += time.monotonic()-start; ledger.add(energy=count*chains, gradient=count*chains)
        block_times.append(elapsed); block_ends.append(len(history)); block_accepted.append(int(acc.sum()))
    def save_output(name, end, record):
        nonlocal elapsed
        start = time.monotonic()
        if end:
            sample = np.asarray(history[:end]); save_npz(directory/(name+'.npz'), samples=sample.reshape(-1, 2), samples_by_chain=sample.transpose(1, 0, 2))
        write(directory/(name+'.json'), {'binding': bind, **record, 'production_steps': end, 'retained_states': end*chains,
               'state': 'complete' if end else 'budget_consumed_before_production', 'output': 'ALL production states, including rejection repeats; dependent',
               'initialization': 'independent MAP-Laplace draws in the same law as GAD first bank', 'fixed_final_step': float(np.asarray(carry[-1]))})
        elapsed += time.monotonic()-start
    for rec in gad_records:
        cap = rec['work']; r = rec['round']; jsonfile = directory/f'work{r}.json'
        if jsonfile.exists(): verify_file(jsonfile, bind); continue
        while ledger.work+2*chains<=cap:
            count = min(pc['production_block'], (cap-ledger.work)//(2*chains))
            advance(int(count))
        save_output(f'work{r}', len(history), {**ledger.record(), 'matched_work_cap': cap, 'elapsed_seconds': elapsed,
                    'acceptance_rate': sum(block_accepted)/max(1, len(history)*chains), 'comparison': 'derivative-request matched'})
        checkpoint(); log(f'{target.case}: pMALA work checkpoint {r}, {len(history)} production transitions, work {ledger.work}/{cap}')
    max_time = max(r['elapsed_seconds'] for r in gad_records)
    next_save = len(history)+pc['checkpoint_transitions']
    while elapsed<max_time and elapsed<pc['max_seconds'] and len(history)<pc['max_transitions']:
        advance(min(pc['production_block'], pc['max_transitions']-len(history)))
        if len(history)>=next_save:
            checkpoint(); next_save = len(history)+pc['checkpoint_transitions']
    for rec in gad_records:
        cap = rec['elapsed_seconds']; valid = [i for i,t in enumerate(block_times) if t<=cap]
        idx = valid[-1] if valid else None; end = int(block_ends[idx]) if idx is not None else 0
        counts = dict(setup_info['oracle_counts']); points = chains*(1+pc['warmup']+end)
        counts['energy'] += points; counts['gradient'] += points
        save_output(f'time{rec["round"]}', end, {'oracle_counts': counts, 'work': sum(counts.values()),
                    'elapsed_seconds': block_times[idx] if idx is not None else None, 'matched_time_cap_seconds': cap,
                    'time_undershoot_seconds': cap-block_times[idx] if idx is not None else None,
                    'comparison': 'elapsed-time matched at last complete timed block; no interpolation',
                    'time_cap_reached': bool(elapsed>=cap), 'acceptance_rate': sum(block_accepted[:idx+1])/max(1, end*chains) if idx is not None else None})
    checkpoint()
    save_npz(directory/'all_production.npz', samples_by_chain=np.asarray(history).transpose(1, 0, 2),
             block_times=np.asarray(block_times), block_ends=np.asarray(block_ends), warm_acceptance=warm_probs)
    result = {'binding': bind, **ledger.record(), 'elapsed_seconds': elapsed, 'steps': len(history),
              'time_extension_reached': bool(elapsed>=max_time), 'time_extension_limits': pc}
    write(complete, result); return result
