# GAD phase two v2: 8,192 particles, five rounds

The default launcher now runs a paired TDOA study: the original 15-microsecond arrival-noise target and `tdoa_soft` with 30-microsecond noise. Both use 8,192 bank/output particles and five rounds. Each gets a fresh exact-potential NUTS reference and independently recomputed MAP setup. The six-panel joint histogram is a primary dashboard result.

The historical CPU results in `validation/cpu_pilot/` use 2,048 particles and four rounds. They are retained as the diagnostic motivation, not presented as results of this larger run. V2 receives separate short integration checks; the 8k/five-round experiment is prepared for Vista.

## Original scope

Start with **TDOA source localization**. The second implemented family is the published **logistic growth observation-design experiment**, with both clustered and dispersed observations. These are inexpensive two-dimensional mechanism pilots; they do not replace the paper's PDE applications.

The binding model is retained as a screened diagnostic, not a recommended full campaign: its apparent physical-parameter bend almost disappears in the tested log-affinity coordinates. No sampler ranking was used to make this decision. See `EXPERIMENT_DESIGN.md` and `validation/VALIDATION.md`.

## First Vista experiment

Copy this ZIP to your existing GAD_IP directory, then:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP
unzip -q GAD_phase2_vista.zip
cd GAD_phase2_vista
source slurm/environment.sh
python submit_vista.py \
  --batch ../batches/gad_phase2_tdoa_pair_8k5_seed42_v2 \
  --case tdoa_pair --account DMS22021
```

This submits **one GH node, one job, six-hour limit**. There is no watcher and no job array. It freezes a self-contained source/configuration copy in the new batch, validates derivatives, runs the reference, audits geometry, runs the samplers if the checks pass, and exports figures/metrics. It does not modify or cancel any old campaign.

From the extracted bundle directory, `bash run_first_vista.sh` runs the same paired study; `bash run_first_vista.sh --resume` restarts that same batch after its previous job has stopped. `G2_BATCH` and `G2_ACCOUNT` can override its defaults. Use `G2_CASE=tdoa bash run_first_vista.sh` for the original target alone, or `G2_CASE=tdoa_soft bash run_first_vista.sh` for the softer target alone; each defaults to a distinct new batch.

The existing `hlsi` environment is the default. Override its path before sourcing if needed:

```bash
export G2_VENV_DIR=/your/working/venv
source slurm/environment.sh
```

Only if NumPyro/ArviZ are missing, use `bash install_reference_extras.sh` in that environment. That helper preserves its existing GPU JAX. Do not install a CPU JAX wheel over the working Vista installation.

Inspect a submission without submitting or creating a batch:

```bash
python submit_vista.py --batch ../batches/gad_phase2_tdoa_pair_8k5_seed42_v2 --case tdoa_pair --dry-run
```

To run both families and the logistic negative control sequentially in one allocation, use a **new** batch and `--case all`. The optional four-microphone localization control is `--case tdoa_control`.

## Monitor, restart, collect

The submission command prints the actual job ID and log path. Monitor `squeue -u "$USER"` and the batch's `slurm-JOBID.log`.

After an interrupted or time-limited job has left the queue, resubmit the same frozen campaign:

```bash
python submit_vista.py \
  --batch ../batches/gad_phase2_tdoa_pair_8k5_seed42_v2 \
  --case tdoa_pair --account DMS22021 --resume
```

NUTS resumes at completed warmup/draw chunks; GAD resumes at transport checkpoints; pMALA resumes with its state, RNG, full production history, adaptation result, counts and elapsed time. Runtime versions must match for sampler checkpoints. Source, target or configuration changes require a new campaign. A live recorded job blocks duplicate submission.

Primary result:

```text
../batches/gad_phase2_tdoa_pair_8k5_seed42_v2/tdoa/tdoa_figures_metrics.zip
```

The batch also contains raw samples and checkpoints. The compact export contains dashboard and individual PDF/PNG panels, CSV tables, the frozen target/configuration, and reference/geometry/setup diagnostics.

## Frozen scientific settings

| Component | Production default |
|---|---|
| Dataset / sampler | frozen observations, sampler seed 42, one repeat |
| GAD | 5 rounds, 8,192 bank/output particles, transport-only q-LFGI |
| Integrator | source Heun reverse OU; 300 geometric steps initially; automatic refinement only if its deterministic Gaussian control fails |
| Endpoint | min(1e-6, 0.5 log(1 + 0.01 lambda_min(C_MAP))); stable small-time algebra |
| Initial law | same MAP-Laplace law for GAD first bank and independently dispersed pMALA chains |
| MAP | 4 truth-blind starts; exact full posterior Hessian, documented eigenvalue floor |
| pMALA | 8 chains; 96 charged warmup transitions; fixed metric and step after adaptation; all production states retained |
| Reference | 4 exact-potential NUTS chains; 5,000 warmup + 20,000 retained draws each; target acceptance 0.95; depth 12; dense mass adaptation |
| Reference cross-check | independently refined 2D posterior quadrature; never supplied to either sampler |
| Work checkpoints | cumulative GAD E+G+H request caps after rounds 1-5; setup/warmup/rejections included |
| Wall-time checkpoints | last completed pMALA timed block within each GAD cumulative time; underfill and hard-limit flags saved |

An H request is a historical derivative-request proxy, not a statement that a Hessian costs one gradient. Actual method elapsed time, including compilation and charged preprocessing, accompanies every checkpoint. Reference and diagnostic work is recorded separately. Shared MAP setup is executed once and fully charged to every comparator.

The single-pair TDOA reference uses a verified **range-difference/perpendicular coordinate chart with its exact Jacobian**, followed by affine preconditioning and dense mass adaptation. GAD and pMALA use Cartesian prior coordinates. An affine Cartesian NUTS check showed divergences even with long chains; the chart repairs the independent reference rather than silently accepting those draws. The chart is an available problem-native reparameterization, which is another reason this 2D case is a mechanism calibration, not a claim that all conventional treatments of localization are difficult. Other cases use affine exact-MAP reference coordinates.

If the independent reference shows that the MAP-selected endpoint exceeds the 1% variance tolerance, the numerical endpoint is tightened to a 0.5% reference-scale margin and the Gaussian integrator control is repeated. This scalar accuracy repair is recorded in `setup/production_endpoint.json`; it does not change either sampler's initial law, MAP metric or bank. The optional negative control otherwise sits exactly at the tolerance and can fail due to a small MAP/reference covariance difference.

## Scientific checks and stopping behavior

The default first run performs long NUTS **before** the GAD/pMALA comparison. It requires rank R-hat <= 1.01; bulk ESS >= 1,000; tail ESS >= 400; zero divergences; depth saturation <= 1%; and E-BFMI >= 0.3, including the scientific observables. It also requires agreement with converged quadrature, a usable stiff-subspace gap, appreciable global projector rotation, and a passing endpoint check. A discovered distinct MAP basin stops the single-Laplace pilot rather than hiding a coverage issue.

Reference failure or a negative main-target geometry screen produces a reference-only diagnostic dashboard and `sampling_status.json`. It does **not** report a sampler win. The dispersed logistic case is an intentional negative control and can run after reference checks even without a rotating rank-one subspace. The clustered logistic case may also screen negative in the source-preserving bounded coordinates. Its negative result is useful and is retained.

To explicitly retain a geometry-negative case as a sampler control, run the frozen `code/run.py` with `--run-screen-failures` in a separate output directory. `--allow-provisional` is a debugging option that leaves provisional reference labels everywhere; do not use it for the scientific pilot.

## Outputs

`report/dashboard.pdf` combines the six-panel joint histogram, the turn-energy profile, and the seven existing diagnostic figures, each also exported separately:

1. Posterior geometry in sampled and physical coordinates.
2. Predictive mean and uncertainty curves.
3. Two predeclared scientific QoI CDFs and survival curves.
4. Accuracy versus derivative-request work and measured elapsed time.
5. NUTS scientific-observable traces and chain histograms.
6. Global normal rotation, local coherence and independent grid contours.
7. Bank conditional ESS, actual gate clipping and solve-scaled exact/GN discrepancy.

Tables include SW2, fixed-bandwidth multiscale unbiased MMD squared, full-history mean/covariance/SD errors, predictive mean/SD amplitude/pattern errors and underlying curves, QoI quantiles/tail probabilities/MC errors, reference-versus-reference floors, NUTS and pMALA ESS/jump diagnostics, and separate work ledgers. Small negative unbiased MMD squared estimates are permitted. pMALA cloud metrics stratify its **entire** production history and retain rejection repeats; its moment, predictive moment and QoI estimates use all production. Predictive quantile bands alone use a labeled 4,096-draw cap. Conditional particle/block MC errors are labeled; one seed does not estimate between-repeat uncertainty. The block-MC estimates use blocks up to 128 transitions and can understate error in poorly mixing chains; inspect ESS/R-hat before interpreting them as uncertainty intervals.

MAP-Laplace is the cheap control. A moment Gaussian is fit to one NUTS chain group and evaluated against the other, then swapped; it is an oracle diagnostic with no path into either sampler.

## Local CPU use

The runtime used for numerical validation was Python 3.12, JAX/JAXlib 0.4.35, NumPyro 0.15.3 and ArviZ 0.22.0. Vista uses your established Python 3.11/GPU environment; it is checked at job start.

```bash
python run.py preflight --cpu --out /tmp/gad_phase2_preflight
python run.py run --case tdoa --out runs/local_tdoa --cpu
```

A deliberately tiny labeled integration check is available with `--smoke --run-screen-failures --allow-provisional`. It tests the complete pipeline, not accuracy or performance at the production budget.

All code/data needed for a new campaign is inside this folder. No earlier ZIP, saved PDE posterior, Kaggle source or external data download is needed.

## Geometry and coverage metrics added in v2

`report/tables/geometry_coverage_metrics.csv` retains every completed method checkpoint and each GAD input bank. It reports P(source y<0), absolute reference probability error, counts in each region, joint probability of negative height and constraint satisfaction, the fraction satisfying every whitened residual component within three noise SD, residual quantiles, and conditional SW2 inside each y-sign region. Missing/undersampled regions are explicitly labeled; their conditional SW2 is left empty rather than reported as zero. Global SW2, MMD, covariance and scientific-observable metrics remain available. These diagnostics separate constraint geometry from mass allocation; no single aggregate metric declares a winner.

The distribution-metric cap stays at 2,048 for consistent comparisons with the first pilot and bounded quadratic MMD cost. Histograms, coverage probabilities, physical moments and QoIs use all available samples.

The softer target doubles per-receiver arrival noise from 15 to 30 microseconds, multiplying the difference-noise covariance by four. Truth, prior, sensor geometry and the standardized noise realization remain fixed. This tests whether reduced transverse stiffness helps mass spreading. It does not establish that the turn contains an energy barrier: the measured ridge is smooth, and bank coverage or transport approximation may also matter. Old target references/caches are never imported into the softer posterior.

The dashboard also includes `turn_energy_profile.pdf/png` and `turn_energy_profile.csv`: a truth-blind exact-posterior profile minimizing over source x at fixed source y. It separates ridge-energy variation from the cost of leaving the narrow ridge. It is a profile, not an integrated free-energy curve or proof of a dynamical barrier, and is never used to initialize either sampler.
