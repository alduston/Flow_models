"""Analytic source-localization and growth models in prior-whitened coordinates.

TDOA uses affine Cartesian coordinates with a Gaussian prior. Logistic growth
preserves the published physical uniform priors through an exact logit map and
its Jacobian; its prior Hessian is included in GAD. The screened binding model
has a Gaussian prior directly on logs. Physical plots transform draws.
"""
import numpy as np
import jax
import jax.numpy as jnp
from common import ROOT, read
jax.config.update('jax_enable_x64', True)

CASES = ('logistic_clustered', 'logistic_dispersed', 'tdoa', 'tdoa_soft', 'tdoa_control', 'binding')

class Target:
    dim = 2
    def __init__(self, case):
        if case not in CASES: raise ValueError(case)
        self.case = case; self.data = read(ROOT / 'data' / (case + '.json'))
        self.mu = jnp.asarray(self.data['log_prior_mean']); self.scale = jnp.asarray(self.data['log_prior_sd'])
        obs = jnp.asarray(self.data['y']); sigma = jnp.asarray(self.data['noise_sd'])
        whitening = jnp.asarray(np.linalg.inv(np.linalg.cholesky(np.asarray(self.data.get('noise_covariance',np.diag(np.asarray(sigma)**2))))))
        design = jnp.asarray(self.data['design'])
        self.labels = self.data['parameter_labels']; self.qoi_labels = self.data['qoi_labels']
        tdoa = case.startswith('tdoa'); uniform = self.data.get('prior_family')=='uniform_logit'
        self.coordinate_label = 'prior-whitened Cartesian' if tdoa else ('prior-whitened logit' if uniform else 'prior-whitened log')
        c = np.pi/np.sqrt(3.)
        bounds = jnp.asarray(self.data.get('prior_bounds',[[0.,1.],[0.,1.]]))
        def physical(x):
            if tdoa: return self.mu+self.scale*x
            if uniform: return bounds[:,0]+(bounds[:,1]-bounds[:,0])*jax.nn.sigmoid(c*x)
            return jnp.exp(self.mu + self.scale*x)
        def prior(x):
            if uniform: return jnp.sum(jax.nn.softplus(c*x)+jax.nn.softplus(-c*x))
            return .5*jnp.vdot(x,x)
        def predict(x, at):
            if tdoa:
                source=physical(x); radius=self.data['sensor_radius_m']; phi=self.data['reference_angle_radians']
                receivers=radius*jnp.stack([jnp.cos(at),jnp.sin(at)],axis=-1)
                reference=radius*jnp.array([jnp.cos(phi),jnp.sin(phi)])
                r=jnp.sqrt(jnp.sum((source-receivers)**2,axis=-1)+1e-18)
                r0=jnp.sqrt(jnp.sum((source-reference)**2)+1e-18)
                return (r-r0)*1e6/self.data['sound_speed_m_per_s']
            if case == 'binding':
                p = self.mu + self.scale*x
                # Partition states: empty, once-bound, twice-bound. Stable at L=0.
                log_l = jnp.log(at)
                logits = jnp.stack([jnp.zeros_like(at), p[0]+log_l, p[0]+p[1]+2*log_l], -1)
                weights = jax.nn.softmax(logits, -1)
                return .5*weights[..., 1] + weights[..., 2]
            # K / (1 + (K/x0 - 1) exp(-r t)), evaluated in a stable log form.
            # Priors give negligible mass to K<x0; logaddexp form remains valid there.
            K, r = physical(x)
            ert = jnp.exp(-r*at)
            return K/(1+(K/self.data['initial_population']-1)*ert)
        def forward(x): return predict(x, design)
        def energy(x):
            residual = whitening@(forward(x)-obs)
            return prior(x) + .5*jnp.vdot(residual, residual)
        def gn(x):
            J = whitening@jax.jacfwd(forward)(x)
            return jax.hessian(prior)(x) + J.T@J
        def likelihood_gn(x):
            J=whitening@jax.jacfwd(forward)(x)
            return J.T@J
        def qoi(x):
            p = physical(x)
            if tdoa: return jnp.array([jnp.linalg.norm(p-jnp.asarray(self.data['search_center_m'])),p[1]])
            if case == 'binding':
                # Ratio of sequential macroscopic affinities; occupancy is a held-out prediction.
                return jnp.array([p[1]/p[0], predict(x, jnp.array([0.0025]))[0]])
            t90 = jnp.maximum(0., jnp.log(jnp.maximum(9*(p[0]/self.data['initial_population']-1), 1e-300)))/p[1]
            return jnp.array([predict(x, jnp.array([15.]))[0], t90])
        self.energy = energy; self.physical = physical; self.predict = predict; self.forward = forward
        self.qoi_one = qoi
        self.joint_jax = jax.jit(jax.vmap(jax.value_and_grad(energy)))
        self.gn_jax = jax.jit(jax.vmap(gn)); self.hessian = jax.jit(jax.hessian(energy))
        self.likelihood_gn_jax = jax.jit(jax.vmap(likelihood_gn))
        self.jacobian = jax.jit(jax.jacfwd(forward)); self.forward_batch = jax.jit(jax.vmap(forward))
        self.qoi_jax = jax.jit(jax.vmap(qoi)); self.physical_batch = jax.jit(jax.vmap(physical))
        self.predict_batch = jax.jit(jax.vmap(predict, in_axes=(0, None)))

    def joint(self, x):
        e, g = self.joint_jax(jnp.asarray(x, dtype=jnp.float64))
        return -np.asarray(e), -np.asarray(g)
    def gn(self, x): return np.asarray(self.gn_jax(jnp.asarray(x)))
    def likelihood_gn(self,x): return np.asarray(self.likelihood_gn_jax(jnp.asarray(x)))
    def qois(self, x): return np.asarray(self.qoi_jax(jnp.asarray(x)))
    def parameters(self, x): return np.asarray(self.physical_batch(jnp.asarray(x)))
    def predictions(self, x, at): return np.asarray(self.predict_batch(jnp.asarray(x), jnp.asarray(at)))
