#!/usr/bin/env python3
"""Single-seed campaign CLI. First run: TDOA localization on one Vista node."""
import argparse
import os
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['run', 'preflight', 'export'])
    parser.add_argument('--case', choices=['logistic_clustered', 'logistic_dispersed', 'tdoa', 'tdoa_control', 'binding'], default='tdoa')
    parser.add_argument('--out', type=Path, default=Path('runs/first_tdoa'))
    parser.add_argument('--config', type=Path, default=Path(__file__).parent/'config.json')
    parser.add_argument('--phase', choices=['all', 'prepare', 'reference', 'sample', 'report'], default='all')
    parser.add_argument('--cpu', action='store_true')
    parser.add_argument('--smoke', action='store_true', help='Short labeled validation; not a scientific comparison')
    parser.add_argument('--run-screen-failures', action='store_true', help='Retain a negative geometry case as an explicit sampler control')
    parser.add_argument('--allow-provisional', action='store_true', help='Debug only: sample despite a failed reference/grid check, retaining provisional labels')
    args = parser.parse_args()
    if args.cpu: os.environ['JAX_PLATFORMS'] = 'cpu'
    os.environ.setdefault('JAX_ENABLE_X64','true'); os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE','false')
    os.environ.setdefault('OMP_NUM_THREADS','8'); os.environ.setdefault('MPLBACKEND','Agg')
    from common import ROOT, binding, log, read, runtime, sha, signature, verify_file, write
    if args.command == 'export':
        import zipfile
        report = args.out/'report'
        if not (report/'dashboard.pdf').exists(): raise FileNotFoundError('Run report stage before export')
        dest = args.out/(args.case+'_figures_metrics.zip')
        with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
            for p in sorted(report.rglob('*')):
                if p.is_file(): z.write(p,str(p.relative_to(args.out)))
            for p in [args.out/'target.json',args.out/'screen.json',args.out/'reference/quality.json',args.out/'setup/setup.json',args.out/'setup/production_endpoint.json']:
                if p.exists(): z.write(p,str(p.relative_to(args.out)))
        with zipfile.ZipFile(dest) as z:
            if z.testzip() is not None: raise IOError('Export ZIP integrity error')
        log(f'Export: {dest}'); return
    from models import Target
    from prepare import derivative_check, quadrature, setup, production_endpoint
    import numpy as np
    cfg = read(args.config)
    if args.smoke:
        cfg['smoke_only'] = True
        cfg['gad'].update(particles=128,steps=150)
        cfg['pmala'].update(chains=4,warmup=16,production_block=16,max_transitions=4096,max_seconds=30)
        cfg['reference'].update(chains=4,warmup=300,samples=1000,chunk=250,max_depth=10,max_rhat=1.05,min_bulk_ess=100,min_tail_ess=50)
        cfg['evaluation'].update(cloud_cap=128,directions=64,floor_repeats=4,bootstrap_repeats=16)
    target = Target(args.case); bind = binding(cfg,target.data)
    if args.command == 'preflight':
        from tests import numerical_tests
        result = numerical_tests(); result.update(runtime=runtime(),config_binding=bind)
        write(args.out/'preflight.json',result); log(str(result)); return
    args.out.mkdir(parents=True,exist_ok=True)
    if (args.out/'target.json').exists(): verify_file(args.out/'target.json',bind)
    else:
        from common import source_hashes
        write(args.out/'target.json',{'binding':bind,'config':cfg,'data':target.data,'source_hashes':source_hashes(),'runtime_at_creation':runtime(),
                                    'sampling_seed':cfg['sampler_seed'],'scientific_scope':'biophysical mechanism pilot; 2D, not a replacement PDE claim'})
    s, si = setup(target,cfg,args.out/'setup',bind)
    if not (args.out/'setup/derivatives.json').exists():
        write(args.out/'setup/derivatives.json',{'binding':bind,'checks':derivative_check(target,[np.zeros(2),s['center'],s['center']+s['factor']@np.array([.3,-.3])])})
    if args.phase == 'prepare': log('Preparation complete'); return
    from reference import run as reference
    quality = reference(target,cfg,s,si,args.out/'reference',bind)
    if args.phase == 'reference': log('Reference complete; usable='+str(quality['reference_usable'])); return
    from common import npz
    from audit import screen
    from evaluate import evaluate, reference_grid_check
    quad, qi = quadrature(target,cfg,args.out/'setup',bind)
    refdata = npz(args.out/'reference/samples.npz')
    crosscheck = reference_grid_check(refdata['samples'],quad,target)
    write(args.out/'reference/quadrature_check.json',{'binding':bind,**crosscheck,'quadrature_converged':qi['converged']})
    reference_ok = quality['reference_usable'] and qi['converged'] and crosscheck['agreement']
    if reference_ok:s=production_endpoint(s,cfg,refdata['samples'],args.out/'setup',bind)
    sc = screen(target,cfg,s,si,refdata,quality,args.out,bind)
    geometry_ok = sc['geometry_candidate'] or target.data['control'] or args.run_screen_failures
    can_sample = (reference_ok or args.allow_provisional) and geometry_ok and sc['endpoint_within_tolerance_reference'] and not si['distinct_relevant_basins']
    if args.phase in ['all','sample']:
        if can_sample:
            from samplers import gad,pmala
            gr = gad(target,cfg,s,si,args.out/'gad',bind)
            pmala(target,cfg,s,si,gr,args.out/'pmala',bind)
            write(args.out/'sampling_status.json',{'binding':bind,'state':'complete','reference_provisional':not reference_ok,'geometry_screen_overridden':not sc['geometry_candidate'] and not target.data['control']})
        else:
            write(args.out/'sampling_status.json',{'binding':bind,'state':'screened_out_or_unresolved','reference_ok':reference_ok,'geometry_ok':geometry_ok,'screen':sc,
                                                 'explanation':'No sampler winner can be inferred. Geometry-negative controls can be retained explicitly with --run-screen-failures; unresolved references must be repaired.'})
            log('Sampling skipped: reference or geometry/endpoint screen unresolved; reference-only report will still be created.')
        if args.phase == 'sample': return
    result = evaluate(target,cfg,s,si,args.out,bind)
    log(f'Complete: {args.out}/report/dashboard.pdf; geometry={sc["status"]}; reference={result["reference_usable"]}')

if __name__ == '__main__': main()
