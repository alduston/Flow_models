# Historical v1 numerical pilot

The full CPU pilot below is 2,048 particles/four rounds. V2 now defaults to 8,192 particles/five rounds. See v2_8192_check.json and v2_integration_checks.json for the revised implementation checks. No completed full-size v2 benchmark is claimed.

# Validation - 31 October 2026

Validated locally on CPU, float64. No real Vista/Slurm submission was made. GPU and Grace execution remain a job-start preflight check.

## Numerical implementation

- Independent analytic forward-formula checks for every target, including the shared-reference TDOA covariance.
- Finite-difference score and exact-Hessian checks pass.
- Gaussian q-LFGI score identity holds to about 3e-16 relative error, including t=1e-10.
- Deterministic Heun mean/covariance control passes; endpoint and grid choices are saved.
- The reference-only TDOA chart passes round-trip and analytic-versus-AD Jacobian checks.
- MALA stationarity/MH checks pass on an independent Gaussian target.

## Full-budget TDOA CPU pilot

- Four NUTS chains, each 5,000 warmup + 20,000 retained draws: R-hat max 1.000056; bulk ESS min 30453; tail ESS min 40102; divergences 0.
- Cartesian quadrature agrees: whitened mean error 0.00553; covariance error 0.01232; maximum declared tail-probability difference 0.00151.
- The 90th-percentile MAP-normal rotation is 42.3 degrees. The geometry screen passes.
- Four 2,048-particle GAD rounds and the shared-Laplace pMALA comparison finish with finite outputs.
- Each pMALA derivative-request checkpoint uses the same cap as the corresponding GAD round, with all production states and rejection repeats retained.
- The elapsed-time continuation reaches every GAD time cap. It uses 406,943 production transitions per chain; all four snapshots record the last complete timed block and its undershoot.

| Method | SW2 in prior coordinates |
|---|---:|
| Laplace | 0.3569 |
| GAD-4 | 0.4209 |
| pMALA-work4 | 0.6891 |
| pMALA-time4 | 0.4138 |
| Moment Gaussian A to B | 0.1668 |

This is a mixed result, not a selected success: GAD improves over work-matched pMALA but does not improve on MAP-Laplace in this pilot. The moment Gaussian is a diagnostic oracle. A visible curved target is not sufficient evidence that four-round GAD has found its intended advantage regime. The curvature and bank diagnostics are retained to investigate that distinction. CPU runtime comparisons do not predict Vista GPU performance, particularly with these extremely cheap analytic targets.

## Second family and controls

The source-preserving clustered logistic target has a passing long NUTS reference (80,000 retained draws), with zero divergences and quadrature agreement, but only about 4.5 degrees of normal rotation in the sampled logit coordinates. The prespecified screen therefore skips its full sampler comparison by default. This does not dispute the published physical-coordinate curvature. A short forced-control run exercises its four-round GAD/pMALA path. The dispersed logistic design completes a short end-to-end run, including an exercised reference-triggered endpoint repair. The optional four-microphone TDOA control is implemented and derivative-checked; it has not received a full local comparison.

## Restart and execution checks

- Bit-exact NUTS final-chunk regeneration from the preceding saved RNG/state.
- Bit-exact GAD restart from a terminal transport checkpoint without a completion marker.
- Exact pMALA state/RNG/history preservation after re-entering from a saved state.
- Changed scientific bindings are refused.
- One-node Slurm submission, source freeze, resume and checksum refusal checked with local mocks.
- Python compilation, shell syntax and ZIP integrity checked.
- Dashboard and individual panels rendered and visually inspected.

`cpu_pilot/` contains report files, not resumable sampler caches. It is included for inspection, and is never imported as a Vista initialization or reference. The new Vista batch computes its own reference and comparisons from its frozen source/configuration.
