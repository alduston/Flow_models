"""Atomic outputs and scientific/runtime bindings. No import-time mutations."""
import hashlib
import json
import os
import pickle
import time
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent

def clean(v):
    if isinstance(v, dict): return {str(k): clean(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)): return [clean(x) for x in v]
    if isinstance(v, np.ndarray): return clean(v.tolist())
    if isinstance(v, np.generic): return clean(v.item())
    if isinstance(v, Path): return str(v)
    if isinstance(v, float) and not np.isfinite(v): return None
    return v

def signature(v):
    return hashlib.sha256(json.dumps(clean(v), sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text())

def write(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(clean(data), indent=2, sort_keys=True, allow_nan=False) + '\n')
    os.replace(tmp, path)

def save_npz(path, **data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('wb') as f: np.savez_compressed(f, **data)
    os.replace(tmp, path)

def npz(path):
    with np.load(path, allow_pickle=False) as f: return dict(f)

def save_pickle(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('wb') as f: pickle.dump(value, f, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(tmp, path)

def source_hashes():
    paths = list(ROOT.glob('*.py')) + list((ROOT / 'vendor').glob('*.py'))
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(paths)}

def binding(cfg, data): return signature({'config': cfg, 'data': data, 'source': source_hashes()})

def runtime():
    import jax, numpyro, platform, arviz
    return {'python': platform.python_version(), 'jax': jax.__version__, 'jaxlib': __import__('jaxlib').__version__,
            'numpy': np.__version__, 'numpyro': numpyro.__version__, 'arviz': arviz.__version__,
            'devices': [str(d) for d in jax.devices()]}

def log(message): print(time.strftime('%Y-%m-%d %H:%M:%S'), message, flush=True)

def verify_file(path, bind):
    info = read(path)
    if info.get('binding') != bind: raise ValueError(f'Changed target/config/source: {path}; use a NEW output directory.')
    return info

def check_cloud(x):
    x = np.asarray(x, dtype=float)
    if x.ndim != 2 or x.shape[1] != 2 or not np.isfinite(x).all(): raise FloatingPointError('Invalid 2D cloud')
    return x

class Ledger:
    """Historical E+G+H request proxy; actual elapsed time is saved separately."""
    def __init__(self, initial=None): self.counts = dict(initial or {'energy': 0, 'gradient': 0, 'hessian': 0})
    def add(self, energy=0, gradient=0, hessian=0):
        for k, n in [('energy', energy), ('gradient', gradient), ('hessian', hessian)]: self.counts[k] += int(n)
    @property
    def work(self): return sum(self.counts.values())
    def record(self): return {'oracle_counts': self.counts.copy(), 'work': self.work}
