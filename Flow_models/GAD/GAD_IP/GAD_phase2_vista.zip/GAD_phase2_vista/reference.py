"""Exact-potential NUTS in affine MAP coordinates, with resumable long chains."""
import pickle
import time
import numpy as np
import jax
import jax.numpy as jnp
from numpyro.infer import MCMC, NUTS
from common import log, npz, read, runtime, save_npz, save_pickle, signature, verify_file, write

def diagnostics(chains, extras, target, cfg):
    import arviz as az
    C, N, D = chains.shape
    q = target.qois(chains.reshape(-1, D)).reshape(C, N, -1)
    params = target.parameters(chains.reshape(-1, D)).reshape(C, N, D)
    columns = [('x'+str(j), chains[..., j]) for j in range(D)]
    columns += [(target.labels[j], params[..., j]) for j in range(D)]
    columns += [(target.qoi_labels[j], q[..., j]) for j in range(q.shape[-1])]
    rows = []
    for name, a in columns:
        rows.append({'observable': name, 'rank_rhat': float(az.rhat(a, method='rank')),
                     'bulk_ess': float(az.ess(a, method='bulk')), 'tail_ess': float(az.ess(a, method='tail', prob=(.05, .95)))})
    energy = extras['energy']; bfmi = np.mean(np.diff(energy, axis=1)**2, axis=1)/np.var(energy, axis=1, ddof=1)
    max_rhat = max(r['rank_rhat'] for r in rows); bulk = min(r['bulk_ess'] for r in rows); tail = min(r['tail_ess'] for r in rows)
    div = int(extras['diverging'].sum()); depth = float(np.mean(extras['num_steps'] >= 2**cfg['max_depth']-1))
    finite = bool(np.isfinite(chains).all() and np.isfinite([max_rhat, bulk, tail, *bfmi]).all())
    passed = finite and max_rhat<=cfg['max_rhat'] and bulk>=cfg['min_bulk_ess'] and tail>=cfg['min_tail_ess'] and div<=cfg['max_divergences'] and depth<=cfg['max_depth_fraction'] and bfmi.min()>=cfg['min_ebfmi']
    return {'reference_usable': bool(passed), 'diagnostics': rows, 'max_rank_rhat': max_rhat, 'min_bulk_ess': bulk,
            'min_tail_ess': tail, 'divergences': div, 'depth_saturation_fraction': depth, 'ebfmi_by_chain': bfmi,
            'mean_acceptance': extras['accept_prob'].mean(), 'mean_leapfrog_steps': extras['num_steps'].mean(),
            'thresholds': cfg, 'caveat': 'Within-chain diagnostics do not prove global mode coverage; quadrature supplies an independent 2D check.'}

def run(target, cfg, setup, setup_info, directory, bind):
    directory.mkdir(parents=True, exist_ok=True)
    if (directory/'quality.json').exists():
        verify_file(directory/'quality.json', bind)
        return read(directory/'quality.json')
    rc = cfg['reference']
    from reference_coordinates import coordinates
    decode,potential,coordinate_info=coordinates(target,setup,cfg)
    decode_batch=jax.jit(jax.vmap(decode))
    rt = runtime(); state_binding = signature({'scientific': bind, 'runtime': rt})
    kernel = NUTS(potential_fn=potential, adapt_mass_matrix=rc['adapt_mass_matrix'], dense_mass=rc['dense_mass'],
                  target_accept_prob=rc['target_accept'], max_tree_depth=rc['max_depth'])
    fields = ('potential_energy', 'energy', 'accept_prob', 'num_steps', 'adapt_state.step_size')
    rng = np.random.default_rng(cfg['sampler_seed']+170301)
    # Independent dispersed starts; neither quadrature nor GAD output is used here.
    initials = rng.normal(0, 1.5, (rc['chains'], 2))
    arrays = []; all_extras = []; chain_seconds = []; total_warmup_steps = []; collectors = {}
    def restore(file):
        with file.open('rb') as f: value = pickle.load(f)
        if value['state_binding'] != state_binding: raise ValueError('NUTS runtime/source/target checkpoint mismatch')
        value['state'] = jax.tree_util.tree_map(jnp.asarray, value['state'])
        return value
    for c in range(rc['chains']):
        cd = directory/f'chain{c}'; cd.mkdir(exist_ok=True); warmfile = cd/'warmup.pkl'
        if warmfile.exists(): warm = restore(warmfile)
        else:
            log(f'{target.case}: NUTS chain {c+1}/{rc["chains"]}, warmup {rc["warmup"]}')
            mc = MCMC(kernel, num_warmup=rc['warmup'], num_samples=rc['chunk'], progress_bar=False)
            start = time.monotonic()
            mc.warmup(jax.random.PRNGKey(cfg['sampler_seed']+100003*(c+1)), init_params=jnp.asarray(initials[c]),
                      collect_warmup=True, extra_fields=('num_steps',))
            jax.block_until_ready(mc.post_warmup_state.z)
            warm = {'state_binding': state_binding, 'state': jax.device_get(mc.post_warmup_state),
                    'seconds': time.monotonic()-start, 'leapfrog_steps': int(np.asarray(mc.get_extra_fields()['num_steps']).sum())}
            save_pickle(warmfile, warm); warm = restore(warmfile)
        state = warm['state']; parts = []; eparts = []; elapsed = warm['seconds']
        total_warmup_steps.append(warm['leapfrog_steps'])
        for first in range(0, rc['samples'], rc['chunk']):
            count = min(rc['chunk'], rc['samples']-first); file = cd/f'draws_{first:06d}.pkl'
            if file.exists(): part = restore(file)
            else:
                log(f'{target.case}: NUTS chain {c+1}/{rc["chains"]}, draws {first}/{rc["samples"]}')
                if count not in collectors:
                    collectors[count] = MCMC(kernel, num_warmup=rc['warmup'], num_samples=count, progress_bar=False)
                mc = collectors[count]
                mc.post_warmup_state = state; start = time.monotonic()
                mc.run(state.rng_key, init_params=state.z, extra_fields=fields); jax.block_until_ready(mc.last_state.z)
                part = {'state_binding': state_binding, 'state': jax.device_get(mc.last_state), 'first': first,
                        'samples': np.asarray(mc.get_samples()), 'extras': {k:np.asarray(v) for k,v in mc.get_extra_fields().items()},
                        'seconds': time.monotonic()-start}
                save_pickle(file, part)
            if part['first'] != first or part['samples'].shape != (count, 2): raise ValueError('Invalid NUTS chunk')
            parts.append(part['samples']); eparts.append(part['extras']); state = part['state']; elapsed += part['seconds']
        samples = np.asarray(decode_batch(jnp.asarray(np.concatenate(parts))))
        ex = {k:np.concatenate([e[k] for e in eparts]) for k in eparts[0]}
        arrays.append(samples); all_extras.append(ex); chain_seconds.append(elapsed)
        save_npz(cd/'samples.npz', samples=samples, **ex)
    chains = np.stack(arrays); extras = {k:np.stack([e[k] for e in all_extras]) for k in all_extras[0]}
    if not np.isfinite(chains).all(): raise FloatingPointError('Nonfinite NUTS reference')
    quality = diagnostics(chains, extras, target, rc)
    quality.update(binding=bind, runtime=rt, chain_seconds=chain_seconds, warmup_leapfrog_steps=total_warmup_steps,
                   production_leapfrog_steps=int(extras['num_steps'].sum()), elapsed_seconds=float(sum(chain_seconds))+coordinate_info.get('chart_setup_seconds',0),
                   reference_coordinates=coordinate_info,
                   initialization='independent N(0,2.25I) draws in declared affine reference coordinates; exact scalar potential including any nonlinear Jacobian; full dense mass adaptation')
    save_npz(directory/'samples.npz', samples=chains.reshape(-1, 2), samples_by_chain=chains, **extras)
    write(directory/'quality.json', quality)
    return read(directory/'quality.json')
