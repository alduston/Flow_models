#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source slurm/environment.sh
G2_CASE="${G2_CASE:-tdoa_pair}"
python submit_vista.py \
  --batch "${G2_BATCH:-../batches/gad_phase2_${G2_CASE}_8k5_seed42_v2}" \
  --case "$G2_CASE" --account "${G2_ACCOUNT:-DMS22021}" "$@"
