#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source slurm/environment.sh
python submit_vista.py \
  --batch "${G2_BATCH:-../batches/gad_phase2_tdoa_seed42_v1}" \
  --case tdoa --account "${G2_ACCOUNT:-DMS22021}" "$@"
