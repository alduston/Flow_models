#!/usr/bin/env bash
# Scheduler resources are supplied explicitly by submit_vista.py.
set -euo pipefail
G2_BATCH="${1:?batch directory}"
shift
cd "$G2_BATCH/code"
source slurm/environment.sh
python -u run.py preflight --out "$G2_BATCH/preflight"
for G2_CASE in "$@"; do
  python -u run.py run --case "$G2_CASE" --out "$G2_BATCH/$G2_CASE"
  python -u run.py export --case "$G2_CASE" --out "$G2_BATCH/$G2_CASE"
done
