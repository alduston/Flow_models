#!/usr/bin/env bash
# Same module/venv defaults as the supplied working Vista campaign.
set -euo pipefail
if [[ "${G2_SKIP_MODULES:-0}" != 1 ]]; then
  module purge
  module load "${G2_GCC_MODULE:-gcc/13.2.0}"
  module load "${G2_PYTHON_MODULE:-python3/3.11.8}"
  source "${G2_VENV_DIR:-${SCRATCH:?Set SCRATCH or G2_VENV_DIR}/venvs/hlsi}/bin/activate"
fi
export OMP_NUM_THREADS="${G2_THREADS:-8}"
export OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS" MKL_NUM_THREADS="$OMP_NUM_THREADS" NUMEXPR_NUM_THREADS="$OMP_NUM_THREADS"
export MPLBACKEND=Agg JAX_ENABLE_X64=true XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION="${G2_JAX_MEM_FRACTION:-0.8}"
