#!/usr/bin/env bash
set -euo pipefail
# Run only after sourcing your working Vista environment. Preserve its GPU JAX.
python -c 'import jax; print("Keeping JAX",jax.__version__,jax.devices())'
python -m pip install 'numpyro==0.15.3' 'arviz==0.22.0'
python -c 'import jax,numpyro,arviz; print(jax.__version__,numpyro.__version__,arviz.__version__,jax.devices())'
