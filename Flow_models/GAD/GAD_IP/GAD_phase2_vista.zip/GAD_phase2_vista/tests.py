"""Numerical checks for the scientific failure modes, not output-shape snapshots."""
import numpy as np
import jax.numpy as jnp
from models import Target
from prepare import derivative_check, gaussian_control
from vendor.lfgi import score_batch
from vendor.mala import mala_step

def numerical_tests():
    records = {}
    for case in ['logistic_clustered','logistic_dispersed','tdoa','tdoa_soft','tdoa_control','binding']:
        target = Target(case)
        records[case] = derivative_check(target,[np.zeros(2), np.array([.15,-.12])])
        # Independent formula validates physical parameter order and forward convention.
        x = np.array([.2,-.1]); p = target.parameters(x[None])[0]; at = np.array(target.data['design'])
        if case.startswith('tdoa'):
            radius=target.data['sensor_radius_m']; phi=target.data['reference_angle_radians']
            reference=radius*np.array([np.cos(phi),np.sin(phi)]); receivers=radius*np.column_stack([np.cos(at),np.sin(at)])
            expected=(np.sqrt(np.sum((p-receivers)**2,axis=1)+1e-18)-np.sqrt(np.sum((p-reference)**2)+1e-18))*1e6/target.data['sound_speed_m_per_s']
            cov=np.array(target.data['noise_covariance']);np.testing.assert_allclose(cov,target.data['arrival_time_noise_sd_microseconds']**2*(np.eye(len(at))+np.ones((len(at),len(at)))))
        elif case=='binding':
            a,b=p; expected=(a*at+2*a*b*at*at)/(2*(1+a*at+a*b*at*at))
        else:
            K,r=p; expected=K/(1+(K/target.data['initial_population']-1)*np.exp(-r*at))
        np.testing.assert_allclose(np.asarray(target.forward(jnp.asarray(x))),expected,rtol=2e-13,atol=1e-13)
    rng=np.random.default_rng(1); m=np.array([.5,-.8]); C=np.array([[.025,.014],[.014,.04]]); H=np.linalg.inv(C)
    bank=rng.multivariate_normal(m,C,37); score=-(bank-m)@H; hs=np.tile(H,(len(bank),1,1)); query=rng.normal(size=(13,2))
    gaussian_errors=[]
    for t in [1e-10,1e-6,.001,.1,1.,10.]:
        actual,_=score_batch(jnp.asarray(query),t,jnp.asarray(bank),jnp.asarray(score),jnp.asarray(hs))
        a=np.exp(-t);g=-np.expm1(-2*t); expected=-(query-a*m)@np.linalg.inv(a*a*C+g*np.eye(2))
        err=np.linalg.norm(np.asarray(actual)-expected)/max(1.,np.linalg.norm(expected));gaussian_errors.append(err)
        assert err<2e-10,(t,err)
    ctl=gaussian_control(m,C,10.,1e-7,300);assert ctl['max_relative_variance_error']<.01
    from reference_coordinates import tdoa_chart
    import jax
    chart,logjac,inverse=tdoa_chart(Target('tdoa'))
    for q in [np.array([.2,.4]),np.array([-.4,-.6]),np.array([.7,0.])]:
        x=np.asarray(chart(jnp.asarray(q)));np.testing.assert_allclose(inverse(x),q,atol=1e-11)
        np.testing.assert_allclose(float(logjac(q)),float(jnp.linalg.slogdet(jax.jacfwd(chart)(jnp.asarray(q)))[1]),atol=1e-11)
    # Detailed-balance algebra in whitened Gaussian coordinates; finite MH target.
    def cb(x):return -.5*np.sum(x*x,1),-x
    x=rng.normal(size=(20000,2));lp,s=cb(x);y,_,_,info=mala_step(x,lp,s,cb,.2,rng)
    assert np.linalg.norm(y.mean(0))<.04 and np.linalg.norm(np.cov(y.T)-np.eye(2))<.06
    # Rejections must be preserved; no unique()/trailing-window output transformation.
    _,_,_,bad=mala_step(x,lp,s,lambda z:(np.full(len(z),-np.inf),np.zeros_like(z)),.2,rng)
    assert bad['accepted']==0
    return {'passed':True,'derivative_checks':records,'Gaussian_LFGI_relative_errors':gaussian_errors,'Heun_control':ctl,'MALA_stationarity_check':info}

if __name__=='__main__':
    from common import clean
    import json
    print(json.dumps(clean(numerical_tests()),indent=2))
