# Scientific specification and source lock

## Selection

The attached new-families report recommends binding/logistic as its cheapest source-grounded tests, and TDOA localization as an analytic geometry calibration. We screened before comparing sampler rankings. Binding with the declared lognormal priors almost straightened in log affinities. The source-preserving logistic case has appreciable anisotropy but modest projector rotation in its bounded coordinates. The TDOA case has a connected curved range-difference constraint in Cartesian position coordinates and is the first full pilot.

Two families are implemented for study: TDOA and logistic growth. Binding is retained only to make the negative prescreen reproducible. These are 2D mechanism tests; higher-dimensional kinetic/seismic/PDE relevance remains subsequent work. No new theory is introduced.

## 1. Acoustic TDOA localization

Infer source position s=(s_x,s_y) in meters. The reference microphone sits at angle 200 degrees on a circle of radius 1.2 m; the other microphone is at 10 degrees. Geometry is fixed before sampling. The optional control adds microphones at 85 and 130 degrees. Sound speed is known, c=343 m/s.

F_j(s) = (||s-r_j|| - ||s-r_0||) * 1e6 / c, in microseconds.

The Gaussian prior is s ~ N((0,1), 1.5^2 I). Samplers use x=(s-(0,1))/1.5; no nonlinear chart is used for the target. A 1e-9 m range regularization keeps the derivative defined exactly at a sensor; it is negligible at the observation noise scale and is applied to every method.

Each receiver arrival timestamp has independent noise SD 15 microseconds. Taking differences from a shared reference gives exact covariance Gamma=15^2 (I+11^T), including the off-diagonal terms in the optional multi-sensor control. The scalar posterior energy uses a Cholesky whitening of this covariance. Seed-42 arrival errors and the declared source (0.65,1.3) generate the frozen observations. Truth is used for generation/plots only, never for optimization or sampler initialization.

One range difference constrains a hyperbola branch, with the proper spatial prior making the posterior normalizable. This is deliberately an underinstrumented localization problem, appropriate for checking the geometric mechanism; it is not a claim of high-dimensional difficulty. The four-microphone control asks what remains after additional physical measurements resolve that uncertainty.

Predeclared observables are distance to the fixed search center (0,2) m and source height s_y. Report their full distributions, probability of lying within 1 m of the search center (complement of the saved upper tail), and P(s_y>0). Held-out predictions are TDOAs for receivers around the same fixed circle, including angles not observed.

Sources: Park and Kotun, *Spectral coherence and hyperbolic solutions applied to time difference of arrival localisation*, Applied Acoustics 136 (2018), 149-157, [publisher record](https://www.sciencedirect.com/science/article/pii/S0003682X17301664). Also see [Robust Time-Difference-of-Arrival Localization Using Weighted Least Squares with Cone Tangent Plane Constraint, Sensors 18 (2018), 778](https://doi.org/10.3390/s18030778). The equation and instrument model motivate this proposed synthetic experiment; these coordinates and data are not a reproduction of either paper's experiment.

The independent NUTS reference uses the known single-pair measurement geometry as an exact change of coordinates. Let a be half the sensor spacing, Y the perpendicular coordinate, and delta the range difference. In the sensor frame, X=-(delta/2) sqrt(1+Y^2/(a^2-delta^2/4)). Set delta=2a tanh(eta), Y=1.5 v. The implementation includes the exact determinant of this map into prior-whitened Cartesian coordinates, verified against automatic differentiation and against independent Cartesian quadrature. The chart is used only by NUTS; its output is mapped back before every diagnostic. It excludes only measure-zero focal rays. This repairs reference divergences, and explicitly demonstrates that a problem-native chart can remove much of the 2D sampling difficulty. The result should therefore be interpreted as a Cartesian-sampler calibration, with the chart disclosed.

## 2. Logistic growth: published data-design contrast

Population x(t)=K/[1+(K/x0-1) exp(-r t)], with known x0=0.1. The nominal values are K=17.5 and r=0.7. Clustered observations use t=(6,7,8); the control uses t=(2,7,23). Both use additive Gaussian noise SD 0.4 and the published physical priors K~Uniform(0.1,200), r~Uniform(0,10). Observations are new, frozen seed-42 draws. The legacy author code uses 24 instead of 23 in the dispersed design; we follow the article's figure for that one time.

Use an exact bounded-coordinate map p_i=l_i+(u_i-l_i) sigmoid(c x_i), c=pi/sqrt(3). A physical uniform prior becomes a logistic density with unit variance in x_i. The negative log prior, up to a constant, is softplus(c x_i)+softplus(-c x_i). This includes the transformation Jacobian exactly. Its exact Hessian is added to the likelihood GN matrix; replacing it by an identity would define the wrong target geometry. No coordinate Gaussian prior is substituted for the published uniform physical prior.

Predeclared observables are population at held-out t=15 and time to reach 90% of the carrying capacity. Tail thresholds are 20 population units and 12 time units. The complete predicted trajectory through t=30 is also plotted. Strong parameter compensation does not imply every predictive quantity is uncertain; the plots test that distinction.

Primary sources: [Daly et al. (2018), J. R. Soc. Interface 15:20180318](https://doi.org/10.1098/rsif.2018.0318), [open article](https://pmc.ncbi.nlm.nih.gov/articles/PMC6073654/), and the [author's Logistic.py](https://github.com/Chaste/project_DalyID/blob/master/test/Logistic.py). The original model, nominal values, priors and SD are verified against that code. The [Chaste project tutorial](https://chaste.github.io/docs/paper-tutorials/dalyid/) supplies the original execution/source locator. The analytic solution avoids installing the legacy Chaste/CVODE stack.

## Screen and fairness protocol

The selection screen uses 32 representative independent-reference points in the actual sampling coordinates. It measures the noise-whitened likelihood GN spectrum, rank-one projector gap, angles from the MAP normal and angles between nearby reference points. The rank-one subspace is interpreted only with a usable spectral gap; the multiple-informed-direction negative control is not forced into that picture.

A main geometry candidate requires median likelihood eigenvalue ratio >=10, gap ratio >=3 at 80% of audit points, and 90th-percentile MAP-normal rotation >=10 degrees. These thresholds are prespecified screening rules, not guarantees of a sampler benefit. They are never selected from a GAD/pMALA ranking.

Reference quality checks cover the two parameters and both scientific observables, including bulk/tail ESS, rank R-hat, divergences, tree-depth saturation and E-BFMI. Two-dimensional quadrature is independently refined twice and checked for boundary probability; mean/covariance/tail agreement tests are saved. A diagnostic oracle never initializes GAD or pMALA.

GAD and pMALA share only a charged truth-blind multi-start MAP and exact MAP Hessian. They draw independently from the same Laplace law. GAD queries the exact score and exact-prior-plus-likelihood-GN curvature at each round's bank and reuses it during transport. No score query is made at a reverse trajectory point. The source's stable q-LFGI algebra and Heun transition are ported verbatim; `provenance.json` names the source archive and hashes.

pMALA uses the full MAP metric, a short norm-guarded, acceptance-tuned warmup, and all production states, including rejected repeats. It records one continuous production history, with checkpoints at each cumulative GAD request cap. Equal-size cloud metrics stratify the full history; physical moments and QoIs use the full history. A bounded continuation also produces elapsed-time checkpoints, with actual undershoot or limit failure reported rather than calling a shorter run fully matched.

The endpoint is selected from the narrowest MAP covariance direction and verified against the reference. The deterministic Gaussian control propagates the exact mean/covariance of the actual Heun scheme, including its correlated predictor/corrector noise, and refines the grid only on failure. There is no terminal denoising or hidden MAP-Gaussian correction.

If the independent reference check exceeds the 1% tolerance, the endpoint alone is tightened to a 0.5% reference-scale margin and its Gaussian grid control is repeated. This repair is applied only with a passing reference/quadrature check and is saved separately. The reference covariance is never used as a sampler initial covariance, pMALA metric, GAD bank or score input.

The curvature audit compares four reference, four first-bank and four last-bank points. Its solve-scaled residual norm is explicitly a **pointwise proxy**, not a conditional average over a bank. Conditional ESS and actual solve guarding are logged separately.
