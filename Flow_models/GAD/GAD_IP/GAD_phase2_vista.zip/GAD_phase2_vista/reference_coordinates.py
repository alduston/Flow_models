"""Exact, reference-only coordinates for a single-pair TDOA posterior.

The chart uses the measured range difference and the perpendicular coordinate.
It is a bijection off two measure-zero focal rays and includes its exact
Jacobian. It does not change the posterior or the coordinates used by GAD/MALA.
"""
import time
import numpy as np
import jax
import jax.numpy as jnp
from scipy.optimize import minimize
from common import log

def tdoa_chart(target):
    d = target.data; radius = d['sensor_radius_m']; p0=d['reference_angle_radians']; p1=d['design'][0]
    r0=radius*np.array([np.cos(p0),np.sin(p0)]);r1=radius*np.array([np.cos(p1),np.sin(p1)])
    midpoint=(r0+r1)/2; axis=(r1-r0)/np.linalg.norm(r1-r0);normal=np.array([-axis[1],axis[0]])
    a=np.linalg.norm(r1-r0)/2; sy=float(np.asarray(target.scale).mean())
    mj,ej,nj=jnp.asarray(midpoint),jnp.asarray(axis),jnp.asarray(normal)
    def chart(q):
        eta,v=q; Y=sy*v;delta=2*a*jnp.tanh(eta);b=a*a/(jnp.cosh(eta)**2)
        X=-.5*delta*jnp.sqrt(1+Y*Y/b)
        position=mj+X*ej+Y*nj
        return (position-target.mu)/target.scale
    def log_jacobian(q):
        eta,v=q;Y=sy*v;delta=2*a*jnp.tanh(eta);b=a*a/(jnp.cosh(eta)**2)
        w=jnp.sqrt(1+Y*Y/b)
        dx_ddelta=.5*w+delta*delta*Y*Y/(8*b*b*w)
        return jnp.log(dx_ddelta)+jnp.log(2*a)-2*jnp.log(jnp.cosh(eta))+jnp.log(sy)-jnp.sum(jnp.log(target.scale))
    def inverse(x):
        s=np.asarray(target.mu)+np.asarray(target.scale)*np.asarray(x)
        delta=np.linalg.norm(s-r1)-np.linalg.norm(s-r0)
        return np.array([np.arctanh(np.clip(delta/(2*a),-1+1e-14,1-1e-14)),np.dot(s-midpoint,normal)/sy])
    return chart,log_jacobian,inverse

def coordinates(target,setup,cfg):
    if target.case not in ('tdoa','tdoa_soft') or cfg['reference'].get('tdoa_chart',True) is False:
        m,L=jnp.asarray(setup['center']),jnp.asarray(setup['factor'])
        def decode(z):return m+L@z
        def potential(z):return target.energy(decode(z))
        return decode,potential,{'coordinates':'affine exact-MAP coordinates','exact_target':True}
    start=time.monotonic();chart,logjac,inverse=tdoa_chart(target)
    def energy(q):return target.energy(chart(q))-logjac(q)
    objective=jax.jit(jax.value_and_grad(energy));q0=inverse(setup['center'])
    def callback(q):
        e,g=objective(jnp.asarray(q));return float(e),np.asarray(g)
    opt=minimize(callback,q0,jac=True,method='BFGS',options={'maxiter':500,'gtol':1e-7})
    center=opt.x;H=np.asarray(jax.hessian(energy)(jnp.asarray(center)));e,V=np.linalg.eigh(H)
    floor=max(1e-6,np.max(np.abs(e))/1e8);L=V/np.sqrt(np.maximum(e,floor));m,Lj=jnp.asarray(center),jnp.asarray(L)
    def decode(z):return chart(m+Lj@z)
    def potential(z):return energy(m+Lj@z)
    # Verify the analytic determinant against AD independently of NUTS.
    errors=[]
    for q in [center,center+np.array([.01,.7]),center+np.array([-.01,-.7])]:
        automatic=float(jnp.linalg.slogdet(jax.jacfwd(chart)(jnp.asarray(q)))[1]);analytic=float(logjac(jnp.asarray(q)))
        errors.append(abs(automatic-analytic))
    if max(errors)>1e-9:raise AssertionError('Reference chart Jacobian check failed')
    log('TDOA reference uses exact range-difference chart with verified Jacobian')
    info={'coordinates':'range-difference/perpendicular chart, affine-whitened at its own MAP; reference only',
          'exact_target':True,'jacobian_max_logdet_error':max(errors),'chart_center':center,'chart_factor':L,
          'chart_MAP_objective_calls':int(opt.nfev),'chart_MAP_gradient_norm':float(np.linalg.norm(opt.jac)),
          'chart_setup_seconds':time.monotonic()-start,
          'caveat':'An explicit problem-native chart makes this 2D reference easy. The benchmark tests Cartesian samplers; it does not claim resistance to every nonlinear reparameterization.'}
    return decode,potential,info
