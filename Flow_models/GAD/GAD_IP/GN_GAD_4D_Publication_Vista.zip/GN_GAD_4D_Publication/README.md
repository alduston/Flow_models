# 4D publication run: three rounds, Laplace-start pMALA only

Seeds 42–46; 2,000 bank particles × 3 GN-GAD rounds. One shared four-chain NUTS reference. GN-GAD retains the 50% prior / 50% MAP-Laplace entry; the only MCMC comparator is exact MAP-Hessian-preconditioned pMALA with Laplace initialization. MAP-Laplace and crossfit Moment Gaussian remain offline diagnostic baselines.

## Submit

```bash
python submit_vista.py \
  --batch "$SCRATCH/gad_4d_5seed_N2000_R3_laplace_v1" \
  --python "$SCRATCH/venvs/gad4_publication/bin/python" \
  --account DMS22021 --max-inflight 2
```

Use a NEW batch path: source/configuration differ from the four-round campaign. The source is frozen at BATCH/code, and all output goes to BATCH/results. The scheduler graph is prepare → reference chains (0–3%2) → qualified reference merge → sampler seeds (0–4%2) → report/export. Existing Python-module/shared-library startup repairs and Vista submission-banner parsing are retained.

The NUTS reference remains 3,000 warmup + 10,000 retained draws per chain, target_accept 0.995, max depth 12, with the original strict quality gates. It is shared across all five seeds. Primary matching is E+G+H: the final bank budget is 18,000 requests plus each seed's charged MAP setup. pMALA initialization, eight-chain 256-step warmup, all proposals and rejections are charged. Its final checkpoint has 6,944 production states. Timing is supplementary.

Fresh 8,192-output draws from the saved round-one and round-three input fields support smooth figures and separate fresh-field metrics; they do not rebuild a bank or add a target update. All non-reference histogram panels use 6,944 states at the final cap; NUTS retains all reference draws. Primary cloud metrics remain capped at 2,000 (944 at round one due to charged pMALA warmup), matched across methods. Mean±sample SD is across five sampler seeds on ONE frozen dataset.

## Status and outputs

```bash
python "$SCRATCH/gad_4d_5seed_N2000_R3_laplace_v1/code/status_vista.py" \
  --batch "$SCRATCH/gad_4d_5seed_N2000_R3_laplace_v1"
```

Final artifacts: results/GN_GAD_4D_PAPER_RESULTS.zip and results/report/GN_GAD_4D_DASHBOARD.pdf, including separate PDF/PNG panels, caption index, CSV/LaTeX tables, physical/held-out prediction checks, reference qualification and provenance. Raw arrays/checkpoints remain in the results directory. Optional full export: `run.py export --out BATCH/results --checkpoints`.

For an unchanged interrupted batch, use the same submit command with --resume after its jobs have stopped. For an accepted but partially recorded scheduler graph, --continue-batch reuses the frozen batch settings and submits only missing stages. --adopt-prepare JOBID can recover an accepted preparation whose ID was not recorded. These operations refuse duplicate live jobs or failed dependencies as appropriate.

The original target, models.py, samplers.py, vendor/lfgi.py and primary data remain byte-identical to the uploaded audit. See validation/VALIDATION.md for local test scope. The three-round endpoint was chosen after reviewing the two-seed Colab pilot; this five-seed run is the subsequent confirmation, not an independently preselected endpoint.
