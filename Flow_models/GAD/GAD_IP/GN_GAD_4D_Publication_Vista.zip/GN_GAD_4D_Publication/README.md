# 4D acoustic source inversion: publication confirmation on Vista

**Frozen original 4D primary target. Seeds 42–46. 2,000 bank particles × four GN-GAD rounds.** No new path, acquisition, noise, or prior is selected in this bundle. The original models.py, samplers.py, vendor/lfgi.py, data/primary.json and data/basis.npz are preserved byte for byte from the attached 4D pilot.

## Submit tonight

Unzip, enter `GN_GAD_4D_Publication`, and use the Python executable in an existing compatible JAX GPU environment:

```bash
python3 submit_vista.py \
  --batch "$SCRATCH/gad_4d_5seed_N2000_R4_v1" \
  --python /absolute/path/to/your/JAX-env/bin/python \
  --account DMS22021 --max-inflight 2
```

Replace the Python path. This explicit path bypasses module/venv activation in the job script. The expected versions are JAX/JAXlib 0.6.2, NumPyro 0.19.0, NumPy 2.2.6 and ArviZ 0.22.0; the pinned requirements are included. Float64 GPU execution is checked before every job. A compatible existing environment is preferred over another installation.

If using the original pilot's module/venv workflow, export `GAD4_VENV_DIR=/absolute/path/to/env` and omit `--python`. The supplied `install_vista_env.sh` can create a new environment after loading the appropriate GCC/Python modules; its module names are inherited defaults and may need to match your installation. `run_first_vista.sh` supplies the default account/batch path and also accepts `--python`.

Use `--dry-run` to inspect the graph without submitting. The graph is **prepare → four shared reference chains → qualified merge → five sampler seeds → aggregate report/export**. At most two jobs run concurrently by default; `--max-inflight 4` is supported. Seeds are isolated, and both pMALA starts run sequentially within each seed, avoiding the earlier shared-lock race. No cluster jobs have been submitted by this delivery.

The submitter freezes an exact source snapshot at `BATCH/code`; results are `BATCH/results`, and stage/array logs are at the batch root. Changing code/configuration requires a new batch. An interrupted unchanged batch can be resubmitted with the same command plus `--resume`, after its live jobs have stopped. Completed bank rounds, pMALA checkpoints, reference chunks and frozen-output chunks are reused. Warmup restarts if interrupted before its checkpoint. Known dependency-blocked jobs belonging to that failed batch are cleared on resume; active campaign jobs prevent duplicate submission.

## Check progress / retrieve results

```bash
/absolute/path/to/your/JAX-env/bin/python \
  "$SCRATCH/gad_4d_5seed_N2000_R4_v1/code/run.py" status \
  --out "$SCRATCH/gad_4d_5seed_N2000_R4_v1/results"
```

Final deliverables:

- `BATCH/results/GN_GAD_4D_PAPER_RESULTS.zip`: publication figures, separate scalar panels, CSVs, a LaTeX table, audit metadata and available batch logs.
- `BATCH/results/report/GN_GAD_4D_DASHBOARD.pdf`: review dashboard.
- `BATCH/results/report/tables/figure_index.csv`: captions and main-figure candidates.
- `paper_final_table.csv` / `.tex`, `paired_final_comparisons.csv`, and complete `per_seed_metrics.csv` / `per_seed_events.csv`.

Actual particles and sampler states remain in the campaign directory. A complete checkpoint ZIP can be requested using `run.py export --out BATCH/results --checkpoints`. Compact paper exports intentionally omit large binary checkpoints. On a failure you can still use `run.py export` to collect existing metadata/logs without launching any sampler.

## What is being compared

The four unknowns are center position and half-displacement in two axes: `s(t)=c+((t−5)/5)d`, with c SD 1.5 m and d SD 0.5 m per axis. Four pulse timestamps and 480 µs arrival noise are exactly the original primary case. The target retains the exact physical score and uses GN only for curvature. No alternate acquisition case runs by default.

Mainline GN-GAD uses 50% proper-prior / 50% truth-blind MAP-Laplace entry. Both fixed exact-MAP-Hessian pMALA starts (mixed and pure Laplace) use the same charged multistart MAP setup for each seed. pMALA pays eight-chain initialization, 256 warmup transitions per chain, every production proposal and every rejection. Full production histories, including repeat states, are retained. Reference setup is independent and excluded from competing methods; every method pays its complete own setup allowance.

Frontline cost is **W = E+G+H**. A 2,000-point bank costs 6,000 requests per round, so the endpoint is **24,000 requests plus charged setup** for each seed. Both pMALA starts are checkpointed at every GAD cap. Timing is supplementary and is not described as time matching. Oracle requests do not equate different derivatives' actual FLOPs.

One shared four-chain NUTS reference serves all five seeds: 3,000 warmup + 10,000 retained draws per chain, target_accept 0.995, max depth 12. Native affine coordinates and full-target reference-only reflection MH moves are unchanged. Neither comparator receives reflection moves. Rank Rhat ≤1.01, bulk ESS ≥1,000, tail ESS ≥400, no divergences, E-BFMI ≥0.3, depth checks and event MCSE ≤0.005 gate all seed jobs. A failed reference stops the dependency graph and preserves diagnostics.

## Particle counts, smooth figures and uncertainty

Primary SW2/MMD clouds are capped at 2,000 states. At round one, charged pMALA warmup leaves **944 production states**, so **all three methods use 944 states for that checkpoint's cloud metrics**. Later primary checkpoints use 2,000. Means, covariance, likelihood fit and event estimates retain each method's entire output/history. Effective counts and count-matched reference cloud floors are exported, rather than comparing unequal SW2 noise floors.

Fresh 8,192-sample outputs are drawn from the saved **round-one and round-four input fields**, with no target requests, bank update, terminal projection or additional round. Round four uses the field learned from round three. These draws support smooth figures and a separate high-resolution metric view, with its own common state cap (at most 4,096). At the final cap pMALA has **9,944 production states** per start; all non-reference midpoint histograms show 8,192 states selected across their full histories. NUTS uses all reference draws. Equal count does not imply equal MCMC ESS.

Main plots show **mean ± sample SD over five sampler seeds on one frozen dataset**. No dataset-replication claim is made. Event CSVs separately report MCMC dependence-aware within-run MCSE for pMALA and conditional output SE for GAD; neither is substituted for variability in learning the GAD field. The main histogram seed is **42, fixed before results**; every other seed is provided separately. Gaussian controls include MAP-Laplace and a crossfit moment Gaussian fitted from one reference-chain group and evaluated against another. The latter is diagnostic, not an admissible sampler.

Scientific checks include exact continuous-path height/residence/closest-approach/displacement QoIs, all three event probabilities, pointwise path intervals, likelihood residual fit, and predictions at a third microphone absent from the likelihood. Offline audits report physical width, GN/exact-Hessian discrepancy and conditional bank support. Audit calls never initialize or precondition competing samplers and are excluded from their request ledgers. Fresh-output time is separately itemized.

This is a confirmation run of a selected target. Results are not assumed to favor GAD: all five seeds, both pMALA starts, failed accuracy checks and Gaussian controls remain in the exports. See `validation/VALIDATION.md` for what was actually checked locally.
