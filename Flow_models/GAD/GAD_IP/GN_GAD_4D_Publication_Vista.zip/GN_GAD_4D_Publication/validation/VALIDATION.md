# Validation status

Passed locally using CPU float64, JAX 0.6.2 / NumPyro 0.19.0:

- Original 4D target/gradient/residual Jacobian/GN tests; covariance sharing and alternative-case consistency; exact constant-velocity QoIs; native reflection checks; Gaussian LFGI checks in 2D/4D/16D; actual MH stationarity checks; numerical endpoint controls.
- Complete two-seed smoke pipeline with one four-chain reference, two 64-particle GAD rounds, both pMALA starts, fresh 256-output first/final fields, within-run MCSEs, held-out predictions, all reports and compact export. Smoke references are always provisional.
- GAD, pMALA and GN-MALA interrupted-restart tests: samples and request ledgers agree bit for bit with uninterrupted execution. GN-MALA is tested but is not run in the publication campaign.
- Actual eight-chain / 256-warmup pMALA runs at the production request caps, for both starts: retained state counts 944, 3,944, 6,944 and 9,944, with zero unused requests at each cap.
- Frozen-field display interruption after a saved integration chunk: restart produces exactly the same samples as uninterrupted generation.
- Mock Slurm submission: five-stage afterok graph; reference arrays 0–3%2; seed arrays 0–4%2; explicit Python forwarding; frozen snapshot; live-job duplicate protection; resume; changed-case rejection. No real cluster jobs were submitted.
- Publication PDF/PNG outputs visually inspected. Final renderer was retested against the saved smoke clouds after layout/color-scale changes; production figures use the reference-defined common color scale and flag saturation. The atomic multipage PDF retained a complete trailer after process exit.

The final production target, models.py, samplers.py and vendor/lfgi.py are byte-identical to the uploaded audit. The source hash in the smoke campaign records the exact tested training snapshot; final reporting-only refinements were exercised as a separate postprocessor of those verified saved arrays. No validation result is presented as a production 2,000×4 GPU outcome. Original archived CPU preview particles/figures are not shipped or substituted for new results.

The publication campaign still needs execution on Vista. Its strict reference gates apply before any confirmation seed starts. Mean±SD in final figures is across five sampler seeds on a single frozen dataset, and a comparative advantage is not assumed in advance.
