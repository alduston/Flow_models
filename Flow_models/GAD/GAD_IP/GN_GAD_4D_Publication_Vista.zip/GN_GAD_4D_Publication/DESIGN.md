# Three-round confirmation

Original 4D acoustic target and sampler kernels retained. GN-GAD uses 2,000 particles and three rounds with mixed prior/Laplace entry. Only Laplace-start MAP-Hessian pMALA competes at matched E+G+H budgets. Diagnostic Gaussian controls are retained. Fresh round-three display draws use the saved round-three bank, learned from round-two output, with no additional target update. The reference and five sampler seeds are unchanged.
