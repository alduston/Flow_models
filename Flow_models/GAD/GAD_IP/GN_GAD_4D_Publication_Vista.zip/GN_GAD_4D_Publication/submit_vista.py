#!/usr/bin/env python3
"""Freeze a source snapshot and submit a bounded dependency graph. stdlib only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n');os.replace(tmp,path)
def inputs():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.json','.npz','.sh','.txt','.md'))

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--batch',required=True,type=Path);ap.add_argument('--python',type=Path,help='Absolute Python executable in an existing compatible GPU environment; bypass module activation')
    ap.add_argument('--profile',default='vista',choices=['vista','kaggle','confirm','smoke']);ap.add_argument('--case',default='primary',choices=['primary','narrow','wide','informative'])
    ap.add_argument('--account',default='DMS22021');ap.add_argument('--partition',default='gh');ap.add_argument('--max-inflight',type=int,default=2)
    ap.add_argument('--sampler-time',default='06:00:00');ap.add_argument('--reference-time',default='06:00:00');ap.add_argument('--resume',action='store_true');ap.add_argument('--dry-run',action='store_true')
    a=ap.parse_args();batch=a.batch.resolve()
    if a.python is not None:
        a.python=a.python.absolute()
        if not a.python.is_file():raise SystemExit('--python does not identify an executable file')
    if a.max_inflight<1 or a.max_inflight>4:raise SystemExit('--max-inflight must be between 1 and 4')
    cfg=json.loads((ROOT/f'profiles/{a.profile}.json').read_text());hashes={str(p.relative_to(ROOT)):digest(p) for p in inputs()}
    identity={'schema':1,'profile':a.profile,'case':a.case,'seeds':cfg['seeds'],'input_hashes':hashes,'account':a.account,'partition':a.partition,'max_inflight':a.max_inflight,'python':str(a.python) if a.python else None}
    old=None
    if (batch/'submission.json').exists():
        old=json.loads((batch/'submission.json').read_text())
        if not a.resume:raise SystemExit('Batch exists. Use --resume for unchanged inputs, or a NEW batch path.')
        if old['identity']!=identity:raise SystemExit('Changed source/config/scheduling identity. Use a NEW batch path.')
    elif batch.exists() and any(batch.iterdir()):raise SystemExit('Refusing to freeze into a nonempty unbound batch directory.')
    graph=[('prepare',None,None,'00:30:00'),('chains','prepare',f'0-{cfg["reference"]["chains"]-1}%{a.max_inflight}',a.reference_time),
           ('reference-merge','chains',None,'00:30:00'),('seeds','reference-merge',f'0-{len(cfg["seeds"])-1}%{a.max_inflight}',a.sampler_time),('report','seeds',None,'01:00:00')]
    if a.dry_run:
        for stage,parent,array,wall in graph:
            cmd=['sbatch','--account',a.account,'--partition',a.partition,'--nodes','1','--ntasks','1','--cpus-per-task','8','--time',wall]
            if array:cmd+=['--array',array]
            if parent:cmd+=['--dependency',f'afterok:<{parent}_jobid>']
            cmd += [str(batch/'code/slurm/job.sh'),str(batch),stage,a.profile,a.case,str(a.python) if a.python else '']
            print(shlex.join(cmd))
        print('DRY RUN: no files written and no jobs submitted.');return
    if old:
        tracked=[str(v) for v in old.get('jobs',{}).values()]
        if tracked:
            q=subprocess.run(['squeue','-h','-j',','.join(tracked),'-o','%A|%T|%r'],text=True,capture_output=True)
            if q.returncode and 'Invalid job id' not in q.stderr:raise RuntimeError('Could not inspect existing jobs: '+q.stderr)
            lines=[x for x in q.stdout.splitlines() if x.strip()];active=[x for x in lines if 'DependencyNeverSatisfied' not in x]
            if active:raise SystemExit('This exact batch still has live jobs; refusing duplicates:\n'+'\n'.join(active))
            # Only known dependency-blocked jobs from THIS failed graph are obsolete.
            blocked={x.split('|')[0] for x in lines}
            if blocked:subprocess.run(['scancel',*sorted(blocked)],check=True)
    batch.mkdir(parents=True,exist_ok=True);code=batch/'code'
    if not code.exists():
        for p in inputs():
            dst=code/p.relative_to(ROOT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
    for rel,h in hashes.items():
        if digest(code/rel)!=h:raise SystemExit('Frozen snapshot mismatch: '+rel)
    record={'identity':identity,'jobs':{}};write(batch/'submission.json',record)
    for stage,parent,array,wall in graph:
        cmd=['sbatch','--parsable','--account',a.account,'--partition',a.partition,'--nodes','1','--ntasks','1','--cpus-per-task','8','--time',wall,
             '--job-name','g4pub_'+stage,'--output',str(batch/(stage+'-%A_%a.log'))]
        if array:cmd+=['--array',array]
        if parent:cmd+=['--dependency','afterok:'+record['jobs'][parent]]
        cmd += [str(code/'slurm/job.sh'),str(batch),stage,a.profile,a.case,str(a.python) if a.python else '']
        answer=subprocess.check_output(cmd,text=True).strip();jid=answer.split(';')[0]
        if not jid.isdigit():raise RuntimeError('Unrecognized sbatch answer: '+answer)
        record['jobs'][stage]=jid;write(batch/'submission.json',record);print(stage,jid,flush=True)
    print('Batch:',batch);print('Status: python '+str(code/'run.py')+' status --out '+str(batch/'results'))

if __name__=='__main__':main()
