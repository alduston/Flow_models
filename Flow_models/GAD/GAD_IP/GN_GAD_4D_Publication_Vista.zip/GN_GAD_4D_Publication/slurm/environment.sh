#!/usr/bin/env bash
set -euo pipefail
if [[ "${GAD4_SKIP_MODULES:-0}" != 1 ]]; then
  module purge
  module load "${GAD4_GCC_MODULE:-gcc/13.2.0}"
  module load "${GAD4_PYTHON_MODULE:-python3/3.11.8}"
  source "${GAD4_VENV_DIR:-${SCRATCH:?Set SCRATCH or GAD4_VENV_DIR}/venvs/gad_trajectory4}/bin/activate"
fi
export OMP_NUM_THREADS="${GAD4_THREADS:-1}"
export OPENBLAS_NUM_THREADS="$OMP_NUM_THREADS" MKL_NUM_THREADS="$OMP_NUM_THREADS" NUMEXPR_NUM_THREADS="$OMP_NUM_THREADS"
export JAX_ENABLE_X64=true JAX_PLATFORMS=cuda XLA_PYTHON_CLIENT_PREALLOCATE=false MPLBACKEND=Agg PYTHONUNBUFFERED=1
