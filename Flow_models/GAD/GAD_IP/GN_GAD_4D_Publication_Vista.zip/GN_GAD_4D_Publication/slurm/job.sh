#!/usr/bin/env bash
set -euo pipefail
GAD4_BATCH="${1:?batch directory}"; GAD4_STAGE="${2:?stage}"; GAD4_PROFILE="${3:?profile}"; GAD4_CASE="${4:?case}"
cd "$GAD4_BATCH/code"
if [[ -n "${5:-}" ]]; then
  GAD4_PY="$5"
  export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
  export JAX_ENABLE_X64=true JAX_PLATFORMS=cuda XLA_PYTHON_CLIENT_PREALLOCATE=false MPLBACKEND=Agg PYTHONUNBUFFERED=1
else
  source slurm/environment.sh
  GAD4_PY="$(command -v python)"
fi
unset PYTHONPATH PYTHONHOME
"$GAD4_PY" -c 'import jax; assert jax.config.x64_enabled and len(jax.devices())==1 and jax.devices()[0].platform=="gpu",str(jax.devices()); print(jax.devices())' 
GAD4_OUT="$GAD4_BATCH/results"
case "$GAD4_STAGE" in
  prepare)
    "$GAD4_PY" -u run.py init --out "$GAD4_OUT" --profile "$GAD4_PROFILE" --case "$GAD4_CASE"
    "$GAD4_PY" -u run.py preflight --out "$GAD4_OUT"
    "$GAD4_PY" -u run.py reference-prepare --out "$GAD4_OUT"
    ;;
  chains)
    "$GAD4_PY" -u run.py reference-chain --out "$GAD4_OUT" --chain "${SLURM_ARRAY_TASK_ID:?array task index}"
    ;;
  reference-merge)
    "$GAD4_PY" -u run.py reference-merge --out "$GAD4_OUT"
    ;;
  seeds)
    GAD4_SEED="$("$GAD4_PY" -c 'import json,sys; print(json.load(open(sys.argv[1]))["config"]["seeds"][int(sys.argv[2])])' "$GAD4_OUT/campaign.json" "${SLURM_ARRAY_TASK_ID:?array task index}")"
    "$GAD4_PY" -u run.py seed --out "$GAD4_OUT" --seed "$GAD4_SEED"
    ;;
  report)
    "$GAD4_PY" -u run.py report --out "$GAD4_OUT"
    "$GAD4_PY" -u run.py export --out "$GAD4_OUT"
    ;;
  *) echo "Unknown stage: $GAD4_STAGE" >&2; exit 2 ;;
esac
