# -*- coding: utf-8 -*-
"""Helmholtz inverse-scattering density-evaluation benchmark.

Refactor of the Helmholtz HLSI script to match the Darcy/Navier-Stokes
density benchmark: build a MALA posterior reference bank, evaluate Tweedie /
scalar blend / CE-HLSI probability-flow normalized-density surrogates on that
same bank, and save one publication-style 3x2 density-energy grid.

Typical repository/Slurm run:

    # Place this file at helmholtz/helmholtz.py.
    # Place the updated shared module at <repo-root>/sampling.py.
    sbatch --export=ALL,PROB=helmholtz run_one.slurm

Useful overrides:

    export IP_DENSITY_N_REF_SIGNAL=5000
    export IP_DENSITY_N_REF_GATE=5000
    export IP_DENSITY_N_REF_EVAL=5000
    export IP_DENSITY_BANK_COUPLING=independent      # shared | prefix | independent
    export IP_DENSITY_EVAL_SOURCE=MALA-EVAL          # use a disjoint density-eval bank
    export IP_DENSITY_EVAL_BANK_COUPLING=independent
    export IP_DENSITY_MALA_INIT=map_laplace
    export IP_DENSITY_MALA_STEPS=600
    export IP_DENSITY_MALA_BURNIN=150
    export IP_DENSITY_MALA_DT=2.5e-5
    export IP_DENSITY_MAP_LAPLACE_STARTS=128
    export IP_DENSITY_MAP_LAPLACE_MAX_ITER=25
    export IP_DENSITY_BASELINES=map_laplace
    export IP_DENSITY_RUN_PF_SENSITIVITY=0
    export IP_DENSITY_DRC_PF_STEPS=32
    export IP_DENSITY_DRC_PLOT_LAYOUT=comparison_grid
"""
import gc
import os
import sys
from collections import OrderedDict

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.20")

try:
    THIS_DIR = os.path.dirname(os.path.abspath(__file__))
except NameError:  # notebook / pasted-cell fallback
    THIS_DIR = os.getcwd()

REPO_ROOT = os.path.dirname(THIS_DIR)
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

import jax
import jax.numpy as jnp
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from scipy.spatial.distance import cdist

# ==========================================
# Dashboard PDF utilities
# ==========================================
# Produces a single multipage PDF containing the scalar metrics tables and every
# figure produced by this script. Console progress logs are intentionally not
# captured into the dashboard.

import glob
import numbers
import re
import shutil
import textwrap
from datetime import datetime
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.image as mpimg



#########################################################################

import sys, importlib, linecache, os

# Make sure the problem directory and repo root are import-visible.
if os.getcwd() not in sys.path:
    sys.path.insert(0, os.getcwd())

# Clear stale source-line cache and stale imported module.
linecache.clearcache()
if "sampling" in sys.modules:
    del sys.modules["sampling"]

# Slurm/repository default: import the shared module as <repo-root>/sampling.py.
# A suffixed module can still be selected explicitly with HLSI_SAMPLING_MODULE,
# but no suffixed helper is required for normal GitHub/Slurm use.
SAMPLING_MODULE_NAME = os.environ.get("HLSI_SAMPLING_MODULE", "sampling")
sampling = importlib.import_module(SAMPLING_MODULE_NAME)
importlib.reload(sampling)
# Preserve the historical module name for downstream `from sampling import ...`.
sys.modules["sampling"] = sampling

print("Using:", sampling.__file__)
print("DRC test:", sampling.canonicalize_init_weights("DRC"))

from sampling import (
    GaussianPrior,
    compute_field_summary_metrics,
    compute_heldout_predictive_metrics,
    compute_latent_metrics,
    configure_sampling,
    get_valid_samples,
    compute_map_laplace_density_baseline,
    make_density_manuscript_table,
    run_drc_pf_sensitivity_benchmark,
    init_run_results,
    make_physics_likelihood,
    make_posterior_score_fn,
    plot_field_reconstruction_grid,
    plot_mean_ess_logs,
    plot_pca_histograms,
    resolve_plot_normalizer,
    run_standard_sampler_pipeline,
    save_reproducibility_log,
    save_results_tables,
    summarize_sampler_run,
    zip_run_results_dir,
)


#########################################################################

SAVE_DASHBOARD_PDF = True
DASHBOARD_SHOW_FIGURES = True
DASHBOARD_PDF_PATH = None  # Filled after init_run_results(), inside the active run-results directory.


def _dashboard_is_scalar_cell(x):
    if x is None:
        return True
    if isinstance(x, (str, bool)):
        return True
    if isinstance(x, numbers.Number):
        return True
    if isinstance(x, np.generic):
        return True
    return False


def _dashboard_format_cell(x, max_len=72):
    if x is None:
        return ""
    try:
        if isinstance(x, np.generic):
            x = x.item()
    except Exception:
        pass
    if isinstance(x, numbers.Number):
        try:
            xf = float(x)
            if not np.isfinite(xf):
                return str(x)
            if abs(xf) >= 1e4 or (0 < abs(xf) < 1e-3):
                return f"{xf:.4e}"
            return f"{xf:.6g}"
        except Exception:
            return str(x)
    if isinstance(x, (list, tuple, dict, np.ndarray)):
        try:
            if isinstance(x, np.ndarray):
                return f"array{tuple(x.shape)}"
            return f"{type(x).__name__}[{len(x)}]"
        except Exception:
            return type(x).__name__
    s = str(x)
    if len(s) > max_len:
        return s[: max_len - 3] + "..."
    return s


def _dashboard_sanitize_df(df, include_index=True):
    df = pd.DataFrame(df).copy()
    if include_index and not isinstance(df.index, pd.RangeIndex):
        df = df.reset_index()
    for col in df.columns:
        df[col] = df[col].map(_dashboard_format_cell)
    df.columns = [_dashboard_format_cell(c, max_len=40) for c in df.columns]
    return df


def metrics_dict_to_scalar_df(metrics_dict, display_names=None):
    """Convert the metrics dictionary into a dashboard-friendly scalar table."""
    display_names = display_names or {}
    rows = []
    for label, data in metrics_dict.items():
        if not isinstance(data, dict):
            continue
        row = OrderedDict()
        row["Method"] = display_names.get(label, label)
        for key, val in data.items():
            if _dashboard_is_scalar_cell(val):
                row[key] = val
        rows.append(row)
    return pd.DataFrame(rows)


def nested_dict_to_df(dct, row_name="Method", display_names=None):
    """Convert nested dict/list records into a table without large arrays."""
    display_names = display_names or {}
    if isinstance(dct, pd.DataFrame):
        return dct.copy()
    rows = []
    if isinstance(dct, dict):
        iterable = dct.items()
    else:
        iterable = enumerate(dct)
    for key, val in iterable:
        row = OrderedDict()
        row[row_name] = display_names.get(key, key)
        if isinstance(val, dict):
            for k, v in val.items():
                if _dashboard_is_scalar_cell(v):
                    row[k] = v
                elif isinstance(v, (list, tuple, np.ndarray)):
                    row[k] = _dashboard_format_cell(v)
                else:
                    row[k] = _dashboard_format_cell(v)
        else:
            row["value"] = _dashboard_format_cell(val)
        rows.append(row)
    return pd.DataFrame(rows)


def sampler_configs_to_df(configs):
    rows = []
    for label, cfg in configs.items():
        row = OrderedDict()
        row["Method"] = label
        row.update(cfg)
        rows.append(row)
    return pd.DataFrame(rows)


class DashboardPDF:
    def __init__(self, path, title="Dashboard"):
        self.path = os.path.abspath(path)
        self.title = title
        self.enabled = bool(SAVE_DASHBOARD_PDF)
        self.pdf = PdfPages(self.path) if self.enabled else None
        self._seen_fig_ids = {id(plt.figure(num)) for num in plt.get_fignums()}
        self.figure_pages = 0
        self.table_pages = 0
        self.text_pages = 0

    def add_text_page(self, title, lines, footer=None, mono=False):
        if not self.enabled:
            return
        if isinstance(lines, str):
            lines = lines.splitlines()
        fig = plt.figure(figsize=(11, 8.5))
        fig.patch.set_facecolor("white")
        ax = fig.add_axes([0, 0, 1, 1])
        ax.axis("off")
        ax.text(0.055, 0.93, title, fontsize=18, fontweight="bold", va="top")
        y = 0.86
        fontsize = 9.2 if mono else 10.5
        family = "monospace" if mono else "sans-serif"
        for raw in lines:
            wrapped = textwrap.wrap(str(raw), width=112 if mono else 105) or [""]
            for line in wrapped:
                ax.text(0.06, y, line, fontsize=fontsize, family=family, va="top")
                y -= 0.033 if mono else 0.038
                if y < 0.08:
                    if footer:
                        ax.text(0.055, 0.035, footer, fontsize=8.5, alpha=0.65)
                    self.pdf.savefig(fig, bbox_inches="tight")
                    plt.close(fig)
                    self.text_pages += 1
                    fig = plt.figure(figsize=(11, 8.5))
                    fig.patch.set_facecolor("white")
                    ax = fig.add_axes([0, 0, 1, 1])
                    ax.axis("off")
                    ax.text(0.055, 0.93, title + " (cont.)", fontsize=18, fontweight="bold", va="top")
                    y = 0.86
        if footer:
            ax.text(0.055, 0.035, footer, fontsize=8.5, alpha=0.65)
        self.pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        self.text_pages += 1

    def add_dataframe(self, title, df, max_rows=28, max_cols=7, include_index=True):
        if not self.enabled:
            return
        df = _dashboard_sanitize_df(df, include_index=include_index)
        if df.empty:
            self.add_text_page(title, ["No rows available."])
            return

        # Keep the first column (usually Method / metric name) pinned on horizontal splits.
        first_col = [df.columns[0]]
        other_cols = list(df.columns[1:])
        cols_per_page = max(1, max_cols - 1)
        col_chunks = [other_cols[i:i + cols_per_page] for i in range(0, len(other_cols), cols_per_page)] or [[]]

        for ci, col_chunk in enumerate(col_chunks):
            cols = first_col + col_chunk
            df_col = df.loc[:, cols]
            for ri in range(0, len(df_col), max_rows):
                df_page = df_col.iloc[ri:ri + max_rows]
                fig, ax = plt.subplots(figsize=(11, 8.5))
                fig.patch.set_facecolor("white")
                ax.axis("off")
                suffix = ""
                if len(col_chunks) > 1:
                    suffix += f" - columns {ci + 1}/{len(col_chunks)}"
                if len(df_col) > max_rows:
                    suffix += f" - rows {ri + 1}-{min(ri + max_rows, len(df_col))}"
                ax.set_title(title + suffix, fontsize=15, fontweight="bold", pad=14)

                col_width = 1.0 / max(len(df_page.columns), 1)
                table = ax.table(
                    cellText=df_page.values,
                    colLabels=df_page.columns,
                    cellLoc="center",
                    colLoc="center",
                    loc="center",
                    colWidths=[col_width] * len(df_page.columns),
                )
                table.auto_set_font_size(False)
                table.set_fontsize(7.5 if len(df_page.columns) >= 6 else 8.5)
                table.scale(1.0, 1.25)
                for (row, col), cell in table.get_celld().items():
                    if row == 0:
                        cell.set_text_props(weight="bold")
                    if col == 0 and row > 0:
                        cell.set_text_props(ha="left")
                self.pdf.savefig(fig, bbox_inches="tight")
                plt.close(fig)
                self.table_pages += 1

    def _style_table_cells(self, table, header_fontsize=None, body_fontsize=None,
                           header_facecolor="0.92", first_col_left=True):
        """Apply consistent, readable table styling for dashboard pages."""
        for (row, col), cell in table.get_celld().items():
            cell.set_edgecolor("0.72")
            cell.set_linewidth(0.45)
            if row == 0:
                cell.set_facecolor(header_facecolor)
                cell.set_text_props(weight="bold", fontsize=header_fontsize)
            else:
                if row % 2 == 0:
                    cell.set_facecolor("0.985")
                if body_fontsize is not None:
                    cell.set_text_props(fontsize=body_fontsize)
                if first_col_left and col == 0:
                    cell.set_text_props(ha="left")

    def _add_table_block(self, ax, title, df, bbox, col_widths=None,
                         header_fontsize=8.2, body_fontsize=8.0):
        """Draw one compact table block inside an existing page."""
        df_fmt = _dashboard_sanitize_df(df, include_index=False)
        ax.text(bbox[0], bbox[1] + bbox[3] + 0.012, title,
                fontsize=11.5, fontweight="bold", va="bottom", ha="left")
        if df_fmt.empty:
            ax.text(bbox[0], bbox[1] + 0.5 * bbox[3], "No rows available.", fontsize=10)
            return
        n_cols = len(df_fmt.columns)
        if col_widths is None:
            first_w = 0.24 if n_cols > 1 else 1.0
            rest_w = (1.0 - first_w) / max(n_cols - 1, 1)
            col_widths = [first_w] + [rest_w] * (n_cols - 1)
        table = ax.table(
            cellText=df_fmt.values,
            colLabels=df_fmt.columns,
            cellLoc="center",
            colLoc="center",
            loc="center",
            colWidths=col_widths,
            bbox=bbox,
        )
        table.auto_set_font_size(False)
        table.set_fontsize(body_fontsize)
        self._style_table_cells(table, header_fontsize=header_fontsize, body_fontsize=body_fontsize)

    def _rename_runinfo_columns(self, df):
        """Shorten run-info headers enough to fit while preserving content."""
        rename = {
            "display_name": "method label",
            "method": "sampler",
            "weight_mode": "weights",
            "mala_step_size": "MALA dt",
            "score_norm_initial": "score norm init",
            "score_norm_mean": "score norm mean",
            "score_norm_final": "score norm final",
            "score_norm_max": "score norm max",
            "pde_likelihood_evals": "PDE logL evals",
            "pde_score_evals": "PDE score evals",
            "pde_gn_hessian_evals": "PDE GN Hess evals",
            "pde_solve_count": "PDE solves",
            "runtime_seconds": "runtime (s)",
            "reference_method": "reference",
            "N_ref": "N ref",
            "mala_steps": "MALA steps",
            "mala_burnin": "MALA burnin",
        }
        return df.rename(columns={k: v for k, v in rename.items() if k in df.columns})

    def add_results_tables(self, results_df, results_runinfo_df):
        """Add exactly two table pages: canonical metrics and readable run-info.

        The metrics page keeps the saved *_metrics.csv / tables.tex layout. The
        run-info page preserves the saved *_runinfo.csv contents, but splits the
        many accounting columns into three normal table blocks on one page so it
        remains legible instead of becoming a tiny one-line wide table.
        """
        if not self.enabled:
            return

        # Page 1: metric rows x sampler columns, matching *_metrics.csv / tables.tex.
        metrics_fmt = _dashboard_sanitize_df(results_df, include_index=True)
        fig, ax = plt.subplots(figsize=(12.5, 8.5))
        fig.patch.set_facecolor("white")
        ax.axis("off")
        ax.set_title("Metrics table (saved *_metrics.csv / tables.tex layout)",
                     fontsize=18, fontweight="bold", pad=14)
        n_rows = max(len(metrics_fmt), 1)
        n_cols = max(len(metrics_fmt.columns), 1)
        first_w = 0.34 if n_cols > 1 else 0.95
        rest_w = (0.94 - first_w) / max(n_cols - 1, 1)
        col_widths = [first_w] + [rest_w] * (n_cols - 1)
        table = ax.table(
            cellText=metrics_fmt.values,
            colLabels=metrics_fmt.columns,
            cellLoc="center",
            colLoc="center",
            loc="center",
            colWidths=col_widths,
            bbox=[0.035, 0.055, 0.93, 0.86],
        )
        table.auto_set_font_size(False)
        # Larger text than the previous version; still adapts if many methods are added.
        body_fs = min(10.5, max(7.2, 120.0 / (n_rows + 0.75 * n_cols)))
        header_fs = min(10.5, body_fs + 0.5)
        table.set_fontsize(body_fs)
        self._style_table_cells(table, header_fontsize=header_fs, body_fontsize=body_fs)
        self.pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        self.table_pages += 1

        # Page 2: normal, readable run-info blocks on one page.
        runinfo = pd.DataFrame(results_runinfo_df).copy()
        target = ""
        if "target" in runinfo.columns and len(runinfo) > 0:
            target = str(runinfo["target"].iloc[0])
        runinfo = self._rename_runinfo_columns(runinfo)
        fig, ax = plt.subplots(figsize=(15.5, 10.0))
        fig.patch.set_facecolor("white")
        ax.axis("off")
        title = "Run-info table (saved *_runinfo.csv, split for readability)"
        if target:
            title += f" - {target}"
        ax.set_title(title, fontsize=18, fontweight="bold", pad=14)

        def cols_present(cols):
            return [c for c in cols if c in runinfo.columns]

        config_cols = cols_present([
            "method label", "sampler", "weights", "N ref", "steps",
            "MALA steps", "MALA burnin", "MALA dt", "reference", "runtime (s)",
        ])
        score_cols = cols_present([
            "method label", "score_norm", "score norm init", "score norm mean",
            "score norm final", "score norm max",
        ])
        budget_cols = cols_present([
            "method label", "PDE logL evals", "PDE score evals", "PDE GN Hess evals", "PDE solves",
        ])

        # Normalized column widths for each block. First column gets label width;
        # remaining columns share the rest.
        def widths(n, first=0.24):
            if n <= 1:
                return [1.0]
            return [first] + [(1.0 - first) / (n - 1)] * (n - 1)

        if config_cols:
            self._add_table_block(
                ax, "Sampler configuration and runtime", runinfo[config_cols],
                bbox=[0.035, 0.635, 0.93, 0.265], col_widths=widths(len(config_cols), first=0.22),
                header_fontsize=8.8, body_fontsize=8.7,
            )
        if score_cols:
            self._add_table_block(
                ax, "Score-norm diagnostics", runinfo[score_cols],
                bbox=[0.035, 0.355, 0.93, 0.185], col_widths=widths(len(score_cols), first=0.30),
                header_fontsize=9.2, body_fontsize=9.0,
            )
        if budget_cols:
            self._add_table_block(
                ax, "PDE evaluation budget", runinfo[budget_cols],
                bbox=[0.035, 0.115, 0.93, 0.165], col_widths=widths(len(budget_cols), first=0.30),
                header_fontsize=9.2, body_fontsize=9.0,
            )

        # If future runinfo files add columns not covered above, surface them in a small note
        # instead of silently dropping them.
        used = set(config_cols + score_cols + budget_cols + ["target", "label"])
        extra = [c for c in runinfo.columns if c not in used]
        if extra:
            ax.text(0.035, 0.055, "Additional run-info columns: " + ", ".join(extra),
                    fontsize=8.0, alpha=0.75, ha="left", va="bottom")
        self.pdf.savefig(fig, bbox_inches="tight")
        plt.close(fig)
        self.table_pages += 1

    def _figure_sort_key(self, path):
        name = os.path.basename(path)
        m = re.search(r"_figure_(\d+)_", name)
        return (int(m.group(1)) if m else 10_000, name)

    def add_image_page(self, image_path):
        """Embed one saved PNG/JPG as a full dashboard page."""
        if not self.enabled or not os.path.exists(image_path):
            return
        img = mpimg.imread(image_path)
        h, w = img.shape[:2]
        aspect = w / max(h, 1)
        if aspect > 2.2:
            figsize = (18.0, 7.0)
        elif aspect > 1.35:
            figsize = (15.5, 9.0)
        else:
            figsize = (11.0, 10.0)
        fig = plt.figure(figsize=figsize)
        fig.patch.set_facecolor("white")
        ax = fig.add_axes([0.015, 0.015, 0.97, 0.97])
        ax.imshow(img)
        ax.axis("off")
        self.pdf.savefig(fig, bbox_inches="tight", pad_inches=0.03)
        plt.close(fig)
        self.figure_pages += 1

    def add_run_results_png_figures(self, run_results_dir):
        """Append all saved run-results PNG figures, sorted by figure number.

        This is intentionally based on the files saved by sampling.py's patched
        plt.show() hook, so dashboard coverage matches the normal run-results
        directory exactly: ESS, PCA, field reconstructions, wavefields, boundary
        traces, curvature spectra, and any future diagnostics.
        """
        if not self.enabled or not run_results_dir or not os.path.isdir(run_results_dir):
            return
        pngs = sorted(glob.glob(os.path.join(run_results_dir, "*.png")), key=self._figure_sort_key)
        for path in pngs:
            self.add_image_page(path)

    def add_figure(self, fig=None, close=False):
        if not self.enabled:
            return
        if fig is None:
            fig = plt.gcf()
        try:
            fig.savefig(self.pdf, format="pdf", bbox_inches="tight")
            self.figure_pages += 1
        except Exception as exc:
            self.add_text_page("Figure capture failed", [repr(exc)])
        if close:
            plt.close(fig)

    def capture_new_figures(self, close=False):
        if not self.enabled:
            return
        for num in list(plt.get_fignums()):
            fig = plt.figure(num)
            fig_id = id(fig)
            if fig_id not in self._seen_fig_ids:
                self.add_figure(fig, close=close)
                self._seen_fig_ids.add(fig_id)

    def close(self):
        if self.enabled and self.pdf is not None:
            self.pdf.close()
            self.pdf = None


def dashboard_copy_into_run_dir(dashboard_path, results_df_path=None):
    """Copy the dashboard into the run-results directory so it is included in the zip."""
    if not dashboard_path or not os.path.exists(dashboard_path) or results_df_path is None:
        return dashboard_path
    run_dir = os.path.dirname(os.path.abspath(results_df_path))
    os.makedirs(run_dir, exist_ok=True)
    dest = os.path.join(run_dir, os.path.basename(dashboard_path))
    if os.path.abspath(dest) != os.path.abspath(dashboard_path):
        shutil.copy2(dashboard_path, dest)
    return dest




# ==========================================
# KL basis generation
# ==========================================
os.makedirs('data', exist_ok=True)
N = 32
x = np.linspace(0.0, 1.0, N)
X, Y = np.meshgrid(x, x)
coords = np.column_stack([X.ravel(), Y.ravel()])

ell = 0.10
sigma_prior = 1.0
dists = cdist(coords, coords)
C = sigma_prior ** 2 * np.exp(-dists / ell)

eigvals, eigvecs = np.linalg.eigh(C)
idx = np.argsort(eigvals)[::-1]
eigvals = eigvals[idx]
eigvecs = eigvecs[:, idx]
q_max = 100
Basis_Modes = eigvecs[:, :q_max] * np.sqrt(eigvals[:q_max])
np.savetxt('data/Helmholtz_Basis_Modes.csv', Basis_Modes, delimiter=',')

# ==========================================
# Config
# ==========================================
num_truncated_series = 32
seed = 42
HELMHOLTZ_K = 24.0
HELMHOLTZ_DAMPING = 6.0
BACKGROUND_N2 = 1.0
SCATTERER_AMPLITUDE = 0.45
SCATTERER_RADIUS = 0.30
SCATTERER_SOFTNESS = 0.035
N_SOURCES = 4
N_RECEIVERS = 64
N_HOLDOUT_RECEIVERS = None
SOURCE_WIDTH = 0.055


def _ordered_boundary_indices(n):
    idx = []
    for j in range(n):
        idx.append(0 * n + j)
    for i in range(1, n):
        idx.append(i * n + (n - 1))
    for j in range(n - 2, -1, -1):
        idx.append((n - 1) * n + j)
    for i in range(n - 2, 0, -1):
        idx.append(i * n + 0)
    return np.array(idx, dtype=int)


boundary_indices_ordered = _ordered_boundary_indices(N)
n_boundary = len(boundary_indices_ordered)
receiver_spacing = n_boundary / N_RECEIVERS
receiver_boundary_pos = np.round(np.arange(N_RECEIVERS) * receiver_spacing).astype(int)
receiver_boundary_pos = np.clip(receiver_boundary_pos, 0, n_boundary - 1)
receiver_boundary_pos = np.unique(receiver_boundary_pos)
receiver_flat_indices = boundary_indices_ordered[receiver_boundary_pos]
remaining_boundary_pos = np.setdiff1d(np.arange(n_boundary), receiver_boundary_pos)
if N_HOLDOUT_RECEIVERS is None:
    N_HOLDOUT_RECEIVERS = remaining_boundary_pos.size
else:
    N_HOLDOUT_RECEIVERS = min(int(N_HOLDOUT_RECEIVERS), remaining_boundary_pos.size)
holdout_boundary_pos = remaining_boundary_pos[:N_HOLDOUT_RECEIVERS]
holdout_receiver_flat_indices = boundary_indices_ordered[holdout_boundary_pos]
rr = np.sqrt((X - 0.5) ** 2 + (Y - 0.5) ** 2)
support_mask = 1.0 / (1.0 + np.exp((rr - SCATTERER_RADIUS) / SCATTERER_SOFTNESS))
source_centers = np.array([[0.18, 0.22], [0.82, 0.26], [0.74, 0.82], [0.24, 0.76]], dtype=np.float64)

source_terms = []
for sx, sy in source_centers:
    direction = np.array([0.5 - sx, 0.5 - sy], dtype=np.float64)
    direction /= np.linalg.norm(direction) + 1e-12
    dist2 = (X - sx) ** 2 + (Y - sy) ** 2
    envelope = np.exp(-0.5 * dist2 / (SOURCE_WIDTH ** 2))
    phase = np.exp(1j * HELMHOLTZ_K * (direction[0] * (X - sx) + direction[1] * (Y - sy)))
    src = envelope * phase
    src = src / np.sqrt(np.sum(np.abs(src) ** 2) + 1e-12)
    source_terms.append(src.reshape(-1))
source_terms = np.stack(source_terms, axis=1)

num_observation = N_SOURCES * 2 * N_RECEIVERS
num_holdout_observation = N_SOURCES * 2 * N_HOLDOUT_RECEIVERS
dimension_of_PoI = N * N

df_modes = pd.read_csv('data/Helmholtz_Basis_Modes.csv', header=None)
modes_raw = df_modes.to_numpy().flatten().astype(np.float64)
num_modes_available = modes_raw.size // dimension_of_PoI
full_basis = modes_raw.reshape((dimension_of_PoI, num_modes_available))
basis_truncated = full_basis[:, :num_truncated_series]
pd.DataFrame(basis_truncated).to_csv('data/Basis.csv', index=False, header=False)
pd.DataFrame(receiver_flat_indices).to_csv('data/obs_locations.csv', index=False, header=False)

# ==========================================
# Physics
# ==========================================
jax.config.update("jax_enable_x64", True)
Basis = jnp.array(basis_truncated)
support_mask_jax = jnp.array(support_mask, dtype=jnp.float64)
receiver_indices_jax = jnp.array(receiver_flat_indices, dtype=int)
holdout_receiver_indices_jax = jnp.array(holdout_receiver_flat_indices, dtype=int)
boundary_indices_jax = jnp.array(boundary_indices_ordered, dtype=int)
source_terms_jax = jnp.array(source_terms, dtype=jnp.complex128)

h = 1.0 / (N - 1)
n_total = N * N
_xface_left = (jnp.arange(N - 1)[:, None] * N + jnp.arange(N)[None, :]).ravel()
_xface_right = _xface_left + N
_yface_bot = (jnp.arange(N)[:, None] * N + jnp.arange(N - 1)[None, :]).ravel()
_yface_top = _yface_bot + 1


def _assemble_negative_laplacian():
    weight = 1.0 / (h * h)
    A = jnp.zeros((n_total, n_total), dtype=jnp.complex128)
    A = A.at[_xface_left, _xface_left].add(weight)
    A = A.at[_xface_right, _xface_right].add(weight)
    A = A.at[_xface_left, _xface_right].add(-weight)
    A = A.at[_xface_right, _xface_left].add(-weight)
    A = A.at[_yface_bot, _yface_bot].add(weight)
    A = A.at[_yface_top, _yface_top].add(weight)
    A = A.at[_yface_bot, _yface_top].add(-weight)
    A = A.at[_yface_top, _yface_bot].add(-weight)
    return A


NEG_LAPLACIAN = _assemble_negative_laplacian()
IDENTITY_WAVE = jnp.eye(n_total, dtype=jnp.complex128)


def _flatten_measurements_by_source(meas_complex):
    parts = []
    for s in range(N_SOURCES):
        parts.append(jnp.real(meas_complex[:, s]))
        parts.append(jnp.imag(meas_complex[:, s]))
    return jnp.concatenate(parts, axis=0)


def _flatten_measurements_by_source_generic(meas_complex, n_receivers):
    parts = []
    for s in range(N_SOURCES):
        parts.append(jnp.real(meas_complex[:n_receivers, s]))
        parts.append(jnp.imag(meas_complex[:n_receivers, s]))
    return jnp.concatenate(parts, axis=0)



def _alpha_to_raw_and_contrast(alpha):
    raw_field = jnp.reshape(Basis @ alpha, (N, N))
    contrast = SCATTERER_AMPLITUDE * jnp.tanh(raw_field) * support_mask_jax
    n2_field = BACKGROUND_N2 + contrast
    return raw_field, contrast, n2_field



def _assemble_helmholtz_operator(n2_field):
    diag = -(HELMHOLTZ_K ** 2) * n2_field.reshape(-1)
    return NEG_LAPLACIAN + jnp.diag(diag.astype(jnp.complex128)) + 1j * HELMHOLTZ_DAMPING * IDENTITY_WAVE


BACKGROUND_OPERATOR = _assemble_helmholtz_operator(jnp.ones((N, N), dtype=jnp.float64) * BACKGROUND_N2)
BACKGROUND_FIELDS = jnp.linalg.solve(BACKGROUND_OPERATOR, source_terms_jax)


@jax.jit
def solve_forward(alpha):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    U_total = jnp.linalg.solve(A, source_terms_jax)
    U_scat = U_total - BACKGROUND_FIELDS
    meas = U_scat[receiver_indices_jax, :]
    return _flatten_measurements_by_source(meas)


@jax.jit
def solve_forward_holdout(alpha):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    U_total = jnp.linalg.solve(A, source_terms_jax)
    U_scat = U_total - BACKGROUND_FIELDS
    meas = U_scat[holdout_receiver_indices_jax, :]
    return _flatten_measurements_by_source_generic(meas, holdout_receiver_indices_jax.shape[0])


batch_solve_forward_holdout = jax.jit(jax.vmap(solve_forward_holdout))


@jax.jit
def solve_single_pattern(alpha, pattern_idx):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    u_total = jnp.linalg.solve(A, source_terms_jax[:, pattern_idx])
    u_scat = u_total - BACKGROUND_FIELDS[:, pattern_idx]
    return u_scat.reshape(N, N)


@jax.jit
def solve_single_total_field(alpha, pattern_idx):
    _, _, n2_field = _alpha_to_raw_and_contrast(alpha)
    A = _assemble_helmholtz_operator(n2_field)
    u_total = jnp.linalg.solve(A, source_terms_jax[:, pattern_idx])
    return u_total.reshape(N, N)

# ==========================================
# Shared sampling / density-benchmark config
# ==========================================
ACTIVE_DIM = num_truncated_series
PLOT_NORMALIZER = 'best'
HESS_MIN = 1e-6
HESS_MAX = 1e8
GNL_PILOT_N = 512
GNL_STIFF_LAMBDA_CUT = HESS_MAX
GNL_USE_DOMINANT_PARTICLE_NEWTON = True
BUILD_GNL_BANKS = False


def _env_int(name, default):
    return int(os.environ.get(name, str(default)))


def _env_float(name, default):
    return float(os.environ.get(name, str(default)))


def _env_float_or_none(name, default):
    raw = os.environ.get(name, None)
    if raw is None:
        return default
    raw = str(raw).strip().lower()
    if raw in {'none', 'null', 'nan', ''}:
        return None
    return float(raw)


def _env_bool(name, default):
    raw = os.environ.get(name, None)
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() not in {'0', 'false', 'no', 'off', 'none', ''}



def _env_is_set(name):
    return name in os.environ and str(os.environ.get(name, '')).strip() != ''


def _canonical_bank_coupling(value):
    raw = str(value).strip().lower().replace('-', '_')
    aliases = {
        'same': 'shared',
        'same_bank': 'shared',
        'reuse': 'shared',
        'reused': 'shared',
        'coupled': 'shared',
        'shared': 'shared',
        'prefix': 'prefix',
        'nested': 'prefix',
        'independent': 'independent',
        'indep': 'independent',
        'disjoint': 'independent',
        'separate': 'independent',
    }
    if raw not in aliases:
        raise ValueError(
            f'Unsupported bank coupling {value!r}; expected shared, prefix, or independent.'
        )
    return aliases[raw]


def _required_source_bank_size(n_signal, n_gate, score_gate_bank_coupling):
    coupling = _canonical_bank_coupling(score_gate_bank_coupling)
    if coupling == 'shared':
        return int(n_signal)
    if coupling == 'prefix':
        return int(max(n_signal, n_gate))
    return int(n_signal) + int(n_gate)


def _canonical_source_label(value):
    raw = str(value).strip()
    low = raw.lower().replace('_', '-').replace(' ', '-')
    if low in {'none', 'null', ''}:
        return 'None'
    if low == 'mala':
        return 'MALA'
    if low in {'mala-eval', 'malaeval'}:
        return 'MALA-EVAL'
    return raw


def _env_percentile_pair(name, default):
    raw = os.environ.get(name, None)
    if raw is None:
        return default
    parts = [float(x.strip()) for x in str(raw).replace(';', ',').split(',') if x.strip()]
    if len(parts) < 2:
        return default
    lo, hi = parts[:2]
    if not (0.0 <= lo < hi <= 100.0):
        raise ValueError(f'{name} must be two percentiles 0 <= lo < hi <= 100; got {raw!r}')
    return (lo, hi)


def _env_csv(name, default):
    raw = os.environ.get(name, None)
    if raw is None:
        return tuple(default)
    parts = [x.strip() for x in str(raw).replace(';', ',').split(',') if x.strip()]
    return tuple(parts) if parts else tuple(default)


def _env_int_tuple(name, default):
    return tuple(int(float(x)) for x in _env_csv(name, default))


def _env_float_tuple_or_none(name, default=None):
    raw = os.environ.get(name, None)
    if raw is None:
        return default
    parts = [x.strip() for x in str(raw).replace(';', ',').split(',') if x.strip()]
    if not parts or any(x.lower() in {'none', 'null'} for x in parts):
        return default
    return tuple(float(x) for x in parts)


# Helmholtz keeps a modest legacy IP_DENSITY_N_REF fallback, but now uses the
# same split-bank density controls as the Navier-Stokes benchmark.  The signal
# bank feeds the score field; the gate bank feeds CE-HLSI gate estimation; the
# density-eval bank is the held-out location bank for the PF/DRC correction.
N_REF_SIGNAL = _env_int('IP_DENSITY_N_REF_SIGNAL', _env_int('IP_DENSITY_N_REF', 500))
N_REF_GATE_ENV_SET = _env_is_set('IP_DENSITY_N_REF_GATE')
N_REF_GATE = _env_int('IP_DENSITY_N_REF_GATE', N_REF_SIGNAL)
N_REF_EVAL = _env_int('IP_DENSITY_N_REF_EVAL', N_REF_SIGNAL)
N_REF = N_REF_SIGNAL  # Backward-compatible alias used by reporting helpers.
DEFAULT_N_GEN = _env_int('IP_DENSITY_DEFAULT_N_GEN', N_REF_SIGNAL)

# Density-evaluation correction-factor benchmark.  By default, this follows the
# current Navier-Stokes wiring: the frozen score field is fitted from MALA and
# the eval-bank source/coupling is explicit, so you can use either an independent
# slice from the same source or a distinct MALA-EVAL source bank.
DENSITY_REF_SOURCE = _canonical_source_label(os.environ.get('IP_DENSITY_REF_SOURCE', 'MALA'))
DENSITY_BANK_COUPLING = _canonical_bank_coupling(os.environ.get(
    'IP_DENSITY_BANK_COUPLING',
    os.environ.get('IP_DENSITY_GATE_BANK_COUPLING', 'independent'),
))
DENSITY_EVAL_SOURCE = _canonical_source_label(os.environ.get('IP_DENSITY_EVAL_SOURCE', 'MALA-EVAL'))
DENSITY_EVAL_BANK_COUPLING = _canonical_bank_coupling(
    os.environ.get('IP_DENSITY_EVAL_BANK_COUPLING', 'independent')
)
DENSITY_DRC_PF_STEPS = _env_int('IP_DENSITY_DRC_PF_STEPS', 64)
DENSITY_DRC_EVAL_BATCH_SIZE = _env_int('IP_DENSITY_DRC_EVAL_BATCH_SIZE', 32)
DENSITY_DRC_TMIN = _env_float('IP_DENSITY_DRC_TMIN', 10 ** (-2.5))
DENSITY_DRC_TMAX = _env_float('IP_DENSITY_DRC_TMAX', 5.0)
DENSITY_DRC_CLIP = _env_float_or_none('IP_DENSITY_DRC_CLIP', None)
DENSITY_DRC_TEMPERATURE = _env_float('IP_DENSITY_DRC_TEMPERATURE', 1.0)
DENSITY_DRC_ENERGY_PLOTS = _env_bool('IP_DENSITY_DRC_ENERGY_PLOTS', True)
DENSITY_DRC_PLOT_AXIS_MODE = os.environ.get('IP_DENSITY_DRC_PLOT_AXIS_MODE', 'robust')
DENSITY_DRC_RESIDUAL_AXIS_MODE = os.environ.get('IP_DENSITY_DRC_RESIDUAL_AXIS_MODE', 'robust')
DENSITY_DRC_RESIDUAL_KIND = os.environ.get('IP_DENSITY_DRC_RESIDUAL_KIND', 'affine_normalized')
DENSITY_DRC_AFFINE_FIT_SCOPE = os.environ.get('IP_DENSITY_DRC_AFFINE_FIT_SCOPE', 'central')
DENSITY_DRC_ROBUST_PERCENTILES = _env_percentile_pair('IP_DENSITY_DRC_ROBUST_PERCENTILES', (1.0, 99.0))
DENSITY_DRC_SAVE_RAW_PLOTS = _env_bool('IP_DENSITY_DRC_SAVE_RAW_PLOTS', False)
DENSITY_DRC_SAVE_LOGLOG_PLOTS = _env_bool('IP_DENSITY_DRC_SAVE_LOGLOG_PLOTS', False)
DENSITY_DRC_SAVE_LOGRATIO_RESIDUAL_PLOTS = _env_bool('IP_DENSITY_DRC_SAVE_LOGRATIO_RESIDUAL_PLOTS', False)
DENSITY_DRC_SAVE_LEGACY_ALIAS = _env_bool('IP_DENSITY_DRC_SAVE_LEGACY_ALIAS', True)
DENSITY_DRC_PLOT_LAYOUT = os.environ.get('IP_DENSITY_DRC_PLOT_LAYOUT', 'comparison_grid')
DENSITY_DRC_GRID_MAX_POINTS = _env_int('IP_DENSITY_DRC_GRID_MAX_POINTS', 5000)
DENSITY_DRC_GRID_SAVE_PDF = _env_bool('IP_DENSITY_DRC_GRID_SAVE_PDF', True)

# Divergence defaults matching the density scripts. CE-HLSI and Tweedie dispatch
# to analytic implementations in sampling.py when available; scalar blend keeps
# Hutchinson by default for speed unless explicitly overridden.
DENSITY_TWEEDIE_DIVERGENCE = os.environ.get('IP_DENSITY_TWEEDIE_DIVERGENCE', 'auto')
DENSITY_BLEND_DIVERGENCE = os.environ.get('IP_DENSITY_BLEND_DIVERGENCE', 'auto')
DENSITY_LFGI_DIVERGENCE = os.environ.get('IP_DENSITY_LFGI_DIVERGENCE', 'auto')
DENSITY_DIV_PROBES = _env_int('IP_DENSITY_DRC_DIV_PROBES', 1)

# Manuscript-table extras. These are intentionally thin wrappers around helper
# functions in sampling.py so this Helmholtz benchmark produces the same paper
# metrics as the Navier-Stokes density benchmark: PF density rows, a MAP-Laplace
# Gaussian baseline row, optional known-Z columns, and an optional PF sensitivity
# plot/table.
DENSITY_BASELINES = _env_csv('IP_DENSITY_BASELINES', ('map_laplace',))
DENSITY_KNOWN_LOGZ = _env_float_or_none('IP_DENSITY_KNOWN_LOGZ', None)
DENSITY_RUN_PF_SENSITIVITY = _env_bool('IP_DENSITY_RUN_PF_SENSITIVITY', False)
DENSITY_PF_SENSITIVITY_LABELS = _env_csv('IP_DENSITY_PF_SENSITIVITY_LABELS', ('DENS-CE-HLSI', 'DENS-Tweedie'))
DENSITY_PF_SENSITIVITY_STEPS = _env_int_tuple('IP_DENSITY_PF_SENSITIVITY_STEPS', (32, 64, 128))
DENSITY_PF_SENSITIVITY_TMINS = _env_float_tuple_or_none('IP_DENSITY_PF_SENSITIVITY_TMINS', None)

# MALA source-bank configuration.  DENSITY_SOURCE_REQUIRED_N is the minimum
# number of source particles needed to provide disjoint signal/gate slices from
# DENSITY_REF_SOURCE under the selected score/gate coupling.
DENSITY_SOURCE_REQUIRED_N = _required_source_bank_size(
    N_REF_SIGNAL, N_REF_GATE, DENSITY_BANK_COUPLING,
)
MALA_N_SAMPLES = _env_int('IP_DENSITY_MALA_N_SAMPLES', DENSITY_SOURCE_REQUIRED_N)
MALA_STEPS = _env_int('IP_DENSITY_MALA_STEPS', 600)
MALA_BURNIN = _env_int('IP_DENSITY_MALA_BURNIN', 150)
MALA_DT = _env_float('IP_DENSITY_MALA_DT', 5.0e-5)

# Default to a target-side MAP/Laplace proxy initialization for MALA.  This is
# distinct from the older reference-bank `ref_laplace` mode: `map_laplace` first
# optimizes the posterior and samples N(map, observed_info(map)^{-1}).

MALA_INIT = os.environ.get('IP_DENSITY_MALA_INIT', 'map_laplace')
MALA_PRECOND = _env_bool('IP_DENSITY_MALA_PRECOND', False)
MALA_EVAL_N_SAMPLES = _env_int('IP_DENSITY_MALA_EVAL_N_SAMPLES', N_REF_EVAL)
MALA_EVAL_STEPS = _env_int('IP_DENSITY_MALA_EVAL_STEPS', MALA_STEPS)
MALA_EVAL_BURNIN = _env_int('IP_DENSITY_MALA_EVAL_BURNIN', MALA_BURNIN)
MALA_EVAL_DT = _env_float('IP_DENSITY_MALA_EVAL_DT', MALA_DT)
MALA_EVAL_INIT = os.environ.get('IP_DENSITY_MALA_EVAL_INIT', MALA_INIT)
MALA_EVAL_PRECOND = _env_bool('IP_DENSITY_MALA_EVAL_PRECOND', MALA_PRECOND)
MAP_LAPLACE_STARTS = _env_int('IP_DENSITY_MAP_LAPLACE_STARTS', 128)
MAP_LAPLACE_MAX_ITER = _env_int('IP_DENSITY_MAP_LAPLACE_MAX_ITER', 25)
MAP_LAPLACE_TOL = _env_float('IP_DENSITY_MAP_LAPLACE_TOL', 1e-5)
MAP_LAPLACE_RIDGE = _env_float('IP_DENSITY_MAP_LAPLACE_RIDGE', 1e-6)
MAP_LAPLACE_MAX_STEP_NORM = _env_float('IP_DENSITY_MAP_LAPLACE_MAX_STEP_NORM', 2.0)
MAP_LAPLACE_BACKTRACK_STEPS = _env_int('IP_DENSITY_MAP_LAPLACE_BACKTRACK_STEPS', 8)
HELDOUT_BATCH_SIZE = _env_int('IP_DENSITY_HELDOUT_BATCH_SIZE', 1)

if MALA_N_SAMPLES < DENSITY_SOURCE_REQUIRED_N:
    raise ValueError(
        f'MALA_N_SAMPLES={MALA_N_SAMPLES} must be >= {DENSITY_SOURCE_REQUIRED_N} '
        f'for N_REF_SIGNAL={N_REF_SIGNAL}, N_REF_GATE={N_REF_GATE}, '
        f'and DENSITY_BANK_COUPLING={DENSITY_BANK_COUPLING!r}.'
    )
if DENSITY_EVAL_SOURCE == 'MALA-EVAL' and MALA_EVAL_N_SAMPLES < N_REF_EVAL:
    raise ValueError(
        f'MALA_EVAL_N_SAMPLES={MALA_EVAL_N_SAMPLES} must be >= N_REF_EVAL={N_REF_EVAL}.'
    )

configure_sampling(
    active_dim=ACTIVE_DIM,
    default_n_gen=DEFAULT_N_GEN,
    hess_min=HESS_MIN,
    hess_max=HESS_MAX,
    leaf_min_prec=HESS_MIN,
    leaf_max_prec=HESS_MAX,
    leaf_abs_scale=1.0,
    gnl_pilot_n=GNL_PILOT_N,
    gnl_stiff_lambda_cut=GNL_STIFF_LAMBDA_CUT,
    gnl_use_dominant_particle_newton=GNL_USE_DOMINANT_PARTICLE_NEWTON,
)
# Use the module-qualified call and then explicitly synchronize sampling.py's
# run-results globals. In long notebook sessions, stale matplotlib show hooks
# from a previous experiment can otherwise keep writing late diagnostics into
# the previous run directory.
run_results_info = sampling.init_run_results('helmholtz_density_eval_bench')
DASHBOARD_PDF_PATH = os.path.join(
    run_results_info['run_results_dir'],
    f"{run_results_info['run_results_stem']}_summary_dashboard.pdf",
)


def _sync_sampling_run_results_context():
    """Force sampling.py's figure-save hook to target this Helmholtz run."""
    sampling.RUN_TIMESTAMP = run_results_info['run_timestamp']
    sampling.RUN_RESULTS_ROOT = run_results_info['run_results_root']
    sampling.RUN_RESULTS_DIR = run_results_info['run_results_dir']
    sampling.RUN_RESULTS_STEM = run_results_info['run_results_stem']
    try:
        if plt.show is not sampling._patched_show:
            plt.show = sampling._patched_show
    except Exception:
        pass


def _save_open_figures_to_current_helmholtz_run():
    _sync_sampling_run_results_context()
    return sampling._save_all_open_figures_to_run_results()


_sync_sampling_run_results_context()

# ==========================================
# Execution
# ==========================================
gc.collect()
if torch.cuda.is_available():
    torch.cuda.empty_cache()

np.random.seed(seed)
mode_decay = np.linspace(1.0, 0.45, ACTIVE_DIM)
alpha_true_np = 0.95 * np.random.randn(ACTIVE_DIM) * mode_decay
y_clean = solve_forward(jnp.array(alpha_true_np))
y_clean_np = np.array(y_clean)
NOISE_STD = 4e-4
y_obs_np = y_clean_np + np.random.normal(0.0, NOISE_STD, size=y_clean_np.shape)
y_clean_holdout = solve_forward_holdout(jnp.array(alpha_true_np))
y_clean_holdout_np = np.array(y_clean_holdout)
y_holdout_obs_np = y_clean_holdout_np + np.random.normal(0.0, NOISE_STD, size=y_clean_holdout_np.shape)

prior_model = GaussianPrior(dim=ACTIVE_DIM)
lik_model, lik_aux = make_physics_likelihood(
    solve_forward,
    y_obs_np,
    NOISE_STD,
    use_gauss_newton_hessian=True,
    log_batch_size=50,
    grad_batch_size=25,
    hess_batch_size=2,
)
posterior_score_fn = make_posterior_score_fn(lik_model)


def _density_eval_config(ref_source, score_init, divergence, label, display_name):
    return {
        'display_name': display_name,
        'ref_source': ref_source,
        'init': 'DRC-R',
        'init_weights': 'None',
        'drc_score_init': score_init,
        # The MALA bank is the empirical posterior/reference bank. Do not
        # likelihood-reweight again when fitting each frozen score family.
        'drc_score_init_weights': 'None',
        'transition_w': 'ou',
        'n_ref': N_REF_SIGNAL,
        'n_ref_signal': N_REF_SIGNAL,
        'n_ref_gate': N_REF_GATE,
        'score_gate_bank_coupling': DENSITY_BANK_COUPLING,
        'drc_eval_source': DENSITY_EVAL_SOURCE,
        'drc_eval_n_ref': N_REF_EVAL,
        'drc_eval_bank_coupling': DENSITY_EVAL_BANK_COUPLING,
        'include_results': False,
        'drc_pf_steps': DENSITY_DRC_PF_STEPS,
        'drc_divergence': divergence,
        'drc_div_probes': DENSITY_DIV_PROBES,
        'drc_eval_batch_size': DENSITY_DRC_EVAL_BATCH_SIZE,
        'drc_clip': DENSITY_DRC_CLIP,
        'drc_temperature': DENSITY_DRC_TEMPERATURE,
        'drc_fd_eps': 1e-3,
        'drc_tmin': DENSITY_DRC_TMIN,
        'drc_tmax': DENSITY_DRC_TMAX,
        'drc_store_details': True,
        'drc_energy_benchmark': True,
        'drc_energy_plots': DENSITY_DRC_ENERGY_PLOTS,
        'drc_energy_plot_axis_mode': DENSITY_DRC_PLOT_AXIS_MODE,
        'drc_energy_residual_axis_mode': DENSITY_DRC_RESIDUAL_AXIS_MODE,
        'drc_energy_residual_kind': DENSITY_DRC_RESIDUAL_KIND,
        'drc_energy_affine_fit_scope': DENSITY_DRC_AFFINE_FIT_SCOPE,
        'drc_energy_robust_percentiles': DENSITY_DRC_ROBUST_PERCENTILES,
        'drc_energy_save_raw_plots': DENSITY_DRC_SAVE_RAW_PLOTS,
        'drc_energy_save_loglog_plots': DENSITY_DRC_SAVE_LOGLOG_PLOTS,
        'drc_energy_save_logratio_residual_plots': DENSITY_DRC_SAVE_LOGRATIO_RESIDUAL_PLOTS,
        'drc_energy_save_legacy_alias': DENSITY_DRC_SAVE_LEGACY_ALIAS,
        'drc_energy_plot_layout': DENSITY_DRC_PLOT_LAYOUT,
        'drc_energy_grid_method_order': ('DENS-CE-HLSI', 'DENS-ScalarBlend', 'DENS-Tweedie'),
        'drc_energy_grid_axis_reference': 'DENS-CE-HLSI',
        'drc_energy_grid_max_points': DENSITY_DRC_GRID_MAX_POINTS,
        'drc_energy_grid_save_pdf': DENSITY_DRC_GRID_SAVE_PDF,
    }


SAMPLER_CONFIGS = OrderedDict([
    ('MALA', {
        'display_name': 'MALA reference',
        'init': MALA_INIT,
        'init_weights': 'None',
        'transition_w': 'ou',
        'n_ref': DENSITY_SOURCE_REQUIRED_N,
        'n_samples': MALA_N_SAMPLES,
        'init_steps': 0,
        'mala_steps': MALA_STEPS,
        'mala_burnin': MALA_BURNIN,
        'mala_dt': MALA_DT,
        'precond_mala': MALA_PRECOND,
        'map_laplace_starts': MAP_LAPLACE_STARTS,
        'map_laplace_max_iter': MAP_LAPLACE_MAX_ITER,
        'map_laplace_tol': MAP_LAPLACE_TOL,
        'map_laplace_ridge': MAP_LAPLACE_RIDGE,
        'map_laplace_max_step_norm': MAP_LAPLACE_MAX_STEP_NORM,
        'map_laplace_backtrack_steps': MAP_LAPLACE_BACKTRACK_STEPS,
        'log_mean_ess': False,
        'include_results': True,
        'is_reference': True,
    }),
])

if DENSITY_EVAL_SOURCE == 'MALA-EVAL':
    SAMPLER_CONFIGS['MALA-EVAL'] = {
        'display_name': 'MALA density-eval bank',
        'init': MALA_EVAL_INIT,
        'init_weights': 'None',
        'transition_w': 'ou',
        'n_ref': N_REF_EVAL,
        'n_samples': MALA_EVAL_N_SAMPLES,
        'init_steps': 0,
        'mala_steps': MALA_EVAL_STEPS,
        'mala_burnin': MALA_EVAL_BURNIN,
        'mala_dt': MALA_EVAL_DT,
        'precond_mala': MALA_EVAL_PRECOND,
        'map_laplace_starts': MAP_LAPLACE_STARTS,
        'map_laplace_max_iter': MAP_LAPLACE_MAX_ITER,
        'map_laplace_tol': MAP_LAPLACE_TOL,
        'map_laplace_ridge': MAP_LAPLACE_RIDGE,
        'map_laplace_max_step_norm': MAP_LAPLACE_MAX_STEP_NORM,
        'map_laplace_backtrack_steps': MAP_LAPLACE_BACKTRACK_STEPS,
        'log_mean_ess': False,
        'include_results': False,
        'is_reference': False,
    }

SAMPLER_CONFIGS.update(OrderedDict([
    ('DENS-Tweedie', _density_eval_config(
        DENSITY_REF_SOURCE, 'tweedie', DENSITY_TWEEDIE_DIVERGENCE,
        'DENS-Tweedie', 'Tweedie PF',
    )),
    ('DENS-ScalarBlend', _density_eval_config(
        DENSITY_REF_SOURCE, 'scalar_blend', DENSITY_BLEND_DIVERGENCE,
        'DENS-ScalarBlend', 'Scalar blend PF',
    )),
    ('DENS-CE-HLSI', _density_eval_config(
        DENSITY_REF_SOURCE, 'ce_hlsi', DENSITY_LFGI_DIVERGENCE,
        'DENS-CE-HLSI', 'CE-HLSI/LFGI, GN precision',
    )),
]))

RUN_COMMAND_HINT = (
    'IP_DENSITY_N_REF_SIGNAL={n_signal} IP_DENSITY_N_REF_GATE={n_gate} '
    'IP_DENSITY_N_REF_EVAL={n_eval} IP_DENSITY_BANK_COUPLING={bank_coupling} '
    'IP_DENSITY_EVAL_SOURCE={eval_source} IP_DENSITY_MALA_N_SAMPLES={mala_n} '
    'IP_DENSITY_MALA_EVAL_N_SAMPLES={mala_eval_n} IP_DENSITY_MALA_STEPS={mala_steps} '
    'IP_DENSITY_MALA_BURNIN={burnin} IP_DENSITY_MALA_DT={dt:g} '
    'IP_DENSITY_MALA_INIT={mala_init} IP_DENSITY_MAP_LAPLACE_STARTS={map_starts} '
    'IP_DENSITY_MAP_LAPLACE_MAX_ITER={map_iter} IP_DENSITY_DRC_PF_STEPS={pf_steps} '
    'IP_DENSITY_DRC_PLOT_LAYOUT={layout} IP_DENSITY_BASELINES={baselines} '
    'IP_DENSITY_RUN_PF_SENSITIVITY={pf_sens} python helmholtz.py'
).format(
    n_signal=N_REF_SIGNAL,
    n_gate=N_REF_GATE,
    n_eval=N_REF_EVAL,
    bank_coupling=DENSITY_BANK_COUPLING,
    eval_source=DENSITY_EVAL_SOURCE,
    mala_n=MALA_N_SAMPLES,
    mala_eval_n=MALA_EVAL_N_SAMPLES,
    mala_steps=MALA_STEPS,
    burnin=MALA_BURNIN,
    dt=MALA_DT,
    mala_init=MALA_INIT,
    map_starts=MAP_LAPLACE_STARTS,
    map_iter=MAP_LAPLACE_MAX_ITER,
    pf_steps=DENSITY_DRC_PF_STEPS,
    layout=DENSITY_DRC_PLOT_LAYOUT,
    baselines=','.join(DENSITY_BASELINES),
    pf_sens=int(bool(DENSITY_RUN_PF_SENSITIVITY)),
)



dashboard = DashboardPDF(
    DASHBOARD_PDF_PATH,
    title='Helmholtz density-evaluation dashboard',
)
dashboard.add_text_page(
    'Helmholtz density-evaluation dashboard',
    [
        f"Created: {datetime.now().isoformat(timespec='seconds')}",
        'This dashboard matches the Darcy/Navier-Stokes density-evaluation benchmark, with configurable score-signal, gate, and held-out density-evaluation banks. By default, density values are evaluated on MALA-EVAL rather than on the score-reference bank.',
        'Primary density diagnostic: true posterior energy -log pi(x) versus probability-flow estimated energy -log q(x), plus affine-calibrated residuals in one publication-style comparison grid.',
        'The comparison-grid plot uses CE-HLSI robust axes to align all rows.',
        f"run_results_dir = {run_results_info['run_results_dir']}",
        '',
        f'run command = {RUN_COMMAND_HINT}',
        '',
        f'seed = {seed}',
        f'ACTIVE_DIM = {ACTIVE_DIM}',
        f'N_REF_SIGNAL = {N_REF_SIGNAL}',
        f'N_REF_GATE = {N_REF_GATE}',
        f'N_REF_EVAL = {N_REF_EVAL}',
        f'DENSITY_BANK_COUPLING = {DENSITY_BANK_COUPLING}',
        f'DENSITY_EVAL_SOURCE = {DENSITY_EVAL_SOURCE}',
        f'DENSITY_EVAL_BANK_COUPLING = {DENSITY_EVAL_BANK_COUPLING}',
        f'MALA_N_SAMPLES = {MALA_N_SAMPLES}',
        f'MALA_EVAL_N_SAMPLES = {MALA_EVAL_N_SAMPLES}',
        f'MALA_STEPS = {MALA_STEPS}',
        f'MALA_BURNIN = {MALA_BURNIN}',
        f'MALA_DT = {MALA_DT}',
        f'MALA_INIT = {MALA_INIT}',
        f'MALA_PRECOND = {MALA_PRECOND}',
        f'MAP_LAPLACE_STARTS = {MAP_LAPLACE_STARTS}',
        f'MAP_LAPLACE_MAX_ITER = {MAP_LAPLACE_MAX_ITER}',
        f'MAP_LAPLACE_TOL = {MAP_LAPLACE_TOL}',
        f'MAP_LAPLACE_RIDGE = {MAP_LAPLACE_RIDGE}',
        f'MAP_LAPLACE_MAX_STEP_NORM = {MAP_LAPLACE_MAX_STEP_NORM}',
        f'MAP_LAPLACE_BACKTRACK_STEPS = {MAP_LAPLACE_BACKTRACK_STEPS}',
        f'DENSITY_REF_SOURCE = {DENSITY_REF_SOURCE}',
        f'DENSITY_DRC_PF_STEPS = {DENSITY_DRC_PF_STEPS}',
        f'DENSITY_TWEEDIE_DIVERGENCE = {DENSITY_TWEEDIE_DIVERGENCE}',
        f'DENSITY_BLEND_DIVERGENCE = {DENSITY_BLEND_DIVERGENCE}',
        f'DENSITY_LFGI_DIVERGENCE = {DENSITY_LFGI_DIVERGENCE}',
        f'DENSITY_BASELINES = {DENSITY_BASELINES}',
        f'DENSITY_KNOWN_LOGZ = {DENSITY_KNOWN_LOGZ}',
        f'DENSITY_RUN_PF_SENSITIVITY = {DENSITY_RUN_PF_SENSITIVITY}',
        f'DENSITY_PF_SENSITIVITY_STEPS = {DENSITY_PF_SENSITIVITY_STEPS}',
        f'DENSITY_PF_SENSITIVITY_TMINS = {DENSITY_PF_SENSITIVITY_TMINS}',
        f'DENSITY_DRC_EVAL_BATCH_SIZE = {DENSITY_DRC_EVAL_BATCH_SIZE}',
        f'DENSITY_DRC_TMIN = {DENSITY_DRC_TMIN}',
        f'DENSITY_DRC_TMAX = {DENSITY_DRC_TMAX}',
        f'DENSITY_DRC_CLIP = {DENSITY_DRC_CLIP}',
        f'DENSITY_DRC_PLOT_AXIS_MODE = {DENSITY_DRC_PLOT_AXIS_MODE}',
        f'DENSITY_DRC_RESIDUAL_AXIS_MODE = {DENSITY_DRC_RESIDUAL_AXIS_MODE}',
        f'DENSITY_DRC_RESIDUAL_KIND = {DENSITY_DRC_RESIDUAL_KIND}',
        f'DENSITY_DRC_AFFINE_FIT_SCOPE = {DENSITY_DRC_AFFINE_FIT_SCOPE}',
        f'DENSITY_DRC_ROBUST_PERCENTILES = {DENSITY_DRC_ROBUST_PERCENTILES}',
        f'DENSITY_DRC_PLOT_LAYOUT = {DENSITY_DRC_PLOT_LAYOUT}',
        f'DENSITY_DRC_GRID_MAX_POINTS = {DENSITY_DRC_GRID_MAX_POINTS}',
        f'DENSITY_DRC_GRID_SAVE_PDF = {DENSITY_DRC_GRID_SAVE_PDF}',
        f'DEFAULT_N_GEN = {DEFAULT_N_GEN}',
        f'NOISE_STD = {NOISE_STD}',
        f'HELMHOLTZ_K = {HELMHOLTZ_K}',
        f'HELMHOLTZ_DAMPING = {HELMHOLTZ_DAMPING}',
        f'N = {N}, N_SOURCES = {N_SOURCES}, N_RECEIVERS = {N_RECEIVERS}, N_HOLDOUT_RECEIVERS = {N_HOLDOUT_RECEIVERS}',
        f'HESS_MIN = {HESS_MIN}, HESS_MAX = {HESS_MAX}',
        f'BUILD_GNL_BANKS = {BUILD_GNL_BANKS}',
        f'PLOT_NORMALIZER = {PLOT_NORMALIZER}',
    ],
)

pipeline = run_standard_sampler_pipeline(
    prior_model,
    lik_model,
    SAMPLER_CONFIGS,
    n_ref=N_REF_SIGNAL,
    build_gnl_banks=BUILD_GNL_BANKS,
    compute_pou=True,
)
precomp = pipeline['precomp']
samples = pipeline['samples']
ess_logs = pipeline['ess_logs']
sampler_run_info = pipeline['sampler_run_info']
display_names = pipeline['display_names']
reference_key = pipeline['reference_key']
reference_title = pipeline['reference_title']

summarize_sampler_run(sampler_run_info)
_sync_sampling_run_results_context()
plot_mean_ess_logs(ess_logs, display_names=display_names)

# Add closed-form density baselines on the same held-out density-eval bank.
# Keep this deliberately small: for the manuscript comparison we need the
# MAP-Laplace Gaussian row to test whether Helmholtz nonlinearity separates
# CE-HLSI from a local Gaussian approximation.
def _first_density_eval_bank(precomp_dict):
    for lab in ('DENS-CE-HLSI', 'DENS-Tweedie', 'DENS-ScalarBlend'):
        bank = precomp_dict.get('eval_banks', {}).get(lab)
        if bank is not None:
            return bank
    for lab in ('DENS-CE-HLSI', 'DENS-Tweedie', 'DENS-ScalarBlend'):
        det = precomp_dict.get('drc_details', {}).get(lab)
        if det is not None:
            return {
                'X_ref': det['X_ref'],
                'log_lik_ref': det['log_lik'],
                'bank_name': det.get('eval_bank_name', f'{lab}_details_eval'),
                'eval_only': True,
            }
    return None

baseline_eval_bank = _first_density_eval_bank(precomp)
if baseline_eval_bank is not None and any(str(b).lower().replace('-', '_') in {'map_laplace', 'laplace_map', 'map'} for b in DENSITY_BASELINES):
    try:
        map_df, map_details, map_component = compute_map_laplace_density_baseline(
            baseline_eval_bank,
            prior_model,
            lik_model,
            label='DENS-MAP-Laplace',
            n_starts=MAP_LAPLACE_STARTS,
            max_iter=MAP_LAPLACE_MAX_ITER,
            tol=MAP_LAPLACE_TOL,
            ridge=MAP_LAPLACE_RIDGE,
            max_step_norm=MAP_LAPLACE_MAX_STEP_NORM,
            backtrack_steps=MAP_LAPLACE_BACKTRACK_STEPS,
            batch_size=max(1, DENSITY_DRC_EVAL_BATCH_SIZE),
            save_dir=run_results_info['run_results_dir'],
            run_stem=run_results_info['run_results_stem'],
            make_plots=False,
            precomp=precomp,
            known_logZ=DENSITY_KNOWN_LOGZ,
            plot_axis_mode=DENSITY_DRC_PLOT_AXIS_MODE,
            residual_axis_mode=DENSITY_DRC_RESIDUAL_AXIS_MODE,
            robust_percentiles=DENSITY_DRC_ROBUST_PERCENTILES,
            residual_kind=DENSITY_DRC_RESIDUAL_KIND,
            affine_fit_scope=DENSITY_DRC_AFFINE_FIT_SCOPE,
            verbose=True,
        )
        display_names['DENS-MAP-Laplace'] = 'MAP-Laplace Gaussian'
        print('\n=== Added MAP-Laplace Gaussian density baseline ===')
        print(map_df.to_string(index=False))
    except Exception as exc:
        print(f"WARNING: MAP-Laplace density baseline failed and will be skipped: {exc}")
elif baseline_eval_bank is None:
    print('WARNING: no density eval bank found; MAP-Laplace density baseline skipped.')

# Optional tiny PF-discretization sensitivity plot for the manuscript sanity
# check. This reuses frozen score specs and held-out eval banks; it does not
# rebuild score/gate banks.
pf_sensitivity_df = pd.DataFrame()
pf_sensitivity_fig_path = None
if DENSITY_RUN_PF_SENSITIVITY:
    try:
        pf_sensitivity_df, pf_sensitivity_fig_path = run_drc_pf_sensitivity_benchmark(
            precomp,
            SAMPLER_CONFIGS,
            prior_model,
            lik_model,
            labels=DENSITY_PF_SENSITIVITY_LABELS,
            pf_steps_list=DENSITY_PF_SENSITIVITY_STEPS,
            tmin_list=DENSITY_PF_SENSITIVITY_TMINS,
            save_dir=run_results_info['run_results_dir'],
            run_stem=run_results_info['run_results_stem'],
            batch_size=max(1, DENSITY_DRC_EVAL_BATCH_SIZE),
            robust_percentiles=DENSITY_DRC_ROBUST_PERCENTILES,
            affine_fit_scope=DENSITY_DRC_AFFINE_FIT_SCOPE,
            known_logZ=DENSITY_KNOWN_LOGZ,
            make_plot=True,
        )
        if not pf_sensitivity_df.empty:
            pf_cols = ['method', 'pf_steps', 't_min', 'affine_energy_rmse', 'slope_normalized_energy_rmse', 'raw_logw_ess', 'pointwise_nll']
            pf_cols = [c for c in pf_cols if c in pf_sensitivity_df.columns]
            dashboard.add_dataframe(
                'Density PF discretization sensitivity',
                pf_sensitivity_df[pf_cols],
                max_rows=30,
                max_cols=7,
                include_index=False,
            )
            if pf_sensitivity_fig_path:
                dashboard.add_image_page(pf_sensitivity_fig_path)
    except Exception as exc:
        print(f'WARNING: density PF sensitivity benchmark failed and will be skipped: {exc}')

# Surface the density/energy benchmark produced by ratio-only nodes plus any
# closed-form baseline rows added above.
drc_energy_tables = precomp.get('drc_energy_benchmarks', {})
if drc_energy_tables:
    drc_energy_df = pd.concat(list(drc_energy_tables.values()), ignore_index=True)
    manuscript_density_df = make_density_manuscript_table(
        drc_energy_df,
        display_names=display_names,
        method_order=('DENS-Tweedie', 'DENS-ScalarBlend', 'DENS-CE-HLSI', 'DENS-MAP-Laplace'),
        include_known_z=DENSITY_KNOWN_LOGZ is not None,
    )
    print('\n=== Density/energy benchmark on configured density-eval bank ===')
    print(drc_energy_df.to_string(index=False))
    print('\n=== Manuscript density table ===')
    print(manuscript_density_df.to_string(index=False))
    manuscript_density_df_path = os.path.join(
        run_results_info['run_results_dir'],
        f"{run_results_info['run_results_stem']}_manuscript_density_table.csv",
    )
    manuscript_density_df.to_csv(manuscript_density_df_path, index=False)
    print(f'Saved manuscript density table to {manuscript_density_df_path}')
    dashboard.add_dataframe(
        'Manuscript density table',
        manuscript_density_df,
        max_rows=20,
        max_cols=8,
        include_index=False,
    )
    dashboard.add_dataframe(
        'Full density/energy benchmark on configured density-eval bank',
        drc_energy_df,
        max_rows=24,
        max_cols=8,
        include_index=False,
    )
else:
    drc_energy_df = pd.DataFrame()
    manuscript_density_df = pd.DataFrame()
    manuscript_density_df_path = None
    print("\nWARNING: no density/energy benchmark was found in precomp['drc_energy_benchmarks'].")

metrics = compute_latent_metrics(
    samples,
    reference_key,
    alpha_true_np,
    prior_model,
    lik_model,
    posterior_score_fn,
    display_names=display_names,
)

gc.collect()
if torch.cuda.is_available():
    torch.cuda.empty_cache()

try:
    metrics = compute_heldout_predictive_metrics(
        samples,
        metrics,
        heldout_forward_eval_fn=lambda a: np.array(solve_forward_holdout(jnp.array(a))),
        batched_forward_eval_fn=lambda a_batch: np.asarray(
            batch_solve_forward_holdout(jnp.asarray(a_batch, dtype=jnp.float64))
        ),
        batched_forward_eval_batch_size=HELDOUT_BATCH_SIZE,
        y_holdout_obs_np=y_holdout_obs_np,
        noise_std=NOISE_STD,
        display_names=display_names,
        min_valid=10,
    )
except Exception as exc:
    print(f"WARNING: held-out predictive metrics failed and will be skipped: {exc}")

Basis_np = np.array(Basis)
support_mask_np = np.array(support_mask_jax)
receiver_row = receiver_flat_indices // N
receiver_col = receiver_flat_indices % N
holdout_receiver_row = holdout_receiver_flat_indices // N
holdout_receiver_col = holdout_receiver_flat_indices % N


def _nearest_grid_index(xy):
    rr_loc = (X - xy[0]) ** 2 + (Y - xy[1]) ** 2
    idx_loc = int(np.argmin(rr_loc))
    return idx_loc // N, idx_loc % N


source_rowcol = [_nearest_grid_index(xy) for xy in source_centers]
source_rows = np.array([rc[0] for rc in source_rowcol])
source_cols = np.array([rc[1] for rc in source_rowcol])


def reconstruct_raw_field(latents):
    if isinstance(latents, torch.Tensor):
        latents = latents.detach().cpu().numpy()
    latents = np.asarray(latents)
    if latents.ndim == 1:
        latents = latents[None, :]
    d_lat = latents.shape[1]
    B = Basis_np[:, :d_lat]
    return (latents @ B.T).reshape((-1, N, N))



def raw_to_contrast(raw_fields):
    raw_fields = np.asarray(raw_fields)
    return SCATTERER_AMPLITUDE * np.tanh(raw_fields) * support_mask_np[None, :, :]



def reconstruct_contrast_field(latents):
    return raw_to_contrast(reconstruct_raw_field(latents))



def latent_to_contrast(alpha):
    raw = reconstruct_raw_field(np.asarray(alpha)[None, :])[0]
    return SCATTERER_AMPLITUDE * np.tanh(raw) * support_mask_np



def unpack_measurement_vector(y_vec):
    y_vec = np.asarray(y_vec)
    out = np.zeros((N_SOURCES, N_RECEIVERS), dtype=np.complex128)
    idx_loc = 0
    for s in range(N_SOURCES):
        re = y_vec[idx_loc:idx_loc + N_RECEIVERS]
        idx_loc += N_RECEIVERS
        im = y_vec[idx_loc:idx_loc + N_RECEIVERS]
        idx_loc += N_RECEIVERS
        out[s] = re + 1j * im
    return out



def solve_complex_fields(alpha_latent, source_idx=0):
    alpha_jax = jnp.array(np.asarray(alpha_latent), dtype=jnp.float64)
    u_scat = np.array(solve_single_pattern(alpha_jax, source_idx))
    u_total = np.array(solve_single_total_field(alpha_jax, source_idx))
    return u_total, u_scat



BOUNDARY_TRACE_COLORS = [
    'tab:blue', 'tab:orange', 'tab:green', 'tab:purple', 'tab:brown',
    'tab:pink', 'tab:olive', 'tab:cyan', 'tab:gray', 'tab:red',
]
BOUNDARY_TRACE_MARKERS = ['o', 's', 'D', '^', 'v', 'P', 'X', '<', '>', 'h']


def trace_style_for_index(index):
    """Fixed-order trace style so CE-HLSI bootstrap variants get distinct colors."""
    color = BOUNDARY_TRACE_COLORS[index % len(BOUNDARY_TRACE_COLORS)]
    marker = BOUNDARY_TRACE_MARKERS[index % len(BOUNDARY_TRACE_MARKERS)]
    return dict(
        color=color,
        linestyle='--',
        linewidth=1.55,
        alpha=0.92,
        zorder=6 + index,
        marker=marker,
        markersize=3.2,
        markerfacecolor='white',
        markeredgewidth=0.8,
        markevery=4,
    )


def trace_style_for_label(label):
    # Backward-compatible fallback for any old call sites. New boundary-trace
    # plotting uses trace_style_for_index(...) to guarantee distinct colors.
    return trace_style_for_index(0)


def legend_priority(label):
    label_l = label.lower()
    if label == 'Clean':
        return 0
    if label == 'Noisy obs':
        return 1
    if 'hlsi' in label_l and 'wc' not in label_l and 'ce' not in label_l:
        return 2
    if 'blend' in label_l:
        return 3
    if 'tweedie' in label_l:
        return 4
    if 'prior' in label_l or 'mala' in label_l:
        return 5
    return 6


true_raw = reconstruct_raw_field(alpha_true_np)[0]
true_field = latent_to_contrast(alpha_true_np)
true_meas = unpack_measurement_vector(y_clean_np)
obs_meas = unpack_measurement_vector(y_obs_np)
theta_receivers = 2.0 * np.pi * receiver_boundary_pos / n_boundary

mean_fields, metrics = compute_field_summary_metrics(
    samples,
    metrics,
    alpha_true_np,
    true_field,
    field_from_latent_fn=latent_to_contrast,
    forward_eval_fn=lambda a: np.array(solve_forward(jnp.array(a))),
    y_ref_np=y_obs_np,
    display_names=display_names,
    min_valid=10,
    d_lat=ACTIVE_DIM,
)

print('\n=== Helmholtz field/data metrics ===')
print(f"{'Method':<24} | {'RelL2_q (%)':<12} | {'Pearson':<10} | {'RMSE_a':<12} | {'FwdRel':<12}")
print('-' * 84)
for label in mean_fields:
    data = metrics[label]
    print(f"{display_names.get(label, label):<24} | {100.0 * data['RelL2_field']:<12.4f} | {data.get('Pearson_field', float('nan')):<10.4f} | {data['RMSE_alpha']:<12.4e} | {data['FwdRelErr']:<12.4e}")

plot_normalizer_key = resolve_plot_normalizer(PLOT_NORMALIZER, list(mean_fields.keys()), display_names=display_names, metrics_dict=metrics, fallback=reference_key, best_metric_keys=('RelL2_field', 'IC RelL2(%)', 'RelL2_q(%)'))
plot_normalizer_title = display_names.get(plot_normalizer_key, plot_normalizer_key)
_sync_sampling_run_results_context()
plot_pca_histograms(samples, alpha_true_np, display_names=display_names, normalizer=plot_normalizer_key, metrics_dict=metrics, fallback_key=reference_key)

results_df, results_runinfo_df, results_df_path, results_runinfo_df_path = save_results_tables(metrics, sampler_run_info, n_ref=N_REF_SIGNAL, target_name='Helmholtz scattering density evaluation', display_names=display_names, reference_name=reference_title)

dashboard.add_results_tables(results_df, results_runinfo_df)

save_reproducibility_log(
    title='Helmholtz scattering density-evaluation reproducibility log',
    config={
        'seed': seed,
        'ACTIVE_DIM': ACTIVE_DIM,
        'N_REF_SIGNAL': N_REF_SIGNAL,
        'N_REF_GATE': N_REF_GATE,
        'N_REF_EVAL': N_REF_EVAL,
        'DENSITY_SOURCE_REQUIRED_N': DENSITY_SOURCE_REQUIRED_N,
        'DENSITY_BANK_COUPLING': DENSITY_BANK_COUPLING,
        'DENSITY_EVAL_SOURCE': DENSITY_EVAL_SOURCE,
        'DENSITY_EVAL_BANK_COUPLING': DENSITY_EVAL_BANK_COUPLING,
        'PLOT_NORMALIZER': PLOT_NORMALIZER,
        'HESS_MIN': HESS_MIN,
        'HESS_MAX': HESS_MAX,
        'NOISE_STD': NOISE_STD,
        'MALA_N_SAMPLES': MALA_N_SAMPLES,
        'MALA_EVAL_N_SAMPLES': MALA_EVAL_N_SAMPLES,
        'MALA_EVAL_STEPS': MALA_EVAL_STEPS,
        'MALA_EVAL_BURNIN': MALA_EVAL_BURNIN,
        'MALA_EVAL_DT': MALA_EVAL_DT,
        'MALA_EVAL_INIT': MALA_EVAL_INIT,
        'MALA_STEPS': MALA_STEPS,
        'MALA_BURNIN': MALA_BURNIN,
        'MALA_DT': MALA_DT,
        'MALA_INIT': MALA_INIT,
        'MALA_PRECOND': MALA_PRECOND,
        'MAP_LAPLACE_STARTS': MAP_LAPLACE_STARTS,
        'MAP_LAPLACE_MAX_ITER': MAP_LAPLACE_MAX_ITER,
        'MAP_LAPLACE_TOL': MAP_LAPLACE_TOL,
        'MAP_LAPLACE_RIDGE': MAP_LAPLACE_RIDGE,
        'MAP_LAPLACE_MAX_STEP_NORM': MAP_LAPLACE_MAX_STEP_NORM,
        'MAP_LAPLACE_BACKTRACK_STEPS': MAP_LAPLACE_BACKTRACK_STEPS,
        'DENSITY_REF_SOURCE': DENSITY_REF_SOURCE,
        'DENSITY_DRC_PF_STEPS': DENSITY_DRC_PF_STEPS,
        'DENSITY_DRC_EVAL_BATCH_SIZE': DENSITY_DRC_EVAL_BATCH_SIZE,
        'DENSITY_DRC_TMIN': DENSITY_DRC_TMIN,
        'DENSITY_DRC_TMAX': DENSITY_DRC_TMAX,
        'DENSITY_DRC_CLIP': DENSITY_DRC_CLIP,
        'DENSITY_DRC_TEMPERATURE': DENSITY_DRC_TEMPERATURE,
        'DENSITY_DRC_PLOT_AXIS_MODE': DENSITY_DRC_PLOT_AXIS_MODE,
        'DENSITY_DRC_RESIDUAL_AXIS_MODE': DENSITY_DRC_RESIDUAL_AXIS_MODE,
        'DENSITY_DRC_RESIDUAL_KIND': DENSITY_DRC_RESIDUAL_KIND,
        'DENSITY_DRC_AFFINE_FIT_SCOPE': DENSITY_DRC_AFFINE_FIT_SCOPE,
        'DENSITY_DRC_ROBUST_PERCENTILES': DENSITY_DRC_ROBUST_PERCENTILES,
        'DENSITY_DRC_SAVE_RAW_PLOTS': DENSITY_DRC_SAVE_RAW_PLOTS,
        'DENSITY_DRC_SAVE_LOGLOG_PLOTS': DENSITY_DRC_SAVE_LOGLOG_PLOTS,
        'DENSITY_DRC_SAVE_LOGRATIO_RESIDUAL_PLOTS': DENSITY_DRC_SAVE_LOGRATIO_RESIDUAL_PLOTS,
        'DENSITY_DRC_SAVE_LEGACY_ALIAS': DENSITY_DRC_SAVE_LEGACY_ALIAS,
        'DENSITY_DRC_PLOT_LAYOUT': DENSITY_DRC_PLOT_LAYOUT,
        'DENSITY_DRC_GRID_MAX_POINTS': DENSITY_DRC_GRID_MAX_POINTS,
        'DENSITY_DRC_GRID_SAVE_PDF': DENSITY_DRC_GRID_SAVE_PDF,
        'DENSITY_TWEEDIE_DIVERGENCE': DENSITY_TWEEDIE_DIVERGENCE,
        'DENSITY_BLEND_DIVERGENCE': DENSITY_BLEND_DIVERGENCE,
        'DENSITY_LFGI_DIVERGENCE': DENSITY_LFGI_DIVERGENCE,
        'DENSITY_DIV_PROBES': DENSITY_DIV_PROBES,
        'DENSITY_BASELINES': DENSITY_BASELINES,
        'DENSITY_KNOWN_LOGZ': DENSITY_KNOWN_LOGZ,
        'DENSITY_RUN_PF_SENSITIVITY': DENSITY_RUN_PF_SENSITIVITY,
        'DENSITY_PF_SENSITIVITY_LABELS': DENSITY_PF_SENSITIVITY_LABELS,
        'DENSITY_PF_SENSITIVITY_STEPS': DENSITY_PF_SENSITIVITY_STEPS,
        'DENSITY_PF_SENSITIVITY_TMINS': DENSITY_PF_SENSITIVITY_TMINS,
        'RUN_COMMAND_HINT': RUN_COMMAND_HINT,
        'HELDOUT_BATCH_SIZE': HELDOUT_BATCH_SIZE,
        'num_holdout_observation': num_holdout_observation,
        'N_HOLDOUT_RECEIVERS': N_HOLDOUT_RECEIVERS,
        'num_observation': num_observation,
        'num_truncated_series': num_truncated_series,
        'num_modes_available': num_modes_available,
        'SAMPLER_CONFIGS': SAMPLER_CONFIGS,
    },
    extra_sections={
        'saved_results_files': {
            'metrics_csv': results_df_path,
            'runinfo_csv': results_runinfo_df_path,
            'dashboard_pdf': DASHBOARD_PDF_PATH,
            'manuscript_density_table_csv': manuscript_density_df_path,
            'pf_sensitivity_figure': pf_sensitivity_fig_path,
        },
        'drc_density_energy_benchmark': (
            drc_energy_df.to_dict('records') if isinstance(drc_energy_df, pd.DataFrame) and not drc_energy_df.empty else []
        ),
        'manuscript_density_table': (
            manuscript_density_df.to_dict('records') if isinstance(manuscript_density_df, pd.DataFrame) and not manuscript_density_df.empty else []
        ),
        'density_pf_sensitivity': (
            pf_sensitivity_df.to_dict('records') if isinstance(pf_sensitivity_df, pd.DataFrame) and not pf_sensitivity_df.empty else []
        ),
        'summary_stats': {
            'reference_key': reference_key,
            'reference_title': reference_title,
            'plot_normalizer_key': plot_normalizer_key,
            'plot_normalizer_title': plot_normalizer_title,
            'num_methods_evaluated': len(results_df.columns),
            'num_methods_with_samples': len(samples),
            'num_methods_with_mean_fields': len(mean_fields),
            'num_methods_with_ess_logs': len(ess_logs),
        },
    },
)


def _overlay_field(ax):
    ax.scatter(receiver_col, receiver_row, c='lime', s=12, marker='s', alpha=0.8)
    ax.scatter(source_cols, source_rows, c='cyan', s=50, marker='*', alpha=0.9)
    ax.contour(support_mask_np, levels=[0.5], colors='white', linewidths=1.0)


fig_field, axes_field = plot_field_reconstruction_grid(
    samples,
    mean_fields,
    reconstruct_contrast_field,
    display_names=display_names,
    true_field=true_field,
    plot_normalizer_key=plot_normalizer_key,
    reference_bottom_panel=true_raw,
    reference_bottom_title='Ground Truth\nRaw latent field $m(x)$',
    field_cmap='RdBu_r',
    sample_cmap='RdBu_r',
    bottom_cmap='RdBu_r',
    overlay_reference_fn=_overlay_field,
    overlay_method_fn=_overlay_field,
    suptitle=f'Nonlinear Helmholtz inverse scattering (d={ACTIVE_DIM}, k={HELMHOLTZ_K:g})',
    field_name='Contrast $q(x)$',
)
_sync_sampling_run_results_context()
if DASHBOARD_SHOW_FIGURES:
    plt.show()
else:
    _save_open_figures_to_current_helmholtz_run()
plt.close(fig_field)

print('\nVisualizing complex wavefields for source 0...')
methods_to_plot = [label for label in samples.keys() if label in mean_fields]
n_cols = len(methods_to_plot) + 1
wave_reference_latent = alpha_true_np
wave_reference_total_s0, wave_reference_scat_s0 = solve_complex_fields(wave_reference_latent, source_idx=0)
amp_reference = np.log10(np.abs(wave_reference_scat_s0) + 1e-6)
phase_reference = np.angle(wave_reference_total_s0)
fig2, axes2 = plt.subplots(2, n_cols, figsize=(4 * n_cols, 8))

im_amp0 = axes2[0, 0].imshow(amp_reference, cmap='magma', origin='lower')
axes2[0, 0].scatter(source_cols[0], source_rows[0], c='cyan', s=60, marker='*')
axes2[0, 0].set_title('Ground Truth\nlog10 |u_scat| (src 0)', fontsize=14)
axes2[0, 0].axis('off')
plt.colorbar(im_amp0, ax=axes2[0, 0], fraction=0.046, pad=0.04)

im_phase0 = axes2[1, 0].imshow(phase_reference, cmap='twilight', origin='lower', vmin=-np.pi, vmax=np.pi)
axes2[1, 0].scatter(source_cols[0], source_rows[0], c='cyan', s=60, marker='*')
axes2[1, 0].set_title('Ground Truth\narg(u_total) (src 0)', fontsize=14)
axes2[1, 0].axis('off')
plt.colorbar(im_phase0, ax=axes2[1, 0], fraction=0.046, pad=0.04)

amp_vmin = float(np.min(amp_reference))
amp_vmax = float(np.max(amp_reference))
for i, label in enumerate(methods_to_plot):
    col = i + 1
    samps_clean = get_valid_samples(samples[label])
    if samps_clean.shape[0] < 10:
        axes2[0, col].axis('off')
        axes2[1, col].axis('off')
        continue
    mean_lat = np.mean(samps_clean, axis=0)[:ACTIVE_DIM]
    u_total, u_scat = solve_complex_fields(mean_lat, source_idx=0)
    axes2[0, col].imshow(np.log10(np.abs(u_scat) + 1e-6), cmap='magma', origin='lower', vmin=amp_vmin, vmax=amp_vmax)
    axes2[0, col].scatter(source_cols[0], source_rows[0], c='cyan', s=30, marker='*')
    axes2[0, col].set_title(f"{display_names.get(label, label)}\nlog10 |u_scat|", fontsize=14)
    axes2[0, col].axis('off')
    axes2[1, col].imshow(np.angle(u_total), cmap='twilight', origin='lower', vmin=-np.pi, vmax=np.pi)
    axes2[1, col].scatter(source_cols[0], source_rows[0], c='cyan', s=30, marker='*')
    axes2[1, col].set_title(f"{display_names.get(label, label)}\narg(u_total)", fontsize=14)
    axes2[1, col].axis('off')
plt.tight_layout()
try:
    _save_open_figures_to_current_helmholtz_run()
except Exception:
    pass
if DASHBOARD_SHOW_FIGURES:
    plt.show()
plt.close(fig2)

print('\nVisualizing boundary receiver traces for source 0...')
fig3, axes3 = plt.subplots(2, 2, figsize=(32, 7.8), sharex='col', gridspec_kw={'height_ratios': [1.0, 1.0], 'wspace': 0.14, 'hspace': 0.16})
(ax3a, ax3b), (ax3c, ax3d) = axes3
y_true_s0 = true_meas[0]
y_obs_s0 = obs_meas[0]
real_true = np.real(y_true_s0)
imag_true = np.imag(y_true_s0)
real_obs = np.real(y_obs_s0)
imag_obs = np.imag(y_obs_s0)
model_trace_data = OrderedDict()
for trace_idx, label in enumerate(methods_to_plot[:4]):
    samps_clean = get_valid_samples(samples[label])
    if samps_clean.shape[0] < 10:
        continue
    mean_lat = np.mean(samps_clean, axis=0)[:ACTIVE_DIM]
    y_pred = unpack_measurement_vector(np.array(solve_forward(jnp.array(mean_lat))))[0]
    pretty_label = display_names.get(label, label)
    model_trace_data[pretty_label] = {'real': np.real(y_pred).copy(), 'imag': np.imag(y_pred).copy(), 'style': trace_style_for_index(trace_idx)}
obs_scatter_style = dict(color='tab:red', s=10, alpha=0.42, linewidths=0.0, zorder=1)
clean_main_style = dict(color='k', linewidth=2.4, alpha=0.92, zorder=4)
resid_zero_style = dict(color='0.25', linewidth=1.0, linestyle='--', alpha=0.75, zorder=0)
ax3a.plot(theta_receivers, real_true, label='Clean', **clean_main_style)
ax3b.plot(theta_receivers, imag_true, label='Clean', **clean_main_style)
ax3a.scatter(theta_receivers, real_obs, label='Noisy obs', **obs_scatter_style)
ax3b.scatter(theta_receivers, imag_obs, label='Noisy obs', **obs_scatter_style)
real_resid_max = 0.0
imag_resid_max = 0.0
hlsi_main_real = None
hlsi_main_imag = None
for pretty_label, trace_info in model_trace_data.items():
    main_style = trace_info['style']
    resid_style = dict(main_style)
    resid_style['linewidth'] = max(1.1, 0.92 * main_style.get('linewidth', 1.4))
    resid_style['alpha'] = min(0.98, main_style.get('alpha', 0.9))
    resid_style['zorder'] = main_style.get('zorder', 6)
    real_pred = trace_info['real']
    imag_pred = trace_info['imag']
    real_resid = np.abs(real_pred - real_true)
    imag_resid = np.abs(imag_pred - imag_true)
    ax3a.plot(theta_receivers, real_pred, label=pretty_label, **main_style)
    ax3b.plot(theta_receivers, imag_pred, label=pretty_label, **main_style)
    ax3c.plot(theta_receivers, real_resid, label=pretty_label, **resid_style)
    ax3d.plot(theta_receivers, imag_resid, label=pretty_label, **resid_style)
    real_resid_max = max(real_resid_max, float(np.max(np.abs(real_resid))))
    imag_resid_max = max(imag_resid_max, float(np.max(np.abs(imag_resid))))
    if pretty_label.lower() == 'hlsi':
        hlsi_main_real = real_pred
        hlsi_main_imag = imag_pred
ax3c.axhline(0.0, **resid_zero_style)
ax3d.axhline(0.0, **resid_zero_style)
for ax in [ax3a, ax3b, ax3c, ax3d]:
    ax.grid(True, alpha=0.28)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
if hlsi_main_real is not None:
    real_lo = min(np.min(real_true), np.min(hlsi_main_real))
    real_hi = max(np.max(real_true), np.max(hlsi_main_real))
    real_pad = max(1e-8, 0.12 * (real_hi - real_lo))
    ax3a.set_ylim(real_lo - real_pad, real_hi + real_pad)
if hlsi_main_imag is not None:
    imag_lo = min(np.min(imag_true), np.min(hlsi_main_imag))
    imag_hi = max(np.max(imag_true), np.max(hlsi_main_imag))
    imag_pad = max(1e-8, 0.12 * (imag_hi - imag_lo))
    ax3b.set_ylim(imag_lo - imag_pad, imag_hi + imag_pad)
if real_resid_max > 0:
    ax3c.set_ylim(0.0, 1.15 * real_resid_max)
if imag_resid_max > 0:
    ax3d.set_ylim(0.0, 1.15 * imag_resid_max)
ax3a.set_title('Source-0 boundary traces: real part', fontsize=15)
ax3b.set_title('Source-0 boundary traces: imaginary part', fontsize=15)
ax3a.set_ylabel('Signal', fontsize=13)
ax3c.set_ylabel('|Residual|', fontsize=13)
ax3c.set_xlabel('Boundary angle (rad)', fontsize=13)
ax3d.set_xlabel('Boundary angle (rad)', fontsize=13)
handles, labels = [], []
for ax in (ax3a, ax3b):
    h, l = ax.get_legend_handles_labels()
    handles.extend(h)
    labels.extend(l)
legend_map = OrderedDict()
for h, l in zip(handles, labels):
    if l not in legend_map:
        legend_map[l] = h
fig3.legend(legend_map.values(), legend_map.keys(), loc='upper center', ncol=min(6, len(legend_map)), frameon=False, fontsize=10, bbox_to_anchor=(0.5, 1.02))
fig3.suptitle('Source-0 scattered-field boundary traces', fontsize=16, y=1.08)
plt.tight_layout(rect=[0.0, 0.0, 1.0, 0.96])
try:
    _save_open_figures_to_current_helmholtz_run()
except Exception:
    pass
if DASHBOARD_SHOW_FIGURES:
    plt.show()
plt.close(fig3)

print('\nVisualizing Gauss-Newton curvature spectrum...')
fig4, ax4 = plt.subplots(1, 1, figsize=(9, 5))
true_curv = np.linalg.eigvalsh(-np.array(lik_aux['hess_lik_gn_jax'](jnp.array(alpha_true_np), jnp.array(y_obs_np), NOISE_STD)))
true_curv = np.clip(np.sort(true_curv)[::-1], 1e-16, None)
ax4.semilogy(np.arange(1, true_curv.size + 1), true_curv, marker='o', linewidth=2, label='Truth GN spectrum')
if reference_key in mean_fields:
    ref_alpha = np.asarray(metrics[reference_key]['mean_latent'])
    ref_curv = np.linalg.eigvalsh(-np.array(lik_aux['hess_lik_gn_jax'](jnp.array(ref_alpha), jnp.array(y_obs_np), NOISE_STD)))
    ref_curv = np.clip(np.sort(ref_curv)[::-1], 1e-16, None)
    ax4.semilogy(np.arange(1, ref_curv.size + 1), ref_curv, marker='s', linewidth=2, label=f'{display_names.get(reference_key, reference_key)} GN spectrum')
ax4.axhline(HESS_MIN, linestyle='--', linewidth=1.5, label='HESS_MIN')
ax4.axhline(HESS_MAX, linestyle='--', linewidth=1.5, label='HESS_MAX')
ax4.set_xlabel('Eigenvalue rank', fontsize=13)
ax4.set_ylabel('Curvature magnitude', fontsize=13)
ax4.set_title('Gauss-Newton curvature spectrum', fontsize=15)
ax4.grid(True, which='both', alpha=0.25)
ax4.legend(fontsize=9)
plt.tight_layout()
try:
    _save_open_figures_to_current_helmholtz_run()
except Exception:
    pass
if DASHBOARD_SHOW_FIGURES:
    plt.show()
plt.close(fig4)

_save_open_figures_to_current_helmholtz_run()
try:
    sampling._save_all_open_figures_to_run_results()
except Exception as exc:
    print(f'WARNING: final open-figure save before dashboard failed: {exc}')

dashboard.add_run_results_png_figures(run_results_info['run_results_dir'])
dashboard.close()
# sampling.py now accepts extra_paths in the artifact-complete zip helper.  The
# fallback keeps this Helmholtz script runnable with older helper versions, but
# the complete-artifact behavior requires the updated sampling.py from the
# Navier-Stokes patch.
try:
    run_results_zip_path = zip_run_results_dir(extra_paths=[DASHBOARD_PDF_PATH])
except TypeError:
    run_results_zip_path = zip_run_results_dir()
print(f'Dashboard PDF: {DASHBOARD_PDF_PATH}')
print(f'Run-results zip: {run_results_zip_path}')
print('\n=== Helmholtz density-evaluation pipeline complete ===')
