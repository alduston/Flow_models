# Helmholtz: ten NS-analogous GAD/MALA repeats on Vista

This self-contained bundle adapts the uploaded Helmholtz density-evaluation script into the same iterative-sampling comparison used in the completed Navier–Stokes repeats. Each run executes GAD rounds 1, 2, and 3 and an independent prior-initialized MALA baseline. Tables and figures report GAD 1, GAD 3, and MALA. Round 2 remains part of round 3's execution and cumulative work.

## Start

Place the ZIP in your existing `GAD_IP` directory:

```bash
cd /work/10812/ald4435/frontera/Flow_models/Flow_models/GAD/GAD_IP
unzip GAD_helmholtz_vista_repeats.zip
bash helmholtz_repeats/submit_repeats.sh
squeue -u "$USER"
```

This submits ten GPU tasks for seeds 42–51 and a dependent aggregation job. At most two repeats run simultaneously by default. Each task has a four-hour reservation on `gh`; aggregation has 15 minutes on the same partition. These are time requests, not measured runtime predictions for this new configuration.

Optional account, time, and concurrency settings:

```bash
bash helmholtz_repeats/submit_repeats.sh -A YOUR_ACCOUNT -t 04:00:00 --max-parallel 2
```

The account applies to both jobs. The working environment is the existing `$SCRATCH/venvs/hlsi`, with gcc/13.2.0 and python3/3.11.8. Override its path through `IP_VENV_DIR`. Required packages are GPU-enabled JAX and PyTorch, NumPy, SciPy, pandas, and Matplotlib. No NUTS or density-surrogate packages are required. Both JAX and PyTorch must see the GPU; a silent CPU fallback is rejected.

The bundle contains the exact shared `sampling.py` used by the NS repeats. Existing files in your repository are left intact. Every batch snapshots its source and gives each seed a separate working directory, preventing races on the original script's `data/Basis.csv` and `data/obs_locations.csv`. Inherited sampler/density overrides are cleared for publication runs.

## Adaptation and defaults

The supplied Helmholtz grid, KL construction, forward solver, sources/receivers, contrast transformation, synthetic truth, and noise are preserved. The density-specific MALA-bank/density-surrogate/MAP-Laplace experiment is replaced with the NS sampler comparison. Original Helmholtz and NS scripts are retained under `provenance/`, together with source hashes.

| Setting | Helmholtz repeat |
| --- | --- |
| Independent master seeds | 42–51 |
| Grid / latent coefficients | 32×32 / 32 |
| GAD reference and gate bank | 2,000 shared, equally weighted particles |
| Generated particles per method | 2,000 |
| GAD rounds executed / reported | 1, 2, 3 / 1 and 3 |
| Reverse SDE | stochastic reverse-OU Heun, 200 log-time steps |
| Diffusion interval | 10 to 10^(-2.5) |
| Clean information proxy | standard Gaussian prior + Gauss–Newton likelihood |
| Hessian spectral band / curvature ridge | [1e-6, 1e6] / 1e-6 |
| MALA initialization / chains | standard Gaussian prior / 32 |
| MALA warmup / retained draws per chain | 217 / 63 |
| MALA reported draws | 2,000 from 2,016 generated post-warmup draws |
| MALA thinning / initial h | 1 / 1e-4 |
| MALA adaptation | warmup-only dual averaging, target acceptance 0.574 |
| MALA h bounds | [1e-12, 1e-1] |
| GAD work proxy after rounds 1 / 3 | 6,000 / 18,000 |
| MALA work proxy | 17,984 |
| Likelihood / gradient / GN batch sizes | 50 / 25 / 2 |
| Held-out forward-evaluation batch size | 2 |

The sampler settings match NS. Held-out evaluation batches are reduced from NS's eight to two because Helmholtz uses dense complex solves. This changes the evaluation batching, not the samples or mathematical metric. The Hessian cap is the NS value 1e6, replacing the original density experiment's 1e8 cap.

The master seed changes the synthetic coefficients, training/held-out noise, and sampler randomness. Sources and receiver locations stay fixed. The uncertainty therefore describes ten synthetic problem realizations, with methods paired within each realization; these are not ten restarts of one fixed posterior. Seed 42 retains the uploaded Helmholtz truth/noise convention.

## Preserved Helmholtz problem

The prior KL basis uses the covariance `exp(-distance/0.10)` with unit variance on the 32×32 unit-square grid. The leading 32 modes of the 100 saved modes parameterize a raw field. Contrast is `0.45*tanh(raw_field)*support_mask`, with radial logistic support centered at (0.5,0.5), radius 0.30, and softness 0.035. Squared refractive index is one plus contrast. Truth coefficients are `0.95*standard_normal(32)*linspace(1,0.45,32)`; the inference prior remains N(0,I).

The preserved discrete operator is the edge-assembled negative graph Laplacian, minus `24^2*n_squared` on its diagonal, plus global complex damping `6i*I`. The graph boundary rows and global damping are exactly those in the supplied script; no new outgoing-radiation or absorbing-layer condition is introduced. Each forward call solves a 1024×1024 complex system for four source right-hand sides and subtracts the homogeneous background solution.

Four normalized complex Gaussian sources have width 0.055 and the original centers `(0.18,0.22)`, `(0.82,0.26)`, `(0.74,0.82)`, and `(0.24,0.76)`. Sixty-four deterministic boundary receivers provide 512 real training components (real and imaginary parts for each source). All 60 remaining boundary locations provide 480 disjoint held-out components. Independent observation noise has standard deviation 4e-4 per real component. Exact basis, source, receiver, support, truth, clean data, and noisy data arrays are saved per seed.

## Metrics, work, and uncertainty

The primary table matches the NS columns: coefficient RMSE, contrast-field RMSE, forward relative error, held-out predictive NLL, and the legacy `KLdiag` diagnostic. Field reconstruction evaluates contrast at the posterior coefficient mean, following the existing field-summary convention. Forward error compares that coefficient mean's predicted training measurements with **noise-free** training data, matching NS; the original density script used noisy training data for this scalar error. The secondary table includes KSD, standardized held-out residual RMS (target 1), complex scattered-wavefield RMSE, and cumulative work.

`RMSE_wavefield` is the square root of the mean squared complex modulus error, across all grid nodes and all four sources, evaluated at the coefficient mean. It is the Helmholtz state-error counterpart to final-vorticity RMSE in NS. The displayed wavefield figure uses source 0; the scalar metric uses all four sources.

Held-out NLL uses the NS helper's Gaussian approximation to posterior predictive samples, adds observation-noise variance, and averages NLL over the 480 real components. Standardized residual RMS uses marginal predictive variances. Covariance jitter and any diagonal fallback are recorded in `evaluation_diagnostics.json`. A missing/nonfinite required metric or failed predictive evaluation blocks completion.

The existing NS evaluation helper removes coordinatewise 5-IQR extreme samples before metrics. This rule is preserved for comparability; the sampler still uses its unweighted banks. Raw sample counts, retained counts/fractions, and the additional retained count used by the legacy KL helper are reported. Raw nonfinite particle outputs, including the hidden second round, fail the run rather than being silently discarded. Every raw bank is archived. The legacy `KLdiag` computes five-nearest-neighbor entropy plus unnormalized negative log-posterior energy; the unknown log normalizer is omitted. It is not an absolute, normalized KL. MMD uses MALA as its comparison reference, with self-MMD zero by construction, and is not an independent accuracy guarantee. The shared KSD uses RBF bandwidths 0.1/0.2/0.4/0.8 and at most 1,000 retained particles.

The work proxy counts clean likelihood, score, and Gauss–Newton bank evaluations, including all three GAD rounds and MALA initialization/warmup/production. It does not price dense complex factorizations, reverse-flow algebra, compilation, or evaluation as full end-to-end FLOPs. Treat the comparison as approximately **matched portable work proxy**, not matched wall time or FLOPs. Runtime and detailed work counts are archived.

Aggregation requires all ten valid seeds, expected settings, unchanged source/output hashes, finite primary metrics, and the expected cumulative work counts. Tables report mean ± sample SD across the ten realizations. `paired_contrasts.csv` reports GAD3−MALA, GAD1−MALA, and GAD3−GAD1 with 95% percentile-bootstrap intervals for their mean paired differences, using 10,000 resamples and seed 20261021, matching the NS repeat bundle. The calibration RMS should be read relative to one rather than mechanically minimized. Auxiliary nonfinite diagnostics remain visible in numeric counts.

## Figures and archives

Each seed saves vector PDFs, 400-dpi PNGs, a dashboard, and metadata for:

- Contrast at the coefficient mean, absolute reconstruction error, and posterior contrast sample SD, with color limits shared across methods within each row.
- Real/imaginary scattered wavefields for source 0, using shared row-wise color scales.
- PCA histograms of the retained posterior banks: one shared basis from the preselected GAD3 bank, common axes and density scales, 60×60 bins, full retained-bank normalization, no smoothing or extra window clipping, and a synthetic-truth marker. Projection basis, center, and limits are saved.
- The shared helper's ESS-versus-diffusion-time diagnostic.

The batch is created under `GAD_IP/batches/helmholtz_repeats_<timestamp>_<pid>/`. It contains immediate `run_job_id.txt` and `aggregate_job_id.txt` records and preserved submission logs. Main results:

- `meta_results/helmholtz/headline_table.tex` and `meta_metrics.csv`.
- `meta_results/secondary_table.tex`.
- `meta_results/metrics_per_seed.csv`, `metrics_numeric.csv`, and `paired_contrasts.csv`.
- `meta_results/runinfo_per_seed.csv`, `runinfo_summary.csv`, and `aggregation_audit.json`.
- `helmholtz/run_results/seed_*/`: isolated runs, actual software/hardware records, frozen configuration, exact realization arrays, raw particle banks, figures, and logs.
- **`manuscript_update_inputs.zip`**: the handoff to return. It includes tables, all-round banks, realization arrays, field summaries, configurations, logs, and the preselected seed-42 PDFs. Keep the full batch for every seed's high-resolution figure files.

## Recovery and optional GPU smoke check

After interrupted jobs finish, resume only missing or failed seeds:

```bash
bash helmholtz_repeats/submit_repeats.sh --resume-batch /absolute/path/to/the/batch
```

The launcher refuses resubmission while saved jobs remain active. Failed attempts are moved outside the aggregator's run tree; completed seeds with valid hashes are skipped. If only aggregation submission failed, the run-array ID remains saved, and the same resume command can schedule aggregation after the runs finish without rerunning valid experiments.

Optional short GPU integration check, from `GAD_IP`:

```bash
sbatch helmholtz_repeats/smoke_test.slurm
```

It keeps the full Helmholtz forward model but uses 64 particles and four Heun steps, records `run_kind=smoke`, and saves under a separate `helmholtz_smoke_<jobid>` directory. It cannot enter the ten-seed publication aggregation. This checks the runtime environment and numerical path, not the accuracy of the production schedule.

Local checks are available with `python -m unittest discover -s helmholtz_repeats/tests -v`. Production GPU Helmholtz experiments have not been executed during bundle preparation. The checks cover the preserved physics, default sampler schedule, imports, orchestration, aggregation, and layout; no synthetic result is delivered as an experiment.
