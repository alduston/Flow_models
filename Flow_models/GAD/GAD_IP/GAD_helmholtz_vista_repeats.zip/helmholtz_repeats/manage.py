#!/usr/bin/env python3
"""Isolated, frozen-source repetitions of the uploaded GAD inverse problems."""
import argparse
import ast
import datetime as dt
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import runpy
import shutil
import socket
import subprocess
import sys
import time
import traceback
import zipfile

PROBLEMS = {"helmholtz": "helmholtz.py"}
SEEDS = list(range(42, 52))
METHODS = ["LFGI-GAD-1", "LFGI-GAD-3", "MALA"]
PRIMARY_METRICS = ["RMSE_alpha", "RMSE_field", "FwdRelErr", "HeldoutPredNLL", "KLdiag", "KSD", "HeldoutStdResRMS"]
STATE_METRICS = {"helmholtz": "RMSE_wavefield"}


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def dump(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    tmp.replace(path)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def assignments():
    return [(p, s) for p in PROBLEMS for s in SEEDS]


def verify_source(batch):
    manifest = json.loads((batch / 'batch_manifest.json').read_text())
    for rel, expected in manifest['snapshot_sha256'].items():
        if digest(batch / 'source' / rel) != expected:
            raise RuntimeError(f'Frozen source changed: {rel}; create a new batch')
    return manifest


def verified_status(batch, seed):
    status_path = batch / 'helmholtz/run_results' / f'seed_{seed}' / 'status.json'
    status = json.loads(status_path.read_text())
    if status.get('status') != 'complete' or status.get('problem') != 'helmholtz' or status.get('seed') != seed:
        raise ValueError(f'Seed {seed} is not complete')
    for rel, expected in status['artifact_sha256'].items():
        path = (batch / rel).resolve()
        if not path.is_relative_to(batch.resolve()) or digest(path) != expected:
            raise ValueError(f'Seed {seed}: modified or missing artifact {rel}')
    config = json.loads((batch / status['config_json']).read_text())
    expected = dict(seed=seed, run_kind='paper', N=32, ACTIVE_DIM=32, N_REF=2000,
        DEFAULT_N_GEN=2000, ITERATIVE_TRANSPORT_ROUNDS=3, TRANSPORT_STEPS=200,
        MALA_N_CHAINS=32, MALA_WARMUP=217, MALA_THIN=1, MALA_DT=1e-4,
        MALA_TARGET_ACCEPT=.574, HESS_MIN=1e-6, HESS_MAX=1e6, HELDOUT_BATCH_SIZE=2,
        NOISE_STD=4e-4, HELMHOLTZ_K=24., HELMHOLTZ_DAMPING=6.,
        num_observation=512, num_holdout_observation=480)
    for key, value in expected.items():
        if config[key] != value:
            raise ValueError(f'Seed {seed}: unexpected {key}={config[key]!r}')
    return status


def prepare(args):
    root, batch = args.root.resolve(), args.batch.resolve()
    files = ["sampling.py", "plot_helmholtz.py"] + [f"{p}/{f}" for p, f in PROBLEMS.items()]
    for rel in files:
        if not (root / rel).is_file():
            raise FileNotFoundError(root / rel)
        ast.parse((root / rel).read_text())
    # Validate imports against the bundled, NS-tested sampling implementation.
    shared = ast.parse((root / "sampling.py").read_text())
    exports = {n.name for n in shared.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    for p, f in PROBLEMS.items():
        tree = ast.parse((root / p / f).read_text())
        for n in tree.body:
            if isinstance(n, ast.ImportFrom) and n.module in {"sampling", "gad_sampling"}:
                missing = {a.name for a in n.names} - exports
                if missing:
                    raise ValueError(f"{p}: missing sampler exports {missing}")
    batch.mkdir(parents=True, exist_ok=False)
    (batch / "logs").mkdir()
    source = batch / "source"
    source.mkdir()
    original_hashes, patched_hashes = {}, {}
    for rel in files:
        target = source / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        text = (root / rel).read_text()
        original_hashes[rel] = digest(root / rel)
        if rel == "helmholtz/helmholtz.py":
            tree = ast.parse(text)
            seed_nodes = [n for n in tree.body if isinstance(n, ast.Assign)
                          and any(isinstance(t, ast.Name) and t.id == 'seed' for t in n.targets)]
            if len(seed_nodes) != 1 or 'IP_RUN_SEED' not in ast.get_source_segment(text, seed_nodes[0]):
                raise ValueError("Helmholtz must have exactly one IP_RUN_SEED assignment")
        ast.parse(text)
        target.write_text(text)
        patched_hashes[rel] = digest(target)
    for rel in ["manage.py", "run_repeat.slurm", "aggregate_repeats.slurm", "smoke_test.slurm", "environment.sh", "README.md", "submit_repeats.sh", "figure_captions.tex", "experiment_setup.tex"]:
        shutil.copy2(Path(__file__).parent / rel, source / rel)
        patched_hashes[rel] = digest(source / rel)
    shutil.copytree(root / 'provenance', source / 'provenance')
    for path in (source / 'provenance').rglob('*'):
        if path.is_file():
            patched_hashes[str(path.relative_to(source))] = digest(path)
    manifest = {
        "created_utc": now(), "root": str(root), "batch": str(batch),
        "seeds": SEEDS, "problems": PROBLEMS, "methods": METHODS,
        "task_assignment": [{"task": i, "problem": p, "seed": s} for i, (p, s) in enumerate(assignments())],
        "original_sha256": original_hashes, "snapshot_sha256": patched_hashes,
        "changes": ["preserved Helmholtz physics; NS-analogous sampler configuration; seed via IP_RUN_SEED"],
        "replication_unit": "truth, training/held-out noise, and sampler randomness vary with master seed; source and receiver geometry are fixed; methods paired within realization",
        "configuration": "NS-analogous Helmholtz defaults; inherited IP_ITER_*, IP_MALA_*, IP_DENSITY_*, problem-specific overrides and HLSI_SAMPLING_MODULE cleared",
    }
    dump(batch / "batch_manifest.json", manifest)
    print(f"Prepared {batch}", flush=True)


def run(args):
    batch = args.batch.resolve()
    manifest = verify_source(batch)
    jobs = manifest["task_assignment"]
    if not 0 <= args.task < len(jobs):
        raise ValueError("task must be in 0..9")
    job = jobs[args.task]
    problem, seed = job["problem"], job["seed"]
    source = batch / "source"
    for rel, expected in manifest["snapshot_sha256"].items():
        if digest(source / rel) != expected:
            raise RuntimeError(f"Frozen source changed: {rel}")
    workspace = batch / problem / "run_results" / f"seed_{seed}"
    if workspace.exists():
        try:
            verified_status(batch, seed)
            print(f'Seed {seed} is already complete and verified; skipping.')
            return
        except (OSError, KeyError, ValueError):
            failed = batch / 'failed_attempts'
            failed.mkdir(exist_ok=True)
            workspace.rename(failed / f'seed_{seed}_{dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")}')
    workspace.mkdir(parents=True, exist_ok=False)
    script = workspace / problem / PROBLEMS[problem]
    script.parent.mkdir()
    shutil.copy2(source / problem / script.name, script)
    shutil.copy2(source / "sampling.py", workspace / "sampling.py")
    shutil.copy2(source / "plot_helmholtz.py", workspace / "plot_helmholtz.py")
    inherited = {k: v for k, v in os.environ.items() if k.startswith(("IP_ITER_", "IP_MALA_", "IP_DENSITY_", "IP_DARCY_ITER_", "IP_NAVIER_ITER_", "IP_HELMHOLTZ_ITER_")) or k == "HLSI_SAMPLING_MODULE"}
    for key in inherited:
        os.environ.pop(key)
    os.environ["IP_RUN_SEED"] = str(seed)
    os.environ["IP_RUN_KIND"] = "paper"
    os.environ["MPLBACKEND"] = "Agg"
    os.environ["JAX_PLATFORMS"] = "cuda"
    os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")
    os.environ.setdefault("XLA_PYTHON_CLIENT_MEM_FRACTION", "0.20")
    # Prevent a separately installed gad_sampling/sampling on PYTHONPATH from
    # taking precedence over the immutable local copy.
    sys.path.insert(0, str(workspace))
    metadata = {
        "problem": problem, "seed": seed, "task": args.task, "started_utc": now(),
        "status": "running", "hostname": socket.gethostname(), "platform": platform.platform(),
        "python": sys.version, "python_executable": sys.executable,
        "discarded_config_overrides": inherited,
        "environment": {k: v for k, v in os.environ.items() if k.startswith(("SLURM_", "IP_")) or k in {
            "OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS",
            "MPLBACKEND", "JAX_PLATFORMS", "XLA_PYTHON_CLIENT_PREALLOCATE", "XLA_PYTHON_CLIENT_MEM_FRACTION"}},
        "source_sha256": manifest["snapshot_sha256"],
    }
    status_file = workspace / "status.json"
    dump(status_file, metadata)
    start = time.monotonic()
    print(f"Running {problem}, seed {seed}, workspace {workspace}", flush=True)
    try:
        import numpy as np
        import torch
        import jax
        if not torch.cuda.is_available():
            raise RuntimeError("PyTorch cannot see CUDA; refusing a CPU run")
        if not any(d.platform == "gpu" for d in jax.devices()):
            raise RuntimeError("JAX cannot see a GPU; refusing a CPU run")
        metadata["torch_gpu"] = torch.cuda.get_device_name(0)
        metadata["torch_cuda_version"] = torch.version.cuda
        metadata["jax_devices"] = [str(d) for d in jax.devices()]
        metadata["versions"] = {}
        for package in ["numpy", "pandas", "scipy", "matplotlib", "torch", "jax", "jaxlib"]:
            metadata["versions"][package] = importlib.metadata.version(package)
        freeze = subprocess.run([sys.executable, "-m", "pip", "freeze"], text=True, capture_output=True)
        (workspace / "pip_freeze.txt").write_text(freeze.stdout + freeze.stderr)
        dump(status_file, metadata)
        os.chdir(script.parent)
        result = runpy.run_path(str(script), run_name="__main__")

        def to_numpy(x):
            if torch.is_tensor(x):
                return x.detach().cpu().numpy()
            return np.asarray(x)

        keys = ["alpha_true_np", "Basis", "obs_indices_train", "obs_indices_holdout", "y_clean_np", "y_obs_np",
                "y_clean_holdout_np", "y_holdout_obs_np", "true_field", "true_complex_wavefields", "mode_decay", "support_mask", "source_terms", "source_centers", "receiver_flat_indices", "holdout_receiver_flat_indices", "boundary_indices_ordered"]
        np.savez_compressed(workspace / "realization.npz", **{k: to_numpy(result[k]) for k in keys if k in result})
        np.savez_compressed(workspace / "posterior_samples.npz",
                            **{k: to_numpy(v) for k, v in result.get("samples", {}).items()})
        metrics = list((script.parent / "run_results").rglob("*_metrics.csv"))
        runinfo = list((script.parent / "run_results").rglob("*_runinfo.csv"))
        if len(metrics) != 1 or len(runinfo) != 1:
            raise RuntimeError(f"Expected one metrics and one runinfo file; found {len(metrics)}, {len(runinfo)}")
        config_path = metrics[0].parent / 'experiment_config.json'
        artifacts = [metrics[0], runinfo[0], config_path, workspace/'realization.npz',
                     workspace/'posterior_samples.npz', metrics[0].parent/'samples_all_rounds.npz']
        metadata.update(status="complete", metrics_csv=str(metrics[0].relative_to(batch)),
                        runinfo_csv=str(runinfo[0].relative_to(batch)), config_json=str(config_path.relative_to(batch)),
                        artifact_sha256={str(path.relative_to(batch)):digest(path) for path in artifacts})
        dump(status_file, metadata)
        verified_status(batch, seed)
    except BaseException:
        metadata.update(status="failed", traceback=traceback.format_exc())
        raise
    finally:
        metadata.update(finished_utc=now(), elapsed_seconds=time.monotonic() - start)
        dump(status_file, metadata)


def aggregate(args):
    import numpy as np
    import pandas as pd
    batch = args.batch.resolve()
    manifest = verify_source(batch)
    rows, info_frames, status_rows, errors = [], [], [], []
    for job in manifest["task_assignment"]:
        p, s = job["problem"], job["seed"]
        status_file = batch / p / "run_results" / f"seed_{s}" / "status.json"
        if not status_file.exists():
            errors.append(f"{p} seed {s}: no status file (not started or setup failed)")
            continue
        status = json.loads(status_file.read_text())
        status_rows.append({k: status.get(k) for k in ["problem", "seed", "status", "hostname", "torch_gpu", "elapsed_seconds"]})
        if status.get("status") != "complete":
            errors.append(f"{p} seed {s}: {status.get('status')}; see {status_file}")
            continue
        try:
            verified_status(batch, s)
        except (OSError, KeyError, ValueError) as exc:
            errors.append(f'{p} seed {s}: {exc}')
            continue
        metric_path, info_path = batch / status["metrics_csv"], batch / status["runinfo_csv"]
        frame = pd.read_csv(metric_path)
        if "metric" not in frame or any(m not in frame for m in METHODS) or frame["metric"].duplicated().any():
            errors.append(f"Invalid metrics schema or duplicated metric in {metric_path}")
            continue
        # Expose a missing entire metric (e.g. a swallowed held-out evaluation
        # failure), as well as a NaN in one run, in the numeric counts/audit.
        for metric in PRIMARY_METRICS + [STATE_METRICS[p]]:
            if metric not in set(frame["metric"]):
                frame.loc[len(frame)] = {"metric": metric, **{m: np.nan for m in METHODS}}
        for method in METHODS:
            for metric, value in zip(frame["metric"], frame[method]):
                rows.append({"problem": p, "seed": s, "method": method, "metric": metric,
                             "value": pd.to_numeric(value, errors="coerce")})
        info = pd.read_csv(info_path)
        if "label" not in info or set(info["label"]) != set(METHODS) or info["label"].duplicated().any():
            errors.append(f"Invalid or duplicated runinfo methods in {info_path}")
            continue
        expected_work = {'LFGI-GAD-1':6000, 'LFGI-GAD-3':18000, 'MALA':17984}
        work = info.set_index('label')['pde_solve_count']
        if any(int(work[label]) != count for label, count in expected_work.items()):
            errors.append(f'{p} seed {s}: work counts do not match the frozen NS-analogous configuration')
            continue
        info.insert(0, "problem", p)
        info.insert(1, "seed", s)
        info_frames.append(info)
    pd.DataFrame(status_rows).to_csv(batch / "completion_status.csv", index=False)
    if errors:
        raise RuntimeError("Refusing incomplete batch aggregation:\n" + "\n".join(errors))
    out = batch / "meta_results"
    out.mkdir(exist_ok=True)
    long = pd.DataFrame(rows)
    long.to_csv(out / "metrics_per_seed.csv", index=False)
    finite = long.assign(value=long["value"].where(np.isfinite(long["value"])))
    stats = finite.groupby(["problem", "method", "metric"])["value"].agg(["mean", "std", "count"]).reset_index()
    stats = stats.rename(columns={"count": "n_finite"})
    stats["n_expected"] = len(SEEDS)
    stats.to_csv(out / "metrics_numeric.csv", index=False)
    primary = stats.metric.isin(PRIMARY_METRICS + list(STATE_METRICS.values()))
    invalid = stats.loc[primary & (stats.n_finite != len(SEEDS))]
    if len(invalid):
        dump(out / 'aggregation_audit.json', {'error':'required metrics are missing/nonfinite',
             'invalid':invalid.to_dict('records')})
        raise RuntimeError('Required metrics are missing/nonfinite; no publication tables were produced')
    info = pd.concat(info_frames, ignore_index=True)
    info.to_csv(out / "runinfo_per_seed.csv", index=False)
    numeric_cols = [c for c in info.select_dtypes(include="number") if c != "seed"]
    info.groupby(["problem", "label"])[numeric_cols].agg(["mean", "std", "count"]).to_csv(out / "runinfo_summary.csv")
    contrasts = []
    rng = np.random.default_rng(20261021)
    for (problem, metric), group in long.groupby(["problem", "metric"], sort=True):
        wide = group.pivot(index="seed", columns="method", values="value")
        for lhs, rhs in [("LFGI-GAD-3", "MALA"), ("LFGI-GAD-1", "MALA"), ("LFGI-GAD-3", "LFGI-GAD-1")]:
            diff = (wide[lhs] - wide[rhs]).to_numpy(dtype=float)
            diff = diff[np.isfinite(diff)]
            n = len(diff)
            if n:
                boot = diff[rng.integers(0, n, size=(10000, n))].mean(axis=1)
                lo, hi = np.quantile(boot, [0.025, 0.975])
                mean = diff.mean()
                sd = diff.std(ddof=1) if n > 1 else np.nan
            else:
                mean = sd = lo = hi = np.nan
            contrasts.append({"problem": problem, "metric": metric, "lhs": lhs, "rhs": rhs,
                              "n_pairs": n, "mean_difference": mean, "std_difference": sd,
                              "bootstrap_95_low": lo, "bootstrap_95_high": hi})
    pd.DataFrame(contrasts).to_csv(out / "paired_contrasts.csv", index=False)
    write_latex_tables(stats, out, info)
    for problem in PROBLEMS:
        group=stats[stats.problem==problem].copy()
        group['formatted']=group.apply(lambda row:f"{row['mean']:.4g} +/- {row['std']:.3g}" if row.n_finite==len(SEEDS) else f"check n={int(row.n_finite)}",axis=1)
        group.pivot(index='metric',columns='method',values='formatted').reindex(columns=METHODS).to_csv(out/problem/'meta_metrics.csv')
    quality = {
        "complete_runs": len(status_rows), "expected_runs": 10,
        "metrics_with_missing_or_nonfinite_values": stats.loc[stats.n_finite != len(SEEDS)].to_dict("records"),
        "bootstrap_resamples": 10000, "bootstrap_seed": 20261021,
        "bootstrap_unit": "paired realization/master seed; percentile interval for the mean paired difference",
        "warning": "Ten seeds give limited precision; bootstrap intervals are descriptive, unadjusted for multiple comparisons. MMD uses MALA as reference; KLdiag is a diagnostic proxy, not true KL.",
    }
    dump(out / "aggregation_audit.json", quality)
    (out / "summary.txt").write_text(
        "Completed 10 Helmholtz runs; master seeds 42..51.\n"
        "Tables report mean +/- sample SD across independent problem realizations.\n"
        "Paired differences are lhs minus rhs; for lower-is-better metrics negative favors lhs.\n"
        "Non-finite entries remain visible in numeric counts and aggregation_audit.json.\n"
        "Use runinfo_per_seed.csv for MALA acceptance, R-hat, work, and runtime.\n"
        "Keep the entire batch directory, including source, logs, realization and posterior arrays.\n")
    # Include all-round banks and field summaries for audit/replotting, and the
    # preselected seed-42 PDFs for representative figures.
    archive = batch / "manuscript_update_inputs.zip"
    paths = set((batch / "source").rglob("*")) | set(out.rglob("*")) | set((batch / "logs").rglob("*"))
    paths.update(batch.glob("*.json"))
    paths.update(batch.glob("*.csv"))
    paths.update(batch.glob("*_job_id.txt"))
    for p in PROBLEMS:
        for pattern in ["status.json", "pip_freeze.txt", "realization.npz", "*_parameters.txt", "*_metrics.csv", "*_runinfo.csv", "experiment_config.json", "evaluation_diagnostics.json", "plot_metadata.json", "pca_basis.npz", "field_summaries.npz", "samples_all_rounds.npz"]:
            paths.update((batch / p).rglob(pattern))
    paths.update((batch / "helmholtz/run_results/seed_42").rglob("*.pdf"))
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zipped:
        for path in sorted(paths):
            if path.is_file() and "__pycache__" not in path.parts:
                zipped.write(path, path.relative_to(batch))
    print(f"Validated all 10 Helmholtz runs. Tables: {out}", flush=True)
    print(f"Manuscript handoff: {archive}", flush=True)


def write_latex_tables(stats, out, info):
    """Draft replacements for the two headline tables; no invented results."""
    def number(value, precision):
        text = f"{value:.{precision}g}"
        if "e" in text:
            mantissa, exponent = text.split("e")
            return mantissa + r"\times 10^{" + str(int(exponent)) + "}"
        return text

    def cell(problem, method, metric):
            sub = stats.loc[stats.problem == problem].set_index(["method", "metric"])
            if (method, metric) not in sub.index:
                return r"\text{missing}"
            row = sub.loc[(method, metric)]
            if int(row.n_finite) != len(SEEDS):
                return r"\text{check }n=" + str(int(row.n_finite))
            return number(row["mean"], 4) + r" \pm " + number(row["std"], 3)

    for problem in PROBLEMS:
        lines = ["% Generated from ten seeds; mean +/- sample SD. KLdiag is a proxy.",
                 r"\noindent\resizebox{\textwidth}{!}{%",
                 r"\begin{tabular}{llccccc}", r"\toprule",
                 r"Method & Round & $\mathrm{RMSE}_{\alpha}$ & $\mathrm{RMSE}_{\mathrm{field}}$ & Fwd Err & Held-out NLL & $\widetilde{\mathrm{KL}}$ \\",
                 r"\midrule"]
        for method, label, round_ in [("LFGI-GAD-1", "q-LFGI--GN GAD", "1"), ("LFGI-GAD-3", "q-LFGI--GN GAD", "3"), ("MALA", "MALA", "---")]:
            cells = ["$" + cell(problem, method, m) + "$" for m in ["RMSE_alpha", "RMSE_field", "FwdRelErr", "HeldoutPredNLL", "KLdiag"]]
            lines.append(" & ".join([label, round_, *cells]) + r" \\")
        lines += [r"\bottomrule", r"\end{tabular}", r"}"]
        (out / problem).mkdir(exist_ok=True)
        (out / problem / "headline_table.tex").write_text("\n".join(lines) + "\n")
    lines = ["% State RMSE: complex scattered wavefield over all four sources. Mean +/- sample SD.",
             r"\noindent\resizebox{\textwidth}{!}{%",
             r"\begin{tabular}{lllcccc}", r"\toprule",
             r"Problem & Method & Round & KSD & Std. residual RMS ($\to 1$) & Wave RMSE & Work proxy \\", r"\midrule"]
    for problem, label in [("helmholtz", "Helmholtz")]:
        for method, name, round_ in [("LFGI-GAD-1", "GAD", "1"), ("LFGI-GAD-3", "GAD", "3"), ("MALA", "MALA", "---")]:
            cells = ["$" + cell(problem, method, m) + "$" for m in ["KSD", "HeldoutStdResRMS", STATE_METRICS[problem]]]
            work = info.loc[(info.problem == problem) & (info.label == method), "pde_solve_count"]
            proxy = "$" + number(work.mean(), 4) + r" \pm " + number(work.std(), 3) + "$"
            lines.append(" & ".join([label, name, round_, *cells, proxy]) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}", r"}"]
    (out / "secondary_table.tex").write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--batch", type=Path, required=True)
    p = sub.add_parser("run")
    p.add_argument("--batch", type=Path, required=True)
    p.add_argument("--task", type=int, required=True)
    p = sub.add_parser("aggregate")
    p.add_argument("--batch", type=Path, required=True)
    p = sub.add_parser('missing-tasks')
    p.add_argument('--batch', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'missing-tasks':
        batch=args.batch.resolve()
        verify_source(batch)
        missing=[]
        for task,seed in enumerate(SEEDS):
            try:
                verified_status(batch,seed)
            except (OSError,ValueError,KeyError):
                missing.append(str(task))
        print(','.join(missing))
        return
    {"prepare": prepare, "run": run, "aggregate": aggregate}[args.command](args)


if __name__ == "__main__":
    main()
