"""Paper-scale Helmholtz diagnostics, generated from retained evaluation samples."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ORDER = ['LFGI-GAD-1', 'LFGI-GAD-3', 'MALA']


def style():
    plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':8,
        'axes.titlesize':8, 'axes.labelsize':8, 'xtick.labelsize':7,
        'ytick.labelsize':7, 'pdf.fonttype':42, 'ps.fonttype':42,
        'savefig.facecolor':'white'})


def save(fig, directory, stem, qa_label=None):
    if qa_label:
        fig.text(.5,.5,qa_label,ha='center',rotation=25,color='#A00000',alpha=.25,fontsize=15)
    fig.savefig(Path(directory)/(stem+'.pdf'), bbox_inches='tight')
    fig.savefig(Path(directory)/(stem+'.png'), dpi=400, bbox_inches='tight')
    plt.close(fig)


def plot_contrast(directory, truth, means, stds, names, qa_label=None):
    style()
    methods=[key for key in ORDER if key in means]
    fig,axes=plt.subplots(3,len(methods)+1,figsize=(6.5,5.3),squeeze=False)
    rows = [[truth, *[means[key] for key in methods]],
            [np.zeros_like(truth), *[np.abs(means[key]-truth) for key in methods]],
            [None, *[stds[key] for key in methods]]]
    signed=max(float(np.max(np.abs(a))) for a in rows[0]) or 1e-12
    limits=[(-signed,signed),(0,max(float(np.max(a)) for a in rows[1]) or 1e-12),
            (0,max(float(np.max(stds[k])) for k in methods) or 1e-12)]
    cmaps=['RdBu_r','magma','viridis']
    for r in range(3):
        artist=None
        for c,array in enumerate(rows[r]):
            ax=axes[r,c]
            if array is None:
                ax.text(.5,.5,'Not defined\nfor fixed truth',ha='center',va='center',transform=ax.transAxes,fontsize=7)
                ax.set_xlim(0,1);ax.set_ylim(0,1);ax.set_aspect('equal')
            else:
                artist=ax.imshow(array,origin='lower',extent=(0,1,0,1),cmap=cmaps[r],
                    vmin=limits[r][0],vmax=limits[r][1],interpolation='nearest')
            ax.set_xticks([0,1]);ax.set_yticks([0,1])
            if c:ax.set_yticklabels([])
            if r<2:ax.set_xticklabels([])
            else:ax.set_xlabel('$x_1$',labelpad=1)
            ax.tick_params(length=2,pad=1)
            if not c:ax.set_ylabel('$x_2$',labelpad=1)
            if r==0:ax.set_title('Truth' if c==0 else names[methods[c-1]],pad=5)
        axes[r,0].text(-.44,.5,['Contrast at mean coefficient','Absolute error','Contrast sample SD'][r],
            transform=axes[r,0].transAxes,ha='center',va='center',fontsize=8,rotation=90)
        colorax=fig.add_axes([.92, .69-r*.285, .014, .20])
        fig.colorbar(artist,cax=colorax).ax.tick_params(labelsize=6,length=2)
    fig.subplots_adjust(left=.16,right=.89,bottom=.08,top=.94,hspace=.20,wspace=.10)
    save(fig,directory,'helmholtz_contrast',qa_label)
    return dict(field='0.45*tanh(KL field)*support mask', mean_estimator='contrast at retained coefficient posterior mean',
                uncertainty='pointwise sample SD over all retained evaluation particles, ddof=1',
                limits=limits, shared_limits='within each row across every method', extent=[0,1,0,1])


def plot_wavefields(directory, truth, means, names, qa_label=None):
    style()
    methods=[key for key in ORDER if key in means]
    arrays=[truth[:,:,0],*[means[key][:,:,0] for key in methods]]
    fig,axes=plt.subplots(2,len(arrays),figsize=(6.5,3.6),squeeze=False)
    limits=[]
    for row,fun in enumerate([np.real,np.imag]):
        limit=max(float(np.abs(fun(a)).max()) for a in arrays) or 1e-12
        limits.append([-limit,limit])
        for col,array in enumerate(arrays):
            ax=axes[row,col]
            artist=ax.imshow(fun(array),origin='lower',extent=(0,1,0,1),cmap='RdBu_r',
                vmin=-limit,vmax=limit,interpolation='nearest')
            ax.set_xticks([0,1]);ax.set_yticks([0,1]);ax.tick_params(length=2,pad=1)
            if col:ax.set_yticklabels([])
            else:ax.set_ylabel('$x_2$',labelpad=1)
            if row==0:
                ax.set_xticklabels([]);ax.set_title('Truth' if col==0 else names[methods[col-1]])
            else:ax.set_xlabel('$x_1$',labelpad=1)
        axes[row,0].text(-.44,.5,['Real scattered field','Imaginary scattered field'][row],
            transform=axes[row,0].transAxes,ha='center',va='center',fontsize=8,rotation=90)
        colorax=fig.add_axes([.92,.56-row*.43,.014,.29])
        fig.colorbar(artist,cax=colorax).ax.tick_params(labelsize=6,length=2)
    fig.subplots_adjust(left=.16,right=.89,bottom=.12,top=.91,wspace=.1,hspace=.18)
    save(fig,directory,'helmholtz_wavefields',qa_label)
    return dict(source_index=0,quantity='complex scattered field at retained coefficient posterior mean',
                limits=limits,extent=[0,1,0,1], shared_limits='within real/imaginary rows across methods',
                scalar_state_metric='RMSE_wavefield uses all four sources, not only source 0')


def plot_pca(directory, samples, truth, names, qa_label=None):
    style()
    methods=[key for key in ORDER if key in samples]
    anchor=np.asarray(samples['LFGI-GAD-3'])
    center=anchor.mean(axis=0)
    _,_,vectors=np.linalg.svd(anchor-center,full_matrices=False)
    basis=vectors[:4].T
    projection={key:(np.asarray(samples[key])-center)@basis for key in methods}
    truth_proj=(np.asarray(truth)-center)@basis
    fig,axes=plt.subplots(2,len(methods),figsize=(6.5,4.1),squeeze=False)
    metadata=[]
    for row,(i,j) in enumerate([(0,1),(2,3)]):
        pooled=np.concatenate([projection[key][:,[i,j]] for key in methods]+[truth_proj[[i,j]][None,:]])
        low=pooled.min(0);high=pooled.max(0);pad=np.maximum(high-low,1e-8)*.05
        low-=pad;high+=pad
        histograms=[]
        for key in methods:
            count,xe,ye=np.histogram2d(projection[key][:,i],projection[key][:,j],bins=60,
                range=[[low[0],high[0]],[low[1],high[1]]])
            histograms.append(count/(len(samples[key])*(xe[1]-xe[0])*(ye[1]-ye[0])))
        vmax=max(float(a.max()) for a in histograms) or 1e-12
        for col,(key,hist) in enumerate(zip(methods,histograms)):
            ax=axes[row,col]
            artist=ax.imshow(hist.T,origin='lower',extent=(low[0],high[0],low[1],high[1]),
                aspect='auto',cmap='Blues',vmin=0,vmax=vmax,interpolation='nearest')
            ax.scatter(truth_proj[i],truth_proj[j],marker='x',color='#B22632',s=18,linewidths=1)
            ax.set_xlabel(f'PC {i+1}',labelpad=1)
            if col==0:ax.set_ylabel(f'PC {j+1}',labelpad=1)
            if row==0:ax.set_title(names[key])
            ax.tick_params(length=2,pad=1)
            ax.locator_params(axis='both',nbins=3)
        colorax=fig.add_axes([.92,.59-row*.45,.014,.25])
        fig.colorbar(artist,cax=colorax).ax.tick_params(labelsize=6,length=2)
        metadata.append(dict(pc_pair=[i+1,j+1],lower=low.tolist(),upper=high.tolist(),density_max=vmax))
    fig.subplots_adjust(left=.09,right=.89,bottom=.12,top=.90,wspace=.38,hspace=.5)
    save(fig,directory,'helmholtz_pca',qa_label)
    np.savez_compressed(Path(directory)/'pca_basis.npz',center=center,basis=basis,truth_projection=truth_proj)
    return dict(anchor='LFGI-GAD-3', centering='anchor retained mean',basis='right singular vectors of centered anchor samples',
                histogram_bins=60,normalization='count/(full retained sample count * bin area)',smoothing=None,
                window='all retained method projections and synthetic truth plus 5% padding; no additional clipping',
                truth_marker='red x',panels=metadata,retained_counts={key:len(samples[key]) for key in methods})
