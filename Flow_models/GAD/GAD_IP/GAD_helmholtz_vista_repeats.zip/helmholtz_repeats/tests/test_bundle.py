"""CPU checks; synthetic workflow fixtures are not Helmholtz sampling results."""
import argparse
import ast
from collections import OrderedDict
import contextlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import manage


def source():
    return (ROOT/'helmholtz/helmholtz.py').read_text()


def config(text=None):
    text=text or source()
    if '# === NS-ANALOGOUS SAMPLER SETTINGS ===' in text:
        block=text.split('# === NS-ANALOGOUS SAMPLER SETTINGS ===')[1].split('# === EXECUTION ===')[0]
    else:
        block=text[text.index('ACTIVE_DIM = num_truncated_series'):text.index('\nconfigure_sampling(',text.index('ACTIVE_DIM = num_truncated_series'))]
    names={'os':os,'np':np,'OrderedDict':OrderedDict,'num_truncated_series':32}
    with patch.dict(os.environ,{},clear=True):
        exec(compile(block,'sampler_settings','exec'),names)
    return names


def fixture(parent):
    parent=Path(parent)
    batch=parent/'batch'
    manage.prepare(argparse.Namespace(root=ROOT,batch=batch))
    cfg=config()
    keys=['ACTIVE_DIM','N_REF','DEFAULT_N_GEN','ITERATIVE_TRANSPORT_ROUNDS','TRANSPORT_STEPS',
          'MALA_N_CHAINS','MALA_WARMUP','MALA_THIN','MALA_DT','MALA_TARGET_ACCEPT','HESS_MIN','HESS_MAX','HELDOUT_BATCH_SIZE','NOISE_STD']
    for i,seed in enumerate(manage.SEEDS):
        workspace=batch/'helmholtz/run_results'/f'seed_{seed}'
        result=workspace/'helmholtz/run_results/fixture_run'
        result.mkdir(parents=True)
        experiment={key:cfg[key] for key in keys}
        experiment.update(seed=seed,run_kind='paper',N=32,HELMHOLTZ_K=24.,HELMHOLTZ_DAMPING=6.,
                          num_observation=512,num_holdout_observation=480)
        (result/'experiment_config.json').write_text(json.dumps(experiment))
        values={method:[(i+1)*factor*(j+1) for j in range(8)] for method,factor in
                [('LFGI-GAD-1',2.),('LFGI-GAD-3',1.),('MALA',3.)]}
        names=manage.PRIMARY_METRICS+['RMSE_wavefield']
        pd.DataFrame({'metric':names,**values}).to_csv(result/'fixture_metrics.csv',index=False)
        rows=[dict(label=method,pde_solve_count=work,runtime_seconds=2.,mala_acceptance_rate=.5,
                   mala_rhat_max=1.1) for method,work in [('LFGI-GAD-1',6000),('LFGI-GAD-3',18000),('MALA',17984)]]
        pd.DataFrame(rows).to_csv(result/'fixture_runinfo.csv',index=False)
        np.savez_compressed(workspace/'realization.npz',alpha_true_np=np.zeros(32),Basis=np.zeros((1024,32)))
        np.savez_compressed(workspace/'posterior_samples.npz',**{m:np.zeros((2000,32)) for m in manage.METHODS})
        np.savez_compressed(result/'samples_all_rounds.npz',**{m:np.zeros((2000,32)) for m in ['LFGI-GAD-1','LFGI-GAD-2','LFGI-GAD-3','MALA']})
        artifacts=[result/'experiment_config.json',result/'fixture_metrics.csv',result/'fixture_runinfo.csv',
                   workspace/'realization.npz',workspace/'posterior_samples.npz',result/'samples_all_rounds.npz']
        status=dict(problem='helmholtz',seed=seed,status='complete',metrics_csv=str((result/'fixture_metrics.csv').relative_to(batch)),
            runinfo_csv=str((result/'fixture_runinfo.csv').relative_to(batch)),config_json=str((result/'experiment_config.json').relative_to(batch)),
            artifact_sha256={str(p.relative_to(batch)):manage.digest(p) for p in artifacts})
        manage.dump(workspace/'status.json',status)
    return batch


class BundleTests(unittest.TestCase):
    def test_sampler_matches_ns(self):
        helm=config()
        ns=config((ROOT/'provenance/navier_stokes_reference.py').read_text())
        keys=['N_REF','DEFAULT_N_GEN','TRANSPORT_STEPS','ITERATIVE_TRANSPORT_ROUNDS','MALA_N_CHAINS',
              'MALA_WARMUP','MALA_DRAWS_PER_CHAIN','MALA_DT','HESS_MIN','HESS_MAX','SAMPLER_CONFIGS']
        for key in keys:self.assertEqual(helm[key],ns[key],key)
        self.assertEqual(helm['MALA_EXPECTED_PDE_PROXY'],17984)
        self.assertEqual(helm['GAD3_EXPECTED_PDE_PROXY'],18000)
        self.assertFalse(helm['SAMPLER_CONFIGS']['LFGI-GAD-2']['include_results'])

    def test_preserved_physical_block(self):
        original=(ROOT/'provenance/helmholtz_original.py').read_text()
        old=original[original.index("os.makedirs('data'"):original.index('# Shared sampling / density-benchmark config')]
        new=source().split('# === BEGIN PRESERVED HELMHOLTZ MODEL ===')[1].split('# === END PRESERVED HELMHOLTZ MODEL ===')[0]
        new=new.replace('seed = int(os.environ.get("IP_RUN_SEED", "42"))','seed = 42')
        self.assertEqual(ast.dump(ast.parse(old)),ast.dump(ast.parse(new)))

    def test_numpy_forward_and_receiver_split(self):
        text=source()
        start=text.index("os.makedirs('data'")
        end=text.index('jax.config.update',start)
        scope=dict(os=os,np=np,pd=pd,cdist=cdist)
        previous=Path.cwd()
        with tempfile.TemporaryDirectory() as temp:
            try:
                os.chdir(temp)
                exec(compile(text[start:end],'geometry','exec'),scope)
            finally:os.chdir(previous)
        train,hold=scope['receiver_flat_indices'],scope['holdout_receiver_flat_indices']
        self.assertEqual((len(train),len(hold)),(64,60))
        self.assertEqual(len(np.intersect1d(train,hold)),0)
        self.assertEqual(len(np.union1d(train,hold)),124)
        n=scope['N'];size=n*n;grid=np.arange(size).reshape(n,n)
        lap=np.zeros((size,size),dtype=np.complex128);weight=(n-1)**2
        for left,right in [(grid[:-1,:].ravel(),grid[1:,:].ravel()),(grid[:,:-1].ravel(),grid[:,1:].ravel())]:
            np.add.at(lap,(left,left),weight);np.add.at(lap,(right,right),weight)
            np.add.at(lap,(left,right),-weight);np.add.at(lap,(right,left),-weight)
        self.assertTrue(np.allclose(lap.sum(1),0))
        scope.update(jnp=np,Basis=scope['basis_truncated'],support_mask_jax=scope['support_mask'],
            NEG_LAPLACIAN=lap,IDENTITY_WAVE=np.eye(size,dtype=np.complex128),
            source_terms_jax=scope['source_terms'],receiver_indices_jax=train,holdout_receiver_indices_jax=hold)
        functions=['_alpha_to_raw_and_contrast','_assemble_helmholtz_operator','_flatten_measurements_by_source',
                   '_flatten_measurements_by_source_generic','solve_forward','solve_forward_holdout']
        nodes=[]
        for node in ast.parse(text).body:
            if isinstance(node,ast.FunctionDef) and node.name in functions:
                node.decorator_list=[];nodes.append(node)
        exec(compile(ast.Module(body=nodes,type_ignores=[]),'numpy_physics','exec'),scope)
        background=scope['_assemble_helmholtz_operator'](np.ones((n,n)))
        scope['BACKGROUND_FIELDS']=np.linalg.solve(background,scope['source_terms'])
        zero=scope['solve_forward'](np.zeros(32))
        self.assertEqual(zero.shape,(512,));self.assertLess(float(np.max(np.abs(zero))),1e-12)
        alpha=np.linspace(-.3,.3,32)
        pred=scope['solve_forward'](alpha);held=scope['solve_forward_holdout'](alpha)
        self.assertEqual(held.shape,(480,));self.assertTrue(np.isfinite(pred).all())
        self.assertTrue(np.isfinite(held).all());self.assertGreater(float(np.linalg.norm(pred)),0)

    def test_ten_seed_aggregation_and_missing_selector(self):
        with tempfile.TemporaryDirectory() as temp:
            batch=fixture(temp)
            manage.aggregate(argparse.Namespace(batch=batch))
            stats=pd.read_csv(batch/'meta_results/metrics_numeric.csv')
            row=stats[(stats.method=='LFGI-GAD-3')&(stats.metric=='RMSE_alpha')].iloc[0]
            self.assertAlmostEqual(row['mean'],5.5)
            self.assertAlmostEqual(row['std'],np.std(np.arange(1,11),ddof=1))
            contrasts=pd.read_csv(batch/'meta_results/paired_contrasts.csv')
            row=contrasts[(contrasts.lhs=='LFGI-GAD-3')&(contrasts.rhs=='MALA')&(contrasts.metric=='RMSE_alpha')].iloc[0]
            self.assertAlmostEqual(row.mean_difference,-11)
            self.assertLess(row.bootstrap_95_high,0)
            self.assertTrue((batch/'manuscript_update_inputs.zip').is_file())
            (batch/'helmholtz/run_results/seed_51/status.json').unlink()
            result=subprocess.run([sys.executable,str(batch/'source/manage.py'),'missing-tasks','--batch',str(batch)],capture_output=True,text=True)
            self.assertEqual(result.stdout.strip(),'9',result.stderr)

    def test_reject_incomplete_and_nonfinite(self):
        with tempfile.TemporaryDirectory() as temp:
            batch=fixture(temp)
            status_path=batch/'helmholtz/run_results/seed_51/status.json'
            status=json.loads(status_path.read_text());status['status']='failed';manage.dump(status_path,status)
            with self.assertRaisesRegex(RuntimeError,'incomplete'):manage.aggregate(argparse.Namespace(batch=batch))
            status['status']='complete'
            p=batch/status['metrics_csv'];frame=pd.read_csv(p);frame.loc[0,'MALA']=np.nan;frame.to_csv(p,index=False)
            status['artifact_sha256'][str(p.relative_to(batch))]=manage.digest(p);manage.dump(status_path,status)
            with self.assertRaisesRegex(RuntimeError,'missing/nonfinite'):manage.aggregate(argparse.Namespace(batch=batch))
            self.assertFalse((batch/'meta_results/helmholtz/headline_table.tex').exists())

    def test_submission_and_aggregation_rejection(self):
        with tempfile.TemporaryDirectory() as temp:
            temp=Path(temp);bin_=temp/'bin';bin_.mkdir()
            sbatch=bin_/'sbatch'
            sbatch.write_text(f'#!{sys.executable}\nimport json,os,sys\nfrom pathlib import Path\np=Path(os.environ["CALLS"])\na=json.loads(p.read_text()) if p.exists() else []\na.append(sys.argv[1:]);p.write_text(json.dumps(a))\nif len(a)==2 and os.getenv("REJECT_AGG")=="1":sys.exit(1)\nprint("Site-wrapper preamble")\nprint(str(11000+len(a)))\n')
            sbatch.chmod(0o755)
            (bin_/'squeue').write_text('#!/bin/bash\n[[ "${ACTIVE:-0}" == 0 ]] || echo "11001_[0-9] RUNNING"\n')
            (bin_/'squeue').chmod(0o755)
            env={**os.environ,'PATH':str(bin_)+os.pathsep+os.environ['PATH'],'IP_SKIP_MODULES':'1',
                 'IP_BATCH_PARENT':str(temp/'batches'),'CALLS':str(temp/'calls.json')}
            result=subprocess.run(['bash',str(ROOT/'submit_repeats.sh'),'-A','TEST'],env=env,text=True,capture_output=True)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            calls=json.loads((temp/'calls.json').read_text());self.assertEqual(len(calls),2)
            self.assertIn('--array=0-9%2',calls[0]);self.assertIn('--dependency=afterany:11001',calls[1])
            self.assertIn('TEST',calls[1])
            batch=next((temp/'batches').iterdir())
            env['ACTIVE']='1'
            result=subprocess.run(['bash',str(ROOT/'submit_repeats.sh'),'--resume-batch',str(batch)],env=env,text=True,capture_output=True)
            self.assertEqual(result.returncode,2)
            env.update(REJECT_AGG='1',IP_BATCH_PARENT=str(temp/'failed'),CALLS=str(temp/'failed_calls.json'))
            result=subprocess.run(['bash',str(ROOT/'submit_repeats.sh')],env=env,text=True,capture_output=True)
            self.assertNotEqual(result.returncode,0)
            batch=next((temp/'failed').iterdir())
            self.assertEqual((batch/'run_job_id.txt').read_text().strip(),'11001')
            self.assertFalse((batch/'aggregate_job_id.txt').exists())


if __name__=='__main__':unittest.main()
