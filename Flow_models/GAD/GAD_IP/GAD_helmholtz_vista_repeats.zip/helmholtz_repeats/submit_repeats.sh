#!/bin/bash
set -eo pipefail
HELM_TOOLS_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
HELM_RESUME=""
HELM_PARALLEL=2
HELM_ACCOUNT=()
HELM_TIME="${IP_HELMHOLTZ_TIME:-04:00:00}"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --resume-batch) HELM_RESUME="$2"; shift 2 ;;
    --max-parallel) HELM_PARALLEL="$2"; shift 2 ;;
    --account|-A) HELM_ACCOUNT=(-A "$2"); shift 2 ;;
    --time|-t) HELM_TIME="$2"; shift 2 ;;
    *) printf 'Unknown option: %s\n' "$1" >&2; exit 2 ;;
  esac
done
[[ "$HELM_PARALLEL" =~ ^[1-9][0-9]*$ ]] || { echo '--max-parallel must be positive' >&2; exit 2; }
source "$HELM_TOOLS_DIR/environment.sh"
set -u
command -v sbatch >/dev/null
if [[ -n "$HELM_RESUME" ]]; then
  IP_BATCH_DIR="$(cd -- "$HELM_RESUME" && pwd)"
  HELM_IDS=$(python - "$IP_BATCH_DIR" <<'PY'
from pathlib import Path
import sys
print(','.join({p.read_text().strip() for p in Path(sys.argv[1]).glob('*_job_id.txt') if p.read_text().strip().isdigit()}))
PY
)
  if ! HELM_QUEUE=$(squeue -h -u "$USER" -o '%i %T'); then
    echo 'Cannot check active jobs; resubmission stopped to avoid duplicates.' >&2
    exit 2
  fi
  HELM_ACTIVE=$(python - "$HELM_IDS" "$HELM_QUEUE" <<'PY'
import re,sys
ids=set(sys.argv[1].split(','))
for line in sys.argv[2].splitlines():
    match=re.match(r'\s*(\d+)',line)
    if match and match.group(1) in ids:print(line)
PY
)
  if [[ -n "$HELM_ACTIVE" ]]; then
    printf 'This batch has active jobs:\n%s\nWait for completion or cancel obsolete dependent jobs before resuming.\n' "$HELM_ACTIVE" >&2
    exit 2
  fi
  HELM_TASKS=$(python "$IP_BATCH_DIR/source/manage.py" missing-tasks --batch "$IP_BATCH_DIR")
else
  IP_BATCH_DIR="${IP_BATCH_PARENT:-$HELM_TOOLS_DIR/../batches}/helmholtz_repeats_$(date +%Y%m%d_%H%M%S)_$$"
  python "$HELM_TOOLS_DIR/manage.py" prepare --root "$HELM_TOOLS_DIR" --batch "$IP_BATCH_DIR"
  IP_BATCH_DIR="$(cd -- "$IP_BATCH_DIR" && pwd)"
  HELM_TASKS=0-9
fi
export IP_BATCH_DIR
printf 'Batch: %s\n' "$IP_BATCH_DIR"
trap 'printf "Submission stopped. Inspect %s/logs/submit-*.log and *_job_id.txt. Resume with: bash %q --resume-batch %q\n" "$IP_BATCH_DIR" "$HELM_TOOLS_DIR/submit_repeats.sh" "$IP_BATCH_DIR" >&2' ERR
helm_submit() {
  local helm_stage="$1"
  shift
  local helm_log="$IP_BATCH_DIR/logs/submit-${helm_stage}-$(date +%s).log"
  if ! sbatch --parsable "${HELM_ACCOUNT[@]}" "$@" > "$helm_log" 2>&1; then
    cat "$helm_log" >&2
    return 1
  fi
  cat "$helm_log" >&2
  python - "$helm_log" "$IP_BATCH_DIR/${helm_stage}_job_id.txt" <<'PY'
from pathlib import Path
import re,sys
ids=re.findall(r'^\s*(?:Submitted batch job\s+)?([0-9]+)(?:;[^\s;]+)?\s*$',Path(sys.argv[1]).read_text(),re.MULTILINE)
if not ids:sys.exit('No Slurm job ID found; inspect the saved submission log before retrying.')
Path(sys.argv[2]).write_text(ids[-1]+'\n')
print(ids[-1])
PY
}
HELM_DEP=()
if [[ -n "$HELM_TASKS" ]]; then
  HELM_RUN_JOB=$(helm_submit run --time="$HELM_TIME" --array="${HELM_TASKS}%${HELM_PARALLEL}" \
    --export=ALL,IP_BATCH_DIR="$IP_BATCH_DIR" --output="$IP_BATCH_DIR/logs/run-%A_%a.out" \
    "$IP_BATCH_DIR/source/run_repeat.slurm")
  HELM_DEP=(--dependency="afterany:$HELM_RUN_JOB")
  printf 'Helmholtz array: %s (tasks %s, maximum simultaneous %s)\n' "$HELM_RUN_JOB" "$HELM_TASKS" "$HELM_PARALLEL"
fi
HELM_AGG_JOB=$(helm_submit aggregate "${HELM_DEP[@]}" --export=ALL,IP_BATCH_DIR="$IP_BATCH_DIR" \
  --output="$IP_BATCH_DIR/logs/aggregate-%j.out" "$IP_BATCH_DIR/source/aggregate_repeats.slurm")
printf 'Aggregation: %s\nMonitor: squeue -u "$USER"\nReturn: %s/manuscript_update_inputs.zip\n' "$HELM_AGG_JOB" "$IP_BATCH_DIR"
trap - ERR
