# Validation during bundle preparation

Six CPU tests passed:

1. The Helmholtz sampler schedule matches the NS comparison: 2,000 particles, three rounds, 200 Heun steps, 32 MALA chains, 217 warmup transitions, and work proxies 18,000 versus 17,984.
2. The complete physical-model block has the same syntax tree as the supplied Helmholtz source, apart from reading the master seed from the environment.
3. A NumPy execution of the copied forward formulas confirms the 64/60 disjoint boundary-receiver split, 512/480 real measurement dimensions, zero scattering at zero contrast, and finite nonzero-contrast predictions. This checks the model formulas; it does not validate JAX differentiation or GPU execution.
4. A synthetic ten-seed fixture verifies aggregation means, sample SDs, paired bootstrap differences, complete result packaging, and selection of a missing seed for resubmission.
5. Incomplete batches and missing/nonfinite required metrics are rejected before publication tables are written.
6. A fake scheduler verifies the ten-task array, aggregation dependency, account propagation, immediate job-ID recording, active-job resubmission prevention, and preservation of the run ID after aggregation submission fails.

Python compilation and Bash syntax checks passed. All three figure templates were rendered with clearly watermarked synthetic inputs and visually inspected. Generated tables, figure captions, and setup text were compiled at the manuscript's 11-point size and margins, with no overfull boxes, unresolved labels, or layout warnings after stabilization. These generated QA figures and synthetic data are excluded from the delivered bundle.

Production PDE/MALA/GAD runs have not been executed locally. JAX and PyTorch are not installed in this workspace's runtime. Use the supplied optional GPU smoke job to check the complete numerical path in the working Vista environment. Production outputs record actual package versions, devices, settings, work counts, retention diagnostics, and reproducibility arrays.
