#!/bin/bash
if [[ "${IP_SKIP_MODULES:-0}" != 1 ]]; then
  module purge
  module load gcc/13.2.0
  module load python3/3.11.8
  source "${IP_VENV_DIR:-$SCRATCH/venvs/hlsi}/bin/activate"
fi
export OMP_NUM_THREADS=8 MKL_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 NUMEXPR_NUM_THREADS=8
export MPLBACKEND=Agg JAX_ENABLE_X64=true
export XLA_PYTHON_CLIENT_PREALLOCATE=false XLA_PYTHON_CLIENT_MEM_FRACTION=0.20
